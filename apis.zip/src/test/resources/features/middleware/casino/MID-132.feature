@regression @casino
@epic:MID-106-Casino
Feature: MID-132 - Trending Now
  https://opapgr.atlassian.net/browse/MID-132
  
  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header Accept = application/json
    And header locale = el-GR
    #And param location = base
    When path uip/casino/api/v1.0/games/trending

  Scenario: Trending Now
    And param location = base
    #And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
      "data": [
        {
            "href": "#string",
            "id": "#string",
            "name": "#string",
            "launchUrl": "#string",
            "backgroundImageUrl": "#string",
            "popularity": "#number",
            "isNew": "#boolean",
            "width": "#number",
            "height": "#number",
            "hasFunMode": "#boolean",
            "hasAnonymousFunMode": "#boolean",
            "thumbnail": "#string",
            "subVendor": "#string",
            "subVendorId": "#number",
            "subVendorDisplayName": "#any",
            "defaultThumbnail": "#string",
            "type": "casino-games",
            "minBet": "#any",
            "maxWin": "#any",
            "volatility": "#any",
            "liveCasinoCategory": "#any",
            "advancedTags": "#any",
            "logo": "#string",
            "slug": "#string",
            "theoreticalPayOut": "#number",
            "alias": "#any",
            "cellSize": "#any",
            "isVIPTable": "#any",
            "platform": "#any",
            "maxBetRestriction": "#any",
            "position": "#any",
            "groups": "#any",
            "subGroups": "#any",
           "groupInfos": "#any",
            "vendor": {
                "href": "#string"
            },
            "tags": "#object",
            "categories": "#object",
            "jackpots": "#object",
            "details": "#any",
            "promo": "#object",
            "exclusive": "#object",
            "gameCode": "#string",
            "ruleUrl": "#any",
            "helpUrl":  "#string",
            "languages": "#any",
            "currencies": "#any",
            "realMode": "#object",
            "license": "#string",
             "minHitFrequency": "#number",
            "maxHitFrequency":"#number",
            "jackpotContribution": "#any",
            "evolutionGamingTableID": "#any",
            "vendorGameID": "#string",
            "restrictedTerritories": "#any",
            "lobby": "#any",
             "gameId": "#number",
            "thumbnails": "#object",
            "fpp": "#number",
            "bonusContribution": "#number",
            "icons": "#object",
            "gid": "#any"
        }
     ]
     }
     """
    And match path $.data[*].platform should be #contains PC
    And match path $.data[*].href should be #contains everymatrix

  Scenario: Trending Now - player id as "#any" string
    And param location = base
    And header x-player-id = ""
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains For input string: ""
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Trending Now - player id hack
    And param location = base
    And header x-player-id = 99999999999999999999999
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains 99999999999999999999999
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Trending Now - no location
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains System Error: Required request parameter 'location'
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Trending Now - no location - no player id
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains System Error: Required request parameter 'location'
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001



