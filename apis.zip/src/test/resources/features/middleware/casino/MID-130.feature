@regression @casino
@epic:MID-106-Casino
Feature: MID-130 - Favorite Games
  https://opapgr.atlassian.net/browse/MID-130
  
  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Accept = application/json
    And header Content-Type = application/json
    And header locale = el-GR
    * def retryPattern = { "minutes": 5,"seconds" : 30,"pollMillis":5000,"status": 200 }
    When path uip/casino/api/v1.0/games/favorite


  Scenario Outline: Favorite Games - channel PC,iPhone,iPad, Android
    And param location = <location>
    And header x-player-id = {{playerId}}
    And header channel = <channel>
    And retry GET  until condition
      """
        {{retryPattern}}
      """
    Then status 200
    And match
     """
     {
      "data": [
        {
            "href": "#string",
            "id": "#string",
            "name": "#string",
            "launchUrl": "#string",
            "backgroundImageUrl": "#string",
            "popularity": "#number",
            "isNew": "#boolean",
            "width": "#number",
            "height": "#number",
            "hasFunMode": "#boolean",
            "hasAnonymousFunMode": "#boolean",
            "thumbnail": "#string",
            "subVendor": "#string",
            "subVendorId": "#number",
            "subVendorDisplayName": "#any",
            "metaTitle": "#any",
            "metaDescription": "#any",
            "defaultThumbnail": "#string",
            "type": "casino-games",
            "minBet": "#any",
            "maxWin": "#any",
            "volatility": "#any",
            "liveCasinoCategory": "#any",
            "advancedTags": "#any",
            "logo": "#string",
            "slug": "#string",
            "theoreticalPayOut": "#number",
            "alias": "#any",
            "cellSize": "#any",
            "isVIPTable": "#any",
            "platform": "#array",
            "maxBetRestriction": "#object",
            "position": "#any",
            "groups": "#object",
            "subGroups": "#any",
           "groupInfos": {
                "count": "#number",
                "items": "#object"
            },
            "vendor": {
                "href": "#string"
            },
            "tags": "#object",
            "categories": "#object",
            "jackpots": "#object",
            "details": "#any",
            "promo": "#object",
            "exclusive": "#object",
            "gameCode": "#string",
            "ruleUrl": "#any",
            "helpUrl":  "#string",
            "languages": "#array",
            "currencies": "#array",
            "realMode": "#object",
            "license": "#string",
             "minHitFrequency": "#number",
            "maxHitFrequency":"#number",
            "jackpotContribution": "#any",
            "evolutionGamingTableID": "#any",
            "vendorGameID": "#string",
            "restrictedTerritories": "#any",
            "lobby": "#any",
             "gameId": "#number",
            "thumbnails": "#object",
            "fpp": "#number",
            "bonusContribution": "#number",
            "icons": "#object",
            "gid": "#any"
        }
     ]
     }
     """
    And match path $.data[*].id should be != 0
    And match path $.data[*].platform should be #contains <channel>
    And match path $.data[*].href should be #contains language
    And match path $.data[*].href should be #contains everymatrix

    Examples:
      |testId       | location | channel      |
      | MID-130     |  base    |  PC          |
      | MID-130     |  base    |  iPhone      |
      | MID-130     |  base    |  iPad        |
      | MID-130     |  base    |  Android     |

  Scenario Outline: Favorite Games - Wrong channel
    And header channel = <channel>
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition  {{retryPattern}}
    Then status 500
    And match path $.msg should be #contains No favorite game found for player
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 10005

    Examples:
      |testId       | location | channel   |
      | MID-129     |  base    |  Unknown  |
      | MID-129     |  base    |  ""       |

  Scenario: Favorite Games - player id as "#any" string
    And param location = base
    And header x-player-id = ""
    And retry GET  until condition
      """
       { "status": 500 }
      """
    Then status 500
    And match path $.msg should be #contains For input string: ""
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Favorite Games - player id hack
    And param location = base
    And header x-player-id = 99999999999999999999999
    And retry GET  until condition
      """
       { "status": 500 }
      """
    Then status 500
    And match path $.msg should be #contains 99999999999999999999999
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Favorite Games - no player id
    And param location = base
    And retry GET  until condition
      """
       { "status": 500 }
      """
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Favorite Games - no location
    And header x-player-id = {{playerId}}
    And retry GET  until condition
      """
       { "status": 500 }
      """
    Then status 500
    And match path $.msg should be #contains System Error: Required request parameter 'location'

  Scenario: Favorite Games - no player id - no location
    And retry GET  until condition
      """
       { "status": 500 }
      """
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001



