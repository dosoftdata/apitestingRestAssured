@regression @personalized @leagues @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[7] leagues

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Accept = application/json
    And header Content-Type = application/json
    And header locale = en-US
    And param drilldownNodeIds = 100
    And param count = 100
    And param toOffset = 5d
    And param location = recommended_leagues
    When path /uip/sportsbook/api/v1.0/leagues

  Scenario Outline:[1] leagues
    And param recommended = true
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match each $.data[*] should match
    """
        {
            "id": "#string",
            "img": "#string",
            "name": "#string",
            "priority": "#number",
            "sportId": "#string",
            "sportName": "#string",
            "sportRefRecordId": "#string",
            "title": "#string",
            "tournamentRefRecordId": "#string",
            "type": "#string"
        }
    """
    Examples:
      |channel|
      |R      |
#      |T      |
#      |H      |
#      |I      |
#      |X      |
#      |M      |
#      |A      |

  Scenario:[2] leagues -  no player id
    And param recommended = true
    And header channel = A
    And retry GET  until condition {}
    Then status 500
    And match path $.failed should be = true
    And match path $.code should be = 1001
    And match path $.msg should be #contains Required request parameter 'playerId'
    And match path $.source should be #contains vaix-api-connector-gr
    And match path $.errorDetails.map.cause should be #contains gr.opap.gateway.api
