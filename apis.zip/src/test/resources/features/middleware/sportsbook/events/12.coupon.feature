@regression @events @ps @eventCoupon
@epic:MID-61-Middleware-Sportsbook
Feature:[17] Coupon by DrillDownTagIds and filters
  Get Sportsbook Events for Coupon by DrillDownTagIds and filters

  Background:
    Given url {{psMiddlewareHost}}
    And header Content-Type = application/json
    When path  /uip/sportsbook/api/v1.0/events/coupon
    And param excludeEventsWithNoMarkets = true
    And param excludeExpiredMarketsEvent = true
    And param excludeSettledEvents = true
    And param excludeResultedEvents = true
    And param excludeExpiredMarketsMarket = true
    And param sortsIncluded = MTCH
    And param limit = 7
    And param liveNow = false
    And param startTimeRange = ONE_DAY
    And param orderEventsBy = startTime
    And param prioritisePrimaryMarkets = true
    And param marketGroupCodesIncluded = MATCH_RESULT,TOTAL_GOALS_OVER/UNDER,BOTH_TEAMS_TO_SCORE
    And param includePrimaryMarketsOnly = false
    And param includeMarkets = true
    And param includeTeams = true
    And param includeCommentary = true
    And param includeProviders = true
    And param includeCollections = false
    And param includeRaceDetails = false
    And param location = sports_atoz
    And param count = 10
    And param toOffset = 5d
    And param channel = I
    And param locale = el-GR


  Scenario:[1] Coupon by DrillDownTagIds - active
    And param active = true
    And param drilldownTagIds = 11
   # And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
      {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": true,
            "markets": "#array"
          }
      """

    And match each $.data.events[*].markets[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": true,
            "status": "ACTIVE"
          }
      """

  Scenario:[2]  Coupon by DrillDownTagIds - no active
    And param drilldownNodeIds = 11
    And header x-player-id = {{playerId}}
    And param active = false
    And retry GET  until condition {}
    Then status 200
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": false,
            "markets": "#array"
          }
      """
    And match each $.data.events[*].markets[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": false,
            "status": "ACTIVE"
          }
      """


  Scenario:[3] Coupon by DrillDownTagIds with missed player and active status.
    And retry GET  until condition {}
    Then status 200
    And match
     """
      {
       "data": {
          "events":"#array"
        }
      }
     """
#    And match each $.data.events[*] should match
#      """
#         {
#            "id": "#string",
#            "name": "#string",
#            "active": true,
#            "markets": "#array"
#          }
#      """
#    And match each $.data.events[*].markets[*] should match
#      """
#         {
#            "id": "#string",
#            "name": "#string",
#            "active": true,
#            "status": "ACTIVE"
#          }
#      """


