@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-155 - Recommended Events
  https://opapgr.atlassian.net/browse/MID-155
  User requests to get all the recommended events, without including any related markets or additional betting information.

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header Accept = application/json
    And header locale = en-US
    When path  uip/retail-sportsbook/api/v1.0/sports/events/recommended

  Scenario Outline: MID-155-01 - Recommended event
    And param location = <location>
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
      """
      {
         "code": 1000,
         "msg": "success",
         "source": "api-gateway",
         "data": { "events": "#array" },
          "time": "#number",
          "success": true,
          "failed": false
       }
      """
    And match each $.data.events[*] should match
      """
      {
                "id": "#string",
                "name": "#string",
                "active": true,
                "displayOrder": "#number",
                "sortCode": "#string",
                "startTime": "#datetime",
                "liveNow": false,
                "resulted": false,
                "settled": false,
                "rcpAvailable": "#boolean",
                "hasBoostedMarket": "#boolean",
                "type": "#object",
                "class": "#object",
                "category": "#object",
                 "sportDrilldownTagId": "#string",
                "regionDrilldownTagId": "#string",
                "competitionDrilldownTagId": "#string",
                "displayed": true,
                "confidence": "#number"
            }
      """
     And match path $.data.events[*].started should be = false
     And match path $.data.events[*].status should be = ACTIVE
     And match path $.data.events[*].displayed should be = true
    And match each $.data.events[*].externalIds[*] should match
      """
       {
          "id": "#string",
          "provider": "#string"
       }
      """

     #* def events/recommended in response.data.events
    Examples:
    |testId           | location                      | channel |
    |  MID_155_01     |  recommended_prematchevents   |  R      |
#    |  MID-155-01     |  recommended_prematchevents   |   T     |
#    |  MID-155-01     |  recommended_prematchevents   |   H     |
#    |  MID-155-01     |  recommended_prematchevents   |   I     |
#    |  MID-155-01     |  recommended_prematchevents   |   X     |
#    |  MID-155-01     |  recommended_prematchevents   |   M     |
#    |  MID-155-01     |  recommended_prematchevents   |   A     |

  Scenario Outline: MID-155-02 - Recommended event - default channel
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
      """
      {
         "code": 1000,
         "msg": "success",
         "source": "api-gateway",
         "data": { "events": "#array" },
          "time": "#number",
          "success": true,
          "failed": false
       }
      """

    Examples:
      |testId           | location                      | channel |
      |  MID-155-02     |  recommended_prematchevents   |  R      |

  Scenario Outline: MID-155-03 - Recommended event - missed location
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           | location                      | channel |
      |  MID-155-03     |  recommended_prematchevents   |  R      |

  Scenario Outline: MID-155-04 - Recommended event - missed player
    And param location = <location>
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'

    Examples:
      |testId           | location                      | channel |
      |  MID-155-04     |  recommended_prematchevents   |  R      |