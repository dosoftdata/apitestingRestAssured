@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-170 - Recommended Betslips
  https://opapgr.atlassian.net/browse/MID-170
  user requests to get all the recommended betslips according to VAIXs metrics.

  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When path  uip/retail-sportsbook/api/v1.0/sports/betslips/recommended


  Scenario Outline: MID-170-01 - Recommended Betslips
    And param location = <location>
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    * def <testId> in response.data.allBetSlips
    Examples:
      |testId           | location                      | channel |
      |  MID_170_01     |  recommended_prematchevents   |  R      |
#    |  MID-170-01     |  recommended_prematchevents   |   T     |
#    |  MID-170-01     |  recommended_prematchevents   |   H     |
#    |  MID-170-01     |  recommended_prematchevents   |   I     |
#    |  MID-170-01     |  recommended_prematchevents   |   X     |
#    |  MID-170-01     |  recommended_prematchevents   |   M     |
#    |  MID-170-01     |  recommended_prematchevents   |   A     |

  Scenario Outline: MID-170-02 - Recommended Betslips - default channel
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    Examples:
      |testId           | location                      | channel |
      |  MID-170-02     |  recommended_prematchevents   |  R      |

  Scenario Outline: MID-170-03 - Recommended Betslips - missed location
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           | location                      | channel |
      |  MID-170-03     |  recommended_prematchevents   |  R      |

  Scenario Outline: MID-170-04 - Recommended Betslips - missed player
    And param location = <location>
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'

    Examples:
      |testId           | location                      | channel |
      |  MID-170-04     |  recommended_prematchevents   |  R      |