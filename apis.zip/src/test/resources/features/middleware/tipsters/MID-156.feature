@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-156 - Recommended Bets
  https://opapgr.atlassian.net/browse/MID-156
  user requests to get all the recommended betting selections for specific events.

  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When path uip/retail-sportsbook/api/v1.0/sports/selections/recommended

  Scenario: MID-156-01 Recommended Bets
    And header channel = I
    And param location = recommended_prematchevents
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
      """
      {
         "code": 1000,
         "msg": "success",
         "source": "api-gateway",
         "data": { "events": "#array" },
          "time": "#number",
          "success": true,
          "failed": false
       }
      """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array",
            "marketCounts": "#object",
            "confidence": "#number"
          }
      """

  Scenario Outline: MID-156-02 - Recommended Bets - default channel
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
      """
      {
         "code": 1000,
         "msg": "success",
         "source": "api-gateway",
         "data": { "events": "#array" },
          "time": "#number",
          "success": true,
          "failed": false
       }
      """

    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array",
            "marketCounts": "#object",
            "confidence": "#number"
          }
      """
    Examples:
      |testId           | location                      | channel |
      |  MID-156-02     |  recommended_prematchevents   |  R      |

  Scenario Outline: MID-156-03 - Recommended Bets- missed location
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           | location                      | channel |
      |  MID-156-03     |  recommended_prematchevents   |  R      |

  Scenario Outline: MID-156-04 - Recommended Bets - missed player
    And param location = <location>
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'

    Examples:
      |testId           | location                      | channel |
      |  MID-156-04     |  recommended_prematchevents   |  R      |