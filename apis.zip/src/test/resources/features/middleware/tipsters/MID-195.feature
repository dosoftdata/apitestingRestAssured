@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-195 - Shuffle Bets
  https://opapgr.atlassian.net/browse/MID-195
  In this scenario, the user requests to get a new selection which should replace a specific betslip selection provided earlier by MID-170: Recommended Betslips
  -Given a betslip recommended to the user, the latter should be able to request the replacement of a betslip selection with a new one.

  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When path  uip/retail-sportsbook/api/v1.0/sports/selections/similar


  Scenario Outline: MID-195-01 - Shuffle Bets
    And param location = <location>
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array",
            "marketCounts": "#object",
            "confidence": "#number",
            "betBuilders":"#array"
          }
      """
    And match each $.data.events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """

    * def <testId> in response.data.events
    Examples:
      |testId           | location                      | channel |
      |  MID_182_01     |  recommended_prematchevents   |  R      |
      |  MID-195-01     |  recommended_prematchevents   |   T     |
      |  MID-195-01     |  recommended_prematchevents   |   H     |
      |  MID-195-01     |  recommended_prematchevents   |   I     |
      |  MID-195-01     |  recommended_prematchevents   |   X     |
      |  MID-195-01     |  recommended_prematchevents   |   M     |
      |  MID-195-01     |  recommended_prematchevents   |   A     |

  Scenario Outline: MID-195-02 - Shuffle Bets - default channel
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array",
            "marketCounts": "#object",
            "confidence": "#number",
            "betBuilders":"#array"
          }
      """
    And match each $.data.events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """

    Examples:
      |testId           | location                      | channel |
      |  MID-195-02     |  recommended_prematchevents   |  R      |

  Scenario Outline: MID-195-03 - Shuffle Bets - missed location
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           | location                      | channel |
      |  MID-195-03     |  recommended_prematchevents   |  R      |

  Scenario Outline: MID-195-04 - Shuffle Bets - missed player
    And param location = <location>
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'

    Examples:
      |testId           | location                      | channel |
      |  MID-195-04     |  recommended_prematchevents   |  R      |