@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-174 - Similar Tipsters
  https://opapgr.atlassian.net/browse/MID-174
  In this scenario the user requests to get a list of tipsters which are similar to his betting activity. The user should receive a list of objects, each one containing a user id and a distance field, which indicates how similar to the user each tipster is.
  
  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When path uip/retail-sportsbook/api/v1.0/sports/selections/popular


  Scenario Outline: MID-174-01 - Shuffle Bets
    And param location = <location>
    And header channel = <channel>
   # And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "sortCode": "MTCH",
            "markets": "#array",
            "active": true,
            "startTime": "#datetime",
            "hasBoostedMarket": false,
            "status": "ACTIVE",
            "displayed": true,
            "marketCounts": "#object"
          }
      """
    Examples:
      |testId           | location                      | channel |
      |  MID_170_01     |  recommended_prematchevents   |  R      |
      |  MID-182-01     |  recommended_prematchevents   |   T     |
      |  MID-182-01     |  recommended_prematchevents   |   H     |
      |  MID-182-01     |  recommended_prematchevents   |   I     |
      |  MID-182-01     |  recommended_prematchevents   |   X     |
      |  MID-182-01     |  recommended_prematchevents   |   M     |
      |  MID-182-01     |  recommended_prematchevents   |   A     |

  Scenario Outline: MID-174-02 - Shuffle Bets - default channel
    And param location = <location>
    #And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "sortCode": "MTCH",
            "markets": "#array",
            "active": true,
            "startTime": "#datetime",
            "hasBoostedMarket": false,
            "status": "ACTIVE",
            "displayed": true,
            "marketCounts": "#object"
          }
      """
    Examples:
      |testId           | location                      | channel |
      |  MID-174-02     |  recommended_prematchevents   |  R      |

  Scenario Outline: MID-174-03 - Shuffle Bets - missed location
    And header channel = <channel>
    #And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           | location                      | channel |
      |  MID-174-03     |  recommended_prematchevents   |  R      |

  Scenario Outline: MID-174-04 - Shuffle Bets - missed player
    And param location = <location>
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 200
    And match path $.msg should be #contains Required request header 'x-player-id'

    Examples:
      |testId           | location                      | channel |
      |  MID-182-04     |  recommended_prematchevents   |  R      |