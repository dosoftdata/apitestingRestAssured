@place-bets-web
Feature: Place bets - WEB / JOKER
  Background:
    Given url {{ApiOPAP.http}}
    And header Content-Type = application/json
    And header Accept = application/json
    And header Accept-Encoding = gzip, deflate, br
    And header Host = {{ApiOPAP.host}}

  Scenario: get token
    And header X-GAME-ID = {{GAMES.JOKER}}
    And header Authorization = Basic d2lkZ2V0Omh0dHBzOi8vZGV2LWppcmEuZGV2ZWxvcG1lbnQuZGMub3BhcC9icm93c2UvREVWLTEyNzIx
    And header x-csrftoken = {{uuid}}
    And path web/access/oidc/token
    And request
      """
      {
        "grant_type": "password",
        "username": "restassured12064573",
        "password": "Qwerty12345!",
        "channel": "WEB",
        "group": "EP",
        "scope": "openid http://betware.com/oidc/scopes/session",
        "rememberMe": false,
        "verify_token": "6ZzzzAzA"
      }
      """
    When method POST
    Then status 401 or 200
    * def placeBetToken in response.access_token
    * def placeBetTokenType in response.token_type
    * Cookie placeBetCookie in response.csrftoken

  Scenario: Get Time
    And header Authorization = {{placeBetTokenType}} {{placeBetToken}}
    And header x-csrftoken = {{placeBetCookie}}
    And path web/wager-service/rest/v1/wagers/time
    When method GET
    Then status 401 or 200
    * def placeBetDateTime in response.$
    * Cookie placeBetCookie in response.csrftoken

  Scenario Outline: Place Wager/Web - JOKER
    And header Origin = {{ApiOPAP.http}}
    And header X-GAME-ID = {{GAMES.JOKER}}
    And header Authorization = {{placeBetTokenType}} {{placeBetToken}}
    And header x-csrftoken = {{placeBetCookie}}
    And path web/wager-service/rest/v1/wagers/me/place/multiple/lotteryWagers
    And request
      """
      [
       {
        "gameType": "<gameType>",
        "wager": {
            "boards": [
                {
                    "betType": <betType>,
                    "panels": [
                        {
                            "selection": [<mainSelection> ]
                        },
                        {
                            "selection": [<jokerSelection>]
                        }
                    ],
                    "boardId": <boardId>
                }
            ],
            "quickPick": <quickPick>
        }
     }
    ]
      """
    When method POST
    Then status 200
    And match path $.[0].gameType should be = <gameType>
    * def placeBetSerialNumber in response.[0].wager.serialNumbers

    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick |
      | JOKER    | 0       |   0      | 1,2,3,4,5     | 15             | false     |