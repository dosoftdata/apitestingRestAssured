function fn(name) {

  var env = java.lang.System.getProperty("env");
  if (!env) { env = "uat"
      + ""; } // default
  var RandomUtil = Java.type('apis.middleware.utilities.RandomUtil'),
      TimestampUtil = Java.type('apis.middleware.utilities.TimestampUtil');


  var config = {
    env: env,
    janusBaseUrl : "https://janusint.development.dc.opap",
    janus: {
      baseUrl: "https://janusint.development.dc.opap",
      basePath: "web/access/oidc/token",
      authorization : "Basic YmV0d2FyZTpodHRwczovL2ppcmEuYmV0d2FyZS5jb20vYnJvd3NlL0JXSU1EQ0QtMzcx",
      contentType : "application/x-www-form-urlencoded",
      grantType : "http://betware.com/oidc/grant-type/ssbt.terminal",
      scope : "http://betware.com/oidc/scopes/session"
    },
    tora: {
      baseUrl: "https://login.microsoftonline.com",
      basePath: "97c3f67d-6d05-42a8-9ec0-d8e78cd4aedc/oauth2/v2.0/token",
      client_id: "10cf3481-5d45-466b-ae4c-b08a5ab06628",
      client_secret : "ngR8Q~L1ZgI7JbtRHGs9J.UkG5Xb_l-vCfF0.cLn",
      grant_type: "client_credentials",
      scope: "api://7af097ad-2c9f-46bb-adcf-d17892f571b5/.default",
      cookie: "fpc=AkY5X8ysnoFNiOgQknuKz3Dkg2nfAQAAANxdZOAOAAAA"
    },
    middlewareHost : "https://uip-dev.development.dc.opap",
    toraMiddlewareHost : "https://uip-dev.opap.gr",
    psMiddlewareHost: "https://ciapi.pamestoixima.gr",
    ApiOPAP : {
      http: "https://apidev.opap.gr",
      host: "apidev.opap.gr"
    },
    $randomPassword : RandomUtil.generatePassword(),
    $randomAlphaNumeric:  RandomUtil.randomAlphaNumeric(20),
    timestamp: TimestampUtil.getLocalTimestamp(),
    uuid : java.util.UUID.randomUUID(),
    ssbtid: "101023HPT02",
    retailerid: 101023,
    playerId: 413451693, //191088323,
    amount: 10,
    GAMES: {
      JOKER: "JOKER",
      SPORTSBOOK: "SPORTSBOOK",
      CASINO: "CASINO",
      KINO: "KINO",
      LOTTO: "LOTTO",
      PROTO: "PROTO",
      OPAPONLINE :"OPAPONLINE"
    },
    database: {
      host: "localhost",
      ports: [5432, 5433],
      credentials: { user: "admin", pass: "secret" }
    },
    apiKeys: ["key1", "key2"],
    enabled: true
  };
  if (env === "uat") {
    config.middlewareHost = "https://uip-uat.development.dc.opap";
    config.janus.baseUrl = "https://janusuat.development.dc.opap";
    config.toraMiddlewareHost = "https://uip-uat.opap.gr";
    config.psMiddlewareHost = "https://uatapi.pamestoixima.gr";
    config.playerId = 939932925;
  } else if (env === "preprod") {
    config.middlewareHost = "http://uip-pre.development.dc.opap";
    config.janus.baseUrl = "https://januspre.development.dc.opap";
    config.toraMiddlewareHost = "http://uip-pre.opap.gr";
    config.psMiddlewareHost = "https://preapi.pamestoixima.gr";
    config.playerId = 708235797;
  }
  else if (env === "local") {
        config.janus.baseUrl = "https://janusint.development.dc.opap",
        config.middlewareHost = "http://localhost:80",
        config.toraMiddlewareHost = "https://uip-dev.opap.gr",
        config.psMiddlewareHost= config.middlewareHost,
        config.playerId = 191088323
  }

  return config;
}
