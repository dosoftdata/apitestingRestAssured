
package apis.middleware.hooks;

import apis.middleware.core.base.ApiBase;
import apis.middleware.core.helpers.WireMockFactoryOnce; // singleton factory (start once)
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.config.ConfigLoader;
import com.github.tomakehurst.wiremock.WireMockServer;
import io.cucumber.java.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Hooks {
  private static final Logger log = LoggerFactory.getLogger(Hooks.class);
  // Per-thread guard: ensure this glue class runs its before-all init once per worker (safe even if @BeforeAll is once)
  private static final ThreadLocal<Boolean> TL_INIT = ThreadLocal.withInitial(() -> false);

  @BeforeAll
  public static void beforeAll() {
    if (!TL_INIT.get()) {
      // Start the global WireMock only if not started by any thread yet
      WireMockServer server = WireMockFactoryOnce.getServer();
      WireMockFactoryOnce.retain(); // announce usage for ref-counted shutdown

      // Write-once global URL, safe with multiple threads racing at startup
      String url = server.baseUrl();
      ScenarioContext.putIfAbsentGlobal("mockServerUrl", url);

     // log.info("Global mockServerUrl = {}", ScenarioContext.getGlobal("mockServerUrl", String.class));
      TL_INIT.set(true);
    }
  }

  @Before(order = 0)
  public void resetSpecAndSetScenarios(Scenario scenario) {
    // Your existing flow
    ApiBase.spec().reset();
    ScenarioContext.sc.set(scenario);
    ConfigLoader.loadConfig();

    // (Optional) mirror the global value into per-scenario context for existing steps
    String url = ScenarioContext.getGlobal("mockServerUrl", String.class);
    if (url != null) {
      ScenarioContext.set("mockServerUrl", url);
    }
  }

  @After(order = Integer.MAX_VALUE)
  public void after(Scenario scenario) {
    if (scenario.isFailed()) {
      log.warn("Scenario failed: {}", scenario.getName());
      // attach diagnostics if needed
    }
  }

  @AfterAll
  public static void afterAll() {
    if (Boolean.TRUE.equals(TL_INIT.get())) {
      try {
        WireMockFactoryOnce.release();
      } finally {
        TL_INIT.remove();
      }
    }
  }
}
