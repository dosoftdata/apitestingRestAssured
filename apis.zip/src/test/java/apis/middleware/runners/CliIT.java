package apis.middleware.runners;

import apis.middleware.core.helpers.WireMockFactoryOnce;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.qameta.allure.testng.AllureTestNg;
import lombok.extern.slf4j.Slf4j;
import apis.middleware.dsl.ScenarioContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.*;

/**
 * The type Cli it.
 */
@Listeners({AllureTestNg.class})
@CucumberOptions(
    plugin = {
        "pretty",
        "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"
    },
    features = "classpath:features",
    glue = {
        "apis.middleware.dsl.actions",
        "apis.middleware.stepDefs",
        "apis.middleware.hooks"
    }
   //,tags = "@regression"
)
public class CliIT extends AbstractTestNGCucumberTests {
  private static final Logger log = LoggerFactory.getLogger(CliIT.class);
  @Override
  @DataProvider(parallel = false)
  public Object[][] scenarios() {
    return super.scenarios();
  }

  /**
   * Before class.
   */
  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    String tag = System.getProperty("cucumber.filter.tags", "");
    log.info("Running tests with tag: {}", !tag.isEmpty() ? tag : "No tag filter applied");
  }

  /**
   * After clas.
   */
  @AfterClass(alwaysRun = true)
  public void afterClas() {
    ScenarioContext.clear();
  }

}