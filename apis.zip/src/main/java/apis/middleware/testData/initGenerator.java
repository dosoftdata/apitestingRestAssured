package apis.middleware.testData;

import apis.middleware.core.helpers.WireMockFactoryOnce;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The type Init generator.
 */

public class initGenerator {

  /**
   * The Props.
   */
  static Properties props = new Properties();
  private static final Logger log = LoggerFactory.getLogger(initGenerator.class);

  /**
   * The entry point of application.
   *
   * @param args the input arguments
   * @throws IOException the io exception
   */
  public static void main(String[] args) throws IOException {
    Path resultsDir = Paths.get("reports");
    Files.createDirectories(resultsDir);

    ReportsEnvProps(resultsDir, props);

    try {
      log.info("Staring process testdata.");
      DynamicDataPreProcessor td = new DynamicDataPreProcessor();
      td.run();
      log.info("end process testdata.");
    }catch ( RuntimeException e){
      log.error(e.getMessage());
    }

  }

  /**
   * Reports env props.
   *
   * @param resultsDir the results dir
   * @param props      the props
   * @description Report test env properties
   */
  public static void ReportsEnvProps(Path resultsDir, Properties props) {
    props.setProperty("Environment", System.getProperty("env", "dev"));
    props.setProperty("OS", System.getProperty("os.name"));
    props.setProperty("Java Version", System.getProperty("java.version"));

    File envFile = new File(resultsDir.toFile(), "environment.properties");
    try (FileOutputStream fos = new FileOutputStream(envFile)) {
      props.store(fos, "Allure Environment Properties");
      log.info("Allure environment.properties created.");
    } catch (IOException e) { log.error(e.getMessage()); }
  }
}
