package apis.middleware.core.base;

import io.restassured.RestAssured;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import java.util.concurrent.atomic.AtomicReference;
import lombok.Getter;
import lombok.Setter;

/**
 * The type Api base.
 */
public class ApiBase{
    static {
        RestAssured.reset();
        RestAssured.requestSpecification = null;
        RestAssured.responseSpecification = null;
        RestAssured.urlEncodingEnabled = true;
        // Disable SSL verification globally for all requests
        RestAssured.useRelaxedHTTPSValidation();
        RestAssured.defaultParser = Parser.JSON;
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
    }
    private static final RequestSpecification requestSpec = ApiSpecsMap.requestSpec;

    private static final AtomicReference<CustomRequestSpec> specRef = new AtomicReference<>();

    @Getter
    @Setter
    private Response response;

    /**
     * Spec custom request spec.
     *
     * @return the custom request spec
     */
    public static CustomRequestSpec spec(){
        specRef.set(new CustomRequestSpec(requestSpec));
        return specRef.get();
    }
}
