package apis.middleware.core.base;

import apis.middleware.core.filters.AllureRequestResponseFilter;
import apis.middleware.core.filters.DedupeRequestFilter;
import apis.middleware.core.filters.RequestDelayFilter;
import apis.middleware.core.filters.RequestUrlDecodeFilter;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.*;
import io.restassured.filter.log.*;
import io.restassured.specification.RequestSpecification;
import lombok.Data;
import org.apache.http.client.CookieStore;
import org.apache.http.client.protocol.RequestAcceptEncoding;
import org.apache.http.client.protocol.ResponseContentEncoding;
import org.apache.http.impl.client.*;


/**
 * The type Api specs map.
 */
@Data
@SuppressWarnings("deprecation")
public abstract class ApiSpecsMap {
    private static final CookieStore cookieStoreGBL = new BasicCookieStore();
  /**
   * The constant requestSpec.
   */
  public static RequestSpecification requestSpec = new RequestSpecBuilder()
            .addFilter(new RequestDelayFilter(2000))
            .addFilter(new RequestUrlDecodeFilter())
            .addFilter(new DedupeRequestFilter())
            .addFilter(new AllureRequestResponseFilter())
            .addFilter(new ErrorLoggingFilter())
//            .addFilter(new RequestLoggingFilter(LogDetail.ALL))
//            .addFilter(new ResponseLoggingFilter(LogDetail.ALL))
             .build()
            .config(RestAssuredConfig.newConfig()
                    .httpClient(HttpClientConfig.httpClientConfig()
                    .httpClientFactory(() -> {
                        DefaultHttpClient httpClient = new DefaultHttpClient();
                        httpClient.addRequestInterceptor(new RequestAcceptEncoding());
                        httpClient.addResponseInterceptor(new ResponseContentEncoding());
                        httpClient.setCookieStore(cookieStoreGBL);
                        return httpClient;
                    })
                    .setParam("http.protocol.cookie-policy", "compatibility")));

  private ApiSpecsMap (){}
}
