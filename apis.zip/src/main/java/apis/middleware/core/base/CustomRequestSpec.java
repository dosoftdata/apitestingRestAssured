package apis.middleware.core.base;

import apis.middleware.core.filters.AllureRequestResponseFilter;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import io.restassured.filter.Filter;
import io.restassured.http.ContentType;
import io.restassured.config.RestAssuredConfig;
import io.restassured.specification.ProxySpecification;
import io.restassured.specification.RequestSender;
import io.restassured.specification.ResponseSpecification;

import java.io.File;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * The type Custom request spec.
 */
public class CustomRequestSpec  {

    private RequestSpecification spec;

    /**
     * Instantiates a new Custom request spec.
     *
     * @param baseSpec the base spec
     */
    public CustomRequestSpec(RequestSpecification baseSpec) {
        this.spec = RestAssured.given().spec(baseSpec).filter(new AllureRequestResponseFilter());
    }

    /**
     * Reset custom request spec.
     *
     * @return the custom request spec
     */
    public CustomRequestSpec reset() {
        this.spec = RestAssured.given();
        return this;
    }


    /**
     * Sets header.
     *
     * @param name  the name
     * @param value the value
     * @return the header
     */
    public CustomRequestSpec setHeader(String name, String value) {
         spec.header(name, value);
        return this;
    }

    /**
     * Sets headers.
     *
     * @param headers the headers
     * @return the headers
     */
    public CustomRequestSpec setHeaders(Map<String, String> headers) {
        spec.headers(headers);
        return this;
    }

    /**
     * Sets body.
     *
     * @param body the body
     * @return the body
     */
    public CustomRequestSpec setBody(Object body) {
        spec.body(body);
        return this;
    }

    /**
     * Sets query param.
     *
     * @param name  the name
     * @param value the value
     * @return the query param
     */
    public CustomRequestSpec setQueryParam(String name, Object value) {
        spec.queryParam(name, value);
        return this;
    }

    /**
     * Sets path param.
     *
     * @param name  the name
     * @param value the value
     * @return the path param
     */
    public CustomRequestSpec setPathParam(String name, Object value) {
        spec.pathParam(name, value);
        return this;
    }

    /**
     * Sets base uri.
     *
     * @param baseUri the base uri
     * @return the base uri
     */
    public CustomRequestSpec setBaseUri(String baseUri) {
        spec.baseUri(baseUri);
        return this;
    }

    /**
     * Sets base path.
     *
     * @param basePath the base path
     * @return the base path
     */
    public CustomRequestSpec setBasePath(String basePath) {
        spec.basePath(basePath);
        return this;
    }

    /**
     * Sets form param.
     *
     * @param name  the name
     * @param value the value
     * @return the form param
     */
    public CustomRequestSpec setFormParam(String name, Object value) {
        spec.formParam(name, value);
        return this;
    }

    /**
     * Add multi part file custom request spec.
     *
     * @param controlName the control name
     * @param file        the file
     * @param mimeType    the mime type
     * @return the custom request spec
     */
    public CustomRequestSpec addMultiPartFile(String controlName, File file, String mimeType) {
        this.spec.multiPart(controlName, file, mimeType);
        return this;
    }

    /**
     * Add multi part custom request spec.
     *
     * @param controlName the control name
     * @param name        the name
     * @param mimeType    the mime type
     * @return the custom request spec
     */
    public CustomRequestSpec addMultiPart(String controlName, String name, String mimeType) {
        this.spec.multiPart(controlName, name, mimeType);
        return this;
    }

    /**
     * Sets redirect follow.
     *
     * @param value the value
     * @return the redirect follow
     */
    public CustomRequestSpec setRedirectFollow(Boolean value) {
        spec.redirects().follow(value);
        return this;
    }

    /**
     * Sets redirect circular.
     *
     * @param value the value
     * @return the redirect circular
     */
    public CustomRequestSpec setRedirectCircular(Boolean value) {
        spec.redirects().allowCircular(value);
        return this;
    }

    /**
     * Sets cookie.
     *
     * @param name  the name
     * @param value the value
     * @return the cookie
     */
    public CustomRequestSpec setCookie(String name, String value) {
        spec.cookie(name, value);
        return this;
    }

    /**
     * Sets filter.
     *
     * @param filter the filter
     * @return the filter
     */
    public CustomRequestSpec setFilter(Filter filter) {
        spec.filter(filter);
        return this;
    }

    /**
     * Build request specification.
     *
     * @return the request specification
     */
    public RequestSpecification build() {
        return spec;
    }

    /**
     * Given request specification.
     *
     * @return the request specification
     */
    public RequestSpecification given() {
        return spec.given();
    }

    /**
     * Header request specification.
     *
     * @param name  the name
     * @param value the value
     * @return the request specification
     */
// Delegate all RequestSpecification methods to spec
    public RequestSpecification header(String name, Object value) { return spec.header(name, value); }

    /**
     * Headers request specification.
     *
     * @param headers the headers
     * @return the request specification
     */
    public RequestSpecification headers(Map<String, ?> headers) { return spec.headers(headers); }

    /**
     * Headers request specification.
     *
     * @param firstHeaderName      the first header name
     * @param firstHeaderValue     the first header value
     * @param headerNameValuePairs the header name value pairs
     * @return the request specification
     */
    public RequestSpecification headers(String firstHeaderName, Object firstHeaderValue, Object... headerNameValuePairs) { return spec.headers(firstHeaderName, firstHeaderValue, headerNameValuePairs); }

    /**
     * Content type request specification.
     *
     * @param contentType the content type
     * @return the request specification
     */
    public RequestSpecification contentType(ContentType contentType) { return spec.contentType(contentType); }

    /**
     * Content type request specification.
     *
     * @param contentType the content type
     * @return the request specification
     */
    public RequestSpecification contentType(String contentType) { return spec.contentType(contentType); }

    /**
     * Accept request specification.
     *
     * @param contentType the content type
     * @return the request specification
     */
    public RequestSpecification accept(ContentType contentType) { return spec.accept(contentType); }

    /**
     * Accept request specification.
     *
     * @param contentType the content type
     * @return the request specification
     */
    public RequestSpecification accept(String contentType) { return spec.accept(contentType); }

    /**
     * Body request specification.
     *
     * @param body the body
     * @return the request specification
     */
    public RequestSpecification body(String body) { return spec.body(body); }

    /**
     * Body request specification.
     *
     * @param body              the body
     * @param additionalObjects the additional objects
     * @return the request specification
     */
    public RequestSpecification body(Object body, Object... additionalObjects) { return spec.body(body); }

    /**
     * Param request specification.
     *
     * @param name  the name
     * @param value the value
     * @return the request specification
     */
    public RequestSpecification param(String name, Object value) { return spec.param(name, value); }

    /**
     * Param request specification.
     *
     * @param name   the name
     * @param values the values
     * @return the request specification
     */
    public RequestSpecification param(String name, Object... values) { return spec.param(name, values); }

    /**
     * Query param request specification.
     *
     * @param name   the name
     * @param values the values
     * @return the request specification
     */
    public RequestSpecification queryParam(String name, Object... values) { return spec.queryParam(name, values); }

    /**
     * Path param request specification.
     *
     * @param name  the name
     * @param value the value
     * @return the request specification
     */
    public RequestSpecification pathParam(String name, Object value) { return spec.pathParam(name, value); }

    /**
     * Form param request specification.
     *
     * @param name  the name
     * @param value the value
     * @return the request specification
     */
    public RequestSpecification formParam(String name, Object value) { return spec.formParam(name, value); }

    /**
     * Cookie request specification.
     *
     * @param name  the name
     * @param value the value
     * @return the request specification
     */
    public RequestSpecification cookie(String name, String value) { return spec.cookie(name, value); }

    /**
     * Cookies request specification.
     *
     * @param cookies the cookies
     * @return the request specification
     */
    public RequestSpecification cookies(Map<String, ?> cookies) { return spec.cookies(cookies); }

    /**
     * Session id request specification.
     *
     * @param sessionIdValue the session id value
     * @return the request specification
     */
    public RequestSpecification sessionId(String sessionIdValue) { return spec.sessionId(sessionIdValue); }

    /**
     * Config request specification.
     *
     * @param config the config
     * @return the request specification
     */
    public RequestSpecification config(RestAssuredConfig config) { return spec.config(config); }

    /**
     * Proxy request specification.
     *
     * @param host the host
     * @param port the port
     * @return the request specification
     */
    public RequestSpecification proxy(String host, int port) { return spec.proxy(host, port); }

    /**
     * Proxy request specification.
     *
     * @param proxySpecification the proxy specification
     * @return the request specification
     */
    public RequestSpecification proxy(ProxySpecification proxySpecification) { return spec.proxy(proxySpecification); }

    /**
     * Filters request specification.
     *
     * @param filters the filters
     * @return the request specification
     */
    public RequestSpecification filters(Collection<Filter> filters) { return spec.filters((List<Filter>) filters); }

    /**
     * Filter request specification.
     *
     * @param filter the filter
     * @return the request specification
     */
    public RequestSpecification filter(Filter filter) { return spec.filter(filter); }

    /**
     * Base uri request specification.
     *
     * @param uri the uri
     * @return the request specification
     */
    public RequestSpecification baseUri(String uri) { return spec.baseUri(uri); }

    /**
     * Base path request specification.
     *
     * @param path the path
     * @return the request specification
     */
    public RequestSpecification basePath(String path) { return spec.basePath(path); }

    /**
     * Port request specification.
     *
     * @param port the port
     * @return the request specification
     */
    public RequestSpecification port(int port) { return spec.port(port); }

    /**
     * Url encoding enabled request specification.
     *
     * @param isEnabled the is enabled
     * @return the request specification
     */
    public RequestSpecification urlEncodingEnabled(boolean isEnabled) { return spec.urlEncodingEnabled(isEnabled); }

    /**
     * Relaxed https validation request specification.
     *
     * @return the request specification
     */
    public RequestSpecification relaxedHTTPSValidation() { return spec.relaxedHTTPSValidation(); }

    /**
     * Relaxed https validation request specification.
     *
     * @param protocol the protocol
     * @return the request specification
     */
    public RequestSpecification relaxedHTTPSValidation(String protocol) { return spec.relaxedHTTPSValidation(protocol); }

    /**
     * Trust store request specification.
     *
     * @param pathToTrustStore the path to trust store
     * @param password         the password
     * @return the request specification
     */
    public RequestSpecification trustStore(String pathToTrustStore, String password) { return spec.trustStore(pathToTrustStore, password); }

    /**
     * Multipart request specification.
     *
     * @param controlName the control name
     * @param object      the object
     * @return the request specification
     */
    public RequestSpecification multipart(String controlName, Object object) { return spec.multiPart(controlName, object); }

    /**
     * When request sender.
     *
     * @return the request sender
     */
    public RequestSender when() { return spec.when(); }

    /**
     * Response response specification.
     *
     * @return the response specification
     */
    public ResponseSpecification response() { return spec.response(); }

}
