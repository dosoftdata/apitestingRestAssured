package apis.middleware.core.helpers;

/**
 * DBManager
 * Singleton manager for a single JDBC connection shared across all scenarios.
 */
import apis.middleware.core.filters.RequestDelayFilter;
import java.sql.*;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The type Db manager.
 */

public class DBManager {
  private static DBManager instance;
  private Connection connection;
  private static final Logger log = LoggerFactory.getLogger(DBManager.class);

  private DBManager() {}

  /**
   * Gets instance.
   *
   * @return the instance
   */
  public static synchronized DBManager getInstance() {
    if (instance == null) instance = new DBManager();
    return instance;
  }

  /**
   * Connect.
   *
   * @param jdbcUrl  the jdbc url
   * @param user     the user
   * @param password the password
   */
  public void connect(String jdbcUrl, String user, String password) {
    if (connection != null) return;
    try {
      connection = DriverManager.getConnection(jdbcUrl, user, password);
      log.info("[DBManager] Connected to database.");
    } catch (SQLException e) {
      log.error("DBManager Database connection failed: " + e.getMessage());
    }
  }

  /**
   * Query result set.
   *
   * @param sql the sql
   * @return the result set
   * @throws SQLException the sql exception
   */
  public ResultSet query(String sql) throws SQLException {
    if (connection == null) throw new SQLException("No DB connection");
    Statement stmt = connection.createStatement();
    return stmt.executeQuery(sql);
  }

  /**
   * Close.
   */
  public void close() {
    if (connection != null) {
      try {
        connection.close();
        log.info("DBManager Connection closed.");
      } catch (SQLException e) {
        log.error(e.getMessage());
      }
    }
  }
}
