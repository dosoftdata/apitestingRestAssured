package apis.middleware.core.helpers;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The type Wire mock factory.
 */

public class WireMockFactory {
    private static WireMockServer wireMockServer;
    private static final Logger log = LoggerFactory.getLogger(WireMockFactory.class);

    /**
     * Gets server.
     *
     * @return the server
     */
    public static WireMockServer getServer() {
        if (wireMockServer == null) {
            wireMockServer = new WireMockServer(
                WireMockConfiguration
                    .options()
                    .dynamicPort()
                    .usingFilesUnderDirectory("src/test/resources/wiremock")
                    .extensions(new com.github.tomakehurst.wiremock.extension.responsetemplating.ResponseTemplateTransformer(true))

            );
            wireMockServer.start();
            log.info("WireMock server started.");
        }
        return wireMockServer;
    }

    /**
     * Stop server.
     */
    public static void stopServer() {
        if (wireMockServer != null && wireMockServer.isRunning()) {
            wireMockServer.stop();
            log.info("WireMock server stopped.");
        }
    }

    /**
     * Gets port.
     *
     * @return the port
     */
    public static int getPort() {
        if (wireMockServer.isRunning()) {
            return wireMockServer.port();
        }
        return 0;
    }
}
