package apis.middleware.core.filters;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;

import java.util.LinkedHashMap;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The type Dedupe request filter.
 */

public class DedupeRequestFilter implements Filter {
  private static final Logger log = LoggerFactory.getLogger(DedupeRequestFilter.class);

  /**
   * The constant lastHeaders.
   */
  public static Map<String, String> lastHeaders = new LinkedHashMap<>();
  /**
   * The constant lastQueryParams.
   */
  public static Map<String, String> lastQueryParams = new LinkedHashMap<>();
  /**
   * The constant lastFormParams.
   */
  public static Map<String, String> lastFormParams = new LinkedHashMap<>();
  /**
   * The constant lastPathParams.
   */
  public static Map<String, String> lastPathParams = new LinkedHashMap<>();
  /**
   * The constant lastCookies.
   */
  public static Map<String, String> lastCookies = new LinkedHashMap<>();
  /**
   * The constant lastMultiparts.
   */
  public static Map<String, String> lastMultiparts = new LinkedHashMap<>();

  @Override
  public Response filter(FilterableRequestSpecification requestSpec,
      FilterableResponseSpecification responseSpec,
      FilterContext ctx) {

    // Deduplicate Headers
    lastHeaders.clear();
    requestSpec.getHeaders().asList().forEach(h -> lastHeaders.put(h.getName(), h.getValue()));
    requestSpec.removeHeaders();
    lastHeaders.forEach(requestSpec::header);
    // Capture Query Params
    lastQueryParams.clear();
    requestSpec.getQueryParams().forEach((k, v) -> lastQueryParams.put(k, String.valueOf(v)));
    // Capture Form Params
    lastFormParams.clear();
    requestSpec.getFormParams().forEach((k, v) -> lastFormParams.put(k, String.valueOf(v)));
    // Capture Path Params
    lastPathParams.clear();
    requestSpec.getPathParams().forEach((k, v) -> lastPathParams.put(k, String.valueOf(v)));
    // Capture Cookies
    lastCookies.clear();
    requestSpec.getCookies().asList().forEach(c -> lastCookies.put(c.getName(), c.getValue()));
    // Capture Multiparts (if any)
    lastMultiparts.clear();
    requestSpec.getMultiPartParams().forEach(mp -> lastMultiparts.put(mp.getControlName(), mp.getFileName()));

    return ctx.next(requestSpec, responseSpec);
  }
}
