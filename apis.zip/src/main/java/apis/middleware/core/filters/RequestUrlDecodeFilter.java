package apis.middleware.core.filters;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The type Request url decode filter.
 */

public class RequestUrlDecodeFilter implements Filter {
  private static final Logger log = LoggerFactory.getLogger(RequestUrlDecodeFilter.class);
  @Override
  public Response filter(FilterableRequestSpecification requestSpec,
      FilterableResponseSpecification responseSpec,
      FilterContext ctx) {

      URLDecoder.decode(requestSpec.getURI(), StandardCharsets.UTF_8);

    return ctx.next(requestSpec, responseSpec);
  }
}
