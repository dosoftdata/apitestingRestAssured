package apis.middleware.core.filters;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 * The type Log 4 j rest assured filter.
 */
public class Log4jRestAssuredFilter implements Filter {

  private static final Logger logger = LogManager.getLogger(Log4jRestAssuredFilter.class);

  @Override
  public Response filter(FilterableRequestSpecification requestSpec,
      FilterableResponseSpecification responseSpec,
      FilterContext context) {

    logger.info("Request: {}()", requestSpec.getURI());
    logger.info("Request Headers: {}", requestSpec.getHeaders());
    //logger.info(Optional.of("Request Body: {}"), requestSpec.getBody());

    Response response = context.next(requestSpec, responseSpec);

    logger.info("Response Status Code: {}", response.getStatusCode());
    logger.info("Response Headers: {}", response.getHeaders());
    logger.info("Response Body: {}", response.getBody().asPrettyString());

    return response;
  }
}
