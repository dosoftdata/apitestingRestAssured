package apis.middleware.dsl;

import apis.middleware.core.helpers.WireMockFactoryOnce;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The type Json matcher result.
 */
@Getter
public class JsonMatcherResult {
  private final boolean success;
  private final String message;
  private static final Logger log = LoggerFactory.getLogger(JsonMatcherResult.class);

  /**
   * Instantiates a new Json matcher result.
   *
   * @param success the success
   * @param message the message
   */
  public JsonMatcherResult(boolean success, String message) {
    this.success = success;
    this.message = message;
  }

  /**
   * Success json matcher result.
   *
   * @return the json matcher result
   */
  public static JsonMatcherResult success() {
    return new JsonMatcherResult(true, "Match successful");
  }

  /**
   * Fail json matcher result.
   *
   * @param msg the msg
   * @return the json matcher result
   */
  public static JsonMatcherResult fail(String msg) {
    //log.info(msg);
    return new JsonMatcherResult(false, msg);
  }

  /**
   * Pass json matcher result.
   *
   * @param msg the msg
   * @return the json matcher result
   */
  public static JsonMatcherResult pass(String msg) {
    //log.info(msg);
    return new JsonMatcherResult(true, msg);
  }

}


