package opap.middleware.core;

import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.Getter;
import lombok.Setter;

public class ApiBase{
    static {
        // Disable SSL verification globally for all requests
        io.restassured.RestAssured.useRelaxedHTTPSValidation();
        io.restassured.RestAssured.defaultParser = Parser.JSON;
    }
    @Getter
    @Setter
    private RequestSpecification requestSpec = ApiSpecsMap.requestSpec;
    @Getter
    @Setter
    private Response response;
}
