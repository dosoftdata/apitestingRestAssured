package opap.middleware.steps;

import opap.middleware.dsl.ScenarioContext;

public abstract class DslHelper {
  final ScenarioContext context;
  public DslHelper(ScenarioContext context) {
    this.context = context;
  }
}
