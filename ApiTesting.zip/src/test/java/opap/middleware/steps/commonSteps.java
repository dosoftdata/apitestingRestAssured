package opap.middleware.steps;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import lombok.SneakyThrows;
import opap.middleware.core.RequestDelayFilter;
import opap.middleware.dsl.*;

import java.io.File;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.await;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class commonSteps extends DslHelper {
    public commonSteps(ScenarioContext context) {super(context);}

    @When("^url (.+)")
    public void url(String expression) {
        this.context.getSpec().setBaseUri(ScenarioContext.resolve(expression));
    }
    @When("^delay request (\\d+)")
    public void delayRequest(int millisecond) {
        this.context.getSpec().setFilter(new RequestDelayFilter(millisecond));
    }

    @When("^path (.+)")
    public void path(String path) {
        this.context.getSpec().setBasePath(ScenarioContext.resolve(path));
    }

    @When("^param ([^\\s]+) = (.+)")
    public void param(String name, String value) {
        this.context.getSpec().setQueryParam(name, ScenarioContext.resolve(value));
    }

    @When("^cookie ([^\\s]+) = (.+)")
    public void cookie(String name, String value) {
        this.context.getSpec().setCookie(name, ScenarioContext.resolve(value));
    }

    @When("^header ([^\\s]+) = (.+)")
    public void header(String name, String value) {
        this.context.getSpec().setHeader(name, ScenarioContext.resolve(value));
    }
    @SneakyThrows
    @When("^method (GET|POST|PUT|PATCH|DELETE)(?: \"([^\"]+)\")?$")
    public void method(String method, String path) {
        if (path != null) {
            this.context.getSpec().setBasePath(ScenarioContext.resolve(path));
        }
        this.context.getApi().setResponse(
                this.context.getRes().spec(this.context.getSpec().build())
                .when().request(method));

    }

    @When("^form field ([^\\s]+) = (.+)")
    public void formField(String name, Object value) {
        this.context.getSpec().setFormParam(name, ScenarioContext.resolve((String) value));
    }

    @When("^request$")
    public void requestDocstring(String body) {
        this.context.getSpec().setBody(ScenarioContext.resolve(body));
    }

    @When("^request (.+)")
    public void request(String body) { this.context.getSpec().setBody(ScenarioContext.resolve(body));}


    @When("^def (\\w+) = (.+)$")
    public void def(String name, String expression) {
        context.setVariable(name, expression);
    }
    @When("^def (\\w+) in response.(.+)$")
    public void defResponse(String name, String expression) {
        String value = context.getApi().getResponse().jsonPath().getString(expression);
        ScenarioContext.set(name, value);
    }

    @When("^status (\\d+)")
    public void status(int status) {
       context.getApi().getResponse().then().statusCode(status);
    }
    @When("^assert (.+) = (.+)")
    public void assertEqual(String s1,String expression) {
          assertThat(s1, is(ScenarioContext.resolve(expression)));
    }
    @When("^match response (.+)(=|contains|any|only|deep)(.*)")
    public void match(String expression, String op1, String rhs) throws JsonProcessingException {
        String jsonPath = expression.trim();
        String expected = ScenarioContext.resolve(rhs).trim();
        ObjectMapper mapper = new ObjectMapper();

        Object actual = context.getApi().getResponse().path(jsonPath);
        switch (op1) {
            case "=":
                assertThat(actual.toString(), equalTo(expected));
                break;
            case "contains":
                assertThat(actual.toString(), containsString(expected));
                break;
            case "any":
                assertThat(actual.toString().split(","), hasItemInArray(expected));
                break;
            case "only":
                assertThat(actual.toString(), equalTo(expected));
                break;
            case "deep":
                JsonNode actualNode = mapper.readTree(mapper.writeValueAsString(actual));
                JsonNode expectedNode = mapper.readTree(expected);
                assertThat("JSON deep comparison failed", actualNode.equals(expectedNode), is(true));
                break;
            default:
                throw new IllegalArgumentException("Unsupported match operator: " + op1);
        }
    }

  @When("^redirect follow (\\d+)")
  public void redirectFollow(Integer b) {
    this.context.getSpec().setRedirectFollow(Boolean.valueOf(String.valueOf(b)));
  }
    @When("^redirect circular (\\d+)")
    public void redirectCircular(Integer b) {
        this.context.getSpec().setRedirectCircular(Boolean.valueOf(String.valueOf(b)));
    }
    @When("^retry (GET|POST|PUT|PATCH|DELETE)(?: \"([^\"]+)\")? until (.+) in response.(.*)$")
    public void retry(String method, String path, String until, String body) {
        if (path != null) {
            this.context.getSpec().setBasePath(ScenarioContext.resolve(path));
        }
              await()
               .atMost(60, TimeUnit.SECONDS)         // Total time to wait
                .pollInterval(5, TimeUnit.SECONDS)    // Custom poll interval
                .pollDelay(2, TimeUnit.SECONDS)       // Optional initial delay
                .until(() -> {
                    this.context.getApi().setResponse(
                            this.context.getRes().spec(this.context.getSpec().build())
                                    .when().request(method));
                    return this.context.getApi().getResponse().path(body).toString().equalsIgnoreCase(until);
                });

    }

  @When("^multipart file (.+) path (.+) mimeType (.+)")
  public void multipartFile(String file, File filePath, String mimeType) {
        this.context.getSpec().addMultiPartFile(file, filePath, mimeType);
  }
    @When("^multipart (.+), (.+), (.+)$")
    public void multipart(String file, String filePath, String mimeType) {
        this.context.getSpec().addMultiPart(file, filePath, mimeType);
    }

}
