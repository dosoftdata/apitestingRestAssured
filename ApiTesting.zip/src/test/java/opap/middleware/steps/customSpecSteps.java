package opap.middleware.steps;

import io.cucumber.java.en.And;
import opap.middleware.dsl.ScenarioContext;
import org.json.JSONArray;
import org.json.JSONObject;


public class customSpecSteps extends DslHelper {
    public customSpecSteps(ScenarioContext context) {
        super(context);
    }
    @And("^set CreatDigitalPayBody with (.+), (.+), (.+), (.*) values$")
    public void setCreatDigitalPayRequestBody(
            String _uuid, String ssbtid, String retailerid, int _amount
    ) {
        String uuid = ScenarioContext.resolve(_uuid);
        String terminalCode = ScenarioContext.resolve(ssbtid);
        String shopId = ScenarioContext.resolve(retailerid);

        JSONObject json = new JSONObject();
        json.put("uuid", uuid);

        JSONObject paymentDetails = new JSONObject();
        paymentDetails.put("totalAmount", _amount);

        JSONObject channelDetails = new JSONObject();
        channelDetails.put("terminalId", terminalCode);
        channelDetails.put("retailerId", shopId);
        paymentDetails.put("channelDetails", channelDetails);

        JSONArray payments = new JSONArray();
        JSONObject payment = new JSONObject();
        payment.put("amount", _amount);
        payment.put("merchant", "TORA");
        payment.put("count", 1);
        payments.put(payment);
        paymentDetails.put("payments", payments);

        paymentDetails.put("expiration", 0);
        paymentDetails.put("paymentProviderReferenceId", JSONObject.NULL);
        paymentDetails.put("paymentMethodType", "CARD");
        json.put("paymentDetails", paymentDetails);
        json.put("paymentType", "PURCHASE");
        json.put("channel", "SSBT");
        json.put("userId", "Test");
        json.put("type", "PURCHASE");
        this.context.getSpec().setBody(json.toString());
    }


}
