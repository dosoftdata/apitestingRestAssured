package opap.middleware.runners;

import com.github.tomakehurst.wiremock.WireMockServer;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import lombok.extern.slf4j.Slf4j;
import opap.middleware.core.WireMockFactory;
import opap.middleware.dsl.ScenarioContext;
import org.testng.annotations.*;

@Slf4j
@CucumberOptions(
    plugin = {
        "pretty",
        "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"
    },
    features = "classpath:features",
    glue = {
        "opap.middleware.steps",
        "opap.middleware.hooks"
    },
    tags = "@regression"
)
public class TestRunner extends AbstractTestNGCucumberTests {
  private static WireMockServer wireMockServer;
  @Override
  @DataProvider(parallel = false)
  public Object[][] scenarios() {
    return super.scenarios();
  }

  @BeforeSuite(alwaysRun = true)
  public void beforeSuite() {
    wireMockServer = WireMockFactory.getServer();
    ScenarioContext.set("mockServer", wireMockServer);
    ScenarioContext.set("mockServerUrl", wireMockServer.baseUrl());
    log.info("WireMock server started: {}", ScenarioContext.get("mockServerUrl"));
  }

  @BeforeClass(alwaysRun = true)
  public void logTagFilter() {
    String tag = System.getProperty("cucumber.filter.tags", "");
    log.info("Running tests with tag: {}", tag != null ? tag : "No tag filter applied");
  }

  @AfterSuite(alwaysRun = true)
  public void afterAll() {
    WireMockFactory.stopServer();
    ScenarioContext.clear();
    log.info("WireMock server stopped.");
  }
}