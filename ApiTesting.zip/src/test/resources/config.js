function fn(name) {

  var env = java.lang.System.getProperty("env");
  if (!env) {
    env = "uat"; // default
  }

  var config = {
    env: env,
    baseUrl: "https://fakerestapi.azurewebsites.net",
    janusBaseUrl : "https://janusint.development.dc.opap",
    middlewareHost : "https://uip-dev.development.dc.opap",
    adminUser: { username: "admin", password: "secret" },
    normalUser: { username: "user", password: "password" },
    uuid : java.util.UUID.randomUUID(),
    ssbtid: "101023HPT02",
    retailerid: 101023
  };
  if (env === "uat") {
    config.middlewareHost = "https://uip-uat.development.dc.opap";
    config.janusBaseUrl = "https://janusuat.development.dc.opap";
  } else if (env === "preprod") {
    config.baseUrl = "https://fakerestapi.azurewebsites.net";
    config.janusBaseUrl = "";
  }



  return config;
}
