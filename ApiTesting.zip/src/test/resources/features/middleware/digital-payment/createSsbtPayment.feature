@regression @digitalPaymentSSBT

Feature: Digital Payment - SSBT

   Scenario: Janus Token
     Given url <janusBaseUrl>
     And header Authorization = Basic YmV0d2FyZTpodHRwczovL2ppcmEuYmV0d2FyZS5jb20vYnJvd3NlL0JXSU1EQ0QtMzcx
     And header Content-Type = application/x-www-form-urlencoded
     And form field grant_type = http://betware.com/oidc/grant-type/ssbt.terminal
     And form field scope = http://betware.com/oidc/scopes/session
     And form field ssbtId = <ssbtid>
     When path /web/access/oidc/token
     And method POST
     Then status 200
     * def janusToken in response.access_token
     * def janusTokenType in response.token_type

  Scenario: Create digital payment
      Given url <middlewareHost>
      And header Content-Type = application/json
      And header Authorization = <janusTokenType> <janusToken>
      And header GUID = <uuid>
      When path /ssbt/api/v1.0/digital-payment
      And set CreatDigitalPayBody with <uuid>, <ssbtid>, <retailerid>, 80 values
      And method POST
      Then status 200
      * def transactionId in response.data.transactionId
      * def uuid in response.data.uuid

  Scenario Outline: Check digital payment Status WAIT_FROM_TORA
    Given url <middlewareHost>
    And header Content-Type = application/json
    And path /ssbt/api/v1.0/digital-payment/<transactionId>
    And delay request 100
    When method GET 
    Then status 200
    And match response data.status = <status>
    And match response code = 1000
    And match response msg = success
    Examples:
      | status          |
      | WAIT_FROM_TORA  |
      | WAIT_FROM_TORA  |
      | WAIT_FROM_TORA  |