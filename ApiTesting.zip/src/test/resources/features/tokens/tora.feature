Feature: Token token
  curl --location 'https://login.microsoftonline.com/97c3f67d-6d05-42a8-9ec0-d8e78cd4aedc/oauth2/v2.0/token' \
  --header 'Content-Type: application/x-www-form-urlencoded' \
  --header 'Cookie: fpc=AkY5X8ysnoFNiOgQknuKz3Dkg2nfAQAAANxdZOAOAAAA' \
  --data-urlencode 'grant_type=client_credentials' \
  --data-urlencode 'client_id=10cf3481-5d45-466b-ae4c-b08a5ab06628' \
  --data-urlencode 'client_secret=ngR8Q~L1ZgI7JbtRHGs9J.UkG5Xb_l-vCfF0.cLn' \
  --data-urlencode 'scope=api://7af097ad-2c9f-46bb-adcf-d17892f571b5/.default'

  Scenario: Request Toral token
    Given url <janusBaseUrl>
    And header Authorization = Basic YmV0d2FyZTpodHRwczovL2ppcmEuYmV0d2FyZS5jb20vYnJvd3NlL0JXSU1EQ0QtMzcx
    And header Content-Type = application/x-www-form-urlencoded
    And form field grant_type = http://betware.com/oidc/grant-type/ssbt.terminal
    And form field scope = http://betware.com/oidc/scopes/session
    And form field ssbtId = <ssbtid>
    When path /web/access/oidc/token
    And method POST
    Then status 200
    * def janusToken in response.access_token
    * def janusTokenType in response.token_type
