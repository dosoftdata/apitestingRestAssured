package apiResources.endpoints;

public enum LimitServiceResources {
  PlayerLimits(
      "/web/limit/rest/v1/customers/"
          + "{{playerId}}"
          + "/limits"), // this endpoint can be used with both GET and POST

  PlayerLimitsCC("/cc/limit/rest/v1/users/1-{{playerId}}/limits"),
  PlayerLimitsCCv2("/cc/limit/rest/v2/users/1-{{playerId}}/limits"),

  // region GET Methods

  // endregion

  // region POST Methods
  PlayerLimitsV2("/web/limit/rest/v2/customers/" + "{{playerId}}" + "/limits"),
  ApproveLimits(
      "/web/limit/rest/v1/customers/{{playerId}}/limits/approve"), // currently for negative
  // scenarios. Check if valid
  // endpoint

  ApproveLimitsCC("/cc/limit/rest/v1/users/{{playerId}}/limits"),
  RejectLimits("/web/limit/rest/v1/customers/{{playerId}}/limits/reject"),
  RejectLimitsCC("/cc/limit/rest/v1/users/{{playerId}}/limits/reject");

  // endregion

  // region PUT Methods

  // endregion

  // region DEL Methods

  // endregion
  private String resource;

  LimitServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
