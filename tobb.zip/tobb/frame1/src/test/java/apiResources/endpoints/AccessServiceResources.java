package apiResources.endpoints;

public enum AccessServiceResources {

  // region Hybrid methods
  CustomerAccessAttributes(
      "/cc/access/rest/v1/customers/{{playerId}}/access-attributes/{{operationalUnit}}"), // GET,DEL
  AllowAdminAccessAttributes(
      "/cc/access/rest/v2/admins/{{adminId}}/access-attributes/direct/allow"), // GET,PUT
  AllowRoleAccessAttributes(
      "/cc/access/rest/v2/roles/admin/{{roleId}}/access-attributes/direct/allow"), // GET,PUT
  RolesAdminCC("/cc/access/rest/v2/roles/admin"), // GET,POST
  RolesAdminRoleIdCC("/cc/access/rest/v2/roles/admin/{{roleId}}"), // GET,DEL,PUT
  ApiAccessAttributes("/api/access/rest/v1/accessattributes"), // GET,DEL,POST
  ApiAssertions("/api/access/rest/v1/assertions/{{assertionId}}"), // GET,DEL,PUT
  AccessGroups("/api/access/rest/v1/accessgroups"), // GET,POST
  AccessGroupMembers("/api/access/rest/v1/accessgroups/{{accessgroupId}}/members"),
  AccessGroupMemberId(
      "/api/access/rest/v1/accessgroups/{{accessgroupId}}/members/{{accessgroupMemberId}}"), // DEl,GET
  SessionId("/api/access/rest/v1/sessions/{{sessionId}}"),
  Sessions("/api/access/rest/v1/sessions"),
  SessionsInvalidRetailerLength("api/access/rest/v1/sessions?logoutMethod=SESSION_TIMEOUT&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test&retailerId=test"),
  EnabledFeatureFlags("/cc/access/rest/v1/feature"),
  EnabledFeatureFlagsAll("/cc/access/rest/v1/feature/all"),

  // endregion

  // region GET Methods
  GetUserInfo("/web/access/oidc/userinfo"),
  GetAccessGroupId("/api/access/rest/v1/accessgroups/{{accessgroupId}}"),
  GetRoleMembers("/api/access/rest/v1/accessgroups/members?memberId=1-{{playerId}}"),
  CheckSession("/web/access/session/check"),
  GetAdminAccessAttributes("/cc/access/rest/v1/admins/{{adminId}}/access-attributes"),
  GetCurrentAccess("/api/access/rest/v1/accessattributes/current"),
  GetCurrentAccessV2("/api/access/rest/v2/accessattributes/current"),
  GetModules("/cc/access/rest/v1/modules"),
  GetSessionMinutesCC("/cc/access/rest/v1/sessionminutes/{{userGroup}}-{{playerId}}"),
  GetSessionMinutesWeb("/web/access/rest/v1/customers/{{playerId}}/sessionminutes"),
  GetSessionWeb("/web/access/rest/v1/time/session"),
  GetAdminRolesCC("/cc/access/rest/v2/admins/{{adminId}}/roles"),
  GetApiAccessAttributes("/api/access/rest/v1/accessattributes/{{accessattributes}}"),
  GetAccessAttributesAudit("/api/access/rest/v1/users/{{playerId}}/accessattributes/audit"),
  GetAccessGroupMembers("/api/access/rest/v1/accessgroups/members"),
  GetLoginTimes("/api/access/rest/v1/logintimes/{{playerId}}/{{loginTime}}"),
  GetPreviousLoginTimes("/api/access/rest/v1/logintimes/1-{{playerId}}/previous"),
  GetLastLoginTimes("/api/access/rest/v1/logintimes/1-{{playerId}}/last"),
  GetUserSessions("/cc/access/rest/v2/sessions/1-{{playerId}}/online"),
  GetAccessAttributesV2("/api/access/rest/v2/accessattributes/{{accessattributes}}"),
  GetMemberIdsV2("/api/access/rest/v2/roles/admin/{{roleId}}/member-ids"),
  CheckIfFeatureIsReady("/web/access/rest/v1/feature/check"),
  GetCustomerAccessRights(
      "cc/access/rest/v1/customers/{{playerId}}/access-attributes/admin.admins|admin-details|manage"),
  GetCustomerAccessRightsView(
      "cc/access/rest/v1/customers/{{playerId}}/access-attributes/admin.players|manage-access|view"),
  GetUserActiveSessionV1("/cc/access/rest/v1/sessions/{{playerId}}/online"),
  GetCustomerAccessRightsApi("/api/access/rest/v1/customers/{{playerId}}/access-attributes"),
  GetAccessAttributesChangeHistory("/api/access/rest/v1/users/{{userId}}/accessattributes/audit"),
  UpdatePendingPasswordWeb("/web/access/rest/v1/sessions/pending/password"),

  // endregion

  // region POST Methods
  LoginNew("/web/access/oidc/token"),
  LoginOld("/web/access/rest/v2/sessions"),
  LogOut("/web/access/rest/v1/sessions/current"),
  LoginBackOffice("/cc/access/rest/v1/sessions"),
  LoginApi("/api/access/oidc/token"),
  AddUserToEpGroup("/api/access/rest/v1/accessgroups/{{exclusiveGamesGroupId}}/members"),
  AddUserToNepGroup("/api/access/rest/v1/accessgroups/{{exclusiveGamesGroupId}}/members"),
  PostCustomerAccessAttributes("/cc/access/rest/v1/customers/{{playerId}}/access-attributes"),
  AcceptContractAgreements("/web/access/rest/v1/sessions/pending/contract-agreements"),
  SessionAccess("/api/access/rest/v1/sessions/{{sessionId}}/access"),
  AccessCheckV2("/api/access/rest/v2/access/check"),
  Introspect("/api/access/oidc/introspect"),

  // region Login External
  LoginExternalRandomProviderStart("/web/access/rest/v1/sessions/external/randomProvider/start"),
  LoginExternalTestProviderStart("/web/access/rest/v1/sessions/external/testProvider/start"),
  LoginExternalRandomProviderFinish("/web/access/rest/v1/sessions/external/randomProvider/finish"),
  LoginExternalTestProviderFinish("/web/access/rest/v1/sessions/external/testProvider/finish"),
  LoginExternalRandomProviderPending(
      "/web/access/rest/v1/sessions/external/randomProvider/pending/ssn"),
  LoginExternalTestProviderPending(
      "/web/access/rest/v1/sessions/external/testProvider/pending/ssn"),
  // endregion

  // endregion

  // region PUT Methods
  AdminRolesV2("/api/access/rest/v2/admins/{{adminId}}/roles"),
  AccessRoleIdV2("/api/access/rest/v2/roles/player/{{roleId}}"),
  ApiTestAssertion("api/access/rest/v1/assertions/testAssertion?assertionId=testAssertionId"),
  ApiSessionId(
      "/api/access/rest/v1/assertions/testAssertion?assertionId=testAssertionId&sessionId=testSessionId"),
  AccessGroupsV2("/api/access/rest/v2/accessgroups/members"),
  UpdatePassword("/cc/access/rest/v1/sessions/pending/password"),
  // endregion

  // region DEL Methods
  DeleteCurrentSession("/cc/access/rest/v1/sessions/current"),
  DeleteCurrentSessionToken("/web/access/rest/v1/sessions/current/token"),
  DeleteMembersV2("/api/access/rest/v2/roles/player/{{roleId}}/members"),
  ForceLogoutSessionsV1CC("/cc/access/rest/v1/sessions/1-{{playerId}}"),
  ForceLogoutSessionsV1CCWithDifferentPlayerId("/cc/access/rest/v1/sessions/{{playerId}}"),
  ForceLogoutSessionsV2CC("/cc/access/rest/v2/sessions/1-{{playerId}}");

  // endregion
  private String resource;

  AccessServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
