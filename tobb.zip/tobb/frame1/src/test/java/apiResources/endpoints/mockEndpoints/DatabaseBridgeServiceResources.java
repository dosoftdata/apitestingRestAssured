package apiResources.endpoints.mockEndpoints;

public enum DatabaseBridgeServiceResources {

  // region GET Methods
  // endregion

  // region POST Methods
  DatabaseExecute("/database/execute");
  // endregion

  // region PUT Methods

  // endregion

  // region DEL Methods

  // endregion
  private String resource;

  DatabaseBridgeServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
