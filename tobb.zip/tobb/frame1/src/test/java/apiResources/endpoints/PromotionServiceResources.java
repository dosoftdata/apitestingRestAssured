package apiResources.endpoints;

public enum PromotionServiceResources {

  // region GET Methods
  GetUniversalPromotions("/web/promotion/rest/v1/promotions"),
  GetPlayersPromotions("/web/promotion/rest/v1/promotions/player/{{playerId}}"),
  GetActivePlayersPromotions("/web/promotion/rest/v1/promotions/player/{{playerId}}"),
  GetEligiblePromotions("/web/promotion/rest/v1/promotions/player/{{playerId}}/eligible"),
  GetPromoEligibility("/web/promotion/rest/v1/promotions/player/{{playerId}}/promo-eligibility"),
  GetPlayerPromotionsCC("/cc/promotion/rest/v1/promotions/player/{{playerId}}"),
  GetPromotionsHistoryCC("/cc/promotion/rest/v1/promotions/{{playerId}}/history"),
  // endregion

  // region POST Methods
  CheckBetEligibility("/web/promotion/rest/v1/promotions/player/{{playerId}}/bet-eligibility");
  // endregion

  // region PUT Methods

  // endregion

  // region DEL Methods

  // endregion
  private String resource;

  PromotionServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
