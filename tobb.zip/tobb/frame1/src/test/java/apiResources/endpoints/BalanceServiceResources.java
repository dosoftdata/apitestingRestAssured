package apiResources.endpoints;

public enum BalanceServiceResources {

  // region GET Methods
  GetBalanceV1("/web/balance/rest/v1/users/{{playerId}}/balances"),
  GetBalanceV2("/web/balance/rest/v2/users/{{playerId}}/balances");

  // endregion

  // region POST Methods

  // endregion

  // region PUT Methods

  // endregion

  // region DEL Methods

  // endregion
  private String resource;

  BalanceServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
