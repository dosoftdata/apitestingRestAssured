package apiResources.endpoints;

public enum WalletServiceResources {

  // region GET Methods
  GetAPIWalletBalance("/api/wallet/rest/v2/users/1-{{playerId}}/accounts"),
  GetWalletBalance("/cc/wallet/rest/v2/users/1-{{playerId}}/accounts"),
  GetWalletBalanceWithId("/cc/wallet/rest/v2/users/1-{{playerId}}/accounts/{{accountId}}"),
  GetWalletBalanceWeb("/web/wallet/rest/v2/customers/{{playerId}}/accounts/{{accountId}}/balance"),
  GetWalletBalanceCC("/cc/wallet/rest/v2/users/1-{{playerId}}/accounts/{{accountId}}/balance"),
  GetWalletBonusBalance("/cc/wallet/rest/v2/users/1-{{playerId}}/accounts/AT_BONUS_PRIZE/balance"),
  GetWalletBalanceWithAccountType(
      "/cc/wallet/rest/v2/users/1-{{playerId}}/accounts/{{accountType}}/balance"),

  GetPaymentCodes("/cc/wallet/rest/v2/customers/{{playerId}}/payment-methods"),
  GetPaymentCodesOld("/cc/wallet/rest/v1/customers/{{playerId}}/payment-methods"),
  GetPaymentCodesWeb("/web/wallet/rest/v2/customers/{{playerId}}/payment-methods"),
  GetPlayerAccountsWebV1("/web/wallet/rest/v1/customers/{{playerId}}/accounts"),
  GetPlayerAccountsWeb("/web/wallet/rest/v2/customers/{{playerId}}/accounts"),
  GetPlayerAccountsWebV3("/web/wallet/rest/v3/customers/{{playerId}}/accounts"),
  GetPlayerAccountsWebV4("/web/wallet/rest/v4/customers/{{playerId}}/accounts"),
  GetPlayerAccountsWebWithId("/web/wallet/rest/v2/customers/{{playerId}}/accounts/{{accountId}}"),
  GetPlayerWalletV1("/api/wallet/rest/v1/users/1-{{playerId}}/accounts/{{accountId}}"),
  GetPlayerLegacyWallet("/web/wallet/rest/v2/customers/{{playerId}}/accounts/AT_MAIN-0"),
  GetUserLegacyWalletV1("/api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-0"),
  GetPlayerLotteryWalletV1("/api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-1"),
  GetPlayerBettingWalletV1("/api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-2"),
  GetPlayerLotteryWallet("/web/wallet/rest/v2/customers/{{playerId}}/accounts/AT_MAIN-1"),
  GetPlayerBettingWallet("/web/wallet/rest/v2/customers/{{playerId}}/accounts/AT_MAIN-2"),
  GetPlayerPaymentsAsAdmin("cc/wallet/rest/v1/payments"),
  GetPlayerPaymentsAsAdminV2("cc/wallet/rest/v2/payments"),
  GetPlayerTransactionsAsAdmin1(
      "cc/wallet/rest/v1-opap/users/1-{{playerId}}/accounts/AT_MAIN-1/transactions"),
  GetGrandPrizePayments("/cc/wallet/rest/v1/payments/manuallyHandled"),
  GetPlayerTransactionsAsAdmin2(
      "/cc/wallet/rest/v1-opap/users/1-{{playerId}}/accounts/AT_MAIN-2/transactions"),
  GetManualAdjustments(
      "/cc/wallet/rest/v2/users/1-{{playerId}}/manual-adjustments/AT_MAIN-2/productIds"),
  GetBOPayments("/cc/wallet/rest/v1/payments/transfer-out"),
  GetAllUsersPayments("/cc/wallet/rest/v1/payments"),
  GetAccountV1("api/wallet/rest/v1/users/1-{{playerId}}/accounts"),
  GetAccountV2("api/wallet/rest/v2/users/1-{{playerId}}/accounts"),
  GetAccountV1CC("/cc/wallet/rest/v1/users/1-{{playerId}}/accounts"),
  GetAccountV1CCWithId("/cc/wallet/rest/v1/users/1-{{playerId}}/accounts/{{accountId}}"),
  GetAccountHistoryCC(
      "/cc/wallet/rest/v1/users/1-{{playerId}}/accounts/{{accountId}}/history/{{daysBack}}"),
  GetAccountV2CC("cc/wallet/rest/v2/users/1-{{playerId}}/accounts"),
  GetQuickDeposit("web/wallet/rest/v2/customers/{{playerId}}/accounts/quick-deposit"),
  GetLegacyTransactionWithId(
      "/api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-0/transactions/{{transactionId}}"),

  GetAudit("/api/wallet/rest/v1/users/audit"),
  GetPlayerAudit("/api/wallet/rest/v1/users/{{playerId}}/audit"),
  GetAccountInformation("/api/wallet/rest/v3/users/1-{{playerId}}/accounts"),
  ValidateIban("/api/wallet/rest/v1/iban/validate"),

  GetPlayerTransactionsV1(
      "/web/wallet/rest/v1/customers/{{playerId}}/accounts/{{accountId}}/transactions"),
  GetPlayerTransactionsCC(
      "/cc/wallet/rest/v1/users/1-{{playerId}}/accounts/{{accountId}}/transactions"),
  GetPlayerTransactionTypesCC(
      "/cc/wallet/rest/v1/users/1-{{playerId}}/accounts/{{accountId}}/transactions/transaction-types"),
  GetPlayerTransactionsV1OPAP(
      "/web/wallet/rest/v1-opap/customers/{{playerId}}/accounts/{{accountId}}/transactions"),
  GetPlayerTransactionTypesV1(
      "/web/wallet/rest/v1/customers/1-{{playerId}}/accounts/{{accountId}}/transactions/transaction-types"),
  GetPlayerTransactionTypesV1OPAP(
      "/web/wallet/rest/v1-opap/customers/{{playerId}}/accounts/{{accountId}}/transactions/transaction-types"),
  GetSsbtAccounts("/web/wallet/rest/v2-opap/customers/ssbt/accounts"),
  GetPaymentMethodsPayments(
      "/cc/wallet/rest/v1/customers/1-{{playerId}}/payment-methods/{{paymentMethodId}}/payments"),
  GetRejectedOutPayments("/cc/wallet/rest/v1/payments/rejected-out"),
  GetTransferInPayments("/cc/wallet/rest/v1/payments/transfer-in"),
  GetTransferOutPayments("/cc/wallet/rest/v1/payments/transfer-out"),
  GetServiceProviders("/cc/wallet/rest/v1/serviceproviders"),
  GetPayouts("/cc/wallet/rest/v1/payouts"),
  GetDepositAccessOperations("/api/wallet/rest/v1/users/1-{{playerId}}/accessoperations/DEPOSIT"),
  GetWithdrawAccessOperations("/api/wallet/rest/v1/users/1-{{playerId}}/accessoperations/WITHDRAW"),
  GetBuyAccessOperations("/api/wallet/rest/v1/users/1-{{playerId}}/accessoperations/BUY"),
  GetPayoutAccessOperations("/api/wallet/rest/v1/users/1-{{playerId}}/accessoperations/PAYOUT"),
  GetAccessOperations("/api/wallet/rest/v1/users/1-{{playerId}}/accessoperations"),
  GetAccessOperationsWithId(
      "/api/wallet/rest/v1/users/1-{{playerId}}/accessoperations/{{accessoperationsId}}"),
  GetAccountProductsV4("/api/wallet/rest/v4/accounts/products"),
  GetPlayersAccountCCV1("/cc/wallet/rest/v1/users/1-{{playerId}}/accounts"),
  GetPlayersMainAccounts("/api/wallet/rest/v4/accounts/main"),
  GetAccountsGroup("/api/wallet/rest/v4/accounts/{{accountId}}/group"),
  GetLastTransaction("/cc/wallet/rest/v1/payments/{{deposit_paymentId}}"),
  // endregion

  // region Hybrid Methods
  AccessOperationsV1("/cc/wallet/rest/v1/users/1-{{playerId}}/accessoperations"),
  AccessOperationsV2("/cc/wallet/rest/v2/users/1-{{playerId}}/accessoperations"),
  LegacyTransaction("/api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-0/transactions"),
  PaymentMethodV1("/api/wallet/rest/v1/customers/{{playerId}}/payment-methods"),
  PaymentMethodWithId(
      "/api/wallet/rest/v1/customers/{{playerId}}/payment-methods/{{paymentMethodId}}"),
  PaymentMethodWithIdCC(
      "/cc/wallet/rest/v1/customers/{{playerId}}/payment-methods/{{paymentMethodId}}"),
  PlayerAccountsV1("/web/wallet/rest/v1/customers/{{playerId}}/accounts/{{accountId}}"),
  PaymentWithId("cc/wallet/rest/v1/payments/{{paymentId}}"),

  // endregion

  // region POST Methods
  PostPaymentViaPaymentCode("/api/wallet/rest/v1/payments"),
  PostPaymentViaCard("/web/tora/rest/v1/customers/{{playerId}}/payments"),
  PostMastercardDetailsToSandbox("/api/threedsecure"),
  PostWalletFunds("/api/wallet/rest/v2/users/1-{{playerId}}/funds"),
  ManualAdjustLotteryWallet(
      "/cc/wallet/rest/v2-opap/users/1-{{playerId}}/accounts/AT_MAIN-1/adjust"),

  ManualAdjustBettingWalletv2(
      "/cc/wallet/rest/v2-opap/users/1-{{playerId}}/accounts/AT_MAIN-2/adjust"),
  ManualAdjustBettingWallet(
      "/cc/wallet/rest/v3-opap/users/1-{{playerId}}/accounts/AT_MAIN-2/adjust"),
  ManuallyAdjustLegacyWallet(
      "/cc/wallet/rest/v2-opap/users/1-{{playerId}}/accounts/AT_MAIN-0/adjust"),

  ManuallyAdjustWallet(
      "/cc/wallet/rest/v2-opap/users/1-{{playerId}}/accounts/{{accountId}}/adjust"),

  CreateTransaction("/api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-1/transactions"),
  CreateBettingTransaction(
      "/api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-2/transactions"),
  CaptureLegacyTransaction(
      "/api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-0/transactions/capture"),
  CaptureLegacyTransactionWithId(
      "/api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-0/transactions/{{accountId}}/capture"),
  RejectLegacyTransaction(
      "/api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-0/transactions/reject"),
  VerifyPaymentViaToraWebhooks("/api/tora/rest/v1/events"),
  ValidWithdrawalViaCardOrIBAN("/api/wallet/rest/v1/payments"),
  ApprovePayment("/cc/wallet/rest/v1/payments/{{paymentId}}/approve"),
  VerifyPayment("/cc/wallet/rest/v1/payments/{{paymentId}}/verify"),
  RejectPayment("/cc/wallet/rest/v1/payments/{{paymentId}}/reject"),
  CancelPayment("/cc/wallet/rest/v1/payments/{{paymentId}}/cancel"),
  CancelRefund("/web/wallet/rest/v1/customers/{{playerId}}/payments/{{paymentId}}/cancel-refund"),
  PaymentsVoucher("/web/wallet/rest/v1-opap/payments/voucher/{{voucherId}}"),
  CashoutVoucher("/web/wallet/rest/v1-opap/payments/cashout/voucher"),
  PaymentsRollover("/web/wallet/rest/v2-opap/payments/rollover/{{wagerId}}"),
  RetryOutPayment("/cc/wallet/rest/v1/payments/{{paymentId}}/retryout"),
  RecordPayments("/cc/wallet/rest/v1/payments/record"),
  RejectDepositViaTora("api/tora/rest/v1/withdrawal/rejection"),

  // endregion

  // region PUT Methods
  VerifyDepositToTora("/api/wallet/rest/v1/payments/{{deposit_paymentId}}/verified"),
  CommitCardDepositToTora("/web/tora/rest/v1/payments/{{deposit_paymentId}}/token"),
  CommitCardWithdrawalToTora("/api/wallet/rest/v1/payments/{{withdrawal_paymentId}}"),
  ApproveWithdrawal("/api/wallet/rest/v1/payments/{{withdrawal_paymentId}}"),
  VerifyWithdrawalWithIBAN("/api/wallet/rest/v1/payments/{{withdrawal_paymentId}}/verified"),

  CloseLegacyAccountV1("/api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-0/close"), //
  CloseAccountV2(
      "/api/wallet/rest/v2/users/{{playerId}}/accounts/close"), // deprecated just negative
  // Scenarios
  CloseAccountV4("/api/wallet/rest/v4/users/{{userType}}-{{playerId}}/accounts/close"),
  ApproveWithdrawalCC("/cc/wallet/rest/v1/payments/{{withdrawal_paymentId}}"),
  BlockLegacyWallet("api/wallet/rest/v1/users/1-{{playerId}}/accounts/AT_MAIN-0/block"),
  PaymentMethodWithIdWeb(
      "/web/wallet/rest/v1/customers/{{playerId}}/payment-methods/{{paymentMethodId}}"),
  PaymentMethodWithIdWebV2(
      "/web/wallet/rest/v2/customers/{{playerId}}/payment-methods/{{paymentMethodId}}"),
  CancelTransaction(
      "/api/wallet/rest/v1/users/1-{{playerId}}/accounts/{{accountId}}/transactions/{{transactionId}/reject"),
  CommitSkrillToWallet("/api/wallet/rest/v3/customers/{{playerId}}/payment-methods/SKRILL_IN"),
  PrecommitPaymentToWallet("/api/wallet/rest/v3/payments/{{deposit_paymentId}}/precommit"),
  // endregion

  // region DEL Methods
  PaymentMethodWithIdWebV1OPAP(
      "/web/wallet/rest/v1-opap/customers/{{playerId}}/payment-methods/{{paymentMethodId}}"),
  DeletePaymentMethodV1("/api/wallet/rest/v1/customers/{{playerId}}/payment-methods/delete");

  // endregion

  private String resource;

  WalletServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
