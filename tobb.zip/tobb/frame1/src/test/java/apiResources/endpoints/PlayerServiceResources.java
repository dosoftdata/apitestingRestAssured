// Player Service = /customer Endpoints
package apiResources.endpoints;

public enum PlayerServiceResources {
  // region Get Methods
  GetPlayerLevels("/web/customer/rest/v1/players/" + "{{playerId}}" + "/player-levels"),
  GetBoPendingVerifications("/cc/customer/rest/v1/pending-verifications"),
  GetBoPlayerPendingVerifications(
      "/cc/customer/rest/v1/players/{{playerId}}/pending-verifications"),
  GetBoKycMsisdnStatus("/cc/customer/rest/v1/players/{{playerId}}/verifications"),
  GetBoChangesTab("/cc/customer/rest/v1/players/{{playerId}}/change-history"),
  GetPlayerLevel("/cc/customer/rest/v1-opap/players/{{playerId}}/access/groups"),
  GetUploadedDocuments("/cc/customer/rest/v1/players/{{playerId}}/documents"),
  GetPlayerV2("/cc/customer/rest/v2/players/{{playerId}}"),
  GetPlayer("web/customer/rest/v1-opap/players/{{playerId}}"),
  GetPlayerInfoMasked("/web/customer/rest/v2-opap/players/{{playerId}}/masked"),
  GetPlayerInfoEnableOtp("/web/customer/rest/v2-opap/players/{{playerId}}"),
  GetAccountClosure("/cc/customer/rest/v3/players/account-actions"),
  GetIbanManagement("/cc/customer/rest/v2/pending-verifications"),
  GetInactivityManagement("/cc/customer/rest/v4/players/account-actions"),
  GetPlayerOverview("/cc/customer/rest/v1/customers"),

  // endregion

  // region POST Methods
  RegisterPlayer("/web/customer/rest/v1-opap/players"),
  VerifyPlayersEmail("/web/customer/rest/v1/verifications/email"),
  UploadDocumentsWeb("/web/customer/rest/v1/players/{{playerId}}/documents"),
  VerifyDocuments("/cc/customer/rest/v1/players/{{playerId}}/verification-documents/approve"),
  VerificationConfirm("/cc/customer/rest/v1/players/{{playerId}}/verifications/confirm"),
  VerifyIBAN("/api/customer/rest/v1/customers/{{playerId}}/verifications/iban"),
  ValidateRegistrationFields("/web/customer/rest/v1-opap/players/registration-fields/validate"),
  // endregion

  // region POST & PUT method
  VerifyOTP("/web/customer/rest/v1/otp"),
  // endregion

  // region PUT Methods
  MSISDNRegister("/web/customer/rest/v2/players/{{playerId}}/msisdn-register"),
  AddAndRemoveUsersFromGroups("/cc/customer/rest/v1-opap/players/{{playerId}}/access/games-groups"),
  MSISDNRegisterNew("/web/customer/rest/v2/players/{{playerId}}/msisdn"),
  MSISDNRegisterVerify("/web/customer/rest/v2/players/{{playerId}}/msisdn/verify"),
  EnableMFALogin("/web/customer/rest/v1/users/{{playerId}}/preferences/mfa/login/enablement"),
  DisableMFALogin("/web/customer/rest/v1/users/{{playerId}}/preferences/mfa/login/disablement"),
  UpdatePasswordWeb("/web/customer/rest/v1/customers/{{playerId}}/password"),
  OpenCloseAccountCC("/cc/customer/rest/v2/players/{{playerId}}/status");

  // endregion

  // region DEL Methods

  // endregion
  private String resource;

  PlayerServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
