package apiResources.endpoints.mockEndpoints;

public enum DrillHostServiceResources {

  // region GET Methods
  // endregion

  // region POST Methods
  DrillHost("/proxy/drill/query.json");
  // endregion

  // region PUT Methods

  // endregion

  // region DEL Methods

  // endregion
  private String resource;

  DrillHostServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
