package apiResources.endpoints;

public enum AdminServiceResources {

    // region GET Methods
    GetAdminSession("/cc/admin/rest/v1/session-admin"),
    GetAdminUsers("/cc/admin/rest/v1/admins"),
    ExportSuperAdminUsers("cc/admin/rest/v1/admins/{{superAdminAccessId}}/export"),
    GetAdminById("/cc/admin/rest/v1/admins/{{adminId}}"),

    // endregion

    // region POST Methods
    CreateOrCheckNewClerkUser("/cc/admin/rest/v1/admins"),
    // endregion

    // region PUT Methods
    UpdateAdminInfo("/cc/admin/rest/v1/admins/{{adminId}}/info"),
    UpdateAdminPassword("/cc/admin/rest/v1/admins/{{adminId}}/password"),
    EnableClerkUser("cc/admin/rest/v1/admins/{{affiliateUserRoleId}}/info"),
    UpdateAffiliatePassword("cc/admin/rest/v1/admins/{{affiliateUserRoleId}}/password"),
    EnableUser("cc/admin/rest/v1/admins/{{roleId}}/info");
    // endregion

    // region DEL Methods

    // endregion
    private String resource;

    AdminServiceResources(String resource) {
        this.resource = resource;
    }

    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }
}
