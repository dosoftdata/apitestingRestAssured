package apiResources.endpoints;

public enum ApplePayServiceResources {

  // region GET Methods

  // endregion

  // region POST Methods
  ApplePay("/web/applepay/rest/v1/customers/{{playerId}}/payments");
  // endregion

  // region PUT Methods

  // endregion

  // region DEL Methods

  // endregion
  private String resource;

  ApplePayServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
