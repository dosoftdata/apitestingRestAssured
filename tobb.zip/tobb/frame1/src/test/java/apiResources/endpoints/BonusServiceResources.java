package apiResources.endpoints;

public enum BonusServiceResources {

    // region GET Methods

    //WEB
    GetWebBonusPrizes("/web/bonus/rest/v1/bonus-prizes/users/{{playerId}}"),
    GetWebBonuses("/web/bonus/rest/v1/bonuses"),
    GetWebReferralCode("/web/bonus/rest/v1/bonuses/referral-code"),
    GetWebBonusPrizesFdbGameIds("/web/bonus/rest/v1/bonus-prizes/users/{{playerId}}/fdb/gameIds"),
    GetWebBonusPrizesFdb("/web/bonus/rest/v1/bonus-prizes/users/{{playerId}}/fdb"),

    //API
    GetBonusPrizes("/api/bonus/rest/v1/bonus-prizes/users/1-{{playerId}}"),
    GetAllowedGame("/api/bonus/rest/v1/bonus-prizes/users/1-{{playerId}}/allowed-game"),
    GetBonusPrizesWithId("/api/bonus/rest/v1/bonus-prizes/users/1-{{playerId}}/assigned/{{bonusPrizeId}}"),
    GetPreferredBonusPrize("/api/bonus/rest/v1/bonus-prizes/users/1-{{playerId}}/preferred-bonus-prize"),

    // CC
    GetCCBonusWithId("/cc/bonus/rest/v1/bonuses/{{bonusActiveId}}"),
    GetCCBonusPrizesWithId("/cc/bonus/rest/v1/bonus-prizes/{{bonusPrizeId}}"),
    GetCCBonusPrizesWithUserId("/cc/bonus/rest/v1/bonus-prizes/users/1-{{playerId}}"),
    GetCCBonusWithName("/cc/bonus/rest/v1/bonuses/name/{{bonusName}}"),
    GetCCAllowedGames("/cc/bonus/rest/v1/bonuses/allowed-games"),
    GetCCPaymentMethods("/cc/bonus/rest/v1/bonuses/payment-methods"),
    // endregion

    // region POST Methods
    AssignBonus("/api/bonus/rest/v1/bonuses/{{bonusActiveId}}/users/1-{{playerId}}"),
    AssignBonusSegment("/api/bonus/rest/v1/bonuses/{{bonusActiveId}}/segment"),
    GetWebBonusPrizesFdbSelection("/web/bonus/rest/v1/bonus-prizes/users/{{playerId}}/fdb/selection"),
    // endregion

    // region GET & POST Methods at the same time
    Bonuses("/cc/bonus/rest/v1/bonuses"),
    AllowedGames("/cc/bonus/rest/v1/bonuses/{{bonusActiveId}}/allowed-games"),
    // endregion

    // region PUT Methods
    UpdateBonusPrizes("/api/bonus/rest/v1/bonus-prizes/{{bonusPrizeId}}/users/1-{{playerId}}"),
    AdjustBonusPrizes("/cc/bonus/rest/v1/bonus-prizes/{{bonusPrizeId}}/users/1-{{playerId}}/adjust"),
    UpdateCCBonus("/cc/bonus/rest/v1/bonuses/{{bonusActiveId}}"),
    UpdateCCBonusPrize("/cc/bonus/rest/v1/bonuses/{{bonusPrizeId}}"),
    ModifyFdbForBonus("/cc/bonus/rest/v1/bonuses/{{bonusActiveId}}/fdb");
    // endregion

    // region DEL Methods

    // endregion
    private String resource;

    BonusServiceResources(String resource) {
        this.resource = resource;
    }

    public String getResource() {
        return resource;
    }

    public void setResource(String resource) {
        this.resource = resource;
    }
}
