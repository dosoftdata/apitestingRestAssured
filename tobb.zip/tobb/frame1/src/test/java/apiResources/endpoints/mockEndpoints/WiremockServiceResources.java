package apiResources.endpoints.mockEndpoints;

public enum WiremockServiceResources {
  // region GET Methods
  GetAllStubs("/__admin/mappings"),
  GetAllRequests("/__admin/requests"),

  // endregion

  // region POST Methods
  ResetAllMappings("/__admin/mappings/reset"),
  ResetAllScenarios("/__admin/scenarios/reset"),
  AddAStub("__admin/mappings");

  // endregion

  // region PUT Methods

  // endregion

  // region DEL Methods

  // endregion
  private String resource;

  WiremockServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
