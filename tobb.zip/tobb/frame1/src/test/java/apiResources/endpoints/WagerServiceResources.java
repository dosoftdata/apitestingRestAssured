package apiResources.endpoints;

public enum WagerServiceResources {
  // region GET Methods
  GetTime("/web/wager-service/rest/v1/wagers/time"),
  GetLotteryWagerDetailsWeb(
      "/web/wager-service/rest/v1/wagers/{{playerId}}/lottery/ILOT-{{serialNumber}}/details"),
  GetLotteryWagerDetailsCC(
      "/cc/wager-service/rest/v1/users/{{playerId}}/wagers/lottery/ILOT-{{serialNumber}}/details"),
  GetWagerProductIds("/cc/wager-service/rest/v1/wagers/productIds"),
  GetAllWagers("/cc/wager-service/rest/v1/users/1-{{playerId}}/wagers"),
  // endregion
  // region POST Methods
  PlaceWager("/web/wager-service/rest/v1/wagers/" + "{{playerId}}" + "/place/lotteryWager"),
  PlaceMultipleWagers(
      "/web/wager-service/rest/v1/wagers/{{playerId}}/place/multiple/lotteryWagers"),
  PayWinningBet("/api/wager-service/rest/v1/winnings"),
  PlayBetFunds("/api/wager-service/rest/v1/users/1-{{playerId}}/funds"),
  CaptureBet("/api/wager-service/rest/v1/users/1-{{playerId}}/funds/{{referenceId2}}/capture"),
  CancelReservation(
      "/api/wager-service/rest/v1/users/1-{{playerId}}/funds/{{referenceId2}}/cancel"),
  EmailMyTicket("/web/wager-service/rest/v1/wagers/{{playerId}}/lottery/{{serialNumber}}/notify");
  // endregion

  // region PUT Methods

  // endregion

  // region DEL Methods

  // endregion

  private String resource;

  WagerServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
