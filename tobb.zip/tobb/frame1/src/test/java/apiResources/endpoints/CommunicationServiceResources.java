package apiResources.endpoints;

public enum CommunicationServiceResources {

  // region GET Methods
  GetMailIdForFetchHash("/cc/communication/rest/v1/emails"),
  GetHashForMailVerification("/cc/communication/rest/v1/emails/" + getMailIdForHash()),
  GetBoSms("/cc/communication/rest/v1/sms"),
  GetBoSmsDescription("/cc/communication/rest/v1/sms/{{smsId}}"),
  GetPlayerNotifications("/web/communication/rest/v1/notifications"),
  GetBONotifications("/cc/communication/rest/v1/notifications"),
  GetBONotificationsWithId("/cc/communication/rest/v1/notifications/{{notificationId}}"),
  GetPlayerUnseenNotifications("/web/communication/rest/v1/notifications/unseen"),
  GetBOEvents("/cc/communication/rest/v1/events"),
  GetBOEventsDetails("/cc/communication/rest/v1/events/{{eventId}}"),
  GetBOEmailTemplateForEventId("/cc/communication/rest/v1/events/{{eventId}}/email-templates"),
  GeBONotificationsForEventId(
      "/cc/communication/rest/v1/events/{{eventId}}/notification-templates"),
  GetBOSmsTemplatesForEventId("/cc/communication/rest/v1/events/{{eventId}}/sms-templates"),
  GetBOInternalMessagesForEventId(
      "/cc/communication/rest/v1/events/{{eventId}}/internalmessage-templates"),
  GetPlayerPreferences(
      "/web/communication/rest/v1/messages-preferences/{{playerId}}?preferenceType=ALL&category=ALL"),
  GetPlayerPreferencesForPreferenceTypeMarketing(
      "/web/communication/rest/v1/messages-preferences/{{playerId}}?preferenceType=MARKETING"),
  GetPlayerPreferencesApiV1("/api/communication/rest/v1/messages-preferences/players/{{playerId}}"),
  GetPlayerPreferencesWebV1("/web/communication/rest/v1/messages-preferences/{{playerId}}"),
  GetInternalMessages("/api/communication/rest/v1/internal-messages/inbox/messages"),
  // endregion

  // region POST Methods
  BulkMessages("/api/communication/rest/v1/messages/bulk"),
  AddMessageTypesNEP(
      "/api/communication/rest/v1/messages-preferences/players/{{playerId}}/verticals/_NEP/marketing/message-types"),
  AddMessageTypesEP(
      "/api/communication/rest/v1/messages-preferences/players/{{playerId}}/verticals/_EP/marketing/message-types"),

  //  endregion

  // region Hybrid Methods
  PlayerPreferences(
      "/cc/communication/rest/v1/messages-preferences/{{playerId}}"), // Get or Put method
  BOEmailTemplateId(
      "/cc/communication/rest/v1/events/{{eventId}}/email-templates/{{emailTemplateId}}"),
  BONotificationsForNotificationId(
      "/cc/communication/rest/v1/events/{{eventId}}/notification-templates/{{notificationId}}"),
  PlayerPreferencesWebV2("/web/communication/rest/v2/messages-preferences/{{playerId}}"),
  PlayerPreferencesCCV1("/cc/communication/rest/v1/messages-preferences/{{playerId}}"),
  // endregion

  // region PUT Methods
  EditPlayerPreferencesApiV1EP(
      "/api/communication/rest/v1/messages-preferences/players/{{playerId}}/verticals/_EP"),
  EditPlayerPreferencesApiV1NEP(
      "/api/communication/rest/v1/messages-preferences/players/{{playerId}}/verticals/_NEP"),
  EditPlayerPreferencesApiV2EP(
      "/api/communication/rest/v2/messages-preferences/players/{{playerId}}/verticals/_EP"),
  EditPlayerPreferencesApiV2NEP(
      "/api/communication/rest/v1/messages-preferences/players/{{playerId}}/verticals/_NEP"),
  EditPlayerPreferencesWebV1("/web/communication/rest/v1/messages-preferences/{{playerId}}"),
  MarkNotificationAsSeen("/web/communication/rest/v1/notifications/mark-as-seen"),
  MarkNotificationAsRead("/web/communication/rest/v1/notifications/{{notificationId}}/read"),
  InitializePlayerPreferences("/web/communication/rest/v1/messages-preferences/{{playerId}}");
  // endregion

  // region DEL Methods

  // endregion

  private String resource;
  public static String mailIdForHash;
  public static String smsId;

  CommunicationServiceResources(String resource) {
    this.resource = resource;
  }

  public static String getMailIdForHash() {
    return mailIdForHash;
  }

  public static void setMailIdForHash(String mailId) {
    mailIdForHash = mailId;
  }

  public static String getSmsId() {
    return smsId;
  }

  public static void setSmsId(String sms) {
    smsId = sms;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
