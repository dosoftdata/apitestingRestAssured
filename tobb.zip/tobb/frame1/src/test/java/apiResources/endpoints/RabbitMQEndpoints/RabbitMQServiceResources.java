package apiResources.endpoints.RabbitMQEndpoints;

public enum RabbitMQServiceResources {

  // region Hybrid methods

  // endregion

  // region GET Methods

  // endregion

  // region POST Methods
  CreateBinding("/api/bindings/%2F/e/{{exchange}}/q/{{queue}}"),
  GetQueueMessages("/api/queues/%2f/{{queue}}/get"),
  // /api/queues/

  PublishToExchange("/api/exchanges/%2f/{{exchange}}/publish"),
  // region Login External

  // endregion

  // endregion

  // region PUT Methods
  CreateQueue("/api/queues/%2f/{{queue}}");
  // replace url and variable

  // endregion

  // region DEL Methods

  // endregion
  private String resource;

  RabbitMQServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
