package apiResources.endpoints;

public enum WitServiceResources {

  // region GET Methods
  ReplaceThisUrl("/sth/sth");

  // endregion

  // region POST Methods

  // endregion

  // region PUT Methods

  // endregion

  // region DEL Methods

  // endregion

  private String resource;

  WitServiceResources(String resource) {
    this.resource = resource;
  }

  public String getResource() {
    return resource;
  }

  public void setResource(String resource) {
    this.resource = resource;
  }
}
