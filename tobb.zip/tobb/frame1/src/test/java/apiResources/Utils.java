package apiResources;

import apiResources.endpoints.RabbitMQEndpoints.RabbitMQServiceResources;
import apiResources.endpoints.mockEndpoints.DatabaseBridgeServiceResources;
import apiResources.endpoints.mockEndpoints.DrillHostServiceResources;
import apiResources.endpoints.mockEndpoints.WiremockServiceResources;
import apiResources.pojo.requests.communicationService.PlayerPreferences;
import apiResources.pojo.requests.wagerService.CancelReservation;
import apiResources.pojo.requests.wagerService.CaptureBet;
import apiResources.pojo.requests.wagerService.PlayBetFunds;
import apiResources.endpoints.*;
import apiResources.testDataBuild.AccessServiceData;
import apiResources.testDataBuild.CommunicationServiceData;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.http.Cookie;
import io.restassured.http.Cookies;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.junit.jupiter.api.Assertions;
import stepDefinitions.CommonStepDefinitions;

import java.io.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

import static io.restassured.RestAssured.given;
import static org.apache.http.client.params.ClientPNames.COOKIE_POLICY;
import static org.apache.http.client.params.CookiePolicy.BROWSER_COMPATIBILITY;

/**
 * Utils is a helper class that has all the core functionality as well as many global variables that
 * can be inherited in stepDefinitions.
 */
public class Utils extends DataContext {

    /**
     * Sets all variables related to configuration files.
     */
    public void setUpConfig() {
        try {
            // region Global Values
            environment = getGlobalValue("environment");
            maxRetries = Integer.parseInt(getGlobalValue("maxRetries"));
            initalMaxRetries = maxRetries;
            mobilePrefix = getGlobalValue("mobilePrefix");
            isAccessToken = Boolean.parseBoolean(getGlobalValue("isAccessToken"));
            ccUsername = getGlobalValue("cc.username");
            ccPassword = getGlobalValue("cc.password");
            isMeEnabledInWeb = Boolean.parseBoolean(getGlobalValue("isMeEnabledInWeb"));
            // endregion

            // region Environment specific Values
            host = getEnvironmentValue(environment, "web.host");
            ccHost = getEnvironmentValue(environment, "cc.host");
            walletHost = getEnvironmentValue(environment, "wallet.host");
            wiremockHost = getEnvironmentValue(environment, "wiremock.host");
            rabbitHost = getEnvironmentValue(environment, "rabbit.host");
            configUsername = getEnvironmentValue(environment, "web.username");
            configPassword = getEnvironmentValue(environment, "web.password");
            configPlayerId = getEnvironmentValue(environment, "web.playerId");
            // endregion

            username = configUsername;
            password = configPassword;

            log = new PrintStream(new FileOutputStream("logging.txt"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Gets the value of the key from global.properties.
     *
     * @param key the key
     * @return the global value
     * @throws IOException the io exception
     */
    public static String getGlobalValue(String key) throws IOException {
        Properties prop = new Properties();
        InputStream file = Utils.class.getResourceAsStream("/global.properties");
        if (file == null) {
            throw new RuntimeException("Didn't find the file: global.properties");
        }
        prop.load(file);
        String propertyValue = prop.getProperty(key);
        if (propertyValue == null) {
            throw new RuntimeException(
                    "Didn't find the property " + key + " in file:  global.properties");
        }
        return propertyValue;
    }

    /**
     * Gets environment value from the specific environment property file.
     *
     * @param environment the environment
     * @param key         the key
     * @return the environment value
     * @throws IOException the io exception
     */
    public static String getEnvironmentValue(String environment, String key) throws IOException {
        Properties prop = new Properties();
        InputStream file =
                Utils.class.getResourceAsStream("/environments/" + environment + ".properties");
        if (file == null) {
            throw new RuntimeException("Didn't find the file: " + environment + ".properties");
        }
        prop.load(file);
        String propertyValue = prop.getProperty(key);
        if (propertyValue == null) {
            throw new RuntimeException(
                    "Didn't find the property " + key + " in file: " + environment + ".properties");
        }
        return propertyValue;
    }

    /**
     * Gets json path of a key value from the response of a call.
     *
     * @param response the response
     * @param key      the key
     * @return the json path
     */
    public String getJsonPath(Response response, String key) {
        String resp = response.asString();
        JsonPath js = new JsonPath(resp);
        return js.get(key).toString();
    }

    /**
     * The predefined specifications are defined here.
     *
     * @param spec the spec
     * @return the request specification
     */
    public RequestSpecification requestSpecWithHeadersSpecification(String spec) {
        RequestSpecification specification;
        specString = spec;

        if (spec.contains("cc_")) {
            setSpecBuildersCC();
            switch (spec) {
                case "cc_csrftokenSpec":
                    specification = cc_csrftokenSpec;
                    break;
                case "cc_incorrectAuthorizationSpec":
                    specification = cc_incorrectAuthorizationSpec;
                    break;
                case "cc_emptySpec":
                    specification = cc_emptySpec;
                    break;
                case "cc_incorrectCookieSpec":
                    specification = cc_incorrectCookieSpec;
                    break;
                default:
                    specification = cc_csrftokenSpec;
                    System.out.println("Wrong specification " + spec);
                    break;
            }
        } else if (spec.contains("api_")) {
            setSpecBuildersApi();
            switch (spec) {
                case "api_mainSpec_specWithGameId":
                    specification = api_mainSpec_specWithGameId;
                    break;
                case "api_mainSpec":
                    specification = api_mainSpec;
                    break;
                case "api_mainSpec_mainHost":
                    specification = api_mainSpec_mainHost;
                    break;
                case "api_specWithGameId":
                    specification = api_specWithGameId;
                    break;
                case "api_specWithGameId_idempotent":
                    specification = api_specWithGameId_idempotent;
                    break;
                case "api_checkoutToraWallet":
                    specification = api_checkoutToraWallet;
                    break;
                case "api_intralotSpecWithGameId":
                    specification = api_intralotSpecWithGameId;
                    break;
                case "api_incorrectAuthorizationSpecBothParts":
                    specification = api_incorrectAuthorizationSpecBothParts;
                    break;
                case "api_incorrectAuthorizationSpecFirstPart":
                    specification = api_incorrectAuthorizationSpecFirstPart;
                    break;
                case "api_incorrectAuthorizationSpec":
                    specification = api_incorrectAuthorizationSpec;
                    break;
                case "api_emptySpec":
                    specification = api_emptySpec;
                    break;
                case "api_login":
                    specification = api_login;
                    break;
                case "api_login_missingAuth":
                    specification = api_login_missingAuth;
                    break;
                default:
                    specification = api_mainSpec;
                    System.out.println("Wrong specification " + spec);
                    break;
            }
        } else if (spec.contains("upload")) {
            switch (spec) {
                case "uploadSpecWeb":
                    specification = uploadSpecWeb;
                    break;
                default:
                    specification = uploadSpecWeb;
                    System.out.println("Wrong specification " + spec);
                    break;
            }
        } else if (spec.contains("wiremock")) {
            setSpecBuildersWiremock();
            switch (spec) {
                case "wiremockSpec":
                    specification = wiremockSpec;
                    break;
                default:
                    specification = wiremockSpec;
                    System.out.println("Wrong specification " + spec);
                    break;
            }
        } else if (spec.contains("rabbit")) {
            setSpecBuildersRabbitMQ();
            switch (spec) {
                case "rabbitSpec":
                    specification = rabbitSpec;
                    break;
                default:
                    specification = rabbitSpec;
                    System.out.println("Wrong specification " + spec);
                    break;
            }
        } else {
            if (isAccessToken) {
                setSpecBuildersNew();
            } else {
                setSpecBuildersOld();
            }
            specification = mainspec;

            switch (spec) {
                case "specWithGameId":
                    specification = specwithgameId;
                    break;
                case "mainSpec":
                    break;
                case "specWithGameIdOrigin":
                    specification = specwithgameIdOrigin;
                    break;
                case "specWithOrigin":
                    specification = specWithOrigin;
                    break;
                case "mainspecCCcsrfNoToken":
                    specification = mainspecCCcsrfNoToken;
                    break;
                case "specWithGameIdNoToken":
                    specification = specwithgameIdNoToken;
                    break;
                case "loginNew":
                    specification = loginNew;
                    break;
                case "loginNewGeoBlocking":
                    specification = loginNewGeoBlocking;
                    break;
                case "emptySpec":
                    setSpecBuildersEmpty();
                    specification = emptySpec;
                    break;
                case "otpSpecNoToken":
                    specification = otpSpecNoToken;
                    break;
                case "incorrectAuthorizationSpec":
                    specification = incorrectAuthorizationSpec;
                    break;
                case "incorrectCookieSpec":
                    specification = incorrectCookieSpec;
                    break;
                case "specWithResourceValue":
                    specification = specWithResourceValue;
                    break;
                default:
                    System.out.println("Wrong specification " + spec);
                    break;
            }
        }
        req =
                given()
                        .config(redirectWithCookiesConfig)
                        .log()
                        .all()
                        .relaxedHTTPSValidation()
                        .redirects()
                        .follow(true)
                        .redirects()
                        .allowCircular(true)
                        .spec(specification);
        return req;
    }

    /**
     * Sets specBuilders (headers) for CC calls.
     */
    private void setSpecBuildersCC() {

        cc_csrftokenSpec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + ccHost)
                        .addHeader("x-csrftoken", ccCsrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", ccHost)
                        //   .addCookie(new Cookie.Builder("csrftoken", ccCsrftoken).build())
                        // doesn't work
                        // with that . INVESTIGATE DEV?
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        cc_incorrectAuthorizationSpec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + ccHost)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", ccHost)
                        .addHeader("Authorization", "test")
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        cc_incorrectCookieSpec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + ccHost)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", ccHost)
                        .addCookie(new Cookie.Builder("csrftoken", "IamWrongCookieCC").build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        cc_emptySpec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + ccHost)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", ccHost)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();
    }

    /**
     * Sets specBuilders (headers) for Upload calls. This method is an exception and should be called
     * in Cucumber step instead of Utils because of it's parameters
     *
     * @param fileName   the fileName to be uploaded
     * @param typeOfFile the type of file to be uploaded. headers ->type
     */
    public void setSpecBuildersUpload(String fileName, String typeOfFile) throws IOException {

        String currentPath = new java.io.File(".").getCanonicalPath();
        String fileImagePath = "/src/test/resources/images/";

        String imagePath = currentPath + fileImagePath;
        String stringPath = imagePath + fileName;

        System.out.println("I am trying to upload image from path" + stringPath);
        File path = new File(stringPath);

        System.out.println("Path after conversion to File: " + path);

        File initialPath2 = new File(imagePath);

        File filesList2[] = initialPath2.listFiles();
        System.out.println("List of files and directories in the final directory:");
        for (File file : filesList2) {
            System.out.println("File name: " + file.getName());
            System.out.println("File path: " + file.getAbsolutePath());
            System.out.println(" ");
        }

        uploadSpecWeb =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", csrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", "Bearer " + accessToken)
                        .addCookie(new Cookie.Builder("csrftoken", csrftoken).build())
                        .addMultiPart("file", path, "multipart/form-data")
                        .addMultiPart("fileName", fileName, "multipart/form-data")
                        .addMultiPart("type", typeOfFile, "multipart/form-data")
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.MULTIPART)
                        .build();
    }

    /**
     * Sets specBuilders (headers) for Api calls.
     */
    private void setSpecBuildersApi() {
        api_mainSpec_specWithGameId =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + walletHost)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", walletHost)
                        .addHeader("Authorization", "Bearer " + apiToken)
                        .addHeader("X-GAME-ID", gameId)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        api_mainSpec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + walletHost)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", walletHost)
                        .addHeader("Authorization", "Bearer " + apiToken)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        api_mainSpec_mainHost =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", "Bearer " + apiToken)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        api_specWithGameId =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", "Bearer " + apiToken)
                        .addHeader("X-GAME-ID", gameId)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        api_specWithGameId_idempotent =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", "Bearer " + apiToken)
                        .addHeader("X-GAME-ID", gameId)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        api_intralotSpecWithGameId =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", "Bearer " + intralotToken)
                        .addHeader("X-GAME-ID", gameId)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        api_incorrectAuthorizationSpec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", "Bearer " + "test")
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        api_incorrectAuthorizationSpecFirstPart =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", "Test" + apiToken)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        api_incorrectAuthorizationSpecBothParts =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", "Test_Test_Test")
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        api_login =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", api_auth)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        api_login_missingAuth =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        api_emptySpec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        String toraWalletprefix = "";
        if (environment.equals("Preprod")) {
            toraWalletprefix = "preprod";
        } else {
            toraWalletprefix = "sandbox";
        }

        api_checkoutToraWallet =
                new RequestSpecBuilder()
                        .setBaseUri("https://checkout." + toraWalletprefix + ".torawallet.gr")
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Origin", "https://checkout." + toraWalletprefix + ".torawallet.gr")
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();
    }

    /**
     * Sets specBuilders (headers) for Wiremock calls.
     */
    private void setSpecBuildersWiremock() {
        if (wiremockHost.isBlank() || wiremockHost == null) {
            throw new RuntimeException(
                    "Wiremock host url has no value. Please check the .properties file for wiremock.host or you probably don't need wiremock in "
                            + environment);
        }

        wiremockSpec =
                new RequestSpecBuilder()
                        .setBaseUri("http://" + wiremockHost)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", wiremockHost)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();
    }

    /**
     * Sets specBuilders (headers) for Rabbit MQ calls.
     */
    private void setSpecBuildersRabbitMQ() {
        if (rabbitHost.isBlank() || rabbitHost == null) {
            throw new RuntimeException(
                    "Rabbit host url has no value. Please check the .properties file for rabbit.host or you probably don't need Rabbit MQ host in "
                            + environment);
        }

        String rabbitAuth = "Basic Z3Vlc3Q6Z3Vlc3Q=";

        rabbitSpec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + rabbitHost)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Authorization", rabbitAuth)
                        .setUrlEncodingEnabled(false)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();
    }

    private void setSpecBuildersEmpty() {
        if (!environment.contains("Azure") && drillOrBridge) {
            throw new RuntimeException(
                    "environment has incorrect value."
                            + " Please check the environment in global.properties as we need it to be some Azure environment or deactivate Drill/Database scenarios"
                            + ". Current Environment is "
                            + environment);
        }

        emptySpec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();
    }

    /**
     * Sets game id. Used by common step.
     *
     * @param xGameId the x game id
     */
    public void setGameId(String xGameId) {
        try {
            gameId = apiResources.xGameId.valueOf(xGameId.class, xGameId).getValue();
        } catch (Exception e) {
            throw new RuntimeException("xGame Id: " + xGameId + " is not declared as an enum");
        }
    }

    /**
     * Sets spec builders for web calls (with access token)
     */
    public static void setSpecBuildersNew() {
        mainspec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", csrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", "Bearer " + accessToken)
                        .addCookie(new Cookie.Builder("csrftoken", csrftoken).build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        incorrectAuthorizationSpec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", "test")
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        incorrectCookieSpec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addCookie(new Cookie.Builder("csrftoken", "IamWrongCookieWeb").build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        otpSpecNoToken =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", csrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addCookie(new Cookie.Builder("csrftoken", csrftoken).build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        specwithgameId =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", csrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("X-GAME-ID", gameId)
                        .addHeader("Authorization", "Bearer " + accessToken)
                        .addCookie(new Cookie.Builder("csrftoken", csrftoken).build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        specwithgameIdOrigin =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", csrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("X-GAME-ID", gameId)
                        .addHeader("Origin", "https://" + host)
                        .addHeader("Authorization", "Bearer " + accessToken)
                        .addCookie(new Cookie.Builder("csrftoken", csrftoken).build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        specWithOrigin =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", csrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Origin", "https://" + host)
                        .addHeader("Authorization", "Bearer " + accessToken)
                        .addCookie(new Cookie.Builder("csrftoken", csrftoken).build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        mainspecCCcsrfNoToken =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", ccCsrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addCookie(new Cookie.Builder("csrftoken", ccCsrftoken).build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        specwithgameIdNoToken =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", csrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("X-GAME-ID", gameId)
                        .addCookie(new Cookie.Builder("csrftoken", csrftoken).build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        String authWidget =
                "d2lkZ2V0Omh0dHBzOi8vZGV2LWppcmEuZGV2ZWxvcG1lbnQuZGMub3BhcC9icm93c2UvREVWLTEyNzIx";
        String basic_auth_widgets = "Basic " + authWidget;

        loginNew =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("X-GAME-ID", gameId)
                        .addHeader("Authorization", basic_auth_widgets)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        loginNewGeoBlocking =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("X-GAME-ID", gameId)
                        .addHeader("X-SOURCE-ALLOW", String.valueOf(xSourceAllow))
                        .addHeader("Authorization", basic_auth_widgets)
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        specWithResourceValue =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", csrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("Authorization", "Bearer " + accessToken)
                        .addHeader("X-RESOURCE-VALUE", resourceValue)
                        .addHeader("X-OTP", otpCode)
                        .addCookie(new Cookie.Builder("csrftoken", csrftoken).build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();
    }

    /**
     * Sets spec builders for old login. (without accessToken)
     */
    public static void setSpecBuildersOld() {
        mainspec =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", csrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addCookie(new Cookie.Builder("csrftoken", csrftoken).build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        specwithgameId =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", csrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("X-GAME-ID", gameId)
                        .addCookie(new Cookie.Builder("csrftoken", csrftoken).build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();

        specwithgameIdOrigin =
                new RequestSpecBuilder()
                        .setBaseUri("https://" + host)
                        .addHeader("x-csrftoken", csrftoken)
                        .addHeader("Accept-Encoding", "gzip, deflate, br")
                        .addHeader("Host", host)
                        .addHeader("X-GAME-ID", gameId)
                        .addHeader("Origin", "https://" + host)
                        .addCookie(new Cookie.Builder("csrftoken", csrftoken).build())
                        .addFilter(RequestLoggingFilter.logRequestTo(log))
                        .addFilter(ResponseLoggingFilter.logResponseTo(log))
                        .setContentType(ContentType.JSON)
                        .build();
    }

    /**
     * Login the old way. (without access token)
     */
    protected static void loginOld() {
        System.out.println("#### Starting with common HttpClient LoginOld");
        String encoding = "gzip, deflate, br";
        String channel = "WEB";
        String subChannel = "";
        String group = "EP";

        AccessServiceData accessServiceData = new AccessServiceData();
        requestBody = accessServiceData.addLoginOldData(username, password, channel, subChannel, group);

        AccessServiceResources accessServiceAPI = AccessServiceResources.valueOf("LoginOld");
        String resourceValue = accessServiceAPI.getResource();

        // OPTIONS TO GET CSRFTOKEN
        {
            Response response =
                    given()
                            .config(redirectWithCookiesConfig)
                            .log()
                            .all()
                            .relaxedHTTPSValidation()
                            .contentType(ContentType.JSON)
                            .header("Host", host)
                            .header("Accept-Encoding", encoding)
                            .header("x-game-id", gameId)
                            .when()
                            .request("OPTIONS", "https://" + host + resourceValue)
                            .then()
                            .assertThat()
                            .statusCode(200)
                            .extract()
                            .response();

            showAllCookiesAndPrintResponse(
                    response.getDetailedCookies(), response.getStatusCode(), response.asPrettyString());
            if (response.getCookie("csrftoken") != null) {
                csrftoken = response.getCookie("csrftoken");
            }
        }
        // LOGIN (OLD WAY)
        {
            Response login_resp =
                    given()
                            .config(redirectWithCookiesConfig)
                            .log()
                            .all()
                            .relaxedHTTPSValidation()
                            .contentType(ContentType.JSON)
                            .header("Host", host)
                            .header("Accept-Encoding", encoding)
                            .header("x-csrftoken", csrftoken)
                            .header("X-GAME-ID", gameId)
                            .and()
                            .body(requestBody)
                            .when()
                            .post("https://" + host + resourceValue)
                            .then()
                            .assertThat()
                            .statusCode(204)
                            .extract()
                            .response();

            showAllCookiesAndPrintResponse(
                    login_resp.getDetailedCookies(), login_resp.getStatusCode(), login_resp.asPrettyString());
        }
    }

    /**
     * Login the new way. (with access token)
     */
    protected static void loginNew() {
        System.out.println("#### Starting with common HttpClient LoginNew");

        String authWidget =
                "d2lkZ2V0Omh0dHBzOi8vZGV2LWppcmEuZGV2ZWxvcG1lbnQuZGMub3BhcC9icm93c2UvREVWLTEyNzIx";
        String basic_auth_widgets = "Basic " + authWidget;
        String channel = "WEB";
        String group = "EP";
        String scope = "openid http://betware.com/oidc/scopes/session";
        String encoding = "gzip, deflate, br";

        AccessServiceData accessServiceData = new AccessServiceData();
        requestBody = accessServiceData.addLoginNewData(username, password, group, channel, scope);

        AccessServiceResources accessServiceAPI = AccessServiceResources.valueOf("LoginNew");
        String resourceValue = accessServiceAPI.getResource();

        {
            Response response =
                    given()
                            .config(redirectWithCookiesConfig)
                            .log()
                            .all()
                            .relaxedHTTPSValidation()
                            .redirects()
                            .follow(true)
                            .redirects()
                            .allowCircular(true)
                            .contentType(ContentType.JSON)
                            .header("Host", host)
                            .header("Accept-Encoding", encoding)
                            .header("X-GAME-ID", gameId)
                            .header("Authorization", basic_auth_widgets)
                            .body(requestBody)
                            .when()
                            .post("https://" + host + resourceValue)
                            .then()
                            .extract()
                            .response();

            JsonPath jsonPathEvaluator = response.jsonPath();
            accessToken = jsonPathEvaluator.get("access_token");
            String token = response.getCookie("csrftoken");
            if (response.getCookie("csrftoken") != null) {
                csrftoken = response.getCookie("csrftoken");
            } else {
                List<org.apache.http.cookie.Cookie> listofCookies = cookieStore.getCookies();
                for (org.apache.http.cookie.Cookie cookie : listofCookies) {
                    if (cookie != null && cookie.getName().equals("csrftoken")) {
                        csrftoken = cookie.getValue();
                    }
                }
            }

            showAllCookiesAndPrintResponse(
                    response.getDetailedCookies(), response.getStatusCode(), response.asPrettyString());
            Assertions.assertEquals(200, response.statusCode());
        }
    }

    protected static void loginNewNegative() {
        System.out.println("#### Starting with common HttpClient LoginNew");

        String authWidget =
                "d2lkZ2V0Omh0dHBzOi8vZGV2LWppcmEuZGV2ZWxvcG1lbnQuZGMub3BhcC9icm93c2UvREVWLTEyNzIx";
        String basic_auth_widgets = "Basic " + authWidget;
        String channel = "WEB";
        String group = "EP";
        String scope = "openid http://betware.com/oidc/scopes/session";
        String encoding = "gzip, deflate, br";

        AccessServiceData accessServiceData = new AccessServiceData();
        requestBody = accessServiceData.addLoginNewData(username, password, group, channel, scope);

        AccessServiceResources accessServiceAPI = AccessServiceResources.valueOf("LoginNew");
        String resourceValue = accessServiceAPI.getResource();

        {
            Response response =
                    given()
                            .config(redirectWithCookiesConfig)
                            .log()
                            .all()
                            .relaxedHTTPSValidation()
                            .redirects()
                            .follow(true)
                            .redirects()
                            .allowCircular(true)
                            .contentType(ContentType.JSON)
                            .header("Host", host)
                            .header("Accept-Encoding", encoding)
                            .header("X-GAME-ID", gameId)
                            .header("Authorization", basic_auth_widgets)
                            .body(requestBody)
                            .when()
                            .post("https://" + host + resourceValue)
                            .then()
                            .extract()
                            .response();

            JsonPath jsonPathEvaluator = response.jsonPath();
            accessToken = jsonPathEvaluator.get("access_token");
            String token = response.getCookie("csrftoken");
            if (response.getCookie("csrftoken") != null) {
                csrftoken = response.getCookie("csrftoken");
            } else {
                List<org.apache.http.cookie.Cookie> listofCookies = cookieStore.getCookies();
                for (org.apache.http.cookie.Cookie cookie : listofCookies) {
                    if (cookie != null && cookie.getName().equals("csrftoken")) {
                        csrftoken = cookie.getValue();
                    }
                }
            }

            showAllCookiesAndPrintResponse(
                    response.getDetailedCookies(), response.getStatusCode(), response.asPrettyString());
            Assertions.assertEquals(400, response.statusCode());
        }
    }

    /**
     * Login for api calls.
     */
    protected void loginAPI() {
        System.out.println("#### Starting with LoginAPI");
        String encoding = "gzip, deflate, br";

        String auth = "YmV0d2FyZTpodHRwczovL2ppcmEuYmV0d2FyZS5jb20vYnJvd3NlL0JXSU1EQ0QtMzcx";

        if (environment.equals("Preprod")) {
            auth =
                    "YmV0d2FyZTpHLV9uT1kwdmZaSnhDdWt5dC1feVNvcHBMQWd1TmhVNHV4MUMzaWJLWm5ZbXFQUlFUVWpjOFJvbQ==";
        }
        String basic_auth = "Basic " + auth;
        AccessServiceData accessServiceData = new AccessServiceData();

        requestBody = accessServiceData.addLoginApiData();
        AccessServiceResources accessServiceAPI = AccessServiceResources.valueOf("LoginApi");
        String resourceValue = accessServiceAPI.getResource();

        {
            Response response =
                    given()
                            .config(redirectWithCookiesConfig)
                            .log()
                            .all()
                            .relaxedHTTPSValidation()
                            .redirects()
                            .follow(true)
                            .redirects()
                            .allowCircular(true)
                            .contentType(ContentType.JSON)
                            .body(requestBody)
                            .header("Host", host)
                            .header("Accept-Encoding", encoding)
                            .header("Authorization", basic_auth)
                            .when()
                            .post("https://" + host + resourceValue)
                            .then()
                            .extract()
                            .response();

            JsonPath jsonPathEvaluator = response.jsonPath();
            apiToken = jsonPathEvaluator.get("access_token");

            showStatusCodeAndResponse(response.getStatusCode(), response.asPrettyString());
            Assertions.assertEquals(200, response.statusCode());
        }
    }

    /**
     * Login for api calls but with intralot auth header.
     */
    protected void loginIntralotToken() {
        System.out.println("#### Starting with LoginIntralot");
        String encoding = "gzip, deflate, br";

        String auth = "SUxPVDpodHRwczovL2ppcmEuYmV0d2FyZS5jb20vYnJvd3NlL0JXSU1EQ0QtMzcx";
        if (environment.equals("Preprod")) {
            auth = "SUxPVDpodHRwczovL2Rldi1qaXJhLmRldmVsb3BtZW50LmRjLm9wYXAvYnJvd3NlL0pBTi00Mzk=";
        }
        String basic_auth = "Basic " + auth;
        AccessServiceData accessServiceData = new AccessServiceData();

        requestBody = accessServiceData.addLoginApiData();
        AccessServiceResources accessServiceAPI = AccessServiceResources.valueOf("LoginApi");
        String resourceValue = accessServiceAPI.getResource();

        {
            Response response =
                    given()
                            .config(redirectWithCookiesConfig)
                            .log()
                            .all()
                            .relaxedHTTPSValidation()
                            .redirects()
                            .follow(true)
                            .redirects()
                            .allowCircular(true)
                            .contentType(ContentType.JSON)
                            .body(requestBody)
                            .header("Host", host)
                            .header("Accept-Encoding", encoding)
                            .header("Authorization", basic_auth)
                            .when()
                            .post("https://" + host + resourceValue)
                            .then()
                            .extract()
                            .response();

            JsonPath jsonPathEvaluator = response.jsonPath();
            intralotToken = jsonPathEvaluator.get("access_token");

            showStatusCodeAndResponse(response.getStatusCode(), response.asPrettyString());
            Assertions.assertEquals(200, response.statusCode());
        }
    }

    /**
     * Login to back office.
     */
    public void loginBackOffice() {
        {
            AccessServiceResources accessServiceAPI = AccessServiceResources.valueOf("LoginBackOffice");
            String resourceValue = accessServiceAPI.getResource();
            String encoding = "gzip, deflate, br";

            AccessServiceData accessServiceData = new AccessServiceData();
            if (isTestLoginCC) {
                requestBody = accessServiceData.addLoginBackOfficeData(ccUsername, "test");
            } else {
                requestBody = accessServiceData.addLoginBackOfficeData(ccUsername, ccPassword);
            }
            // Call Options
            Response response1 =
                    given()
                            .config(redirectWithCookiesConfig)
                            .log()
                            .all()
                            .relaxedHTTPSValidation()
                            .redirects()
                            .follow(true)
                            .redirects()
                            .allowCircular(true)
                            .contentType(ContentType.JSON)
                            .header("Host", ccHost)
                            .header("Accept-Encoding", encoding)
                            .header("Origin", "https://" + ccHost)
                            .body(requestBody)
                            .when()
                            .request("OPTIONS", "https://" + ccHost + resourceValue)
                            .then()
                            .extract()
                            .response();

            showAllCookiesAndPrintResponse(
                    response1.getDetailedCookies(), response1.getStatusCode(), response1.asPrettyString());
            Assertions.assertEquals(200, response1.statusCode(), "Wrong status code returned");

            if (response1.getCookie("csrftoken") != null) {
                ccCsrftoken = response1.getCookie("csrftoken");
            } else {
                List<org.apache.http.cookie.Cookie> listofCookies = cookieStore.getCookies();
                for (org.apache.http.cookie.Cookie cookie : listofCookies) {
                    if (cookie != null && cookie.getName().equals("csrftoken")) {
                        ccCsrftoken = cookie.getValue();
                        break;
                    }
                }
            }

            // Call BackOffice Login
            Response response =
                    given()
                            .config(redirectWithCookiesConfig)
                            .log()
                            .all()
                            .relaxedHTTPSValidation()
                            .redirects()
                            .follow(true)
                            .redirects()
                            .allowCircular(true)
                            .contentType(ContentType.JSON)
                            .header("Host", ccHost)
                            .header("Accept-Encoding", encoding)
                            .header("x-csrftoken", ccCsrftoken)
                            .header("Origin", "https://" + ccHost)
                            .body(requestBody)
                            .when()
                            .post("https://" + ccHost + resourceValue)
                            .then()
                            .extract()
                            .response();
            if (isTestLoginCC) {
                showAllCookiesAndPrintResponse(
                        response.getDetailedCookies(), response.getStatusCode(), response.asPrettyString());
                Assertions.assertEquals(400, response.statusCode(), "Wrong status code returned");
            } else {
                showAllCookiesAndPrintResponse(
                        response.getDetailedCookies(), response.getStatusCode(), response.asPrettyString());
                Assertions.assertEquals(204, response.statusCode(), "Wrong status code returned");
            }
        }
    }

    /**
     * Limit oidc check. Mostly needed for old login.
     */
    protected static void limitOidcCheck() {
        {
            Response response =
                    given()
                            .config(redirectWithCookiesConfig)
                            .log()
                            .all()
                            .relaxedHTTPSValidation()
                            .redirects()
                            .follow(true)
                            .redirects()
                            .allowCircular(true)
                            .contentType("application/json")
                            .header("Host", host)
                            .header("Accept-Encoding", "gzip, deflate, br")
                            .header("x-csrftoken", csrftoken)
                            .header("X-GAME-ID", gameId)
                            .when()
                            .get("https://" + host + "/web/limit/oidc/check")
                            .then()
                            .extract()
                            .response();

            showAllCookiesAndPrintResponse(
                    response.getDetailedCookies(), response.getStatusCode(), response.asPrettyString());
            Assertions.assertEquals(200, response.statusCode());
        }
    }

    /**
     * Wallet oidc check. Mostly needed for old login.
     */
    protected static void walletOidcCheck() {
        {
            Response response =
                    given()
                            .config(redirectWithCookiesConfig)
                            .log()
                            .all()
                            .relaxedHTTPSValidation()
                            .redirects()
                            .follow(true)
                            .redirects()
                            .allowCircular(true)
                            .contentType("application/json")
                            .header("Host", host)
                            .header("Accept-Encoding", "gzip, deflate, br")
                            .header("x-csrftoken", csrftoken)
                            .when()
                            .get("https://" + host + "/web/wallet/oidc/check?source=provider")
                            .then()
                            .extract()
                            .response();

            showAllCookiesAndPrintResponse(
                    response.getDetailedCookies(), response.getStatusCode(), response.asPrettyString());
            Assertions.assertEquals(200, response.statusCode());
        }
    }

    /**
     * Tora oidc check. Mostly needed for old login.
     */
    protected static void toraOidcCheck() {
        {
            Response response =
                    given()
                            .config(redirectWithCookiesConfig)
                            .log()
                            .all()
                            .relaxedHTTPSValidation()
                            .redirects()
                            .follow(true)
                            .redirects()
                            .allowCircular(true)
                            .contentType("application/json")
                            .header("Host", host)
                            .header("Accept-Encoding", "gzip, deflate, br")
                            .header("x-csrftoken", csrftoken)
                            .when()
                            .get("https://" + host + "/web/tora/oidc/check")
                            .then()
                            .extract()
                            .response();

            showAllCookiesAndPrintResponse(
                    response.getDetailedCookies(), response.getStatusCode(), response.asPrettyString());
            Assertions.assertEquals(200, response.statusCode());
        }
    }

    /**
     * Cookie setup.
     */
    protected static void cookieSetup() {
        System.out.println("#### Starting Cookie Setup");
        cookieStore = new BasicCookieStore();
        httpClientFactory =
                () -> {
                    DefaultHttpClient httpClient = new DefaultHttpClient();
                    httpClient.setCookieStore(cookieStore);
                    return httpClient;
                };
        redirectWithCookiesConfig =
                RestAssuredConfig.newConfig()
                        .httpClient(
                                HttpClientConfig.httpClientConfig()
                                        .httpClientFactory(httpClientFactory)
                                        .setParam(COOKIE_POLICY, BROWSER_COMPATIBILITY));
        System.out.println("#### Done with Cookie Setup");
    }

    /**
     * Prints the cookies that just taken from a call and print the response. Used for debugging.
     *
     * @param detailedCookies the cookies that returned from the call.
     * @param statusCode      status code of response.
     * @param response        the response of the call
     */
    protected static void showAllCookiesAndPrintResponse(
            Cookies detailedCookies, int statusCode, String response) {
        showIncomingCookies(detailedCookies);
        showCookies(cookieStore.getCookies());
        showStatusCodeAndResponse(statusCode, response);
    }

    /**
     * Prints the status code and the response of some call. Used in login methods.
     *
     * @param statusCode the status code of the response
     * @param response   the whole response of the call.
     */
    private static void showStatusCodeAndResponse(int statusCode, String response) {
        System.out.println(String.format("Response ==> %d %s", statusCode, response));
    }

    /**
     * Prints the cookies that just taken from a call in detail. Used for debugging.
     *
     * @param detailedCookies the cookies that returned from the call.
     */
    private static void showIncomingCookies(Cookies detailedCookies) {
        List<Cookie> cookies = detailedCookies.asList();
        System.out.println(String.format("*** Cookies in response => %d", cookies.size()));
        for (Cookie cookie : cookies) {
            System.out.println(String.format("**** Cookie in response: %s", cookie));
        }
    }

    /**
     * Prints the cookies that just are stored in cookie store in detail. Used for debugging.
     *
     * @param cookies the cookies that have been stored in cookie store.
     */
    private static void showCookies(List<org.apache.http.cookie.Cookie> cookies) {
        System.out.println(String.format("||| Cookies in store => %d", cookies.size()));
        for (org.apache.http.cookie.Cookie cookie : cookies) {
            System.out.println(String.format("|||| Cookie in store: %s", cookie));
        }
    }

    /**
     * Calculates random value array list. Used in placeWager to mock false quickpick.
     *
     * @param arrayList the array list
     * @return the array list
     */
    protected static ArrayList<Integer> calculateRandomValue(ArrayList<Integer> arrayList) {
        int maxMain = 45;
        int minMain = 1;
        int tempValue1;
        int tempValue2 = -1;

        for (int i = 0; i < 5; i++) {
            tempValue1 = (int) Math.floor(Math.random() * (maxMain - minMain + 1) + minMain);
            if (tempValue1 != tempValue2) {
                arrayList.add(tempValue1);
            } else {
                tempValue2 = tempValue1;
                continue;
            }
            tempValue2 = tempValue1;
        }
        return arrayList;
    }

    /**
     * Adds delay in seconds.
     *
     * @param seconds the seconds
     */
    protected static void AddDelayInSeconds(int seconds) {
        int duration = seconds * 1000;
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Calculates new referenceId in request if genericRetryMechanism is activated
     */
    private static void playBetFundsNewReferenceId(Utils utils) {
        PlayBetFunds playBetFunds = (PlayBetFunds) requestBody;
        Utils.referenceId2 = String.valueOf(utils.calculateRandomInteger(100000000, 999999999));
        playBetFunds.setReferenceId(Utils.referenceId2);
        requestBody = playBetFunds;
    }

    /**
     * Retry mechanism with 3 seconds delay. It is used in between calls.
     *
     * @param methodType     the method type
     * @param url            the url
     * @param statusCodeList the status code list
     * @param maxRetries     the max retries
     */
    protected static void retryMechanism(
            String methodType, String url, List<String> statusCodeList, int maxRetries) {
        retryMechanism(methodType, url, statusCodeList, maxRetries, 3);
    }

    /**
     * Retry mechanism with dynamically seconds delay.
     *
     * @param methodType     the method type
     * @param url            the url
     * @param statusCodeList the status code list
     * @param maxRetries     the max retries
     * @param delayInSeconds the delay in seconds
     */
    protected static void retryMechanism(
            String methodType,
            String url,
            List<String> statusCodeList,
            int maxRetries,
            int delayInSeconds) {
        int retry = 0;
        int statusCode = response.getStatusCode();

        for (int i = 0; i < maxRetries; i++) {
            if (statusCodeList.contains(Integer.toString(statusCode))) {
                retry++;
                AddDelayInSeconds(delayInSeconds);
                recalculateRequestBodyAndRes(methodType);

                if (methodType.equalsIgnoreCase("POST")) {
                    System.out.println("Method POST with wrong status code. Starting Retry #" + retry);
                    response = res.when().post(url);
                } else if (methodType.equalsIgnoreCase("GET")) {
                    System.out.println("Method GET with wrong status code. Starting Retry " + retry);
                    response = res.when().get(url);
                } else if (methodType.equalsIgnoreCase("PUT")) {
                    System.out.println("Method PUT with wrong status code. Starting Retry " + retry);
                    response = res.when().put(url);
                } else if (methodType.equalsIgnoreCase("DEL")) {
                    System.out.println("Method DEL with wrong status code. Starting Retry " + retry);
                    response = res.when().delete(url);
                }
                System.out.println("Previous Status Code: " + statusCode);
                statusCode = response.getStatusCode();
                System.out.println("New Status Code: " + statusCode);
            } else {
                System.out.println("Retry :#" + retry + " was successful");
                break;
            }
            System.out.println(response.asPrettyString());
        }
    }

    /**
     * Recalculates requestBody and res variable (currently for specific methods)
     */
    protected static void recalculateRequestBodyAndRes(String methodType) {

        Utils utils = new Utils();

        // Should be generic but not easy cause of different requests. So switch case..
        switch (retryResource) {
            case "PlayBetFunds":
                playBetFundsNewReferenceId(utils);
                break;
            case "CaptureBet":
                captureBetnewBatchSubBatchId(utils);
                break;
            case "CancelReservation":
                cancelReservationNewBatchId(utils);
                break;
            default:
                break;
        }

        // Request Specification logic for building request (PUT, POST changes only)
        if (methodType.equalsIgnoreCase("POST") || methodType.equalsIgnoreCase("PUT")) {
            if (utils.endPointParams.isEmpty()) {
                res =
                        given()
                                .spec(utils.requestSpecWithHeadersSpecification(specString))
                                .body(requestBody)
                                .relaxedHTTPSValidation();
            } else {
                res =
                        given()
                                .spec(utils.requestSpecWithHeadersSpecification(specString))
                                .body(requestBody)
                                .queryParams(utils.endPointParams)
                                .relaxedHTTPSValidation();
            }
        } else if (!methodType.equalsIgnoreCase("GET") && !methodType.equalsIgnoreCase("DEL")) {
            System.out.println("Method" + methodType + "not supported yet");
        }
    }

    /**
     * Calculates new Batch id for retry purposes - Cancel Reservation
     */
    private static void cancelReservationNewBatchId(Utils utils) {
        CancelReservation cancelReservation = (CancelReservation) requestBody;
        Utils.batchId = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));
        cancelReservation.setBatchId(Utils.batchId);
        requestBody = cancelReservation;
    }

    /**
     * Calculates new Batch Subbatch id for retry purposes - Capture Bet
     */
    private static void captureBetnewBatchSubBatchId(Utils utils) {
        CaptureBet captureBet = (CaptureBet) requestBody;
        Utils.batchId = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));
        Utils.subBatchId = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));
        captureBet.setBatchId(Utils.batchId);
        captureBet.setSubBatchId(Utils.subBatchId);
        requestBody = captureBet;
    }

    /**
     * A custom retry mechanism that calls either the retryMechanism or retryMechanismAndCheckField
     * depending on different case.
     *
     * @param method              the method type (GET/POST/PUT/DEL)
     * @param responseStatusCode  the response status code from the first failed call.
     * @param arrayName           the array of the response. If it's not an array it's empty "".
     * @param maxRetries          the max retries to stop
     * @param delayInSeconds      the delay in seconds between each call
     * @param retryStatusCode     the code to expect to keep retrying
     * @param responseField       the field to check for some value
     * @param responseFieldValues the values to check the field. Can be one or multiple.
     */
    protected static void customRetryMechanism(
            String method,
            Integer responseStatusCode,
            String arrayName,
            int maxRetries,
            int delayInSeconds,
            int retryStatusCode,
            String responseField,
            List<String> responseFieldValues) {

        JsonPath js = new JsonPath(response.asString());
        String[] statCodes = new String[]{String.valueOf(retryStatusCode)};
        List<String> statCodeList = Arrays.asList(statCodes);

        // depends on responseField value && arrayName value
        if (!responseField.isBlank() && responseStatusCode == retryStatusCode) {

            // for non arrays responses
            if (arrayName.isBlank()) {
                retryMechanismAndCheckField(
                        method,
                        endpointUrl,
                        statCodeList,
                        maxRetries,
                        delayInSeconds,
                        responseField,
                        responseFieldValues);
            } else {
                int count = js.getInt(arrayName + ".size()");
                if (count < 1) {
                    retryMechanismAndCheckField(
                            method,
                            endpointUrl,
                            statCodeList,
                            maxRetries,
                            delayInSeconds,
                            responseField,
                            responseFieldValues);
                }
            }
        } else {
            // for non arrays responses
            if ((arrayName.isBlank()) && responseStatusCode == retryStatusCode) {
                retryMechanism(method, endpointUrl, statCodeList, maxRetries, delayInSeconds);

                // for array responses
            } else {
                int count = js.getInt(arrayName + ".size()");

                if (count < 1 && responseStatusCode == retryStatusCode) {
                    retryMechanism(method, endpointUrl, statCodeList, maxRetries, delayInSeconds);
                }
            }
        }
    }

    /**
     * Retry mechanism that also checks some field for accepted value/values.
     *
     * @param methodType     the method type (GET/POST/PUT/DEL)
     * @param url            the endpoint
     * @param statusCodeList the codes we are expecting as to keep retrying
     * @param maxRetries     the max retries to stop
     * @param delayInSeconds the delay in seconds between each call
     * @param fieldToCheck   the field to check for some value
     * @param fieldValues    the values to check the field. Can be one or multiple.
     */
    protected static void retryMechanismAndCheckField(
            String methodType,
            String url,
            List<String> statusCodeList,
            int maxRetries,
            int delayInSeconds,
            String fieldToCheck,
            List<String> fieldValues) {

        int retry = 0;
        int statusCode = response.getStatusCode();
        JsonPath js;
        String fieldValue = "";

        for (int i = 0; i < maxRetries; i++) {
            if (statusCodeList.contains(Integer.toString(statusCode))) {
                for (int j = 0; j < fieldValues.size(); j++) {
                    if (fieldValue.equalsIgnoreCase(fieldValues.get(j))) {
                        System.out.println(
                                "Retry :#" + retry + " was successful Value: " + fieldValue + " found");
                        return;
                    }
                }
                retry++;
                AddDelayInSeconds(delayInSeconds);
                if (methodType.equalsIgnoreCase("POST")) {
                    System.out.println(
                            "Method POST with wrong value in field "
                                    + fieldToCheck
                                    + ". Starting Retry #"
                                    + retry);
                    response = res.when().post(url);
                } else if (methodType.equalsIgnoreCase("GET")) {
                    System.out.println(
                            "Method GET with wrong value in field "
                                    + fieldToCheck
                                    + ". Starting Retry #"
                                    + retry);
                    response = res.when().get(url);
                } else if (methodType.equalsIgnoreCase("PUT")) {
                    System.out.println(
                            "Method PUT with wrong value in field "
                                    + fieldToCheck
                                    + ". Starting Retry #"
                                    + retry);
                    response = res.when().put(url);
                } else if (methodType.equalsIgnoreCase("DEL")) {
                    System.out.println(
                            "Method DEL with wrong value in field "
                                    + fieldToCheck
                                    + ". Starting Retry #"
                                    + retry);
                    response = res.when().delete(url);
                }
                System.out.println("Expecting one of values below: " + fieldValues);
                System.out.println("Previous Status Code: " + statusCode);
                statusCode = response.getStatusCode();
                js = new JsonPath(response.asString()); // here
                fieldValue = js.get(fieldToCheck);
                System.out.println("New Status Code: " + statusCode);
                System.out.println("New value: " + fieldValue);
            } else {
                System.out.println("Retry :#" + retry + " was successful");
                break;
            }
            System.out.println(response.asPrettyString());
        }
    }

    /**
     * Relogin mechanism. This is mostly useful if the token expires.
     *
     * @param methodType     the method type
     * @param url            the url
     * @param statusCodeList the status code list
     * @param maxRetries     the max retries
     * @param response       the response
     */
    protected void reloginMechanism(
            String methodType,
            String url,
            List<String> statusCodeList,
            int maxRetries,
            Response response) {
        int statusCode = response.getStatusCode();
        String responseString = response.asString();
        CommonStepDefinitions commonSteps = new CommonStepDefinitions();

        if (statusCodeList.contains(Integer.toString(statusCode))) {
            if (url.contains("/web")
                    && (responseString.contains("invalid_token")
                    || responseString.contains("AUTHENTICATION_REQUIRED"))) {
                System.out.println("Invalid Token");
                commonSteps.loginWebFlow();
            } else if (url.contains("/cc")
                    && (responseString.contains("login_required")
                    || responseString.contains(("AUTHENTICATION_REQUIRED"))
                    || responseString.contains("Access not allowed"))) {
                commonSteps.loginBackOffice();
            } else if (url.contains("/api")
                    && (responseString.contains("invalid_token")
                    || responseString.contains("AUTHENTICATION_REQUIRED"))) {
                commonSteps.loginAPI();
            }
            if (methodType.equalsIgnoreCase("GET") || methodType.equalsIgnoreCase("DEL")) {
                if (endPointParams.isEmpty()) {
                    res = given().spec(requestSpecWithHeadersSpecification(specString));
                } else {
                    res =
                            given()
                                    .spec(requestSpecWithHeadersSpecification(specString))
                                    .queryParams(endPointParams);
                }
            } else if (methodType.equalsIgnoreCase("POST") || methodType.equalsIgnoreCase("PUT")) {
                if (endPointParams.isEmpty()) {
                    res = given().spec(requestSpecWithHeadersSpecification(specString)).body(requestBody);
                } else {
                    res =
                            given()
                                    .spec(requestSpecWithHeadersSpecification(specString))
                                    .queryParams(endPointParams);
                }
            } else {
                System.out.println("Method" + methodType + "not supported yet");
            }
            retryMechanism(methodType, url, statusCodeList, maxRetries);
        }
        endPointParams = new HashMap<>(); // initialize everytime if it has value
    }

    /**
     * Creates endPointParams given in get header common step.
     *
     * @param keys   the keys
     * @param values the values
     */
    protected void split2StringsAndAddToDict(String keys, String values) {
        endPointParams = new HashMap<>(); // initialize everytime if it has value

        if (keys.split(",").length > 1) {
            String[] keyArray = keys.split(",");
            String[] valueArray = values.split(",");

            for (int i = 0; i < keyArray.length; i++) {
                endPointParams.put(keyArray[i], valueArray[i]);
            }
        } else {
            endPointParams.put(keys, values);
        }
    }

    /**
     * Calculates new param values. Used in get header to change the playerId and date in query
     * Params.
     *
     * @param keys   the keys
     * @param values the values
     * @return the string
     */
    protected String calculateNewParamValues(String keys, String values) {
        String[] keyArray = keys.split(",");
        String[] valueArray = values.split(",");

        for (int i = 0; i < keyArray.length; i++) {
            if (keyArray[i].contains("playerId")
                    || keyArray[i].contains("ownerId")
                    || keyArray[i].contains("customerId")) {
                valueArray[i] = playerId;
            } else if (keyArray[i].contains("userId")
                    || keyArray[i].contains("memberId")
                    || keyArray[i].contains("updatedByUserId")) {
                String[] splitted = valueArray[i].split("-");
                if (splitted.length > 1) {
                    valueArray[i] = splitted[0] + "-" + playerId;
                } else {
                    valueArray[i] = "1-" + playerId;
                }
            } else if (keyArray[i].contains("GrandPrize")) {
                valueArray[i] = ownerIdGrandPrize;
            } else if (keyArray[i].contains("dateFrom")
                    || keyArray[i].contains("dateTo")
                    || keyArray[i].contains("fromBought")
                    || keyArray[i].contains("toBought")
                    || keyArray[i].contains("startDate")
                    || keyArray[i].contains("endDate")
                    || keyArray[i].contains("fromDate")
                    || keyArray[i].contains("toDate")) {

                if (valueArray[i].contains("seconds")) {
                    valueArray[i] = calculateDateNowInSecondsWithoutPlusTime();
                } else if (valueArray[i].contains("datenow")) {
                    valueArray[i] = calculateDateNowToString();
                }
            }
            if (i == 0) {
                values = valueArray[0];
            }
            if (i > 0) {
                values = values + "," + valueArray[i];
            }
        }
        return values;
    }

    protected String calculateParamValues(String keys, String values) {
        String[] keyArray = keys.split(",");
        String[] valueArray = values.split(",");

        for (int i = 0; i < keyArray.length; i++) {
            if (keyArray[i].contains("userId") || keyArray[i].contains("updatedByUserId")) {
                valueArray[i] = "102-" + friendsAndFamilyGroupId;
            }
            if (i == 0) {
                values = valueArray[0];
            }
            if (i > 0) {
                values = values + "," + valueArray[i];
            }
        }
        return values;
    }

    protected String calculateGrandPrizeValues(String keys, String values) {
        String[] keyArray = keys.split(",");
        String[] valueArray = values.split(",");

        for (int i = 0; i < keyArray.length; i++) {
            if (keyArray[i].contains("customerId")) {
                valueArray[i] = playerId;
            }
            if (i == 0) {
                values = valueArray[0];
            }
            if (i > 0) {
                values = values + "," + valueArray[i];
            }
        }
        return values;
    }

    protected String calculatePageNumberValues(String keys, String values) {
        String[] keyArray = keys.split(",");
        String[] valueArray = values.split(",");

        for (int i = 0; i < keyArray.length; i++) {
            if (keyArray[i].contains("pagenumber")) {
                valueArray[i] = calculateDateNowToString();
            }
            if (i == 0) {
                values = valueArray[0];
            }
            if (i > 0) {
                values = values + "," + valueArray[i];
            }
        }
        return values;
    }

    /**
     * Calculates random integer with lower and upper bound.
     *
     * @param lowerBound the lower bound
     * @param upperBound the upper bound
     * @return the int
     */
    public int calculateRandomInteger(int lowerBound, int upperBound) {
        Random rand = new Random();
        int random_integer = rand.nextInt(upperBound - lowerBound) + lowerBound;
        return random_integer;
    }

    /**
     * Calculates random alphanumeric
     *
     * @param length     length of string
     * @param useLetters if we need letters or not
     * @param useNumbers if we need numbers or not
     * @return the string
     */
    public String calculateRandomString(int length, boolean useLetters, boolean useNumbers) {
        return RandomStringUtils.random(length, useLetters, useNumbers);
    }

    /**
     * Calculates today's date. Used only when this format is needed 2023-12-19 without
     * minutes/seconds.
     *
     * @return the current date in YYYY-MM-DD format.
     */
    public String calculateDateNowToString() {
        String todaysDate = String.valueOf(java.time.LocalDate.now());
        System.out.println(todaysDate);
        return todaysDate;
    }

    /**
     * Calculates today's date with the format YYYY-MM-DDTHH:mm:ss+02:00 e.g 2023-12-19T13:04:26+02:00
     *
     * @return the current date in YYYY-MM-DDTHH:mm:ss+03:00 or +02:00 format depending on season in
     * Athens
     */
    public String calculateDateNowInSecondsToString() {
        ZoneId athensZoneId = ZoneId.of("Europe/Athens");
        LocalDateTime ldtAthens = LocalDateTime.now(athensZoneId);
        String zdtAthens = ldtAthens.atZone(athensZoneId).toString();
        int plusTimeIndex = zdtAthens.indexOf("+");
        String plusTime = zdtAthens.substring(plusTimeIndex, zdtAthens.indexOf("["));
        int milliIndex = zdtAthens.indexOf('.');
        String result = zdtAthens.substring(0, milliIndex) + plusTime;
        return result;
    }

    /**
     * Calculates today's date with the format YYYY-MM-DDTHH:mm:ssZ e.g 2023-12-19T13:04:26Z
     *
     * @return the current date in YYYY-MM-DDTHH:mm:ssZ
     */
    public String calculateDateNowInSecondsWithoutPlusTime() {
        ZoneId athensZoneId = ZoneId.of("Europe/Athens");
        LocalDateTime ldtAthens = LocalDateTime.now(athensZoneId);
        String zdtAthens = ldtAthens.atZone(athensZoneId).toString();
        int milliIndex = zdtAthens.indexOf('.');
        String result = zdtAthens.substring(0, milliIndex) + "Z";
        return result;
    }

    /**
     * Login web flow logic.
     */
    protected void loginWebFlow() {
        if (isAccessToken) {
            loginNew();
        } else {
            loginOld();
            limitOidcCheck();
            walletOidcCheck();
            toraOidcCheck();
        }
    }

    /**
     * Calculates the endpoint of the given service and resource.
     *
     * @param service  the service
     * @param resource the resource
     * @return the string
     */
    public String calculateEndpointUrl(String service, String resource) {
        String url = "";
        switch (service) {
            case "AccessService":
                AccessServiceResources accessServiceAPI = AccessServiceResources.valueOf(resource);
                url = accessServiceAPI.getResource();
                break;
            case "AdminService":
                AdminServiceResources adminServiceAPI = AdminServiceResources.valueOf(resource);
                url = adminServiceAPI.getResource();
                break;
            case "ApplePayService":
                ApplePayServiceResources appleServiceAPI = ApplePayServiceResources.valueOf(resource);
                url = appleServiceAPI.getResource();
                break;
            case "BalanceService":
                BalanceServiceResources balanceServiceAPI = BalanceServiceResources.valueOf(resource);
                url = balanceServiceAPI.getResource();
                break;
            case "BonusService":
                BonusServiceResources bonusServiceAPI = BonusServiceResources.valueOf(resource);
                url = bonusServiceAPI.getResource();
                break;
            case "CommunicationService":
                CommunicationServiceResources communicationServiceAPI =
                        CommunicationServiceResources.valueOf(resource);
                url = communicationServiceAPI.getResource();
                break;
            case "DrawService":
                DrawServiceResources drawServiceAPI = DrawServiceResources.valueOf(resource);
                url = drawServiceAPI.getResource();
                break;
            case "LimitService":
                LimitServiceResources limitServiceAPI = LimitServiceResources.valueOf(resource);
                url = limitServiceAPI.getResource();
                break;
            case "PlayerService":
                PlayerServiceResources playerServiceAPI = PlayerServiceResources.valueOf(resource);
                url = playerServiceAPI.getResource();
                break;
            case "PromotionService":
                PromotionServiceResources promotionServiceAPI = PromotionServiceResources.valueOf(resource);
                url = promotionServiceAPI.getResource();
                break;
            case "SubscriptionService":
                SubscriptionServiceResources subscriptionServiceAPI =
                        SubscriptionServiceResources.valueOf(resource);
                url = subscriptionServiceAPI.getResource();
                break;
            case "WagerService":
                WagerServiceResources wagerServiceAPI = WagerServiceResources.valueOf(resource);
                url = wagerServiceAPI.getResource();
                break;
            case "WalletService":
                WalletServiceResources walletServiceResources = WalletServiceResources.valueOf(resource);
                url = walletServiceResources.getResource();
                break;
            case "WitService":
                WitServiceResources witServiceResources = WitServiceResources.valueOf(resource);
                url = witServiceResources.getResource();
                break;
            case "WiremockService":
                WiremockServiceResources wiremockServiceResources =
                        WiremockServiceResources.valueOf(resource);
                url = wiremockServiceResources.getResource();
                break;
            case "DrillHostService":
                DrillHostServiceResources drillHostServiceResources =
                        DrillHostServiceResources.valueOf(resource);
                url = drillHostServiceResources.getResource();
                break;
            case "DatabaseBridgeService":
                DatabaseBridgeServiceResources databaseBridgeServiceResources =
                        DatabaseBridgeServiceResources.valueOf(resource);
                url = databaseBridgeServiceResources.getResource();
                break;
            case "RabbitMQService":
                RabbitMQServiceResources rabbitMQServiceResources =
                        RabbitMQServiceResources.valueOf(resource);
                url = rabbitMQServiceResources.getResource();
                break;
            default:
                Assertions.fail("Testing code is not implemented for service: " + service);
                break;
        }
        System.out.println("About to call: " + url);
        return url;
    }

    /**
     * Sets resource by service.
     *
     * @param service       the service
     * @param resourceName  the resource name
     * @param resourceValue the resource value
     */
    public void setResourceByService(String service, String resourceName, String resourceValue) {
        switch (service) {
            case "AccessService":
                AccessServiceResources accessServiceAPI = AccessServiceResources.valueOf(resourceName);
                accessServiceAPI.setResource(resourceValue);
                break;
            case "AdminService":
                AdminServiceResources adminServiceAPI = AdminServiceResources.valueOf(resourceName);
                adminServiceAPI.setResource(resourceValue);
                break;
            case "ApplePayService":
                ApplePayServiceResources appleServiceAPI = ApplePayServiceResources.valueOf(resourceName);
                appleServiceAPI.setResource(resourceValue);
                break;
            case "BalanceService":
                BalanceServiceResources balanceServiceAPI = BalanceServiceResources.valueOf(resourceName);
                balanceServiceAPI.setResource(resourceValue);
                break;
            case "BonusService":
                BonusServiceResources bonusServiceAPI = BonusServiceResources.valueOf(resourceName);
                bonusServiceAPI.setResource(resourceValue);
                break;
            case "CommunicationService":
                CommunicationServiceResources communicationServiceAPI =
                        CommunicationServiceResources.valueOf(resourceName);
                communicationServiceAPI.setResource(resourceValue);
                break;
            case "DrawService":
                DrawServiceResources drawServiceAPI = DrawServiceResources.valueOf(resourceName);
                drawServiceAPI.setResource(resourceValue);
                break;
            case "LimitService":
                LimitServiceResources limitServiceAPI = LimitServiceResources.valueOf(resourceName);
                limitServiceAPI.setResource(resourceValue);
                break;
            case "PlayerService":
                PlayerServiceResources playerServiceAPI = PlayerServiceResources.valueOf(resourceName);
                playerServiceAPI.setResource(resourceValue);
                break;
            case "PromotionService":
                PromotionServiceResources promotionServiceAPI =
                        PromotionServiceResources.valueOf(resourceName);
                promotionServiceAPI.setResource(resourceValue);
                break;
            case "SubscriptionService":
                SubscriptionServiceResources subscriptionServiceAPI =
                        SubscriptionServiceResources.valueOf(resourceName);
                subscriptionServiceAPI.setResource(resourceValue);
                break;
            case "WagerService":
                WagerServiceResources wagerServiceAPI = WagerServiceResources.valueOf(resourceName);
                wagerServiceAPI.setResource(resourceValue);
                break;
            case "WalletService":
                WalletServiceResources walletServiceResources =
                        WalletServiceResources.valueOf(resourceName);
                walletServiceResources.setResource(resourceValue);
                break;
            case "WitService":
                WitServiceResources witServiceResources = WitServiceResources.valueOf(resourceName);
                witServiceResources.setResource(resourceValue);
                break;
            case "WiremockService":
                WiremockServiceResources wiremockServiceResources =
                        WiremockServiceResources.valueOf(resourceName);
                wiremockServiceResources.setResource(resourceValue);
                break;
            case "RabbitMQService":
                RabbitMQServiceResources rabbitMQServiceResources =
                        RabbitMQServiceResources.valueOf(resourceName);
                rabbitMQServiceResources.setResource(resourceValue);
                break;
            default:
                Assertions.fail("Testing code is not implemented for service: " + service);
                break;
        }
    }

    /**
     * Generic Retry mechanism that is called in each method call.
     *
     * @param resource   the name of the resource to be retried.
     * @param method     the method type. GET/POST/PUT/DEL are the accepted values.
     * @param statusCode the response status code of the initial call.
     */
    public void genericRetryMechanism(String resource, String method, Integer statusCode) {
        String[] reloginStatusCodes = {"401", "403"};
        List<String> reloginStatusCodeList = Arrays.asList(reloginStatusCodes);

        // special case for OTP before registration
        if (resource.equals("VerifyOTP") && statusCode == 403) {
            csrftoken = response.getCookie("csrftoken");
        }
        // relogin Mechanism for 401,403 & invalid_token & retry once
        if (reloginStatusCodeList.contains(statusCode.toString()) && maxRetries > 0) {
            reloginMechanism(method, endpointUrl, reloginStatusCodeList, 1, response);
        }
        // retry Mechanism maxRetries for specific status Codes
        String[] statusCodes = {"500", "501", "502", "503", "504", "404"};
        List<String> statusCodeList = Arrays.asList(statusCodes);

        if (statusCodeList.contains(statusCode.toString()) && maxRetries > 0) {
            retryMechanism(method, endpointUrl, statusCodeList, maxRetries);
        }
    }

    /**
     * Prepares the parameters for the custom retry Mechanism. Some methods need other acceptance
     * criteria to stop the retry. This code can be expanded for other custom resources.
     *
     * @param resource the name of the resource to be retried.
     */
    public void populateRetryMechanism(String resource) {
        delayInSeconds = 0;
        retryStatusCode = 200;
        arrayName = "";
        customMaxRetries = 0;
        readyForRetry = false;
        responseField = "";
        responseFieldValues = new ArrayList<>() {
        };
        ArrayList<String> tempResponseFieldValues = new ArrayList<>() {
        };

        switch (resource) {
            case "GetMailIdForFetchHash":
                calculateRetryValues(2, "data", 10, 200, true);
                break;
            case "GetWalletBalance":
                calculateRetryValues(2, "js", 10, 200, true); // js = unnamed array
                break;
            case "CommitCardDepositToTora":
                //no status here.
                calculateRetryValues(4, "", 10, 202, true);
                break;
        }
    }

    /**
     * Internal call of populateRetryMechanism . Sets the global values related to parameters given
     *
     * @param maxRetries the number of retries of the given Method.
     * @param array      the name of the array of the response.
     * @param delay      the delay between the retries.
     * @param statusCode the expected status code for retry.
     * @param retry      set to true for the retry to happen.
     */
    protected void calculateRetryValues(
            int maxRetries, String array, int delay, int statusCode, boolean retry) {
        customMaxRetries = maxRetries;
        arrayName = array;
        delayInSeconds = delay;
        retryStatusCode = statusCode;
        readyForRetry = retry;
    }

    /**
     * Internal call of populateRetryMechanism . Sets the global values related to parameters given.
     * Extended of previous calculate by 2 params - fieldToCheck & values
     *
     * @param maxRetries   the number of retries of the given Method.
     * @param array        the name of the array of the response.
     * @param delay        the delay between the retries.
     * @param statusCode   the expected status code for retry.
     * @param retry        set to true for the retry to happen.
     * @param fieldToCheck response field to check for retry.
     * @param values       accepted values of field to stop retry.
     */
    protected void calculateRetryValues(
            int maxRetries,
            String array,
            int delay,
            int statusCode,
            boolean retry,
            String fieldToCheck,
            ArrayList<String> values) {
        customMaxRetries = maxRetries;
        arrayName = array;
        delayInSeconds = delay;
        retryStatusCode = statusCode;
        readyForRetry = retry;
        responseField = fieldToCheck;
        responseFieldValues = values;
    }

    protected void saveToken() {
        String tempToken = response.getCookie("csrftoken");
        if (endpointUrl.contains("/web") && tempToken != null) {
            csrftoken = tempToken;
        } else if (endpointUrl.contains("/cc") && tempToken != null) {
            ccCsrftoken = tempToken;
        }
    }

    /**
     * Edit Player Preferences internal calculation of request. Has been moved to utils cause it can
     * be called with different specification for api/web/cc methods.
     *
     * @param subcategories   request related
     * @param selected        request related
     * @param messageTypes    request related
     * @param categories      request related
     * @param preferenceTypes request related
     * @param specification   the specification for headers. Accepted Values are :
     *                        api_mainSpec_mainHost, cc_csrftokenSpec
     */
    protected void calculatePlayerPreferences(
            String subcategories,
            String selected,
            String messageTypes,
            String categories,
            String preferenceTypes,
            String specification) {

        String[] subCategoryList = subcategories.split(",");
        String[] selectedList = selected.split(",");
        String[] messageTypeList = messageTypes.split(",");
        String[] categoryList = categories.split(",");
        String[] preferenceTypeList = preferenceTypes.split(",");
        List<PlayerPreferences> finalList = new ArrayList<>();

        CommunicationServiceData communicationServiceData = new CommunicationServiceData();

        for (int i = 0; i < subCategoryList.length; i++) {
            PlayerPreferences playerPreferences =
                    communicationServiceData.setPlayerPreferences(
                            subCategoryList[i],
                            selectedList[i],
                            messageTypeList[i],
                            categoryList[i],
                            preferenceTypeList[i]);
            finalList.add(playerPreferences);
        }
        requestBody = finalList;
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }
}
