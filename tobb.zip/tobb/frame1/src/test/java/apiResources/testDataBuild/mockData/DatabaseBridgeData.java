package apiResources.testDataBuild.mockData;

import apiResources.Utils;

import static apiResources.DataContext.*;

public class DatabaseBridgeData {

  public String addDatabaseBridgeData(String query) throws Exception {
    if (query.contains("newContractId")) {
      if (drillContractId == null) {
        throw new Exception(
            "RestAssured: ContractId has not been pre-calculated with drillHost call");
      }
      query = query.replace("newContractId", drillContractId);
    }

    if (query.contains("newPlayerId")) {
      if (playerId == null) {
        throw new Exception("RestAssured: PlayerId has not been pre-calculated");
      }
      query = query.replace("newPlayerId", playerId);
    }

    // this is for sessionminutesId or any other 4 digit id

    if (query.contains("randomId")) {
      Utils utils = new Utils();
      String randomId = String.valueOf(utils.calculateRandomInteger(1000, 9999));
      query = query.replace("randomId", randomId);
    }

    if (query.contains("randomSessionId")) {
      Utils utils = new Utils();
      sessionId =
          "_"
              + utils.calculateRandomString(12, true, true)
              + "_"
              + utils.calculateRandomString(30, true, true);
      query = query.replace("randomSessionId", sessionId);
    }
    if (query.contains("calculatedSessionId")) {
      if (sessionId == null) {
        throw new Exception("RestAssured: SessionId has not been pre-calculated");
      }
      query = query.replace("calculatedSessionId", sessionId);
    }

    return "[" + "\"" + query + "\"" + "]";
  }
}
