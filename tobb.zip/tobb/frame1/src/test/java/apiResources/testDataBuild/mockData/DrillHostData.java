package apiResources.testDataBuild.mockData;

import apiResources.pojo.requests.drillHostService.DrillHost;

import static apiResources.DataContext.playerId;

public class DrillHostData {

  public DrillHost addDrillHostData(String queryType, String query) {
    if (query.contains("{{playerId}}") && playerId != null) {
      query = query.replace("{{playerId}}", playerId);
      System.out.println("PlayerId replaced with: " + playerId);
    }
    DrillHost drillhost = new DrillHost();
    drillhost.setQueryType(queryType);
    drillhost.setQuery(query);
    return drillhost;
  }
}
