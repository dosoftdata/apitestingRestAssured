package apiResources.testDataBuild;

public class SubscriptionServiceData {
}
