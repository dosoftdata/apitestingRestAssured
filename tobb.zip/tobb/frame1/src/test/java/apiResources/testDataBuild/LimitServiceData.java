package apiResources.testDataBuild;

import apiResources.pojo.requests.limitService.AddLimits;
import apiResources.pojo.requests.limitService.AddTimeLimits;
import apiResources.pojo.requests.limitService.Limits;

public class LimitServiceData {

  public AddLimits addLimits(String limitType, String period, String amount) {
    AddLimits limits = new AddLimits();
    AddLimits.Quantity quantity = new AddLimits.Quantity();

    quantity.setAmount(Integer.parseInt(amount));
    quantity.setCurrency("EUR");

    limits.setLimitType(limitType);
    limits.setPeriod(period);
    limits.setAmount(Integer.parseInt(amount));
    limits.setCurrency("EUR");
    limits.setQuantityType("MAX_AMOUNT");
    limits.setQuantity(quantity);

    return limits;
  }

  public Limits setMandatoryLimits(String limitType, String period, String amount, String gameId) {
    Limits limits = new Limits();
    Limits.Quantity quantity = new Limits.Quantity();
    Limits.Scope scope = new Limits.Scope();

    quantity.setAmount(Long.parseLong(amount));
    quantity.setCurrency("EUR");
    scope.setGameId(gameId);

    limits.setLimitType(limitType);
    limits.setPeriod(period);
    limits.setQuantityType("MAX_AMOUNT");
    limits.setQuantity(quantity);
    limits.setScope(scope);

    return limits;
  }

  public Limits SetMandatoryTimeLimits(
      String limitType, String period, String amount, String gameId) {
    Limits limits = new Limits();
    Limits.Quantity quantity = new Limits.Quantity();
    Limits.Scope scope = new Limits.Scope();

    quantity.setDurationInSeconds(Long.parseLong(amount));
    scope.setGameId(gameId);

    limits.setLimitType(limitType);
    limits.setPeriod(period);
    limits.setQuantityType("MAX_DURATION");
    limits.setQuantity(quantity);
    limits.setScope(scope);

    return limits;
  }

  public AddTimeLimits addTimeLimits(String limitType, String period, String amount) {
    AddTimeLimits limits = new AddTimeLimits();
    AddTimeLimits.Quantity quantity = new AddTimeLimits.Quantity();

    quantity.setDurationInSeconds(Integer.parseInt(amount));

    limits.setLimitType(limitType);
    limits.setPeriod(period);
    limits.setQuantityType("MAX_DURATION");
    limits.setQuantity(quantity);
    limits.setDurationInSeconds(Integer.parseInt(amount));

    return limits;
  }

  public String postDailyDepositLimits(String period, int amount, String limitType) {
    return "[\n"
        + "    {\n"
        + "        \"limitType\": \""
        + limitType
        + "\",\n"
        + "        \"period\": \""
        + period
        + "\",\n"
        + "        \"quantity\": {\n"
        + "            \"amount\": "
        + amount
        + ", \n"
        + "            \"currency\": \"EUR\"\n"
        + "        },\n"
        + "        \"amount\": "
        + amount
        + ", \n"
        + "        \"currency\": \"EUR\",\n"
        + "        \"quantityType\": \"MAX_AMOUNT\"\n"
        + "    }\n"
        + "]";
  }

  public String postTimeLimits(String period, int duration, String limitType) {
    return "[\n"
        + "    {\n"
        + "        \"limitType\": \""
        + limitType
        + "\",\n"
        + "        \"period\": \""
        + period
        + "\",\n"
        + "        \"quantity\": {\n"
        + "            \"durationInSeconds\": "
        + duration
        + "\n"
        + "        },\n"
        + "        \"durationInSeconds\": "
        + duration
        + ",\n"
        + "        \"quantityType\": \"MAX_DURATION\"\n"
        + "    }\n"
        + "]";
  }
}
