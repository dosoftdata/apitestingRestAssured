package apiResources.testDataBuild;

public class DrawServiceData {
}
