package apiResources.testDataBuild;

import apiResources.pojo.requests.applePayService.ApplePay;

public class ApplePayServiceData {

  public ApplePay addApplePayData(String currency, float amount, String sessionUrl) {
    ApplePay applePay = new ApplePay();
    applePay.setCurrency(currency);
    applePay.setAmount(amount);
    applePay.setSessionUrl(sessionUrl);
    return applePay;
  }
}
