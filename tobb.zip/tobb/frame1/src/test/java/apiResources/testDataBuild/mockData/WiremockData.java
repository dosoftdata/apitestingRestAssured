package apiResources.testDataBuild.mockData;

import apiResources.pojo.requests.wiremockService.AddAStub;

import static apiResources.DataContext.*;

public class WiremockData {
  public AddAStub addStubData(
      String scenarioName,
      String requiredScenarioState,
      String priority,
      String method,
      String url,
      String status,
      String body,
      String[] headers) {

    // For Testing purposes only
    /*
    playerId = "12345";
    paymentId = "123445555";
    cardFingerprint = "010";
    wiremockGuid=

     */

    // initial thought of replacing
    if (body.contains("{{playerId}}") && playerId != null) {
      body = body.replace("{{playerId}}", playerId);
      System.out.println("PlayerId replaced with: " + playerId);
    }
    if (body.contains("{{deposit_paymentId}}") && paymentId != null) {
      body = body.replace("{{deposit_paymentId}}", paymentId);
      System.out.println("PaymentId replaced with: " + paymentId);
    }
    if (body.contains("{{paymentIdViaPaymentCard}}") && paymentIdViaPaymentCard != null) {
      body = body.replace("{{paymentIdViaPaymentCard}}", paymentIdViaPaymentCard);
      System.out.println("PaymentId replaced with: " + paymentIdViaPaymentCard);
    }
    if (body.contains("{{Card1_fingerprint}}") && cardFingerprint != null) {
      body = body.replace("{{Card1_fingerprint}}", cardFingerprint);
      System.out.println("Card FingerPrint replaced with: " + cardFingerprint);
    }
    if (body.contains("{{guid}}") && wiremockGuid != null) {
      body = body.replace("{{guid}}", wiremockGuid);
      System.out.println("Guid replaced with: " + wiremockGuid);
    }
    if (body.contains("{{timestamp}}") && wiremockTimestamp != null) {
      body = body.replace("{{timestamp}}", wiremockTimestamp);
      System.out.println("Timestamp replaced with: " + wiremockTimestamp);
    }
    if (body.contains("{{wagerId}}") && wiremockWagerId != null) {
      body = body.replace("{{wagerId}}", wiremockWagerId);
      System.out.println("WagerId replaced with: " + wiremockWagerId);
    }
    if (body.contains("{{serialNumbers}}") && wiremockSerialNumbers != null) {
      body = body.replace("{{serialNumbers}}", wiremockSerialNumbers);
      System.out.println("SerialNumbers replaced with: " + wiremockSerialNumbers);
    }
    if (body.contains("{{creationTime}}") && wiremockCreationTime != null) {
      body = body.replace("{{creationTime}}", wiremockCreationTime);
      System.out.println("CreationTime replaced with: " + wiremockCreationTime);
    }
    if (body.contains("{{randomId}}") && randomId != null) {
      body = body.replace("{{randomId}}", randomId);
      System.out.println("randomId replaced with: " + randomId);
    }

    if (headers.length > 1) {
      if (headers[1].contains("{{guid}}")) {
        headers[1] = headers[1].replace("{{guid}}", wiremockGuid);
        System.out.println("Guid in headers replaced with: " + wiremockGuid);
      }
    }

    System.out.println(body);

    AddAStub addAStub = new AddAStub();
    addAStub.setScenarioName(scenarioName);
    addAStub.setRequiredScenarioState(requiredScenarioState);

    if (!priority.isEmpty() && !priority.isBlank()) {
      addAStub.setPriority(Integer.parseInt(priority));
    }

    // set request
    AddAStub.Request req = new AddAStub.Request();
    if (url.contains("*")) {
      req.setUrlPattern(url);
    } else {
      req.setUrl(url);
    }
    req.setMethod(method);
    addAStub.setRequest(req);

    // set response
    AddAStub.Response resp = new AddAStub.Response();
    resp.setStatus(Integer.parseInt(status));

    if (!body.isEmpty() && !body.isBlank()) {
      resp.setBody(body);
    }

    // set headers (Content-Type and GUID for now)
    AddAStub.headers headers1 = new AddAStub.headers();

    headers1.setContentType(headers[0]);

    if (headers.length > 1) {
      headers1.setGUID(headers[1]);
    }

    resp.setHeaders(headers1);
    addAStub.setResponse(resp);
    return addAStub;
  }

  public AddAStub addStubDataToken(
      String scenarioName,
      String requiredScenarioState,
      String priority,
      String method,
      String urlPattern,
      String status,
      String body,
      String[] headers) {

    // For Testing purposes only
    /*
    playerId = "12345";
    paymentId = "123445555";
    cardFingerprint = "010";
    wiremockGuid=

     */

    // initial thought of replacing
    if (body.contains("{{playerId}}") && playerId != null) {
      body = body.replace("{{playerId}}", playerId);
      System.out.println("PlayerId replaced with: " + playerId);
    }
    if (body.contains("{{deposit_paymentId}}") && paymentId != null) {
      body = body.replace("{{deposit_paymentId}}", paymentId);
      System.out.println("PaymentId replaced with: " + paymentId);
    }
    if (body.contains("{{paymentIdViaPaymentCard}}") && paymentIdViaPaymentCard != null) {
      body = body.replace("{{paymentIdViaPaymentCard}}", paymentIdViaPaymentCard);
      System.out.println("PaymentId replaced with: " + paymentIdViaPaymentCard);
    }
    if (body.contains("{{Card1_fingerprint}}") && cardFingerprint != null) {
      body = body.replace("{{Card1_fingerprint}}", cardFingerprint);
      System.out.println("Card FingerPrint replaced with: " + cardFingerprint);
    }
    if (body.contains("{{guid}}") && wiremockGuid != null) {
      body = body.replace("{{guid}}", wiremockGuid);
      System.out.println("Guid replaced with: " + wiremockGuid);
    }
    if (body.contains("{{timestamp}}") && wiremockTimestamp != null) {
      body = body.replace("{{timestamp}}", wiremockTimestamp);
      System.out.println("Timestamp replaced with: " + wiremockTimestamp);
    }
    if (body.contains("{{wagerId}}") && wiremockWagerId != null) {
      body = body.replace("{{wagerId}}", wiremockWagerId);
      System.out.println("WagerId replaced with: " + wiremockWagerId);
    }
    if (body.contains("{{serialNumbers}}") && wiremockSerialNumbers != null) {
      body = body.replace("{{serialNumbers}}", wiremockSerialNumbers);
      System.out.println("SerialNumbers replaced with: " + wiremockSerialNumbers);
    }
    if (body.contains("{{creationTime}}") && wiremockCreationTime != null) {
      body = body.replace("{{creationTime}}", wiremockCreationTime);
      System.out.println("CreationTime replaced with: " + wiremockCreationTime);
    }

    if (headers.length > 1) {
      if (headers[1].contains("{{guid}}")) {
        headers[1] = headers[1].replace("{{guid}}", wiremockGuid);
        System.out.println("Guid in headers replaced with: " + wiremockGuid);
      }
    }

    System.out.println(body);

    AddAStub addAStub = new AddAStub();
    addAStub.setScenarioName(scenarioName);
    addAStub.setRequiredScenarioState(requiredScenarioState);

    if (!priority.isEmpty() && !priority.isBlank()) {
      addAStub.setPriority(Integer.parseInt(priority));
    }

    // set request
    AddAStub.Request req = new AddAStub.Request();
    req.setUrlPattern(urlPattern);
    req.setMethod(method);
    addAStub.setRequest(req);

    // set response
    AddAStub.Response resp = new AddAStub.Response();
    resp.setStatus(Integer.parseInt(status));

    if (!body.isEmpty() && !body.isBlank()) {
      resp.setBody(body);
    }

    // set headers (Content-Type and GUID for now)
    AddAStub.headers headers1 = new AddAStub.headers();

    headers1.setContentType(headers[0]);

    if (headers.length > 1) {
      headers1.setGUID(headers[1]);
    }

    resp.setHeaders(headers1);
    addAStub.setResponse(resp);
    return addAStub;
  }
}
