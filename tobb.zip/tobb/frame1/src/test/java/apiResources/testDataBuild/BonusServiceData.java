package apiResources.testDataBuild;

import apiResources.Utils;
import apiResources.pojo.requests.bonusService.*;

import java.util.ArrayList;
import java.util.List;

public class BonusServiceData {
    public BonusPrize updateBonusPrizes(
            String providerId, String gameId, String status, float amount, boolean closeAccount) {

        BonusPrize bonusPrize = new BonusPrize();

        if (gameId.equalsIgnoreCase("CASINO")) {
            Utils utils = new Utils();
            String transactionID = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));
            bonusPrize.setTransactionId(transactionID);
            bonusPrize.setCloseAccount(closeAccount);
            bonusPrize.setAmount(amount);
        }
        bonusPrize.setStatus(status);
        bonusPrize.setGameId(gameId);
        bonusPrize.setProviderId(providerId);
        return bonusPrize;
    }

    public String adjustBonusPrizes(int amount) {

        Utils utils = new Utils();
        String transactionID = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));

        return "{\n"
                + "\t\"amount\": \""
                + amount
                + "\",\n"
                + "\t\"transactionId\":\""
                + transactionID
                + "\",\n"
                + "}";
    }

    public AssignBonus assignBonusToUser(String amount, String gameId, String providerId) {

        AssignBonus assignBonus = new AssignBonus();
        assignBonus.setGameId(gameId);
        assignBonus.setAmount(amount);
        assignBonus.setProviderId(providerId);


        return assignBonus;
    }

    public List<AllowedGames> postAllowedGames(String gameType, List<String> gameIds) {

        AllowedGames allowedGames = new AllowedGames();
        allowedGames.setGameType(gameType);
        allowedGames.setGameIds(gameIds);

        List<AllowedGames> allowedGamesList = new ArrayList<>();
        allowedGamesList.add(allowedGames);

        return allowedGamesList;
    }

    public BonusStatus cancelBonusPrize() {

        BonusStatus bonusPrize = new BonusStatus();
        bonusPrize.setStatus("CANCELLED");

        BonusStatus.metaData metadata = new BonusStatus.metaData();
        metadata.setCancelReason("test");
        bonusPrize.setMetadata(metadata);

        return bonusPrize;
    }

    public BonusStatus cancelBonus() {

        BonusStatus bonus = new BonusStatus();
        bonus.setStatus("CANCELLED");

        return bonus;
    }

    public FdbEnable updateBonusFdbEnable(String fdbEnabled, String fdbLinkEl, String fdbLinkEn) {

        FdbEnable fdbEnablePayload = new FdbEnable();
        fdbEnablePayload.setFdbEnabled(fdbEnabled);
        fdbEnablePayload.setFdbLinkEl(fdbLinkEl);
        fdbEnablePayload.setFdbLinkEn(fdbLinkEn);

        return fdbEnablePayload;
    }

    public FdbSelection bonusPrizeFdbSelect(String gameId, String playerId) {

        String userId;
        if (playerId == null || playerId.isEmpty()) {
            userId = null; // Default playerId if not provided
        } else {
            userId = "1-" + playerId; // Prefixing userId with "1-"
        }
        FdbSelection bonusPrizeFdbSelection = new FdbSelection();
        bonusPrizeFdbSelection.setGameId(gameId);
        bonusPrizeFdbSelection.setUserId(userId);

        return bonusPrizeFdbSelection;
    }

    public String assignBonusToUser(String userId) {

        return "{\n"
                + "  \"users\": [\n"
                + "    \"" + userId + "\"\n"
                + "  ]\n"
                + "}";
    }

    public AddBonus addBonus(
            String rewardType,
            String bonusAssignment,
            String activationTrigger,
            String rewardAmountType,
            String bonusValidTo,
            String minimumBets,
            String gameType,
            String gameIds,
            String singleUse,
            String rewardExpiryDays,
            String rewardAmount,
            int status,
            String rollOver,
            String program) {

        AddBonus addBonus = new AddBonus();
        Utils utils = new Utils();

        if (rewardType.equals("PRE_WAGER")) {
            addBonus.setRollOver(rollOver);
        }

        ArrayList<AddBonus.AllowedGame> allowedGames = new ArrayList<>();
        ArrayList<AddBonus.LangDetail> langDetails = new ArrayList<>();
        AddBonus.LangDetail langDetail1 = new AddBonus.LangDetail();
        AddBonus.LangDetail langDetail2 = new AddBonus.LangDetail();

        String[] gameIdList = gameIds.split(",");

        // maybe improve
        if (!gameType.contains(",")) {
            AddBonus.AllowedGame allowedGame1 = new AddBonus.AllowedGame();
            allowedGame1.setGameType(gameType);
            allowedGame1.setGameIds(List.of(gameIdList));
            allowedGames.add(allowedGame1);
        } else {
            String[] gameTypeList = gameType.split(",");

            for (int i = 0; i < gameTypeList.length; i++) {
                AddBonus.AllowedGame allowedGame1 = new AddBonus.AllowedGame();
                allowedGame1.setGameType(gameTypeList[i]);
                allowedGames.add(allowedGame1);
                allowedGame1.setGameIds(List.of(gameIdList));
                allowedGames.add(allowedGame1);
            }
        }

        addBonus.setAllowedGames(allowedGames);

        // LANG DETAILS
        langDetail1.setName(
                "BONUSRESTASSURED" + utils.calculateRandomInteger(10000000, 99999999) + "EL");

        langDetail1.setDescription("bonus περιγραφή στα Ελληνικά");
        langDetail1.setCode("el");

        langDetail2.setName(
                "BONUSRESTASSURED" + utils.calculateRandomInteger(10000000, 99999999) + "EL");

        langDetail2.setDescription("bonus description in english");
        langDetail2.setCode("en");

        langDetails.add(langDetail1);
        langDetails.add(langDetail2);

        addBonus.setLangDetails(langDetails);

        addBonus.setBonusTerms("http://www.opap.gr");
        // parameters
        addBonus.setProgram(program);
        addBonus.setRewardType(rewardType);
        addBonus.setBonusAssignment(bonusAssignment);
        addBonus.setActivationTrigger(activationTrigger);
        addBonus.setRewardAmountType(rewardAmountType);
        addBonus.setBonusValidTo(bonusValidTo);
        addBonus.setMinimumBets(minimumBets);

        addBonus.setSingleUse(singleUse);
        addBonus.setRewardExpiryDays(rewardExpiryDays);
        addBonus.setRewardAmount(rewardAmount);
        addBonus.setStatus(status);

        // Note: if you call calculateDateNowInSeconds has some bug with the hour (1h later). This will
        // do for now.
        addBonus.setBonusValidFrom(utils.calculateDateNowToString());

        return addBonus;
    }

    public AddBonusExtraFields addBonusExtraFields(
            String rewardType,
            String bonusAssignment,
            String activationTrigger,
            String paymentMethodName,
            String paymentMethodPercentage,
            String activationExpiryDays,
            String activationMinimumAmount,
            String rewardAmountType,
            String bonusValidFrom,
            String bonusValidTo,
            String minimumBets,
            String minimumBetAmount,
            String entryRequirement,
            String bonusCode,
            String gameType,
            String gameIds,
            String singleUse,
            String bonusTerms,
            String rewardExpiryDays,
            String rewardAmount,
            int status,
            String rollOver,
            String program) {

        AddBonusExtraFields addBonusExtraFields = new AddBonusExtraFields();
        Utils utils = new Utils();

        ArrayList<AddBonusExtraFields.AllowedGame> allowedGames = new ArrayList<>();
        ArrayList<AddBonusExtraFields.PaymentMethod> paymentMethods = new ArrayList<>();
        ArrayList<AddBonusExtraFields.LangDetail> langDetails = new ArrayList<>();
        AddBonusExtraFields.LangDetail langDetail1 = new AddBonusExtraFields.LangDetail();
        AddBonusExtraFields.LangDetail langDetail2 = new AddBonusExtraFields.LangDetail();

        String[] gameIdList = gameIds.split(",");

        // maybe improve
        if (!gameType.contains(",")) {
            AddBonusExtraFields.AllowedGame allowedGame1 = new AddBonusExtraFields.AllowedGame();
            allowedGame1.setGameType(gameType);
            allowedGame1.setGameIds(List.of(gameIdList));
            allowedGames.add(allowedGame1);
        } else {
            String[] gameTypeList = gameType.split(",");

            for (int i = 0; i < gameTypeList.length; i++) {
                AddBonusExtraFields.AllowedGame allowedGame1 = new AddBonusExtraFields.AllowedGame();
                allowedGame1.setGameType(gameTypeList[i]);
                allowedGames.add(allowedGame1);
                allowedGame1.setGameIds(List.of(gameIdList));
                allowedGames.add(allowedGame1);
            }
        }

        if ("DEPOSIT".equals(activationTrigger)) {
            if (paymentMethodName != null && !paymentMethodName.isEmpty()) {
                // Split names by comma, trim whitespace, filter out empty names
                String[] paymentMethodNameList = paymentMethodName.split(",");
                for (String name : paymentMethodNameList) {
                    name = name.trim();
                    // Skip if both name and percentage are empty/null
                    boolean isNameEmpty = (name.equals("") || name.isEmpty());
                    boolean isPercentageEmpty = (paymentMethodPercentage == null || paymentMethodPercentage.isEmpty());
                    if (!(isNameEmpty && isPercentageEmpty)) {
                        AddBonusExtraFields.PaymentMethod paymentMethod = new AddBonusExtraFields.PaymentMethod();
                        paymentMethod.setName(name);
                        paymentMethod.setPercentage(paymentMethodPercentage != null ? paymentMethodPercentage.trim() : null);
                        paymentMethods.add(paymentMethod);
                    }
                }
            }
        }

        // For Single Object of PaymentMethod
//      AddBonusExtraFields.PaymentMethod paymentMethod = new AddBonusExtraFields.PaymentMethod();
//      paymentMethod.setPaymentMethodName(paymentMethodName);
//      paymentMethod.setPaymentMethodPercentage(paymentMethodPercentage);


        addBonusExtraFields.setAllowedGames(allowedGames);
        addBonusExtraFields.setPaymentMethods(paymentMethods);
        // LANG DETAILS
        langDetail1.setName(
                "BONUSRESTASSURED" + utils.calculateRandomInteger(10000000, 99999999) + "EL");

        langDetail1.setDescription("bonus περιγραφή στα Ελληνικά");
        langDetail1.setCode("el");

        langDetail2.setName(
                "BONUSRESTASSURED" + utils.calculateRandomInteger(10000000, 99999999) + "EL");

        langDetail2.setDescription("bonus description in english");
        langDetail2.setCode("en");

        langDetails.add(langDetail1);
        langDetails.add(langDetail2);

        addBonusExtraFields.setLangDetails(langDetails);

        // Note: if you call calculateDateNowInSeconds has some bug with the hour (1h later). This will
        // do for now.
        addBonusExtraFields.setBonusValidFrom(bonusValidFrom);
        if (bonusValidFrom == null || bonusValidFrom.equals("")) {
            addBonusExtraFields.setBonusValidFrom(utils.calculateDateNowToString());
        }

        // parameters
        addBonusExtraFields.setProgram(program);
        addBonusExtraFields.setRollOver(rollOver);
        addBonusExtraFields.setRewardType(rewardType);
        addBonusExtraFields.setBonusAssignment(bonusAssignment);
        addBonusExtraFields.setEntryRequirement(entryRequirement);
        addBonusExtraFields.setBonusCode(bonusCode);
        addBonusExtraFields.setActivationTrigger(activationTrigger);
        addBonusExtraFields.setActivationExpiryDays(activationExpiryDays);
        addBonusExtraFields.setActivationMinimumAmount(activationMinimumAmount);
        addBonusExtraFields.setRewardAmountType(rewardAmountType);
        addBonusExtraFields.setBonusValidTo(bonusValidTo);
        addBonusExtraFields.setBonusTerms(bonusTerms);
        addBonusExtraFields.setMinimumBets(minimumBets);
        addBonusExtraFields.setMinimumBetAmount(minimumBetAmount);
        addBonusExtraFields.setSingleUse(singleUse);
        addBonusExtraFields.setRewardExpiryDays(rewardExpiryDays);
        addBonusExtraFields.setRewardAmount(rewardAmount);
        addBonusExtraFields.setStatus(status);

        return addBonusExtraFields;
    }

}
