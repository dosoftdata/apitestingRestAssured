package apiResources.testDataBuild;

import apiResources.pojo.requests.promotionService.BetEligibility;

public class PromotionServiceData {

  public BetEligibility addCheckBetEligibilityData(
      int gameId, int boards, int consecutiveDraws, boolean simpleBet, int cost) {

    BetEligibility betEligibility = new BetEligibility();
    betEligibility.setSimpleBet(simpleBet);
    betEligibility.setCost(cost);
    betEligibility.setBoards(boards);
    betEligibility.setConsecutiveDraws(consecutiveDraws);
    betEligibility.setGameId(gameId);

    return betEligibility;
  }
}
