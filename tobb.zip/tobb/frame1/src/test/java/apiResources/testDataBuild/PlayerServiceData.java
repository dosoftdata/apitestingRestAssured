package apiResources.testDataBuild;

import apiResources.Utils;
import apiResources.pojo.requests.playerService.*;

import static apiResources.Utils.*;

public class PlayerServiceData {

  public Register addRegisterPayload(
      String username,
      String password,
      String email,
      String identityType,
      String firstName,
      String middleName,
      String lastName,
      String gender,
      String dateOfBirth,
      String country,
      String address,
      String profession,
      String city,
      String zipCode,
      String bonusCode,
      String secretQuestion,
      String secretAnswer,
      String ibanNumber,
      String permanentResidenceCountry) {
    int random_integer;

    if (randomIntGenerated == 0) {
      Utils utils = new Utils();
      random_integer = utils.calculateRandomInteger(10000000, 99999999);
      randomIntGenerated = random_integer;
    } else {
      random_integer = randomIntGenerated;
    }

    username = username + random_integer;
    Utils.registeredUsername = username;
    Utils.registeredPassword = password;

    Register register = new Register();
    register.setUsername(username);
    register.setPassword(password);
    register.setIdentityType(identityType);
    register.setFirstName(firstName);
    register.setMiddleName(middleName);
    register.setLastName(lastName);
    register.setGender(gender);
    register.setDateOfBirth(dateOfBirth);
    register.setCountry(country);

    if (!email.contains("@")) {
      register.setEmail(email + random_integer + "@mailsac.com");
    } else {
      register.setEmail(email);
    }

    register.setIdentityNumber(String.valueOf(random_integer));
    register.setPhone("21" + random_integer);
    register.setMobilePhone("69" + random_integer);

    register.setAddress1(address);
    register.setProfession(profession);
    register.setZip(zipCode);
    register.setCity(city);
    register.setBonusCode(bonusCode);
    register.setSecretQuestion(secretQuestion);
    register.setSecretAnswer(secretAnswer);
    register.setIbanNumber(ibanNumber);
    register.setOtpUuid(uuid);
    register.setPermanentResidenceCountry(permanentResidenceCountry);

    return register;
  }

  public VerifyPlayerEmail addVerifyPlayerEmailPayload() {
    VerifyPlayerEmail verifyplayerEmail = new VerifyPlayerEmail();
    verifyplayerEmail.setPlayerId(playerId);
    verifyplayerEmail.setHash(hash);
    return verifyplayerEmail;
  }

  public VerifyPlayerEmail addVerifySpecificPlayerEmailPayload(String playerId) {
    VerifyPlayerEmail verifyplayerEmail = new VerifyPlayerEmail();
    verifyplayerEmail.setPlayerId(playerId);
    verifyplayerEmail.setHash(hash);
    return verifyplayerEmail;
  }

  public MSISDNRegister addMSISDNRegisterPayload(int randomIntGenerated, String otp) {
    MSISDNRegister msisdnRegister = new MSISDNRegister();
    msisdnRegister.setMsisdn(mobilePrefix + randomIntGenerated);
    msisdnRegister.setOtp(otp);
    return msisdnRegister;
  }

  public VerifyDocument addVerifyDocumentPayload(
      String verificationType, String statusDescription, String subType) {
    VerifyDocument verifyDocument = new VerifyDocument();

    verifyDocument.setStatusDescription(statusDescription);
    verifyDocument.setVerificationType(verificationType);

    // for CARD VERIFICATION
    if (verificationType.equals("CARD")) {
      if (subType.equalsIgnoreCase("FRONT")) {
        verifyDocument.setDocumentId(cardFrontDocumentId);
      } else if (subType.equalsIgnoreCase("BACK")) {
        verifyDocument.setDocumentId(cardBackDocumentId);
      }
      verifyDocument.setVerificationId(cardVerificationId);
    }
    /// for IDENTITY Verification
    else if (verificationType.equals("IDENTITY")) {
      if (subType.equalsIgnoreCase("OTHER")) {
        verifyDocument.setDocumentId(otherDocumentId);
      } else if (subType.equalsIgnoreCase("UTILITY_BILL")) {
        verifyDocument.setDocumentId(utilityDocumentId);
      }
      verifyDocument.setVerificationId(identityVerificationId);
    }
    return verifyDocument;
  }

  public ConfirmVerification addConfirmVerificationPayload(String verificationType) {
    ConfirmVerification confirmVerification = new ConfirmVerification();
    confirmVerification.setVerificationType(verificationType);
    if (verificationType.equalsIgnoreCase("CARD")) {
      confirmVerification.setId(cardVerificationId);
    } else if (verificationType.equalsIgnoreCase("IDENTITY")) {
      confirmVerification.setId(identityVerificationId);
    }
    return confirmVerification;
  }

  public VerifyIban addVerifyIbanPayload(String iban) {
    VerifyIban verifyIban = new VerifyIban();
    verifyIban.setIban(iban);
    verifyIban.setId(ibanVerificationId);
    return verifyIban;
  }

  public VerifyOtp addPutOtpPayload() {
    VerifyOtp verifyOtp = new VerifyOtp();
    verifyOtp.setPhoneNumber("69" + randomIntGenerated);
    verifyOtp.setUuid(uuid);
    verifyOtp.setVerificationCode("000000");
    return verifyOtp;
  }

  public VerifyOtp addPostOtpPayload() {
    Utils utils = new Utils();
    int random_integer = utils.calculateRandomInteger(10000000, 99999999);
    randomIntGenerated = random_integer;
    VerifyOtp verifyOtp = new VerifyOtp();
    verifyOtp.setPhoneNumber("69" + random_integer);
    return verifyOtp;
  }

  public String addUpdatePassword() {
    return "{\n"
        + "    \"newPassword\": \""
        + "Qwerty123"
        + "\",\n"
        + "    \"oldPassword\": \""
        + "Qwerty12345!"
        + "\"\n"
        + "}";
  }

  public ValidateRegistrationFields addRegistrationStep1ValidationPayload(
          String username,
          String password,
          String mobilePhone,
          String email,
          String promoCode) {
    ValidateRegistrationFields registrationStepValidation = new ValidateRegistrationFields();
    registrationStepValidation.setUsername(username);
    registrationStepValidation.setPassword(password);
    registrationStepValidation.setMobilePhone(mobilePhone);
    registrationStepValidation.setEmail(email);
    registrationStepValidation.setPromoCode(promoCode);
    return registrationStepValidation;
  }
}
