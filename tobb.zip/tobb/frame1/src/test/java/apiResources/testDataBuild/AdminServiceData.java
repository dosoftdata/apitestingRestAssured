package apiResources.testDataBuild;

import apiResources.DataContext;
import apiResources.Utils;
import apiResources.pojo.requests.accessService.EnableClerkUser;
import apiResources.pojo.requests.accessService.UpdateAffiliatePassword;
import apiResources.pojo.requests.adminService.CreateNewAdmin;
import apiResources.pojo.requests.adminService.CreateNewRole;
import apiResources.pojo.requests.adminService.UpdateAdminInfo;
import apiResources.pojo.requests.adminService.UpdateAdminPassword;

import java.util.List;

public class AdminServiceData {
    public CreateNewAdmin addCreateNewAdmin(
            String email, String firstName, String language, String lastName,
            String loginName, String password, String passwordRepeated, int status,  List<Integer> groupIds) {

        Utils utils = new Utils();
        int random_integer = 0;

        if (loginName.equals("USE_EXISTING")) {
            loginName = DataContext.registeredAdminLoginName;
            email = DataContext.registeredAdminEmail;
        } else {
            random_integer = utils.calculateRandomInteger(10000, 99999);
            loginName = loginName + random_integer;
            DataContext.generatedAdminLoginName = loginName;
            if (!email.contains("@")) {
                email = email + random_integer + "@mailsac.com";
                DataContext.generatedAdminEmail = email;
            } else {
                DataContext.generatedAdminEmail = email;
            }
        }

        CreateNewAdmin createNewAdmin = new CreateNewAdmin();


        if (!firstName.isEmpty()) {
            createNewAdmin.setFirstName(firstName);
        }

        createNewAdmin.setLanguage(language != null ? language : "");

        if (!lastName.isEmpty()) {
            createNewAdmin.setLastName(lastName);
        }

        createNewAdmin.setLoginName(loginName);
        createNewAdmin.setEmail(email);

        if (!password.isEmpty()) {
            createNewAdmin.setPassword(password);
        }

        if (!passwordRepeated.isEmpty()) {
            createNewAdmin.setPasswordRepeated(passwordRepeated);
        }

        createNewAdmin.setStatus(status);
        createNewAdmin.setGroupIds(groupIds);

        return createNewAdmin;
    }

    public CreateNewRole addCreateNewRole(
            String email, String firstName, String language, String lastName,
            String loginName, String password, String passwordRepeated, int status,  List<Integer> groupIds) {

        CreateNewRole createNewRole = new CreateNewRole();

        if (!email.isEmpty()) {
            createNewRole.setEmail(email);
        }
        if (!firstName.isEmpty()) {
            createNewRole.setFirstName(firstName);
        }
        createNewRole.setLanguage(language != null ? language : "");

        if (!lastName.isEmpty()) {
            createNewRole.setLastName(lastName);
        }
        if (!loginName.isEmpty()) {
            createNewRole.setLoginName(loginName);
        }
        if (!password.isEmpty()) {
            createNewRole.setPassword(password);
        }
        if (!passwordRepeated.isEmpty()) {
            createNewRole.setPasswordRepeated(passwordRepeated);
        }
        createNewRole.setStatus(status);

        createNewRole.setGroupIds(groupIds);

        return createNewRole;
    }

    public CreateNewRole addCreateNewRoleAffiliate(
            String email, String firstName, String language, String lastName,
            String loginName, String password, String passwordRepeated) {

        CreateNewRole createNewRole = new CreateNewRole();

        if (!email.isEmpty()) {
            createNewRole.setEmail(email);
        }
        if (!firstName.isEmpty()) {
            createNewRole.setFirstName(firstName);
        }
        createNewRole.setLanguage(language != null ? language : "");

        if (!lastName.isEmpty()) {
            createNewRole.setLastName(lastName);
        }
        if (!loginName.isEmpty()) {
            createNewRole.setLoginName(loginName);
        }
        if (!password.isEmpty()) {
            createNewRole.setPassword(password);
        }
        if (!passwordRepeated.isEmpty()) {
            createNewRole.setPasswordRepeated(passwordRepeated);
        }

        return createNewRole;
    }

    public EnableClerkUser addEnableClerkUser(
            String email, String firstname, String language, String lastName,
            String loginName, int status,  List<Integer> groupIds) {

        EnableClerkUser enableClerkUser = new EnableClerkUser();

        if (!email.isEmpty()) {
            enableClerkUser.setEmail(email);
        }
        if (!firstname.isEmpty()) {
            enableClerkUser.setFirstName(firstname);
        }
        if (language.equals("null")){
            enableClerkUser.setLanguage("");}
        else{
            enableClerkUser.setLanguage(language);
        }

        if (!lastName.isEmpty()) {
            enableClerkUser.setLastName(lastName);
        }
        if (!loginName.isEmpty()) {
            enableClerkUser.setLoginName(loginName);
        }
        enableClerkUser.setStatus(status);

        enableClerkUser.setGroupIds(groupIds);

        return enableClerkUser;
    }

    public UpdateAffiliatePassword addUpdateAffiliatePassword(
            String password, String passwordRepeated) {

        UpdateAffiliatePassword updateAffiliatePassword = new UpdateAffiliatePassword();

        if (!password.isEmpty()) {
            updateAffiliatePassword.setPassword(password);
        }
        if (!passwordRepeated.isEmpty()) {
            updateAffiliatePassword.setPasswordRepeated(passwordRepeated);
        }

        return updateAffiliatePassword;
    }

    public String addLoginAsHighWinningsUser(String loginName, String password) {
        return "{\n" +
                "    \"loginName\": \"" + loginName + "\",\n" +
                "    \"password\": \"" + password + "\"\n" +
                "}";
    }

    public String addUpdatePasswordAsHighWinningsUser(String password) {
        return "{\n" +
                "    \"newPassword\": \"" + password + "\"\n"+
                "}";
    }

    public Object addUpdateAdminInfo(String firstName, String lastName, String email, String loginName, List<Integer> groupIds, int status) {
        UpdateAdminInfo updateAdminInfo = new UpdateAdminInfo();

        if (loginName.equals("USE_EXISTING")) {
            loginName = DataContext.registeredAdminLoginName;
        }

        if (!firstName.isEmpty()) {
            updateAdminInfo.setFirstName(firstName);
        }
        if (!lastName.isEmpty()) {
            updateAdminInfo.setLastName(lastName);
        }
        if (!email.isEmpty()) {
            updateAdminInfo.setEmail(email);
        }
        if (!loginName.isEmpty()) {
            updateAdminInfo.setLoginName(loginName);
        }
        updateAdminInfo.setGroupIds(groupIds);
        updateAdminInfo.setStatus(status);

        return updateAdminInfo;
    }

    public Object addUpdateAdminPassword(String newPassword, String newPasswordRepeated) {

        UpdateAdminPassword updateAdminPassword = new UpdateAdminPassword();

        if (!newPassword.isEmpty()) {
            updateAdminPassword.setPassword(newPassword);
        }
        if (!newPasswordRepeated.isEmpty()) {
            updateAdminPassword.setPasswordRepeated(newPasswordRepeated);
        }

        return updateAdminPassword;
    }
}
