package apiResources.testDataBuild;

import apiResources.Utils;
import apiResources.pojo.requests.accessService.*;

import java.util.ArrayList;
import java.util.List;

import static apiResources.DataContext.*;
import static apiResources.Utils.playerId;

public class AccessServiceData {
  public LoginNew addLoginNewData(
      String username, String password, String group, String channel, String scope) {

    LoginNew loginNew = new LoginNew();
    loginNew.setGrant_type("password");
    loginNew.setScope(scope);
    loginNew.setRememberMe(false);
    loginNew.setVerify_token("6ZzzzAzA");

    if (!username.isEmpty()) {
      loginNew.setUsername(username);
    }
    if (!password.isEmpty()) {
      loginNew.setPassword(password);
    }
    if (!group.isEmpty()) {
      loginNew.setGroup(group);
    }
    if (!channel.isEmpty()) {
      loginNew.setChannel(channel);
    }
    return loginNew;
  }

  public LoginNew addLoginNewDataRememberMe(
      String username,
      String password,
      String group,
      String channel,
      String scope,
      boolean rememberMe) {

    LoginNew loginNew = new LoginNew();
    loginNew.setGrant_type("password");
    loginNew.setScope(scope);
    loginNew.setRememberMe(rememberMe);
    loginNew.setVerify_token("6ZzzzAzA");

    if (!username.isEmpty()) {
      loginNew.setUsername(username);
    }
    if (!password.isEmpty()) {
      loginNew.setPassword(password);
    }
    if (!group.isEmpty()) {
      loginNew.setGroup(group);
    }
    if (!channel.isEmpty()) {
      loginNew.setChannel(channel);
    }
    return loginNew;
  }

  public LoginNew addLoginNewDataOtpCode(
      String username,
      String password,
      String group,
      String channel,
      String otpCode,
      String scope) {

    LoginNew loginNew = new LoginNew();
    loginNew.setGrant_type("password");
    loginNew.setScope(scope);
    loginNew.setOtpCode(otpCode);

    if (!username.isEmpty()) {
      loginNew.setUsername(username);
    }
    if (!password.isEmpty()) {
      loginNew.setPassword(password);
    }
    if (!group.isEmpty()) {
      loginNew.setGroup(group);
    }
    if (!channel.isEmpty()) {
      loginNew.setChannel(channel);
    }
    return loginNew;
  }

  public LoginNew addLoginNewDataWithNoToken(
      String username, String password, String group, String channel, String scope) {

    LoginNew loginNew = new LoginNew();
    loginNew.setGrant_type("password");
    loginNew.setUsername(username);
    loginNew.setPassword(password);
    loginNew.setGroup(group);
    loginNew.setChannel(channel);
    loginNew.setScope(scope);
    loginNew.setRememberMe(false);
    return loginNew;
  }

  public LoginOld addLoginOldData(
      String username, String password, String channel, String subChannel, String group) {
    LoginOld loginOld = new LoginOld();
    loginOld.setUsername(username);
    loginOld.setPassword(password);
    loginOld.setChannel(channel);
    loginOld.setSubchannel(subChannel);
    loginOld.setGroup(group);
    return loginOld;
  }

  public LoginBackOffice addLoginBackOfficeData(String loginName, String password) {

    LoginBackOffice loginBackOffice = new LoginBackOffice();
    loginBackOffice.setLoginName(loginName);
    loginBackOffice.setPassword(password);
    return loginBackOffice;
  }

  public String addLoginApiData() {
    return "{\"grant_type\":\"client_credentials\"}";
  }

  public String addUserToEpGroup() {
    return "{\n"
        + "    \"memberId\": \"1-"
        + playerId
        + "\",\n"
        + "    \"retailerId\": \"1\",\n"
        + "    \"updatedByUserId\": \"1-"
        + playerId
        + "\"\n"
        + "}";
  }

  public String addUserToNepGroup() {
    return "{\n"
        + "    \"memberId\": \"1-"
        + playerId
        + "\",\n"
        + "    \"retailerId\": \"1\",\n"
        + "    \"updatedByUserId\": \"1-"
        + playerId
        + "\"\n"
        + "}";
  }

  public String addUserToFriendsAndFamilyGroupMismatch() {
    return "{\n"
        + "    \"memberId\": \"102-"
        + friendsAndFamilyGroupId
        + "\",\n"
        + "    \"retailerId\": \"1\",\n"
        + "    \"updatedByUserId\": \"102-"
        + friendsAndFamilyGroupId
        + "\"\n"
        + "}";
  }

  public String addUserToFriendsAndFamilyGroup() {
    return "{\n"
        + "    \"memberId\": \"1-"
        + playerId
        + "\",\n"
        + "    \"retailerId\": \"1\",\n"
        + "    \"updatedByUserId\": \"1-"
        + playerId
        + "\"\n"
        + "}";
  }

  public String logOut() {
    return "{\n" + "    \"loginName\": \"admin\",\n" + "    \"password\": \"admin\"" + "}";
  }

  public String addUserToGroup(String epGroup, String nepGroup) {
    boolean epGroupBool = Boolean.parseBoolean(epGroup);
    boolean nepGroupBool = Boolean.parseBoolean(nepGroup);

    return "{\n"
        + "    \"exclusiveGamesGroupAccess\": "
        + epGroupBool
        + ", \n"
        + "    \"nonExclusiveGamesGroupAccess\": "
        + nepGroupBool
        + "\n"
        + "}";
  }

  public List<ApiAccessAttributes> addApiAccessAttributes(
      String accessType,
      String operationalUnit,
      String userId,
      String created,
      String updated,
      String updatedByUserId,
      String operatorId,
      String reason,
      String valid,
      String notifyStatus) {
    ApiAccessAttributes apiAccessAttributes = new ApiAccessAttributes();

    List<ApiAccessAttributes> apiAccessAttributesList =
        new ArrayList(); // this is temporary solution works for 1 accessAttribute at a time if we
    // happen to need more accessAttributes in an addition refactor here and in step.

    if (userId.equals("newPlayerWeb")) {
      apiAccessAttributes.setUserId("1-" + playerId);
    } else if (!userId.isEmpty()) {
      apiAccessAttributes.setUserId(userId);
    }
    if (updatedByUserId.equals("newPlayerWeb")) {
      apiAccessAttributes.setUpdatedByUserId("1-" + playerId);
    } else if (!updatedByUserId.isEmpty()) {
      apiAccessAttributes.setUpdatedByUserId(updatedByUserId);
    }
    if (!accessType.isEmpty()) {
      apiAccessAttributes.setAccessType(accessType);
    }

    if (!operationalUnit.isEmpty()) {
      apiAccessAttributes.setOperationalUnit(operationalUnit);
    }

    if (!created.isEmpty() && !created.equals("null")) {
      apiAccessAttributes.setCreated(created);
    }
    if (!updated.isEmpty() && !updated.equals("null")) {
      apiAccessAttributes.setUpdated(updated);
    }
    if (!operatorId.isEmpty() && !operatorId.equals("null")) {
      apiAccessAttributes.setOperatorId(updated);
    }
    if (!reason.isEmpty() && !reason.equals("null")) {
      apiAccessAttributes.setReason(reason);
    }

    if (!valid.equals("null") && !valid.isEmpty()) {
      // empty object here. for validFrom validTo use the other step.
      ApiAccessAttributes.Valid valid1 = new ApiAccessAttributes.Valid();
      apiAccessAttributes.setValid(valid1);
    }

    if (!notifyStatus.isEmpty()) {
      apiAccessAttributes.setNotifyStatus(notifyStatus);
    }

    apiAccessAttributesList.add(apiAccessAttributes);
    return apiAccessAttributesList;
  }

  public List<ApiAccessAttributes> addApiAccessAttributesValidFromValidTo(
      String accessType,
      String operationalUnit,
      String userId,
      String created,
      String updated,
      String updatedByUserId,
      String operatorId,
      String reason,
      String validFrom,
      String validTo,
      String notifyStatus) {
    ApiAccessAttributes apiAccessAttributes = new ApiAccessAttributes();

    List<ApiAccessAttributes> apiAccessAttributesList =
        new ArrayList(); // this is temporary solution works for 1 accessAttribute at a time if we
    // happen to need more accessAttributes in an addition refactor here and in step.

    if (userId.equals("newPlayerWeb")) {
      apiAccessAttributes.setUserId("1-" + playerId);
    } else {
      apiAccessAttributes.setUserId(userId);
    }
    if (updatedByUserId.equals("newPlayerWeb")) {
      apiAccessAttributes.setUpdatedByUserId("1-" + playerId);
    } else {
      apiAccessAttributes.setUpdatedByUserId(updatedByUserId);
    }

    apiAccessAttributes.setAccessType(accessType);
    apiAccessAttributes.setCreated(created);
    apiAccessAttributes.setOperationalUnit(operationalUnit);
    apiAccessAttributes.setUpdated(updated);
    apiAccessAttributes.setOperatorId(operatorId);

    if (validFrom.equals("null") && validTo.equals("null")) {
      apiAccessAttributes.setValid(null);
    } else {
      ApiAccessAttributes.Valid valid1 = new ApiAccessAttributes.Valid();
      Utils utils = new Utils();
      String dateNow = utils.calculateDateNowInSecondsToString();

      if (validFrom.equals("datenow")) {
        validFrom = dateNow;
      }
      if (validTo.equals("datenow")) {
        validTo = dateNow;
      }
      valid1.setFrom(validFrom);
      valid1.setTo(validTo);
      apiAccessAttributes.setValid(valid1);
    }
    apiAccessAttributes.setReason(reason);

    if (!notifyStatus.isEmpty()) {
      apiAccessAttributes.setNotifyStatus(notifyStatus);
    }
    apiAccessAttributesList.add(apiAccessAttributes);
    return apiAccessAttributesList;
  }

  public AddCustomerAccessAttribute addCustomerAccessAttributes(
      String accessType,
      String userType,
      String userId,
      String operationalUnit,
      String validTo,
      String reason,
      String blockHours) {
    AddCustomerAccessAttribute addCustomerAccessAttributes = new AddCustomerAccessAttribute();

    if (userId.equals("newPlayerWeb")) {
      addCustomerAccessAttributes.setUserId("1-" + playerId);
    } else {
      addCustomerAccessAttributes.setUserId(userId);
    }
    addCustomerAccessAttributes.setAccessType(accessType);
    if (operationalUnit.equals("null")) {
      addCustomerAccessAttributes.setOperationalUnit(null);
    } else {
      addCustomerAccessAttributes.setOperationalUnit(operationalUnit);
    }
    addCustomerAccessAttributes.setUserType(userType);
    addCustomerAccessAttributes.setReason(reason);
    addCustomerAccessAttributes.setBlockHours(blockHours);

    if (validTo.equals("null")) {
      addCustomerAccessAttributes.setValidTo(null);
    } else {
      addCustomerAccessAttributes.setValidTo(validTo);
    }
    return addCustomerAccessAttributes;
  }

  public CreateAssertion createAssertion(
      String type,
      String ssoSessionId,
      String userId,
      String securityDomainName,
      String issued,
      String expires) {
    CreateAssertion createAssertion = new CreateAssertion();

    if (userId.equals("newPlayerWeb")) {
      createAssertion.setUserId("1-" + playerId);
    } else {
      createAssertion.setUserId(userId);
    }
    createAssertion.setType(type);
    createAssertion.setSsoSessionId(ssoSessionId);

    createAssertion.setSecurityDomainName(securityDomainName);
    createAssertion.setIssued(issued);
    createAssertion.setExpires(expires);

    return createAssertion;
  }

  public String addLoginExternalPendingData(String ssn) {
    return "{\n" + "    \"ssn\": " + "\"" + ssn + "\"" + "\n}";
  }

  public String addLoginExternalData(String target) {
    return "{\n" + "    \"target\": " + "\"" + target + "\"" + "\n}";
  }

  public String addLoginExternalWrongRequest(String request) {
    return request;
  }

  public ForceLogoutCC addForceLogoutCCData(String reason, String group) {
    ForceLogoutCC forceLogoutCC = new ForceLogoutCC();
    forceLogoutCC.setReason(reason);
    forceLogoutCC.setGroup(group);
    return forceLogoutCC;
  }

  public NewAccessRole addNewAccessRole(String name, String description) {
    NewAccessRole newAccessRole = new NewAccessRole();
    newAccessRole.setName(name);
    newAccessRole.setDescription(description);
    return newAccessRole;
  }

  public String addLoginAsAffiliateUser(String loginName) {
    return "{\n" + "    \"loginName\": " + "\"" + loginName + "\"" + "\n}";
  }

  public String addLoginAsHighWinningsUser(String loginName, String password) {
    return "{\n"
        + "    \"loginName\": \""
        + loginName
        + "\",\n"
        + "    \"password\": \""
        + password
        + "\"\n"
        + "}";
  }

  public String addLoginAsHighWinningsUserAzure() {
    return "{\n"
        + "    \"loginName\": \""
        + azureHighWinningsUsername
        + "\",\n"
        + "    \"password\": \""
        + azureHighWinningsPassword
        + "\"\n"
        + "}";
  }

  public AddAccessAttribute addApiAccessAttributesForFriendsAndFamilyGroupId(
      String accessType,
      String operationalUnit,
      String userId,
      String created,
      String updated,
      String updatedByUserId,
      String operatorId,
      String reason,
      String validFrom,
      String validTo) {

    AddAccessAttribute addAccessAttributes = new AddAccessAttribute();

    if (userId.contains("friendsAndFamilyGroupId")) {
      addAccessAttributes.setUserId("102-" + friendsAndFamilyGroupId);
    } else if (userId.contains("playerId")) {
      addAccessAttributes.setUserId("1-" + playerId);
    } else {
      addAccessAttributes.setUserId(userId);
    }

    addAccessAttributes.setCreated(created);
    addAccessAttributes.setOperationalUnit(operationalUnit);
    addAccessAttributes.setAccessType(accessType);
    addAccessAttributes.setUpdated(updated);

    if (updatedByUserId.contains("friendsAndFamilyGroupId")) {
      addAccessAttributes.setUpdatedByUserId("102-" + friendsAndFamilyGroupId);
    } else if (updatedByUserId.contains("playerId")) {
      addAccessAttributes.setUpdatedByUserId("1-" + playerId);
    } else {
      addAccessAttributes.setUpdatedByUserId(updatedByUserId);
    }
    addAccessAttributes.setOperatorId(operatorId);
    addAccessAttributes.setReason(reason);

    if (validFrom.equals("null")) {
      addAccessAttributes.setValidFrom("");
    } else {
      addAccessAttributes.setValidFrom(validFrom);
    }

    if (validTo.equals("null")) {
      addAccessAttributes.setValidTo("");
    } else {
      addAccessAttributes.setValidTo(validTo);
    }

    return addAccessAttributes;
  }

  public List<AllowAdminAccessAttribute> addAllowAdminAccessAttribute(String operationalUnit) {
    List<AllowAdminAccessAttribute> allowAdminAccessAttributeList = new ArrayList<>();
    AllowAdminAccessAttribute allowAdminAccessAttribute = new AllowAdminAccessAttribute();
    allowAdminAccessAttribute.setOperationalUnit(operationalUnit);
    allowAdminAccessAttributeList.add(allowAdminAccessAttribute);
    return allowAdminAccessAttributeList;
  }

  public String getOperationalUnitsPayload() {
    return "[\n"
        + "    {\"operationalUnit\": \"admin.payments/prize-payments/manage-review\"},\n"
        + "    {\"operationalUnit\": \"admin.payments/prize-payments/review\"},\n"
        + "    {\"operationalUnit\": \"admin.payments/prize-payments/view\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/adjust\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/cancel-payment\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/delete-payment-methods\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/edit-payment-methods\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/edit-wallet-permissions\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/modify-payment-methods\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/view-grand-prize\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/view-payment-methods\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/view-payments\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/view-wallet-balance\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/view-wallet-permissions\"},\n"
        + "    {\"operationalUnit\": \"admin.players/transactions/view\"},\n"
        + "    {\"operationalUnit\": \"admin.players/transactions/view-grand-prize\"},\n"
        + "    {\"operationalUnit\": \"admin.players/activity/list\"},\n"
        + "    {\"operationalUnit\": \"admin.players/archives/view-archives\"},\n"
        + "    {\"operationalUnit\": \"admin.players/player-email/update\"},\n"
        + "    {\"operationalUnit\": \"admin.players/player-info/requestPasswordReset\"},\n"
        + "    {\"operationalUnit\": \"admin.players/player-info/update\"},\n"
        + "    {\"operationalUnit\": \"admin.players/player-info/view\"},\n"
        + "    {\"operationalUnit\": \"admin.players/player-info/viewStatus\"},\n"
        + "    {\"operationalUnit\": \"admin.players/player-levels/view\"},\n"
        + "    {\"operationalUnit\": \"admin.players/player-notes/update\"},\n"
        + "    {\"operationalUnit\": \"admin.players/player-notes/view\"},\n"
        + "    {\"operationalUnit\": \"admin.players/player-summary/view\"},\n"
        + "    {\"operationalUnit\": \"admin.players/player-tax-info/update\"},\n"
        + "    {\"operationalUnit\": \"admin.players/player-tax-info/view\"},\n"
        + "    {\"operationalUnit\": \"admin.players/session-overview/view\"},\n"
        + "    {\"operationalUnit\": \"admin.players/accounts/verify-payment-by-id\"},\n"
        + "    {\"operationalUnit\": \"adminrest.players/payments/verify/WEB\"}\n"
        + "]";
  }

  public AccessCheck addAccessCheckData(
      String userRequest, String callerRequest, String operationalUnit) {
    AccessCheck accessCheck = new AccessCheck();

    if (!operationalUnit.isEmpty()) {
      accessCheck.setOperationalUnit(operationalUnit);
    }

    if (!userRequest.isEmpty()) {
      AccessCheck.Users user = new AccessCheck.Users();
      if (userRequest.equals("newPlayerWeb")) {
        userRequest = "1-" + playerId;
      }
      user.setUserId(userRequest);
      accessCheck.setUserRequest(user);
    }

    if (!callerRequest.isEmpty()) {
      AccessCheck.Users caller = new AccessCheck.Users();
      if (callerRequest.equals("newPlayerWeb")) {
        callerRequest = "1-" + playerId;
      }
      caller.setUserId(callerRequest);
      accessCheck.setCallerRequest(caller);
    }
    return accessCheck;
  }

  public String addAssignAccessAttributeFeatureWrongCustomerId(String feature) {
    return "{\n"
        + "    \"feature\": \""
        + feature
        + "\",\n"
        + "    \"customerIds\": \"1-"
        + playerId
        + "\"\n"
        + "}";
  }

  public AddFeatureFlag addFeatureFlag(String feature, List<String> customerIds) {

    AddFeatureFlag addFeatureFlag = new AddFeatureFlag();

    if (!feature.equals("null")) {
      addFeatureFlag.setFeature(feature);
    } else {
      addFeatureFlag.setFeature(null);
    }
    addFeatureFlag.setCustomerIds(customerIds);
    return addFeatureFlag;
  }

  public String addAssignAccessAttributeFeature(String feature) {
    return "{\n"
        + "    \"feature\": \""
        + feature
        + "\",\n"
        + "    \"customerIds\":"
        + playerId
        + "\"\n"
        + "}";
  }

  public String addAssignAccessAttributeFeatureTest() {
    return "{\n"
        + "    \"feature\": \""
        + "test"
        + "\",\n"
        + "    \"customerIds\": \""
        + ""
        + "\"\n"
        + "}";
  }

  public String addEnableFeature(String feature) {
    return "{\n" + "    \"feature\": \"" + feature + "\"\n" + "}";
  }

  public AccessGroup addAccessGroupsData(
      String name, String description, String updatedByUserId, String memberType) {

    AccessGroup accessGroup = new AccessGroup();

    if (name.equals("testNameRandom")) {
      Utils utils = new Utils();
      name = "testName" + utils.calculateRandomInteger(1000, 9999);
      accessGroupName = name;
    } else if (name.equals("existingGroup")) {
      name = accessGroupName;
    }

    if (updatedByUserId.equals("newPlayerWeb")) {
      updatedByUserId = "1-" + playerId;
    }

    accessGroup.setDescription(description);
    accessGroup.setName(name);

    if (!updatedByUserId.isEmpty()) {
      accessGroup.setUpdatedByUserId(updatedByUserId);
    }
    if (!memberType.isEmpty()) {
      accessGroup.setMemberType(Integer.parseInt(memberType));
    }
    return accessGroup;
  }

  public String addAdminRoleIdData(String roleId) {
    return "[" + "\"" + roleId + "\"" + "]";
  }

  public String addAccessRoleV2data(String memberId) {
    return "{ \"memberId\": \"" + memberId + "\" }";
  }

  public AccessGroupMember addAccessGroupMembersData(
      String memberId, String retailerId, String updatedByUserId) {

    // maybe improve
    if (memberId.contains("newPlayerWeb")) {
      if (playerId == null) {
        throw new RuntimeException(
            "Player has not been set correctly. Please check if a new player has been created or you have overwritten his value in the flow properly");
      }

      String[] prefix = memberId.split("-");
      memberId = prefix[0] + "-" + playerId;
      System.out.println("MemberId for request is: " + memberId);
    }

    AccessGroupMember accessGroupMember = new AccessGroupMember();
    accessGroupMember.setMemberId(memberId);
    accessGroupMember.setUpdatedByUserId(updatedByUserId);
    accessGroupMember.setRetailerId(retailerId);

    return accessGroupMember;
  }

  public AccessGroupMemberV2 addAccessGroupMembersV2Data(
      String action, String accessGroupId, String accessGroupMemberId, String userId) {
    AccessGroupMemberV2 accessGroupMemberv2 = new AccessGroupMemberV2();

    if (userId.equals("newPlayerWeb")) {
      userId = "1-" + playerId;
    }
    if (accessGroupId.equals("newAccessGroupId")) {
      accessGroupId = newAccessGroupId;
    }

    if (accessGroupMemberId.equals("newGroupMemberId")) {
      accessGroupMemberId = newGroupMemberId;
    }

    if (!accessGroupId.equals("null") && !accessGroupId.isEmpty()) {
      accessGroupMemberv2.setAccessGroupId(accessGroupId);
    }

    if (action != null && !action.isEmpty()) {
      accessGroupMemberv2.setAction(action);
    }

    if (!accessGroupMemberId.equals("null") && !accessGroupMemberId.isEmpty()) {
      accessGroupMemberv2.setAccessGroupMemberId(accessGroupMemberId);
    }

    if (!userId.equals("null") && !userId.isEmpty()) {
      accessGroupMemberv2.setUserId(userId);
    }
    return accessGroupMemberv2;
  }

  public String addLoginAsHighWinningsUserAzureBeforeUpdate() {
    return "{\n"
        + "    \"loginName\": \""
        + azureHighWinningsUsername
        + "\",\n"
        + "    \"password\": \""
        + "Fabola12345678!"
        + "\"\n"
        + "}";
  }

  public String addLoginAsHighWinningsUserAzureAfterUpdate() {
    return "{\n"
        + "    \"loginName\": \""
        + azureHighWinningsUsername
        + "\",\n"
        + "    \"password\": \""
        + "Fabola12345678@"
        + "\"\n"
        + "}";
  }

  public LoginApi addLoginApiDynamicData(
      String grantType,
      String code,
      String refreshToken,
      String retailerId,
      String betwareRetailerId,
      String betwareTerminalId,
      String clientAssertion,
      String clientAssertionType,
      String clientSecret,
      String clientId,
      String username,
      String password,
      String cardNumber,
      String pin,
      String assertion,
      String claims) {

    LoginApi loginApi = new LoginApi();
    loginApi.setGrant_type(grantType); // this is mandatory in general

    // the fields below are for negative scenarios only. Not all of them used at once I have added
    // them in one general method.

    if (!code.isEmpty()) {
      loginApi.setCode(code);
    }
    if (!retailerId.isEmpty()) {
      loginApi.setRetailerId(retailerId);
    }
    if (!clientAssertion.isEmpty()) {
      loginApi.setClient_assertion(clientAssertion);
    }
    if (!username.isEmpty()) {
      loginApi.setUsername(username);
    }
    if (!password.isEmpty()) {
      loginApi.setPassword(password);
    }
    if (!betwareRetailerId.isEmpty()) {
      loginApi.setBetware_retailer_id(betwareRetailerId);
    }
    if (!betwareTerminalId.isEmpty()) {
      loginApi.setBetware_terminal_id(betwareTerminalId);
    }
    if (!refreshToken.isEmpty()) {
      loginApi.setRefresh_token(refreshToken);
    }
    if (!clientAssertionType.isEmpty()) {
      loginApi.setClient_assertion_type(clientAssertionType);
    }
    if (!clientId.isEmpty()) {
      loginApi.setClient_id(clientId);
    }
    if (!clientSecret.isEmpty()) {
      loginApi.setClient_secret(clientSecret);
    }
    if (!cardNumber.isEmpty()) {
      loginApi.setCardnumber(cardNumber);
    }
    if (!pin.isEmpty()) {
      loginApi.setPin(pin);
    }
    if (!assertion.isEmpty()) {
      loginApi.setAssertion(assertion);
    }
    if (!claims.isEmpty()) {
      loginApi.setClaims(claims);
    }

    return loginApi;
  }

  public OperationalUnit addOperationalUnits(String operationalUnit) {
    OperationalUnit opUnit = new OperationalUnit();
    opUnit.setOperationalUnit(operationalUnit);
    return opUnit;
  }
}
