package apiResources.testDataBuild;

import apiResources.Utils;
import apiResources.pojo.requests.communicationService.BulkMessage;
import apiResources.pojo.requests.communicationService.MarkNotificationAsRead;
import apiResources.pojo.requests.communicationService.MarkNotificationAsSeen;
import apiResources.pojo.requests.communicationService.PlayerPreferences;
import apiResources.pojo.requests.communicationService.*;

import java.util.ArrayList;
import java.util.List;

public class CommunicationServiceData {
  public PlayerPreferences setPlayerPreferences(
      String subCategory,
      String selected,
      String messageType,
      String category,
      String preferenceType) {

    PlayerPreferences playerPreferences = new PlayerPreferences();
    if (!preferenceType.isEmpty() && !preferenceType.isBlank()) {
      playerPreferences.setPreferenceType(preferenceType);
    }
    if (!subCategory.isEmpty() && !subCategory.isBlank()) {
      playerPreferences.setSubCategory(subCategory);
    }
    if (!selected.isEmpty() && !selected.isBlank()) {
      playerPreferences.setSelected(Boolean.parseBoolean(selected));
    }
    if (!messageType.isEmpty() && !messageType.isBlank()) {
      playerPreferences.setMessageType(messageType);
    }
    if (!category.isEmpty() && !category.isBlank()) {
      playerPreferences.setCategory(category);
    }
    return playerPreferences;
  }

  public MarkNotificationAsSeen addMarkNotificationAsSeenPayload(String id) {

    if (id.equals("notificationId")) {
      id = id.replace("notificationId", Utils.notificationId);
    }
    if (id.contains("playerId")) {
      id = id.replace("playerId", Utils.playerId);
    }
    if (id.contains("notificationIdOnly")) {
      id = id.replace("notificationIdOnly", Utils.notificationIdOnly);
    }
    if (id.contains("userType")) {
      id = id.replace("userType", Utils.userType);
    }

    MarkNotificationAsSeen markNotificationAsSeen = new MarkNotificationAsSeen();
    markNotificationAsSeen.setId(id);
    return markNotificationAsSeen;
  }

  public MarkNotificationAsRead addMarkNotificationAsReadPayload(boolean read) {
    MarkNotificationAsRead markNotificationAsRead = new MarkNotificationAsRead();
    markNotificationAsRead.setRead(read);
    return markNotificationAsRead;
  }

  public BulkMessage addBulkMessagesPayload(
      String externalId, String eventOwner, String eventName, String wagerId, String userId) {
    BulkMessage bulkMessage = new BulkMessage();
    BulkMessage.Recipients recipient = new BulkMessage.Recipients();
    BulkMessage.Parameters parameter = new BulkMessage.Parameters();
    List<BulkMessage.Recipients> recipients = new ArrayList<>();

    bulkMessage.setEventOwner(eventOwner);
    bulkMessage.setEventName(eventName);
    bulkMessage.setExternalId(externalId);

    recipient.setUserId(userId);
    parameter.setWagerId(wagerId);

    recipients.add(recipient);

    bulkMessage.setRecipients(recipients);
    bulkMessage.setParameters(parameter);

    return bulkMessage;
  }

  public ChangeTemplateIdValues ChangeTemplateIdValues(
      String subject,
      String status,
      String senderAddress,
      String senderName,
      String replyToAddress,
      String body) {

    ChangeTemplateIdValues changeTemplateIdValues = new ChangeTemplateIdValues();

    changeTemplateIdValues.setSubject(subject);
    if (!status.isEmpty()) {
      changeTemplateIdValues.setStatus(status);
    }
    if (!senderAddress.isEmpty()) {
      changeTemplateIdValues.setSenderAddress(senderAddress);
    }
    if (!senderName.isEmpty()) {
      changeTemplateIdValues.setSenderName(senderName);
    }
    if (!replyToAddress.isEmpty()) {
      changeTemplateIdValues.setReplyToAddress(replyToAddress);
    }
    if (!body.isEmpty()) {
      changeTemplateIdValues.setBody(body);
    }

    return changeTemplateIdValues;
  }

  public ChangeNotificationIdValues ChangeNotificationIdValues(
      String subject,
      String status,
      String senderAddress,
      String senderName,
      String replyToAddress,
      String body,
      String targetUrl) {

    if (status.contains("oldStatus")) {
      status = status.replace("oldStatus", Utils.status);
    }
    if (body.contains("oldBody")) {
      body = body.replace("oldBody", Utils.body);
    }
    if (subject.contains("oldSubject")) {
      subject = subject.replace("oldSubject", Utils.subject);
    }

    ChangeNotificationIdValues changenotificationIdValues = new ChangeNotificationIdValues();

    changenotificationIdValues.setSubject(subject);
    changenotificationIdValues.setStatus(status);
    changenotificationIdValues.setSenderAddress(senderAddress);
    changenotificationIdValues.setSenderName(senderName);
    changenotificationIdValues.setReplyToAddress(replyToAddress);
    changenotificationIdValues.setBody(body);
    changenotificationIdValues.setTargetUrl(targetUrl);

    return changenotificationIdValues;
  }

  public String addMessageTypesPayload(String messageType) {
    if (messageType.isBlank() || messageType.isEmpty()) {
      return "[]";
    } else {
      return "[" + "\"" + messageType + "\"" + "]";
    }
  }
}
