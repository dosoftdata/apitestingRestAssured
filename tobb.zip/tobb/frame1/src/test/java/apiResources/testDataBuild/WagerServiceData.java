package apiResources.testDataBuild;

import apiResources.Utils;
import apiResources.pojo.requests.wagerService.CaptureBet;
import apiResources.pojo.requests.wagerService.PayWinningBet;
import apiResources.pojo.requests.wagerService.PlaceWager;
import apiResources.pojo.requests.wagerService.PlayBetFunds;
import apiResources.pojo.requests.wagerService.PlayBetFundsExtra;
import apiResources.pojo.requests.wagerService.CancelReservation;

import java.util.ArrayList;
import java.util.List;

public class WagerServiceData {

    public PlaceWager addWagerPayload(
            String gameType,
            int betType,
            int boardId,
            ArrayList<Integer> mainSelection,
            ArrayList<Integer> JokerSelection,
            int multipleDraws,
            String quickPick) {

        PlaceWager placeWager = new PlaceWager();
        PlaceWager.Wager wager = new PlaceWager.Wager();
        PlaceWager.ParticipatingDraws draws = new PlaceWager.ParticipatingDraws();

        // set Panels
        List<PlaceWager.Panel> panels = new ArrayList<>();
        PlaceWager.Panel mainPanel = new PlaceWager.Panel();
        PlaceWager.Panel jokerPanel = new PlaceWager.Panel();

        mainPanel.setSelection(mainSelection);
        panels.add(mainPanel);
        jokerPanel.setSelection(JokerSelection);
        panels.add(jokerPanel);

        // set Boards
        ArrayList<PlaceWager.Board> boards = new ArrayList<>();
        PlaceWager.Board board = new PlaceWager.Board();

        // meaning boardId is empty
        if (boardId != -99) {
            board.setBoardId(boardId);
        }
        board.setBetType(betType);
        board.setPanels(panels);
        boards.add(board);

        // set GameType,MultipleDraws,QuickPick,ParticipationDraws
        placeWager.setGameType(gameType);
        wager.setQuickPick(Boolean.parseBoolean(quickPick));

        if (multipleDraws != -99) {
            draws.setMultipleDraws(multipleDraws);
            wager.setParticipatingDraws(draws);
        }
        wager.setBoards(boards);
        placeWager.setWager(wager);

        return placeWager;
    }

    public List<PlaceWager> addMultipleWagerPayload(
            String gameType,
            int betType,
            int boardId,
            ArrayList<Integer> mainSelection,
            ArrayList<Integer> JokerSelection,
            String quickPick) {

        PlaceWager placeWager = new PlaceWager();
        PlaceWager.Wager wager = new PlaceWager.Wager();

        // set Panels
        List<PlaceWager.Panel> panels = new ArrayList<>();
        PlaceWager.Panel mainPanel = new PlaceWager.Panel();
        PlaceWager.Panel jokerPanel = new PlaceWager.Panel();

        mainPanel.setSelection(mainSelection);
        panels.add(mainPanel);
        jokerPanel.setSelection(JokerSelection);
        panels.add(jokerPanel);

        // set Boards
        ArrayList<PlaceWager.Board> boards = new ArrayList<>();
        PlaceWager.Board board = new PlaceWager.Board();

        // meaning boardId is empty
        if (boardId != -99) {
            board.setBoardId(boardId);
        }
        board.setBetType(betType);
        board.setPanels(panels);
        boards.add(board);

        // set GameType,MultipleDraws,QuickPick,ParticipationDraws
        placeWager.setGameType(gameType);
        wager.setQuickPick(Boolean.parseBoolean(quickPick));
        wager.setBoards(boards);
        placeWager.setWager(wager);

        ArrayList<PlaceWager> placeWagerList = new ArrayList<>();
        placeWagerList.add(placeWager);

        return placeWagerList;
    }

    public PayWinningBet addPayWinningPayload(
            int amount,
            int taxAmount,
            String currency,
            String description,
            String issued,
            String partialPayment,
            String productId) {
        PayWinningBet payWinningBet = new PayWinningBet();

        payWinningBet.setAmount(amount);
        payWinningBet.setDescription(description);
        payWinningBet.setCurrency(currency);
        payWinningBet.setIssued(issued);
        payWinningBet.setProductId(productId);
        payWinningBet.setPartialPayment(partialPayment);

        Utils utils = new Utils();
        Utils.referenceId = String.valueOf(utils.calculateRandomInteger(100000000, 999999999));
        payWinningBet.setReferenceId(Utils.referenceId);
        payWinningBet.setSerialNumber(Utils.serialNumber);
        payWinningBet.setTaxAmount(taxAmount);

        return payWinningBet;
    }

    public PlayBetFunds addPlayBetFundsPayload(
            float taxAmount,
            String gameId,
            float bonusAmount,
            String accountId,
            float amount,
            String currency,
            String issued,
            String productId,
            String type,
            String description,
            String autocapture,
            String status,
            String captured,
            String bonusPrizeId) {
        PlayBetFunds playBetFunds = new PlayBetFunds();

        // metadata bonusPrizeId
        if (bonusPrizeId != null && !bonusPrizeId.isEmpty()) {
            PlayBetFunds.Metadata metadata = new PlayBetFunds.Metadata();
            metadata.setBonusPrizeId(bonusPrizeId);
            playBetFunds.setMetadata(metadata);
        }
        if (type.equals("BUY") && autocapture.equals("true")) {
            Utils utils = new Utils();
            Utils.batchId = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));
            Utils.subBatchId = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));
            playBetFunds.setBatchId(Utils.batchId);
            playBetFunds.setSubBatchId(Utils.subBatchId);
        }
        // otherwise these fields are null and not shown
        if (type.equals("CANCEL")
                || type.equals("PRIZE_ROLLBACK")
                || type.equals("ADJUST")
                || type.equals("PRIZE")
                || type.equals("REFUND")) {
            playBetFunds.setBatchId(Utils.batchId);
            playBetFunds.setSubBatchId(Utils.subBatchId);
        }
        if (type.contains("PRIZE")) {
            playBetFunds.setTaxAmount(taxAmount);
        }

        // for Bonus
        if (gameId != null && !gameId.equals("")) {
            PlayBetFunds.Metadata metadata = new PlayBetFunds.Metadata();

            metadata.setBonusAmount(bonusAmount);
            metadata.setGameId(gameId);
            playBetFunds.setMetadata(metadata);
            playBetFunds.setBonusRollover(null);
            playBetFunds.setBonusPrizeId(Utils.bonusPrizeId);
        }

        playBetFunds.setAccountId(accountId);
        playBetFunds.setAmount(amount);
        playBetFunds.setCurrency(currency);
        playBetFunds.setIssued(issued);
        playBetFunds.setProductId(productId);
        playBetFunds.setType(type);
        playBetFunds.setDescription(description);

        playBetFunds.setAutocapture(Boolean.parseBoolean(autocapture));
        playBetFunds.setCaptured(Boolean.parseBoolean(captured));

        playBetFunds.setStatus(status);
        Utils utils = new Utils();
        Utils.referenceId2 = String.valueOf(utils.calculateRandomInteger(100000000, 999999999));

        playBetFunds.setReferenceId(Utils.referenceId2);

        return playBetFunds;
    }

    public PlayBetFundsExtra addPlayBetFundsExtraPayload(
            float taxAmount,
            String gameId,
            float bonusAmount,
            String accountId,
            float amount,
            String currency,
            String issued,
            String productId,
            String type,
            String description,
            String autocapture,
            String status,
            String captured,
            String bonusRollover,
            String bonusPrizeId) {
        PlayBetFundsExtra playBetFundsExtra = new PlayBetFundsExtra();

        // metadata bonusPrizeId
        if (bonusPrizeId != null && !bonusPrizeId.isEmpty()) {
            PlayBetFundsExtra.Metadata metadata = new PlayBetFundsExtra.Metadata();
            metadata.setBonusPrizeId(bonusPrizeId);
            playBetFundsExtra.setMetadata(metadata);
        }

        if (type.equals("BUY") && playBetFundsExtra.isAutocapture()) {
            Utils utils = new Utils();
            Utils.batchId = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));
            Utils.subBatchId = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));
            playBetFundsExtra.setBatchId(Utils.batchId);
            playBetFundsExtra.setSubBatchId(Utils.subBatchId);
        }
        // otherwise these fields are null and not shown
        if (type.equals("CANCEL")
                || type.equals("PRIZE_ROLLBACK")
                || type.equals("ADJUST")
                || type.equals("PRIZE")
                || type.equals("REFUND")
                || (type.equals("BUY") && playBetFundsExtra.isAutocapture())) {
            playBetFundsExtra.setBatchId(Utils.batchId);
            playBetFundsExtra.setSubBatchId(Utils.subBatchId);
        }

        if (type.contains("PRIZE")) {
            playBetFundsExtra.setTaxAmount(taxAmount);
        }

        // for Bonus
        if (gameId != null && !gameId.equals("")) {
            PlayBetFundsExtra.Metadata metadata = new PlayBetFundsExtra.Metadata();

            metadata.setBonusAmount(bonusAmount);
            metadata.setGameId(gameId);
            playBetFundsExtra.setMetadata(metadata);
            playBetFundsExtra.setBonusRollover(null);
            playBetFundsExtra.setBonusPrizeId(Utils.bonusPrizeId);
        }

        playBetFundsExtra.setAccountId(accountId);
        playBetFundsExtra.setAmount(amount);
        playBetFundsExtra.setCurrency(currency);
        playBetFundsExtra.setIssued(issued);
        playBetFundsExtra.setProductId(productId);
        playBetFundsExtra.setType(type);
        playBetFundsExtra.setDescription(description);
        playBetFundsExtra.setAutocapture(Boolean.parseBoolean(autocapture));
        playBetFundsExtra.setStatus(status);
        playBetFundsExtra.setCaptured(Boolean.parseBoolean(captured));
        playBetFundsExtra.setBonusRollover(bonusRollover);
        Utils utils = new Utils();
        Utils.referenceId2 = String.valueOf(utils.calculateRandomInteger(100000000, 999999999));

        playBetFundsExtra.setReferenceId(Utils.referenceId2);

        return playBetFundsExtra;
    }

    public CaptureBet addCaptureBetPayload(float amount) {

        CaptureBet captureBet = new CaptureBet();
        Utils utils = new Utils();
        Utils.batchId = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));
        Utils.subBatchId = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));

        captureBet.setAmount(amount);
        captureBet.setBatchId(Utils.batchId);
        captureBet.setSubBatchId(Utils.subBatchId);
        return captureBet;
    }

    public CancelReservation addCancelReservationPayload(String reason) {
        CancelReservation cancelReservation = new CancelReservation();
        Utils utils = new Utils();
        Utils.batchId = String.valueOf(utils.calculateRandomInteger(1000000, 9999999));

        cancelReservation.setBatchId(Utils.batchId);
        cancelReservation.setReason(reason);
        return cancelReservation;
    }
}
