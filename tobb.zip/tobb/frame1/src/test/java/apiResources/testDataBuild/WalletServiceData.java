package apiResources.testDataBuild;

import apiResources.Utils;
import apiResources.pojo.requests.walletService.AccessOperation;
import apiResources.pojo.requests.walletService.*;
import java.util.List;
import java.util.ArrayList;

import static apiResources.Utils.*;

public class WalletServiceData {

  public String postDepositViaPaymentWithId(String id, String code) {

    String paymentCodeNum = null;
    String paymentCodeId = null;
    if (code.equalsIgnoreCase("NonExclusive")) {
      paymentCodeNum = paymentCodeNonExclusive;
      paymentCodeId = "PAYMENT_CODE_NON_EXCLUSIVE";
    } else if (code.equalsIgnoreCase("Exclusive")) {
      paymentCodeNum = Utils.paymentCodeExclusive;
      paymentCodeId = "PAYMENT_CODE_EXCLUSIVE";
    }
    return "{\n"
        + "\t\"action\" : \"COMMIT\",\n"
        + "\t\"operation\" : \"WALLET_DEPOSIT\",\n"
        + "\t\"channel\" : \"WEB\",\n"
        + "\t\"paymentType\" : \"PT_TRANSFER_IN\",\n"
        + "\t\"paymentMethod\" : {\n"
        + "        \"type\" : \"PAYMENT_CODE\",\n"
        + "        \"id\" : \""
        + paymentCodeId
        + "\",\n"
        + "        \"card\" : null,\n"
        + "        \"paymentCode\":{\"paymentCode\":\""
        + paymentCodeNum
        + "\"},\n"
        + "        \"voucher\" : null\n"
        + "    },\n"
        + "\t\"paymentId\" : null,\n"
        + "\t\"pspPaymentId\" : \"pspId.1\",\n"
        + "\t\"amount\" : {\n"
        + "    \"amount\" : 10,\n"
        + "    \"currency\" : \"EUR\"\n"
        + "\t},\n"
        + "\t\"serviceCost\" : {\n"
        + "\t\t\"amount\" : 1,\n"
        + "\t\t\"currency\" : \"EUR\"\n"
        + "\t},\n"
        + "\t\"owner\" : {\n"
        + "\t\t\"id\" : \""
        + id
        + "\",\n"
        + "\t\t\"type\" : 1\n"
        + "\t},\n"
        + "\t\"issuer\" :  null,\n"
        + "\t\"pspId\" : \"voucherPSPDemo\",\n"
        + "\t\"pspTargetId\" : \"pspTargetId\",\n"
        + "\t\"extraParams\" : null,\n"
        + "\t\"forceReview\" : false,\n"
        + "\t\"paybankId\" : \"123\"\n"
        + "}";
  }

  public String postDepositViaPayment(String code) {

    String paymentCodeNum = null;
    String paymentCodeId = null;
    if (code.equalsIgnoreCase("NonExclusive")) {
      paymentCodeNum = paymentCodeNonExclusive;
      paymentCodeId = "PAYMENT_CODE_NON_EXCLUSIVE";
    } else if (code.equalsIgnoreCase("Exclusive")) {
      paymentCodeNum = Utils.paymentCodeExclusive;
      paymentCodeId = "PAYMENT_CODE_EXCLUSIVE";
    }
    return "{\n"
        + "\t\"action\" : \"COMMIT\",\n"
        + "\t\"operation\" : \"WALLET_DEPOSIT\",\n"
        + "\t\"channel\" : \"WEB\",\n"
        + "\t\"paymentType\" : \"PT_TRANSFER_IN\",\n"
        + "\t\"paymentMethod\" : {\n"
        + "        \"type\" : \"PAYMENT_CODE\",\n"
        + "        \"id\" : \""
        + paymentCodeId
        + "\",\n"
        + "        \"card\" : null,\n"
        + "        \"paymentCode\":{\"paymentCode\":\""
        + paymentCodeNum
        + "\"},\n"
        + "        \"voucher\" : null\n"
        + "    },\n"
        + "\t\"paymentId\" : null,\n"
        + "\t\"pspPaymentId\" : \"pspId.1\",\n"
        + "\t\"amount\" : {\n"
        + "    \"amount\" : 10,\n"
        + "    \"currency\" : \"EUR\"\n"
        + "\t},\n"
        + "\t\"serviceCost\" : {\n"
        + "\t\t\"amount\" : 1,\n"
        + "\t\t\"currency\" : \"EUR\"\n"
        + "\t},\n"
        + "\t\"owner\" : {\n"
        + "\t\t\"id\" : \""
        + playerId
        + "\",\n"
        + "\t\t\"type\" : 1\n"
        + "\t},\n"
        + "\t\"issuer\" :  null,\n"
        + "\t\"pspId\" : \"voucherPSPDemo\",\n"
        + "\t\"pspTargetId\" : \"pspTargetId\",\n"
        + "\t\"extraParams\" : null,\n"
        + "\t\"forceReview\" : false,\n"
        + "\t\"paybankId\" : \"123\"\n"
        + "}";
  }

  public WithdrawalViaCard withdrawalViaCard(
      int amount, String action, String operation, String paymentMethodType, String viaMethod) {

    String id = null;
    if (viaMethod.equalsIgnoreCase("CARD")) {
      id = cardFingerprint;
    } else if (viaMethod.equalsIgnoreCase("IBAN")) {
      id = "DEFAULT_OUT";
    }

    WithdrawalViaCard withdrawalViaCard = new WithdrawalViaCard();
    WithdrawalViaCard.PaymentMethod paymentMethod = new WithdrawalViaCard.PaymentMethod();
    WithdrawalViaCard.PaymentMethod.BankAccount bankAccount =
        new WithdrawalViaCard.PaymentMethod.BankAccount();
    WithdrawalViaCard.Amount amount1 = new WithdrawalViaCard.Amount();
    WithdrawalViaCard.ServiceCost serviceCost = new WithdrawalViaCard.ServiceCost();
    WithdrawalViaCard.Owner owner = new WithdrawalViaCard.Owner();

    paymentMethod.setType(paymentMethodType);
    paymentMethod.setId(id);
    paymentMethod.setCard(null);

    paymentMethod.setBankAccount(bankAccount);
    bankAccount.setBankId("112233");

    amount1.setAmount(amount);
    amount1.setCurrency("EUR");

    paymentMethod.setVoucher(null);

    serviceCost.setAmount(1);
    serviceCost.setCurrency("EUR");

    owner.setId(playerId);
    owner.setType(1);

    withdrawalViaCard.setAction(action);
    withdrawalViaCard.setOperation(operation);
    withdrawalViaCard.setChannel("WEB");
    withdrawalViaCard.setPaymentType("PT_TRANSFER_OUT");
    withdrawalViaCard.setPaymentMethod(paymentMethod);
    withdrawalViaCard.setServiceCost(serviceCost);
    withdrawalViaCard.setOwner(owner);

    withdrawalViaCard.setPaymentId(null);
    withdrawalViaCard.setPspPaymentId("pspId.1");
    withdrawalViaCard.setAmount(amount1);

    withdrawalViaCard.setIssuer(null);
    withdrawalViaCard.setPspId("TORA");
    withdrawalViaCard.setPspTargetId("SEPA");
    withdrawalViaCard.setExtraParams(null);
    withdrawalViaCard.setForceReview(false);
    withdrawalViaCard.setPaybankId("123");

    return withdrawalViaCard;
  }

  public DepositViaPaymentCode postDepositViaPaymentCode(
      String paymentMethodId,
      String paymentCode,
      int amount,
      String action,
      String operation,
      String paymentMethodType) {

    DepositViaPaymentCode depositViaPaymentCode = new DepositViaPaymentCode();
    DepositViaPaymentCode.PaymentMethod paymentMethod = new DepositViaPaymentCode.PaymentMethod();
    DepositViaPaymentCode.PaymentMethod.PaymentCode paymentCode1 =
        new DepositViaPaymentCode.PaymentMethod.PaymentCode();
    DepositViaPaymentCode.Amount amount1 = new DepositViaPaymentCode.Amount();
    DepositViaPaymentCode.ServiceCost serviceCost = new DepositViaPaymentCode.ServiceCost();
    DepositViaPaymentCode.Owner owner = new DepositViaPaymentCode.Owner();

    String paymentCodeNum = null;

    if (paymentCode.equalsIgnoreCase("NonExclusive")) {
      paymentCodeNum = paymentCodeNonExclusive;
    } else if (paymentCode.equalsIgnoreCase("Exclusive")) {
      paymentCodeNum = Utils.paymentCodeExclusive;
    }

    paymentMethod.setType(paymentMethodType);
    paymentMethod.setId(paymentMethodId);
    paymentMethod.setCard(null);

    paymentMethod.setPaymentCode(paymentCode1);
    paymentCode1.setPaymentCode(paymentCodeNum);

    amount1.setAmount(amount);
    amount1.setCurrency("EUR");

    paymentMethod.setVoucher(null);

    serviceCost.setAmount(1);
    serviceCost.setCurrency("EUR");

    owner.setId(playerId);
    owner.setType(1);

    depositViaPaymentCode.setAction(action);
    depositViaPaymentCode.setOperation(operation);
    depositViaPaymentCode.setChannel("WEB");
    depositViaPaymentCode.setPaymentType("PT_TRANSFER_IN");
    depositViaPaymentCode.setPaymentMethod(paymentMethod);
    depositViaPaymentCode.setServiceCost(serviceCost);
    depositViaPaymentCode.setOwner(owner);

    depositViaPaymentCode.setPaymentId(null);
    depositViaPaymentCode.setPspPaymentId("pspId.1");
    depositViaPaymentCode.setAmount(amount1);

    depositViaPaymentCode.setIssuer(null);
    depositViaPaymentCode.setPspId("voucherPSPDemo");
    depositViaPaymentCode.setPspTargetId("pspTargetId");
    depositViaPaymentCode.setExtraParams(null);
    depositViaPaymentCode.setForceReview(false);
    depositViaPaymentCode.setPaybankId("123");

    return depositViaPaymentCode;
  }

  public DepositViaBankAccount postDepositViaBankAccount(
      String paymentMethodId,
      String paymentCode,
      String amount,
      String action,
      String operation,
      String paymentType,
      String paymentMethodType,
      String bankId,
      String pspId,
      String pspTargetId,
      String currency,
      String owner) {

    DepositViaBankAccount depositViaBankAccount = new DepositViaBankAccount();
    DepositViaBankAccount.PaymentMethod paymentMethod = new DepositViaBankAccount.PaymentMethod();
    DepositViaBankAccount.PaymentMethod.BankAccount bankAccount1 =
        new DepositViaBankAccount.PaymentMethod.BankAccount();
    DepositViaBankAccount.Amount amount1 = new DepositViaBankAccount.Amount();
    DepositViaBankAccount.ServiceCost serviceCost = new DepositViaBankAccount.ServiceCost();
    DepositViaBankAccount.Owner owner1 = new DepositViaBankAccount.Owner();

    String paymentCodeNum = null;

    //    if (paymentCode.equalsIgnoreCase("NonExclusive")) {
    //      paymentCodeNum = paymentCodeNonExclusive;
    //    } else if (paymentCode.equalsIgnoreCase("Exclusive")) {
    //      paymentCodeNum = Utils.paymentCodeExclusive;
    //    }

    paymentMethod.setType(paymentMethodType);
    paymentMethod.setId(paymentMethodId);
    paymentMethod.setCard(null);

    paymentMethod.setBankAccount(bankAccount1);
    bankAccount1.setBankId(bankId);

    if (amount.equalsIgnoreCase(("null"))) {
      amount = null;
    }
    amount1.setAmount(amount);
    amount1.setCurrency("EUR");

    paymentMethod.setVoucher(null);

    serviceCost.setAmount(1);
    serviceCost.setCurrency("EUR");

    if (owner.equals("empty")) {
      owner1.setId("");
    } else if (owner.equals("PlayerIdLimited")) {
      owner1.setId(playerId);
    } else if (owner.equals("test")) {
      owner1.setId("123");
    }

    owner1.setType(1);

    depositViaBankAccount.setAction(action);
    depositViaBankAccount.setOperation(operation);
    depositViaBankAccount.setChannel("WEB");
    depositViaBankAccount.setPaymentType(paymentType);
    depositViaBankAccount.setPaymentMethod(paymentMethod);
    depositViaBankAccount.setServiceCost(serviceCost);
    depositViaBankAccount.setOwner(owner1);

    depositViaBankAccount.setPaymentId(null);
    depositViaBankAccount.setPspPaymentId("30001");
    depositViaBankAccount.setAmount(amount1);

    depositViaBankAccount.setIssuer(null);
    depositViaBankAccount.setPspId(pspId);
    depositViaBankAccount.setPspTargetId(pspTargetId);
    depositViaBankAccount.setExtraParams(null);
    depositViaBankAccount.setForceReview(false);
    depositViaBankAccount.setPaybankId("123");

    return depositViaBankAccount;
  }

  public String postDepositViaCard(String amount) {

    return "{\n"
        + "\t\"amount\": \""
        + amount
        + "\",\n"
        + "\t\"currency\": \"EUR\",\n"
        + "\t\"paymentMethodType\": \"CARD\",\n"
        + "\t\"paymentType\": \"PT_TRANSFER_IN\"\n"
        + "}";
  }

  public Paypal postDepositViaPaypal(
      String amount, String payerId, String email, String fullName, String country) {

    Paypal paypalDeposit = new Paypal();
    Paypal.PaypalInfo paypalInfo = new Paypal.PaypalInfo();
    paypalInfo.setCountry(country);
    paypalInfo.setFull_name(fullName);
    paypalInfo.setEmail(email);
    paypalInfo.setPayer_id(payerId);

    paypalDeposit.setAmount(amount);
    paypalDeposit.setCurrency("EUR");
    paypalDeposit.setPaymentMethodType("PAYPAL");
    paypalDeposit.setPaymentMethodType("PT_TRANSFER_IN");
    return paypalDeposit;
  }

  //  public String postDepositCardOwnerIdEmpty() {
  //    return "{\n"
  //            + "\t\"action\": \"PREPARE\",\n"
  //            + "\t\"operation\": \"WALLET_DEPOSIT\",\n"
  //            + "\t\"channel\": \"WEB\",\n"
  //            + "\t\"paymentType\": \"PT_TRANSFER_IN\",\n"
  //            + "\t\"paymentMethod\": {\n"
  //            + "\t\t\"type\": \"BANK_ACCOUNT\",\n"
  //            + "\t\t\"id\": \"PAYMENT_CODE_EXCLUSIVE\",\n"
  //            + "\t\t\"card\": null,\n"
  //            + "\t\t\"bankAccount\": {\n"
  //            + "\t\t\t\"bankId\": \"112233\"\n"
  //            + "\t\t},\n"
  //            + "\t\t\"voucher\": null\n"
  //            + "\t},\n"
  //            + "\t\"paymentId\": null,\n"
  //            + "\t\"pspPaymentId\": \"pspId.1\",\n"
  //            + "\t\"amount\": {\n"
  //            + "\t\t\"amount\": 800.0,\n"
  //            + "\t\t\"currency\": \"EUR\"\n"
  //            + "\t},\n"
  //            + "\t\"serviceCost\": {\n"
  //            + "\t\t\"amount\": 1,\n"
  //            + "\t\t\"currency\": \"EUR\"\n"
  //            + "\t},\n"
  //            + "\t\"owner\": {\n"
  //            + "\t\t\"id\": \"\",\n"
  //            + "\t\t\"type\": 55\n"
  //            + "\t},\n"
  //            + "\t\"issuer\": null,\n"
  //            + "\t\"pspId\": \"voucherPSPDemo\",\n"
  //            + "\t\"pspTargetId\": \"pspTargetId\",\n"
  //            + "\t\"extraParams\": null,\n"
  //            + "\t\"forceReview\": false,\n"
  //            + "\t\"paybankId\": \"123\"\n"
  //            + "}";
  //  }

  //  public String postDepositAmountNull() {
  //    return "{\n"
  //            + "\t\"action\": \"PREPARE\",\n"
  //            + "\t\"operation\": \"WALLET_DEPOSIT\",\n"
  //            + "\t\"channel\": \"WEB\",\n"
  //            + "\t\"paymentType\": \"PT_TRANSFER_IN\",\n"
  //            + "\t\"paymentMethod\": {\n"
  //            + "\t\t\"type\": \"BANK_ACCOUNT\",\n"
  //            + "\t\t\"id\": \"PAYMENT_CODE_EXCLUSIVE\",\n"
  //            + "\t\t\"card\": null,\n"
  //            + "\t\t\"bankAccount\": {\n"
  //            + "\t\t\t\"bankId\": \"112233\"\n"
  //            + "\t\t},\n"
  //            + "\t\t\"voucher\": null\n"
  //            + "\t},\n"
  //            + "\t\"paymentId\": null,\n"
  //            + "\t\"pspPaymentId\": \"pspId.1\",\n"
  //            + "\t\"amount\": {\n"
  //            + "\t\t\"amount\": null,\n"
  //            + "\t\t\"currency\": \"EUR\"\n"
  //            + "\t},\n"
  //            + "\t\"serviceCost\": {\n"
  //            + "\t\t\"amount\": 1,\n"
  //            + "\t\t\"currency\": \"EUR\"\n"
  //            + "\t},\n"
  //            + "\t\"owner\": {\n"
  //            + "\t\t\"id\": \"{{playerIdLimited}}\",\n"
  //            + "\t\t\"type\": 1\n"
  //            + "\t},\n"
  //            + "\t\"issuer\": null,\n"
  //            + "\t\"pspId\": \"voucherPSPDemo\",\n"
  //            + "\t\"pspTargetId\": \"pspTargetId\",\n"
  //            + "\t\"extraParams\": null,\n"
  //            + "\t\"forceReview\": false,\n"
  //            + "\t\"paybankId\": \"123\"\n"
  //            + "}";
  //  }

  public String approveWithdrawal(Integer amount) {

    return "{\n"
        + "\t\"serviceCost\" : {\n"
        + "\t\t\"amount\" : "
        + amount
        + ",\n"
        + "\t\t\"currency\" : \"EUR\"\n"
        + "\t},\n"
        + " \n"
        + "\t\"forceReview\" : false,\n"
        + "\t\"auditData\" : null\n"
        + "}";
  }

  public String approveWithdrawalCC(String action) {

    return "{ \"action\":" + "\"" + action + "\"" + "}";
  }

  public String verifyPaymentViaToraWebhooks(Integer amount) {

    return "{\n"
        + "    \"event_id\": \"evt_AAE1llwFk0Tik7EISTnwyGGI\",\n"
        + "    \"event\": \"transfer.successful\",\n"
        + "    \"data\": {\n"
        + "        \"id\": \"trf_TvaagAweAUilRcLia9ErSYhS\",\n"
        + "        \"object\": \"transfer\",\n"
        + "        \"status\": \"successful\",\n"
        + "        \"status_reason\": null,\n"
        + "        \"amount\": "
        + amount
        + ",\n"
        + "        \"currency\": \"EUR\",\n"
        + "        \"description\": \"Wallet withdrawal id:1313544\",\n"
        + "        \"meta\": {\n"
        + "            \"playerId\": \""
        + playerId
        + "\",\n"
        + "            \"paymentId\": \""
        + withdrawal_paymentId
        + "\"\n"
        + "        },\n"
        + "        \"created_at\": \"2022-11-10T15:15:26+00:00\",\n"
        + "        \"updated_at\": \"2022-11-10T09:05:07+00:00\",\n"
        + "        \"recipient\": \"bank\",\n"
        + "        \"recipient_info\": {\n"
        + "\t\t\t\"holder_name\": \"TEST PROD\",\n"
        + "\t\t\t\"exp_year\": \"2030\",\n"
        + "\t\t\t\"exp_month\": \"12\",\n"
        + "\t\t\t\"last4\": \"6417\",\n"
        + "\t\t\t\"brand\": \"master\",\n"
        + "\t\t\t\"bin\": \"558868\",\n"
        + "\t\t\t\"fingerprint\": \""
        + cardFingerprint
        + "\",\n"
        + "\t\t\t\"errorCode\": \"0\",\n"
        + "\t\t\t\"errorMessage\": \"Success\",\n"
        + "\t\t\t\"orderNumber\": \"pmt_"
        + withdrawal_paymentId
        + "\",\n"
        + "\t\t\t\"orderStatus\": 2,\n"
        + "\t\t\t\"actionCode\": 0,\n"
        + "\t\t\t\"actionCodeDescription\": \"Transaction completed successfully.\",\n"
        + "\t\t\t\"amount\": "
        + amount
        + ",\n"
        + "\t\t\t\"currency\": \"EUR\",\n"
        + "\t\t\t\"date\": 1503488574032,\n"
        + "\t\t\t\"orderDescription\": \"testDescription\",\n"
        + "\t\t\t\"merchantOrderParams\": {\n"
        + "\t\t\t\t\"name\": \"eci\",\n"
        + "\t\t\t\t\"value\": \"07\"\n"
        + "\t\t\t},\n"
        + "\t\t\t\"attributes\": {\n"
        + "\t\t\t\t\"name\": \"mdOrder\",\n"
        + "\t\t\t\t\"value\": \"f11c8534\"\n"
        + "\t\t\t},\n"
        + "\t\t\t\"cardAuthInfo\": {\n"
        + "\t\t\t\t\"expiration\": \"120625\",\n"
        + "\t\t\t    \"cardholderName\": \"TEST PROD\",\n"
        + "\t\t\t    \"approvalCode\": \"696969\",\n"
        + "\t\t\t    \"pan\": \"558868**6417\"\n"
        + "\t\t\t},\n"
        + "\t\t\t\"authDateTime\": 1503488574032,\n"
        + "\t\t\t\"terminalId\": \"90800101\",\n"
        + "\t\t\t\"authRefNum\": \"000062806528\",\n"
        + "\t\t\t\"paymentAmountInfo\": {\n"
        + "\t\t\t\t\"paymentState\": \"DEPOSITED\",\n"
        + "\t\t\t\t\"approvedAmount\": 1200,\n"
        + "\t\t\t\t\"depositedAmount\": 1200,\n"
        + "\t\t\t\t\"refundedAmount\": 0\n"
        + "\t\t\t},\n"
        + "\t\t\t\"bankInfo\": {\n"
        + "\t\t\t\t\"bankName\": \"CRBAGRA0\",\n"
        + "\t\t\t\t\"bankCountryCode\": \"GR\",\n"
        + "\t\t\t\t\"bankCountryName\": \"Greece\"\n"
        + "\t\t\t},\n"
        + "\t\t\t\"utrnno\": 62806528,\n"
        + "\t\t\t\"businessDate\": \"170823\"\n"
        + "        },\n"
        + "        \"payment_id\": \""
        + withdrawal_paymentId
        + "\",\n"
        + "        \"scheduled_at\": \"2022-11-10\",\n"
        + "        \"transaction_id\": null\n"
        + "    },\n"
        + "    \"webhook_token\": \"hok_viVdup2q199imTMjg0zJxaSU\"\n"
        + "}";
  }

  public String commitCardDepositToTora() {

    return "{\n" + "\t\"token\": \"" + depositTokenId + "\"\n" + "}";
  }

  public CommitWithdrawal commitWithdrawalToTora(
      int amount, String currency, boolean forceReview, String auditData) {

    CommitWithdrawal commitWithdrawal = new CommitWithdrawal();

    if (!auditData.equals("null")) {
      commitWithdrawal.setAuditData(auditData);
    }
    commitWithdrawal.setForceReview(forceReview);

    CommitWithdrawal.ServiceCost serviceCost = new CommitWithdrawal.ServiceCost();
    serviceCost.setAmount(amount);
    serviceCost.setCurrency(currency);

    commitWithdrawal.setServiceCost(serviceCost);

    return commitWithdrawal;
  }

  public String setMasterCardDetails(
      String amount,
      String cardNumber,
      String holderName,
      String cvv,
      String exp_month,
      String exp_year,
      String currency,
      String primaryKey) {

    return "{\n"
        + "\t\"card\":{\n"
        + "\t\t\"number\":\""
        + cardNumber
        + "\",\n"
        + "\t\t\"holder_name\":\""
        + holderName
        + "\",\n"
        + "\t\t\"cvv\":\""
        + cvv
        + "\",\n"
        + "\t\t\"exp_month\":\""
        + exp_month
        + "\",\n"
        + "\t\t\"exp_year\":\""
        + exp_year
        + "\"\n"
        + "\t},\n"
        + "\t\n"
        + "\t\"amount\":\""
        + amount
        + "\",\n"
        + "\t\"pk\": \""
        + primaryKey
        + "\",\n"
        + "\t\"currency\":\""
        + currency
        + "\",\n"
        + "\t\"merchant_reference\":\""
        + paymentIdViaPaymentCard
        + "\",\n"
        + "\t\"signature\":\""
        + signature
        + "\"\n"
        + "}";
  }

  public ManualAdjustWallet manualAdjustWallet(
      String transactionType,
      String transactionSubType,
      String productId,
      String operation,
      String amount,
      String transactionBetweenWallets,
      String wallet) {
    ManualAdjustWallet manualAdjustWallet = new ManualAdjustWallet();
    if (wallet.equalsIgnoreCase("Lottery wallet")) {
      if (amount.equalsIgnoreCase("0")) {

        manualAdjustWallet.setTransactionType(transactionType);
        manualAdjustWallet.setTransactionSubType(transactionSubType);
        manualAdjustWallet.setReason("Closing account manual adjustment");
        manualAdjustWallet.setProductId(productId);
        manualAdjustWallet.setOperation(operation);
        manualAdjustWallet.setAmount(exclWalletUnspentDeposits);
        manualAdjustWallet.setCurrency("EUR");
      } else {
        manualAdjustWallet.setTransactionType(transactionType);
        manualAdjustWallet.setTransactionSubType(transactionSubType);
        manualAdjustWallet.setReason("Closing account manual adjustment");
        manualAdjustWallet.setProductId(productId);
        manualAdjustWallet.setOperation(operation);
        manualAdjustWallet.setAmount(amount);
        manualAdjustWallet.setCurrency("EUR");
      }
    } else if (wallet.equalsIgnoreCase("Betting wallet")) {
      if (amount.equalsIgnoreCase("0")) {

        manualAdjustWallet.setTransactionType(transactionType);
        manualAdjustWallet.setTransactionSubType(transactionSubType);
        manualAdjustWallet.setReason("Casino Tax Withhold U/B");
        manualAdjustWallet.setProductId(productId);
        manualAdjustWallet.setOperation(operation);
        manualAdjustWallet.setAmount(nonExclWalletUnspentDeposits);
        manualAdjustWallet.setCurrency("EUR");

        if (!transactionBetweenWallets.isEmpty()) {
          manualAdjustWallet.setTransactionBetweenWallets(
              Boolean.parseBoolean(transactionBetweenWallets));
        }
      } else {
        manualAdjustWallet.setTransactionType(transactionType);
        manualAdjustWallet.setTransactionSubType(transactionSubType);
        manualAdjustWallet.setReason("Casino Tax Withhold U/B");
        manualAdjustWallet.setProductId(productId);
        manualAdjustWallet.setOperation(operation);
        manualAdjustWallet.setAmount(amount);
        manualAdjustWallet.setCurrency("EUR");
        if (!transactionBetweenWallets.isEmpty()) {
          manualAdjustWallet.setTransactionBetweenWallets(
              Boolean.parseBoolean(transactionBetweenWallets));
        }
      }
    } else if (wallet.equalsIgnoreCase("Legacy wallet")) {
      manualAdjustWallet.setTransactionType(transactionType);
      manualAdjustWallet.setTransactionSubType(transactionSubType);
      manualAdjustWallet.setReason("Bad debt write-off");
      manualAdjustWallet.setProductId(productId);
      manualAdjustWallet.setOperation(operation);
      manualAdjustWallet.setAmount(amount);
      manualAdjustWallet.setCurrency("EUR");
    }
    return manualAdjustWallet;
  }

  public PostWalletFunds PostWalletFunds(
      String accountId,
      int amount,
      String currency,
      String issued,
      String productId,
      String type,
      String description,
      String autocapture,
      String status,
      String captured,
      String batchId) {
    PostWalletFunds postWalletFunds = new PostWalletFunds();

    postWalletFunds.setAccountId(accountId);
    postWalletFunds.setAmount(amount);
    postWalletFunds.setCurrency(currency);
    postWalletFunds.setIssued(issued);
    postWalletFunds.setProductId(productId);
    postWalletFunds.setType(type);
    postWalletFunds.setDescription(description);
    postWalletFunds.setAutocapture(Boolean.parseBoolean(autocapture));
    postWalletFunds.setStatus(status);
    postWalletFunds.setCaptured(Boolean.parseBoolean(captured));

    Utils utils = new Utils();
    walletFundsReferenceId = String.valueOf(utils.calculateRandomInteger(100000000, 999999999));

    postWalletFunds.setReferenceId(walletFundsReferenceId);
    postWalletFunds.setBatchId(batchId);

    return postWalletFunds;
  }

  public Transaction createTransaction(
      String issued, String type, String amount, String productId) {
    Transaction transaction = new Transaction();
    Utils utils = new Utils();
    int random_integer = utils.calculateRandomInteger(10000, 99999);

    if (issued.equalsIgnoreCase("datenow")) {
      transaction.setIssued(utils.calculateDateNowInSecondsToString());
    } else {
      transaction.setIssued(issued);
    }
    transaction.setType(type);
    transaction.setAmount(amount);
    transaction.setReferenceId(String.valueOf(random_integer));
    transaction.setCurrency("EUR");
    transaction.setDescription("A rest Assured Transaction");
    transaction.setProductId(productId);

    return transaction;
  }

  public BettingTransaction createBettingTransaction(
      String issued,
      int prizeLevel,
      String type,
      String amount,
      String productId,
      String currency,
      String description,
      String fromDescription,
      String toDescription,
      String state,
      String batchId,
      String subBatchId,
      String transactionId,
      String callerServiceProviderId,
      boolean autocapture,
      String metadataValue) {

    BettingTransaction bettingTransaction = new BettingTransaction();
    Utils utils = new Utils();
    int random_integer = utils.calculateRandomInteger(10000, 99999);
    BettingTransaction.Metadata metadata = new BettingTransaction.Metadata();

    if (issued.equalsIgnoreCase("datenow")) {
      bettingTransaction.setIssued(utils.calculateDateNowInSecondsToString());
    } else {
      bettingTransaction.setIssued(issued);
    }

    bettingTransaction.setPrizeLevel(prizeLevel);
    bettingTransaction.setType(type);
    bettingTransaction.setAmount(amount);
    bettingTransaction.setReferenceId(String.valueOf(random_integer));
    bettingTransaction.setCurrency(currency);
    bettingTransaction.setDescription(description);
    bettingTransaction.setProductId(productId);
    bettingTransaction.setFromDescription(fromDescription);
    bettingTransaction.setToDescription(toDescription);
    bettingTransaction.setState(state);
    bettingTransaction.setBatchId(batchId);
    bettingTransaction.setSubBatchId(subBatchId);
    bettingTransaction.setTransactionId(transactionId);
    bettingTransaction.setCallerServiceProviderId(callerServiceProviderId);
    bettingTransaction.setAutocapture(autocapture);

    metadata.setValue(metadataValue);
    bettingTransaction.setMetadata(metadata);
    return bettingTransaction;
  }

  public RestrictUser Restrictuser(
      String depositId, String depositAccessType, String withdrawId, String withdrawAccessType) {
    RestrictUser accessRestrictions = new RestrictUser();

    RestrictUser.AccessDetail depositDetail = new RestrictUser.AccessDetail();
    depositDetail.setId(depositId);
    depositDetail.setAccessType(depositAccessType);

    RestrictUser.AccessDetail withdrawDetail = new RestrictUser.AccessDetail();
    withdrawDetail.setId(withdrawId);
    withdrawDetail.setAccessType(withdrawAccessType);
    List<RestrictUser.AccessDetail> depositList = new ArrayList<>();
    depositList.add(depositDetail);

    List<RestrictUser.AccessDetail> withdrawList = new ArrayList<>();
    withdrawList.add(withdrawDetail);

    accessRestrictions.setDeposit(depositList);
    accessRestrictions.setWithdraw(withdrawList);

    return accessRestrictions;
  }

  public String addVerifyGrandprizePayment(String paymentId) {
    return "{\n" + "    \"bankPaymentId\": " + "\"" + paymentId + "\"" + "\n}";
  }

  // same object for Account oppening/closing
  public CloseAccount addCloseAccount(
      String status, String statusDescription, String statusReason) {
    CloseAccount closeAccount = new CloseAccount();

    closeAccount.setStatus(status);
    closeAccount.setStatusReason(statusReason);
    closeAccount.setStatusDescription(statusDescription);

    return closeAccount;
  }

  public CancelTransaction cancelTransaction(String id, String referenceId) {
    CancelTransaction cancelTransaction = new CancelTransaction();
    cancelTransaction.setId(id);
    cancelTransaction.setReferenceId(referenceId);
    return cancelTransaction;
  }

  public CommitPaymentMethod commitPaymentMethodToWallet(
      String serviceProviderId,
      String paymentMethodType,
      String directionIn,
      String paymentMethodId,
      String serviceProviderTargetId,
      String email,
      String createdById,
      int createdByType,
      String updatedById,
      int updatedByType) {

    CommitPaymentMethod commitPaymentMethod = new CommitPaymentMethod();
    commitPaymentMethod.setServiceProviderId(serviceProviderId);
    commitPaymentMethod.setPaymentMethodType(paymentMethodType);
    commitPaymentMethod.setDirectionIn(directionIn);
    commitPaymentMethod.setPaymentMethodId(paymentMethodId);
    commitPaymentMethod.setServiceProviderTargetId(serviceProviderTargetId);
    commitPaymentMethod.setEmail(email);

    CommitPaymentMethod.PlayerType playerType1 = new CommitPaymentMethod.PlayerType();
    CommitPaymentMethod.PlayerType playerType2 = new CommitPaymentMethod.PlayerType();

    if (createdById.equals("newPlayerWeb")) {
      playerType1.setId(playerId);
    } else {
      playerType1.setId(createdById);
    }
    if (updatedById.equals("newPlayerWeb")) {
      playerType2.setId(playerId);
    } else {
      playerType2.setId(updatedById);
    }
    playerType1.setType(createdByType);
    playerType2.setType(updatedByType);

    commitPaymentMethod.setCreatedBy(playerType1);
    commitPaymentMethod.setUpdatedBy(playerType2);

    return commitPaymentMethod;
  }

  // to be used in Azure Only
  public AccessOperation editAccessOperations(
      String buyListId,
      String buyListAccessType,
      String payoutListId,
      String payoutListAccessType,
      String depositListId,
      String depositListAccessType,
      String withdrawListId,
      String withdrawListAccessType,
      String reason) {

    String[] buyIdList = buyListId.split(",");
    String[] buyAccessTypeList = buyListAccessType.split(",");
    String[] payoutIdList = payoutListId.split(",");
    String[] payoutAccessTypeList = payoutListAccessType.split(",");
    String[] depositIdList = depositListId.split(",");
    String[] depositAccessTypeList = depositListAccessType.split(",");
    String[] withdrawIdList = withdrawListId.split(",");
    String[] withdrawAccessTypeList = withdrawListAccessType.split(",");

    List<AccessOperation.Operation> buyArrayList = new ArrayList<>();
    List<AccessOperation.Operation> payoutList = new ArrayList<>();
    List<AccessOperation.Operation> depositList = new ArrayList<>();
    List<AccessOperation.Operation> withdrawList = new ArrayList<>();

    AccessOperation.Operation buy = new AccessOperation.Operation();
    AccessOperation.Operation payout = new AccessOperation.Operation();
    AccessOperation.Operation deposit = new AccessOperation.Operation();
    AccessOperation.Operation withdraw = new AccessOperation.Operation();

    for (int i = 0; i < buyIdList.length; i++) {
      buy.setId(buyIdList[i]);
      buy.setAccessType(buyAccessTypeList[i]);
      buyArrayList.add(buy);
    }

    for (int i = 0; i < payoutIdList.length; i++) {
      payout.setId(payoutIdList[i]);
      payout.setAccessType(payoutAccessTypeList[i]);
      payoutList.add(payout);
    }

    for (int i = 0; i < depositIdList.length; i++) {
      deposit.setId(depositIdList[i]);
      deposit.setAccessType(depositAccessTypeList[i]);
      depositList.add(deposit);
    }

    for (int i = 0; i < withdrawIdList.length; i++) {
      withdraw.setId(withdrawIdList[i]);
      withdraw.setAccessType(withdrawAccessTypeList[i]);
      withdrawList.add(withdraw);
    }

    AccessOperation accessOperation = new AccessOperation();
    accessOperation.setDeposit(depositList);
    accessOperation.setWithdraw(withdrawList);
    accessOperation.setPayout(payoutList);
    accessOperation.setBuy(buyArrayList);
    accessOperation.setReason(reason);

    return accessOperation;
  }

  public RejectDepositViaTora rejectDepositViaTora(
      String payId,
      String preconditionStatus,
      int amount,
      String iban,
      String name,
      String bankName,
      String accountNumber) {

    RejectDepositViaTora rejectDepositViaTora = new RejectDepositViaTora();

    RejectDepositViaTora.Meta meta = new RejectDepositViaTora.Meta();
    RejectDepositViaTora.Data data = new RejectDepositViaTora.Data();
    RejectDepositViaTora.Data.RecipientInfo recipientInfo =
        new RejectDepositViaTora.Data.RecipientInfo();

    rejectDepositViaTora.setEvent_id("evt_5cuu5rPqi6znnkYYXCmPeGgp");
    rejectDepositViaTora.setEvent("transfer.rejected");
    rejectDepositViaTora.setWebhook_token("hok_Eap3KeCAEose3uZ39hljjMu3");
    rejectDepositViaTora.setPreconditionStatus(preconditionStatus);

    data.setAmount(amount);
    data.setId("trf_AsLwbaTDIICEsBROjInN8D9n");
    data.setObject("transfer");
    data.setStatus("rejected");
    data.setStatus_reason("Test");
    data.setCurrency("EUR");
    data.setDescription("None");
    data.setCreated_at(null);
    data.setUpdated_at(null);
    data.setRecipient("TORA");

    recipientInfo.setIban(iban);
    recipientInfo.setCountry("GR");
    recipientInfo.setCode("011");
    recipientInfo.setName(name);
    recipientInfo.setBank_name(bankName);
    recipientInfo.setAccount_number(accountNumber);
    recipientInfo.setEmail("");
    recipientInfo.setSubject("");
    recipientInfo.setNote("");
    recipientInfo.setDateOfBirth("");
    recipientInfo.setFirstName("");
    recipientInfo.setLasName("");

    // TODO: which paymentId is correct here?
    if (payId.isBlank()) {
      meta.setPaymentId(paymentId);
    } else {
      meta.setPaymentId(payId);
    }

    data.setRecipient_info(recipientInfo);
    data.setMeta(meta);
    rejectDepositViaTora.setData(data);

    return rejectDepositViaTora;
  }

  public PrecommitPayment precommitPaymentToWallet(
      int serviceCostAmount,
      String issuerId,
      String cardType,
      String cardName,
      String cardNumber,
      String expiryMonth,
      String expiryYear,
      String accountNumber,
      String paymentCode,
      String fingerprint) {

    PrecommitPayment precommitPayment = new PrecommitPayment();
    PrecommitPayment.ServiceCost serviceCost = new PrecommitPayment.ServiceCost();
    PrecommitPayment.Issuer issuer = new PrecommitPayment.Issuer();
    PrecommitPayment.PaymentMethod paymentMethod = new PrecommitPayment.PaymentMethod();

    PrecommitPayment.PaymentMethod.Card card = new PrecommitPayment.PaymentMethod.Card();
    PrecommitPayment.PaymentMethod.BankAccount bankAccount =
        new PrecommitPayment.PaymentMethod.BankAccount();
    PrecommitPayment.PaymentMethod.Voucher voucher = new PrecommitPayment.PaymentMethod.Voucher();
    PrecommitPayment.PaymentMethod.External external =
        new PrecommitPayment.PaymentMethod.External();
    PrecommitPayment.PaymentMethod.PaymentCode payCode =
        new PrecommitPayment.PaymentMethod.PaymentCode();

    // easy fields
    precommitPayment.setAuditData("testAuditData");
    precommitPayment.setFraud(false);
    precommitPayment.setForceReview(false);

    // inner fields - serviceCost
    serviceCost.setAmount(serviceCostAmount);
    serviceCost.setCurrency("EUR");

    // issuer
    if (issuerId.isBlank() || issuerId.equals("newPlayerWeb")) {
      issuer.setId(Integer.parseInt(playerId));
    } else {
      issuer.setId(Integer.parseInt(issuerId));
    }
    issuer.setType(1);

    // card
    card.setCardName(cardName);
    card.setCardNumber(cardNumber);
    card.setExpiryMonth(expiryMonth);
    card.setExpiryYear(expiryYear);

    // bankAccount
    bankAccount.setAccountNumber(accountNumber);
    bankAccount.setBankPersonalId("testBankPersonalId");
    bankAccount.setBankId("testBankId");

    // voucher
    voucher.setSerial("testSerial");

    // external
    external.setExternalReferenceId("testExternalReferenceId");
    external.setEmail("test@test.com");

    // paymentCode
    // TODO: recheck field
    if (paymentCode.isBlank()) {
      payCode.setPaymentCode(paymentCodeExclusive);
    } else {
      payCode.setPaymentCode(paymentCode);
    }

    // fingerprint (paymentMethod + card)
    if (fingerprint.isBlank()) {
      paymentMethod.setId(cardFingerprint);
      paymentMethod.setFingerPrint(cardFingerprint);
      card.setFingerprint(cardFingerprint);

    } else {
      paymentMethod.setId(fingerprint);
      paymentMethod.setId(fingerprint);
      card.setFingerprint(fingerprint);
    }

    // populate paymentMethod
    paymentMethod.setType(cardType);
    paymentMethod.setRealOwnerName("testRealOwnerName");
    paymentMethod.setCard(card);
    paymentMethod.setBankAccount(bankAccount);
    paymentMethod.setVoucher(voucher);
    paymentMethod.setPaymentCode(payCode);
    paymentMethod.setExternal(external);

    // populate precommitPayment
    precommitPayment.setServiceCost(serviceCost);
    precommitPayment.setIssuer(issuer);
    precommitPayment.setPaymentMethod(paymentMethod);

    return precommitPayment;
  }
}
