package apiResources.testDataBuild.rabbitMQData;

import apiResources.pojo.requests.rabbitMQService.CreateQueue;
import apiResources.pojo.requests.rabbitMQService.CreateBinding;
import apiResources.pojo.requests.rabbitMQService.GetQueueMessage;
import apiResources.pojo.requests.rabbitMQService.Publish;

import static apiResources.DataContext.*;

public class RabbitMQData {

  public CreateBinding addCreateBindingData(
      String source,
      String vhost,
      String routingKey,
      String destination,
      String destinationType,
      Object arguments) {

    CreateBinding createBinding = new CreateBinding();
    CreateBinding.Arguments arg = new CreateBinding.Arguments();

    createBinding.setSource(source);
    createBinding.setVhost(vhost);
    createBinding.setRouting_key(routingKey);
    createBinding.setDestination(destination);
    createBinding.setDestinationType(destinationType);

    if (arguments.equals("{}")) {
      createBinding.setArguments(arg);
    }
    // else if we find another case write extra code. fill extra values in arguments

    return createBinding;
  }

  public CreateQueue addCreateQueueData(
      boolean autoDelete, boolean durable, Object arguments, String vhost, String name) {

    CreateQueue createQueue = new CreateQueue();
    CreateQueue.Arguments arg = new CreateQueue.Arguments();

    createQueue.setAuto_delete(autoDelete);
    createQueue.setDurable(durable);
    createQueue.setVhost(vhost);
    createQueue.setName(name);

    if (arguments.equals("{}")) {
      createQueue.setArguments(arg);
    }
    // else if we find another case write extra code. fill extra values in arguments

    return createQueue;
  }

  public Publish addPublishToExchangeData(
      String contentType, String routingKey, String payload, String payloadEncoding) {

    if (payload.contains("{{playerId}}") && playerId != null) {
      payload = payload.replace("{{playerId}}", playerId);
      System.out.println("PlayerId replaced with: " + playerId);
    }
    if (payload.contains("{{sessionMinuteId}}") && sessionMinuteId != null) {
      payload = payload.replace("{{sessionMinuteId}}", sessionMinuteId);
      System.out.println("sessionMinuteId replaced with: " + sessionMinuteId);
    }
    if (payload.contains("{{sessionDomain}}") && sessionDomain != null) {
      payload = payload.replace("{{sessionDomain}}", sessionDomain);
      System.out.println("sessionDomain replaced with: " + sessionDomain);
    }
    if (payload.contains("{{sessionGameId}}") && sessionGameId != null) {
      payload = payload.replace("{{sessionGameId}}", sessionGameId);
      System.out.println("sessionGameId replaced with: " + sessionGameId);
    }

    Publish publish = new Publish();
    publish.setPayload(payload);
    publish.setPayload_encoding(payloadEncoding);
    publish.setRouting_key(routingKey);

    Publish.Properties property = new Publish.Properties();

    property.setContentType(contentType);
    publish.setProperties(property);

    return publish;
  }

  public GetQueueMessage addGetQueueMessagesData(
      int count, String ackmode, String encoding, int truncate) {

    GetQueueMessage getQueueMessage = new GetQueueMessage();
    getQueueMessage.setEncoding(encoding);
    getQueueMessage.setTruncate(truncate);
    getQueueMessage.setAckmode(ackmode);
    getQueueMessage.setCount(count);

    return getQueueMessage;
  }
}
