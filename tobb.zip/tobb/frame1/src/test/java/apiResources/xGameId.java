package apiResources;

public enum xGameId {
  JOKER("JOKER"),
  SPORTSBOOK("SPORTSBOOK"),
  CASINO("CASINO"),
  KINO("KINO"),
  LOTTO("LOTTO"),
  PROTO("PROTO"),
  OPAPONLINE("OPAPONLINE");

  private String value;

  private xGameId(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }
}
