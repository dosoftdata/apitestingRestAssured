package apiResources.pojo.requests.walletService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class ManualAdjustWallet {
  private String transactionType;

  private String transactionSubType;

  private String reason;

  private String productId;

  private String operation;

  private String amount;

  private String currency;
  private Boolean transactionBetweenWallets;

  public String getTransactionType() {
    return transactionType;
  }

  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }

  public String getTransactionSubType() {
    return transactionSubType;
  }

  public void setTransactionSubType(String transactionSubType) {
    this.transactionSubType = transactionSubType;
  }

  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public String getOperation() {
    return operation;
  }

  public void setOperation(String operation) {
    this.operation = operation;
  }

  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  public Boolean getTransactionBetweenWallets() {
    return transactionBetweenWallets;
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  public void setTransactionBetweenWallets(Boolean transactionBetweenWallets) {
    this.transactionBetweenWallets = transactionBetweenWallets;
  }
}
