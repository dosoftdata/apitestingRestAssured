package apiResources.pojo.requests.bonusService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class BonusPrize {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String providerId;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String gameId;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String status;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String transactionId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private boolean closeAccount;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private float amount;

    public boolean isCloseAccount() {
        return closeAccount;
    }

    public void setCloseAccount(boolean closeAccount) {
        this.closeAccount = closeAccount;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    public String getGameId() {
        return gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
