package apiResources.pojo.requests.wagerService;

public class CaptureBet {

  private float amount;
  private String batchId;
  private String subBatchId;

  public float getAmount() {
    return amount;
  }

  public void setAmount(float amount) {
    this.amount = amount;
  }

  public String getBatchId() {
    return batchId;
  }

  public void setBatchId(String batchId) {
    this.batchId = batchId;
  }

  public String getSubBatchId() {
    return subBatchId;
  }

  public void setSubBatchId(String subBatchId) {
    this.subBatchId = subBatchId;
  }
}
