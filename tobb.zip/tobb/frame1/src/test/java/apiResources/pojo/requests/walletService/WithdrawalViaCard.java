package apiResources.pojo.requests.walletService;

public class WithdrawalViaCard {

  private String action;

  private String operation;

  private String channel;

  private String paymentType;

  private PaymentMethod paymentMethod;

  private Object paymentId;

  private String pspPaymentId;

  private Amount amount;

  private ServiceCost serviceCost;

  private Owner owner;

  private Object issuer;

  private String pspId;

  private String pspTargetId;

  private Object extraParams;

  private Boolean forceReview;

  private String paybankId;

  public String getAction() {
    return action;
  }

  public void setAction(String action) {
    this.action = action;
  }

  public String getOperation() {
    return operation;
  }

  public void setOperation(String operation) {
    this.operation = operation;
  }

  public String getChannel() {
    return channel;
  }

  public void setChannel(String channel) {
    this.channel = channel;
  }

  public String getPaymentType() {
    return paymentType;
  }

  public void setPaymentType(String paymentType) {
    this.paymentType = paymentType;
  }

  public static class PaymentMethod {

    private String type;

    private String id;

    private Object card;

    private BankAccount bankAccount;

    private Object voucher;

    public String getType() {
      return type;
    }

    public void setType(String type) {
      this.type = type;
    }

    public String getId() {
      return id;
    }

    public void setId(String id) {
      this.id = id;
    }

    public Object getCard() {
      return card;
    }

    public void setCard(Object card) {
      this.card = card;
    }

    public static class BankAccount {

      private String bankId;

      public String getBankId() {
        return bankId;
      }

      public void setBankId(String bankId) {
        this.bankId = bankId;
      }
    }

    public BankAccount getBankAccount() {
      return bankAccount;
    }

    public void setBankAccount(BankAccount bankAccount) {
      this.bankAccount = bankAccount;
    }

    public Object getVoucher() {
      return voucher;
    }

    public void setVoucher(Object voucher) {
      this.voucher = voucher;
    }
  }

  public PaymentMethod getPaymentMethod() {
    return paymentMethod;
  }

  public void setPaymentMethod(PaymentMethod paymentMethod) {
    this.paymentMethod = paymentMethod;
  }

  public Object getPaymentId() {
    return paymentId;
  }

  public void setPaymentId(Object paymentId) {
    this.paymentId = paymentId;
  }

  public String getPspPaymentId() {
    return pspPaymentId;
  }

  public void setPspPaymentId(String pspPaymentId) {
    this.pspPaymentId = pspPaymentId;
  }

  public static class Amount {

    private Integer amount;

    private String currency;

    public Integer getAmount() {
      return amount;
    }

    public void setAmount(Integer amount) {
      this.amount = amount;
    }

    public String getCurrency() {
      return currency;
    }

    public void setCurrency(String currency) {
      this.currency = currency;
    }
  }

  public Amount getAmount() {
    return amount;
  }

  public void setAmount(Amount amount) {
    this.amount = amount;
  }

  public static class ServiceCost {

    private Integer amount;

    private String currency;

    public Integer getAmount() {
      return amount;
    }

    public void setAmount(Integer amount) {
      this.amount = amount;
    }

    public String getCurrency() {
      return currency;
    }

    public void setCurrency(String currency) {
      this.currency = currency;
    }
  }

  public ServiceCost getServiceCost() {
    return serviceCost;
  }

  public void setServiceCost(ServiceCost serviceCost) {
    this.serviceCost = serviceCost;
  }

  public static class Owner {

    private String id;

    private Integer type;

    public String getId() {
      return id;
    }

    public void setId(String id) {
      this.id = id;
    }

    public Integer getType() {
      return type;
    }

    public void setType(Integer type) {
      this.type = type;
    }
  }

  public Owner getOwner() {
    return owner;
  }

  public void setOwner(Owner owner) {
    this.owner = owner;
  }

  public Object getIssuer() {
    return issuer;
  }

  public void setIssuer(Object issuer) {
    this.issuer = issuer;
  }

  public String getPspId() {
    return pspId;
  }

  public void setPspId(String pspId) {
    this.pspId = pspId;
  }

  public String getPspTargetId() {
    return pspTargetId;
  }

  public void setPspTargetId(String pspTargetId) {
    this.pspTargetId = pspTargetId;
  }

  public Object getExtraParams() {
    return extraParams;
  }

  public void setExtraParams(Object extraParams) {
    this.extraParams = extraParams;
  }

  public Boolean getForceReview() {
    return forceReview;
  }

  public void setForceReview(Boolean forceReview) {
    this.forceReview = forceReview;
  }

  public String getPaybankId() {
    return paybankId;
  }

  public void setPaybankId(String paybankId) {
    this.paybankId = paybankId;
  }
}
