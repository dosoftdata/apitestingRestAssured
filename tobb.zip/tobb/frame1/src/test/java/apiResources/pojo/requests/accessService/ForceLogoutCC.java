package apiResources.pojo.requests.accessService;

public class ForceLogoutCC {
  private String reason;
  private String group;

  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public String getGroup() {
    return group;
  }

  public void setGroup(String group) {
    this.group = group;
  }
}
