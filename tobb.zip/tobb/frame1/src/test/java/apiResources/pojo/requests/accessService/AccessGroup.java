package apiResources.pojo.requests.accessService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class AccessGroup {
  private String name;
  private String description;

  @JsonInclude(JsonInclude.Include.NON_DEFAULT)
  private int memberType;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String updatedByUserId;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public String getUpdatedByUserId() {
    return updatedByUserId;
  }

  public void setUpdatedByUserId(String updatedByUserId) {
    this.updatedByUserId = updatedByUserId;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public int getMemberType() {
    return memberType;
  }

  public void setMemberType(int memberType) {
    this.memberType = memberType;
  }
}
