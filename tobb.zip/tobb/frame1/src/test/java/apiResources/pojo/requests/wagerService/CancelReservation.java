package apiResources.pojo.requests.wagerService;

//import com.fasterxml.jackson.annotation.JsonInclude;

public class CancelReservation {
  private String batchId;
  private String reason;

  public String getBatchId() {
    return batchId;
  }

  public void setBatchId(String batchId) {
    this.batchId = batchId;
  }
  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
   }
}
