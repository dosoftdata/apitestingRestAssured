package apiResources.pojo.requests.walletService;

public class PostWalletFunds {
  private String accountId;
  private float amount;
  private String currency;
  private String issued;
  private String referenceId;
  private String productId;
  private String type;
  private String description;
  private boolean autocapture;
  private String status;
  private boolean captured;
  private String batchId;

  // Getter Methods

  public String getAccountId() {
    return accountId;
  }

  public float getAmount() {
    return amount;
  }

  public String getCurrency() {
    return currency;
  }

  public String getIssued() {
    return issued;
  }

  public String getReferenceId() {
    return referenceId;
  }

  public String getProductId() {
    return productId;
  }

  public String getType() {
    return type;
  }

  public String getDescription() {
    return description;
  }

  public boolean getAutocapture() {
    return autocapture;
  }

  public String getStatus() {
    return status;
  }

  public boolean getCaptured() {
    return captured;
  }

  public String getBatchId(String batchId) {
    return this.batchId;
  }

  // Setter Methods

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public void setAmount(float amount) {
    this.amount = amount;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public void setIssued(String issued) {
    this.issued = issued;
  }

  public void setReferenceId(String referenceId) {
    this.referenceId = referenceId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public void setType(String type) {
    this.type = type;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setAutocapture(boolean autocapture) {
    this.autocapture = autocapture;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public void setCaptured(boolean captured) {
    this.captured = captured;
  }

  public void setBatchId(String batchId) {
    this.batchId = batchId;
  }
}
