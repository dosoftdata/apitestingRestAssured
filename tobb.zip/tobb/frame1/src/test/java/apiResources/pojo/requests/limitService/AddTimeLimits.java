package apiResources.pojo.requests.limitService;

public class AddTimeLimits {
  private String limitType;
  private String period;
  private Quantity quantity;
  private Integer durationInSeconds;
  private String quantityType;

  public String getLimitType() {
    return limitType;
  }

  public void setLimitType(String limitType) {
    this.limitType = limitType;
  }

  public String getPeriod() {
    return period;
  }

  public void setPeriod(String period) {
    this.period = period;
  }

  public static class Quantity {
    private Integer durationInSeconds;

    public Integer getDurationInSeconds() {
      return durationInSeconds;
    }

    public void setDurationInSeconds(Integer durationInSeconds) {
      this.durationInSeconds = durationInSeconds;
    }
  }

  public Quantity getQuantity() {
    return quantity;
  }

  public void setQuantity(Quantity quantity) {
    this.quantity = quantity;
  }

  public Integer getDurationInSeconds() {
    return durationInSeconds;
  }

  public void setDurationInSeconds(Integer durationInSeconds) {
    this.durationInSeconds = durationInSeconds;
  }

  public String getQuantityType() {
    return quantityType;
  }

  public void setQuantityType(String quantityType) {
    this.quantityType = quantityType;
  }
}
