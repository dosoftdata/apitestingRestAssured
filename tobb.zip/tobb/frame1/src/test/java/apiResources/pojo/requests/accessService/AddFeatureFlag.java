package apiResources.pojo.requests.accessService;

import java.util.List;

public class AddFeatureFlag {
  private String feature;
  private List<String> customerIds;

  public String getFeature() { return feature; }
  public void setFeature(String feature) { this.feature = feature; }

  public List<String> getCustomerIds() { return customerIds; }
  public void setCustomerIds(List<String> customerIds) { this.customerIds = customerIds; }
}
