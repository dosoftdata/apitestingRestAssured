package apiResources.pojo.requests.wagerService;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;

public class PlaceWager {
  private String gameType;
  private Wager wager;

  public Wager getWager() {
    return wager;
  }

  public void setWager(Wager wager) {
    this.wager = wager;
  }

  public String getGameType() {
    return gameType;
  }

  public void setGameType(String gameType) {
    this.gameType = gameType;
  }

  public static class Board {

    private int betType;
    private List<Panel> panels;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private int boardId;

    public int getBoardId() {
      return boardId;
    }

    public void setBoardId(int boardId) {
      this.boardId = boardId;
    }

    public List<Panel> getPanels() {
      return panels;
    }

    public void setPanels(List<Panel> panels) {
      this.panels = panels;
    }

    public int getBetType() {
      return betType;
    }

    public void setBetType(int betType) {
      this.betType = betType;
    }
  }

  public static class Panel {
    private ArrayList<Integer> selection;

    public ArrayList<Integer> getSelection() {
      return selection;
    }

    public void setSelection(ArrayList<Integer> selection) {
      this.selection = selection;
    }
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  public static class ParticipatingDraws {
    private int multipleDraws;

    public int getMultipleDraws() {
      return multipleDraws;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setMultipleDraws(int multipleDraws) {
      this.multipleDraws = multipleDraws;
    }
  }

  public static class Wager {
    private ArrayList<Board> boards;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private ParticipatingDraws participatingDraws;

    private boolean quickPick;

    public ParticipatingDraws getParticipatingDraws() {
      return participatingDraws;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setParticipatingDraws(ParticipatingDraws participatingDraws) {
      this.participatingDraws = participatingDraws;
    }

    public boolean isQuickPick() {
      return quickPick;
    }

    public void setQuickPick(boolean quickPick) {
      this.quickPick = quickPick;
    }

    public ArrayList<Board> getBoards() {
      return boards;
    }

    public void setBoards(ArrayList<Board> boards) {
      this.boards = boards;
    }
  }
}
