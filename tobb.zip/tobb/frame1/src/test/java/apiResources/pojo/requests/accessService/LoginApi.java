package apiResources.pojo.requests.accessService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class LoginApi {

  private String grant_type;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String code;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String username;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String password;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String retailerId;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String betware_retailer_id;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String betware_terminal_id;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String refresh_token;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String client_assertion;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String client_assertion_type;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String assertion;

  public String getAssertion() {
    return assertion;
  }

  public void setAssertion(String assertion) {
    this.assertion = assertion;
  }

  public String getClaims() {
    return claims;
  }

  public void setClaims(String claims) {
    this.claims = claims;
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String claims;

  public String getClient_id() {
    return client_id;
  }

  public void setClient_id(String client_id) {
    this.client_id = client_id;
  }

  public String getClient_secret() {
    return client_secret;
  }

  public void setClient_secret(String client_secret) {
    this.client_secret = client_secret;
  }

  public String getCardnumber() {
    return cardnumber;
  }

  public void setCardnumber(String cardnumber) {
    this.cardnumber = cardnumber;
  }

  public String getPin() {
    return pin;
  }

  public void setPin(String pin) {
    this.pin = pin;
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String client_id;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String client_secret;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String cardnumber;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String pin;

  public String getGrant_type() {
    return grant_type;
  }

  public void setGrant_type(String grant_type) {
    this.grant_type = grant_type;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getRetailerId() {
    return retailerId;
  }

  public void setRetailerId(String retailerId) {
    this.retailerId = retailerId;
  }

  public String getClient_assertion() {
    return client_assertion;
  }

  public void setClient_assertion(String client_assertion) {
    this.client_assertion = client_assertion;
  }

  public String getClient_assertion_type() {
    return client_assertion_type;
  }

  public void setClient_assertion_type(String client_assertion_type) {
    this.client_assertion_type = client_assertion_type;
  }
  public String getBetware_retailer_id() {
    return betware_retailer_id;
  }

  public void setBetware_retailer_id(String betware_retailer_id) {
    this.betware_retailer_id = betware_retailer_id;
  }

  public String getBetware_terminal_id() {
    return betware_terminal_id;
  }

  public String getRefresh_token() {
    return refresh_token;
  }

  public void setRefresh_token(String refresh_token) {
    this.refresh_token = refresh_token;
  }

  public void setBetware_terminal_id(String betware_terminal_id) {
    this.betware_terminal_id = betware_terminal_id;
  }

}
