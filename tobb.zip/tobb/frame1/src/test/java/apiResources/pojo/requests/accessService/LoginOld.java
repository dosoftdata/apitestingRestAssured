package apiResources.pojo.requests.accessService;

public class LoginOld {
  private String loginName;
  private String password;
  private String channel;
  private String subchannel;
  private String group;

  // Getter Methods
  public String getLoginName() {
    return loginName;
  }

  public String getPassword() {
    return password;
  }

  public String getChannel() {
    return channel;
  }

  public String getSubchannel() {
    return subchannel;
  }

  public String getGroup() {
    return group;
  }

  // Setter Methods
  public void setUsername(String loginName) {
    this.loginName = loginName;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public void setChannel(String channel) {
    this.channel = channel;
  }

  public void setSubchannel(String subchannel) {
    this.subchannel = subchannel;
  }

  public void setGroup(String group) {
    this.group = group;
  }
}
