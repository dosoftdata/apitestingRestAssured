package apiResources.pojo.requests.rabbitMQService;

import apiResources.pojo.requests.communicationService.BulkMessage;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

public class CreateQueue {

  private boolean auto_delete;
  private boolean durable;
  private Arguments arguments;
  private String vhost;
  private String name;

  public static class Arguments {

    public String getTest() {
      return test;
    }

    public void setTest(String test) {
      this.test = test;
    }

    // workaround . dont fill this field. or replace with a valid one
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String test;
  }

  public void setArguments(Arguments arguments) {
    this.arguments = arguments;
  }

  public Arguments getArguments() {
    return arguments;
  }

  public boolean isAuto_delete() {
    return auto_delete;
  }

  public void setAuto_delete(boolean auto_delete) {
    this.auto_delete = auto_delete;
  }

  public boolean isDurable() {
    return durable;
  }

  public void setDurable(boolean durable) {
    this.durable = durable;
  }

  public String getVhost() {
    return vhost;
  }

  public void setVhost(String vhost) {
    this.vhost = vhost;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
