package apiResources.pojo.requests.accessService;

public class LoginBackOffice {
  private String loginName;
  private String password;

  // Getter Methods
  public String getLoginName() {
    return loginName;
  }

  public String getPassword() {
    return password;
  }

  // Setter Methods
  public void setLoginName(String loginName) {
    this.loginName = loginName;
  }

  public void setPassword(String password) {
    this.password = password;
  }
}
