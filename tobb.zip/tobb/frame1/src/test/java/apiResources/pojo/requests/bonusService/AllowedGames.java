package apiResources.pojo.requests.bonusService;

import java.util.List;

public class AllowedGames {
  private String gameType;
  private List<String> gameIds;

  public String getGameType() {
    return gameType;
  }

  public void setGameType(String gameType) {
    this.gameType = gameType;
  }

  // Getter and Setter for gameIds
  public List<String> getGameIds() {
    return gameIds;
  }

  public void setGameIds(List<String> gameIds) {
    this.gameIds = gameIds;
  }

}
