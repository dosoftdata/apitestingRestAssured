package apiResources.pojo.requests.applePayService;

public class ApplePay {
  private String currency;
  private float amount;
  private String sessionUrl;

  // Getter Methods

  public String getCurrency() {
    return currency;
  }

  public float getAmount() {
    return amount;
  }

  public String getSessionUrl() {
    return sessionUrl;
  }

  // Setter Methods

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public void setAmount(float amount) {
    this.amount = amount;
  }

  public void setSessionUrl(String sessionUrl) {
    this.sessionUrl = sessionUrl;
  }
}
