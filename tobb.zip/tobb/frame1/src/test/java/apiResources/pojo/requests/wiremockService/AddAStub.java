package apiResources.pojo.requests.wiremockService;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AddAStub {
  private String scenarioName;
  private String requiredScenarioState;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private int priority;

  private Request request;
  private Response response;

  public Response getResponse() {
    return response;
  }

  public void setResponse(Response response) {
    this.response = response;
  }

  public String getScenarioName() {
    return scenarioName;
  }

  public void setScenarioName(String scenarioName) {
    this.scenarioName = scenarioName;
  }

  public String getRequiredScenarioState() {
    return requiredScenarioState;
  }

  public void setRequiredScenarioState(String requiredScenarioState) {
    this.requiredScenarioState = requiredScenarioState;
  }

  public int getPriority() {
    return priority;
  }

  public void setPriority(int priority) {
    this.priority = priority;
  }

  public Request getRequest() {
    return request;
  }

  public void setRequest(Request request) {
    this.request = request;
  }

  public static class Request {
    public String method;

    public String getMethod() {
      return method;
    }

    public void setMethod(String method) {
      this.method = method;
    }

    public String getUrl() {
      return url;
    }

    public void setUrl(String url) {
      this.url = url;
    }

    public String getUrlPattern() {
      return urlPattern;
    }

    public void setUrlPattern(String urlPattern) {
      this.urlPattern = urlPattern;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String url;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String urlPattern;
  }

  public static class headers {
    @JsonProperty("Content-Type")
    private String contentType;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String GUID;

    public String getContentType() {
      return contentType;
    }

    public void setContentType(String contentType) {
      this.contentType = contentType;
    }

    public String getGUID() {
      return GUID;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setGUID(String GUID) {
      this.GUID = GUID;
    }
  }

  public static class Response {
    private int status;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String body;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private headers headers;

    public AddAStub.headers getHeaders() {
      return headers;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setHeaders(AddAStub.headers headers) {
      this.headers = headers;
    }

    public int getStatus() {
      return status;
    }

    public void setStatus(int status) {
      this.status = status;
    }

    public String getBody() {
      return body;
    }

    public void setBody(String body) {
      this.body = body;
    }
  }
}
