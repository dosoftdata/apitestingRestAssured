package apiResources.pojo.requests.walletService;

public class Paypal {

  private String amount;
  private String currency;
  private String paymentMethodType;
  private PaypalInfo paypal;
  private String paymentType;

  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public String getPaymentMethodType() {
    return paymentMethodType;
  }

  public void setPaymentMethodType(String paymentMethodType) {
    this.paymentMethodType = paymentMethodType;
  }

  public PaypalInfo getPaypal() {
    return paypal;
  }

  public void setPaypal(PaypalInfo paypal) {
    this.paypal = paypal;
  }

  public String getPaymentType() {
    return paymentType;
  }

  public void setPaymentType(String paymentType) {
    this.paymentType = paymentType;
  }

  public static class PaypalInfo {
    private String payer_id;
    private String email;
    private String full_name;
    private String country;

    public String getPayer_id() {
      return payer_id;
    }

    public void setPayer_id(String payer_id) {
      this.payer_id = payer_id;
    }

    public String getEmail() {
      return email;
    }

    public void setEmail(String email) {
      this.email = email;
    }

    public String getFull_name() {
      return full_name;
    }

    public void setFull_name(String full_name) {
      this.full_name = full_name;
    }

    public String getCountry() {
      return country;
    }

    public void setCountry(String country) {
      this.country = country;
    }
  }
}
