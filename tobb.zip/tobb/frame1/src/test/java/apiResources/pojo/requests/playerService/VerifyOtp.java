package apiResources.pojo.requests.playerService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class VerifyOtp {
  private String phoneNumber;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String uuid;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String verificationCode;

  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public String getUuid() {
    return uuid;
  }

  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  public String getVerificationCode() {
    return verificationCode;
  }

  public void setVerificationCode(String verificationCode) {
    this.verificationCode = verificationCode;
  }
}
