package apiResources.pojo.requests.bonusService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class BonusStatus {
  private String status;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private metaData metadata; // Optional field

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public metaData getMetadata() {
    return metadata;
  }

  public void setMetadata(metaData metadata) {
    this.metadata = metadata;
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  public static class metaData {
    private String cancelReason;

    // Getter for cancelReason
    public String getCancelReason() {
      return cancelReason;
    }

    // Setter for cancelReason
    public void setCancelReason(String cancelReason) {
      this.cancelReason = cancelReason;
    }
  }
}
