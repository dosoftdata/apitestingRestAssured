package apiResources.pojo.requests.walletService;

import java.util.List;

public class AccessOperation {
  private List<Operation> buy;
  private List<Operation> payout;
  private List<Operation> deposit;
  private List<Operation> withdraw;
  private String reason;

  public static class Operation {
    private String id;

    public String getId() {
      return id;
    }

    public void setId(String id) {
      this.id = id;
    }

    public String getAccessType() {
      return accessType;
    }

    public void setAccessType(String accessType) {
      this.accessType = accessType;
    }

    private String accessType;
  }

  public List<Operation> getBuy() {
    return buy;
  }

  public void setBuy(List<Operation> buy) {
    this.buy = buy;
  }

  public List<Operation> getPayout() {
    return payout;
  }

  public void setPayout(List<Operation> payout) {
    this.payout = payout;
  }

  public List<Operation> getDeposit() {
    return deposit;
  }

  public void setDeposit(List<Operation> deposit) {
    this.deposit = deposit;
  }

  public List<Operation> getWithdraw() {
    return withdraw;
  }

  public void setWithdraw(List<Operation> withdraw) {
    this.withdraw = withdraw;
  }

  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }
}
