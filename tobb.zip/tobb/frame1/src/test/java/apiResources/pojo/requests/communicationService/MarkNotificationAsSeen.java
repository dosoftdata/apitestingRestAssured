package apiResources.pojo.requests.communicationService;

public class MarkNotificationAsSeen {

  private String id;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }
}
