package apiResources.pojo.requests.communicationService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class PlayerPreferences {
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String subCategory;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private boolean selected;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String messageType;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String category;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String preferenceType;

  public String getSubCategory() {
    return subCategory;
  }

  public boolean isSelected() {
    return selected;
  }

  public void setSelected(boolean selected) {
    this.selected = selected;
  }

  public void setSubCategory(String subCategory) {
    this.subCategory = subCategory;
  }

  public String getMessageType() {
    return messageType;
  }

  public void setMessageType(String messageType) {
    this.messageType = messageType;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public String getPreferenceType() {
    return preferenceType;
  }

  public void setPreferenceType(String preferenceType) {
    this.preferenceType = preferenceType;
  }
}
