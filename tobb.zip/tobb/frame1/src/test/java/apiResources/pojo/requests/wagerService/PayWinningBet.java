package apiResources.pojo.requests.wagerService;

public class PayWinningBet {
  private int amount;
  private int taxAmount;
  private String currency;
  private String description;
  private String issued;
  private String partialPayment;

  private String productId;
  private String serialNumber;

  public int getAmount() {
    return amount;
  }

  public void setAmount(int amount) {
    this.amount = amount;
  }

  public String getReferenceId() {
    return referenceId;
  }

  public void setReferenceId(String referenceId) {
    this.referenceId = referenceId;
  }

  public String referenceId;

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getIssued() {
    return issued;
  }

  public void setIssued(String issued) {
    this.issued = issued;
  }

  public String getPartialPayment() {
    return partialPayment;
  }

  public void setPartialPayment(String partialPayment) {
    this.partialPayment = partialPayment;
  }

  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public String getSerialNumber() {
    return serialNumber;
  }

  public void setSerialNumber(String serialNumber) {
    this.serialNumber = serialNumber;
  }

  public int getTaxAmount() {
    return taxAmount;
  }

  public void setTaxAmount(int taxAmount) {
    this.taxAmount = taxAmount;
  }
}
