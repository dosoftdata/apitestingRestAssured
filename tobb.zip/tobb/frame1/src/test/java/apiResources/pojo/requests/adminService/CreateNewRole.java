package apiResources.pojo.requests.adminService;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

public class CreateNewRole {
  private String email;
  private String firstName;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String language;
  private String lastName;
  private String loginName;
  private String password;
  private String passwordRepeated;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private int status;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private List<Integer> groupIds;

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLanguage() {
    return language;
  }

  public void setLanguage(String language) {
    this.language = language;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getLoginName() {
    return loginName;
  }

  public void setLoginName(String loginName) {
    this.loginName = loginName;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getPasswordRepeated() {
    return passwordRepeated;
  }

  public void setPasswordRepeated(String passwordRepeated) {
    this.passwordRepeated = passwordRepeated;
  }

  public int getStatus() { return status; }
  public void setStatus(int status) { this.status = status; }

  public List<Integer> getGroupIds() { return groupIds; }
  public void setGroupIds(List<Integer> groupIds) { this.groupIds = groupIds; }
}