package apiResources.pojo.requests.accessService;

import com.fasterxml.jackson.annotation.JsonInclude;

// don't send some fields if are empty just to check negative scenarios.
// accessType,operationalUnit,userId are mandatory thought!

public class ApiAccessAttributes {
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String accessType;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String operationalUnit;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String userId;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String created;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String updated;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String updatedByUserId;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String operatorId;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String reason;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Valid valid;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String notifyStatus;

  public String getNotifyStatus() {
    return notifyStatus;
  }

  public void setNotifyStatus(String notifyStatus) {
    this.notifyStatus = notifyStatus;
  }

  public String getAccessType() {
    return accessType;
  }

  public void setAccessType(String accessType) {
    this.accessType = accessType;
  }

  public String getOperationalUnit() {
    return operationalUnit;
  }

  public void setOperationalUnit(String operationalUnit) {
    this.operationalUnit = operationalUnit;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getCreated() {
    return created;
  }

  public void setCreated(String created) {
    this.created = created;
  }

  public String getUpdated() {
    return updated;
  }

  public void setUpdated(String updated) {
    this.updated = updated;
  }

  public String getUpdatedByUserId() {
    return updatedByUserId;
  }

  public void setUpdatedByUserId(String updatedByUserId) {
    this.updatedByUserId = updatedByUserId;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public Valid getValid() {
    return valid;
  }

  public void setValid(Valid valid) {
    this.valid = valid;
  }

  public static class Valid {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String from;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String to;

    public String getTo() {
      return to;
    }

    public String getFrom() {
      return from;
    }

    public void setFrom(String from) {
      this.from = from;
    }

    public void setTo(String to) {
      this.to = to;
    }
  }
}
