package apiResources.pojo.requests.walletService;
import java.util.List;

public class RestrictUser {
  private List<AccessDetail> deposit;
  private List<AccessDetail> withdraw;

  public List<AccessDetail> getDeposit() {
    return deposit;
  }
  public void setDeposit(List<AccessDetail> deposit) {
    this.deposit = deposit;
  }
  public List<AccessDetail> getWithdraw() {
    return withdraw;
  }
  public void setWithdraw(List<AccessDetail> withdraw) {
    this.withdraw = withdraw;
  }

public static class AccessDetail {
  private String id;
  private String accessType;

  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
  public String getAccessType() {
    return accessType;
  }
  public void setAccessType(String accessType) {
    this.accessType = accessType;
  }
}
}
