package apiResources.pojo.requests.wagerService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class PlayBetFundsExtra {
    private String accountId;
    private float amount;
    private String currency;
    private String issued;
    private String referenceId;
    private String productId;
    private String type;
    private String description;
    private boolean autocapture;
    private String status;
    public boolean captured;
    private Metadata metadata;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String batchId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String subBatchId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String bonusPrizeId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String bonusRollover;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private float taxAmount;

    public float getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(float taxAmount) {
        this.taxAmount = taxAmount;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getSubBatchId() {
        return subBatchId;
    }

    public void setSubBatchId(String subBatchId) {
        this.subBatchId = subBatchId;
    }

    public String getBonusPrizeId() {
        return bonusPrizeId;
    }

    public void setBonusPrizeId(String bonusPrizeId) {
        this.bonusPrizeId = bonusPrizeId;
    }

    public String getBonusRollover() {
        return bonusRollover;
    }

    public void setBonusRollover(String bonusRollover) {
        this.bonusRollover = bonusRollover;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Metadata {

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String bonusPrizeId;

        public String getBonusPrizeId() {
            return bonusPrizeId;
        }

        public void setBonusPrizeId(String bonusPrizeId) {
            this.bonusPrizeId = bonusPrizeId;
        }

        @JsonInclude(JsonInclude.Include.NON_NULL)
        private String gameId;

        @JsonInclude(JsonInclude.Include.NON_DEFAULT)
        private double bonusAmount;

        public String getGameId() {
            return gameId;
        }

        public void setGameId(String gameId) {
            this.gameId = gameId;
        }

        public double getBonusAmount() {
            return bonusAmount;
        }

        public void setBonusAmount(double bonusAmount) {
            this.bonusAmount = bonusAmount;
        }
    }

    public Metadata getMetadata() {
        return metadata;
    }

    public void setMetadata(Metadata value) {
        this.metadata = value;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getIssued() {
        return issued;
    }

    public void setIssued(String issued) {
        this.issued = issued;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isAutocapture() {
        return autocapture;
    }

    public void setAutocapture(boolean autocapture) {
        this.autocapture = autocapture;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isCaptured() {
        return captured;
    }

    public void setCaptured(boolean captured) {
        this.captured = captured;
    }
}
