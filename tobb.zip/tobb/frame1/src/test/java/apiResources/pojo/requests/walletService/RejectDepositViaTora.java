// designed for AT-MAIN-2 transaction endpoint
package apiResources.pojo.requests.walletService;

public class RejectDepositViaTora {
  private String event_id;
  private String event;
  private Data data;
  private String webhook_token;
  private String preconditionStatus;

  public static class Data {
    private String id;
    private String object;
    private String status;
    private String status_reason;
    private int amount;
    private String currency;
    private String description;
    private Meta meta;
    private String created_at;
    private String updated_at;
    private String recipient;
    private RecipientInfo recipient_info;

    public Meta getMeta() {
      return meta;
    }

    public void setMeta(Meta meta) {
      this.meta = meta;
    }

    public String getCreated_at() {
      return created_at;
    }

    public void setCreated_at(String created_at) {
      this.created_at = created_at;
    }

    public String getUpdated_at() {
      return updated_at;
    }

    public void setUpdated_at(String updated_at) {
      this.updated_at = updated_at;
    }

    public String getRecipient() {
      return recipient;
    }

    public void setRecipient(String recipient) {
      this.recipient = recipient;
    }

    public RecipientInfo getRecipient_info() {
      return recipient_info;
    }

    public void setRecipient_info(RecipientInfo recipient_info) {
      this.recipient_info = recipient_info;
    }

    public static class RecipientInfo {

      private String iban;

      public String getIban() {
        return iban;
      }

      public void setIban(String iban) {
        this.iban = iban;
      }

      public String getCountry() {
        return country;
      }

      public void setCountry(String country) {
        this.country = country;
      }

      public String getCode() {
        return code;
      }

      public void setCode(String code) {
        this.code = code;
      }

      public String getName() {
        return name;
      }

      public void setName(String name) {
        this.name = name;
      }

      public String getBank_name() {
        return bank_name;
      }

      public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
      }

      public String getAccount_number() {
        return account_number;
      }

      public void setAccount_number(String account_number) {
        this.account_number = account_number;
      }

      public String getRemittance_info() {
        return remittance_info;
      }

      public void setRemittance_info(String remittance_info) {
        this.remittance_info = remittance_info;
      }

      public String getEmail() {
        return email;
      }

      public void setEmail(String email) {
        this.email = email;
      }

      public String getSubject() {
        return subject;
      }

      public void setSubject(String subject) {
        this.subject = subject;
      }

      public String getNote() {
        return note;
      }

      public void setNote(String note) {
        this.note = note;
      }

      public String getDateOfBirth() {
        return dateOfBirth;
      }

      public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
      }

      public String getFirstName() {
        return firstName;
      }

      public void setFirstName(String firstName) {
        this.firstName = firstName;
      }

      public String getLasName() {
        return lasName;
      }

      public void setLasName(String lasName) {
        this.lasName = lasName;
      }

      private String country;
      private String code;
      private String name;
      private String bank_name;
      private String account_number;
      private String remittance_info;
      private String email;
      private String subject;
      private String note;
      private String dateOfBirth;
      private String firstName;
      private String lasName;
    }

    public String getId() {
      return id;
    }

    public void setId(String id) {
      this.id = id;
    }

    public String getObject() {
      return object;
    }

    public void setObject(String object) {
      this.object = object;
    }

    public String getStatus() {
      return status;
    }

    public void setStatus(String status) {
      this.status = status;
    }

    public String getStatus_reason() {
      return status_reason;
    }

    public void setStatus_reason(String status_reason) {
      this.status_reason = status_reason;
    }

    public int getAmount() {
      return amount;
    }

    public void setAmount(int amount) {
      this.amount = amount;
    }

    public String getCurrency() {
      return currency;
    }

    public void setCurrency(String currency) {
      this.currency = currency;
    }

    public String getDescription() {
      return description;
    }

    public void setDescription(String description) {
      this.description = description;
    }
  }

  public String getEvent_id() {
    return event_id;
  }

  public void setEvent_id(String event_id) {
    this.event_id = event_id;
  }

  public String getEvent() {
    return event;
  }

  public void setEvent(String event) {
    this.event = event;
  }

  public Data getData() {
    return data;
  }

  public void setData(Data data) {
    this.data = data;
  }

  public String getWebhook_token() {
    return webhook_token;
  }

  public void setWebhook_token(String webhook_token) {
    this.webhook_token = webhook_token;
  }

  public String getPreconditionStatus() {
    return preconditionStatus;
  }

  public void setPreconditionStatus(String preconditionStatus) {
    this.preconditionStatus = preconditionStatus;
  }

  public static class Meta {
    private String paymentId;

    public String getPaymentId() {
      return paymentId;
    }

    public void setPaymentId(String paymentId) {
      this.paymentId = paymentId;
    }
  }
}
