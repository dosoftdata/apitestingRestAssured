package apiResources.pojo.requests.accessService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class AddCustomerAccessAttribute {
  private String accessType;
  private String userType;
  private String userId;
  private String operationalUnit;
  private String reason;
  private String validTo;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String blockHours;

  public String getAccessType() {
    return accessType;
  }

  public void setAccessType(String accessType) {
    this.accessType = accessType;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getUserType() {
    return userType;
  }

  public void setUserType(String userType) {
    this.userType = userType;
  }

  public String getOperationalUnit() {
    return operationalUnit;
  }

  public void setOperationalUnit(String operationalUnit) {
    this.operationalUnit = operationalUnit;
  }

  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  public String getValidTo() {
    return validTo;
  }

  public void setValidTo(String validTo) {
    this.validTo = validTo;
  }

  public String getBlockHours() {return blockHours;}

  public void setBlockHours(String blockHours) {this.blockHours = blockHours;}
}
