package apiResources.pojo.requests.playerService;

public class VerifyDocument {

  private int verificationId;

  private String verificationType;

  private int documentId;

  private String statusDescription;

  public void setVerificationId(int verificationId) {
    this.verificationId = verificationId;
  }

  public int getVerificationId() {
    return verificationId;
  }

  public void setVerificationType(String verificationType) {
    this.verificationType = verificationType;
  }

  public String getVerificationType() {
    return verificationType;
  }

  public void setDocumentId(int documentId) {
    this.documentId = documentId;
  }

  public int getDocumentId() {
    return documentId;
  }

  public void setStatusDescription(String statusDescription) {
    this.statusDescription = statusDescription;
  }

  public String getStatusDescription() {
    return statusDescription;
  }
}
