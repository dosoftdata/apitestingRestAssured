package apiResources.pojo.requests.accessService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class AccessGroupMember {
  private String memberId;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String retailerId;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String updatedByUserId;

  public String getMemberId() {
    return memberId;
  }

  public void setMemberId(String memberId) {
    this.memberId = memberId;
  }

  public String getRetailerId() {
    return retailerId;
  }

  public void setRetailerId(String retailerId) {
    this.retailerId = retailerId;
  }

  public String getUpdatedByUserId() {
    return updatedByUserId;
  }

  public void setUpdatedByUserId(String updatedByUserId) {
    this.updatedByUserId = updatedByUserId;
  }
}
