package apiResources.pojo.requests.playerService;

public class ConfirmVerification {
  private int id;
  private String verificationType;

  public void setVerificationType(String verificationType) {
    this.verificationType = verificationType;
  }

  public String getVerificationType() {
    return verificationType;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }
}
