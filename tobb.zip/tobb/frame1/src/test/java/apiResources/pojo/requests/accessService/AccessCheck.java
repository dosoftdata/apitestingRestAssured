package apiResources.pojo.requests.accessService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class AccessCheck {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Users userRequest;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Users callerRequest;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String operationalUnit;

  public String getOperationalUnit() {
    return operationalUnit;
  }

  public void setOperationalUnit(String operationalUnit) {
    this.operationalUnit = operationalUnit;
  }

  public Users getUserRequest() {
    return userRequest;
  }

  public void setUserRequest(Users userRequest) {
    this.userRequest = userRequest;
  }

  public Users getCallerRequest() {
    return callerRequest;
  }

  public void setCallerRequest(Users callerRequest) {
    this.callerRequest = callerRequest;
  }

  public static class Users {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String userId;

    public String getUserId() {
      return userId;
    }

    public void setUserId(String userId) {
      this.userId = userId;
    }
  }
}
