package apiResources.pojo.requests.accessService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class CreateAssertion {
  private String type;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String ssoSessionId;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String userId;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String securityDomainName;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String issued;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String expires;

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }


  public String getSsoSessionId() {
    return ssoSessionId;
  }

  public void setSsoSessionId(String ssoSessionId) {
    this.ssoSessionId = ssoSessionId;
  }

  public String getSecurityDomainName() {
    return securityDomainName;
  }

  public void setSecurityDomainName(String securityDomainName) {
    this.securityDomainName = securityDomainName;
  }
  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getIssued() {
    return issued;
  }

  public void setIssued(String issued) {
    this.issued = issued;
  }

  public String getExpires() {
    return expires;
  }

  public void setExpires(String expires) {
    this.expires = expires;
  }

}
