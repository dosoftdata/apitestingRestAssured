package apiResources.pojo.requests.walletService;

public class CloseAccount {
  private String status;
  private String statusDescription;
  private String statusReason;

  public void setStatus(String status) {
    this.status = status;
  }
  public String getStatus() {
    return status;
  }

  public void setStatusDescription(String statusDescription) {this.statusDescription = statusDescription;}
  public String getStatusDescription() {
    return statusDescription;
  }

  public void setStatusReason(String statusReason) {this.statusReason = statusReason;}
  public String getStatusReason() {return statusReason;}

}
