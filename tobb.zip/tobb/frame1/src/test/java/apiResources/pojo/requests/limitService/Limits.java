package apiResources.pojo.requests.limitService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class Limits {
  private String limitType;
  private String quantityType;
  private Quantity quantity;
  private String period;
  private Scope scope;

  public String getLimitType() {
    return limitType;
  }

  public void setLimitType(String value) {
    this.limitType = value;
  }

  public String getQuantityType() {
    return quantityType;
  }

  public void setQuantityType(String value) {
    this.quantityType = value;
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  public static class Quantity {

    private Long durationInSeconds;
    private Long amount;

    private String currency;

    public Long getDurationInSeconds() {
      return durationInSeconds;
    }

    public void setDurationInSeconds(Long durationInSeconds) {
      this.durationInSeconds = durationInSeconds;
    }

    public Long getAmount() {
      return amount;
    }

    public void setAmount(Long amount) {
      this.amount = amount;
    }

    public String getCurrency() {
      return currency;
    }

    public void setCurrency(String currency) {
      this.currency = currency;
    }
  }

  public Quantity getQuantity() {
    return quantity;
  }

  public void setQuantity(Quantity value) {
    this.quantity = value;
  }

  public String getPeriod() {
    return period;
  }

  public void setPeriod(String value) {
    this.period = value;
  }

  public static class Scope {
    private String gameId;

    public String getGameId() {
      return gameId;
    }

    public void setGameId(String value) {
      this.gameId = value;
    }
  }

  public Scope getScope() {
    return scope;
  }

  public void setScope(Scope value) {
    this.scope = value;
  }
}
