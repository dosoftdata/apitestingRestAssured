package apiResources.pojo.requests.rabbitMQService;

public class GetQueueMessage {

  private int count;
  private String ackmode;
  private String encoding;
  private int truncate;

  public String getAckmode() {
    return ackmode;
  }

  public void setAckmode(String ackmode) {
    this.ackmode = ackmode;
  }

  public int getCount() {
    return count;
  }

  public void setCount(int count) {
    this.count = count;
  }

  public String getEncoding() {
    return encoding;
  }

  public void setEncoding(String encoding) {
    this.encoding = encoding;
  }

  public int getTruncate() {
    return truncate;
  }

  public void setTruncate(int truncate) {
    this.truncate = truncate;
  }
}
