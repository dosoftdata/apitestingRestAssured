package apiResources.pojo.requests.communicationService;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

public class BulkMessage {
  private String externalId;
  private String eventOwner;
  private String eventName;
  private Parameters parameters;
  private List<Recipients> recipients;

  public List<Recipients> getRecipients() {
    return recipients;
  }

  public void setRecipients(List<Recipients> recipients) {
    this.recipients = recipients;
  }

  public String getExternalId() {
    return externalId;
  }

  public void setExternalId(String externalId) {
    this.externalId = externalId;
  }

  public String getEventOwner() {
    return eventOwner;
  }

  public void setEventOwner(String eventOwner) {
    this.eventOwner = eventOwner;
  }

  public String getEventName() {
    return eventName;
  }

  public void setEventName(String eventName) {
    this.eventName = eventName;
  }

  public Parameters getParameters() {
    return parameters;
  }

  public void setParameters(Parameters parameters) {
    this.parameters = parameters;
  }

  public static class Parameters {
    public String getWagerId() {
      return wagerId;
    }

    public void setWagerId(String wagerId) {
      this.wagerId = wagerId;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String wagerId;
  }

  public static class Recipients {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String userId;

    public String getUserId() {
      return userId;
    }

    public void setUserId(String userId) {
      this.userId = userId;
    }
  }
}
