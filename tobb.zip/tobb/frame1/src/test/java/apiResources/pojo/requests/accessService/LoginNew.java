package apiResources.pojo.requests.accessService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class LoginNew {
  private String grant_type;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String username;

  private String password;
  private String channel;
  private String group;
  private String scope;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String otpCode;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private boolean rememberMe;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String verify_token;

  public boolean isRememberMe() {
    return rememberMe;
  }

  public void setRememberMe(boolean rememberMe) {
    this.rememberMe = rememberMe;
  }

  public String getVerify_token() {
    return verify_token;
  }

  public void setVerify_token(String verify_token) {
    this.verify_token = verify_token;
  }

  // Getter Methods
  public String getGrant_type() {
    return grant_type;
  }

  public String getUsername() {
    return username;
  }

  public String getPassword() {
    return password;
  }

  public String getChannel() {
    return channel;
  }

  public String getGroup() {
    return group;
  }

  public String getScope() {
    return scope;
  }

  public String getOtpCode() {
    return otpCode;
  }

  // Setter Methods
  public void setGrant_type(String grant_type) {
    this.grant_type = grant_type;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public void setChannel(String channel) {
    this.channel = channel;
  }

  public void setGroup(String group) {
    this.group = group;
  }

  public void setScope(String scope) {
    this.scope = scope;
  }

  public void setOtpCode(String otpCode) {
    this.otpCode = otpCode;
  }
}
