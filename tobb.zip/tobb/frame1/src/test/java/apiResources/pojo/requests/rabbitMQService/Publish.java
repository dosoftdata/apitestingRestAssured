package apiResources.pojo.requests.rabbitMQService;

import io.restassured.http.ContentType;

public class Publish {

  private Properties properties;
  private String routing_key;
  private String payload;
  private String payload_encoding;

  public static class Properties {
    public String contentType;

    public String getContentType() {
      return contentType;
    }

    public void setContentType(String contentType) {
      this.contentType = contentType;
    }
  }

  public Properties getProperties() {
    return properties;
  }

  public void setProperties(Properties properties) {
    this.properties = properties;
  }

  public String getRouting_key() {
    return routing_key;
  }

  public void setRouting_key(String routing_key) {
    this.routing_key = routing_key;
  }

  public String getPayload() {
    return payload;
  }

  public void setPayload(String payload) {
    this.payload = payload;
  }

  public String getPayload_encoding() {
    return payload_encoding;
  }

  public void setPayload_encoding(String payload_encoding) {
    this.payload_encoding = payload_encoding;
  }
}
