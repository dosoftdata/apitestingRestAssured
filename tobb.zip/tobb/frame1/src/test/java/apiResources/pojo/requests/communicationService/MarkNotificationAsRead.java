package apiResources.pojo.requests.communicationService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class MarkNotificationAsRead {

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private boolean read;

  public boolean isRead() {
    return read;
  }

  public void setRead(boolean read) {
    this.read = read;
  }
}
