package apiResources.pojo.requests.walletService;

public class CommitWithdrawal {

  private ServiceCost serviceCost;

  public ServiceCost getServiceCost() {
    return serviceCost;
  }

  public void setServiceCost(ServiceCost serviceCost) {
    this.serviceCost = serviceCost;
  }

  public boolean isForceReview() {
    return forceReview;
  }

  public void setForceReview(boolean forceReview) {
    this.forceReview = forceReview;
  }

  public String getAuditData() {
    return auditData;
  }

  public void setAuditData(String auditData) {
    this.auditData = auditData;
  }

  private boolean forceReview;
  private String auditData;

  public static class ServiceCost {
    private int amount;

    public int getAmount() {
      return amount;
    }

    public void setAmount(int amount) {
      this.amount = amount;
    }

    public String getCurrency() {
      return currency;
    }

    public void setCurrency(String currency) {
      this.currency = currency;
    }

    private String currency;
  }
}
