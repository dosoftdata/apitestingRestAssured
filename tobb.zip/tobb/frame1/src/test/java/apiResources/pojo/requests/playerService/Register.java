package apiResources.pojo.requests.playerService;

public class Register {
  private String username;
  private String password;
  private String email;
  private String identityType;
  private String identityNumber;
  private String firstName;
  private String middleName;

  private String lastName;
  private String gender;
  private String dateOfBirth;
  private String country;
  private String city;
  private String address1;
  private String zip;
  private String profession;
  private String phone;
  private String mobilePhone;
  private String bonusCode;
  private String secretQuestion;
  private String secretAnswer;
  private String ibanNumber;
  private String otpUuid;
  private String permanentResidenceCountry;

  // Getter Methods

  public String getUsername() {
    return username;
  }

  public String getPassword() {
    return password;
  }

  public String getEmail() {
    return email;
  }

  public String getIdentityType() {
    return identityType;
  }

  public String getIdentityNumber() {
    return identityNumber;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getMiddleName() {
    return middleName;
  }

  public String getLastName() {
    return lastName;
  }

  public String getGender() {
    return gender;
  }

  public String getDateOfBirth() {
    return dateOfBirth;
  }

  public String getCountry() {
    return country;
  }

  public String getCity() {
    return city;
  }

  public String getAddress1() {
    return address1;
  }

  public String getZip() {
    return zip;
  }

  public String getProfession() {
    return profession;
  }

  public String getPhone() {
    return phone;
  }

  public String getMobilePhone() {
    return mobilePhone;
  }

  public String getBonusCode() {
    return bonusCode;
  }

  public String getSecretQuestion() {
    return secretQuestion;
  }

  public String getSecretAnswer() {
    return secretAnswer;
  }

  public String getIbanNumber() {
    return ibanNumber;
  }

  public String getOtpUuid() {
    return otpUuid;
  }

  public String getpermanentResidenceCountry() {
    return permanentResidenceCountry;
  }

  // Setter Methods

  public void setUsername(String username) {
    this.username = username;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public void setIdentityType(String identityType) {
    this.identityType = identityType;
  }

  public void setIdentityNumber(String identityNumber) {
    this.identityNumber = identityNumber;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public void setMiddleName(String middleName) {
    this.middleName = middleName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public void setGender(String gender) {
    this.gender = gender;
  }

  public void setDateOfBirth(String dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public void setAddress1(String address1) {
    this.address1 = address1;
  }

  public void setZip(String zip) {
    this.zip = zip;
  }

  public void setProfession(String profession) {
    this.profession = profession;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public void setMobilePhone(String mobilePhone) {
    this.mobilePhone = mobilePhone;
  }

  public void setBonusCode(String bonusCode) {
    this.bonusCode = bonusCode;
  }

  public void setSecretQuestion(String secretQuestion) {
    this.secretQuestion = secretQuestion;
  }

  public void setSecretAnswer(String secretAnswer) {
    this.secretAnswer = secretAnswer;
  }

  public void setIbanNumber(String ibanNumber) {
    this.ibanNumber = ibanNumber;
  }

  public void setOtpUuid(String otpUuid) {
    this.otpUuid = otpUuid;
  }

  public void setPermanentResidenceCountry(String permanentResidenceCountry) {
    this.permanentResidenceCountry = permanentResidenceCountry;
  }
}
