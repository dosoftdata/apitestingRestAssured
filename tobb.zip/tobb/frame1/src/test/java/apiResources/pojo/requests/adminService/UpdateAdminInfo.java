package apiResources.pojo.requests.adminService;

import java.util.List;

public class UpdateAdminInfo {
    private String firstName;
    private String lastName;
    private String email;
    private String loginName;
    private java.util.List<Integer> groupIds;
    private int status;

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getLoginName() { return loginName; }
    public void setLoginName(String loginName) { this.loginName = loginName; }

    public List<Integer> getGroupIds() {
        return groupIds;
    }
    public void setGroupIds(List<Integer> groupIds) {
        this.groupIds = groupIds;
    }

    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
}
