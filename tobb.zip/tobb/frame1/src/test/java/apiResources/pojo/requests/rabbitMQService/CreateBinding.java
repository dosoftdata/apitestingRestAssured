package apiResources.pojo.requests.rabbitMQService;

import apiResources.pojo.requests.communicationService.BulkMessage;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

public class CreateBinding {

  private String source;
  private String vhost;
  private String routing_key;
  private String destination;
  private String destinationType;
  private Arguments arguments;

  public static class Arguments {

    public String getTest() {
      return test;
    }

    public void setTest(String test) {
      this.test = test;
    }

    // workaround . dont fill this field. or replace with a valid argument
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String test;
  }

  public String getSource() {
    return source;
  }

  public void setSource(String source) {
    this.source = source;
  }

  public String getVhost() {
    return vhost;
  }

  public void setVhost(String vhost) {
    this.vhost = vhost;
  }

  public String getRouting_key() {
    return routing_key;
  }

  public void setRouting_key(String routing_key) {
    this.routing_key = routing_key;
  }

  public String getDestination() {
    return destination;
  }

  public void setDestination(String destination) {
    this.destination = destination;
  }

  public String getDestinationType() {
    return destinationType;
  }

  public void setDestinationType(String destinationType) {
    this.destinationType = destinationType;
  }

  public Arguments getArguments() {
    return arguments;
  }

  public void setArguments(Arguments arguments) {
    this.arguments = arguments;
  }
}
