package apiResources.pojo.requests.drillHostService;

public class DrillHost {
  private String queryType;
  private String query;

  public String getQueryType() {
    return queryType;
  }

  public void setQueryType(String queryType) {
    this.queryType = queryType;
  }

  public String getQuery() {
    return query;
  }

  public void setQuery(String query) {
    this.query = query;
  }
}
