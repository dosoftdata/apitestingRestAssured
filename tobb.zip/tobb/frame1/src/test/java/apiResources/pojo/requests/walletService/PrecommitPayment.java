package apiResources.pojo.requests.walletService;

public class PrecommitPayment {
  private ServiceCost serviceCost;
  private String auditData;
  private boolean forceReview;
  private Issuer issuer;
  private boolean fraud;
  private PaymentMethod paymentMethod;

  public ServiceCost getServiceCost() {
    return serviceCost;
  }

  public void setServiceCost(ServiceCost serviceCost) {
    this.serviceCost = serviceCost;
  }

  public String getAuditData() {
    return auditData;
  }

  public void setAuditData(String auditData) {
    this.auditData = auditData;
  }

  public boolean isForceReview() {
    return forceReview;
  }

  public void setForceReview(boolean forceReview) {
    this.forceReview = forceReview;
  }

  public Issuer getIssuer() {
    return issuer;
  }

  public void setIssuer(Issuer issuer) {
    this.issuer = issuer;
  }

  public boolean isFraud() {
    return fraud;
  }

  public void setFraud(boolean fraud) {
    this.fraud = fraud;
  }

  public PaymentMethod getPaymentMethod() {
    return paymentMethod;
  }

  public void setPaymentMethod(PaymentMethod paymentMethod) {
    this.paymentMethod = paymentMethod;
  }

  public static class ServiceCost {
    private int amount;
    private String currency;

    public int getAmount() {
      return amount;
    }

    public void setAmount(int amount) {
      this.amount = amount;
    }

    public String getCurrency() {
      return currency;
    }

    public void setCurrency(String currency) {
      this.currency = currency;
    }
  }

  public static class Issuer {
    private int id;
    private int type;

    public int getId() {
      return id;
    }

    public void setId(int id) {
      this.id = id;
    }

    public int getType() {
      return type;
    }

    public void setType(int type) {
      this.type = type;
    }
  }

  public static class PaymentMethod {
    private String type;

    private String id;

    private Card card;

    private BankAccount bankAccount;

    private Voucher voucher;
    private PaymentCode paymentCode;
    private External external;

    public String getType() {
      return type;
    }

    public void setType(String type) {
      this.type = type;
    }

    public String getId() {
      return id;
    }

    public void setId(String id) {
      this.id = id;
    }

    public Card getCard() {
      return card;
    }

    public void setCard(Card card) {
      this.card = card;
    }

    public BankAccount getBankAccount() {
      return bankAccount;
    }

    public void setBankAccount(BankAccount bankAccount) {
      this.bankAccount = bankAccount;
    }

    public Voucher getVoucher() {
      return voucher;
    }

    public void setVoucher(Voucher voucher) {
      this.voucher = voucher;
    }

    public PaymentCode getPaymentCode() {
      return paymentCode;
    }

    public void setPaymentCode(PaymentCode paymentCode) {
      this.paymentCode = paymentCode;
    }

    public External getExternal() {
      return external;
    }

    public void setExternal(External external) {
      this.external = external;
    }

    public String getRealOwnerName() {
      return realOwnerName;
    }

    public void setRealOwnerName(String realOwnerName) {
      this.realOwnerName = realOwnerName;
    }

    public String getFingerPrint() {
      return fingerPrint;
    }

    public void setFingerPrint(String fingerPrint) {
      this.fingerPrint = fingerPrint;
    }

    private String realOwnerName;
    private String fingerPrint;

    public static class Card {

      private String cardName;
      private String cardNumber;
      private String expiryMonth;
      private String expiryYear;
      private String fingerprint;

      public String getCardName() {
        return cardName;
      }

      public void setCardName(String cardName) {
        this.cardName = cardName;
      }

      public String getCardNumber() {
        return cardNumber;
      }

      public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
      }

      public String getExpiryMonth() {
        return expiryMonth;
      }

      public void setExpiryMonth(String expiryMonth) {
        this.expiryMonth = expiryMonth;
      }

      public String getExpiryYear() {
        return expiryYear;
      }

      public void setExpiryYear(String expiryYear) {
        this.expiryYear = expiryYear;
      }

      public String getFingerprint() {
        return fingerprint;
      }

      public void setFingerprint(String fingerprint) {
        this.fingerprint = fingerprint;
      }
    }

    public static class BankAccount {
      private String bankId;
      private String accountNumber;
      private String bankPersonalId;

      public String getBankId() {
        return bankId;
      }

      public void setBankId(String bankId) {
        this.bankId = bankId;
      }

      public String getAccountNumber() {
        return accountNumber;
      }

      public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
      }

      public String getBankPersonalId() {
        return bankPersonalId;
      }

      public void setBankPersonalId(String bankPersonalId) {
        this.bankPersonalId = bankPersonalId;
      }
    }

    public static class Voucher {
      private String serial;

      public String getSerial() {
        return serial;
      }

      public void setSerial(String serial) {
        this.serial = serial;
      }
    }

    public static class PaymentCode {
      private String paymentCode;

      public String getPaymentCode() {
        return paymentCode;
      }

      public void setPaymentCode(String paymentCode) {
        this.paymentCode = paymentCode;
      }
    }

    public static class External {

      private String email;
      private String externalReferenceId;

      public String getEmail() {
        return email;
      }

      public void setEmail(String email) {
        this.email = email;
      }

      public String getExternalReferenceId() {
        return externalReferenceId;
      }

      public void setExternalReferenceId(String externalReferenceId) {
        this.externalReferenceId = externalReferenceId;
      }
    }
  }
}
