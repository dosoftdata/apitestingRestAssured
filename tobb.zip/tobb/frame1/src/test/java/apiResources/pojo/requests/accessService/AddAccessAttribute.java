package apiResources.pojo.requests.accessService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class AddAccessAttribute {
  private String accessType;
  private String operationalUnit;
  private String userId;
  private String reason;
  private String updatedByUserId;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String created;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String updated;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String operatorId;
//  private String valid;
@JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String validFrom;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String validTo;

  public String getAccessType() {
    return accessType;
  }

  public void setAccessType(String accessType) {
    this.accessType = accessType;
  }

  public String getOperationalUnit() {
    return operationalUnit;
  }

  public void setOperationalUnit(String operationalUnit) {
    this.operationalUnit = operationalUnit;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getCreated() {
    return created;
  }

  public void setCreated(String created) {
    this.created = created;
  }

  public String getUpdated() {
    return updated;
  }

  public void setUpdated(String updated) {
    this.updated = updated;
  }

  public String getUpdatedByUserId() {
    return updatedByUserId;
  }

  public void setUpdatedByUserId(String updatedByUserId) {
    this.updatedByUserId = updatedByUserId;
  }

  public String getOperatorId() {
    return operatorId;
  }

  public void setOperatorId(String operatorId) {
    this.operatorId = operatorId;
  }

  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

//  public String getValid() {
//    return valid;
//  }
//
//  public void setValid(String valid) {
//    this.valid = valid;
//  }

  public String getValidFrom() {
    return validFrom;
  }

  public void setValidFrom(String validFrom) {
    this.validFrom = validFrom;
  }
  public String getValidTo() {
    return validTo;
  }

  public void setValidTo(String validTo) {
    this.validTo = validTo;
  }
}
