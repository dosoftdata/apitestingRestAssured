package apiResources.pojo.requests.accessService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class AccessGroupMemberV2 {
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String action;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String accessGroupId;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String accessGroupMemberId;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String userId;

  public String getAction() {
    return action;
  }

  public void setAction(String action) {
    this.action = action;
  }

  public String getAccessGroupId() {
    return accessGroupId;
  }

  public void setAccessGroupId(String accessGroupId) {
    this.accessGroupId = accessGroupId;
  }

  public String getAccessGroupMemberId() {
    return accessGroupMemberId;
  }

  public void setAccessGroupMemberId(String accessGroupMemberId) {
    this.accessGroupMemberId = accessGroupMemberId;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }
}
