package apiResources.pojo.requests.promotionService;

public class BetEligibility {
  private int gameId;
  private int boards;
  private int consecutiveDraws;
  private boolean simpleBet;

  public int getGameId() {
    return gameId;
  }

  public void setGameId(int gameId) {
    this.gameId = gameId;
  }

  public int getBoards() {
    return boards;
  }

  public void setBoards(int boards) {
    this.boards = boards;
  }

  public int getConsecutiveDraws() {
    return consecutiveDraws;
  }

  public void setConsecutiveDraws(int consecutiveDraws) {
    this.consecutiveDraws = consecutiveDraws;
  }

  public boolean isSimpleBet() {
    return simpleBet;
  }

  public void setSimpleBet(boolean simpleBet) {
    this.simpleBet = simpleBet;
  }

  public int getCost() {
    return cost;
  }

  public void setCost(int cost) {
    this.cost = cost;
  }

  private int cost;
}
