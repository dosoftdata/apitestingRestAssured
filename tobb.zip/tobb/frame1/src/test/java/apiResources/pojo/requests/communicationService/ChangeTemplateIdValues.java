package apiResources.pojo.requests.communicationService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class ChangeTemplateIdValues {
  private String subject;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String status;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String senderAddress;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String senderName;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String replyToAddress;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String body;

  public String getSubject() {
    return subject;
  }
  public void setSubject(String subject) {
    this.subject = subject;
  }
  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getSenderAddress() {
    return senderAddress;
  }

  public void setSenderAddress(String senderAddress) {
    this.senderAddress = senderAddress;
  }

  public String getSenderName() {
    return senderName;
  }

  public void setSenderName(String category) {
    this.senderName = category;
  }

  public String getReplyToAddress() {
    return replyToAddress;
  }

  public void setReplyToAddress(String preferenceType) {
    this.replyToAddress = preferenceType;
  }
  public String getBody() {
    return body;
  }

  public void setBody(String preferenceType) {
    this.body = preferenceType;
  }
}
