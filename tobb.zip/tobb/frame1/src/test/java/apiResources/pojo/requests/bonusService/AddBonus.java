package apiResources.pojo.requests.bonusService;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;

public class AddBonus {

  private String rewardType;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String bonusAssignment;
  private String activationTrigger;
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String rewardAmountType;
  private List<LangDetail> langDetails = new ArrayList<>();
  private String bonusTerms;
  private String bonusValidFrom;
  private String bonusValidTo;
  private String minimumBets;
  private List<AllowedGame> allowedGames = new ArrayList<>();
  private String singleUse;
  private String rewardExpiryDays;
  private String rewardAmount;
  private int status;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String rollOver;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String program;

  public String getRollOver() {
    return rollOver;
  }

  public void setRollOver(String rollOver) {
    this.rollOver = rollOver;
  }

  public String getProgram() {
    return program;
  }

  public void setProgram(String program) {
    this.program = program;
  }

  public static class AllowedGame {
    private String gameType;
    private List<String> gameIds = new ArrayList<>();

    public String getGameType() {
      return gameType;
    }

    public void setGameType(String gameType) {
      this.gameType = gameType;
    }

    public List<String> getGameIds() {
      return gameIds;
    }

    public void setGameIds(List<String> gameIds) {
      this.gameIds = gameIds;
    }
  }

  public static class LangDetail {
    private String name;
    private String description;
    private String code;

    public String getName() {
      return name;
    }

    public void setName(String name) {
      this.name = name;
    }

    public String getDescription() {
      return description;
    }

    public void setDescription(String description) {
      this.description = description;
    }

    public String getCode() {
      return code;
    }

    public void setCode(String code) {
      this.code = code;
    }
  }

  public String getRewardType() {
    return rewardType;
  }

  public void setRewardType(String rewardType) {
    this.rewardType = rewardType;
  }

  public String getBonusAssignment() {
    return bonusAssignment;
  }

  public void setBonusAssignment(String bonusAssignment) {
    this.bonusAssignment = bonusAssignment;
  }

  public String getActivationTrigger() {
    return activationTrigger;
  }

  public void setActivationTrigger(String activationTrigger) {
    this.activationTrigger = activationTrigger;
  }

  public String getRewardAmountType() {
    return rewardAmountType;
  }

  public void setRewardAmountType(String rewardAmountType) {
    this.rewardAmountType = rewardAmountType;
  }

  public List<LangDetail> getLangDetails() {
    return langDetails;
  }

  public void setLangDetails(List<LangDetail> langDetails) {
    this.langDetails = langDetails;
  }

  public String getBonusTerms() {
    return bonusTerms;
  }

  public void setBonusTerms(String bonusTerms) {
    this.bonusTerms = bonusTerms;
  }

  public String getBonusValidFrom() {
    return bonusValidFrom;
  }

  public void setBonusValidFrom(String bonusValidFrom) {
    this.bonusValidFrom = bonusValidFrom;
  }

  public String getBonusValidTo() {
    return bonusValidTo;
  }

  public void setBonusValidTo(String bonusValidTo) {
    this.bonusValidTo = bonusValidTo;
  }

  public String getMinimumBets() {
    return minimumBets;
  }

  public void setMinimumBets(String minimumBets) {
    this.minimumBets = minimumBets;
  }

  public List<AllowedGame> getAllowedGames() {
    return allowedGames;
  }

  public void setAllowedGames(List<AllowedGame> allowedGames) {
    this.allowedGames = allowedGames;
  }

  public String getSingleUse() {
    return singleUse;
  }

  public void setSingleUse(String singleUse) {
    this.singleUse = singleUse;
  }

  public String getRewardExpiryDays() {
    return rewardExpiryDays;
  }

  public void setRewardExpiryDays(String rewardExpiryDays) {
    this.rewardExpiryDays = rewardExpiryDays;
  }

  public String getRewardAmount() {
    return rewardAmount;
  }

  public void setRewardAmount(String rewardAmount) {
    this.rewardAmount = rewardAmount;
  }

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }
}
