// Improve if needed is used temporary cause the full request is uknown.
package apiResources.pojo.requests.walletService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class CancelTransaction {
  private String id;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String referenceId;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getReferenceId() {
    return referenceId;
  }

  public void setReferenceId(String referenceId) {
    this.referenceId = referenceId;
  }
}
