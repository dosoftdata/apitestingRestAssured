package apiResources.pojo.requests.bonusService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class AssignBonus {
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String providerId;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String gameId;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String amount;

  public String getProviderId() {
    return providerId;
  }

  public void setProviderId(String providerId) {
    this.providerId = providerId;
  }

  public String getGameId() {
    return gameId;
  }

  public void setGameId(String gameId) {
    this.gameId = gameId;
  }

  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }
}
