package apiResources.pojo.requests.accessService;

public class AllowAdminAccessAttribute {
  private String operationalUnit;

  public String getOperationalUnit() {
    return operationalUnit;
  }

  public void setOperationalUnit(String operationalUnit) {
    this.operationalUnit = operationalUnit;
  }
}
