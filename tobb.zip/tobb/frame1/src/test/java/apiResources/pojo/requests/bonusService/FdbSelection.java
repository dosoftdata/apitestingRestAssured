package apiResources.pojo.requests.bonusService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class FdbSelection {
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String gameId;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String userId;

  public String getGameId() {
    return gameId;
  }

  public void setGameId(String gameId) {
    this.gameId = gameId;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }
}
