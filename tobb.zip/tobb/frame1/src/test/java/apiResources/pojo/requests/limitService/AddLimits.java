package apiResources.pojo.requests.limitService;

public class AddLimits {
  private String limitType;
  private String period;
  private Quantity quantity;
  private int amount;
  private String currency;
  private String quantityType;

  public String getLimitType() {
    return limitType;
  }

  public void setLimitType(String limitType) {
    this.limitType = limitType;
  }

  public String getPeriod() {
    return period;
  }

  public static class Quantity {
    private int amount;
    private String currency;

    public Integer getAmount() {
      return amount;
    }

    public void setAmount(Integer amount) {
      this.amount = amount;
    }

    public String getCurrency() {
      return currency;
    }

    public void setCurrency(String currency) {
      this.currency = currency;
    }
  }

  public void setPeriod(String period) {
    this.period = period;
  }

  public Quantity getQuantity() {
    return quantity;
  }

  public void setQuantity(Quantity quantity) {
    this.quantity = quantity;
  }

  public Integer getAmount() {
    return amount;
  }

  public void setAmount(Integer amount) {
    this.amount = amount;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public String getQuantityType() {
    return quantityType;
  }

  public void setQuantityType(String quantityType) {
    this.quantityType = quantityType;
  }
}
