package apiResources.pojo.requests.playerService;

public class VerifyIban {

  private String iban;

  private int id;

  public String getIban() {
    return iban;
  }

  public void setIban(String iban) {
    this.iban = iban;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }
}
