package apiResources.pojo.requests.bonusService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class FdbEnable {
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String fdbEnabled;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String fdbLinkEl;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private String fdbLinkEn;

  public String getFdbEnabled() {
    return fdbEnabled;
  }

  public void setFdbEnabled(String fdbEnabled) {
    this.fdbEnabled = fdbEnabled;
  }

  public String getFdbLinkEl() {
    return fdbLinkEl;
  }

  public void setFdbLinkEl(String fdbLinkEl) {
    this.fdbLinkEl = fdbLinkEl;
  }

  public String getFdbLinkEn() {
    return fdbLinkEn;
  }

  public void setFdbLinkEn(String fdbLinkEn) {
    this.fdbLinkEn = fdbLinkEn;
  }
}
