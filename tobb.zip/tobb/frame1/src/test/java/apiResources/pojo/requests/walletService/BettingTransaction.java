// designed for AT-MAIN-2 transaction endpoint
package apiResources.pojo.requests.walletService;

public class BettingTransaction {
  private String issued;
  private int prizeLevel;
  private String type;
  private String amount;
  private String referenceId;
  private String currency;
  private String description;
  private String fromDescription;
  private String toDescription;
  private String productId;
  private String state;
  private String batchId;
  private String subBatchId;
  private Metadata metadata;

  public Metadata getMetadata() {
    return metadata;
  }

  public void setMetadata(Metadata metadata) {
    this.metadata = metadata;
  }

  public static class Metadata {
    public String getValue() {
      return value;
    }

    public void setValue(String value) {
      this.value = value;
    }

    private String value;
  }

  public String getIssued() {
    return issued;
  }

  public void setIssued(String issued) {
    this.issued = issued;
  }

  public int getPrizeLevel() {
    return prizeLevel;
  }

  public void setPrizeLevel(int prizeLevel) {
    this.prizeLevel = prizeLevel;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }

  public String getReferenceId() {
    return referenceId;
  }

  public void setReferenceId(String referenceId) {
    this.referenceId = referenceId;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getFromDescription() {
    return fromDescription;
  }

  public void setFromDescription(String fromDescription) {
    this.fromDescription = fromDescription;
  }

  public String getToDescription() {
    return toDescription;
  }

  public void setToDescription(String toDescription) {
    this.toDescription = toDescription;
  }

  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getBatchId() {
    return batchId;
  }

  public void setBatchId(String batchId) {
    this.batchId = batchId;
  }

  public String getSubBatchId() {
    return subBatchId;
  }

  public void setSubBatchId(String subBatchId) {
    this.subBatchId = subBatchId;
  }

  public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public String getCallerServiceProviderId() {
    return callerServiceProviderId;
  }

  public void setCallerServiceProviderId(String callerServiceProviderId) {
    this.callerServiceProviderId = callerServiceProviderId;
  }

  public boolean isAutocapture() {
    return autocapture;
  }

  public void setAutocapture(boolean autocapture) {
    this.autocapture = autocapture;
  }

  private String transactionId;
  private String callerServiceProviderId;
  private boolean autocapture;
}
