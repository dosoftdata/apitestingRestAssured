package apiResources.pojo.requests.communicationService;

import com.fasterxml.jackson.annotation.JsonInclude;

public class ChangeNotificationIdValues {
  private String subject;
  private String status;
  private String senderAddress;
  private String senderName;
  private String replyToAddress;
  private String body;
  public String TargetUrl;

  public String getSubject() {
    return subject;
  }
  public void setSubject(String subject) {
    this.subject = subject;
  }
  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getSenderAddress() {
    return senderAddress;
  }

  public void setSenderAddress(String senderAddress) {
    this.senderAddress = senderAddress;
  }

  public String getSenderName() {
    return senderName;
  }

  public void setSenderName(String category) {
    this.senderName = category;
  }

  public String getReplyToAddress() {
    return replyToAddress;
  }

  public void setReplyToAddress(String preferenceType) {
    this.replyToAddress = preferenceType;
  }
  public String getBody() {
    return body;
  }

  public void setBody(String preferenceType) {
    this.body = preferenceType;
  }

  @JsonInclude(JsonInclude.Include.NON_NULL)
  public String getTargetUrl() {
    return TargetUrl;
  }

  public void setTargetUrl(String preferenceType) {
    this.TargetUrl = preferenceType;
  }
}
