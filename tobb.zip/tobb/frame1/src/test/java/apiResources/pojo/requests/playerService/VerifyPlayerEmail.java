package apiResources.pojo.requests.playerService;

public class VerifyPlayerEmail {

  private String playerId;
  private String hash;

  public String getPlayerId() {
    return playerId;
  }

  public String getHash() {
    return hash;
  }

  public void setHash(String hash) {
    this.hash = hash;
  }

  public void setPlayerId(String playerId) {
    this.playerId = playerId;
  }
}
