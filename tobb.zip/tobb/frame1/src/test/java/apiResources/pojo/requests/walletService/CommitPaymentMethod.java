package apiResources.pojo.requests.walletService;

public class CommitPaymentMethod {
  private String serviceProviderId;
  private String paymentMethodType;
  private String directionIn;

  private PlayerType createdBy;

  private PlayerType updatedBy;

  private String paymentMethodId;
  private String serviceProviderTargetId;
  private String email;

  public static class PlayerType {
    private String id;
    private int type;

    public int getType() {
      return type;
    }

    public void setType(int type) {
      this.type = type;
    }

    public String getId() {
      return id;
    }

    public void setId(String id) {
      this.id = id;
    }
  }

  public String getServiceProviderId() {
    return serviceProviderId;
  }

  public void setServiceProviderId(String serviceProviderId) {
    this.serviceProviderId = serviceProviderId;
  }

  public String getPaymentMethodType() {
    return paymentMethodType;
  }

  public void setPaymentMethodType(String paymentMethodType) {
    this.paymentMethodType = paymentMethodType;
  }

  public String getDirectionIn() {
    return directionIn;
  }

  public void setDirectionIn(String directionIn) {
    this.directionIn = directionIn;
  }

  public String getPaymentMethodId() {
    return paymentMethodId;
  }

  public PlayerType getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(PlayerType createdBy) {
    this.createdBy = createdBy;
  }

  public PlayerType getUpdatedBy() {
    return updatedBy;
  }

  public void setUpdatedBy(PlayerType updatedBy) {
    this.updatedBy = updatedBy;
  }

  public void setPaymentMethodId(String paymentMethodId) {
    this.paymentMethodId = paymentMethodId;
  }

  public String getServiceProviderTargetId() {
    return serviceProviderTargetId;
  }

  public void setServiceProviderTargetId(String serviceProviderTargetId) {
    this.serviceProviderTargetId = serviceProviderTargetId;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }
}
