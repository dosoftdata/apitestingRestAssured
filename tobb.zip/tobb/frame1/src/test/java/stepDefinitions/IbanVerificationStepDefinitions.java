package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.PlayerServiceData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import static io.restassured.RestAssured.given;

public class IbanVerificationStepDefinitions extends Utils {
  PlayerServiceData playerServiceData = new PlayerServiceData();

  @Then(
      "I verify Iban Pending Verification with status {string} or status {string} and iban {string}")
  public void iVerifyIbanPendingVerificationWithStatusOrStatusAndIban(
      String status1, String status2, String iban) {

    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    boolean success = false;

    for (var i = 0; i < count; i++) {
      String verificationType = js.get("verificationType[" + i + "]");

      if (verificationType.equals("IBAN")) {
        String responseStatus = js.get("status[" + i + "]");
        String ibanResponse = js.get("value[" + i + "]");

        if (responseStatus.equals(status1) || responseStatus.equals(status2)) {
          Assertions.assertTrue(true);
        } else {
          Assertions.fail(
              "Status "
                  + responseStatus
                  + "not expected. Status expected was: "
                  + status1
                  + "or "
                  + status2);
        }

        Assertions.assertEquals(iban, ibanResponse);
        success = true;

        ibanVerificationId = js.get("id[" + i + "]");

        System.out.println("Iban Verification Id is saved: " + ibanVerificationId);
        break;
      }
    }
    if (!success) {
      Assertions.fail("Verification Type IBAN not found");
    }
  }

  @Given("I create a Post VerifyIBAN payload with iban {string}")
  public void iCreateAPostVerifyIBANPayloadWithIban(String iban) {
    requestBody = playerServiceData.addVerifyIbanPayload(iban);
    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I verify Identity Pending Verification with status {string}")
  public void iVerifyIdentityPendingVerificationWithStatus(String status) {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    boolean success = false;

    for (var i = 0; i < count; i++) {
      String verificationType = js.get("verificationType[" + i + "]");

      if (verificationType.equals("IDENTITY")) {
        String responseStatus = js.get("status[" + i + "]");

        Assertions.assertEquals(status, responseStatus);

        success = true;

        identityVerificationId = js.get("id[" + i + "]");
        System.out.println("Identity Verification Id is saved: " + identityVerificationId);
        break;
      }
    }
    if (!success) {
      Assertions.fail("Verification Type IDENTITY not found");
    }
  }
}
