package stepDefinitions;

import static apiResources.endpoints.CommunicationServiceResources.smsId;
import static io.restassured.RestAssured.given;

import apiResources.Utils;
import apiResources.pojo.requests.accessService.ApiAccessAttributes;
import apiResources.pojo.requests.accessService.OperationalUnit;
import apiResources.testDataBuild.AccessServiceData;
import apiResources.testDataBuild.CommunicationServiceData;
import io.cucumber.java.ParameterType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.Assertions;
import apiResources.testDataBuild.WalletServiceData;

public class AccessStepDefinitions extends Utils {
  AccessServiceData accessServiceData = new AccessServiceData();
  WalletServiceData walletServiceData = new WalletServiceData();

  @Given(
      "I create a POST ApiAccessAttributes payload with {string} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
  public void iCreateAPOSTApiAccessAttributesPayloadWith(
      String accessType,
      String operationalUnit,
      String userId,
      String created,
      String updated,
      String updatedByUserId,
      String operatorId,
      String reason,
      String valid,
      String notifyStatus) {

    requestBody =
        accessServiceData.addApiAccessAttributes(
            accessType,
            operationalUnit,
            userId,
            created,
            updated,
            updatedByUserId,
            operatorId,
            reason,
            valid,
            notifyStatus);

    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given(
      "I create a POST ApiAccessAttributes validFrom validTo payload with {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
  public void iCreateAPOSTApiAccessAttributesPayloadWithValidFromValidTo(
      String accessType,
      String operationalUnit,
      String userId,
      String created,
      String updated,
      String updatedByUserId,
      String operatorId,
      String reason,
      String validFrom,
      String validTo,
      String notifyStatus) {

    requestBody =
        accessServiceData.addApiAccessAttributesValidFromValidTo(
            accessType,
            operationalUnit,
            userId,
            created,
            updated,
            updatedByUserId,
            operatorId,
            reason,
            validFrom,
            validTo,
            notifyStatus);

    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I create a LoginExternal Post payload with {string}")
  public void iCreateALoginExternalPostPayloadWith(String target) {
    requestBody = accessServiceData.addLoginExternalData(target);

    String specification = "mainSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create a LoginExternal Pending Post payload with {string}")
  public void iCreateALoginExternalPendingPostPayloadWith(String ssn) {
    requestBody = accessServiceData.addLoginExternalPendingData(ssn);

    String specification = "mainSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create a LoginExternal WrongRequest Post payload with {string}")
  public void iCreateALoginExternalWrongRequestPostPayloadWith(String request) {
    requestBody = accessServiceData.addLoginExternalWrongRequest(request);
    String specification = "mainSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create a DEL ForceLogoutCC payload with {string} {string}")
  public void iCreateADELForceLogoutCCPayloadWith(String reason, String group) {
    requestBody = accessServiceData.addForceLogoutCCData(reason, group);
    String specification = "cc_csrftokenSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I verify for group {string} the fields {int} {int} {int} for Get User Session")
  public void iVerifyGroupForGetUserSession(
      String group, int webActive, int webRememberMeActive, int webRememberMeTotal) {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");
    int successFound = 0;

    if (!group.equals("NEP") && !group.equals("EP")) {
      throw new RuntimeException("Wrong group in Gherkin: " + group);
    }

    for (int i = 0; i < count; i++) {
      Object actualGroup = js.get("[" + i + "]." + "group");
      Object actualWebActive = js.get("[" + i + "]." + "WEB.active");
      Object actualWebRememberMeActive = js.get("[" + i + "]." + "WEB.rememberMe.active");
      Object actualRememberMeTotal = js.get("[" + i + "]." + "WEB.rememberMe.total");

      if (actualGroup.equals(group)) {
        Assertions.assertEquals(webActive, actualWebActive);
        Assertions.assertEquals(webRememberMeActive, actualWebRememberMeActive);
        Assertions.assertEquals(webRememberMeTotal, actualRememberMeTotal);
        successFound++;
      }
    }
    if (successFound == 0) {
      Assertions.fail("No NEP or EP groups found");
    }
  }

  @Then("I check access groups")
  public void checkAccessGroups() {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("$.size()");

    for (int i = 0; i < count; i++) {
      String name = js.get("name[" + i + "]");
      Integer memberType = js.get("memberType[" + i + "]");
      String updatedByUserId = js.get("updatedByUserId[" + i + "]");
      String description = js.get("description[" + i + "]");

      switch (name) {
        case "Technician":
          Assertions.assertEquals(memberType, 3);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(description, "Group of admins having technician role");
          break;
        case "Master Clerk":
          Assertions.assertEquals(memberType, 4);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(description, "Group of clerks that have all access rights");
          break;
        case "Super Admin":
          Assertions.assertEquals(memberType, 3);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(
              description, "Group of admins that have full access to all Backoffice functionality");
          break;
        case "clerk":
          Assertions.assertEquals(memberType, 3);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(
              description, "Group of admins that have full access to Affiliate app");
          break;
        case "NO_PLAYER_LEVEL":
          Assertions.assertEquals(memberType, 1);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(description, "Access group for NO_PLAYER_LEVEL player level.");
          break;
        case "TEMPORARY_ACCOUNT":
          Assertions.assertEquals(memberType, 1);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(description, "Access group for TEMPORARY_ACCOUNT player level.");
          break;
        case "VERIFIED_ACCOUNT":
          Assertions.assertEquals(memberType, 1);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(description, "Access group for VERIFIED_ACCOUNT player level.");
          break;
        case "FULL_ACCOUNT":
          Assertions.assertEquals(memberType, 1);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(description, "Access group for FULL_ACCOUNT player level.");
          break;
        case "ONLY_KYC_ACCESS_ACCOUNT":
          Assertions.assertEquals(memberType, 1);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(
              description, "Access group for ONLY_KYC_ACCESS_ACCOUNT player level.");
          break;
        case "EXCLUSIVE_GAMES_ONLY":
          Assertions.assertEquals(memberType, 1);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(description, "Access group for EXCLUSIVE GAMES only");
          break;
        case "NON_EXCLUSIVE_GAMES_ONLY":
          Assertions.assertEquals(memberType, 1);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(description, "Access group for NON EXCLUSIVE GAMES only");
          break;
        case "FRIENDS_AND_FAMILY":
          Assertions.assertEquals(memberType, 1);
          Assertions.assertEquals(updatedByUserId, "0-");
          Assertions.assertEquals(description, "Access group for FRIENDS & FAMILY");
          String friendsAndFamilyGroupId = getJsonPath(response, "accessGroupId");
          System.out.println("friendsAndFamilyGroupId saved: " + friendsAndFamilyGroupId);

          break;
        default:
          Assertions.fail("Unexpected access group found: " + name);
      }
    }
  }

  @And("I create a Login as Affiliate user Post payload with {string}")
  public void iloginAsAffiliateUser(String loginName) {
    requestBody = accessServiceData.addLoginAsAffiliateUser(loginName);

    res = given().spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec")).body(requestBody);
  }

  @And("I create a Login as HighWinnings user Post payload with {string} {string}")
  public void iloginAsHighWinningsUser(String loginName, String password) {
    requestBody = accessServiceData.addLoginAsHighWinningsUser(loginName, password);

    res = given().spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec")).body(requestBody);
  }

  @And("I Login as HighWinnings user Post payload for Azure after password update")
  public void iloginAsHighWinningsUserAzureUpdate() {
    requestBody = accessServiceData.addLoginAsHighWinningsUserAzureAfterUpdate();

    res = given().spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec")).body(requestBody);
  }

  @And("I Login as HighWinnings user Post payload for Azure before password update")
  public void iloginAsHighWinningsUserAzure() {
    requestBody = accessServiceData.addLoginAsHighWinningsUserAzureBeforeUpdate();

    res = given().spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec")).body(requestBody);
  }

  @Given(
      "I create a POST ApiAccessAttributes payload for friendsAndFamilyGroupId with {string} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
  public void iCreateAPOSTApiAccessAttributesPayloadForFriendsAndFamilyGroupIdWith(
      String accessType,
      String operationalUnit,
      String userId,
      String created,
      String updated,
      String updatedByUserId,
      String operatorId,
      String reason,
      String validFrom,
      String validTo) {

    List<Object> requestBodyList = new ArrayList<>();

    requestBody =
        accessServiceData.addApiAccessAttributesForFriendsAndFamilyGroupId(
            accessType,
            operationalUnit,
            userId,
            created,
            updated,
            updatedByUserId,
            operatorId,
            reason,
            validFrom,
            validTo);

    requestBodyList.add(requestBody);

    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBodyList);
  }

  @Given("I create a RolesAdminCC payload with {string} {string}")
  public void iCreateAPOSTRolesAdminCCPayloadWith(String name, String description) {
    requestBody = accessServiceData.addNewAccessRole(name, description);
    String specification = "cc_csrftokenSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I copy the value of the roleId from the response")
  public void iCopyTheValueOfTheRoleIdFromTheResponse() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    roleIdCC = jsonPathEvaluator.getInt(""); // not sure here debug.
    System.out.println("RoleIdCC saved: " + roleIdCC);
  }

  // checks for the specific 3 roles. can be improved but these are the important I think.
  @And("I verify the admin roles Technician Super Admin Clerk")
  public void iVerifyTheAdminRolesTechnicianSuperAdminClerk() {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");
    int successFound = 0;

    for (int i = 0; i < count; i++) {
      Object actualName = js.get("[" + i + "]." + "name");
      Object actualDescription = js.get("[" + i + "]." + "description");
      Object accessRoleId = js.get("[" + i + "]." + "accessRoleId");

      if (actualName.equals("Technician")) {
        Assertions.assertEquals("Group of admins having technician role", actualDescription);
        successFound++;
      } else if (actualName.equals("Super Admin")) {
        Assertions.assertEquals(
            "Group of admins that have full access to all Backoffice functionality",
            actualDescription);
        superAdminAccessId = accessRoleId.toString();
        successFound++;
      } else if (actualName.equals("clerk")) {
        Assertions.assertEquals(
            "Group of admins that have full access to Affiliate app", actualDescription);
        successFound++;
      }
    }
    if (successFound < 3) {
      Assertions.fail("Some role is missing. " + successFound + " roles found");
    }
    System.out.println("Found: " + successFound + " roles");
    System.out.println("SuperAdminAccessId has value: " + superAdminAccessId);
  }

  @And("I verify get modules response")
  public void iVerifyGetModulesResponse() {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");
    int successFound = 0;
    ArrayList<Integer> arrlist;
    int countAccessOperations = 0;

    for (int i = 0; i < count; i++) {
      Object moduleId = js.get("[" + i + "]." + "moduleId");
      Object name = js.get("[" + i + "]." + "name");
      Object resources = js.get("[" + i + "]." + "resources");
      arrlist = (ArrayList<Integer>) resources;
      int countResources = arrlist.size();

      if (moduleId.equals("admin.admins")) {
        Assertions.assertEquals("Admins", name);
        Assertions.assertEquals(2, countResources, "Wrong number of resources (Admins)");
        Object accessOperations0 = js.get("[" + i + "]." + "resources[0].accessOperations");
        arrlist = (ArrayList<Integer>) accessOperations0;
        countAccessOperations = arrlist.size();
        Assertions.assertEquals(
            6, countAccessOperations, "Wrong number of accessOperations (Admins)");

        successFound++;

        // pm.expect(jsonData[i].resources[0].accessOperations[0].accessOperationId).to.eql("create");
      } else if (moduleId.equals("admin.bonus")) {
        Assertions.assertEquals("Bonus", name);
        Assertions.assertEquals(4, countResources, "Wrong number of resources (Bonuses)");

        successFound++;
        // pm.expect(jsonData[i].resources[0].accessOperations[0].accessOperationId).to.eql("create");
      } else if (moduleId.equals("admin.messages")) {
        Assertions.assertEquals("Messages", name);
        Assertions.assertEquals(2, countResources, "Wrong number of resources (messages)");

        successFound++;
      } else if (moduleId.equals("admin.payments")) {
        Assertions.assertEquals("payments", name);
        Assertions.assertEquals(5, countResources, "Wrong number of resources (payments)");

        successFound++;
      } else if (moduleId.equals("admin.players")) {
        Assertions.assertEquals("Players", name);

        successFound++;
      } else if (moduleId.equals("admin.wagers")) {
        Assertions.assertEquals("wagers", name);
        Assertions.assertEquals(1, countResources, "Wrong number of wagers");
        successFound++;
      }
    }
    if (successFound < 6) {
      Assertions.fail(
          "Some moduleId is missing. Found " + successFound + "moduleIds while expecting 6");
    }
  }

  @Given("I create A PUT AllowAdminAccessAttributes payload with {string}")
  public void iCreateAPUTAllowAdminAccessAttributesPayloadWith(String operationalUnit) {
    requestBody = accessServiceData.addAllowAdminAccessAttribute(operationalUnit);
    String specification = "cc_csrftokenSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create an Assign_Access_Roles_for_Clerk payload")
  public void i_create_Assign_Access_Roles_for_Clerk_payload() {
    requestBody = accessServiceData.getOperationalUnitsPayload();

    String specification = "cc_csrftokenSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And(
      "I create a POST CustomerAccessAttributes payload with {string} {string} {string} {string} {string} {string} {string}")
  public void iCreateAPOSTCustomerAccessAttributesPayloadWith(
      String accessType,
      String userType,
      String userId,
      String operationalUnit,
      String validTo,
      String reason,
      String blockHours) {

    if (validTo.equals("datenow")) {
      validTo = calculateDateNowInSecondsToString();
    }
    requestBody =
        accessServiceData.addCustomerAccessAttributes(
            accessType, userType, userId, operationalUnit, validTo, reason, blockHours);

    String specification = "cc_csrftokenSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create a POST AccessCheckV2 payload with {string} {string} {string}")
  public void iCreateAPOSTAccessCheckVPayloadWith(
      String userRequest, String callerRequest, String operationalUnit) {

    requestBody = accessServiceData.addAccessCheckData(userRequest, callerRequest, operationalUnit);

    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And(
      "I create a PUT CreateAssertion payload with {string} {string} {string} {string} {string} {string}")
  public void iCreateAPUTCreateAssertionPayloadWith(
      String type,
      String ssoSessionId,
      String userId,
      String securityDomainName,
      String issued,
      String expires) {

    if (issued.equals("datenow")) {
      issued = calculateDateNowInSecondsToString();
    }
    if (expires.equals("datenow")) {
      expires = calculateDateNowInSecondsToString();
    }
    requestBody =
        accessServiceData.createAssertion(
            type, ssoSessionId, userId, securityDomainName, issued, expires);

    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I create a Post RestrictUser payload with {string} {string} {string} {string}")
  public void iCreateAPostRestrictUserPayloadWith(
      String depositId, String depositAccessType, String withdrawId, String withdrawAccessType) {
    requestBody =
        walletServiceData.Restrictuser(
            depositId, depositAccessType, withdrawId, withdrawAccessType);
    String specification = "cc_csrftokenSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I check buy, withdrawals, payout, deposits operations with {string} {string} {string}")
  public void iCheckOperations(
      String DepositAccessType, String WithdrawAccessType, String BuyAccessType) {
    JsonPath js = new JsonPath(response.asString());
    int payoutCount = js.getInt("payout.size()");
    String[] depositAccessType = DepositAccessType.split(",");
    String[] withdrawAccessType = WithdrawAccessType.split(",");
    String[] buyAccessType = BuyAccessType.split(",");

    for (int i = 0; i < payoutCount; i++) {
      Assertions.assertEquals("ALL", js.getString("payout[" + i + "].id"));
      Assertions.assertEquals("ALLOW", js.getString("payout[" + i + "].accessType"));
      Assertions.assertTrue(js.getBoolean("payout[" + i + "].settable"));
      Assertions.assertEquals("", js.getString("payout[" + i + "].reason"));
    }

    int depositCount = js.getInt("deposit.size()");

    String[][] expectedDeposit = {
      {"CARD", "true", ""},
      {"SKRILL", "true", ""},
      {"PAYPAL", "true", ""},
      {"PAYSAFECARD", "true", ""},
      {"APPLE_PAY", "true", ""},
      {"GOOGLE_PAY", "true", ""},
      {"IRIS", "true", ""},
      {"PAYMENT_CODE", "true", ""},
      {"CASH", "true", ""},
      {"ALL", "true", ""}
    };

    for (int i = 0; i < depositCount; i++) {
      Assertions.assertEquals(expectedDeposit[i][0], js.getString("deposit[" + i + "].id"));
      Assertions.assertEquals(depositAccessType[i], js.getString("deposit[" + i + "].accessType"));
      Assertions.assertEquals(
          Boolean.parseBoolean(expectedDeposit[i][1]),
          js.getBoolean("deposit[" + i + "].settable"));
      Assertions.assertEquals(expectedDeposit[i][2], js.getString("deposit[" + i + "].reason"));
    }

    int buyCount = js.getInt("buy.size()");

    String[][] expectedBuy = {
      {"ALL", "true", "MANDATORY_LIMITS_NOT_SET"},
      {"CASINO", "false", ""},
      {"SPORTSBOOK", "false", ""},
      {"EUROJACKPOT", "true", "MANDATORY_LIMITS_NOT_SET"},
      {"JOKER", "true", "MANDATORY_LIMITS_NOT_SET"},
      {"PROTO", "true", "MANDATORY_LIMITS_NOT_SET"},
      {"LOTTO", "true", "MANDATORY_LIMITS_NOT_SET"},
      {"OPAPONLINE", "true", ""},
      {"KINO", "true", "MANDATORY_LIMITS_NOT_SET"},
      {"SUPER3", "true", "MANDATORY_LIMITS_NOT_SET"}
    };

    for (int i = 0; i < buyCount; i++) {
      Assertions.assertEquals(expectedBuy[i][0], js.getString("buy[" + i + "].id"));
      Assertions.assertEquals(buyAccessType[i], js.getString("buy[" + i + "].accessType"));
      Assertions.assertEquals(
          Boolean.parseBoolean(expectedBuy[i][1]), js.getBoolean("buy[" + i + "].settable"));
      Assertions.assertEquals(expectedBuy[i][2], js.getString("buy[" + i + "].reason"));
    }

    int withdrawCount = js.getInt("withdraw.size()");

    String[][] expectedWithdraw = {
      {"CARD", "true", ""},
      {"IBAN", "true", ""},
      {"SKRILL", "true", ""},
      {"PAYPAL", "true", ""},
      {"PAYSAFECARD", "true", ""},
      {"APPLE_PAY", "true", ""},
      {"ALL", "true", ""}
    };

    for (int i = 0; i < withdrawCount; i++) {
      Assertions.assertEquals(expectedWithdraw[i][0], js.getString("withdraw[" + i + "].id"));
      Assertions.assertEquals(
          withdrawAccessType[i], js.getString("withdraw[" + i + "].accessType"));
      Assertions.assertEquals(
          Boolean.parseBoolean(expectedWithdraw[i][1]),
          js.getBoolean("withdraw[" + i + "].settable"));
      Assertions.assertEquals(expectedWithdraw[i][2], js.getString("withdraw[" + i + "].reason"));
    }
  }

  @And("I check EP, NEP wallets")
  public void iCheckWalletsForV2() {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("$.size()");

    for (int i = 0; i < count; i++) {
      String accountGroup = js.getString("[" + i + "].accountGroup");
      String accountType = js.getString("[" + i + "].accountId.accountType");
      String accountNumber = js.getString("[" + i + "].accountId.accountNumber");
      String depositId = js.getString("[" + i + "].accessOperations.deposit[0].id");
      String accessType = js.getString("[" + i + "].accessOperations.deposit[0].accessType");
      boolean settable = js.getBoolean("[" + i + "].accessOperations.deposit[0].settable");
      String reason = js.getString("[" + i + "].accessOperations.deposit[0].reason");

      if (accountGroup.equals("NonExclusive")) {
        Assertions.assertEquals("AT_MAIN", accountType);
        Assertions.assertEquals("2", accountNumber);
      } else {
        Assertions.assertEquals("Exclusive", accountGroup);
        Assertions.assertEquals("AT_MAIN", accountType);
        Assertions.assertEquals("1", accountNumber);
      }

      Assertions.assertEquals("CARD", depositId);
      Assertions.assertEquals("DENY", accessType);
      Assertions.assertEquals(true, settable);
      Assertions.assertEquals("", reason);
    }
  }

  @And("I verify the 12 mandatory groups")
  public void iVerifyTheMandatoryGroups() {

    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");
    int successFound = 0;

    for (int i = 0; i < count; i++) {
      Object actualName = js.get("[" + i + "]." + "name");
      Object actualDescription = js.get("[" + i + "]." + "description");
      Object accessGroupId = js.get("[" + i + "]." + "accessGroupId");
      Object memberType = js.get("[" + i + "]." + "memberType");
      Object updatedByUserId = js.get("[" + i + "]." + "updatedByUserId");

      if (actualName.equals("Technician")) {
        Assertions.assertEquals("Group of admins having technician role", actualDescription);
        Assertions.assertEquals(3, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        technicianRoleId = accessGroupId.toString();
        successFound++;

      } else if (actualName.equals("Super Admin")) {
        Assertions.assertEquals(
            "Group of admins that have full access to all Backoffice functionality",
            actualDescription);
        Assertions.assertEquals(3, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        superAdminAccessId = accessGroupId.toString();
        successFound++;
      } else if (actualName.equals("clerk")) {
        Assertions.assertEquals(
            "Group of admins that have full access to Affiliate app", actualDescription);
        Assertions.assertEquals(3, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        clerkAccessRoleId = accessGroupId.toString();
        successFound++;
      } else if (actualName.equals("Master Clerk")) {
        Assertions.assertEquals("Group of clerks that have all access rights", actualDescription);
        Assertions.assertEquals(4, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        successFound++;
      } else if (actualName.equals("NO_PLAYER_LEVEL")) {
        Assertions.assertEquals(
            "Access group for NO_PLAYER_LEVEL player level.", actualDescription);
        Assertions.assertEquals(1, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        successFound++;
      } else if (actualName.equals("TEMPORARY_ACCOUNT")) {
        Assertions.assertEquals(
            "Access group for TEMPORARY_ACCOUNT player level.", actualDescription);
        Assertions.assertEquals(1, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        successFound++;
      } else if (actualName.equals("VERIFIED_ACCOUNT")) {
        Assertions.assertEquals(
            "Access group for VERIFIED_ACCOUNT player level.", actualDescription);
        Assertions.assertEquals(1, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        successFound++;
      } else if (actualName.equals("FULL_ACCOUNT")) {
        Assertions.assertEquals("Access group for FULL_ACCOUNT player level.", actualDescription);
        Assertions.assertEquals(1, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        successFound++;
        fullAccountAccessGroupId = accessGroupId.toString(); // 7 everywhere?
      } else if (actualName.equals("ONLY_KYC_ACCESS_ACCOUNT")) {
        Assertions.assertEquals(
            "Access group for ONLY_KYC_ACCESS_ACCOUNT player level.", actualDescription);
        Assertions.assertEquals(1, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        successFound++;
      } else if (actualName.equals("EXCLUSIVE_GAMES_ONLY")) {
        Assertions.assertEquals("Access group for EXCLUSIVE GAMES only", actualDescription);
        Assertions.assertEquals(1, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        successFound++;
      } else if (actualName.equals("NON_EXCLUSIVE_GAMES_ONLY")) {
        Assertions.assertEquals("Access group for NON EXCLUSIVE GAMES only", actualDescription);
        Assertions.assertEquals(1, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        successFound++;
      } else if (actualName.equals("FRIENDS_AND_FAMILY")) {
        Assertions.assertEquals("Access group for FRIENDS & FAMILY", actualDescription);
        Assertions.assertEquals(1, memberType);
        Assertions.assertEquals("0-", updatedByUserId);
        successFound++;
      }
    }
    if (successFound < 12) {
      Assertions.fail("Some role is missing. " + successFound + " roles found");
    }
    System.out.println("Found: " + successFound + " roles");
    System.out.println("SuperAdminAccessId has value: " + superAdminAccessId);
    System.out.println("FullAccountAccessGroupId has value: " + fullAccountAccessGroupId);
  }

  @Given("I create a POST AccessGroups payload with {string} {string} {string} {string}")
  public void iCreateAPOSTAccessGroupsPayloadWith(
      String name, String description, String updatedByUserId, String memberType) {
    requestBody =
        accessServiceData.addAccessGroupsData(name, description, updatedByUserId, memberType);

    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I copy the value of the newAccessGroupId from the response")
  public void iCopyTheValueOfTheNewAccessGroupIdFromTheResponse() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    newAccessGroupId = jsonPathEvaluator.get("accessGroupId");
    System.out.println("New Access Group Id  is saved: " + newAccessGroupId);
  }

  @And(
      "I create a Post Assign Access Attribute of Feature with wrong customerId payload with {string}")
  public void iCreateAssignAccessAttributeFeaturePayloadWrongCustomerIdWith(String feature) {
    requestBody = accessServiceData.addAssignAccessAttributeFeatureWrongCustomerId(feature);
    String specification = "cc_csrftokenSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I create a Post Assign Access Attribute of Feature payload with {string}")
  public void iCreateAssignAccessAttributeFeaturePayloadWith(String feature) {
    requestBody = accessServiceData.addAssignAccessAttributeFeature(feature);
    String specification = "cc_csrftokenSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I create a Post Assign Access Attribute of Feature for Negative cases payload")
  public void iCreateAssignAccessAttributeFeatureNegativePayloadWith() {

    requestBody = accessServiceData.addAssignAccessAttributeFeatureTest();
    String specification = "cc_csrftokenSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I create a Post Assign Access Attribute of Feature payload {string} {string}")
  public void iCreateAssignAccessAttributeFeatureEmptyCustomerIdPayloadWith(
      String feature, String customerIds) {
    List<String> customerIdsList = new ArrayList<>();
    if (customerIds.equals("changeitwrong")) {
      customerIds = "1-" + playerId;
    } else if (customerIds.equals("changeit")) {
      customerIds = playerId;
    } else if (customerIds.equals("changeit1")) {
      customerIds = "0-0";
    }
    String[] customerIdsArray = customerIds.split(",");
    for (String customerId : customerIdsArray) {
      customerIdsList.add(customerId.trim());
      requestBody = accessServiceData.addFeatureFlag(feature, customerIdsList);
      String specification = "cc_csrftokenSpec";
      res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }
  }

  @And("I create a Post Enable Feature for payload with {string}")
  public void iEnableFeaturePayloadWith(String feature) {

    requestBody = accessServiceData.addEnableFeature(feature);
    String specification = "cc_csrftokenSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I check if BO user exists with loginName {string} and lastName {string}")
  public void iCheckIfuserExists(String loginName, String lastName) {
    JsonPath jsonPathEvaluator = response.jsonPath();
    String foundLoginName =
        jsonPathEvaluator.getString(
            "data.find { it.loginName == '"
                + loginName
                + "' && it.lastName == '"
                + lastName
                + "' }.loginName");

    userExists = foundLoginName != null;
    System.out.println("User exists flag is set to: " + userExists);
  }

  @Given("I create an AdminRolesV2 payload with roleId {string}")
  public void iCreateAnAdminRolesVPayloadWithRoleId(String roleId) {
    if (roleId.equals("superAdminAccessId")) {
      roleId = superAdminAccessId;
    }
    requestBody = accessServiceData.addAdminRoleIdData(roleId);

    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create a AccessRoleIdV2 payload with {string}")
  public void iCreateAAccessRoleIdVPayloadWith(String memberId) {
    requestBody = accessServiceData.addAccessRoleV2data(memberId);
    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I create new High Winnings user for Azure")
  public void iCreateUserForAzure() {
    String baseUsername = "highw";
    String baseEmail = "ceca";
    String endEmail = "@oziere.com";
    int randomNumber = new Random().nextInt(10000); // 0–9999
    azureHighWinningsUsername = baseUsername + randomNumber;
    azureHighWinningsEmail = baseEmail + randomNumber + endEmail;
    System.out.println("Generated Username: " + azureHighWinningsUsername);
    System.out.println("Generated Email: " + azureHighWinningsEmail);
  }

  @And("I verify field {string} in response body has the new calculated accessGroupId value")
  public void iVerifyFieldInResponseBodyHasTheNewCalculatedAccessGroupIdValue(String field) {
    Assertions.assertEquals(newAccessGroupId, getJsonPath(response, field));
  }

  @And("I verify field {string} in response body has the new calculated accessGroupName value")
  public void iVerifyFieldInResponseBodyHasTheNewCalculatedAccessGroupNameValue(String field) {
    Assertions.assertEquals(accessGroupName, getJsonPath(response, field));
  }

  @Given("I create a POST AccessGroupMembers payload with {string} {string} {string}")
  public void iCreateAPOSTAccessGroupMembersPayloadWith(
      String memberId, String retailerId, String updatedByUserId) {
    requestBody =
        accessServiceData.addAccessGroupMembersData(memberId, retailerId, updatedByUserId);
    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create a PUT AccessGroupsV2 payload with array {string} {string} {string} {string}")
  public void iCreateAPOSTAccessGroupsVPayloadWithArray(
      String actions, String accessGroupIds, String accessGroupMemberIds, String userIds) {
    String specification = "api_mainSpec_mainHost";

    String[] actionList = actions.split(",");
    String[] accessGroupIdList = accessGroupIds.split(",");
    String[] accessGroupMemberIdList = accessGroupMemberIds.split(",");
    String[] userIdList = userIds.split(",");

    List<Object> accessGroupItems = new ArrayList<>();

    for (int i = 0; i < actionList.length; i++) {
      Object item =
          accessServiceData.addAccessGroupMembersV2Data(
              actionList[i], accessGroupIdList[i], accessGroupMemberIdList[i], userIdList[i]);
      accessGroupItems.add(item);
      requestBody = accessGroupItems;
    }

    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I copy the value of the newGroupMemberId from the response")
  public void iCopyTheValueOfTheNewGroupMemberIdFromTheResponse() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    newGroupMemberId = jsonPathEvaluator.get("accessGroupMemberId");
    System.out.println("newGroupMemberId saved: " + newGroupMemberId);
  }

  @And("the {string} in response body is the calculated newAccessGroupId")
  public void theInResponseBodyIsTheCalculatedNewAccessGroupId(String field) {
    Assertions.assertEquals(newAccessGroupId, getJsonPath(response, field));
  }

  @Given(
      "I create a POST LoginApi specification {string} with payload {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
  public void iCreateAPOSTLoginApiPayloadWith(
      String specification,
      String grantType,
      String code,
      String refreshToken,
      String retailerId,
      String betwareRetailerId,
      String betwareTerminalId,
      String clientAssertion,
      String clientAssertionType,
      String clientSecret,
      String clientId,
      String username,
      String password,
      String cardNumber,
      String pin,
      String assertion,
      String claims) {

    requestBody =
        accessServiceData.addLoginApiDynamicData(
            grantType,
            code,
            refreshToken,
            retailerId,
            betwareRetailerId,
            betwareTerminalId,
            clientAssertion,
            clientAssertionType,
            clientSecret,
            clientId,
            username,
            password,
            cardNumber,
            pin,
            assertion,
            claims);
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I create a PUT AllowRoleAccessAttributes payload with {string}")
  public void iCreateAPUTAllowRoleAccessAttributesPayloadWith(String operationalUnits) {
    String specification = "cc_csrftokenSpec";
    String[] operationalUnitList = operationalUnits.split(",");
    List<OperationalUnit> finalList = new ArrayList<>();

    for (int i = 0; i < operationalUnitList.length; i++) {
      OperationalUnit opUnit = accessServiceData.addOperationalUnits(operationalUnitList[i]);
      finalList.add(opUnit);
    }
    requestBody = finalList;
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }
}
