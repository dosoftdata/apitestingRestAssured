package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.mockData.WiremockData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.junit.jupiter.api.Assertions;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.Instant;

import static io.restassured.RestAssured.given;

public class WiremockStepDefinitions extends Utils {
  WiremockData wiremockData = new WiremockData();

  @Given(
      "I create a POST AddAStub payload with {string} {string} {string} {string} {string} {string} {string} {string}")
  public void iCreateAPOSTAddAStubPayloadWith(
      String scenarioName,
      String requiredScenarioState,
      String priority,
      String method,
      String url,
      String status,
      String body,
      String headers) {

    Utils utils = new Utils();
    randomId = utils.calculateRandomString(8, true, true);
    String[] headerList = headers.split(",");

    requestBody =
        wiremockData.addStubData(
            scenarioName, requiredScenarioState, priority, method, url, status, body, headerList);

    String specification = "wiremockSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I setup {string} guid and timestamp {string} wiremock variable")
  public void iSetupWiremockVariable(String guid, String timestamp) {
    if (guid.equals("datenow")) {
      String epochInMillisecond = String.valueOf(Instant.now().toEpochMilli());
      System.out.println("Epoch in Millisecond: " + epochInMillisecond);
      guid = epochInMillisecond;
      // will it work on pipeline ? check
    }
    if (timestamp.equals("datenow")) {
      timestamp = calculateDateNowInSecondsToString();
    }
    wiremockTimestamp = timestamp;
    wiremockGuid = guid;
  }

  @Given("I setup creationTime {string} and wagerId and serialNumbers wiremock variables")
  public void iSetupCreationTimeAndWagerIdAndSerialNumbersWiremockVariables(String creationTime) {
    Utils utils = new Utils();

    if (creationTime.equals("datenow")) {
      creationTime = wiremockGuid;
    }
    wiremockCreationTime = creationTime;

    // can be bigger but ok 9 digits
    wiremockWagerId = String.valueOf(utils.calculateRandomInteger(100000000, 999999999));
    wiremockSerialNumbers =
        "15173649910000000092" + utils.calculateRandomInteger(100000000, 999999999);
  }

  @Given("I setup deposit paymentId {string} and card fingerprint {string}")
  public void iSetupDepositPaymentIdAndCardFingerprint(String payId, String cardFingerprint1) {
    if (payId.equals("random")) {
      paymentId = String.valueOf(calculateRandomInteger(10000, 99999));
    } else {
      paymentId = payId;
    }
    cardFingerprint = cardFingerprint1;
    System.out.println("Payment id was setup: " + paymentId);
    System.out.println("cardFingerprint was setup: " + cardFingerprint);
  }

  @Given("I setup card fingerprint {string}")
  public void iSetupCardFingerprint(String cardFingerprint1) {
    cardFingerprint = cardFingerprint1;
  }

  @And("wagerId in response body is the same as stubbed one")
  public void wageridInResponseBodyIsTheSameAsStubbedOne() {
    Assertions.assertEquals(wiremockWagerId, getJsonPath(response, "[0].wager.wagerId"));
  }

  @And("serialNumbers in response body is the same as stubbed one")
  public void serialNumbersInResponseBodyIsTheSameAsStubbedOne() {
    Assertions.assertEquals(
        wiremockSerialNumbers, getJsonPath(response, "[0].wager.serialNumbers[0]"));
  }

  @And("wagerId in response body of Place Wager is the same as stubbed one")
  public void wageridInResponseBodyofPlaceWagerIsTheSameAsStubbedOne() {
    Assertions.assertEquals(wiremockWagerId, getJsonPath(response, "[0].wagerId"));
  }

  @And("serialNumbers in response body of Place Wager is the same as stubbed one")
  public void serialNumbersInResponseBodyofPlaceWagerIsTheSameAsStubbedOne() {
    Assertions.assertEquals(wiremockSerialNumbers, getJsonPath(response, "[0].serialNumbers[0]"));
  }
}
