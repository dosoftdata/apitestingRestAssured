package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.WalletServiceData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import static io.restassured.RestAssured.given;

public class WithdrawalsStepDefinitions extends Utils {

  WalletServiceData walletServiceData = new WalletServiceData();

  @When("I create a Post Withdrawal via {string} payload with {int} {string} {string} {string}")
  public void i_create_a_post_withdrawal_via_payload_with(
      String viaMethod, Integer amount, String action, String operation, String paymentMethodType) {
    requestBody =
        walletServiceData.withdrawalViaCard(
            amount, action, operation, paymentMethodType, viaMethod);
    String specification = "api_mainSpec_specWithGameId";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @When(
      "I create a Post Withdrawal without X-GameId via {string} payload with {int} {string} {string} {string}")
  public void i_create_a_post_withdrawal_without_xgameId_via_payload_with(
      String viaMethod, Integer amount, String action, String operation, String paymentMethodType) {
    requestBody =
        walletServiceData.withdrawalViaCard(
            amount, action, operation, paymentMethodType, viaMethod);
    String specification = "api_mainSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Then("I verify the card number and the card fingerprint")
  public void i_verify_the_card_number_and_the_card_fingerprint() {
    JsonPath js = new JsonPath(response.asString());
    String actualCardNumber = js.get("paymentMethod.card.cardNumber");
    String actualFingerprint = js.get("paymentMethod.id");

    Assertions.assertEquals(cardNumber, actualCardNumber);
    Assertions.assertEquals(cardFingerprint, actualFingerprint);
  }

  @Then("I copy the value of the withdrawal paymentId")
  public void i_copy_the_value_of_the_withdrawal_payment_id() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    withdrawal_paymentId = jsonPathEvaluator.get("paymentId");
    System.out.println("Withdrawal Payment Id is saved: " + withdrawal_paymentId);
  }

  @Given("I create a ApproveWithdrawal Put payload with amount {int}")
  public void i_create_a_approve_withdrawal_via_card_put_payload_with_amount(Integer amount) {
    requestBody = walletServiceData.approveWithdrawal(amount);
    String specification = "api_mainSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @When(
      "I change url resource of method {string} of service {string} with new withdrawal payment Id")
  public void i_change_url_resource_of_method_of_service_with_new_withdrawal_payment_id(
      String resourceName, String service) {
    int paymentLength = withdrawal_paymentId.length();
    String resourceValue = calculateEndpointUrl(service, resourceName);
    resourceValue = resourceValue.replace("{{withdrawal_paymentId}}", withdrawal_paymentId);
    resourceValue =
        resourceValue.replaceAll("[0-9]{" + paymentLength + "}", withdrawal_paymentId); // for retry
    setResourceByService(service, resourceName, resourceValue);
    System.out.println("Dynamic url has been overridden with: " + resourceValue);
  }

  @When("I create a Post VerifyPaymentViaToraWebhooks payload with amount {int}")
  public void i_create_a_post_verify_payment_via_tora_webhooks_payload_with_amount(Integer amount) {
    requestBody = walletServiceData.verifyPaymentViaToraWebhooks(amount);
    String specification = "api_mainSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create a VerifyWithdrawalViaIBAN Put Payload")
  public void i_create_a_verify_withdrawal_via_iban_put_payload() {
    requestBody = "";
    String specification = "api_mainSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create a ApproveWithdrawalCC Put payload with action {string}")
  public void iCreateAApproveWithdrawalCCPutPayloadWithAction(String action) {
    requestBody = walletServiceData.approveWithdrawalCC(action);
    String specification = "cc_csrftokenSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }
}
