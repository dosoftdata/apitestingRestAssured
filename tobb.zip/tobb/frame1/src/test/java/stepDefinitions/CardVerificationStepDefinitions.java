package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.PlayerServiceData;
import apiResources.endpoints.PlayerServiceResources;
import io.cucumber.java.en.*;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import static io.restassured.RestAssured.given;

public class CardVerificationStepDefinitions extends Utils {
  PlayerServiceData data = new PlayerServiceData();

  @Then(
      "I verify Card Pending Verification with status {string} {string} {string} {string} {string} {string}")
  public void iVerifyCardPendingVerificationWithStatus(
      String status,
      String cardExpirationYear,
      String cardName,
      String cardNumber,
      String cardHolderName,
      String cardExpirationMonth) {

    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    boolean success = false;

    for (var i = 0; i < count; i++) {
      String verificationType = js.get("verificationType[" + i + "]");

      if (verificationType.equals("CARD")) {
        String responseStatus = js.get("status[" + i + "]");
        String responseExpirationYear = js.get("metadata[" + i + "].cardExpDateYear");
        String responseCardName = js.get("metadata[" + i + "].cardName");
        String responseCardNumber = js.get("metadata[" + i + "].cardNumber");
        String responseCardHolderName = js.get("metadata[" + i + "].cardHolderName");
        String responseExpirationMonth = js.get("metadata[" + i + "].cardExpDateMonth");

        Assertions.assertEquals(status, responseStatus);
        Assertions.assertEquals(cardExpirationYear, responseExpirationYear);
        Assertions.assertEquals(cardName, responseCardName);
        Assertions.assertEquals(cardNumber, responseCardNumber);
        Assertions.assertEquals(cardHolderName, responseCardHolderName);
        Assertions.assertEquals(cardExpirationMonth, responseExpirationMonth);

        System.out.println("Verification Type CARD Found Successfully");
        success = true;

        cardVerificationId = js.get("id[" + i + "]");

        System.out.println("CardVerificationId is saved: " + cardVerificationId);
        break;
      }
    }
    if (!success) {
      Assertions.fail(
          "Verification Type CARD not found. Please check if you have made a deposit with a card");
      // if retry mechanism delete the assertion above and uncomment the code below

      // mechanism to upload the previous uploaded file and run the same call again. can be swapped
      // with delay 100 sec before the first upload.
      /* List<String> statusCodeList = new ArrayList<>();
      statusCodeList.add("200");
      PlayerServiceResources playerServiceAPI = PlayerServiceResources.valueOf("UploadDocumentsWeb");
      String url=playerServiceAPI.getResource();
      CommonStepDefinitions commonStepDefinitions = new CommonStepDefinitions();
      commonStepDefinitions.iCreateAUploadDocumentsWebPayloadWith(tempFileName,tempFileType);
      retryMechanism("POST", url, statusCodeList, 1, 40); //call uploadDocumentsWeb

      playerServiceAPI = PlayerServiceResources.valueOf("GetBoPlayerPendingVerifications");
       url=playerServiceAPI.getResource();
      commonStepDefinitions.iCreateAGetHeader("cc_csrftokenSpec");
      retryMechanism("GET",url,statusCodeList,1); //call
      iVerifyCardPendingVerificationWithStatus(status, cardExpirationYear, cardName, cardNumber, cardHolderName, cardExpirationMonth);*/
      // end of mechanism
    }
  }

  @Then("I verify Uploaded Documents with {string} {string} {string}")
  public void iVerifyUploadedDocumentsWithTypes(String types, String fileName, String fileType) {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");
    int successDocuments = 0;

    String[] documentTypes = types.split(",");

    for (int i = 0; i < documentTypes.length; i++) {
      for (int j = 0; j < count; j++) {

        String responseDocType = js.get("type[" + j + "]");
        int responseDocumentId = js.get("id[" + j + "]");
        if (documentTypes[i].equalsIgnoreCase(responseDocType)) {
          Assertions.assertEquals(fileName, js.get("fileName[" + j + "]"));
          Assertions.assertEquals(fileType, js.get("fileType[" + j + "]"));
          Assertions.assertEquals(playerId, js.get("playerId[" + j + "]"));

          if (responseDocType.equals("CARD_FRONT")) {
            cardFrontDocumentId = responseDocumentId;
          } else if (responseDocType.equals("CARD_BACK")) {
            cardBackDocumentId = responseDocumentId;
          } else if (responseDocType.equals("UTILITY_BILL")) {
            utilityDocumentId = responseDocumentId;
          } else if (responseDocType.equals("OTHER")) {
            otherDocumentId = responseDocumentId;
          }
          successDocuments++;
          System.out.println(
              "DocumentId saved: " + responseDocumentId + " for document Type: " + responseDocType);
        }
      }
    }
    if (successDocuments == 0 || successDocuments > count) {
      Assertions.fail(
          "SuccessDocuments found are not as many as expected.Found "
              + successDocuments
              + " documents");
    }
  }

  @Given("I create a VerifyDocuments payload with {string} {string} and subcategory {string}")
  public void iCreateAVerifyDocumentsPayloadWith(
      String verificationType, String statusDescription, String subType) {
    requestBody = data.addVerifyDocumentPayload(verificationType, statusDescription, subType);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @And("I copy the value of the fingerprint from the response")
  public void iCopyTheValueOfTheFingerprintFromTheResponse() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    cardFingerprint = jsonPathEvaluator.get("metadata.fingerprint");
    System.out.println("CardFingerPrint is saved: " + cardFingerprint);
  }

  @And("I copy the value of the cardNumber from the response")
  public void iCopyTheValueOfTheCardNumberFromTheResponse() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    cardNumber = jsonPathEvaluator.get("metadata.cardNumber");
    System.out.println("Card Number is saved: " + cardNumber);
  }

  @When("I create a VerificationConfirm payload with {string}")
  public void iCreateAVerificationConfirmPayloadWithAndSubcategory(String verificationType) {
    requestBody = data.addConfirmVerificationPayload(verificationType);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }
}
