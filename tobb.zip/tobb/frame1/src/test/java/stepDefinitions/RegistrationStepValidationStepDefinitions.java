package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.PlayerServiceData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import java.util.HashMap;
import java.util.Map;

import static apiResources.DataContext.registeredUsername;
import static io.restassured.RestAssured.given;

public class RegistrationStepValidationStepDefinitions extends Utils {

    PlayerServiceData data = new PlayerServiceData();

    @Given("I create a Registration Step 1 Validation payload with {string} {string} {string} {string} {string}")
    public void iCreateARegistrationStep1ValidationPayloadWith(String username,
                                                               String password,
                                                               String mobilePhone,
                                                               String email,
                                                               String promoCode) {
        if (username.equals("<USED_USERNAME>")) {
            username = registeredUsername;
        }

        if (mobilePhone.equals("<USED_MOBILE_PHONE>")) {
            mobilePhone = "69" + randomIntGenerated;
        }

        if (email.equals("<USED_EMAIL>")) {
            email = registeredUsername + "@mailsac.com";
        }

        requestBody =
                data.addRegistrationStep1ValidationPayload(
                        username,
                        password,
                        mobilePhone,
                        email,
                        promoCode);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("specWithGameIdNoToken"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @And("I verify Step Validation Error occurs on {string} with {string} and on {string} with {string}")
    public void iVerifyStepValidationErrorOccursOnWithAndOnWith(String fieldName1, String errorId1, String fieldName2, String errorId2) {
        JsonPath js = new JsonPath(response.asString());

        int count = js.getList("$").size();
        Map<String, String> actualErrors = new HashMap<>();

        for (int i = 0; i < count; i++) {
            String fieldName = js.getString("[" + i + "].fieldName");
            String errorId = js.getString("[" + i + "].errorId");
            actualErrors.put(fieldName, errorId);
        }

        Map<String, String> expectedErrors = new HashMap<>();
        if (fieldName1 != null && !fieldName1.isBlank()) {
            expectedErrors.put(fieldName1, errorId1);
        }
        if (fieldName2 != null && !fieldName2.isBlank()) {
            expectedErrors.put(fieldName2, errorId2);
        }

        if (count != expectedErrors.size()) {
            Assertions.fail("Expected " + expectedErrors.size() + " validation errors but got " + count +
                    ". Actual errors: " + actualErrors);
        }

        for (Map.Entry<String, String> entry : expectedErrors.entrySet()) {
            String field = entry.getKey();
            String expectedError = entry.getValue();

            if (!actualErrors.containsKey(field)) {
                Assertions.fail("Expected fieldName " + field + " not found. Actual fields: " + actualErrors.keySet());
            }

            String actualError = actualErrors.get(field);
            if (!expectedError.equals(actualError)) {
                Assertions.fail("For fieldName " + field + ", expected errorId: " + expectedError +
                        " but got: " + actualError);
            }
        }
    }
}
