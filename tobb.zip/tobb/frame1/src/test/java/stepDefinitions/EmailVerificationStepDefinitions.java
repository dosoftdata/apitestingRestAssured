package stepDefinitions;

import apiResources.Utils;
import apiResources.endpoints.CommunicationServiceResources;
import apiResources.pojo.requests.communicationService.PlayerPreferences;
import apiResources.testDataBuild.CommunicationServiceData;
import apiResources.testDataBuild.PlayerServiceData;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import java.util.ArrayList;
import java.util.List;

import static apiResources.endpoints.CommunicationServiceResources.mailIdForHash;
import static apiResources.endpoints.CommunicationServiceResources.setMailIdForHash;
import static io.restassured.RestAssured.given;

public class EmailVerificationStepDefinitions extends Utils {
    PlayerServiceData data = new PlayerServiceData();
    CommunicationServiceData communicationServiceData = new CommunicationServiceData();

    // This is to be used for the flow that OTP is after registration.
    @Given("I create a VerifyEmail payload with inner playerId and hash")
    public void iCreateAVerifyEmailPayloadWithInnerPlayerIdAndHash() {
        requestBody = data.addVerifyPlayerEmailPayload();
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("mainspecCCcsrfNoToken"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    // This is to be used for the flow that OTP is after registration for specific playerId.
    @Given("I create a VerifyEmail payload with playerId {string} and hash")
    public void iCreateAVerifyEmailPayloadWithInnerPlayerIdAndHash(String playerId) {
        requestBody = data.addVerifySpecificPlayerEmailPayload(playerId);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("mainspecCCcsrfNoToken"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    // This is to be used for the flow that OTP didn't exist before registration.
    @Given("I create a VerifyEmail payload with inner playerId and hash before otp")
    public void iCreateAVerifyEmailPayloadWithInnerPlayerIdAndHashBeforeOtp() {
        requestBody = data.addVerifyPlayerEmailPayload();
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("mainspecCCcsrfNoToken"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @Then("I copy the value of the mailId from the response")
    public void iCopyTheValueOfMailIdFromTheResponse() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        int dataSize = jsonPathEvaluator.getInt("data.size()");
        String mailIdForHash = jsonPathEvaluator.get("data[0].id");

        // new implementation
        for (int i = 0; i < dataSize; i++) {
            String templateName = jsonPathEvaluator.get("data[" + i + "].templateName");

            if (templateName.contains("registrationWelcomeEvent")) {
                mailIdForHash = jsonPathEvaluator.get("data[" + i + "].id");
                break;
            }
        }

        CommunicationServiceResources communicationServiceAPI =
                CommunicationServiceResources.valueOf("GetHashForMailVerification");
        setMailIdForHash(mailIdForHash);
        communicationServiceAPI.setResource("/cc/communication/rest/v1/emails/" + mailIdForHash);
        System.out.println("Mail Id saved: " + mailIdForHash);
        System.out.println(
                "Dynamic url has been overriden with: " + communicationServiceAPI.getResource());
    }

    @Then("I copy the value of the mailId from the response with template name {string}")
    public void iCopyTheValueOfMailIdFromTheResponseWithTemplateName(String templateToSearch) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        int dataSize = jsonPathEvaluator.getInt("data.size()");
        String mailIdForHash = jsonPathEvaluator.get("data[0].id");

        // new implementation
        for (int i = 0; i < dataSize; i++) {
            String templateName = jsonPathEvaluator.get("data[" + i + "].templateName");

            if (templateName.contains(templateToSearch)) {
                mailIdForHash = jsonPathEvaluator.get("data[" + i + "].id");
                break;
            }
        }

        CommunicationServiceResources communicationServiceAPI =
                CommunicationServiceResources.valueOf("GetHashForMailVerification");
        setMailIdForHash(mailIdForHash);
        communicationServiceAPI.setResource("/cc/communication/rest/v1/emails/" + mailIdForHash);
        System.out.println("Mail Id saved: " + mailIdForHash);
        System.out.println(
                "Dynamic url has been overriden with: " + communicationServiceAPI.getResource());
    }


    @Then("I verify MSISDN BO Pending Verifications with status {string}")
    public void iVerifyMsisdnBoPendingVerifications(String responseStatus) {
        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("data.size()");
        boolean success = false;

        for (var i = 0; i < count; i++) {
            String playerIdResponse = js.get("data[" + i + "].playerId");
            String verificationType = js.get("data[" + i + "].verificationType");
            String status = js.get("data[" + i + "].status");
            String value = js.get("data[" + i + "].value");

            if (playerIdResponse.equals(playerId) && verificationType.equals("MSISDN")) {
                Assertions.assertEquals(responseStatus, status);
                Assertions.assertEquals(mobilePrefix + randomIntGenerated, value);
                System.out.println("MSISDN Found Pending Successfully");
                success = true;
                break;
            }
        }
        if (!success) {
            Assertions.fail("MSISDN with playerId " + playerId + " not found");
        }
    }

    @Then("the id in response body is mailIdForHash")
    public void theIdInResponseBodyIsMailIdForHash() {
        Assertions.assertEquals(mailIdForHash, getJsonPath(response, "id"));
    }

    @Then("I copy the value of the hash from the response")
    public void iCopyTheValueOfTheHashFromTheResponse() {
        String body = getJsonPath(response, "body");
        hash = body.split("&hash=")[1].substring(0, 36);
        System.out.println("Hash saved: " + hash);
    }

    @When("I create a {string} PutPlayerPreferences payload with {string} {string} {string} {string} {string}")
    public void iCreateAPutPlayerPreferencesPayloadWith1(
            String urlPrefix,
            String subcategories,
            String selected,
            String messageTypes,
            String categories,
            String preferenceTypes) {

        String specification = "";

        if (urlPrefix.equalsIgnoreCase("API")) {
            specification = "api_mainSpec_mainHost";
        } else if (urlPrefix.equalsIgnoreCase("CC")) {
            specification = "cc_csrftokenSpec";
        } else if (urlPrefix.equalsIgnoreCase("WEB")) {
            specification = "mainSpec";
        } else {
            Assertions.fail("Please provide the correct url prefix (API,CC,WEB)");
        }
        calculatePlayerPreferences(
                subcategories, selected, messageTypes, categories, preferenceTypes, specification);
    }

    @When("I create a PutPlayerPreferences payload with {string} {string} {string} {string} {string} {string}")
    public void iCreateAPutPlayerPreferencesPayloadWith(
            String specification,
            String subcategories,
            String selected,
            String messageTypes,
            String categories,
            String preferenceTypes) {

        if (specification != null) {
            calculatePlayerPreferences(
                    subcategories, selected, messageTypes, categories, preferenceTypes, specification);
        }
    }
}
