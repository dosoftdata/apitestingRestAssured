package stepDefinitions;

import apiResources.DataContext;
import apiResources.Utils;
import apiResources.testDataBuild.AdminServiceData;
import io.cucumber.java.en.And;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import java.util.ArrayList;
import java.util.List;

import static io.restassured.RestAssured.given;

public class AdminStepDefinitions extends Utils {
    AdminServiceData adminServiceData = new AdminServiceData();

    @And(
            "I create a POST CreateNewAdmin payload {string} {string} {string} {string} {string} {string} {string} {int} {string}")
    public void iCreateAPOSTCreateNewAdminPayload(
            String email,
            String firstname,
            String language,
            String lastName,
            String loginName,
            String password,
            String passwordRepeated,
            int status,
            String groupIds) {
        if (groupIds.equals("superAdmin")) {
            groupIds = superAdminAccessId;
        }
        if (groupIds.equals("highWinnings")) {
            groupIds = highWinningsRoleId;
        }
        if (loginName.equals("azureHighWinnings")) {
            loginName = azureHighWinningsUsername;
            email = azureHighWinningsEmail;
        }
        List<Integer> groupIdsList = new ArrayList<>();

        String[] groupIdsArray = groupIds.split(",");
        for (String groupId : groupIdsArray) {
            groupIdsList.add(Integer.parseInt(groupId.trim()));
        }

        requestBody =
                adminServiceData.addCreateNewAdmin(
                        email,
                        firstname,
                        language,
                        lastName,
                        loginName,
                        password,
                        passwordRepeated,
                        status,
                        groupIdsList);
        String specification = "cc_csrftokenSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @And("I create a PUT UpdateAffiliatePassword payload with {string} {string}")
    public void iCreateAPUTEnableClerkUserPayloadWith(String password,
                                                      String passwordRepeated
    ) {

        requestBody = adminServiceData.addUpdateAffiliatePassword(
                password,
                passwordRepeated);

        String specification = "cc_csrftokenSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @And("I create a PUT UpdatePassword payload with {string}")
    public void iCreateAPUTEnableClerkUserPayloadWith(String password) {

        requestBody = adminServiceData.addUpdatePasswordAsHighWinningsUser(
                password);

        String specification = "cc_csrftokenSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @And("I create a PUT EnableClerkUser payload with {string} {string} {string} {string} {string} {int} {string}")
    public void iCreateAPUTEnableClerkUserPayloadWith(String email,
                                                      String firstName,
                                                      String language,
                                                      String lastName,
                                                      String loginName,
                                                      int status,
                                                      String groupIds) {

        if (groupIds.equals("CLERK_ACCESS_ROLE_ID")) {
            groupIds = clerkAccessRoleId;  // Assuming 'clerkAccessRoleId' is already retrieved and stored
        } else if (groupIds.equals("highWinnings")) {
            groupIds = highWinningsRoleId;
        }

        List<Integer> groupIdsList = new ArrayList<>();

        String[] groupIdsArray = groupIds.split(",");
        for (String groupId : groupIdsArray) {
            groupIdsList.add(Integer.parseInt(groupId.trim()));

            requestBody = adminServiceData.addEnableClerkUser(
                    email,
                    firstName,
                    language,
                    lastName,
                    loginName,
                    status,
                    groupIdsList);

            String specification = "cc_csrftokenSpec";
            res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
        }
    }

    @And("I create a PUT UpdateAdminInfo payload with {string} {string} {string} {string} {string} {int}")
    public void iCreateAPUTUpdateAdminInfoPayloadWith(String firstName,
                                                      String lastName,
                                                      String email,
                                                      String loginName,
                                                      String groupIds,
                                                      int status) {

        List<Integer> groupIdsList = new ArrayList<>();
        for (String id : groupIds.split(",")) {
            groupIdsList.add(Integer.parseInt(id.trim()));
        }

        requestBody = adminServiceData.addUpdateAdminInfo(
                firstName,
                lastName,
                email,
                loginName,
                groupIdsList,
                status);

        String specification = "cc_csrftokenSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @And("I copy the value of the {string} admin accessRoleId from the response")
    public void iCopyTheValueOfTheAdminAccessRoleIdFromTheResponse(String adminAccessRoleType) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        if (adminAccessRoleType.equals("clerk")) {
            clerkAccessRoleId = jsonPathEvaluator.getString("find { it.name == 'clerk' }.accessRoleId");
            System.out.println("The accessRoleId for clerk role is: " + clerkAccessRoleId);
        } else if (adminAccessRoleType.equals("Super Admin")) {
            superAdminAccessId = jsonPathEvaluator.getString("find { it.name == 'Super Admin' }.accessRoleId");
            System.out.println("The accessRoleId for Super Admin role is: " + superAdminAccessId);
        }
    }

    @And("I change url resource of method {string} of service {string} with new InvalidAdminRoleId")
    public void iChangeUrlResourceOfMethodOfServiceWithNewInvalidAdminRoleId(String resourceName, String service) {
        String invalidAdminRoleId = "100";
        String resourceValue = calculateEndpointUrl(service, resourceName);
        resourceValue = resourceValue.replaceAll("/\\d+/", "/" + invalidAdminRoleId + "/"); // for retrying with invalid roleId
        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    @And("I change url resource of method {string} of service {string} with new InvalidAdminId")
    public void iChangeUrlResourceOfMethodOfServiceWithNewInvalidAdminId(String resourceName, String service) {
        String invalidAdminId = "500";
        String resourceValue = calculateEndpointUrl(service, resourceName);
        resourceValue = resourceValue.replaceAll("(/\\d+$|/\\{\\{adminId}}$)", "/" + invalidAdminId); // for retrying with invalid adminId
        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    @And("I copy the value of the admin {string} from the response")
    public void iCopyTheValueOfTheAdminFromTheResponse(String keyValue) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        switch (keyValue) {
            case "id":
                adminId = jsonPathEvaluator.getString("id");
                System.out.println("Saved admin id: " + adminId);
                break;
            case "loginName":
                registeredAdminLoginName = jsonPathEvaluator.getString("loginName");
                System.out.println("Saved admin loginName: " + registeredAdminLoginName);
                break;
            case "email":
                registeredAdminEmail = jsonPathEvaluator.getString("email");
                System.out.println("Saved admin email: " + registeredAdminEmail);
                break;
            default:
                throw new IllegalArgumentException("Unknown admin field: " + keyValue);
        }
    }

    /**
     * Verifies that the specified field in the response body matches the expected value
     * based on whether the admin was newly created or existing.
     *
     * @param adminSource Indicates whether to verify against "created" or "existing" admin data.
     * @param keyValue    The field in the response body to verify (e.g., "loginName", "email").
     */
    @And("I verify the {string} admin {string} in the response body")
    public void i_verify_the_admin_in_the_response_body(String adminSource, String keyValue) {
        String actualValue = response.jsonPath().getString(keyValue);
        String expectedValue = null;

        switch (adminSource) {
            case "created":
                if (keyValue.equals("loginName")) {
                    expectedValue = generatedAdminLoginName;
                } else if (keyValue.equals("email")) {
                    expectedValue = generatedAdminEmail;
                } else {
                    throw new IllegalArgumentException("No expected value mapping for key: " + keyValue);
                }
                break;
            case "existing":
                if (keyValue.equals("loginName")) {
                    expectedValue = registeredAdminLoginName;
                } else if (keyValue.equals("email")) {
                    expectedValue = registeredAdminEmail;
                } else {
                    throw new IllegalArgumentException("No expected value mapping for key: " + keyValue);
                }
                break;
            default:
                throw new IllegalArgumentException("Unknown expected admin adminSource: " + adminSource);
        }

        Assertions.assertEquals(expectedValue, actualValue, "Field " + keyValue + " does not match");
    }

    @And("I create a PUT UpdateAdminPassword payload {string} {string}")
    public void iCreateAPUTUpdateAdminPasswordPayload(String newPassword, String newPasswordRepeated) {
        requestBody = adminServiceData.addUpdateAdminPassword(
                newPassword,
                newPasswordRepeated);

        String specification = "cc_csrftokenSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }
}