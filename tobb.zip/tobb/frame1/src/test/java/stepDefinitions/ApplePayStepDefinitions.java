package stepDefinitions;

import apiResources.Utils;
import apiResources.endpoints.CommunicationServiceResources;
import apiResources.testDataBuild.ApplePayServiceData;
import io.cucumber.java.en.*;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import static io.restassured.RestAssured.given;

public class ApplePayStepDefinitions extends Utils {
  ApplePayServiceData data = new ApplePayServiceData();

  @Given("I create an ApplePay payload with {string} {float} {string}")
  public void iCreateAnApplePayPayloadWith(String currency, float amount, String sessionUrl) {
    requestBody = data.addApplePayData(currency, amount, sessionUrl);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("specWithGameIdOrigin"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @Then("I verify the paymentId in response body is the calculated paymentId")
  public void theInResponseBodyIsTheCalculatedPaymentId() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    String responsePaymentId = jsonPathEvaluator.get("paymentId");
    Assertions.assertEquals(paymentId, responsePaymentId);
  }

  @Then("I verify the paymentId in response body is the calculated paymentId via card")
  public void theInResponseBodyIsTheCalculatedPaymentIdCard() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    String responsePaymentId = jsonPathEvaluator.get("paymentId");
    Assertions.assertEquals(paymentIdViaPaymentCard, responsePaymentId);
  }
}
