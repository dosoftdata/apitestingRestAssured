package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.PlayerServiceData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import static io.restassured.RestAssured.given;

public class MobilePhoneVerificationStepDefinitions extends Utils {
  PlayerServiceData data = new PlayerServiceData();

  @And("I create a {string} VerifyOTP payload")
  public void iCreateAVerifyOTPPayload(String methodType) {

    if (methodType.equalsIgnoreCase("POST")) {
      requestBody = data.addPostOtpPayload();

    } else {
      requestBody = data.addPutOtpPayload();
    }

    String specification = "otpSpecNoToken";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I copy the value of the uuid from the response")
  public void iCopyTheValueOfTheUuidFromTheResponse() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    uuid = jsonPathEvaluator.get("uuid");
    System.out.println("Uuid is saved: " + uuid);
  }

  @And("I verify the mobilePhone in response body has the calculated first and {string} last digit")
  public void iVerifyTheInResponseBodyHasTheCalculatedLastDigit(String oldOrNew) {
    JsonPath js = new JsonPath(response.asString());
    String mobilefield = js.get("mobilePhone");
    String mobile = "";

    if (oldOrNew.equals("old")) {
      mobile = mobilePrefix + oldRandomIntGenerated;
    } else if (oldOrNew.equals("new")) {
      mobile = mobilePrefix + randomIntGenerated;
    }
    Assertions.assertEquals(
        mobilePrefix.charAt(0), mobilefield.charAt(0), "Wrong first digit of mobile");
    Assertions.assertEquals(
        mobile.charAt(mobile.length() - 1),
        mobilefield.charAt(mobilefield.length() - 1),
        "Wrong last digit of mobile");
  }
}
