package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.WalletServiceData;
import io.cucumber.java.en.*;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import java.util.ArrayList;

import static io.restassured.RestAssured.given;

public class DepositsStepDefinitions extends Utils {
  WalletServiceData walletServiceData = new WalletServiceData();

  @Given("I create a VerifyDepositToTora payload")
  public void iCreateAVerifyDepositToToraPayloadWithCalculatedPaymentId() {
    requestBody = "";
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("api_mainSpec"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  // BALANCE V1 Response Verification: Checks balances for Wallet
  // Wallets: Lottery or Betting or Lottery Bonus or Betting Bonus
  @Then(
      "I verify the response for GetBalanceV1 for {float} {float} {float} {float} {float} for {string}")
  public void i_verify_the_response_for_get_balance_for_for(
      Float balance,
      Float buyingPower,
      Float nonWithdrawableBalance,
      Float reservedBalance,
      Float withdrawableBalance,
      String accountId) {
    JsonPath js = new JsonPath(response.asString());

    int count = js.getInt("js.size()");
    boolean success1 = false;
    boolean success2 = false;
    String myWallet = "";

    if (accountId.contains("Lottery")) {

      for (var i = 0; i < count; i++) {
        float actualBalance = js.get("balance[" + i + "]");
        float actualBuyingPower = js.get("buyingPower[" + i + "]");
        float actualNonWithdrawableBalance = js.get("nonWithdrawableBalance[" + i + "]");
        float actualReservedBalance = js.get("reservedBalance[" + i + "]");
        float actualWithdrawableBalance = js.get("withdrawableBalance[" + i + "]");
        String actualAccountType = js.get("accountType[" + i + "]");
        String actualAccountNumber = js.get("accountNumber[" + i + "]");
        String id = js.get("id[" + i + "]");

        if (actualAccountType.equalsIgnoreCase("AT_BONUS_PRIZE")
            && accountId.contains("Bonus")
            && actualAccountNumber.equals(bonusPrizeId)) {
          myWallet = "Lottery Bonus Wallet";
          Assertions.assertEquals(
              id, "AT_BONUS_PRIZE-" + bonusPrizeId, "Bonus Prize Id has not correct value");
          Assertions.assertEquals(
              balance, actualBalance, "Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              buyingPower,
              actualBuyingPower,
              "Buying Power in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              nonWithdrawableBalance,
              actualNonWithdrawableBalance,
              "Non Withrdrawable in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              reservedBalance,
              actualReservedBalance,
              "Reserved Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              withdrawableBalance,
              actualWithdrawableBalance,
              "Withdrawable Balance in " + myWallet + " has not correct value");
          success1 = true;
        }
        if (actualAccountType.equalsIgnoreCase("AT_MAIN")
            && actualAccountNumber.equalsIgnoreCase("1")
            && id.equalsIgnoreCase("AT_MAIN-1")
            && !accountId.contains("Bonus")) {
          myWallet = "Lottery Wallet";

          Assertions.assertEquals(
              balance, actualBalance, "Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              buyingPower,
              actualBuyingPower,
              "Buying Power in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              nonWithdrawableBalance,
              actualNonWithdrawableBalance,
              "Non Withrdrawable in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              reservedBalance,
              actualReservedBalance,
              "Reserved Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              withdrawableBalance,
              actualWithdrawableBalance,
              "Withdrawable Balance in " + myWallet + " has not correct value");

          success2 = true;
        }
      }
      if (!success1 && accountId.contains("Bonus")) {
        Assertions.fail("Bonus Lottery wallet not found");
        if (!success2 && !accountId.contains("Bonus")) {
          Assertions.fail("Lottery wallet not found");
        }
      }
    } else if (accountId.contains("Betting")) {

      for (var i = 0; i < count; i++) {
        float actualBalance = js.get("balance[" + i + "]");
        float actualBuyingPower = js.get("buyingPower[" + i + "]");
        float actualNonWithdrawableBalance = js.get("nonWithdrawableBalance[" + i + "]");
        float actualReservedBalance = js.get("reservedBalance[" + i + "]");
        float actualWithdrawableBalance = js.get("withdrawableBalance[" + i + "]");
        String actualAccountType = js.get("accountType[" + i + "]");
        String actualAccountNumber = js.get("accountNumber[" + i + "]");
        String id = js.get("id[" + i + "]");

        if (actualAccountType.equalsIgnoreCase("AT_BONUS_PRIZE")
            && accountId.contains("Bonus")
            && actualAccountNumber.equals(bonusPrizeId)) {
          myWallet = "Betting Bonus Wallet";
          Assertions.assertEquals(
              id, "AT_BONUS_PRIZE-" + bonusPrizeId, "Bonus Prize Id has not correct value");
          Assertions.assertEquals(
              balance, actualBalance, "Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              buyingPower,
              actualBuyingPower,
              "Buying Power in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              nonWithdrawableBalance,
              actualNonWithdrawableBalance,
              "Non Withrdrawable in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              reservedBalance,
              actualReservedBalance,
              "Reserved Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              withdrawableBalance,
              actualWithdrawableBalance,
              "Withdrawable Balance in " + myWallet + " has not correct value");
          success1 = true;
        }
        if (actualAccountType.equalsIgnoreCase("AT_MAIN")
            && actualAccountNumber.equalsIgnoreCase("2")
            && id.equalsIgnoreCase("AT_MAIN-2")
            && !accountId.contains("Bonus")) {
          myWallet = "Betting Wallet";
          Assertions.assertEquals(
              balance, actualBalance, "Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              buyingPower,
              actualBuyingPower,
              "Buying Power in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              nonWithdrawableBalance,
              actualNonWithdrawableBalance,
              "Non Withrdrawable in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              reservedBalance,
              actualReservedBalance,
              "Reserved Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              withdrawableBalance,
              actualWithdrawableBalance,
              "Withdrawable Balance in " + myWallet + " has not correct value");
          success2 = true;
        }
      }
      if (!success1 && accountId.contains("Bonus")) {
        Assertions.fail("Bonus Betting wallet not found");
      }
      if (!success2 && !accountId.contains("Bonus")) {
        Assertions.fail("Betting wallet not found");
      }
    }
    if (!accountId.contains("Bonus")
        && !accountId.contains("Lottery")
        && !accountId.contains("Betting")) {
      Assertions.fail(
          "Please enter a valid wallet to check - Betting,Lottery,Betting Bonus,Lottery Bonus");
    }
  }

  // BALANCE V2 Response Verification: Checks balances for PRIMARY Wallet (Lottery or Betting) and
  // the coresponding secondary wallets
  @Then(
      "I verify the response for GetBalanceV2 for primary {float} {float} {float} {float} {float} for {string} and secondary {float} {float} {float} {float} {float} for {string}")
  public void i_verify_the_response_for_get_balance_v2(
      Float balance,
      Float buyingPower,
      Float nonWithdrawableBalance,
      Float reservedBalance,
      Float withdrawableBalance,
      String accountId1,
      Float secondaryBalance,
      Float secondaryBuyingPower,
      Float secondarynonWithdrawableBalance,
      Float secondaryReservedBalance,
      Float secondarywWthdrawableBalance,
      String accountId2) {

    // call other step for primary wallet calculation
    i_verify_the_response_for_get_balance_v2_for_specific_wallet_only(
        "primary",
        balance,
        buyingPower,
        nonWithdrawableBalance,
        reservedBalance,
        withdrawableBalance,
        accountId1);

    i_verify_the_response_for_get_balance_v2_for_specific_wallet_only(
        "secondary",
        secondaryBalance,
        secondaryBuyingPower,
        secondarynonWithdrawableBalance,
        secondaryReservedBalance,
        secondarywWthdrawableBalance,
        accountId2);
  }

  // BALANCE V2 Response Verification: Checks balances for PRIMARY Wallet (Lottery or Betting or
  // Bonus Wallet or Bonus Lottery)
  // accountType : primary or secondary
  @Then(
      "I verify the response for GetBalanceV2 for {string} {float} {float} {float} {float} {float} for {string}")
  public void i_verify_the_response_for_get_balance_v2_for_specific_wallet_only(
      String accountType,
      Float balance,
      Float buyingPower,
      Float nonWithdrawableBalance,
      Float reservedBalance,
      Float withdrawableBalance,
      String accountId) {

    JsonPath js = new JsonPath(response.asString());

    boolean success = false;
    boolean success1 = false;
    int countTypes = js.getInt(accountType + ".size()");
    String myWallet = "";

    for (var i = 0; i < countTypes; i++) {
      float actualBalance = js.get(accountType + "[" + i + "].balance");
      float actualBuyingPower = js.get(accountType + "[" + i + "].buyingPower");
      float actualNonWithdrawableBalance =
          js.get(accountType + "[" + i + "].nonWithdrawableBalance");
      float actualReservedBalance = js.get(accountType + "[" + i + "].reservedBalance");
      float actualWithdrawableBalance = js.get(accountType + "[" + i + "].withdrawableBalance");
      String actualAccountType = js.get(accountType + "[" + i + "].accountType");
      String actualAccountNumber = js.get(accountType + "[" + i + "].accountNumber");
      String id = js.get(accountType + "[" + i + "].id");

      if (accountId.contains("Lottery")) {
        if (actualAccountType.equalsIgnoreCase("AT_BONUS_PRIZE")
            && accountId.contains("Bonus")
            && actualAccountNumber.equals(bonusPrizeId)) {
          myWallet = "Lottery Bonus Wallet";
          Assertions.assertEquals(
              id, "AT_BONUS_PRIZE-" + bonusPrizeId, "Bonus Prize Id has not correct value");
          Assertions.assertEquals(
              balance, actualBalance, "Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              buyingPower,
              actualBuyingPower,
              "Buying Power in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              nonWithdrawableBalance,
              actualNonWithdrawableBalance,
              "Non Withrdrawable in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              reservedBalance,
              actualReservedBalance,
              "Reserved Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              withdrawableBalance,
              actualWithdrawableBalance,
              "Withdrawable Balance in " + myWallet + " has not correct value");
          success = true;
        } else if (actualAccountType.equalsIgnoreCase("AT_MAIN")
            && actualAccountNumber.equalsIgnoreCase("1")
            && id.equalsIgnoreCase("AT_MAIN-1")
            && !accountId.contains("Bonus")) {
          myWallet = "Lottery Wallet - " + accountType;
          Assertions.assertEquals(
              balance, actualBalance, "Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              buyingPower,
              actualBuyingPower,
              "Buying Power in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              nonWithdrawableBalance,
              actualNonWithdrawableBalance,
              "Non Withrdrawable in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              reservedBalance,
              actualReservedBalance,
              "Reserved Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              withdrawableBalance,
              actualWithdrawableBalance,
              "Withdrawable Balance in " + myWallet + " has not correct value");
          success1 = true;
        }
      } else if (accountId.contains("Betting") && !accountId.contains("Bonus")) {
        myWallet = "Betting Wallet " + accountType;

        if (actualAccountType.equalsIgnoreCase("AT_MAIN")
            && actualAccountNumber.equalsIgnoreCase("2")
            && id.equalsIgnoreCase("AT_MAIN-2")) {
          myWallet = "Betting Wallet - PRIMARY ";
          Assertions.assertEquals(
              balance, actualBalance, "Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              buyingPower,
              actualBuyingPower,
              "Buying Power in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              nonWithdrawableBalance,
              actualNonWithdrawableBalance,
              "Non Withrdrawable in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              reservedBalance,
              actualReservedBalance,
              "Reserved Balance in " + myWallet + " has not correct value");
          Assertions.assertEquals(
              withdrawableBalance,
              actualWithdrawableBalance,
              "Withdrawable Balance in " + myWallet + " has not correct value");
          success1 = true;
        }
      } else if (actualAccountType.equalsIgnoreCase("AT_BONUS_PRIZE")
          && accountId.contains("Bonus")
          && actualAccountNumber.equals(bonusPrizeId)) {
        myWallet = "Betting Bonus Wallet";
        Assertions.assertEquals(
            id, "AT_BONUS_PRIZE-" + bonusPrizeId, "Bonus Prize Id has not correct value");
        Assertions.assertEquals(
            balance, actualBalance, "Balance in " + myWallet + " has not correct value");
        Assertions.assertEquals(
            buyingPower,
            actualBuyingPower,
            "Buying Power in " + myWallet + " has not correct value");
        Assertions.assertEquals(
            nonWithdrawableBalance,
            actualNonWithdrawableBalance,
            "Non Withrdrawable in " + myWallet + " has not correct value");
        Assertions.assertEquals(
            reservedBalance,
            actualReservedBalance,
            "Reserved Balance in " + myWallet + " has not correct value");
        Assertions.assertEquals(
            withdrawableBalance,
            actualWithdrawableBalance,
            "Withdrawable Balance in " + myWallet + " has not correct value");
        success = true;
      }
    }
    if (!success && accountId.contains("Bonus")) {
      Assertions.fail("Betting Bonus Wallet not found");
      if (!success1 && !accountId.contains("Bonus")) {
        Assertions.fail("Betting Wallet - PRIMARY not found");
      }
    }
    if (!accountId.contains("Bonus")
        && !accountId.contains("Lottery")
        && !accountId.contains("Betting")) {
      Assertions.fail(
          "Please enter a valid wallet to check - Betting,Lottery,Betting Bonus,Lottery Bonus");
    }
  }

  /*  Only when SetMasterCardDetails is not set
   */
  @Given("I setup a random deposit token Id")
  public void iSetupARandomDepositTokenId() {
    depositTokenId = "tok_" + calculateRandomInteger(100000, 999999999);
  }

  @When(
      "I change url resource of method {string} of service {string} with new via card deposit paymentId")
  public void i_change_url_resource_of_method_of_service_with_new_via_card_deposit_player_id(
      String resourceName, String service) {
    int length = paymentIdViaPaymentCard.length();
    String resourceValue = calculateEndpointUrl(service, resourceName);
    resourceValue = resourceValue.replace("{{deposit_paymentId}}", paymentIdViaPaymentCard);
    resourceValue =
        resourceValue.replaceAll("[0-9]{" + length + "}", paymentIdViaPaymentCard); // for retry
    setResourceByService(service, resourceName, resourceValue);
    System.out.println("Dynamic url has been overridden with: " + resourceValue);
  }

  @And(
      "I change url resource of method {string} of service {string} with new via paymentCode paymentId")
  public void iChangeUrlResourceOfMethodOfServiceWithNewViaPaymentCodePaymentId(
      String resourceName, String service) {
    int length = paymentId.length();
    String resourceValue = calculateEndpointUrl(service, resourceName);
    resourceValue = resourceValue.replace("{{deposit_paymentId}}", paymentId);
    resourceValue = resourceValue.replaceAll("[0-9]{" + length + "}", paymentId); // for retry
    setResourceByService(service, resourceName, resourceValue);
    System.out.println("Dynamic url has been overridden with: " + resourceValue);
  }

  // a way to change values of retrying dynamically.
  // Check if we can do it more general for all cases. (Status codes, delays, maxRetries,array)
  @Given("I override retry values field {string} and value {string} for CommitDepositToTora")
  public void iOverrideCommitDepositToToraRetryField(String fieldToCheck, String expectedValue) {
    ArrayList<String> tempResponseFieldValues = new ArrayList<>() {};
    tempResponseFieldValues.add(expectedValue);
    overrideRetryByGherkin = true;
    calculateRetryValues(3, "", 10, 202, true, fieldToCheck, tempResponseFieldValues);
  }

  @And("I copy the value of the signature of card")
  public void iCopyTheValueOfTheSignatureOfCard() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    signature = jsonPathEvaluator.get("signature");
    System.out.println("Signature is saved: " + signature);
  }

  @When(
      "I create a Post DepositViaPaypal payload with {string} {string} {string} {string} {string}")
  public void iCreateAPostDepositViaPaypalPayloadWith(
      String amount, String payerId, String email, String fullName, String country) {

    requestBody = walletServiceData.postDepositViaPaypal(amount, payerId, email, fullName, country);
    String specification = "specWithGameIdOrigin";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }
}
