package stepDefinitions;

import apiResources.testDataBuild.LimitServiceData;
import apiResources.testDataBuild.WalletServiceData;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import apiResources.Utils;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;
import apiResources.pojo.requests.limitService.AddLimits;
import apiResources.pojo.requests.limitService.AddTimeLimits;
import apiResources.pojo.requests.limitService.Limits;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static io.restassured.RestAssured.given;

public class LimitsStepDefinitions extends Utils {
  LimitServiceData limitServiceData = new LimitServiceData();
  WalletServiceData walletServiceData = new WalletServiceData();

  @Given(
      "I create a Post PlayerLimits payload for {string} limit period, duration or amount {int} and limitType {string}")
  public void
      i_create_a_post_player_limits_payload_for_limit_period_duration_or_amount_and_limit_type(
          String period, Integer num, String limitType) {
    if (limitType.equalsIgnoreCase("TIME")) {
      requestBody = limitServiceData.postTimeLimits(period, num, limitType);
    } else {
      requestBody = limitServiceData.postDailyDepositLimits(period, num, limitType);
    }
    limitAmountsToVerify.add(num.toString());
    String specification = "specWithGameId";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create PlayerLimits payload with {string}, {string}, {string}")
  public void i_create_player_limits_payload_with(
      String limitTypes, String limitPeriods, String limitAmounts) {
    String[] limits = limitTypes.split(",");
    String[] periods = limitPeriods.split(",");
    String[] amounts = limitAmounts.split(",");
    List<AddLimits> items = new ArrayList<>();
    List<AddTimeLimits> timeItems = new ArrayList<>();
    limitAmountsToVerify = new ArrayList<>();

    for (int i = 0; i < limits.length; i++) {
      if (limits[i].equalsIgnoreCase("TIME")) {
        AddTimeLimits limit = limitServiceData.addTimeLimits(limits[i], periods[i], amounts[i]);
        timeItems.add(limit);
        requestBody = timeItems;
      } else {
        AddLimits limit = limitServiceData.addLimits(limits[i], periods[i], amounts[i]);
        items.add(limit);
        requestBody = items;
        limitAmountsToVerify.add(amounts[i]);
      }
    }

    String specification = "specWithGameId";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create SetMandatoryLimits payload with {string} {string} {string} {string}")
  public void i_create_set_mandatory_limits_payload_with(
      String limitTypes, String limitPeriods, String limitAmounts, String gameIds) {
    String[] limits = limitTypes.split(",");
    String[] periods = limitPeriods.split(",");
    String[] amounts = limitAmounts.split(",");
    String[] ids = gameIds.split(",");
    List<Limits> items = new ArrayList<>();
    List<Limits> timeItems = new ArrayList<>();

    for (int i = 0; i < limits.length; i++) {
      if (limits[i].equalsIgnoreCase("TIME")) {
        Limits limit =
            limitServiceData.SetMandatoryTimeLimits(limits[i], periods[i], amounts[i], ids[i]);
        timeItems.add(limit);

      } else {
        Limits limit =
            limitServiceData.setMandatoryLimits(limits[i], periods[i], amounts[i], ids[i]);
        items.add(limit);
      }
    }
    requestBody = Stream.concat(timeItems.stream(), items.stream()).collect(Collectors.toList());

    String specification = "specWithGameId";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Then(
      "I verify limits for {string} limit period, duration or amount {int} and limitType {string} and gameId {string} for account {string} with pending limits {}")
  public void
      i_verify_limits_for_limit_period_duration_or_amount_and_limit_type_and_game_id_for_wallet(
          String period,
          int amount,
          String limitType,
          String game,
          String account,
          boolean pendingLimits) {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");
    boolean success = false;

    if (limitType.equalsIgnoreCase("DEPOSIT")) {
      for (var i = 0; i < count; i++) {
        String actualLimitType = js.get("limitType[" + i + "]");
        Boolean defaultLimit = js.get("defaultLimit[" + i + "]");
        String accountId = js.get("scope[" + i + "].accountId");
        String currency = js.get("quantity[" + i + "].currency");
        String quantityType = js.get("quantityType[" + i + "]");
        String actualPeriod = js.get("period[" + i + "]");
        Float actualAmount = js.get("quantity[" + i + "].amount");
        if (actualLimitType.equalsIgnoreCase(limitType) && actualPeriod.equalsIgnoreCase(period)) {
          Assertions.assertEquals(limitType, actualLimitType);
          Assertions.assertEquals(amount, actualAmount);
          Assertions.assertEquals(period, actualPeriod);
          Assertions.assertEquals(false, defaultLimit);
          Assertions.assertEquals(account, accountId);
          Assertions.assertEquals("EUR", currency);
          Assertions.assertEquals("MAX_AMOUNT", quantityType);
          if (pendingLimits) {
            Float actualPendingAmount = js.get("pending[" + i + "].quantity.amount");
            String actualPendingCurrency = js.get("pending[" + i + "].quantity.currency");
            String actualPendingTakesEffect = js.get("pending[" + i + "].takesEffect");
            boolean takesEffect = false;

            if (actualPendingTakesEffect.contains("23:59:59")) {
              takesEffect = true;
            }
            Assertions.assertEquals("EUR", actualPendingCurrency);
            Assertions.assertTrue(takesEffect, "Takes effect didn't found value 23:59:59");

            for (int j = 0; j < limitAmountsToVerify.size(); j++) {
              Float limitToVerifyFloat = Float.parseFloat(limitAmountsToVerify.get(j));

              if (limitToVerifyFloat.equals(actualPendingAmount)) {
                success = true;
                break;
              }
            }
            Assertions.assertTrue(success, "Amount not found as pending");
          } else {
            success = true;
          }
        }
      }
      if (!success) {
        Assertions.fail("Deposit limit not found");
      }
    } else if (limitType.equalsIgnoreCase("LOSS") || limitType.equalsIgnoreCase("BUY")) {
      for (var i = 0; i < count; i++) {
        String actualLimitType = js.get("limitType[" + i + "]");
        Boolean defaultLimit = js.get("defaultLimit[" + i + "]");
        String currency = js.get("quantity[" + i + "].currency");
        String quantityType = js.get("quantityType[" + i + "]");
        String actualPeriod = js.get("period[" + i + "]");
        Float actualAmount = js.get("quantity[" + i + "].amount");
        String gameId = js.get("scope[" + i + "].gameId");
        if (actualLimitType.equalsIgnoreCase(limitType) && actualPeriod.equalsIgnoreCase(period)) {
          Assertions.assertEquals(limitType, actualLimitType);
          Assertions.assertEquals(amount, actualAmount);
          Assertions.assertEquals(period, actualPeriod);
          Assertions.assertEquals(game, gameId);
          Assertions.assertEquals(false, defaultLimit);
          Assertions.assertEquals("EUR", currency);
          Assertions.assertEquals("MAX_AMOUNT", quantityType);
          if (pendingLimits) {
            Float actualPendingAmount = js.get("pending[" + i + "].quantity.amount");
            String actualPendingCurrency = js.get("pending[" + i + "].quantity.currency");
            String actualPendingTakesEffect = js.get("pending[" + i + "].takesEffect");
            boolean takesEffect = false;

            if (actualPendingTakesEffect.contains("23:59:59")) {
              takesEffect = true;
            }
            Assertions.assertEquals("EUR", actualPendingCurrency);
            Assertions.assertTrue(takesEffect, "Takes effect didn't found value 23:59:59");

            for (int j = 0; j < limitAmountsToVerify.size(); j++) {
              Float limitToVerifyFloat = Float.parseFloat(limitAmountsToVerify.get(j));

              if (limitToVerifyFloat.equals(actualPendingAmount)) {
                success = true;
                break;
              }
            }
            Assertions.assertTrue(success, "Amount not found as pending");
          } else {
            success = true;
          }
        }
      }
      if (!success) {
        Assertions.fail("Buy or Loss limit not found");
      }
    } else if (limitType.equalsIgnoreCase("TIME")) {
      for (var i = 0; i < count; i++) {
        String actualLimitType = js.get("limitType[" + i + "]");
        Boolean defaultLimit = js.get("defaultLimit[" + i + "]");
        Integer actualDuration = js.get("quantity[" + i + "].durationInSeconds");
        String quantityType = js.get("quantityType[" + i + "]");
        String actualPeriod = js.get("period[" + i + "]");
        Integer requestedByType = js.get("requestedBy[" + i + "].type");
        String requestedByPlayerId = js.get("requestedBy[" + i + "].id");
        if (actualLimitType.equalsIgnoreCase(limitType) && actualPeriod.equalsIgnoreCase(period)) {
          Assertions.assertEquals(limitType, actualLimitType);
          Assertions.assertEquals(amount, actualDuration);
          Assertions.assertEquals(period, actualPeriod);
          Assertions.assertEquals(false, defaultLimit);
          Assertions.assertEquals("MAX_DURATION", quantityType);
          Assertions.assertEquals(1, requestedByType);
          Assertions.assertEquals(playerId, requestedByPlayerId);

          success = true;
        }
      }
      if (!success) {
        Assertions.fail("Time limit not found");
      }
    }
  }

  @Given("I create a CreateTransaction payload with {string} {string} {string} {string}")
  public void iCreateACreateTransactionPayloadWith(
      String issued, String type, String amount, String productId) {
    requestBody = walletServiceData.createTransaction(issued, type, amount, productId);
    String specification = "api_mainSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }
}
