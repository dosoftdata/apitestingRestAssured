package stepDefinitions;

import static io.restassured.RestAssured.given;

import apiResources.Utils;
import apiResources.testDataBuild.AdminServiceData;
import apiResources.testDataBuild.rabbitMQData.RabbitMQData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;

import java.util.ArrayList;
import java.util.List;

public class RabbitMQStepDefinitions extends Utils {
  RabbitMQData rabbitMQData = new RabbitMQData();

  @Given("I create a PUT CreateQueue payload with {} {} {} {string} {string}")
  public void iCreateAPUTCreateQueuePayloadWith(
      boolean autoDelete, boolean durable, Object arguments, String vhost, String name) {

    requestBody = rabbitMQData.addCreateQueueData(autoDelete, durable, arguments, vhost, name);
    String specification = "rabbitSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given(
      "I create a POST CreateBinding payload with {string} {string} {string} {string} {string} {}")
  public void iCreateAPOSTCreateBindingPayloadWith(
      String source,
      String vhost,
      String routingKey,
      String destination,
      String destinationType,
      Object arguments) {

    requestBody =
        rabbitMQData.addCreateBindingData(
            source, vhost, routingKey, destination, destinationType, arguments);

    String specification = "rabbitSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create a POST PublishToExchange payload with {string} {string} {string} {string}")
  public void iCreateAPOSTPublishToExchangePayloadWith(
      String contentType, String routing_key, String payload, String payloadEncoding) {
    requestBody =
        rabbitMQData.addPublishToExchangeData(contentType, routing_key, payload, payloadEncoding);

    String specification = "rabbitSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given("I create a POST GetQueueMessages payload with {int} {string} {string} {int}")
  public void iCreateAPOSTGetQueueMessagesPayloadWith(
      int count, String ackMode, String encoding, int truncate) {

    requestBody = rabbitMQData.addGetQueueMessagesData(count, ackMode, encoding, truncate);
    String specification = "rabbitSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }
}
