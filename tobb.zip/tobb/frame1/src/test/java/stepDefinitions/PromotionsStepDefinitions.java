package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.PlayerServiceData;
import apiResources.testDataBuild.PromotionServiceData;
import io.cucumber.java.en.Given;

import static io.restassured.RestAssured.given;

public class PromotionsStepDefinitions extends Utils {

  PromotionServiceData promotionServiceData = new PromotionServiceData();

  @Given("I create a Post CheckBetEligibility payload with {} {} {} {} {}")
  public void iCreateAPostCheckBetEligibilityPayloadWithGameId(
      int gameId, int boards, int consecutiveDraws, boolean simpleBet, int cost) {
    requestBody =
        promotionServiceData.addCheckBetEligibilityData(
            gameId, boards, consecutiveDraws, simpleBet, cost);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("mainSpec"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }
}
