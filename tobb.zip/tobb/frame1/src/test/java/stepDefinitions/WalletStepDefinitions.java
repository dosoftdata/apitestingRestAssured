package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.PlayerServiceData;
import apiResources.testDataBuild.WalletServiceData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import static io.restassured.RestAssured.given;

public class WalletStepDefinitions extends Utils {

  WalletServiceData walletServiceData = new WalletServiceData();
  PlayerServiceData playerServiceData = new PlayerServiceData();

  @Given("I create a CloseAccountV4 Put payload with {string} {string} {string}")
  public void iCreateACloseAccountvPutPayloadWith(
      String status, String statusDescription, String statusReason) {

    requestBody = walletServiceData.addCloseAccount(status, statusDescription, statusReason);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("api_mainSpec"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @Given("I create a OpenAccount Put payload with {string} {string} {string}")
  public void iCreateOpenAccountPutPayload(
      String status, String statusDescription, String statusReason) {
    requestBody =
        walletServiceData.addCloseAccount(
            status, statusDescription, statusReason); // same request for close/opening

    res =
        given()
            .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @Given(
      "I create a CreateBettingTransaction payload with {string} {int} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {booleanValue} {string}")
  public void iCreateACreateTransactionPayloadWith(
      String issued,
      int prizeLevel,
      String type,
      String amount,
      String productId,
      String currency,
      String description,
      String fromDescription,
      String toDescription,
      String state,
      String batchId,
      String subBatchId,
      String transactionId,
      String callerServiceProviderId,
      boolean autocapture,
      String metadataValue) {
    requestBody =
        walletServiceData.createBettingTransaction(
            issued,
            prizeLevel,
            type,
            amount,
            productId,
            currency,
            description,
            fromDescription,
            toDescription,
            state,
            batchId,
            subBatchId,
            transactionId,
            callerServiceProviderId,
            autocapture,
            metadataValue);
    String specification = "api_mainSpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  // this request is not 100% accurate used in negative scenario if you find one successful improve
  // request.
  @Given("I create a Post CancelTransaction payload with {string} {string}")
  public void iCreateAPostCancelTransactionPayloadWith(String id, String referenceId) {
    requestBody = walletServiceData.cancelTransaction(id, referenceId);
    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @When(
      "I create a PUT CommitPaymentMethod payload with {string} {string} {string} {string} {string} {string} {string} {int} {string} {int}")
  public void iCreateAPUTCommitToSkrillPayloadWith(
      String serviceProviderId,
      String paymentMethodType,
      String directionIn,
      String paymentMethodId,
      String serviceProviderTargetId,
      String email,
      String createdById,
      int createdByType,
      String updatedById,
      int updatedByType) {
    requestBody =
        walletServiceData.commitPaymentMethodToWallet(
            serviceProviderId,
            paymentMethodType,
            directionIn,
            paymentMethodId,
            serviceProviderTargetId,
            email,
            createdById,
            createdByType,
            updatedById,
            updatedByType);
    String specification = "api_mainSpec_mainHost";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given(
      "I create a POST AccessOperations payload with {string} {string} {string} {string} {string} {string} {string} {string} {string}")
  public void iCreateAPOSTAccessOperationsPayloadWith(
      String buyListId,
      String buyListAccessType,
      String payoutListId,
      String payoutListAccessType,
      String depositListId,
      String depositListAccessType,
      String withdrawListId,
      String withdrawListAccessType,
      String reason) {

    requestBody =
        walletServiceData.editAccessOperations(
            buyListId,
            buyListAccessType,
            payoutListId,
            payoutListAccessType,
            depositListId,
            depositListAccessType,
            withdrawListId,
            withdrawListAccessType,
            reason);
    String specification = "cc_csrftokenSpec";

    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given(
      "I create a POST RejectDepositViaTora payload with {string} {string} {int} {string} {string} {string} {string}")
  public void iCreateAPOSTRejectDepositViaToraPayloadWith(
      String paymentId,
      String preconditionStatus,
      int amount,
      String iban,
      String name,
      String bankName,
      String accountNumber) {
    requestBody =
        walletServiceData.rejectDepositViaTora(
            paymentId, preconditionStatus, amount, iban, name, bankName, accountNumber);
    String specification = "api_mainSpec_mainHost";

    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @Given(
      "I create a PUT PrecommitPaymentToWallet payload with {int} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
  public void iCreateAPUTPrecommitPaymentToWalletPayloadWith(
      int serviceCostAmount,
      String issuerId,
      String type,
      String cardName,
      String cardNumber,
      String expiryMonth,
      String expiryYear,
      String accountNumber,
      String paymentCode,
      String fingerprint) {

    requestBody =
        walletServiceData.precommitPaymentToWallet(
            serviceCostAmount,
            issuerId,
            type,
            cardName,
            cardNumber,
            expiryMonth,
            expiryYear,
            accountNumber,
            paymentCode,
            fingerprint);
    String specification = "api_mainSpec_mainHost";

    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I verify paypal values {string} {string} {string} {string} in get payment codes")
  public void iVerifyPaypalSomePaypalValuesInGetPaymentCodes(
      String player,
      String requestPaymentMethodId,
      String requestPaymentMethodStatus,
      String requestEmail) {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");
    boolean success = false;

    for (var i = 0; i < count; i++) {
      String paymentMethodId = js.get("paymentMethodId[" + i + "]");
      if (paymentMethodId.equals(requestPaymentMethodId)) {
        String customerId = js.get("customerId[" + i + "]");
        String paymentMethodType = js.get("paymentMethodType[" + i + "]");
        String serviceProviderTargetId = js.get("serviceProviderTargetId[" + i + "]");
        String serviceProviderId = js.get("serviceProviderId[" + i + "]");
        String paymentMethodTypeName = js.get("paymentMethodTypeName[" + i + "]");
        String paymentMethodStatus = js.get("paymentMethodStatus[" + i + "]");
        String email = js.get("email[" + i + "]");

        if ((player.isBlank() || player.isEmpty() || player.equals("newPlayerWeb"))
            && (playerId != null)) {
          player = playerId;
        }
        Assertions.assertEquals(customerId, player);
        Assertions.assertEquals(paymentMethodStatus, requestPaymentMethodStatus);
        Assertions.assertEquals(email, requestEmail);
        Assertions.assertEquals(paymentMethodId, requestPaymentMethodId);
        Assertions.assertEquals(paymentMethodType, 8);
        Assertions.assertEquals(serviceProviderId, "TORA");
        Assertions.assertEquals(serviceProviderTargetId, "PAYPAL");
        Assertions.assertEquals(paymentMethodTypeName, "PAYPAL");
        success = true;
      }
    }
    Assertions.assertTrue(success, "Success is not true. Paypal method not found\n");
  }
}
