package stepDefinitions;

import apiResources.Utils;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.junit.jupiter.api.Assumptions;
import static apiResources.Utils.*;

public class Hooks {

  public void beforeScenario() {
    CommonStepDefinitions stepDefinitions = new CommonStepDefinitions();
    stepDefinitions.setUpConfig();
    stepDefinitions.iSetupCookies();
    stepDefinitions.setGameId("JOKER"); // default xgameId header can be changed later.
  }

  @Before("@getTime")
  public void beforePlaceWager() {
    CommonStepDefinitions commonStepDefinitions = new CommonStepDefinitions();
    commonStepDefinitions.iCreateAGetHeader("mainSpec");
    commonStepDefinitions.i_make_a_call_to("GET", "GetTime", "WagerService");
    commonStepDefinitions.the_api_call_is_successful_with_status_code(200);
  }

  @Before("@skipIfAssignedBonusDoesNotExist")
  public void skipIfAssignedBonusDoesNotExist() {
    Assumptions.assumeTrue(bonusPrizeExists);
  }

  @Before("@skipIfAssignedBonusExists")
  public void skipIfAssignedBonusExists() {
    Assumptions.assumeFalse(bonusPrizeExists);
  }

  @Before("@skipIfBonusActiveIdExists")
  public void skipAddBonusIfBonusIdExists() {
    Assumptions.assumeFalse(bonusActiveIdExists);
  }

  @Before("@skipIfNotAzure")
  public void skipIfNotAzure() {
    boolean assumption = environment.contains("Azure");
    Assumptions.assumeTrue(assumption);
  }

  @Before("@UnauthorizedCalls")
  public void UnauthorizedCallsBefore() {
    maxRetries = 0;
    System.out.println("Retries changed to: " + maxRetries);
  }

  @After("@UnauthorizedCalls")
  public void UnauthorizedCallsAfter() {
    maxRetries = initalMaxRetries;
    System.out.println("Retries changed to: " + maxRetries);
  }

  @Before("@NoRetry")
  public void NoRetryBefore() {
    maxRetries = 0;
    System.out.println("Retries changed to: " + maxRetries);
  }

  @After("@NoRetry")
  public void NoRetryAfter() {
    maxRetries = initalMaxRetries;
    System.out.println("Retries changed to: " + maxRetries);
  }

  @Before("@skipIfAzure")
  public void skipIfAzure() {
    boolean assumption = !environment.contains("Azure");
    Assumptions.assumeTrue(assumption);
  }

  @Before("@skipIfIntegration")
  public void skipIfIntegration() {
    boolean assumption = !environment.contains("Integration");
    Assumptions.assumeTrue(assumption);
  }

  @Before("@skipIfUAT")
  public void skipIfUAT() {
    boolean assumption = !environment.contains("UAT");
    Assumptions.assumeTrue(assumption);
  }

  @Before("@skipIfPreprod")
  public void skipIfPreprod() {
    boolean assumption = !environment.contains("Preprod");
    Assumptions.assumeTrue(assumption);
  }

  @Before("@skipIfNotIntegration")
  public void skipIfNotIntegration() {
    boolean assumption = environment.contains("Integration");
    Assumptions.assumeTrue(assumption);
  }

  @Before("@skipIfNotUAT")
  public void skipIfNotUAT() {
    boolean assumption = environment.contains("UAT");
    Assumptions.assumeTrue(assumption);
  }

  @Before("@skipIfNotPreprod")
  public void skipIfNotPreprod() {
    boolean assumption = environment.contains("Preprod");
    Assumptions.assumeTrue(assumption);
  }

  @Before("@ConfiguredUser")
  public void configuredUserBefore() {
    tempPlayerId = playerId;
    playerId = configPlayerId;
    System.out.println("PlayerId changed to: " + configPlayerId);
  }

  @After("@ConfiguredUser")
  public void configuredUserAfter() {
    playerId = tempPlayerId;
    System.out.println("PlayerId changed back to: " + tempPlayerId);
  }

  @After("@Concat")
  public void Concat() {
    Utils utils = new Utils();
    utils.setResourceByService(service, retryResource, oldUrl);
    System.out.println("Dynamic url has returned to previous state: " + oldUrl);
  }

  @Before("@skipIfUserExists")
  public void skipIfUserExists() {
    boolean assumption = !userExists;
    Assumptions.assumeTrue(assumption);
  }

}
