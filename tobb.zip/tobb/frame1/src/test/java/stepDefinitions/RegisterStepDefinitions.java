package stepDefinitions;

import apiResources.testDataBuild.PlayerServiceData;
import io.cucumber.java.en.Given;
import apiResources.Utils;
import io.cucumber.java.en.Then;

import static io.restassured.RestAssured.given;
import java.lang.*;

public class RegisterStepDefinitions extends Utils {
  PlayerServiceData data = new PlayerServiceData();

  @Given("I create a Register payload with {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
  public void iCreateAPlaceWagerPayloadWith(
      String username,
      String password,
      String email,
      String identityType,
      String firstName,
      String middleName,
      String lastName,
      String gender,
      String dateOfBirth,
      String country,
      String address,
      String profession,
      String city,
      String zipCode,
      String bonusCode,
      String secretQuestion,
      String secretAnswer,
      String ibanNumber,
      String permanentResidenceCountry) {
    requestBody =
        data.addRegisterPayload(
            username,
            password,
            email,
            identityType,
            firstName,
            middleName,
            lastName,
            gender,
            dateOfBirth,
            country,
            address,
            profession,
            city,
            zipCode,
            bonusCode,
            secretQuestion,
            secretAnswer,
            ibanNumber,
            permanentResidenceCountry);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("specWithGameIdNoToken"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }
}
