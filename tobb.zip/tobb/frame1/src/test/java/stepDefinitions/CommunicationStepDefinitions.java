package stepDefinitions;

import apiResources.Utils;
import apiResources.pojo.requests.communicationService.BulkMessage;
import apiResources.testDataBuild.CommunicationServiceData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import java.util.ArrayList;
import java.util.List;

import static io.restassured.RestAssured.given;

public class CommunicationStepDefinitions extends Utils {
  CommunicationServiceData communicationServiceData = new CommunicationServiceData();

  @And("I verify notified channels have selected {string}")
  public void iVerifyNotifiedChannelsHaveSelected(String selected) {
    Boolean shouldBeSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    for (int i = 0; i < count; i++) {
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.get("[" + i + "].selected");

      if (messageType.equals("NOTIFY")) {
        Assertions.assertEquals(shouldBeSelected, isSelected);
      }
    }
  }

  // No opt-in
  @And("I verify no notify channels have selected {string}")
  public void iVerifyNotNotifiedChannelsHaveSelected(String selected) {
    Boolean shouldBeSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    for (int i = 0; i < count; i++) {
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.get("[" + i + "].selected");

      if (!messageType.equals("NOTIFY")) {
        Assertions.assertEquals(shouldBeSelected, isSelected);
      }
    }
  }

  // Full opt-in
  @And("I verify all channels are activated and have selected {string}")
  public void iVerifyAllChannelsAreActivated(String selected) {
    Boolean shouldBeSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    for (int i = 0; i < count; i++) {
      Boolean isSelected = js.get("[" + i + "].selected");
      Assertions.assertEquals(shouldBeSelected, isSelected);
    }
  }

  @And("I verify property {string} has value {string} with selected {string}")
  public void iVerifyPropertyHasSelected(
      String propertyType, String expectedPropertyValue, String selected) {
    Boolean shouldBeSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String actualPropertyValue = js.getString("[" + i + "]." + propertyType);
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if (actualPropertyValue.equals(expectedPropertyValue)) {
        Assertions.assertEquals(
            shouldBeSelected,
            isSelected,
            "Selected value does not match for " + propertyType + ": " + expectedPropertyValue);
      }
    }
  }

  // All channels ep
  @And("I verify channels activations for EP have selected {string}")
  public void iVerifyChannelActivations(String selected) {
    Boolean shouldBeSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");
    for (int i = 0; i < count; i++) {
      String category = js.getString("[" + i + "].category");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if (category.equals("CAMPAIGN_OFFERS_EP")) {
        Assertions.assertEquals(
            shouldBeSelected,
            isSelected,
            "Expected 'selected' to be true for category: " + category);
      } else if (category.equals("CAMPAIGN_OFFERS_NEP")) {
        Assertions.assertNotEquals(
            shouldBeSelected,
            isSelected,
            "Expected 'selected' to be false for category:" + category);
      } else {
        Assertions.fail("Category not valid: " + category);
      }
    }
  }

  // Only sms for ep
  @And("I verify channels activation for EP and message type SMS have selected {string}")
  public void iVerifyChannelActivationsSMS(String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if (category.equals("CAMPAIGN_OFFERS_EP")
          && (messageType.equals("SMS") || messageType.equals("NOTIFY"))) {
        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for category: " + category);
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category: " + category);
      }
    }
  }

  // All nep channels
  @And(
      "I verify channels activation for category {string} and message type not equals to notify have selected {string}")
  public void iVerifyChannelActivationsNEP(String categoryValue, String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if (category.equals(categoryValue) && !messageType.equals("NOTIFY")) {
        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for category:" + category);
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category: " + category);
      }
    }
  }

  // Sms for ep and campaign opap
  @And(
      "I verify channels activations for EP and campaign OPAP and message type SMS and Notify have selected {string}")
  public void iVerifyChannelActivationsSMSForEP(String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);

    JsonPath js = new JsonPath(response.asString());

    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if (((category.equals("CAMPAIGN_OFFERS_EP") || category.equals("CAMPAIGN_OPAP"))
              && messageType.equals("SMS"))
          || (category.equals("CAMPAIGN_OFFERS_EP") && messageType.equals("NOTIFY"))) {

        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for category:" + category);
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category: " + category);
      }
    }
  }

  // Email for ep and campaign opap
  @And(
      "I verify channels activations for EP and campaign OPAP and message type {string} have selected {string}")
  public void iVerifyChannelActivationsSMSForEPandOPAP(String messagetype, String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);

    JsonPath js = new JsonPath(response.asString());

    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if (((category.equals("CAMPAIGN_OFFERS_EP") || category.equals("CAMPAIGN_OPAP"))
          && messageType.equals(messagetype))) {

        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for category: " + category);
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category: " + category);
      }
    }
  }

  // sms for campaign opap
  @And("I verify channels activation for campaign OPAP and message type SMS have selected {string}")
  public void iVerifyChannelActivationsSMSForOPAP(String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);

    JsonPath js = new JsonPath(response.asString());

    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if (((category.equals("CAMPAIGN_OPAP")) && messageType.equals("SMS"))
          || (category.equals("CAMPAIGN_OFFERS_EP") && messageType.equals("NOTIFY"))) {

        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for category:" + category);
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category:" + category);
      }
    }
  }

  // Call, Viber for NEP
  @And("I verify channels activation for NEP and message type VIBER, CALL have selected {string}")
  public void iVerifyChannelActivationsCallForNEP(String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if ((category.equals("CAMPAIGN_OFFERS_NEP")) || (category.equals("CAMPAIGN_OPAP"))) {
        if (messageType.equals("VIBER") || messageType.equals("CALL")) {
          Assertions.assertEquals(
              expectedSelected,
              isSelected,
              "Expected 'selected' to be true for category: " + category);
        } else {
          Assertions.assertNotEquals(
              expectedSelected,
              isSelected,
              "Expected 'selected' to be false for category:" + category);
        }
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category: " + category);
      }
    }
  }

  // SMS, Call, Viber EP and campaign OPAP
  @And(
      "I verify channels activation for EP and campaign OPAP and message type SMS, CALL, VIBER have selected {string}")
  public void iVerifyChannelActivationCallSMSForEP(String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if ((category.equals("CAMPAIGN_OPAP") || category.equals("CAMPAIGN_OFFERS_EP"))) {
        if (messageType.equals("VIBER")
            || messageType.equals("CALL")
            || messageType.equals("SMS")) {
          Assertions.assertEquals(
              expectedSelected,
              isSelected,
              "Expected 'selected' to be true for category" + category);
        } else {
          Assertions.assertNotEquals(
              expectedSelected,
              isSelected,
              "Expected 'selected' to be false for category:" + category);
        }
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category" + category);
      }
    }
  }

  // SMS,Call, Viber for NEP
  @And(
      "I verify channels activation for NEP and message type SMS, VIBER, CALL have selected {string}")
  public void iVerifyChannelActivationViberForNEP(String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if ((category.equals("CAMPAIGN_OFFERS_NEP"))) {
        if (messageType.equals("VIBER")
            || messageType.equals("CALL")
            || messageType.equals("SMS")) {
          Assertions.assertEquals(
              expectedSelected,
              isSelected,
              "Expected 'selected' to be true for category:" + category);
        } else {
          Assertions.assertNotEquals(
              expectedSelected,
              isSelected,
              "Expected 'selected' to be false for category:" + category);
        }
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category: " + category);
      }
    }
  }

  // SMS, Call for EP, NEP and campaign OPAP
  @And(
      "I verify channels activation for EP, NEP, campaign OPAP and message type SMS, CALL have selected {string}")
  public void iVerifyComplexChannelActivationsEpNep(String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if (messageType.equals("CALL") || messageType.equals("SMS")) {
        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for category:" + category);
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category:" + category);
      }
    }
  }

  // SMS, Call for EP, NEP and campaign OPAP and Viber for NEP
  @And(
      "I verify channels activation for EP, NEP, campaign OPAP and message type SMS, CALL and VIBER for NEP have selected {string}")
  public void iVerifyComplexChannelActivationsEpNepOpap(String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if (messageType.equals("CALL") || messageType.equals("SMS")) {
        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for message type: CALL OR SMS");
      } else if (messageType.equals("VIBER") && category.equals("CAMPAIGN_OFFERS_NEP")) {
        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for category: " + category);
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category" + category);
      }
    }
  }

  // Only sms/viber for ep
  @And("I verify channels activation for EP and message type SMS and VIBER have selected {string}")
  public void iVerifyChannelActivationVIBER(String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if (category.equals("CAMPAIGN_OFFERS_EP")
          && (messageType.equals("SMS") || messageType.equals("VIBER"))) {
        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for category: " + category);
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category: " + category);
      }
    }
  }

  // Only call/email for ep
  @And(
      "I verify channels activation for category {string} and message type CALL and EMAIL have selected {string}")
  public void iVerifyChannelActivationCall(String categoryValue, String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if (category.equals(categoryValue)
          && (messageType.equals("CALL") || messageType.equals("EMAIL"))) {
        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for category: " + category);
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category: " + category);
      }
    }
  }

  // EP/OPAP and SMS - NEP and EMAIL
  @And(
      "I verify channels activation for EP and OPAP and message type SMS and for NEP and EMAIL have selected {string}")
  public void iVerifyChannelActivationSmsEmail(String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if ((((category.equals("CAMPAIGN_OFFERS_EP")) || (category.equals("CAMPAIGN_OPAP")))
              && (messageType.equals("SMS")))
          || (messageType.equals("EMAIL") && category.equals("CAMPAIGN_OFFERS_NEP"))) {
        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for category: " + category);
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category: " + category);
      }
    }
  }

  // EP/OPAP and SMS - NEP and EMAIL and Viber for both
  @And(
      "I verify channels activation for EP and message type SMS, Viber, for NEP and message type EMAIL, Viber and OPAP and message type SMS have selected {string}")
  public void iVerifyChannelActivationViber(String selected) {
    Boolean expectedSelected = Boolean.valueOf(selected);
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      Boolean isSelected = js.getBoolean("[" + i + "].selected");

      if ((((category.equals("CAMPAIGN_OFFERS_EP")) || (category.equals("CAMPAIGN_OPAP")))
              && (messageType.equals("SMS")))
          || ((messageType.equals("EMAIL") && category.equals("CAMPAIGN_OFFERS_NEP")))
          || (messageType.equals("VIBER")
              && (category.equals("CAMPAIGN_OFFERS_EP")
                  || category.equals("CAMPAIGN_OFFERS_NEP")))) {
        Assertions.assertEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be true for category: " + category);
      } else {
        Assertions.assertNotEquals(
            expectedSelected,
            isSelected,
            "Expected 'selected' to be false for category: " + category);
      }
    }
  }

  @And("I copy the value of the notificationId from the response of GetPlayerNotifications")
  public void iCopyTheValueOfTheNotificationIdFromTheResponseOfGetPlayerNotifications() {
    // comment maybe we need list here? we lose other notifications? check in future calls.
    JsonPath jsonPathEvaluator = response.jsonPath();
    notificationId = jsonPathEvaluator.get("data[0].id");
    System.out.println("Notification Id is saved: " + notificationId);
  }

  @And("I copy the value of the notificationIdOnly from the response of GetPlayerNotifications")
  public void iCopyTheValueOfTheNotificationIdOnlyFromTheResponseOfGetPlayerNotifications() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    notificationIdOnly = jsonPathEvaluator.get("data[0].id").toString().substring(12);
    System.out.println("Notification Id is saved: " + notificationIdOnly);
  }

  @And("I copy the value of the userType from the response of GetPlayerNotifications")
  public void iCopyTheValueOfTheUserTypeFromTheResponseOfGetPlayerNotifications() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    userType = jsonPathEvaluator.get("data[0].id").toString().substring(0, 1);
    System.out.println("UserType is saved: " + userType);
  }

  @Then("the response body has single value {string}")
  public void theResponseBodyHasSingleValue(String expectedValue) {
    JsonPath jsonPathEvaluator = response.jsonPath();
    String actualValue = jsonPathEvaluator.get().toString();
    Assertions.assertEquals(expectedValue, actualValue);
  }

  @Given("I create a MarkNotificationAsSeen payload with {string}")
  public void iCreateAMarkNotificationAsSeenPayloadWith(String id) {

    if (id.equals("empty")) {
      requestBody = "";
    } else {
      requestBody = communicationServiceData.addMarkNotificationAsSeenPayload(id);
    }
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("specWithGameId"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @Given("I create a MarkNotificationAsRead payload with {string}")
  public void iCreateAMarkNotificationAsReadPayloadWith(String read) {

    if (read.isEmpty() || read.isBlank()) {
      requestBody = "";
    } else {
      requestBody =
          communicationServiceData.addMarkNotificationAsReadPayload(Boolean.parseBoolean(read));
    }
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("mainSpec"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @And("I change url resource of method {string} of service {string} with {string} notificationId")
  public void iChangeUrlResourceOfMethodOfServiceWithNewNotificationId(
      String resourceName, String service, String notifId) {

    String resourceValue = calculateEndpointUrl(service, resourceName);
    String[] values = resourceValue.split("/");
    String[] initialNotification;
    String regex = "";

    if (!resourceValue.contains("{{notificationId")) {
      initialNotification = values[6].split("-");

      regex =
          "\\d"
              + "{"
              + initialNotification[0].length()
              + "}-"
              + "\\d"
              + "{"
              + initialNotification[1].length()
              + "}-"
              + "\\d"
              + "{"
              + initialNotification[2].length()
              + "}";
    }

    System.out.println("Initial id:" + notifId);

    if (notifId.equals("new")) {
      if (resourceValue.contains("{{notificationId}}")) {
        resourceValue = resourceValue.replace("{{notificationId}}", notificationId);
      } else {
        resourceValue = resourceValue.replaceAll(regex, notificationId); // for second call
      }
    } else {
      Utils utils = new Utils();

      if (notifId.contains("playerId")) {
        notifId = notifId.replace("playerId", Utils.playerId);
      } else if (notifId.contains("randomPlayerId")) {
        notifId =
            notifId.replace(
                "randomPlayerId",
                String.valueOf(utils.calculateRandomInteger(100000000, 999999999)));
      }
      if (notifId.contains("notificationIdOnly")) {
        notifId = notifId.replace("notificationIdOnly", Utils.notificationIdOnly);
      } else if (notifId.contains("randomNotificationId")) {
        notifId =
            notifId.replace(
                "randomNotificationId", String.valueOf(utils.calculateRandomInteger(100, 999)));
      }
      if (notifId.contains("userType")) {
        notifId = notifId.replace("userType", Utils.userType);
      }
      if (notifId.contains("randomUserType")) {
        notifId =
            notifId.replace("randomUserType", String.valueOf(utils.calculateRandomInteger(10, 99)));
      }
      if (resourceValue.contains("{{notificationId}}")) {
        resourceValue = resourceValue.replace("{{notificationId}}", notifId);
      } else {

        resourceValue = resourceValue.replaceAll(regex, notifId); // for second call
        resourceValue = resourceValue.replace("{{notificationId}}", notifId);
      }
    }
    setResourceByService(service, resourceName, resourceValue);
    System.out.println("Dynamic url has been overridden with: " + resourceValue);
  }

  @When("I create a Post BulkMessages with {string} {string} {string} {string} {string}")
  public void iCreateAPostBulkMessagesWith(
      String externalIds,
      String eventOwners,
      String eventNames,
      String parameterWagerIds,
      String recipientUserIds) {

    String[] externalIdList = externalIds.split(",");
    String[] eventOwnersList = eventOwners.split(",");
    String[] eventNamesList = eventNames.split(",");
    String[] parameterWagerIdsList = parameterWagerIds.split(",");
    String[] recipientUserIdsList = recipientUserIds.split(",");

    List<BulkMessage> finalList = new ArrayList<>();

    for (int i = 0; i < externalIdList.length; i++) {
      BulkMessage bulkMessage =
          communicationServiceData.addBulkMessagesPayload(
              externalIdList[i],
              eventOwnersList[i],
              eventNamesList[i],
              parameterWagerIdsList[i],
              recipientUserIdsList[i]);
      finalList.add(bulkMessage);
    }
    requestBody = finalList;
    String specification = "api_mainSpec_mainHost";

    res =
        given()
            .spec(requestSpecWithHeadersSpecification(specification))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @Given(
      "I create a ChangeTemplateIdValues payload with {string} {string} {string} {string} {string} {string}")
  public void iCreateAChangeTemplateIdValuesPayloadWith(
      String subject,
      String status,
      String senderAddress,
      String senderName,
      String replyToAddress,
      String body) {
    requestBody =
        communicationServiceData.ChangeTemplateIdValues(
            subject, status, senderAddress, senderName, replyToAddress, body);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @Given(
      "I create a ChangeNotificationIdValues payload with {string} {string} {string} {string} {string} {string} {string}")
  public void iCreateAChangeNotificationIdValuesPayloadWith(
      String subject,
      String status,
      String senderAddress,
      String senderName,
      String replyToAddress,
      String body,
      String targetUrl) {
    requestBody =
        communicationServiceData.ChangeNotificationIdValues(
            subject, status, senderAddress, senderName, replyToAddress, body, targetUrl);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @Given("I create a AddMessageTypes Post payload with {string}")
  public void iCreateAAddMessageTypesPostPayloadWith(String messageTypes) {

    requestBody = communicationServiceData.addMessageTypesPayload(messageTypes);
    String specification = "api_mainSpec_mainHost";

    res =
        given()
            .spec(requestSpecWithHeadersSpecification(specification))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @And("I verify ALL EP for viber true")
  public void iVerifyALLEPForViberTrue() {

    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      boolean selected = js.get("[" + i + "].selected");

      if (category.equals("CAMPAIGN_OFFERS_EP")
          && (messageType.equals("EMAIL") || messageType.equals("VIBER"))) {
        Assertions.assertTrue(
            selected,
            "Object: "
                + i
                + 1
                + " with category "
                + category
                + "  with messageType "
                + messageType
                + " has selected "
                + selected);
      } else {
        Assertions.assertFalse(
            selected,
            "Object: "
                + i
                + 1
                + " with category "
                + category
                + "  with messageType "
                + messageType
                + " has selected "
                + selected);
      }
    }
  }

  @And("I verify ALL NEP without email and viber")
  public void iVerifyALLNEPWithoutEmailAndViber() {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      boolean selected = js.get("[" + i + "].selected");

      if ((category.equals("CAMPAIGN_OFFERS_NEP") && messageType.equals("SMS"))
          || (category.equals("CAMPAIGN_OFFERS_NEP") && messageType.equals("NOTIFY"))
          || (category.equals("CAMPAIGN_OFFERS_NEP") && messageType.equals("SOCIAL_MEDIA"))) {
        Assertions.assertTrue(
            selected,
            "Object: "
                + i
                + 1
                + " with category "
                + category
                + " with messageType "
                + messageType
                + " has selected "
                + selected);
      } else {
        Assertions.assertFalse(
            selected,
            "Object: "
                + i
                + 1
                + " with category "
                + category
                + "  with messageType "
                + messageType
                + " has selected "
                + selected);
      }
    }
  }

  @Then("I verify EP for SMS and NEP for EMAIL")
  public void iVerifyEPForSMSAndNEPForEMAIL() {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      boolean selected = js.get("[" + i + "].selected");

      if (category.equals("CAMPAIGN_OFFERS_EP") && messageType.equals("SMS")
          || (category.equals("CAMPAIGN_OFFERS_NEP") && messageType.equals("EMAIL"))) {
        Assertions.assertTrue(
            selected,
            "Object: "
                + i
                + 1
                + " with category "
                + category
                + "  with messageType "
                + messageType
                + " has selected "
                + selected);
      } else {
        Assertions.assertFalse(
            selected,
            "Object: "
                + i
                + 1
                + " with category "
                + category
                + "  with messageType "
                + messageType
                + " has selected "
                + selected);
      }
    }
  }

  @And("I verify NEP for SMS")
  public void iVerifyNEPForSMS() {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      boolean selected = js.get("[" + i + "].selected");

      if (category.equals("CAMPAIGN_OFFERS_EP") && messageType.equals("SMS")
          || (category.equals("CAMPAIGN_OFFERS_NEP") && messageType.equals("SMS"))) {
        Assertions.assertTrue(
            selected,
            "Object: "
                + i
                + 1
                + " with category "
                + category
                + "  with messageType "
                + messageType
                + " has selected "
                + selected);
      } else {
        Assertions.assertFalse(
            selected,
            "Object: "
                + i
                + 1
                + " with category "
                + category
                + "  with messageType "
                + messageType
                + " has selected "
                + selected);
      }
    }
  }

  @And("I verify email and call is included {string}")
  public void iVerifyEmailAndCallIsIncluded(String EPorNEP) {

    String categoryToCheck = "";
    if (EPorNEP.equals("EP")) {
      categoryToCheck = "CAMPAIGN_OFFERS_EP";
    } else if (EPorNEP.equals("NEP")) {
      categoryToCheck = "CAMPAIGN_OFFERS_NEP";
    } else {
      Assertions.fail("Wrong Parameter in step: " + EPorNEP);
    }

    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String messageType = js.get("[" + i + "].messageType");
      boolean selected = js.get("[" + i + "].selected");

      if (category.equals(categoryToCheck) && messageType.equals("EMAIL")
          || (category.equals(categoryToCheck) && messageType.equals("CALL"))) {
        Assertions.assertTrue(
            selected,
            "Object: "
                + i
                + 1
                + " with category "
                + category
                + "  with messageType "
                + messageType
                + " has selected "
                + selected);
      } else {
        Assertions.assertFalse(
            selected,
            "Object: "
                + i
                + 1
                + " with category "
                + category
                + "  with messageType "
                + messageType
                + " has selected "
                + selected);
      }
    }
  }

  // specific assertion for backoffice notifications v1.cc
  @And("I verify specific conditions for preferences with values for selected {}")
  public void iVerifySpecificPreferencesForNotificationsWithValuesForSelected(
      String selectedValues) {
    String[] selectedValuesList = selectedValues.split(",");

    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");

    if (selectedValuesList.length < 21) {
      Assertions.fail(
          "Wrong number of values to check. Expected 21 values in format true,false,true e.t.c");
    }
    for (int i = 0; i < count; i++) {
      String category = js.get("[" + i + "].category");
      String subCategory = js.get("[" + i + "].subCategory");
      String messageType = js.get("[" + i + "].messageType");
      String preferenceType = js.get("[" + i + "].preferenceType");
      boolean selected = js.get("[" + i + "].selected");
      String message =
          "Object: "
              + i
              + 1
              + " with category "
              + category
              + " subCategory "
              + subCategory
              + " with messageType "
              + messageType
              + " preferenceType "
              + preferenceType
              + " has selected "
              + selected;

      if (preferenceType.equals("EVENTS")) {
        // cases 1-3
        if (category.equals("ACCOUNTSECURITY") && subCategory.equals("CHANGE")) {

          if (messageType.equals("EMAIL")) { // case 1
            Assertions.assertEquals(Boolean.parseBoolean(selectedValuesList[0]), selected, message);
          } else if (messageType.equals("SMS")) { // case 2
            Assertions.assertEquals(Boolean.parseBoolean(selectedValuesList[1]), selected, message);
          } else if (messageType.equals("NOTIFY")) { // case 3
            Assertions.assertEquals(Boolean.parseBoolean(selectedValuesList[2]), selected, message);
          }
          // cases 4-6
        } else if (category.equals("CUSTOMERACCOUNT")
            && subCategory.equals("PERSONALDETAILSCHANGED")) {
          if (messageType.equals("EMAIL")) { // case 4
            Assertions.assertEquals(Boolean.parseBoolean(selectedValuesList[3]), selected, message);
          } else if (messageType.equals("SMS")) { // case 5
            Assertions.assertEquals(Boolean.parseBoolean(selectedValuesList[4]), selected, message);
          } else if (messageType.equals("NOTIFY")) { // case 6
            Assertions.assertEquals(Boolean.parseBoolean(selectedValuesList[5]), selected, message);
          }
          // cases 6-9
        } else if (category.equals("CUSTOMERLIMIT") && subCategory.equals("CHANGED")) {
          if (messageType.equals("EMAIL")) { // case 7
            Assertions.assertEquals(Boolean.parseBoolean(selectedValuesList[6]), selected, message);
          } else if (messageType.equals("SMS")) { // case 8
            Assertions.assertEquals(Boolean.parseBoolean(selectedValuesList[7]), selected, message);
          } else if (messageType.equals("NOTIFY")) { // case 9
            Assertions.assertEquals(Boolean.parseBoolean(selectedValuesList[8]), selected, message);
          }
        } else if (category.equals("CUSTOMERLIMIT") && subCategory.equals("REACHED")) {
          if (messageType.equals("EMAIL")) { // case 10
            Assertions.assertEquals(Boolean.parseBoolean(selectedValuesList[9]), selected, message);
          } else if (messageType.equals("SMS")) { // case 11
            Assertions.assertEquals(
                Boolean.parseBoolean(selectedValuesList[10]), selected, message);
          } else if (messageType.equals("NOTIFY")) { // case 12
            Assertions.assertEquals(
                Boolean.parseBoolean(selectedValuesList[11]), selected, message);
          }
        } else if (category.equals("PAYMENTS") && subCategory.equals("BANKACCCHANGE")) {
          if (messageType.equals("EMAIL")) { // case 13
            Assertions.assertEquals(
                Boolean.parseBoolean(selectedValuesList[12]), selected, message);
          } else if (messageType.equals("SMS")) { // case 14
            Assertions.assertEquals(
                Boolean.parseBoolean(selectedValuesList[13]), selected, message);
          } else if (messageType.equals("NOTIFY")) { // case 15
            Assertions.assertEquals(
                Boolean.parseBoolean(selectedValuesList[14]), selected, message);
          }
        } else if (category.equals("PAYMENTS") && subCategory.equals("DEPOSIT")) {
          if (messageType.equals("EMAIL")) { // case 16
            Assertions.assertEquals(
                Boolean.parseBoolean(selectedValuesList[15]), selected, message);
          } else if (messageType.equals("SMS")) { // case 17
            Assertions.assertEquals(
                Boolean.parseBoolean(selectedValuesList[16]), selected, message);
          } else if (messageType.equals("NOTIFY")) { // case 18
            Assertions.assertEquals(
                Boolean.parseBoolean(selectedValuesList[17]), selected, message);
          }
        } else if (category.equals("PAYMENTS") && subCategory.equals("WITHDRAWAL")) {
          if (messageType.equals("EMAIL")) { // case 19
            Assertions.assertEquals(
                Boolean.parseBoolean(selectedValuesList[18]), selected, message);
          } else if (messageType.equals("SMS")) { // case 20
            Assertions.assertEquals(
                Boolean.parseBoolean(selectedValuesList[19]), selected, message);
          } else if (messageType.equals("NOTIFY")) { // case 21
            Assertions.assertEquals(
                Boolean.parseBoolean(selectedValuesList[20]), selected, message);
          }
        }
      }
    }
  }

  @And("I change url resource of method {string} of service {string} with notificationId {string}")
  public void iChangeUrlResourceOfMethodOfServiceWithNotificationId(
      String resourceName, String service, String notifyId) {
    String resourceValue = calculateEndpointUrl(service, resourceName);

    String regexPatternNotificationId =
        "(?<=/notifications/)[^/]+"; // Match any alphanumeric value after notifications

    if (notifyId.equalsIgnoreCase("changeit")) {
      notifyId = notificationId;
    }
    if (resourceValue.contains("web") && isMeEnabledInWeb) {
      resourceValue = resourceValue.replaceFirst(regexPatternNotificationId, "me");
      setResourceByService(service, resourceName, resourceValue);
    } else {
      resourceValue = resourceValue.replaceFirst(regexPatternNotificationId, notifyId);
      setResourceByService(service, resourceName, resourceValue);
    }
    System.out.println("Dynamic url has been overridden with: " + resourceValue);
  }
}
