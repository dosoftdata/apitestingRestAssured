package stepDefinitions;

import io.cucumber.java.BeforeAll;
import org.junit.platform.suite.api.*;
import static io.cucumber.junit.platform.engine.Constants.*;

@Suite
@SuiteDisplayName("Rest Assured Suite")
@IncludeEngines("cucumber")
public class RunCucumberTest {
  @BeforeAll
  public static void beforeAllScenario() {
    Hooks h = new Hooks();
    h.beforeScenario();
  }
}
