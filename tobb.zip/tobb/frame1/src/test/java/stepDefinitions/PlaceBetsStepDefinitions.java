package stepDefinitions;

import apiResources.Utils;
import apiResources.endpoints.CommunicationServiceResources;
import apiResources.testDataBuild.PlayerServiceData;
import apiResources.testDataBuild.WagerServiceData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import java.util.ArrayList;

import static apiResources.endpoints.CommunicationServiceResources.*;
import static apiResources.endpoints.CommunicationServiceResources.smsId;
import static io.restassured.RestAssured.given;

public class PlaceBetsStepDefinitions extends Utils {
    WagerServiceData data = new WagerServiceData();

    @Given(
            "I create a PlayBetFunds payload with taxAmount {float} gameId {string} bonusAmount {float} {string} {float} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
    public void iCreateAPlayBetFundsPayloadWith(
            float taxAmount,
            String gameId,
            float bonusAmount,
            String accountId,
            float amount,
            String currency,
            String issued,
            String productId,
            String type,
            String description,
            String autocapture,
            String status,
            String captured,
            String metadataBonusPrizeId) {
        if (issued.equals("datenow")) {
            issued = calculateDateNowInSecondsToString();
        }
        requestBody =
                data.addPlayBetFundsPayload(
                        taxAmount,
                        gameId,
                        bonusAmount,
                        accountId,
                        amount,
                        currency,
                        issued,
                        productId,
                        type,
                        description,
                        autocapture,
                        status,
                        captured,
                        metadataBonusPrizeId);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("api_specWithGameId"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @Given(
            "I create a PlayBetFundsExtra payload with taxAmount {float} gameId {string} bonusAmount {float} {string} {float} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
    public void iCreateAPlayBetFundsExtraPayloadWith(
            float taxAmount,
            String gameId,
            float bonusAmount,
            String accountId,
            float amount,
            String currency,
            String issued,
            String productId,
            String type,
            String description,
            String autocapture,
            String status,
            String captured,
            String bonusRollover,
            String metadataBonusPrizeId) {
        if (issued.equals("datenow")) {
            issued = calculateDateNowInSecondsToString();
        }
        requestBody =
                data.addPlayBetFundsExtraPayload(
                        taxAmount,
                        gameId,
                        bonusAmount,
                        accountId,
                        amount,
                        currency,
                        issued,
                        productId,
                        type,
                        description,
                        autocapture,
                        status,
                        captured,
                        bonusRollover,
                        metadataBonusPrizeId);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("api_specWithGameId"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @Given("I create a CaptureBet payload with {float}")
    public void iCreateACaptureBetPayloadWith(float amount) {
        requestBody = data.addCaptureBetPayload(amount);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("api_specWithGameId"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @Given("I create a PlaceWager payload with {string} {string} {string} {string} {string} {string} {string}")
    public void iCreateAPlaceWagerPayloadWith(
            String gameType,
            String betType,
            String boardId,
            String mainSelection,
            String JokerSelection,
            String multipleDraws,
            String quickPick) {

        ArrayList<Integer> mainselec = new ArrayList<>();
        ArrayList<Integer> jokerselec = new ArrayList<>();

        String[] main = mainSelection.split(" ", 46);
        String[] joker = JokerSelection.split(" ", 21);

        if (!Boolean.parseBoolean(quickPick)) {
            for (int i = 0; i < main.length; i++) {
                mainselec.add(Integer.valueOf(main[i]));
            }

            for (int i = 0; i < joker.length; i++) {
                jokerselec.add(Integer.valueOf(joker[i]));
            }
        }
        // random values mock quickpick
        else {
            mainselec = calculateRandomValue(mainselec);
            int maxJoker = 20;
            int minJoker = 1;
            jokerselec.add((int) Math.floor(Math.random() * (maxJoker - minJoker + 1) + minJoker));
        }

        int tempBoardId;
        if (boardId.isBlank() || boardId.isEmpty()) {
            tempBoardId = -99; // some value such as to ignore if is blank as boardId is optional
        } else {
            tempBoardId = Integer.parseInt(boardId);
        }

        int tempDraws;
        if (multipleDraws.isBlank() || multipleDraws.isEmpty()) {
            tempDraws = -99; // some value such as to ignore if is blank as boardId is optional
        } else {
            tempDraws = Integer.parseInt(multipleDraws);
        }

        requestBody =
                data.addWagerPayload(
                        gameType,
                        Integer.parseInt(betType),
                        tempBoardId,
                        mainselec,
                        jokerselec,
                        tempDraws,
                        quickPick);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("specWithGameIdOrigin"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @Given(
            "I create a PlaceMultipleWagers payload with {string} {string} {string} {string} {string} {string}")
    public void iCreateAPlaceMultipleWagersPayloadWith(
            String gameType,
            String betType,
            String boardId,
            String mainSelection,
            String JokerSelection,
            String quickPick) {

        ArrayList<Integer> mainselec = new ArrayList<>();
        ArrayList<Integer> jokerselec = new ArrayList<>();

        String[] main = mainSelection.split(" ", 46);
        String[] joker = JokerSelection.split(" ", 21);

        for (int i = 0; i < main.length; i++) {
            mainselec.add(Integer.valueOf(main[i]));
        }

        for (int j = 0; j < joker.length; j++) {
            jokerselec.add(Integer.valueOf(joker[j]));
        }

        int tempBoardId;
        if (boardId.isBlank() || boardId.isEmpty()) {
            tempBoardId = -99; // some value such as to ignore if is blank as boardId is optional
        } else {
            tempBoardId = Integer.parseInt(boardId);
        }

        requestBody =
                data.addMultipleWagerPayload(
                        gameType, Integer.parseInt(betType), tempBoardId, mainselec, jokerselec, quickPick);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("specWithGameIdOrigin"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @Given("I create a CancelReservation payload with reason {string}")
    public void iCreateACancelReservationPayloadWithAmountReason(String reason) {
        requestBody = data.addCancelReservationPayload(reason);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("api_specWithGameId"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @Then("I copy the value of the serialNumber from the response")
    public void iCopyTheValueOfTheSerialNumberFromTheResponse() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        serialNumber = jsonPathEvaluator.getString("[0].wager.serialNumbers[0]");
        System.out.println("SerialNumber saved: " + serialNumber);
    }

    @Then("I copy the value of the serialNumber in multiple wager from the response")
    public void iCopyTheValueOfTheSerialNumberInMultipleWagerFromTheResponse() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        serialNumber = jsonPathEvaluator.get("wager[0].serialNumbers[0]");
        System.out.println("SerialNumber saved: " + serialNumber);
    }

    @Then(
            "I verify the serial number in array with index {string} is the serialNumber from placeWager")
    public void iVerifyTheSerialNumberInArrayWithIndexIsTheSerialNumberFromPlaceWager(
            String arrayWithIndex) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        String serialNumberResponse = jsonPathEvaluator.get(arrayWithIndex);
        Assertions.assertEquals(serialNumberResponse, serialNumber);
    }

    @Then(
            "I create a PayWinningBet payload with {int} {int} {string} {string} {string} {string} {string}")
    public void iCreateAPayWinningBetPayloadWith(
            int amount,
            int taxAmount,
            String currency,
            String description,
            String issued,
            String partialPayment,
            String productId) {
        if (issued.equals("datenow")) {
            issued = calculateDateNowInSecondsToString();
        }
        requestBody =
                data.addPayWinningPayload(
                        amount, taxAmount, currency, description, issued, partialPayment, productId);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("api_intralotSpecWithGameId"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @Then("I copy the value of the balance in wallet {string}")
    public void iCopyTheValueOfTheBalanceInWallet(String wallet) {

        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");
        boolean success = false;

        for (int i = 0; i < count; i++) {
            String walletId = js.get("[" + i + "].id");

            if (walletId.equals(wallet)) {
                if (wallet.contains("1")) {
                    mainAmountOld = js.get("[" + i + "].balance").toString();
                } else if (wallet.contains("2")) {
                    mainAmount2Old = js.get("[" + i + "].balance").toString();
                }
                success = true;
                break;
            }
        }
        if (!success) {
            Assertions.fail("Value for copy not found");
        }
    }

    @Then("I verify the balance in wallet {string} remains the same")
    public void iVerifyBalanceInBothWallets(String wallet) {

        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");
        boolean success = false;

        for (int i = 0; i < count; i++) {
            String walletId = js.get("[" + i + "].id");

            if (walletId.equals(wallet)) {
                String balance = js.get("[" + i + "].balance").toString();
                if (walletId.contains("1")) {
                    Assertions.assertEquals(
                            balance,
                            mainAmountOld,
                            "Amount from previous getWalletBalance:  "
                                    + mainAmountOld
                                    + " is not equal to balance returned "
                                    + balance);
                } else if (walletId.contains("2")) {
                    Assertions.assertEquals(
                            balance,
                            mainAmount2Old,
                            "Amount from previous getWalletBalance:  "
                                    + mainAmount2Old
                                    + " is not equal to balance returned "
                                    + balance);
                }
                success = true;
                break;
            }
        }
        if (!success) {
            Assertions.fail("Wallet not found " + wallet);
        }
    }

    @Then("I verify the balance in wallet {string} is {string}")
    public void iVerifyTheAmountInWalletIs(String wallet, String amount) {
        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");
        boolean success = false;

        for (int i = 0; i < count; i++) {
            String walletId = js.get("[" + i + "].id");

            if (walletId.equals(wallet)) {
                String balance = js.get("[" + i + "].balance").toString();
                Assertions.assertEquals(
                        amount,
                        balance,
                        "Amount expected " + amount + " is not equal to balance returned " + balance);
                success = true;
                break;
            }
        }
        if (!success) {
            Assertions.fail("Wallet " + wallet + " not found in response");
        }
    }

    @Then("I verify the balance in wallet {string} is oldAmount {string} {float}")
    public void iVerifyTheBalanceInWalletIsOldAmount(String wallet, String equation, float amount) {

        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");
        boolean success = false;

        for (int i = 0; i < count; i++) {
            String walletId = js.get("[" + i + "].id");

            if (walletId.equals(wallet)) {
                String balance = js.get("[" + i + "].balance").toString();
                float newBalance = 0;
                if (wallet.contains("1")) {
                    if (equation.equals("+")) {
                        newBalance = Float.parseFloat(mainAmountOld) + amount;
                    } else if (equation.equals("-")) {
                        newBalance = Float.parseFloat(mainAmountOld) - amount;
                    }
                } else if (wallet.contains("2")) {
                    if (equation.equals("+")) {
                        newBalance = Float.parseFloat(mainAmount2Old) + amount;
                    } else if (equation.equals("-")) {
                        newBalance = Float.parseFloat(mainAmount2Old) - amount;
                    }
                } else {
                    Assertions.fail("Testing code for wallet" + wallet + "not implemented");
                }
                Assertions.assertEquals(
                        newBalance,
                        Float.parseFloat(balance),
                        "Amount expected " + newBalance + " is not equal to balance returned " + balance);
                success = true;
                break;
            }
        }
        if (!success) {
            Assertions.fail("Wallet " + wallet + " not found in response");
        }
    }

    @And("I create a PlayBetFunds payload with taxAmount {} gameId {} bonusAmount {} {string} {} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
    public void iCreateAPlayBetFundsPayloadWithTaxAmountGameIdBonusAmount(String arg0, String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8, String arg9, String arg10, String arg11, String arg12, String arg13, String arg14, String arg15, String arg16, String arg17, String arg18, String arg19, String arg20, String arg21, String arg22, String arg23, String arg24, String arg25) {
    }
}
