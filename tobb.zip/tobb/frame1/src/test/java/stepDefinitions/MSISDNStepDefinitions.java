package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.PlayerServiceData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import static apiResources.endpoints.CommunicationServiceResources.smsId;
import static io.restassured.RestAssured.given;

public class MSISDNStepDefinitions extends Utils {
  PlayerServiceData data = new PlayerServiceData();
  CommonStepDefinitions commonStepDefinitions = new CommonStepDefinitions();

  // region MSISDN Registration Feature
  @Given("I create a MSISDN Register PUT payload with calculated MSISDN and OTP")
  public void iCreateAMSISDNRegisterPUTPayload() {
    csrftoken = ccCsrftoken;
    commonStepDefinitions.iChangeUrlResourceWithNewPlayerId("MSISDNRegister", "PlayerService");

    requestBody = data.addMSISDNRegisterPayload(randomIntGenerated, otp);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("specWithGameIdNoToken"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @Then("I copy the value of the smsId from the response")
  public void iCopyTheValueOfSmsIdFromTheResponse() {

    JsonPath jsonPathEvaluator = response.jsonPath();
    smsId = jsonPathEvaluator.get("data[0].id");
    String messageText = jsonPathEvaluator.get("data[0].messageText");
    String[] messageTextSplit = messageText.split(" ");

    for (int i = 0; i < messageTextSplit.length; i++) {
      if (messageTextSplit[i].matches("\\d+")) {
        otp = messageTextSplit[i];
      }
    }

    System.out.println("SMS Id saved: " + smsId);
    System.out.println("OTP saved: " + otp);
    commonStepDefinitions.iChangeUrlResourceWithNewSmsId(
        "GetBoSmsDescription", "CommunicationService");
  }

  @Then("I verify the id in response body is smsId")
  public void theInResponseBodyIsSmsId() {
    Assertions.assertEquals(smsId, getJsonPath(response, "id"));
  }

  @Then(
      "I verify the {string} in response body is {string} plus mobilePrefix plus randomIntGenerated")
  public void iVerifyTheInResponseBodyIsPlusMobilePrefixPlusRandomIntGenerated(
      String property, String index) {
    Assertions.assertEquals(
        index + mobilePrefix + randomIntGenerated, getJsonPath(response, property));
  }

  @Then("I verify the {string} in response body is mobilePrefix plus randomIntGenerated")
  public void theInResponseBodyIsRandomIdGenerated(String property) {
    Assertions.assertEquals(mobilePrefix + randomIntGenerated, getJsonPath(response, property));
  }

  @Then(
      "I verify the {string} in response body has all digits masked but the first and the last three")
  public void theInResponseBodyHasTheFirstDigitMaskedAndTheLast3Masked(String property) {
    String firstDigit = mobilePrefix.substring(0, 1);
    String intGenerated = String.valueOf(randomIntGenerated);
    System.out.println("RandomIntGenerated is: " + randomIntGenerated);
    String last3digits = intGenerated.substring(intGenerated.length() - 3);
    Assertions.assertEquals(firstDigit + "******" + last3digits, getJsonPath(response, property));
  }

  @Then(
      "the property {string} in response body array with index {string} does not have playerId value")
  public void thePropertyInResponseBodyArrayWithIndexDoesNotHavePlayerIdValue(
      String property, String arrayWithIndex) {
    JsonPath jsonPathEvaluator = response.jsonPath();
    String actualValue = jsonPathEvaluator.get(arrayWithIndex + "." + property);
    Assertions.assertNotEquals(
        playerId,
        actualValue,
        "Expected property value" + playerId + "is equal with actual value " + actualValue);
  }

  @Then("the property {string} in response body array with index {string} has playerId value")
  public void thePropertyInResponseBodyArrayWithIndexHasPlayerIdValue(
      String property, String arrayWithIndex) {
    JsonPath jsonPathEvaluator = response.jsonPath();
    String actualValue = jsonPathEvaluator.get(arrayWithIndex + "." + property);
    Assertions.assertEquals(
        playerId,
        actualValue,
        "Expected property value" + playerId + "is not equal with actual value " + actualValue);
  }

  @Then("I verify KYC MSISDN Status with status {string} and alreadyVerified {booleanValue}")
  public void iVerifyKYCMSISDNStatusWithStatus(String status, boolean verified) {
    JsonPath js = new JsonPath(response.asString());
    int count = js.getInt("js.size()");
    boolean success = false;
    for (var i = 0; i < count; i++) {
      String type = js.get("type[" + i + "]");
      Object verification = js.get("verification[" + i + "]");

      if (verification != null && type.equals("MSISDN")) {
        String verificationStatus = js.get("verification[" + i + "].status");
        String verificationValue = js.get("verification[" + i + "].value");
        boolean alreadyVerified = js.get("verification[" + i + "].metadata.alreadyVerified");

        Assertions.assertEquals(status, verificationStatus);
        Assertions.assertEquals(verified, alreadyVerified);
        Assertions.assertEquals(mobilePrefix + randomIntGenerated, verificationValue);
        System.out.println("KYC MSISDN Status verified successfully");
        success = true;
        break;
      }
    }
    if (!success) {
      Assertions.fail("KYC MSISDN Status" + status + "has not been found");
    }
  }

  @Then(
      "the property {string} in response body array with index {string} has mobilePrefix plus randomIntGenerated")
  public void thePropertyInResponseBodyArrayWithIndexHasNewMobileValue(
      String property, String arrayWithIndex) {
    JsonPath jsonPathEvaluator = response.jsonPath();
    String expectedValue = mobilePrefix + randomIntGenerated;
    String actualValue =
        jsonPathEvaluator
            .get(arrayWithIndex + "." + property)
            .toString()
            .replace("[", "")
            .replace("]", "");
    Assertions.assertEquals(
        expectedValue,
        actualValue,
        "Expected property value"
            + expectedValue
            + "is not equal with actual value "
            + actualValue);
  }

  // endregion

  // region MSISDN Verification Feature
  @Given("I create a MSISDN RegisterNew PUT payload with calculated MSISDN and OTP null")
  public void iCreateAMSISDNRegisterNewPUTPayloadWithOTPNull() {
    commonStepDefinitions.iChangeUrlResourceWithNewPlayerId("MSISDNRegisterNew", "PlayerService");
    int random_integer = calculateRandomInteger(10000000, 99999999);
    oldRandomIntGenerated = randomIntGenerated;
    randomIntGenerated = random_integer;
    System.out.println("RandomIntGenerated is: " + randomIntGenerated);
    requestBody = data.addMSISDNRegisterPayload(randomIntGenerated, null);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("specWithGameId"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  // TODO: to be deprecated after preprod deployment.
  @Given("I create a MSISDN RegisterNew PUT payload with calculated MSISDN and OTP")
  public void iCreateAMSISDNRegisterNewPUTPayloadWithCalculatedOTP() {
    commonStepDefinitions.iChangeUrlResourceWithNewPlayerId("MSISDNRegisterNew", "PlayerService");
    requestBody = data.addMSISDNRegisterPayload(randomIntGenerated, otp);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("specWithGameId"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @Given("I create a PUT MSISDN Verify payload with calculated MSISDN and OTP")
  public void iCreateAPutMsisdnVerifyPayloadWithCalculatedMsisdnAndOtp() {
    requestBody = data.addMSISDNRegisterPayload(randomIntGenerated, otp);
    res =
        given()
            .spec(requestSpecWithHeadersSpecification("specWithGameId"))
            .body(requestBody)
            .relaxedHTTPSValidation();
  }

  @Then("I verify the {string} in response body is mobilePrefix plus old randomIntGenerated")
  public void theInResponseBodyIsOldRandomIdGenerated(String property) {
    Assertions.assertEquals(mobilePrefix + oldRandomIntGenerated, getJsonPath(response, property));
  }

  @Then(
      "the property {string} in response body array with index {string} has mobilePrefix plus oldRandomIntGenerated")
  public void thePropertyInResponseBodyArrayWithIndexHasOldMobileValue(
      String property, String arrayWithIndex) {
    JsonPath jsonPathEvaluator = response.jsonPath();
    String expectedValue = mobilePrefix + oldRandomIntGenerated;
    String actualValue =
        jsonPathEvaluator
            .get(arrayWithIndex + "." + property)
            .toString()
            .replace("[", "")
            .replace("]", "");
    Assertions.assertEquals(
        expectedValue,
        actualValue,
        "Expected property value"
            + expectedValue
            + "is not equal with actual value "
            + actualValue);
  }

  @And("I copy the value of the resourceValue from the response")
  public void iCopyTheValueOfTheResourceValueFromTheResponse() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    resourceValue = jsonPathEvaluator.get("resourceValue");
    System.out.println("Resource Value saved: " + resourceValue);
  }

  @And("I copy the value of the resource from the response")
  public void iCopyTheValueOfTheResourceFromTheResponse() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    resource = jsonPathEvaluator.get("resource");
    System.out.println("Resource saved: " + resource);
  }

  @And("I copy the value of the otpId from the response")
  public void iCopyTheValueOfTheOtpIdFromTheResponse() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    otpId = jsonPathEvaluator.get("id");
    System.out.println("Resource saved: " + otpId);
  }

  @Given("I setup X-OTP header to {string}")
  public void iSetupXOTPHeaderTo(String otp) {
    otpCode = otp;
  }

  @And("I copy the value of otpCode from messageText from the response")
  public void iCopyTheValueOfOtpFromMessageTextFromTheResponse() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    String messageText = jsonPathEvaluator.get("data[0].messageText");
    String[] messageTextSplit = messageText.split(" ");

    for (int i = 0; i < messageTextSplit.length; i++) {
      if (messageTextSplit[i].matches("\\d+")) {
        otpCode = messageTextSplit[i];
      }
    }
    System.out.println("OTP Code saved: " + otpCode);
  }
  // endregion
}
