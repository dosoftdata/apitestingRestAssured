package stepDefinitions;

import static io.restassured.RestAssured.given;

import apiResources.Utils;
import apiResources.testDataBuild.mockData.DatabaseBridgeData;
import io.cucumber.java.en.*;

public class DatabaseBridgeStepDefinitions extends Utils {

  DatabaseBridgeData databaseBridgeData = new DatabaseBridgeData();

  @Given("I create a DataBridge Payload with {string}")
  public void iCreateADataBridgePayloadWith(String query) throws Exception {
    drillOrBridge = true;
    requestBody = databaseBridgeData.addDatabaseBridgeData(query);
    String specification = "emptySpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }
}
