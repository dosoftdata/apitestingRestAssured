package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.BonusServiceData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import java.util.ArrayList;

import static io.restassured.RestAssured.given;

public class BonusStepDefinitions extends Utils {

    BonusServiceData bonusServiceData = new BonusServiceData();

    @Given("I create a PUT UpdateBonusPrizes payload with {string} {string} {string} {float} {}")
    public void iCreateAPUTUpdateBonusPrizesPayloadWith(
            String providerId, String gameId, String status, float amount, boolean closeAccount) {
        requestBody =
                bonusServiceData.updateBonusPrizes(providerId, gameId, status, amount, closeAccount);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("api_mainSpec_mainHost"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @Given("I create a PUT cancelBonusPrize payload")
    public void iCreateAPUTCancelBonusPrizePayloadWithStatus(
            String status) {
        requestBody = bonusServiceData.cancelBonusPrize();

        res = given()
                .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
                .body(requestBody)
                .relaxedHTTPSValidation();
    }

    @Given("I create a PUT updateFdbBonus payload with {string} {string} {string}")
    public void iCreateAPUTUpdateFdbBonusPayloadWith(
            String fdbEnabled, String fdbLinkEl, String fdbLinkEn) {

        // Assume updateBonusPrizes method is adapted to handle variable parameters
        requestBody = bonusServiceData.updateBonusFdbEnable(fdbEnabled, fdbLinkEl, fdbLinkEn);

        // Build the request body using the given parameters and extraParams
        res = given()
                .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
                .body(requestBody)
                .relaxedHTTPSValidation();
    }

    @Given("I create a POST assignBonus payload with new playerId")
    public void iCreateAPOSTAssignBonusToUserPayloadWith() {
        String userId = "1-" + playerId;
        // Assume updateBonusPrizes method is adapted to handle variable parameters
        requestBody = bonusServiceData.assignBonusToUser(userId);

        // Build the request body using the given parameters and extraParams
        res = given()
                .spec(requestSpecWithHeadersSpecification("api_mainSpec_mainHost"))
                .body(requestBody)
                .relaxedHTTPSValidation();
    }

    @Given("I create a PUT cancelBonus payload")
    public void iCreateAPUTCancelBonusPayloadWithStatus() {
        requestBody = bonusServiceData.cancelBonus();

        res = given()
                .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
                .body(requestBody)
                .relaxedHTTPSValidation();
    }

    @Then("I copy the value of the bonusPrizeId from the response if exists")
    public void iCopyTheValueOfTheBonusPrizeIdFromTheResponseIfExists() {
        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");
        bonusPrizeExists = false;

        if (count > 0) {
            bonusPrizeId = getJsonPath(response, "id").replace("[", "").replace("]", "");
            System.out.println("BonusPrizeId saved: " + bonusPrizeId);
            bonusPrizeExists = true;
        } else {
            System.out.println("BonusPrizeId has not been found");
        }
    }

    @Given("I create a POST assignBonus payload with {string} userId")
    public void iCreateAPOSTAssignBonusToUserPayloadWith(String userIs) {
        String localUserId = "";
        if (userIs.equals("valid")) {
            localUserId = "1-" + playerId;
        } else if (userIs.equals("invalid")) {
            localUserId = playerId;
        } else if (userIs.toLowerCase().contains("notfound")) {
            localUserId = "1-123456789";
        }

        // Assume updateBonusPrizes method is adapted to handle variable parameters
        requestBody = bonusServiceData.assignBonusToUser(localUserId);

        // Build the request body using the given parameters and extraParams
        res = given()
                .spec(requestSpecWithHeadersSpecification("api_mainSpec_mainHost"))
                .body(requestBody)
                .relaxedHTTPSValidation();
    }

    @And("I change url resource of method {string} of service {string} with new bonusPrizeId")
    public void iChangeUrlResourceOfMethodOfServiceWithNewBonusPrizeId(
            String resourceName, String service) {
        String resourceValue = calculateEndpointUrl(service, resourceName);
        int bonusPrizeLength = bonusPrizeId.length();
        // for retry
        if (resourceName.equals("GetBonusPrizesWithId")) {
            resourceValue =
                    resourceValue.replaceAll(
                            "/assigned/[0-9]{" + bonusPrizeLength + "}",
                            "/assigned/"
                                    + bonusPrizeId); // for retry if method has no /assigned doesn't work on retry
            // only.

        } else {
            resourceValue =
                    resourceValue.replaceAll(
                            "/bonus-prizes/[0-9]{" + bonusPrizeLength + "}",
                            "/bonus-prizes/"
                                    + bonusPrizeId); // for retry if method has no /bonus-prizes doesn't work on retry
            // only.
        }
        resourceValue = resourceValue.replace("{{bonusPrizeId}}", bonusPrizeId);

        setResourceByService(service, resourceName, resourceValue);

        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    @And("I change url resource of method {string} of service {string} with invalid bonusPrizeId")
    public void iChangeUrlResourceOfMethodOfServiceWithInvalidBonusPrizeId(
            String resourceName, String service) {
        String resourceValue = calculateEndpointUrl(service, resourceName);
        int previousBonusPrizeLength = bonusPrizeId.length();
        String localBonusPrizeId = "9".repeat(previousBonusPrizeLength);
        // Set bonusPrizeId to localBonusPrizeId for retry purposes

        System.out.println("Previous bonusPrizeId length: " + previousBonusPrizeLength);

        // for retry
        if (resourceName.equals("GetBonusPrizesWithId")) {
            resourceValue =
                    resourceValue.replaceAll(
                            "/assigned/[0-9]{" + previousBonusPrizeLength + "}",
                            "/assigned/"
                                    + localBonusPrizeId); // for retry if method has no /assigned doesn't work on retry
            // only.

        } else {
            resourceValue =
                    resourceValue.replaceAll(
                            "/bonus-prizes/[0-9]{" + previousBonusPrizeLength + "}",
                            "/bonus-prizes/"
                                    + localBonusPrizeId); // for retry if method has no /bonus-prizes doesn't work on retry
            // only.
        }

        resourceValue = resourceValue.replace("{{bonusPrizeId}}", localBonusPrizeId);

        setResourceByService(service, resourceName, resourceValue);

        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    @When("I create a POST AssignBonus payload with {string} {string} {string}")
    public void iCreateAPOSTAssignBonusPayloadWith(String amount, String gameId, String providerId) {
        requestBody = bonusServiceData.assignBonusToUser(amount, gameId, providerId);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("api_mainSpec_mainHost"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @When("I create a POST AllowedGames payload with {string} {string}")
    public void iCreateAPOSTAllowedGamesPayloadWith(String gameType, String gameIds) {
        String[] gameIdsArr = gameIds.split(",");
        ArrayList<String> listOfGameIds = new ArrayList<>();


        for (int i = 0; i < gameIdsArr.length; i++) {
            listOfGameIds.add(gameIdsArr[i].trim());
        }

        requestBody = bonusServiceData.postAllowedGames(gameType, listOfGameIds);
        res = given()
                .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
                .body(requestBody)
                .relaxedHTTPSValidation();
    }

    @When("I create a POST FdbSelection payload with {string} {string}")
    public void iCreateAPOSTBonusPrizeFdbSelectionPayloadWith(String gameId, String playerId) {
        requestBody = bonusServiceData.bonusPrizeFdbSelect(gameId, playerId);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification(specString))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }

    @When(
            "I create a POST AddBonus payload with {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
    public void iCreateAPOSTAddBonusPayloadWith(
            String rewardType,
            String bonusAssignment,
            String activationTrigger,
            String rewardAmountType,
            String bonusValidTo,
            String minimumBets,
            String gameType,
            String gameIds,
            String singleUse,
            String rewardExpiryDays,
            String rewardAmount,
            String status,
            String rollOver,
            String program) {
        requestBody =
                bonusServiceData.addBonus(
                        rewardType,
                        bonusAssignment,
                        activationTrigger,
                        rewardAmountType,
                        bonusValidTo,
                        minimumBets,
                        gameType,
                        gameIds,
                        singleUse,
                        rewardExpiryDays,
                        rewardAmount,
                        Integer.parseInt(status),
                        rollOver,
                        program);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();


    }

    @When(
            "I create a POST AddBonus payload with extra fields {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
    public void iCreateAPOSTAddBonusPayloadWithExtraFields(
            String rewardType,
            String bonusAssignment,
            String activationTrigger,
            String paymentMethodName,
            String paymentMethodPercentage,
            String activationExpiryDays,
            String activationMinimumAmount,
            String rewardAmountType,
            String bonusValidTo,
            String bonusValidFrom,
            String minimumBets,
            String minimumBetAmount,
            String gameType,
            String gameIds,
            String singleUse,
            String bonusTerms,
            String rewardExpiryDays,
            String rewardAmount,
            String entryRequirement,
            String bonusCode,
            String status,
            String rollOver,
            String program) {
        requestBody =
                bonusServiceData.addBonusExtraFields(
                        rewardType,
                        bonusAssignment,
                        activationTrigger,
                        paymentMethodName,
                        paymentMethodPercentage,
                        activationExpiryDays,
                        activationMinimumAmount,
                        rewardAmountType,
                        bonusValidTo,
                        bonusValidFrom,
                        minimumBets,
                        minimumBetAmount,
                        gameType,
                        gameIds,
                        singleUse,
                        bonusTerms,
                        rewardExpiryDays,
                        rewardAmount,
                        entryRequirement,
                        bonusCode,
                        Integer.parseInt(status),
                        rollOver,
                        program);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();

    }

    // Works for array of objects of bonuses
    @And(
            "I copy the value of the first bonusActiveId of providerId {string} and rewardType {string} from the response")
    public void iCopyTheValueOfTheBonusActiveIdFromTheResponse(String providerId, String rewardType) {

        JsonPath js = new JsonPath(response.asString());
        int totalRows = js.getInt("totalRowCount");
        boolean success = false;
        bonusActiveIdExists = false;

        for (int i = 0; i < totalRows; i++) {
            String externalCampaignResponse = js.get("pageItems[" + i + "].rewardType");
            String gameIdResponse = js.get("pageItems[" + i + "].allowedGames[0].gameIds[0]");

            if (externalCampaignResponse.equals(rewardType) && gameIdResponse.equals(providerId)) {
                bonusActiveId =
                        js.get("pageItems[" + i + "].bonusId").toString().replace("[", "").replace("]", "");
                System.out.println("BonusActiveId saved: " + bonusActiveId);
                success = true;
                bonusActiveIdExists = true;
                break;
            }
        }
        if (!success) {
            System.out.println("No Active Bonus exist for providerId " + providerId);
            bonusActiveIdExists = false;
        }
    }

    // Works for object of bonus
    @And(
            "I copy the value of the bonusId of providerId {string} and rewardType {string} from the response")
    public void iCopyTheValueOfTheBonusIdFromTheResponse(String providerId, String rewardType) {
        JsonPath js = new JsonPath(response.asString());
        String rewardTypeResponse = js.get("rewardType");
        String gameIdResponse = js.get("allowedGames[0].gameIds[0]");
        boolean success = false;
        bonusActiveIdExists = false;

        if (rewardTypeResponse.equals(rewardType) && gameIdResponse.equals(providerId)) {
            bonusPrizeId = getJsonPath(response, "bonusId").replace("[", "").replace("]", "");
            System.out.println("BonusActiveId saved: " + bonusActiveId);
            success = true;
            bonusActiveIdExists = true;
        }

        if (!success) {
            System.out.println("No Active Bonus exist for providerId " + providerId);
            bonusActiveIdExists = false;
        }
    }

    @And(
            "I copy the value of the first bonusName of providerId {string} and rewardType {string} from the response")
    public void iCopyTheValueOfTheBonusNameFromTheResponse(String providerId, String rewardType) {

        JsonPath js = new JsonPath(response.asString());
        int totalRows = js.getInt("totalRowCount");
        boolean success = false;
        bonusActiveIdExists = false;

        for (int i = 0; i < totalRows; i++) {
            String externalCampaignResponse = js.get("pageItems[" + i + "].rewardType");
            String gameIdResponse = js.get("pageItems[" + i + "].allowedGames[0].gameIds[0]");

            if (externalCampaignResponse.equals(rewardType) && gameIdResponse.equals(providerId)) {
                bonusName =
                        js.get("pageItems[" + i + "].bonusName").toString().replace("[", "").replace("]", "");

                System.out.println("BonusNameEl saved: " + bonusName);
                success = true;
                bonusActiveIdExists = true;
                break;
            }
        }
        if (!success) {
            System.out.println("No bonusName exist for providerId " + providerId);
            bonusActiveIdExists = false;
        }
    }

    // Works for array of object of bonusPrize
    @And("I copy the value of the bonusPrizeId from the field {string}")
    public void iCopyTheValueOfTheBonusPrizeIdFromTheField(String field) {
        boolean success = false;
        bonusActiveIdExists = false;

        bonusPrizeId = getJsonPath(response, field).replace("[", "").replace("]", "");
        if (!bonusPrizeId.isEmpty()) {
            success = true;
            System.out.println("BonusPrizeId saved: " + bonusPrizeId);
        }

        if (!success) {
            System.out.println("No bonusPrize exist for player: " + playerId);
            bonusActiveIdExists = false;
        }
    }

    @And("I copy the value of the OpapOnline bonusPrizeId from the field {string}")
    public void iCopyTheValueOfTheOpapOnlineBonusPrizeIdFromTheField(String field) {
        boolean success = false;
        opapOnlineBonusPrizeExists = false;

        opapOnlineBonusPrizeId = getJsonPath(response, field).replace("[", "").replace("]", "");
        if (!opapOnlineBonusPrizeId.isEmpty()) {
            success = true;
            System.out.println("OpapOnline BonusPrizeId saved: " + opapOnlineBonusPrizeId);
        }

        if (!success) {
            System.out.println("No OpapOnline bonusPrize exist for player: " + playerId);
            opapOnlineBonusPrizeExists = false;
        }
    }

    @And("I copy the bonusActiveId with field {string} in the response body")
    public void iVerifyTheBonusActiveIdWithFieldInTheResponseBody(String field) {
        JsonPath js = new JsonPath(response.asString());
        String actualId = js.get(field).toString();
        bonusActiveId = actualId;
        System.out.println("BonusActiveId saved: " + actualId);
    }

    @And("I change url resource of method {string} of service {string} with new bonusActiveId")
    public void iChangeUrlResourceOfMethodOfServiceWithNewBonusActiveId(
            String resourceName, String service) {
        String resourceValue = calculateEndpointUrl(service, resourceName);

        String bonusActiveIdlength = String.valueOf(bonusActiveId.length());
        resourceValue = resourceValue.replace("{{bonusActiveId}}", bonusActiveId);

        resourceValue =
                resourceValue.replaceAll(
                        "/bonuses/[0-9]{" + bonusActiveIdlength + "}",
                        "/bonuses/"
                                + bonusActiveId); // for retry if method has no /bonus-prizes doesn't work on retry
        // only. Maybe create new step for other Variable.
        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    @And("I change url resource of method {string} of service {string} with invalid bonusActiveId {string}")
    public void iChangeUrlResourceOfMethodOfServiceWithInvalidBonusActiveId(
            String resourceName, String service, String type) {
        String resourceValue = calculateEndpointUrl(service, resourceName);

        if (type.equals("numeric")) {
            String bonusActiveIdlength = String.valueOf(bonusActiveId.length());
            resourceValue = resourceValue.replace("{{bonusActiveId}}", "123456789");

            resourceValue =
                    resourceValue.replaceAll(
                            "/bonuses/[0-9]{" + bonusActiveIdlength + "}",
                            "/bonuses/"
                                    + "123456789"); // for retry if method has no /bonus-prizes doesn't work on retry
            // only. Maybe create new step for other Variable.
        } else if (type.equals("text")) {
            String bonusActiveIdlength = String.valueOf(bonusActiveId.length());
            resourceValue = resourceValue.replace("{{bonusActiveId}}", "test");

            resourceValue =
                    resourceValue.replaceAll(
                            "/bonuses/[0-9]{" + bonusActiveIdlength + "}",
                            "/bonuses/"
                                    + "test"); // for retry if method has no /bonus-prizes doesn't work on retry
            // only. Maybe create new step for other Variable.
            // Use "test" mode as default for safety reasons
        }

        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    @And("I change url resource of method {string} of service {string} with bonusName {string}")
    public void iChangeUrlResourceOfMethodOfServiceWithBonusName(
            String resourceName, String service, String lang) {
        String resourceValue = calculateEndpointUrl(service, resourceName);

        String bonusName = "";
        switch (lang) {
            case "valid":
                bonusName = bonusName;
                break;
            case "test":
                bonusName = "test";
                break;
            case "empty":
                bonusName = "";
                break;
            default:
                bonusName = "test";
                // Use "test" mode as default for safety reasons
        }

        String bonusNameLength = String.valueOf(bonusName.length());
        resourceValue = resourceValue.replace("{{bonusName}}", bonusNameLength);

        resourceValue =
                resourceValue.replaceAll(
                        "/name/[0-9]{" + bonusNameLength + "}",
                        "/name/"
                                + bonusName);

        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    @And("I verify the bonusPrizeId is the field {string} in the response body")
    public void iVerifyTheBonusPrizeIdIsTheFieldInTheResponseBody(String field) {
        JsonPath js = new JsonPath(response.asString());
        String actualId = js.get(field).toString();
        Assertions.assertEquals(bonusPrizeId, actualId);
    }

    @And("I verify the bonusActiveId is the field {string} in the response body")
    public void iVerifyTheBonusActiveIdIsTheFieldInTheResponseBody(String field) {
        JsonPath js = new JsonPath(response.asString());
        String actualId = js.get(field).toString();
        Assertions.assertEquals(bonusActiveId, actualId);
    }

    @Given("I create a PUT AdjustBonusPrizes payload with {}")
    public void iCreateAPUTAdjustBonusPrizesPayloadWith(int amount) {
        requestBody = bonusServiceData.adjustBonusPrizes(amount);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
    }
}
