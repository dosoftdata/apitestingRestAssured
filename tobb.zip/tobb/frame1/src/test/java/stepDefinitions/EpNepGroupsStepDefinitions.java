package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.AccessServiceData;
import apiResources.testDataBuild.WalletServiceData;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;
import apiResources.testDataBuild.WalletServiceData;

import static io.restassured.RestAssured.given;

public class EpNepGroupsStepDefinitions extends Utils {

    WalletServiceData walletServiceData = new WalletServiceData();
    AccessServiceData accessData = new AccessServiceData();

    @Then("I copy the values of the Payment Codes")
    public void i_copy_the_values_of_the_payment_codes() {

        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");
        Assertions.assertNotSame(count, 0);

        for (int i = 0; i < count; i++) {
            String paymentMethodId = js.get("paymentMethodId[" + i + "]");
            if (paymentMethodId.equalsIgnoreCase("PAYMENT_CODE_NON_EXCLUSIVE")) {
                paymentCodeNonExclusive = js.get("paymentCode[" + i + "]");
                System.out.println("Non Exclusive Payment Code saved: " + paymentCodeNonExclusive);
            } else if (paymentMethodId.equalsIgnoreCase("PAYMENT_CODE_EXCLUSIVE")) {
                paymentCodeExclusive = js.get("paymentCode[" + i + "]");
                System.out.println("Exclusive Payment Code saved: " + paymentCodeExclusive);
            }
        }
    }

    @When(
            "I create a Post DepositViaPayment payload for configured player with playerId {string} and {string} wallet")
    public void
    i_create_a_post_deposit_via_payment_payload_for_configured_player_with_player_id_and_wallet(
            String id, String wallet) {

        if (wallet.equalsIgnoreCase("Betting Wallet")) {
            requestBody = walletServiceData.postDepositViaPaymentWithId(id, "NonExclusive");
        } else if (wallet.equalsIgnoreCase("Lottery Wallet")) {
            requestBody = walletServiceData.postDepositViaPaymentWithId(id, "Exclusive");
        }

        String specification = "api_mainSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @When("I create a Post DepositViaPayment payload for {string} wallet")
    public void i_create_a_post_deposit_via_payment_payload_for_wallet(String wallet) {
        if (wallet.equalsIgnoreCase("Betting Wallet")) {
            requestBody = walletServiceData.postDepositViaPayment("NonExclusive");
        } else if (wallet.equalsIgnoreCase("Lottery Wallet")) {
            requestBody = walletServiceData.postDepositViaPayment("Exclusive");
        }

        String specification = "api_mainSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given(
            "I create a Post DepositViaPaymentCode payload with {string} {string} {int} {string} {string} {string}")
    public void i_create_a_post_deposit_via_payment_code_payload_with(
            String paymentMethodId,
            String paymentCode,
            int amount,
            String action,
            String operation,
            String paymentMethodType) {
        requestBody =
                walletServiceData.postDepositViaPaymentCode(
                        paymentMethodId, paymentCode, amount, action, operation, paymentMethodType);
        String specification = "api_mainSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given("I create a Post DepositViaBankAccount payload with {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
    public void i_create_a_post_deposit_via_bank_account_payload_with(
            String paymentMethodId,
            String paymentCode,
            String amount,
            String action,
            String operation,
            String paymentType,
            String paymentMethodType,
            String bankId,
            String pspId,
            String pspTargetId,
            String currency,
            String owner) {
        requestBody =
                walletServiceData.postDepositViaBankAccount(
                        paymentMethodId, paymentCode, amount, action, operation, paymentType, paymentMethodType, bankId, pspId, pspTargetId, currency, owner);
        String specification = "api_mainSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @When("I create a Post DepositViaCard payload with {string}")
    public void i_create_a_post_deposit_via_card_payload_with(String amount) {

        requestBody = walletServiceData.postDepositViaCard(amount);

        String specification = "specWithGameIdOrigin";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

//  @When("I create a Post DepositViaCard payload for ownerId equals to empty")
//  public void i_create_a_post_deposit_via_card_payload_OwnerId_Empty_with() {
//
//    requestBody = walletServiceData.postDepositCardOwnerIdEmpty();
//
//    String specification = "specWithGameIdOrigin";
//    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
//  }

//  @When("I create a Post DepositViaCard payload for amount equals to null")
//  public void i_create_a_post_deposit_via_card_payload_Amount_Null_with() {
//
//    requestBody = walletServiceData.postDepositAmountNull();
//
//    String specification = "specWithGameIdOrigin";
//    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
//  }

    @Given("I create a Post Checkout Torawallet payload with amount {string} {string} {string} {string} {string} {string} {string} {string}")
    public void i_create_a_post_checkout_torawallet_payload_with_amount(
            String amount,
            String card,
            String holderName,
            String cvv,
            String exp_month,
            String exp_year,
            String currency,
            String primaryKey) {

        requestBody =
                walletServiceData.setMasterCardDetails(
                        amount, card, holderName, cvv, exp_month, exp_year, currency, primaryKey);

        String specification = "api_checkoutToraWallet";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @When(
            "I create a PostWalletFunds payload with {string} {int} {string} {string} {string} {string} {string} {string} {string} {string} {string}")
    public void i_create_a_post_wallet_funds_payload_with(
            String accountId,
            Integer amount,
            String currency,
            String issued,
            String productId,
            String type,
            String description,
            String autocapture,
            String status,
            String captured,
            String batchId) {
        if (issued.equals("datenow")) {
            issued = calculateDateNowInSecondsToString();
        }
        requestBody =
                walletServiceData.PostWalletFunds(
                        accountId,
                        amount,
                        currency,
                        issued,
                        productId,
                        type,
                        description,
                        autocapture,
                        status,
                        captured,
                        batchId);

        String specification = "api_specWithGameId";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given("I create an AddUserToEpGroup payload")
    public void i_create_an_add_user_to_ep_group_payload() {
        requestBody = accessData.addUserToEpGroup();

        String specification = "api_mainSpec_mainHost";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given("I create an AddUserToFriendsAndFamilyGroup payload for Member Id mismatch")
    public void i_create_an_add_user_to_friends_family_group_payload_mismatch() {
        requestBody = accessData.addUserToFriendsAndFamilyGroupMismatch();

        String specification = "api_mainSpec_mainHost";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given("I create an AddUserToFriendsAndFamilyGroup payload")
    public void i_create_an_add_user_to_friends_family_group_payload() {
        requestBody = accessData.addUserToFriendsAndFamilyGroup();

        String specification = "api_mainSpec_mainHost";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given("I create an AddUserToNepGroup payload")
    public void i_create_an_add_user_to_nep_group_payload() {
        requestBody = accessData.addUserToNepGroup();

        String specification = "api_mainSpec_mainHost";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @When("I create payload with EpGroup {string} and NepGroup {string}")
    public void i_create_payload_with_ep_group_and_nep_group(String epGroup, String nepGroup) {
        requestBody = accessData.addUserToGroup(epGroup, nepGroup);

        String specification = "cc_csrftokenSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given(
            "I create a Post ManualAdjustment payload with {string} {string} {string} {string} {string} {string} for {string}")
    public void i_create_a_post_manual_adjustment_payload_with_for(
            String transactionType,
            String transactionSubType,
            String productId,
            String operation,
            String amount,
            String transactionBetweenWallets,
            String wallet) {
        requestBody =
                walletServiceData.manualAdjustWallet(
                        transactionType,
                        transactionSubType,
                        productId,
                        operation,
                        amount,
                        transactionBetweenWallets,
                        wallet);

        String specification = "cc_csrftokenSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given("I change url resource of method {string} of service {string} with new {string}")
    public void i_change_url_resource_of_method_of_service_with_new(
            String resourceName, String service, String idType) {
        String resourceValue = calculateEndpointUrl(service, resourceName);

        if (idType.equalsIgnoreCase("accessGroupIdExclusive")) {
            resourceValue = resourceValue.replace("{{exclusiveGamesGroupId}}", accessGroupIdExclusive);
            int length = accessGroupIdExclusive.length();
            String regexPattern = "/accessgroups/\\d{" + length + "}/";
            resourceValue =
                    resourceValue.replaceAll(
                            regexPattern, "/accessgroups/" + accessGroupIdExclusive + "/"); // for retry

        } else if (idType.equalsIgnoreCase("accessGroupIdNonExclusive")) {

            resourceValue = resourceValue.replace("{{exclusiveGamesGroupId}}", accessGroupIdNonExclusive);
            int length = accessGroupIdNonExclusive.length();
            String regexPattern = "/accessgroups/\\d{" + length + "}/";
            resourceValue =
                    resourceValue.replaceAll(
                            regexPattern, "/accessgroups/" + accessGroupIdNonExclusive + "/"); // for retry
        } else if (idType.equalsIgnoreCase("friendsAndFamilyGroupId")) {

            resourceValue = resourceValue.replace("{{exclusiveGamesGroupId}}", friendsAndFamilyGroupId);
            int length = friendsAndFamilyGroupId.length();
            String regexPattern = "/accessgroups/\\d{" + length + "}/";
            resourceValue =
                    resourceValue.replaceAll(
                            regexPattern, "/accessgroups/" + friendsAndFamilyGroupId + "/"); // for retry
        }

        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    @Then("I verify the response and copy the access group Ids")
    public void i_verify_the_response_and_copy_the_access_group_ids() {
        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");

        for (var i = 0; i < count; i++) {
            String name = js.get("name[" + i + "]");
            Integer memberType = js.get("memberType[" + i + "]");
            String updatedByUserId = js.get("updatedByUserId[" + i + "]");
            String description = js.get("description[" + i + "]");

            if (name.equalsIgnoreCase("NON_EXCLUSIVE_GAMES_ONLY")) {
                Assertions.assertEquals(1, memberType);
                Assertions.assertEquals("0-", updatedByUserId);
                Assertions.assertEquals("Access group for NON EXCLUSIVE GAMES only", description);
                Assertions.assertEquals("NON_EXCLUSIVE_GAMES_ONLY", name);

                accessGroupIdNonExclusive = js.get("accessGroupId[" + i + "]");
                System.out.println("accessGroupIdNonExclusive saved: " + accessGroupIdNonExclusive);

            } else if (name.equalsIgnoreCase("EXCLUSIVE_GAMES_ONLY")) {

                Assertions.assertEquals(1, memberType);
                Assertions.assertEquals("0-", updatedByUserId);
                Assertions.assertEquals("Access group for EXCLUSIVE GAMES only", description);
                Assertions.assertEquals("EXCLUSIVE_GAMES_ONLY", name);

                accessGroupIdExclusive = js.get("accessGroupId[" + i + "]");
                System.out.println("accessGroupIdExclusive saved: " + accessGroupIdExclusive);
            } else if (name.equalsIgnoreCase("FRIENDS_AND_FAMILY")) {

                Assertions.assertEquals(1, memberType);
                Assertions.assertEquals("0-", updatedByUserId);
                Assertions.assertEquals("Access group for FRIENDS & FAMILY", description);
                Assertions.assertEquals("FRIENDS_AND_FAMILY", name);

                friendsAndFamilyGroupId = js.get("accessGroupId[" + i + "]");
                System.out.println("friendsAndFamilyGroupId saved: " + friendsAndFamilyGroupId);
            }
        }
    }

    @Then("I copy and verify the member Id")
    public void i_copy_and_verify_the_member_id() {
        memberIdEpNep = getJsonPath(response, "memberId");
        Assertions.assertEquals(memberIdEpNep, "1-" + playerId);

        System.out.println("Player Id saved: " + memberIdEpNep);
    }

    @Then("I verify the the amount for {string}")
    public void i_verify_the_the_amount_for(String depositAmount) {
        String deposit;

        if (depositAmount.equalsIgnoreCase("nonExclWalletUnspentDeposits")) {
            deposit = nonExclWalletUnspentDeposits;
            Assertions.assertEquals(deposit, getJsonPath(response, "amount[0]"));
        } else if (depositAmount.equalsIgnoreCase("exclWalletUnspentDeposits")) {
            deposit = exclWalletUnspentDeposits;
            Assertions.assertEquals(deposit, getJsonPath(response, "amount"));
        }
    }

    @Then("I verify the response for Role Members for {string}")
    public void i_verify_the_response_for_role_members_for(String role) {
        String paymentCodeExclusive = Utils.accessGroupIdExclusive;
        String paymentCodeNonExclusive = Utils.accessGroupIdNonExclusive;
        System.out.println("exclusive code: " + paymentCodeExclusive);
        System.out.println("non exclusive code: " + paymentCodeNonExclusive);

        String stringResponse = response.asString();
        System.out.println(stringResponse);

        if (role.equalsIgnoreCase("Exclusive")) {
            if (stringResponse.contains("\"accessGroupId\":\"" + paymentCodeExclusive + "\"")) {
                Assertions.assertTrue(true);
            } else {
                Assertions.fail();
                System.out.println("Assertion Fail 1");
            }

            if (stringResponse.contains("\"accessGroupId\":\"" + paymentCodeNonExclusive + "\"")) {
                Assertions.fail();
                System.out.println("Assertion Fail 2");
            } else {
                Assertions.assertTrue(true);
            }

        } else if (role.equalsIgnoreCase("NonExclusive")) {
            if (stringResponse.contains("\"accessGroupId\":\"" + paymentCodeNonExclusive + "\"")) {
                Assertions.assertTrue(true);
            } else {
                Assertions.fail();
                System.out.println("Assertion Fail 3");
            }

            if (stringResponse.contains("\"accessGroupId\":\"" + paymentCodeExclusive + "\"")) {
                Assertions.fail();
                System.out.println("Assertion Fail 4");
            } else {
                Assertions.assertTrue(true);
            }
        } else if (role.equalsIgnoreCase("NotInExclusiveAndNonExclusive")) {
            if (!stringResponse.contains("\"accessGroupId\":\"" + paymentCodeExclusive + "\"")
                    && !stringResponse.contains("\"accessGroupId\":\"" + paymentCodeNonExclusive + "\"")) {
                Assertions.assertTrue(true);
            } else {
                Assertions.fail();
                System.out.println("Assertion Fail 5");
            }
        }
    }

    @Then("I verify the deposit paymentId via card")
    public void i_verify_the_deposit_paymentId_via_card() {
        JsonPath js = new JsonPath(response.asString());
        String actualId = js.get("paymentId");
        Assertions.assertEquals(paymentIdViaPaymentCard, actualId);
    }

    @Then("I verify the deposit paymentId via paymentCode")
    public void i_verify_the_deposit_paymentId_via_payment_code() {
        JsonPath js = new JsonPath(response.asString());
        String actualId = js.get("paymentId");
        Assertions.assertEquals(paymentId, actualId);
    }

    @Then("I copy the value of the paymentId for deposit via card")
    public void i_copy_the_value_of_the_payment_id_for_deposit_via_card() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        paymentIdViaPaymentCard = jsonPathEvaluator.get("paymentId");
        System.out.println("Payment Id via deposit card is saved: " + paymentIdViaPaymentCard);
    }

    @When("I create a CommitCardDeposit to Tora Put payload")
    public void i_create_a_commit_card_deposit_to_tora_put_payload() {
        requestBody = walletServiceData.commitCardDepositToTora();

        String specification = "specWithGameId";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @When(
            "I create a CommitWithdrawal to Tora Put payload with {int} {string} {booleanValue} {string}")
    public void i_create_a_commit_withdrawal_to_tora_put_payload(
            int amount, String currency, boolean forceReview, String auditData) {
        requestBody =
                walletServiceData.commitWithdrawalToTora(amount, currency, forceReview, auditData);

        String specification = "api_mainSpec_mainHost";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Then("I verify the status for Commit Card Deposit To Tora response")
    public void i_verify_the_status_for_commit_card_deposit_to_tora_response() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        boolean success = true;
        if (environment.equals("UAT") || environment.equals("Preprod")) {
            success =
                    status.equalsIgnoreCase("APPROVED")
                            || status.equalsIgnoreCase("VERIFIED")
                            || status.equalsIgnoreCase("REJECTED");
        }
        if (!success) {
            Assertions.fail("Status is still PENDING");
        }
    }

    @Then(
            "I verify the response for GetWalletBalance for {float} {float} {float} {float} {float} for {string}")
    public void i_verify_the_response_for_get_wallet_balance_for(
            Float balance,
            Float buyingPower,
            Float nonWithdrawableBalance,
            Float reservedBalance,
            Float withdrawableBalance,
            String wallet) {
        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");
        boolean success = false;

        Assertions.assertTrue(count != 0);

        if (wallet.equalsIgnoreCase("Lottery Wallet")) {
            for (var i = 0; i < count; i++) {
                float actualBalance = js.get("balance[" + i + "]");
                float actualBuyingPower = js.get("buyingPower[" + i + "]");
                float actualNonWithdrawableBalance = js.get("nonWithdrawableBalance[" + i + "]");
                float actualReservedBalance = js.get("reservedBalance[" + i + "]");
                float actualWithdrawableBalance = js.get("withdrawableBalance[" + i + "]");
                String actualAccountType = js.get("accountType[" + i + "]");
                String actualAccountNumber = js.get("accountNumber[" + i + "]");
                String id = js.get("id[" + i + "]");

                if (actualAccountType.equalsIgnoreCase("AT_MAIN")
                        && actualAccountNumber.equalsIgnoreCase("1")
                        && id.equalsIgnoreCase("AT_MAIN-1")) {
                    Assertions.assertEquals(balance, actualBalance);
                    Assertions.assertEquals(buyingPower, actualBuyingPower);
                    Assertions.assertEquals(nonWithdrawableBalance, actualNonWithdrawableBalance);
                    Assertions.assertEquals(reservedBalance, actualReservedBalance);
                    Assertions.assertEquals(withdrawableBalance, actualWithdrawableBalance);

                    exclWalletMainBalance = Float.toString(js.get("balance[" + i + "]"));
                    exclWalletReservedBalance = Float.toString(js.get("reservedBalance[" + i + "]"));
                    exclWalletWithdrawableBalance = Float.toString(js.get("withdrawableBalance[" + i + "]"));
                    exclWalletUnspentDeposits = Float.toString(js.get("nonWithdrawableBalance[" + i + "]"));
                    exclWalletPlayBalance = Float.toString(js.get("buyingPower[" + i + "]"));

                    System.out.println("exclWalletMainBalance saved: " + exclWalletMainBalance);
                    System.out.println("exclWalletReservedBalance saved: " + exclWalletReservedBalance);
                    System.out.println(
                            "exclWalletWithdrawableBalance saved: " + exclWalletWithdrawableBalance);
                    System.out.println("exclWalletUnspentDeposits saved: " + exclWalletUnspentDeposits);
                    System.out.println("exclWalletPlayBalance saved: " + exclWalletPlayBalance);

                    success = true;
                }
            }
            if (!success) {
                Assertions.fail("Lottery wallet not found");
            }
        } else if (wallet.equalsIgnoreCase("Betting Wallet")) {

            for (var i = 0; i < count; i++) {
                float actualBalance = js.get("balance[" + i + "]");
                float actualBuyingPower = js.get("buyingPower[" + i + "]");
                float actualNonWithdrawableBalance = js.get("nonWithdrawableBalance[" + i + "]");
                float actualReservedBalance = js.get("reservedBalance[" + i + "]");
                float actualWithdrawableBalance = js.get("withdrawableBalance[" + i + "]");
                String actualAccountType = js.get("accountType[" + i + "]");
                String actualAccountNumber = js.get("accountNumber[" + i + "]");
                String id = js.get("id[" + i + "]");

                if (actualAccountType.equalsIgnoreCase("AT_MAIN")
                        && actualAccountNumber.equalsIgnoreCase("2")
                        && id.equalsIgnoreCase("AT_MAIN-2")) {
                    Assertions.assertEquals(balance, actualBalance);
                    Assertions.assertEquals(buyingPower, actualBuyingPower);
                    Assertions.assertEquals(nonWithdrawableBalance, actualNonWithdrawableBalance);
                    Assertions.assertEquals(reservedBalance, actualReservedBalance);
                    Assertions.assertEquals(withdrawableBalance, actualWithdrawableBalance);

                    nonExclWalletMainBalance = Float.toString(js.get("balance[" + i + "]"));
                    nonExclWalletReservedBalance = Float.toString(js.get("reservedBalance[" + i + "]"));
                    nonExclWalletWithdrawableBalance =
                            Float.toString(js.get("withdrawableBalance[" + i + "]"));
                    nonExclWalletUnspentDeposits =
                            Float.toString(js.get("nonWithdrawableBalance[" + i + "]"));
                    nonExclWalletPlayBalance = Float.toString(js.get("buyingPower[" + i + "]"));

                    System.out.println("nonExclWalletMainBalance saved: " + nonExclWalletMainBalance);
                    System.out.println("nonExclWalletReservedBalance saved: " + nonExclWalletReservedBalance);
                    System.out.println(
                            "nonExclWalletWithdrawableBalance saved: " + nonExclWalletWithdrawableBalance);
                    System.out.println("nonExclWalletUnspentDeposits saved: " + nonExclWalletUnspentDeposits);
                    System.out.println("nonExclWalletPlayBalance saved: " + nonExclWalletPlayBalance);

                    success = true;
                }
            }
            if (!success) {
                Assertions.fail("Betting wallet not found");
            }
        } else if (wallet.equalsIgnoreCase("Bonus Wallet")) {
            for (var i = 0; i < count; i++) {
                float actualBalance = js.get("balance[" + i + "]");
                float actualBuyingPower = js.get("buyingPower[" + i + "]");
                float actualNonWithdrawableBalance = js.get("nonWithdrawableBalance[" + i + "]");
                float actualReservedBalance = js.get("reservedBalance[" + i + "]");
                float actualWithdrawableBalance = js.get("withdrawableBalance[" + i + "]");
                String actualAccountType = js.get("accountType[" + i + "]");
                String actualAccountNumber = js.get("accountNumber[" + i + "]");
                String id = js.get("id[" + i + "]");

                if (actualAccountType.equalsIgnoreCase("AT_BONUS_PRIZE")
                        && actualAccountNumber.equals(bonusPrizeId)) {
                    Assertions.assertEquals(id, "AT_BONUS_PRIZE-" + bonusPrizeId);
                    Assertions.assertEquals(balance, actualBalance);
                    Assertions.assertEquals(buyingPower, actualBuyingPower);
                    Assertions.assertEquals(nonWithdrawableBalance, actualNonWithdrawableBalance);
                    Assertions.assertEquals(reservedBalance, actualReservedBalance);
                    Assertions.assertEquals(withdrawableBalance, actualWithdrawableBalance);
                    success = true;
                }
            }
            if (!success) {
                Assertions.fail("Bonus wallet AT_BONUS_PRIZE-" + bonusPrizeId + " not found");
            }
        }
        if (!wallet.equalsIgnoreCase("Lottery Wallet")
                && !wallet.equalsIgnoreCase("Betting Wallet")
                && !wallet.equalsIgnoreCase("Bonus Wallet")) {
            Assertions.fail("Please enter a valid wallet: Lottery Wallet, Betting Wallet, Bonus Wallet");
        }
    }

    @Then(
            "I verify the response for GetAPIWalletBalance for {float} {float} for {string}")
    public void i_verify_the_response_for_get_api_wallet_balance_for(
            Float balance,
            Float reservedBalance,
            String accountId) {
        JsonPath js = new JsonPath(response.asString());
        int count = js.getList("$").size();
        boolean success = false;

        Assertions.assertTrue(count != 0);

        for (var i = 0; i < count; i++) {
            String actualAccountId = js.get("[" + i + "].accountId");
            float actualBalance = js.getFloat("[" + i + "].balance");
            float actualReservedBalance = js.getFloat("[" + i + "].reservedBalance");

            if (accountId.equalsIgnoreCase(actualAccountId) && accountId.equalsIgnoreCase("AT_MAIN-1")) {

                Assertions.assertEquals(balance, actualBalance);
                Assertions.assertEquals(reservedBalance, actualReservedBalance);

                System.out.println("exclWalletMainBalance saved: " + exclWalletMainBalance);
                System.out.println("exclWalletMainReservedBalance saved: " + exclWalletReservedBalance);

                success = true;
            } else if (accountId.equalsIgnoreCase(actualAccountId) && accountId.equalsIgnoreCase("AT_MAIN-2")) {

                Assertions.assertEquals(balance, actualBalance);
                Assertions.assertEquals(reservedBalance, actualReservedBalance);

                System.out.println("nonExclWalletMainBalance saved: " + actualBalance);
                System.out.println("nonExclWalletMainReservedBalance saved: " + actualReservedBalance);

                success = true;
            } else if (accountId.equalsIgnoreCase("AT_BONUS_PRIZE") && actualAccountId.equalsIgnoreCase("AT_BONUS_PRIZE-" + bonusPrizeId)) {

                Assertions.assertEquals(balance, actualBalance);
                Assertions.assertEquals(reservedBalance, actualReservedBalance);

                System.out.println("BonusBalance saved: " + actualBalance);
                System.out.println("BonusReservedBalance saved: " + actualReservedBalance);

                success = true;

            } else if (accountId.equalsIgnoreCase("AT_OPAPONLINE_PRIZE") && actualAccountId.equalsIgnoreCase("AT_BONUS_PRIZE-" + opapOnlineBonusPrizeId)) {

                Assertions.assertEquals(balance, actualBalance);
                Assertions.assertEquals(reservedBalance, actualReservedBalance);

                System.out.println("OpapOnlineWalletBonusBalance saved: " + actualBalance);
                System.out.println("OpapOnlineWalletBonusReservedBalance saved: " + actualReservedBalance);

                success = true;

            }

        }
        if (!success && accountId.equalsIgnoreCase("AT_MAIN-1")) {
            Assertions.fail("Lottery wallet not found");
        } else if (!success && accountId.equalsIgnoreCase("AT_MAIN-2")) {
            Assertions.fail("Betting wallet not found");
        } else if (!success && accountId.equalsIgnoreCase("AT_BONUS")) {
            Assertions.fail("Bonus wallet AT_BONUS_PRIZE-" + bonusPrizeId + " not found");
        }
    }
}
