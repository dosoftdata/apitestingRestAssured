package stepDefinitions;

import apiResources.Utils;
import apiResources.testDataBuild.mockData.DrillHostData;
import io.cucumber.java.en.*;
import io.restassured.path.json.JsonPath;
import org.junit.jupiter.api.Assertions;

import static io.restassured.RestAssured.given;

public class DrillHostStepDefinitions extends Utils {

  DrillHostData drillHostData = new DrillHostData();

  @Given("I create a DrillHost Payload with {string} and {string}")
  public void iCreateADrillHostPayloadWithAnd(String queryType, String query) {
    drillOrBridge = true;
    requestBody = drillHostData.addDrillHostData(queryType, query);
    String specification = "emptySpec";
    res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
  }

  @And("I copy the value of the contractId from the response")
  public void iCopyTheValueOfTheContractIdFromTheResponse() {
    JsonPath jsonPathEvaluator = response.jsonPath();
    drillContractId = jsonPathEvaluator.get("rows[0].ID");
    System.out.println("Drill Contract Id saved: " + drillContractId);
  }
}
