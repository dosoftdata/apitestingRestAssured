package stepDefinitions;

import apiResources.DataContext;
import apiResources.testDataBuild.*;

import apiResources.testDataBuild.AdminServiceData;
import io.cucumber.java.ParameterType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import apiResources.Utils;
import io.restassured.http.Cookies;
import io.restassured.path.json.JsonPath;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static apiResources.endpoints.CommunicationServiceResources.smsId;
import static io.restassured.RestAssured.given;
import static org.awaitility.Awaitility.await;

/**
 * CommonStepDefinitions include the most common steps used and can be dynamically reused in many
 * cases.
 */
public class CommonStepDefinitions extends Utils {

    AccessServiceData accessServiceData = new AccessServiceData();
    AdminServiceData adminServiceData = new AdminServiceData();
    WalletServiceData walletServiceData = new WalletServiceData();
    PlayerServiceData playerServiceData = new PlayerServiceData();

    /**
     * A custom parameter for cucumber. Can be used instead of bool.
     *
     * @param value the value
     * @return the boolean
     */
    @ParameterType(value = "true|True|TRUE|false|False|FALSE")
    public boolean booleanValue(String value) {
        return Boolean.parseBoolean(value);
    }

    /**
     * Creates CookieStore for cookie logging and sets up http client. It is used in Hooks.
     */
    @Given("I setup Cookies")
    public void iSetupCookies() {
        cookieSetup();
    }

    /**
     * Setup game id for the following headers and scenarios. The game id should already exist in Enum
     * file xGameId.
     *
     * @param xGameId the x game (JOKER, SPORTSBOOK)
     */
    @Given("I setup gameId header to {string}")
    public void iSetupGameId(String xGameId) {
        setGameId(xGameId);
    }

    /**
     * Login as a new registered user or a configured one.
     *
     * @param typeOfUser the type of user (newPlayerWeb, configuredPlayerWeb, configuredPlayerCc)
     */
    @Given("I login as a {string} user")
    public void iLoginAsAUser(String typeOfUser) {
        if (typeOfUser.equals("newPlayerWeb")) {
            username = registeredUsername;
            password = registeredPassword;
            loginWebFlow();
        } else if (typeOfUser.equals("configuredPlayerWeb")) {
            username = configUsername;
            password = configPassword;
            loginWebFlow();
        } else if (typeOfUser.equals("testPlayerWeb")) {
            username = registeredUsername;
            password = "test";
            loginNewNegative();
        } else if (typeOfUser.equals("configuredPlayerCc")) {
            loginBackOffice();
        } else if (typeOfUser.equals("testPlayerCc")) {
            isTestLoginCC = true;
            loginBackOffice();
        } else {
            System.out.println("Wrong type of user: " + typeOfUser);
        }
    }

    /**
     * Login as an api user. Gets Token for /api calls.
     */
    @Given("I login as an Api user")
    public void iLoginAsAnApiUser() {
        loginAPI();
    }

    /**
     * Login as an intralot user. Gets Token for /api calls but for intralot authorization.
     */
    @Given("I login as an Intralot user")
    public void iLoginAsAnIntralotUser() {
        loginIntralotToken();
    }

    /**
     * Creates a get header with the given spec. All accepted values can be found in
     * requestSpecWithHeadersSpecification method.
     *
     * @param spec the spec (mainSpec, specWithGameId e.t.c)
     */
    @Given("I create a Get {string} header")
    public void iCreateAGetHeader(String spec) {
        res = given().spec(requestSpecWithHeadersSpecification(spec));
    }

    /**
     * Create a get header with query params. More than one param can be used with commas
     *
     * @param specification the specification (mainSpec, specWithGameId e.t.c)
     * @param keys          the keys
     * @param values        the values . For playerId we have the value changeit which changes to registered
     *                      User ID. For dates datenow can be used for today's date.
     */
    @Given("I create a Get {string} header with query params {string} {string}")
    public void iCreateAGetHeaderWithParams(String specification, String keys, String values) {
        if (values.contains("changeit") || values.contains("datenow")) {
            values = calculateNewParamValues(keys, values);
        } else if (values.contains("friendsAndFamilyGroupId")) {
            values = calculateParamValues(keys, values);
        } else if (values.contains("GrandPrize")) {
            values = calculateGrandPrizeValues(keys, values);
        }
        split2StringsAndAddToDict(keys, values);
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification(specification))
                        .queryParams(endPointParams);
    }

    /**
     * Makes a call to specific method of specific resource and service. Retry Mechanism and Login
     * mechanism are inside here.
     *
     * @param method     the method (GET,PUT,POST,DEL)
     * @param resource   the resource (GetPlayerLevels,GetGetUserInfo e.t.c)
     * @param apiService the api service (AccessService,WalletService)
     */
    @When("I make a {string} call to {string} to service {string}")
    public void i_make_a_call_to(String method, String resource, String apiService) {
        service = apiService;
        endpointUrl = calculateEndpointUrl(apiService, resource);
        retryResource = resource;

        if (method.equalsIgnoreCase("POST")) {
            response = res.when().post(endpointUrl);
        } else if (method.equalsIgnoreCase("GET")) {
            response = res.when().get(endpointUrl);
        } else if (method.equalsIgnoreCase("PUT")) {
            response = res.when().put(endpointUrl);
        } else if (method.equalsIgnoreCase("DEL")) {
            response = res.when().delete(endpointUrl);
        } else {
            System.out.println("Method" + method + "not supported yet");
            return;
        }
        Integer statusCode = response.getStatusCode();
        // helper prints
        System.out.println(statusCode);
        System.out.println(response.asPrettyString());

        genericRetryMechanism(resource, method, statusCode);
        if (!overrideRetryByGherkin) {
            populateRetryMechanism(resource);
        }
        overrideRetryByGherkin = false;

        if (readyForRetry) {
            customRetryMechanism(
                    method,
                    statusCode,
                    arrayName,
                    customMaxRetries,
                    delayInSeconds,
                    retryStatusCode,
                    responseField,
                    responseFieldValues);
        }
        saveToken();
    }

    /**
     * The api call is successful with specific status code.
     *
     * @param code the code (200,201,451)
     */
    @Then("the API call is successful with status code {int}")
    public void the_api_call_is_successful_with_status_code(int code) {
        Assertions.assertEquals(
                code,
                response.getStatusCode(),
                "Actual status Code: " + response.getStatusCode() + " is not what it is expected: " + code);
    }

    /**
     * The api call fails with specific status code.
     *
     * @param code the code (400,401,403,404)
     */
    @Then("the API call fails with status code {int}")
    public void the_api_call_fails_with_status_code(int code) {
        Assertions.assertEquals(
                code,
                response.getStatusCode(),
                "Actual status Code: " + response.getStatusCode() + " is not what it is expected: " + code);
    }

    /**
     * Verifies the value in response. It is used only if the response is one plain object (and not an
     * array).
     *
     * @param keyValue      the key value
     * @param expectedValue the expected value
     */
    @Then("the {string} in response body is {string}")
    public void the_in_response_body_is(String keyValue, String expectedValue) {
        Assertions.assertEquals(expectedValue, getJsonPath(response, keyValue));
    }

    /**
     * Verifies the value is not null. It is used only if the response is one plain object (and not an
     * array).
     *
     * @param keyValue the key value
     */
    @Then("the {string} in response body has value not null")
    public void the_in_response_body_has_value_not_null(String keyValue) {
        Assertions.assertNotNull(getJsonPath(response, keyValue));
    }

    /**
     * Verifies the value is null. It is used only if the response is one plain object (and not an
     * array).
     *
     * @param keyValue the key value
     */
    @Then("the {string} in response body has value null")
    public void the_in_response_body_has_value_null(String keyValue) {
        Assertions.assertNull(response.jsonPath().get(keyValue), keyValue);
    }

    /**
     * Verifies the number of objects in a nameless array. Response must be an array.
     *
     * @param num the num
     */
    @Then("the number of results in a nameless array of objects is {int}")
    public void the_number_of_results_in_a_nameless_array_of_objects_is(Integer num) {
        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");
        Assertions.assertEquals(num, count);
    }

    /**
     * Verifies the number of objects in a nameless array are > @param. Response must be an array.
     *
     * @param num the number to compare
     */
    @Then("the number of results in a nameless array of objects are greater than {int}")
    public void the_number_of_results_in_a_nameless_array_of_objects_are_greater_than(Integer num) {
        JsonPath js = new JsonPath(response.asString());
        boolean success = false;
        int count = js.getInt("js.size()");
        if (count > num) {
            success = true;
        }
        Assertions.assertTrue(success);
    }

    /**
     * Verifies that the property in a specific array and index has a specific value.
     *
     * @param property       the property
     * @param arrayWithIndex the array with index
     * @param propertyValue  the property value
     */
    @Then("the property {string} in response body array with index {string} has value {string}")
    public void theInResponseArrayBodyInIndexIs(
            String property, String arrayWithIndex, String propertyValue) {

        if ((property.equals("userId")
                || property.equals("updatedByUserId")
                || property.equals("memberId"))
                && propertyValue.equals("newPlayerWeb")) {
            propertyValue = "1-" + playerId;
        }

        if (property.equals("accessGroupId") && propertyValue.equals("fullAccountAccessGroupId")) {
            propertyValue = fullAccountAccessGroupId;
        }

        if (propertyValue.equals("bonusActiveId")) {
            propertyValue = bonusActiveId;
        }

        if (propertyValue.equals("bonusPrizeId")) {
            propertyValue = bonusPrizeId;
        }

        JsonPath jsonPathEvaluator = response.jsonPath();
        String actualValue =
                jsonPathEvaluator
                        .get(arrayWithIndex + "." + property)
                        .toString()
                        .replace("[", "")
                        .replace("]", "");

        if (!propertyValue.equals("null")) {
            Assertions.assertEquals(
                    propertyValue,
                    actualValue,
                    "Expected property value "
                            + propertyValue
                            + " is not equal with actual value "
                            + actualValue);
        }
        // TODO: improve..
        else {
            Assertions.assertNull(actualValue);
        }
    }

    /**
     * Verifies that the property in a specific array and index does not have a specific value.
     *
     * @param property       the property
     * @param arrayWithIndex the array with index
     * @param propertyValue  the property value
     */
    @Then(
            "the property {string} in response body array with index {string} does not have value {string}")
    public void theInResponseArrayBodyInIndexIsNot(
            String property, String arrayWithIndex, String propertyValue) {

        if ((property.equals("userId")
                || property.equals("updatedByUserId")
                || property.equals("memberId"))
                && propertyValue.equals("newPlayerWeb")) {
            propertyValue = "1-" + playerId;
        }

        if (property.equals("accessGroupId") && propertyValue.equals("fullAccountAccessGroupId")) {
            propertyValue = fullAccountAccessGroupId;
        }

        if (propertyValue.equals("bonusActiveId")) {
            propertyValue = bonusActiveId;
        }

        if (propertyValue.equals("bonusPrizeId")) {
            propertyValue = bonusPrizeId;
        }

        JsonPath jsonPathEvaluator = response.jsonPath();
        String actualValue =
                jsonPathEvaluator
                        .get(arrayWithIndex + "." + property)
                        .toString()
                        .replace("[", "")
                        .replace("]", "");

        if (!propertyValue.equals("null")) {
            Assertions.assertNotEquals(
                    propertyValue,
                    actualValue,
                    "Expected property value "
                            + propertyValue
                            + " is equal with actual value "
                            + actualValue);
        }
        // TODO: improve..
        else {
            Assertions.assertNull(actualValue);
        }
    }

    /**
     * Verifies that the property in a specific array and index contains a specific string value.
     *
     * @param property       the property
     * @param arrayWithIndex the array with index
     * @param propertyValue  the property value
     */
    @Then("the property {string} in response body array with index {string} contains value {string}")
    public void theInResponseArrayBodyInIndexContains(
            String property, String arrayWithIndex, String propertyValue) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        String actualValue =
                jsonPathEvaluator
                        .get(arrayWithIndex + "." + property)
                        .toString()
                        .replace("[", "")
                        .replace("]", "");

        Assertions.assertTrue(
                actualValue.contains(propertyValue),
                "Actual Value: " + actualValue + " does not contain expected value " + propertyValue);
    }

    /**
     * Verifies that the property in a specific array and index contains either of the values passed
     * in string with commas.
     *
     * @param property       the property
     * @param arrayWithIndex the array with index
     * @param propertyValues one of the values that are acceptable with ||
     */
    @Then(
            "the property {string} in response body array with index {string} contains either of the values {string}")
    public void theInResponseArrayBodyInIndexContainsEither(
            String property, String arrayWithIndex, String propertyValues) {
        JsonPath js = new JsonPath(response.asString());
        String[] propertyValueList = propertyValues.split(",");
        boolean success = false;

        String actualValue =
                js.get(arrayWithIndex + "." + property).toString().replace("[", "").replace("]", "");

        for (String s : propertyValueList) {
            if (actualValue.contains(s)) {
                success = true;
                break;
            }
        }
        if (!success) {
            Assertions.fail("Actual Value: " + actualValue + " does not contain expected value");
        }
    }

    /**
     * Verifies the number of objects in an array with the name specified. Response must be an array.
     *
     * @param array        the array
     * @param expectedSize the expected size
     */
    @Given("the number of results in the first nested array {string} is {int}")
    public void the_number_of_results_in_the_first_nested_array_is(String array, int expectedSize) {
        JsonPath js = new JsonPath(response.asString());
        int actualSize = js.getInt(array + ".size()");
        Assertions.assertEquals(expectedSize, actualSize);
    }

    /**
     * Verifies the number of objects in a specified array is greater than a specific number.
     *
     * @param array   the array
     * @param minSize the min size
     */
    @Given("the number of results in the array {string} is greater than {int}")
    public void the_number_of_results_in_the_array_is_greater_than(String array, int minSize) {
        JsonPath js = new JsonPath(response.asString());
        boolean success = false;
        int actualSize = js.getInt(array + ".size()");
        if (actualSize > minSize) {
            success = true;
        }
        Assertions.assertTrue(success);
    }

    /**
     * Change url resource with new player id. (just registered in the flow) If isMeEnabledInWeb=true
     * it changes with the /me
     *
     * @param resourceName the resource name
     * @param service      the service
     */
    @Then("I change url resource of method {string} of service {string} with new playerId")
    public void iChangeUrlResourceWithNewPlayerId(String resourceName, String service) {

        String resourceValue = calculateEndpointUrl(service, resourceName);
        String replaceRegex = "[0-9]{9}";

        System.out.println("nonNumericPlayerId: " + nonNumericPlayerId);

        if (nonNumericPlayerId != null
                && (!nonNumericPlayerId.isEmpty() || !nonNumericPlayerId.isBlank())) {
            replaceRegex = nonNumericPlayerId;
        }
        System.out.println("Replace regex value is: " + replaceRegex);

        if (resourceValue.contains("web")
                && isMeEnabledInWeb
                && !resourceName.equals("MSISDNRegister")) {
            resourceValue = resourceValue.replace("{{playerId}}", "me");
            resourceValue = resourceValue.replaceAll(replaceRegex, "me");
            setResourceByService(service, resourceName, resourceValue);
        } else {
            resourceValue = resourceValue.replace("{{playerId}}", playerId);
            resourceValue = resourceValue.replaceAll(replaceRegex, playerId); // for retry
            setResourceByService(service, resourceName, resourceValue);
        }
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    /**
     * Change url resource with invalid format player id. 1-playerId is replaced with the playerId
     *
     * @param resourceName the resource name
     * @param service      the service
     */
    @Then("I change url resource of method {string} of service {string} with invalid playerId")
    public void iChangeUrlResourceWithInvalidPlayerId(String resourceName, String service) {

        String resourceValue = calculateEndpointUrl(service, resourceName);

        int playerIdLength = playerId.length();
        nonNumericPlayerId = "";

        if (playerIdLength < 9 && previousPlayerIdLength != 0) { // 3 <9
            playerIdLength = previousPlayerIdLength;
        }

        if (playerId.matches("[A-Za-z]+")) {
            nonNumericPlayerId = playerId;
        }
        System.out.println("NonNumericPlayerId value is:" + nonNumericPlayerId);

        resourceValue = resourceValue.replace("1-{{playerId}}", playerId);
        resourceValue = resourceValue.replaceAll("1-[0-9]{" + playerIdLength + "}", playerId);
        setResourceByService(service, resourceName, resourceValue);

        System.out.println("Dynamic url has been overridden with: " + resourceValue);
        System.out.println(
                "PlayerId value was replaced with :" + playerId + " with replace length " + playerIdLength);
        System.out.println("Previous  Player Id Length is : " + previousPlayerIdLength);
        previousPlayerIdLength = playerId.length();
        System.out.println("Current Player Id Length is : " + previousPlayerIdLength);
    }

    /**
     * Change url resource with example player id. If isMeEnabledInWeb=true it changes with the /me
     *
     * @param resourceName the resource name
     * @param service      the service
     * @param id           the id
     */
    @Then(
            "I change url resource of method {string} of service {string} with configured playerId {string}")
    public void iChangeUrlResourceWithExamplePlayerId(
            String resourceName, String service, String id) {

        String resourceValue = calculateEndpointUrl(service, resourceName);
        int playerIdLength = id.length();
        nonNumericPlayerId = "";

        if (playerIdLength < 9 && previousPlayerIdLength != 0) { // 3 <9
            playerIdLength = previousPlayerIdLength;
        }

        if (id.matches("[A-Za-z]+")) {
            nonNumericPlayerId = id;
        }
        System.out.println("NonNumericPlayerId value is:" + nonNumericPlayerId);

        if (resourceValue.contains("web")
                && isMeEnabledInWeb
                && !resourceName.equals("MSISDNRegister")) {
            resourceValue = resourceValue.replace("{{playerId}}", "me");
            resourceValue = resourceValue.replaceAll("[0-9]{" + playerIdLength + "}", "me");
            setResourceByService(service, resourceName, resourceValue);
        } else {

            resourceValue = resourceValue.replace("{{playerId}}", id);
            resourceValue = resourceValue.replaceAll("[0-9]{" + playerIdLength + "}", id);
            setResourceByService(service, resourceName, resourceValue);
        }
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
        System.out.println(
                "PlayerId value was replaced with :" + id + " with replace length " + playerIdLength);
        System.out.println("Previous  Player Id Length is : " + previousPlayerIdLength);
        previousPlayerIdLength = id.length();
        System.out.println("Current Player Id Length is : " + previousPlayerIdLength);
    }

    /**
     * Change url resource with example admin id.
     *
     * @param resourceName the resource name
     * @param service      the service
     * @param adminId      the id
     */
    @Then(
            "I change url resource of method {string} of service {string} with configured adminId {string}")
    public void iChangeUrlResourceWithExampleAdminId(
            String resourceName, String service, String adminId) {
        String regexPatternAdminId =
                "(?<=/admins/)[^/]+"; // Match any alphanumeric value after notifications
        String resourceValue = calculateEndpointUrl(service, resourceName);
        resourceValue = resourceValue.replaceFirst(regexPatternAdminId, adminId);

        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    /**
     * Change url resource with example parameter id.
     *
     * @param resourceName the resource name
     * @param service      the service
     * @param id           the id - should be numeric
     */
    @Then(
            "I change url resource of method {string} of service {string} with configured parameter {string} {string}")
    public void iChangeUrlResourceWithExampleParameterId(
            String resourceName, String service, String parameter, String id) {
        String regexPattern1 = "";
        String regexPattern2 = "";
        String resourceValue = "";

        if (parameter.equals("roleId")) {
            if (id.equals("roleIdCC")) {
                id = String.valueOf(roleIdCC);
            } else if (id.equals("superAdminAccessId")) {
                id = String.valueOf(superAdminAccessId);
            } else if (id.equals("clerkAccessRoleId")) {
                id = String.valueOf(clerkAccessRoleId);
            } else if (id.equals("highWinnings")) {
                id = String.valueOf(highWinningsRoleId);
            }
            regexPattern1 = "(?<=/admin/)[^/]+"; // Match any alphanumeric value after admin
            regexPattern2 = "(?<=/player/)[^/]+"; // Match any alphanumeric value after player
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            resourceValue = resourceValue.replaceFirst(regexPattern2, id);
            setResourceByService(service, resourceName, resourceValue);
        }
        // temp sol for sessionminutes..special case..
        else if (parameter.equals("userGroup")) {
            regexPattern1 =
                    "(?<=/sessionminutes/)[^/]+"; // Match any alphanumeric value after sessionMinutes
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id) + "-{{playerId}}";
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("userGroupPlayerId")) {
            if (id.equals("playerId")) {
                id = "1-" + String.valueOf(playerId);
            }
            regexPattern1 =
                    "(?<=/sessionminutes/)[^/]+"; // Match any alphanumeric value after sessionMinutes
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);

        } else if (parameter.equals("playerId") || parameter.equals("playerIdCustomers")) {
            if (id.equals("playerIdCustomer")) {
                id = String.valueOf(playerId);
            }
            regexPattern1 = "(?<=/customers/)[^/]+"; // Match any alphanumeric value after customers
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("loginTimes")) {
            if (id.equals("playerId")) {
                id = "1-" + String.valueOf(playerId);
            }
            regexPattern1 = "(?<=/logintimes/)[^/]+";
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("playerIdSessions")) {
            if (id.equals("playerId")) {
                id = "1-" + String.valueOf(playerId);
            } else if (id.equals("accessSessionId")) {
                id = String.valueOf(accessSessionId);
            }
            regexPattern1 = "(?<=/sessions/)[^/]+";
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("operationalUnit")) {
            regexPattern1 =
                    "(?<=/access-attributes/)[^/]+"; // Match any alphanumeric value after access-attributes
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("userId")) {
            regexPattern1 = "(?<=/users/)[^/]+"; // Match any alphanumeric value after users
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("assertionId")) {
            regexPattern1 =
                    "(?<=/assertions/)[^/]+"; // Match any alphanumeric value after access-attributes
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("highWinningsRoleId")) {
            if (id.equals("highWinnings")) {
                id = String.valueOf(highWinningsRoleId);
                regexPattern1 = "(?<=/admin/)[^/]+"; // Match any alphanumeric value after admin
                resourceValue = calculateEndpointUrl(service, resourceName);
                resourceValue = resourceValue.replaceFirst(regexPattern1, id);
                setResourceByService(service, resourceName, resourceValue);
            }
        } else if (parameter.equals("highWinningsEnable")) {
            if (id.equals("highWinnings")) {
                id = String.valueOf(highWinningsRoleId);
                regexPattern1 = "(?<=/admins/)[^/]+"; // Match any alphanumeric value after admins
                resourceValue = calculateEndpointUrl(service, resourceName);
                resourceValue = resourceValue.replaceFirst(regexPattern1, id);
                setResourceByService(service, resourceName, resourceValue);
            }
        } else if (parameter.equals("paymentId")) {
            if (id.equals("highWinnings")) {
                id = String.valueOf(paymentIdGrandPrize);
                regexPattern1 = "(?<=/payments/)[^/]+"; // Match any alphanumeric value after payments
                resourceValue = calculateEndpointUrl(service, resourceName);
                resourceValue = resourceValue.replaceFirst(regexPattern1, id);
                setResourceByService(service, resourceName, resourceValue);
            }
        } else if (parameter.equals("playerIdGrandPrize")) {
            if (id.equals("GrandPrize")) {
                id = "1-" + String.valueOf(playerId);
                regexPattern1 = "(?<=/users/)[^/]+"; // Match any alphanumeric value after payments
                resourceValue = calculateEndpointUrl(service, resourceName);
                resourceValue = resourceValue.replaceFirst(regexPattern1, id);
                setResourceByService(service, resourceName, resourceValue);
            }
        } else if (parameter.equals("playerIdTest")) {
            regexPattern1 = "(?<=/sessions/)[^/]+"; // Match any alphanumeric value after customers
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("accessgroupId")) {
            if (id.equals("newAccessGroupId")) {
                id = newAccessGroupId;
            } else if (id.equals("fullAccountAccessGroupId")) {
                id = fullAccountAccessGroupId;
            }
            regexPattern1 = "(?<=/accessgroups/)[^/]+"; // Match any alphanumeric value after accessgroups
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("accessgroupMemberId")) {
            if (id.equals("newGroupMemberId")) {
                id = newGroupMemberId;
            }
            regexPattern1 = "(?<=/members/)[^/]+"; // Match any alphanumeric value after members
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("bonus")) {
            if (id.equals("bonusId")) {
                id = String.valueOf(bonusActiveId);
                regexPattern1 = "(?<=/bonuses/)[^/]+"; // Match any alphanumeric value after payments
                resourceValue = calculateEndpointUrl(service, resourceName);
                resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            }
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("transactionId")) {
            regexPattern1 = "(?<=/transactions/)[^/]+"; // Match any alphanumeric value after transactions
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("accessoperationsId")) {
            regexPattern1 =
                    "(?<=/accessoperations/)[^/]+"; // Match any alphanumeric value after transactions
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            setResourceByService(service, resourceName, resourceValue);
        } else if (parameter.equals("accountId")) {
            regexPattern1 = "(?<=/accounts/)[^/]+"; // Match any alphanumeric value after admin
            regexPattern2 = "(?<=/transactions/)[^/]+"; // Match any alphanumeric value after player
            resourceValue = calculateEndpointUrl(service, resourceName);
            resourceValue = resourceValue.replaceFirst(regexPattern1, id);
            resourceValue = resourceValue.replaceFirst(regexPattern2, id);
            setResourceByService(service, resourceName, resourceValue);
        } else {
            resourceValue = calculateEndpointUrl(service, resourceName);
            int idLength = id.length();
            resourceValue = resourceValue.replaceAll("[0-9]{" + idLength + "}", id);
            resourceValue = resourceValue.replace("{{" + parameter + "}}", id);
            setResourceByService(service, resourceName, resourceValue);
        }
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    /**
     * Change url resource with new sms id.
     *
     * @param resourceName the resource name
     * @param service      the service
     */
    @Then("I change url resource of method {string} of service {string} with new smsId")
    public void iChangeUrlResourceWithNewSmsId(String resourceName, String service) {
        String resourceValue = calculateEndpointUrl(service, resourceName);
        resourceValue = resourceValue.replace("{{smsId}}", smsId);
        resourceValue = resourceValue.replaceAll("[0-9]-[0-9]+-[0-9]+", smsId); // for retry
        setResourceByService(service, resourceName, resourceValue);

        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    /**
     * Change url resource with new AffiliateUserRoleId.
     *
     * @param resourceName the resource name
     * @param service      the service
     */
    @Then("I change url resource of method {string} of service {string} with new AffiliateUserRoleId")
    public void iChangeUrlResourceWithNewAffiliateUserRoleId(String resourceName, String service) {
        String resourceValue = calculateEndpointUrl(service, resourceName);
        resourceValue =
                resourceValue.replaceAll("[0-9]-[0-9]+-[0-9]+", affiliateUserRoleId); // for retry
        resourceValue = resourceValue.replace("{{affiliateUserRoleId}}", affiliateUserRoleId);
        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    /**
     * Change url resource with new SuperAdminAccessRoleId.
     *
     * @param resourceName the resource name
     * @param service      the service
     */
    @And(
            "I change url resource of method {string} of service {string} with new SuperAdminAccessRoleId")
    public void iChangeUrlResourceWithNewSuperAdminAccessRoleId(String resourceName, String service) {
        String resourceValue = calculateEndpointUrl(service, resourceName);
        resourceValue =
                resourceValue.replaceAll("[0-9]-[0-9]+-[0-9]+", superAdminAccessId); // for retry
        resourceValue = resourceValue.replace("{{superAdminAccessId}}", superAdminAccessId);
        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    /**
     * Change url resource with saved AdminId.
     *
     * @param resourceName the resource name
     * @param service      the service
     */
    @And("I change url resource of method {string} of service {string} with saved AdminId")
    public void iChangeUrlResourceWithSavedAdminId(String resourceName, String service) {
        String resourceValue = calculateEndpointUrl(service, resourceName);
        resourceValue = resourceValue.replaceAll("[0-9]-[0-9]+-[0-9]+", adminId); // for retry
        resourceValue = resourceValue.replace("{{adminId}}", adminId); // Replace {{adminId}} placeholder
        resourceValue = resourceValue.replaceAll("/admins/[^/]+/", "/admins/" + adminId + "/"); // Replace adminId in URL path
        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    /**
     * Change url resource with new serial number.
     *
     * @param resourceName the resource name
     * @param service      the service
     */
    @Then("I change url resource of method {string} of service {string} with new serialNumber")
    public void iChangeUrlResourceWithNewSerialNumber(String resourceName, String service) {
        String resourceValue = calculateEndpointUrl(service, resourceName);
        resourceValue = resourceValue.replace("{{serialNumber}}", serialNumber);
        resourceValue = resourceValue.replaceAll("[0-9]{32}", serialNumber); // for retry
        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    /**
     * Change url resource with new referenceId2 Not so common but changes /funds/ methods.
     *
     * @param resourceName the resource name
     * @param service      the service
     */
    @Then("I change url resource of method {string} of service {string} with referenceId2")
    public void iChangeUrlResourceWithReferenceId2(String resourceName, String service) {
        String resourceValue = calculateEndpointUrl(service, resourceName);
        resourceValue = resourceValue.replace("{{referenceId2}}", referenceId2);
        resourceValue =
                resourceValue.replaceAll(
                        "/funds/[0-9]{9}",
                        "/funds/"
                                + referenceId2); // for retry if method has no funds doesn't work on retry only.
        // Maybe create new step for other Variable.
        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    /**
     * Checks if a property/value pair does not exist in response.
     *
     * @param property the property to be checked
     * @param value    the value to be checked
     */
    @Then("the property {string} and value {string} do not exist in the response body")
    public void the_property_and_value_do_not_exist_in_the_response_body(
            String property, String value) {

        String stringResponse = response.asString();
        System.out.println(stringResponse);

        if (stringResponse.contains("\"" + property + "\":\"" + value + "\"")) {
            Assertions.fail();
        } else {
            Assertions.assertTrue(true);
        }
    }

    /**
     * Checks if a property/value pair exists in response.
     *
     * @param property the property to be checked
     * @param value    the value to be checked
     */
    @Then("the property {string} and value {string} exist in the response body")
    public void the_property_and_value_exist_in_the_response_body(String property, String value) {

        String stringResponse = response.asString();

        if (stringResponse.contains("\"" + property + "\":\"" + value + "\"")) {
            Assertions.assertTrue(true);
        } else {
            Assertions.fail();
        }
    }

    /**
     * Verifies a property (key) does not exist in response.
     *
     * @param property the response property
     */
    @Then("the {string} in response body does not exist")
    public void theInResponseBodyDoesNotExist(String property) {
        try {
            getJsonPath(response, property);
            Assertions.fail("Property: " + property + " found");
        } catch (Exception e) {
            Assertions.assertTrue(true);
        }
    }

    /**
     * Calls the UploadDocumentsWeb and uploads a file (/web resource)
     *
     * @param fileName the filename of the file to be uploaded
     * @param type     the type of the file in the headers
     */
    @Given("I create a UploadDocumentsWeb payload with {string} {string}")
    public void iCreateAUploadDocumentsWebPayloadWith(String fileName, String type)
            throws IOException {
        requestBody = ""; // needed for retry
        setSpecBuildersUpload(
                fileName, type); // is needed cause of params. it can't be called in Utils.
        res =
                given()
                        .spec(requestSpecWithHeadersSpecification("uploadSpecWeb"))
                        .body(requestBody)
                        .relaxedHTTPSValidation();
        tempFileName = fileName;
        tempFileType = type;
    }

    /**
     * Copies the player id from the response body and stores it in Utils for future use (not in array
     * of objects)
     */
    @Then("I copy the value of the player id {string} from the response")
    public void i_copy_the_value_of_the_player_id_from_the_response(String id) {
        playerId = getJsonPath(response, id);
        System.out.println("Player Id saved: " + playerId);
    }

    /**
     * Copies the payment id from the response body and stores it in Utils for future use (not in
     * array of objects)
     */
    @Then("I copy the value of the paymentId")
    public void iCopyTheValueOfThePaymentId() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        paymentId = jsonPathEvaluator.get("paymentId");
        System.out.println("Payment Id saved: " + paymentId);
    }

    /**
     * Copies the deposit tokenId from the response body and stores it in Utils for future use (not in
     * array of objects)
     */
    @Then("I copy the value of the deposit tokenId")
    public void i_copy_the_value_of_the_deposit_token_id() {
        if (environment.contains("Azure")) {
            String baseToken = "tok_7ZQOw37eh3WMFZoCeQ";
            int randomNumber = new Random().nextInt(1000000); // 0–999999
            depositTokenId = baseToken + randomNumber;
        } else {
            JsonPath jsonPathEvaluator = response.jsonPath();
            depositTokenId = jsonPathEvaluator.get("id");
        }

        System.out.println("Deposit Token Id is saved: " + depositTokenId);
    }

    /** Verifies that the player id equals to the saved in Utils player id upon registration */
    /**
     * @param id is the field name in json response
     */
    @Then("I verify the player id {string} in the response body")
    public void i_verify_the_player_id_in_the_response_body(String id) {
        JsonPath js = new JsonPath(response.asString());
        String actualId = js.get(id);

        Assertions.assertEquals(playerId, actualId);
    }

    @Then("I verify that payment Grand prize exists in the response body")
    public void i_verify_the_grandprize_in_the_response_body() {
        JsonPath js = new JsonPath(response.asString());
        String paymentId = js.getString("data.find { it.type == 'TT_PRIZE_OUT' }?.paymentId");

        if (paymentId == null || paymentId.isEmpty()) {
            Assertions.fail("No transactions found with type = TT_PRIZEPAYOUT");
        } else {
            System.out.println("Found paymentId: " + paymentId);
        }
    }

    /** Verifies that the username equals to the saved in Utils username upon registration */
    /**
     * @param user is the field name in json response
     */
    @Then("I verify the username {string} in the response body")
    public void i_verify_the_username_in_the_response_body(String user) {
        JsonPath js = new JsonPath(response.asString());
        String actualUser = js.get(user);
        Assertions.assertEquals(registeredUsername.toLowerCase(), actualUser);
    }

    /**
     * Verifies that a property in the response body includes the specific value
     */
    @Then("the property {string} includes value {string}")
    public void the_property_includes_value(String prop, String value) {
        JsonPath js = new JsonPath(response.asString());
        Object item = js.get(prop);

        if (item.toString().contains(value)) {
            Assertions.assertTrue(true);
        } else {
            Assertions.fail();
        }
    }

    /**
     * Verifies that response includes a value in general
     */
    @Then("the response includes value {string}")
    public void the_response_includes_value(String value) {
        JsonPath js = new JsonPath(response.asString());
        if (js.get().toString().contains(value)) {
            Assertions.assertTrue(true);
        } else {
            Assertions.fail();
        }
    }

    /**
     * Adds X seconds for wait/delay. Using it methodically and random should be avoided.
     */
    @Given("I add {int} seconds delay")
    public void iAddSecondsDelay(int seconds) {
        AddDelayInSeconds(seconds);
    }

    /**
     * Verifies that the specific properties with values exist in all indexes in a nameless array
     *
     * @param properties the properties separated by "," to be checked
     * @param values     the values of the properties separated by "," to be verified
     */
    @And("I verify the properties {string} have values {string} in each index in the nameless array")
    public void iVerifyThePropertiesHaveValuesInTheNamelessArray(String properties, String values) {
        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");

        if (properties.split(",").length > 1) {
            String[] propArray = properties.split(",");
            String[] valueArray = values.split(",");

            for (int responseIndex = 0; responseIndex < count; responseIndex++) {
                for (int i = 0; i < propArray.length; i++) {

                    String actualValue =
                            js.get("[" + responseIndex + "]" + "." + propArray[i])
                                    .toString()
                                    .replace("[", "")
                                    .replace("]", "");
                    Assertions.assertEquals(
                            valueArray[i],
                            actualValue,
                            "Expected value "
                                    + valueArray[i]
                                    + " is not equal with actual value "
                                    + actualValue
                                    + "in index"
                                    + responseIndex
                                    + "of array");
                    System.out.println(
                            "Response value in index "
                                    + responseIndex
                                    + " : "
                                    + valueArray[i]
                                    + " Actual Value:"
                                    + actualValue);
                }
            }
        } else {
            for (int responseIndex = 0; responseIndex < count; responseIndex++) {
                String actualValue =
                        js.get("[" + responseIndex + "]" + "." + properties)
                                .toString()
                                .replace("[", "")
                                .replace("]", "");
                Assertions.assertEquals(
                        values,
                        actualValue,
                        "Expected value "
                                + values
                                + " is not equal with actual value "
                                + actualValue
                                + "in index"
                                + responseIndex
                                + "of array");
                System.out.println(
                        "Response value in index "
                                + responseIndex
                                + " : "
                                + values
                                + " Actual Value:"
                                + actualValue);
            }
        }
    }

    /**
     * Verifies that the player id equals to the saved in Utils player id upon registration plus +1
     * (1-playerId)
     *
     * @param field is the field name in json response
     */
    @And("I verify the 1-playerId is the field {string} in the response body")
    public void iVerifyThe1_PlayerIdIsTheFieldInTheResponseBody(String field) {
        JsonPath js = new JsonPath(response.asString());
        String actualId = js.get(field);
        Assertions.assertEquals("1-" + playerId, actualId);
    }

    /**
     * Verifies that the sessionId equals to the saved in Utils
     *
     * @param field is the field name in json response
     */
    @And("I verify the sessionId is the field {string} in the response body")
    public void iVerifyTheSessionIdIsTheFieldInTheResponseBody(String field) {
        JsonPath js = new JsonPath(response.asString());
        String actualId = js.get(field);
        Assertions.assertEquals(accessSessionId, actualId);
    }

    /**
     * Verifies that the response date is newer than sessionLastAccessedTime
     */
    @And("I verify that the response date is newer than sessionLastAccessedTime")
    public void iVerifyResponseDateIsNewer() {
        String responseDate = response.jsonPath().getString("date");

        boolean isNewer = responseDate.compareTo(sessionLastAccessedTime) > 0;

        System.out.println("Is response date newer? " + isNewer);
    }

    /**
     * Clears all cookies from CookieStore. Works best as a standalone scenario. To test if it works
     * with other scenarios.
     */
    @And("I clear all cookies from CookieStore")
    public void iClearAllCookies() {
        System.out.println("CookieStore before clear:\n" + cookieStore);
        cookieStore.clear();
        System.out.println("CookieStore after clear:\n" + cookieStore);
    }

    @And("I check that JSessionId exists")
    public void jSessionIdIsTrue() {
        Cookies cookies = response.detailedCookies();
        boolean jSessionIdExists = cookies.hasCookieWithName("JSESSIONID");

        if (!jSessionIdExists) {
            Assertions.fail("JSESSIONID cookie does not exist!");
        }
        System.out.println("JSESSIONID Cookie Value: " + cookies.getValue("JSESSIONID"));
    }

    @Given("I create a POST LoginNew payload with {string} {string} {string} {string}")
    public void iCreateAPOSTLoginNewPayloadWith(
            String username, String password, String group, String channel) {

        if (username.equals("newPlayerWeb")) {
            username = registeredUsername;
        }
        requestBody =
                accessServiceData.addLoginNewData(
                        username, password, group, channel, "openid http://betware.com/oidc/scopes/session");
        String specification = "loginNew";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given(
            "I create a POST LoginNew GeoBlocking with allow {booleanValue} and payload with {string} {string} {string} {string}")
    public void iCreateAPOSTLoginNewGeoBlockingPayloadWith(
            boolean allow, String username, String password, String group, String channel) {
        String scope = "openid http://betware.com/oidc/scopes/session";
        xSourceAllow = allow;

        if (username.equals("newPlayerWeb")) {
            username = registeredUsername;
        }
        requestBody = accessServiceData.addLoginNewData(username, password, group, channel, scope);
        String specification = "loginNewGeoBlocking";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given(
            "I create a POST LoginNew payload including RememberMe with {string} {string} {string} {string} {string}")
    public void iCreateAPOSTLoginNewPayloadWith(
            String username, String password, String group, String channel, String rememberMe) {

        if (username.equals("newPlayerWeb")) {
            username = registeredUsername;
        }
        requestBody =
                accessServiceData.addLoginNewDataRememberMe(
                        username,
                        password,
                        group,
                        channel,
                        "openid http://betware.com/oidc/scopes/session",
                        booleanValue(rememberMe));
        String specification = "loginNew";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    /**
     * Verifies that the response field is masked.Cuts the first and the last digit to check
     */
    @Then("I verify the {string} in response body is masked")
    public void iVerifyTheInResponseBodyIsMasked(String field) {
        JsonPath js = new JsonPath(response.asString());
        String actualField = js.get(field);

        String stringToCheck = actualField.substring(1, actualField.length() - 1);
        if (field.equals("identityNumber") || field.equals("phone")) {
            stringToCheck = actualField;
        } else if (field.equals("address1")) {
            List<String> addressPartially = List.of(actualField.split(" "));
            for (int i = 0; i < addressPartially.size(); i++) {
                int addressLength = addressPartially.get(i).length();
                String addressToCheck = addressPartially.get(i).substring(1, addressLength - 1);
                addressLength = addressLength - 2;
                Assertions.assertTrue(addressToCheck.matches("[*]{" + addressLength + "}"));
            }
            return;
        }
        int length = stringToCheck.length();

        // Expects * n-1 times (exceptions of identityNumber, phone & address1)
        Assertions.assertTrue(stringToCheck.matches("[*]{" + length + "}"));
    }

    /**
     * Verifies that the response field is not masked.Only checks for at least one * in the field
     */
    @Then("I verify the {string} in response body is not masked")
    public void iVerifyTheInResponseBodyIsNotMasked(String field) {
        JsonPath js = new JsonPath(response.asString());
        String value = js.get(field);
        Assertions.assertFalse(
                value.contains("*"),
                "The field " + field + " is masked which is not expected. It has value: " + value);
    }

    @Given("I create a POST LoginNew payload with no token {string} {string} {string} {string}")
    public void iCreateAPOSTLoginNewPayloadWithNoToken(
            String username, String password, String group, String channel) {
        if (username.equals("newPlayerWeb")) {
            username = registeredUsername;
        }
        String scope = "openid http://betware.com/oidc/scopes/session";

        requestBody =
                accessServiceData.addLoginNewDataWithNoToken(username, password, group, channel, scope);
        String specification = "loginNew";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given(
            "I create a POST LoginNew payload with otpCode {string} {string} {string} {string} {string}")
    public void iCreateAPOSTLoginNewPayloadWithNoToken(
            String username, String password, String group, String channel, String otp) {
        if (username.equals("newPlayerWeb")) {
            username = registeredUsername;
        }
        if (otp.equals("newOtpCode")) {
            otp = otpCode;
        }

        String scope = "openid http://betware.com/oidc/scopes/session";

        requestBody =
                accessServiceData.addLoginNewDataOtpCode(username, password, group, channel, otp, scope);
        String specification = "loginNew";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }


    @And("the response body array at index {string} has value {string}")
    public void theResponseBodyArrayAtIndexHasValue(String index, String value) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        String actualValue =
                jsonPathEvaluator.get("[" + index + "]").toString().replace("[", "").replace("]", "");
        Assertions.assertEquals(
                value,
                actualValue,
                "Expected value " + value + " is not equal with actual value " + actualValue);
    }

    /**
     * Verifies that the Array has in all objects at least one of the values given
     */
    @Then("I verify the array with field {string} has one of values {string}")
    public void iVerifyTheFieldHasOneOfValues(String field, String values) {
        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");
        int successFound = 0;

        Object[] valueList = values.split(",");

        for (int i = 0; i < count; i++) {
            Object valueToCheck = js.get("[" + i + "]." + field);

            for (Object value : valueList) {
                if (value.equals("true") || value.equals("false")) {
                    value = value.toString();
                    valueToCheck = valueToCheck.toString();
                }
                if (valueToCheck.equals(value)) {
                    successFound++;
                    break;
                }
            }
            if (successFound <= i) {
                Assertions.fail(
                        "Field: "
                                + field
                                + " with value: "
                                + valueToCheck
                                + " was found in object number #"
                                + (i + 1)
                                + " of array"
                                + " but was not what we expected");
            }
        }
        System.out.println("Found " + successFound + " objects with correct value");
    }

    /**
     * Verifies that the specific array has at least one object with the value given
     *
     * @param arrayName
     * @param field
     * @param value
     */
    @Then("I verify the array {string} with field {string} has at least one value {string}")
    public void iVerifyTheFieldHasAtLeastOneValue(String arrayName, String field, String value) {
        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt(arrayName + ".size()");
        boolean successFound = false;

        for (int i = 0; i < count; i++) {
            String valueToCheck = js.get(arrayName + "[" + i + "]." + field);

            if (valueToCheck.equals(value)) {
                successFound = true;
                break;
            }
        }
        if (!successFound) {
            Assertions.fail("Field: " + field + " with value " + value + " was not found in array");
        }
    }

    /**
     * Copies the subject of the BO notifications templates from the response body and stores it.
     */
    @Then(
            "I copy the value of the subject, body and status of the BO notifications templates from the response")
    public void i_copy_the_value_of_properties_from_the_response() {
        subject = getJsonPath(response, "[0].subject");
        body = getJsonPath(response, "[0].body");
        status = getJsonPath(response, "[0].status");
        System.out.println("Subject saved: " + subject);
        System.out.println("Subject saved: " + body);
        System.out.println("Subject saved: " + status);
    }

    /**
     * Copies the event id from the response body and stores it.
     */
    @Then("I copy the value of the event id from the response")
    public void i_copy_the_value_of_the_event_id_from_the_response() {
        eventId = getJsonPath(response, "[0].id");
        System.out.println("EventId Id saved: " + eventId);
    }

    /**
     * Replaces eventId in the Url
     *
     * @param resourceName
     * @param service
     */
    @Then("I change url resource of method {string} of service {string} with new eventId")
    public void iChangeUrlResourceWithNewEventId(String resourceName, String service) {
        String resourceValue = calculateEndpointUrl(service, resourceName);
        resourceValue = resourceValue.replace("{{eventId}}", eventId);
        resourceValue = resourceValue.replaceAll("[0-9]-[0-9]+-[0-9]+", eventId); // for retry
        setResourceByService(service, resourceName, resourceValue);

        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    /**
     * Replaces path params in the Url
     *
     * @param service
     * @param keys
     * @param values
     */
    @Then(
            "I change url resource of method {string} of service {string} with path params {string} {string}")
    public void iChangeUrlResourceWithPathParams(
            String resourceName, String service, String keys, String values) {
        String resourceValue = calculateEndpointUrl(service, resourceName);
        String regexPatternEvents = "(?<=/events/)[^/]+"; // Match any alphanumeric value after /events/
        String regexPatternEmailTemplates =
                "(?<=/email-templates/)[^/]+"; // Match any alphanumeric value after /email-templates/
        String regexPatternNotificationId =
                "(?<=/notification-templates/)[^/]+"; // Match any alphanumeric value after
        // /email-templates/

        if (keys.equals("eventId")) {
            if (values.contains("replaceEventId")) {
                resourceValue = resourceValue.replaceFirst(regexPatternEvents, eventId);
            } else {
                resourceValue = resourceValue.replaceFirst(regexPatternEvents, values);
            }
        }
        if (keys.equals("emailTemplateId")) {
            if (values.contains("replaceEmailTemplateId")) {
                resourceValue = resourceValue.replaceFirst(regexPatternEmailTemplates, emailTemplateId);
            } else {
                resourceValue = resourceValue.replaceFirst(regexPatternEmailTemplates, values);
            }
        }
        //    if (keys.equals("notificationId")) {
        //      if (values.contains("replaceNotificationId")) {
        //        resourceValue = resourceValue.replaceFirst(regexPatternNotificationId,
        // notificationId); // check notificationId
        //      } else {
        //        resourceValue = resourceValue.replaceFirst(regexPatternNotificationId, values);
        //      }
        //    }
        setResourceByService(service, resourceName, resourceValue);

        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    /**
     * Copies the email template id from the response body and stores it.
     */
    @Then("I copy the value of the email template id from the response")
    public void i_copy_the_value_of_the_email_template_id_from_the_response() {
        emailTemplateId = getJsonPath(response, "[0].id");
        System.out.println("Email-Template Id saved: " + emailTemplateId);
    }

    /**
     * Copies the sessionId from the response body and stores it.
     */
    @Then("I copy the value of the sessionId from the response")
    public void i_copy_the_value_of_the_sessionId_from_the_response() {
        accessSessionId = getJsonPath(response, "[0].sessionId");
        System.out.println("sessionId saved: " + accessSessionId);
    }

    /**
     * Copies the sessionLastAccessedTime from the response body and stores it.
     */
    @Then("I copy the value of the sessionLastAccessedTime from the response")
    public void i_copy_the_value_of_the_sessionLastAccessedTime_from_the_response() {
        sessionLastAccessedTime = getJsonPath(response, "lastAccessed");
        System.out.println("sessionLastAccessedTime saved: " + sessionLastAccessedTime);
    }

    /**
     * Verifies a property (key) exists in the response.
     *
     * @param property the response property
     */
    @Then("the {string} in response body exists")
    public void theInResponseBodyExists(String property) {
        try {
            Assertions.assertTrue(
                    response.asString().contains(property),
                    "Property: '" + property + "' does not exist in the response.");
        } catch (Exception e) {
            Assertions.fail("Property: '" + property + "' does not exist in the response.");
        }
    }

    /***
     * Searches in an unnamed array and checks if conditionField with value one of conditionValues has fieldToCheck with value valueTocheck1 and the rest valueTocheck2.
     * Unlimited || in conditions or Unlimited && in conditions.The combination of both is not currently supported. 2 values to check finally.
     *   if field1="a" || field1=="B" || field1==C ..e.t.c
     *   if field1="a" && field1=="b" &&... e.t.c
     *   field2=valueTocheck1 else field2=valueToCheck2
     *
     * @param conditionField condition Field to check
     * @param conditionValues condition Values of condition field
     * @param conditionPrefix  && or || depends on what we want
     * @param fieldToCheck actual field to check
     * @param valueToCheck1 the values to check the actual field
     * @param valueToCheck2 the rest values (else) of the actual field - can be empty if we don't need an assertion here
     */

    @Then(
            "I verify the array if field {string} has values {string} with prefix {string} the field {string} has value {string} and the rest {string}")
    public void iVerifyTheArrayIfFieldHasValueAndValuesEitherTheFieldHasValueAndTheRest(
            String conditionField,
            String conditionValues,
            String conditionPrefix,
            String fieldToCheck,
            String valueToCheck1,
            String valueToCheck2) {

        // needs improvement for &&. and different conditionFields for ||. and maybe do some mix somehow

        if (!conditionPrefix.equals("&&")
                && !conditionPrefix.equals("||")
                && !(conditionPrefix.isBlank() || conditionPrefix.isEmpty())) {
            Assertions.fail(
                    "Please provide a valid condition prefix to the test. Recommended: && || .Or just leave string empty for no operation");
        }

        String[] conditionValuesList = conditionValues.split(","); // CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP
        String[] conditionFieldList = conditionField.split(","); // category,messageType
        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("js.size()");
        boolean condition = false;
        Object responseConditionValue2;
        boolean elseLogging = false;

        for (int i = 0; i < count; i++) {
            Object responseConditionValue = js.get("[" + i + "]." + conditionField); // data[i].category
            Object responseFinalValue = js.get("[" + i + "]." + fieldToCheck);

            for (int j = 0; j < conditionValuesList.length; j++) {
                if ((j + 1) < conditionValuesList.length) {
                    if (conditionPrefix.equals("||")) {
                        condition =
                                (conditionValuesList[j].equals(responseConditionValue)
                                        || conditionValuesList[j + 1].equals(
                                        (responseConditionValue))); // category or category...
                    } else if (conditionPrefix.equals("&&")) {
                        responseConditionValue =
                                js.get("[" + i + "]." + conditionFieldList[j]); // data[i].category
                        responseConditionValue2 =
                                js.get("[" + i + "]." + conditionFieldList[j + 1]); // data[i].messageType
                        condition =
                                (conditionValuesList[j].equals(responseConditionValue)
                                        && conditionValuesList[j + 1].equals(
                                        (responseConditionValue2))); // category & messageType
                    } else {
                        condition = (conditionValuesList[j].equals(responseConditionValue)); // category
                    }
                    if (condition) {
                        Assertions.assertEquals(
                                valueToCheck1,
                                responseFinalValue.toString(),
                                "IF Assertion:"
                                        + "Object "
                                        + i
                                        + 1
                                        + " of field "
                                        + fieldToCheck
                                        + " had expected value: "
                                        + valueToCheck1
                                        + " but actual was "
                                        + responseFinalValue);
                    } else {
                        if (valueToCheck2.isEmpty() || valueToCheck2.isBlank()) {
                            continue;
                        }
                        Assertions.assertEquals(
                                valueToCheck2,
                                responseFinalValue.toString(),
                                "ELSE Assertion: "
                                        + "Object "
                                        + i
                                        + 1
                                        + " of field "
                                        + fieldToCheck
                                        + " had expected value: "
                                        + valueToCheck2
                                        + " but actual was "
                                        + responseFinalValue);
                        elseLogging = true;
                    }
                }
            }
        }
        if (!elseLogging) {
            System.out.println(
                    "Second check value is empty. Else assertion check didn't happen. Just Logging. Could be a valid scenario");
        }
    }

    /**
     * Checks if Property in array has value
     *
     * @param property      the property to check
     * @param expectedValue value to check
     */
    @And("I verify the property {string} has value {string}")
    public void iVerifyThePropertyHasValue(String property, String expectedValue) {
        JsonPath js = new JsonPath(response.asString());
        int count = js.getInt("size()");
        for (int i = 0; i < count; i++) {
            String actualValue = js.getString("[" + i + "]." + property);
            // Check if expectedValue is a boolean value (i.e., "true" or "false")
            if ("true".equalsIgnoreCase(expectedValue) || "false".equalsIgnoreCase(expectedValue)) {
                boolean expectedBoolean = Boolean.parseBoolean(expectedValue);
                boolean actualBoolean = Boolean.parseBoolean(actualValue);
                Assertions.assertEquals(
                        expectedBoolean, actualBoolean, "Property value does not match expected boolean value");
            } else {
                Assertions.assertEquals(
                        expectedValue, actualValue, "Property value does not match expected string value");
            }
        }
    }

    @Given("I reset max retries to {int}")
    public void iResetMaxRetriesTo(int retries) {
        maxRetries = retries;
    }

    /**
     * Checks if the value inf the field is above the aboveValue
     *
     * @param field      the property to check
     * @param aboveValue value to check if resp > aboveValue
     */
    @Then("the {string} in response body is above {int}")
    public void theRowsInResponseBodyIsAbove(String field, int aboveValue) {
        int fieldValue = Integer.parseInt(getJsonPath(response, field));
        Assertions.assertTrue(fieldValue > aboveValue);
    }

    @Then("the {string} size in response body is above {int}")
    public void theInResponseBodyIsAbove(String field, int aboveValue) {
        JsonPath js = new JsonPath(response.asString());
        int actualSize = js.getList("rows").size();

        System.out.println("Found rows: " + actualSize);
        Assertions.assertTrue(
                actualSize > aboveValue,
                "Expected rows size to be above " + aboveValue + ", but was " + actualSize);
    }

    @Given("I create an empty payload with header {string}")
    public void iCreateAnEmptyPayload(String specification) {
        requestBody = "{}";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Given("I create an empty array payload with header {string}")
    public void iCreateAnEmptyArrayPayload(String specification) {
        requestBody = "[]";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @And("the {string} to include today's date")
    public void theToIncludeDatenow(String keyValue) {
        String time = getJsonPath(response, keyValue);
        Utils utils = new Utils();
        String dateCalculated = utils.calculateDateNowToString();
        Assertions.assertTrue(time.contains(dateCalculated));
    }

    @Then("I check if response code is 400 or 200")
    public void checkResponseCode() {
        int statusCode = response.getStatusCode();
        JsonPath js = new JsonPath(response.asString());
        if (statusCode == 400) {
            Assertions.assertEquals(
                    "USERNAME_ALREADY_TAKEN", js.getString("errorId"), "Error ID mismatch");
        } else {
            Assertions.assertEquals(200, statusCode, "Unexpected status code");
        }
    }

    @And("I check that the size of data.length is above {int}")
    public void iCheckThatTheNumberOfBOUsersIsAbove(int num) {
        JsonPath js = new JsonPath(response.asString());

        dataLength = js.getList("data").size();

        if (dataLength <= num) {
            Assertions.fail(
                    "Test failed: Expected data length to be above " + num + ", but got: " + dataLength);
        }
    }

    @And("I check that the size of elements in array {string} is {int}")
    public void iCheckThatTheNumberOfElementsIs(String parameter, int num) {
        JsonPath js = new JsonPath(response.asString());
        int parameterLength = js.getList(parameter).size();

        if (parameterLength != num) {
            Assertions.fail(
                    "Test failed: Expected data length to be " + num + ", but got: " + parameterLength);
        }
    }

    @Then("I copy the value of the ClerkAccessRoleId")
    public void iGetTheAccessRoleIdForClerkRole() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        clerkAccessRoleId = jsonPathEvaluator.getString("find { it.name == 'clerk' }.accessRoleId");
        System.out.println("The accessRoleId for Clerk role is: " + clerkAccessRoleId);
    }

    @Then("I copy the value of the HighWinningsRoleId")
    public void iGetTheAccessRoleIdForHighWinningsRole() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        highWinningsRoleId =
                jsonPathEvaluator.getString("find { it.name == 'HighWinnings' }.accessRoleId");
        System.out.println("The accessRoleId for HighWinnings role is: " + highWinningsRoleId);
    }

    @Then("I copy the value of the AffiliateUserRoleId")
    public void iCopyTheValueOfTheAffiliateUserRoleId() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        affiliateUserRoleId =
                jsonPathEvaluator.getString("data.find { it.loginName == 'affiliateuser1' }.id");
        System.out.println("affiliateUserRoleId is saved: " + affiliateUserRoleId);
    }

    @And(
            "I create a POST CreateNewRole payload {string} {string} {string} {string} {string} {string} {string} {int} {string}")
    public void iCreateAPOSTCreateNewRolePayload(
            String email,
            String firstname,
            String language,
            String lastName,
            String loginName,
            String password,
            String passwordRepeated,
            int status,
            String groupIds) {
        if (groupIds.equals("highWinnings")) {
            groupIds = highWinningsRoleId;
        }
        if (loginName.equals("azureHighWinnings")) {
            loginName = azureHighWinningsUsername;
            email = azureHighWinningsEmail;
        }
        List<Integer> groupIdsList = new ArrayList<>();

        String[] groupIdsArray = groupIds.split(",");
        for (String groupId : groupIdsArray) {
            groupIdsList.add(Integer.parseInt(groupId.trim()));
        }

        requestBody =
                adminServiceData.addCreateNewRole(
                        email,
                        firstname,
                        language,
                        lastName,
                        loginName,
                        password,
                        passwordRepeated,
                        status,
                        groupIdsList);
        String specification = "cc_csrftokenSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @Then(
            "I change url resource of method GetCustomerAccessRights {string} of service {string} with configured playerId {string}")
    public void iChangeUrlResource(String resourceName, String service, String configuredPlayerId) {
        String resourceValue =
                "cc/access/rest/v1/customers/{{playerId}}/access-attributes/admin.admins|admin-details|manage";
        if (configuredPlayerId.isEmpty()) {
            resourceValue = resourceValue.replace("{{playerId}}", playerId);
        } else {
            resourceValue = resourceValue.replace("{{playerId}}", configuredPlayerId);
        }

        System.out.println("Final URL with playerId: " + resourceValue);
        setResourceByService(service, resourceName, resourceValue);
    }

    @And("I log response's info")
    public void iLogResponse() {
        String stringResponse = response.asString();
        System.out.println("[INFO] Response: " + stringResponse);
    }

    @And("I concat the url {string} to the end of url of method {string} of service {string}")
    public void iConcatTheUrlToTheEndOfUrlOfMethodOfService(
            String urlToConcat, String resourceName, String service) {
        if (urlToConcat.equals("/fullAccountAccessGroupId")) {
            urlToConcat = "/" + fullAccountAccessGroupId;
        }
        if (urlToConcat.contains("newPlayerWeb")) {
            urlToConcat = urlToConcat.replace("newPlayerWeb", playerId);
        }

        String resourceValue = calculateEndpointUrl(service, resourceName);
        oldUrl = resourceValue;
        resourceValue = resourceValue.concat(urlToConcat);
        setResourceByService(service, resourceName, resourceValue);
        System.out.println("Dynamic url has been overridden with: " + resourceValue);
    }

    // in testing mode. i want to save the initial url as to not spoil any later replaces.
    // maybe i can add in hooks in the future.
    @And("I save the initial url of method {string} of service {string}")
    public void iSaveTheInitialUrlOfMEthodOfService(String resourceName, String service) {

        String resourceValue = calculateEndpointUrl(service, resourceName);
        oldUrl = resourceValue;
        // setResourceByService(service, resourceName, resourceValue);
        System.out.println("Saved old url : " + resourceValue);
    }

    @And("I return the url of method {string} of service {string} to its previous state")
    public void iReturnTheUrlOfMethodOfServiceToItsOriginalState(
            String resourceName, String service) {
        String resourceValue = calculateEndpointUrl(service, resourceName);
        setResourceByService(service, resourceName, oldUrl);
        System.out.println("Dynamic url has returned to previous state: " + resourceValue);
    }

    @Then("I copy the value of the paymentId for Grand prize")
    public void i_copy_the_value_of_the_payment_id_for_GrandPrize() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        String ownerId = playerId.replace("1-", "");
        paymentIdGrandPrize =
                jsonPathEvaluator.getString("find { it.owner.id == '" + playerId + "' }.paymentId");

        System.out.println("Payment Id for Grand prize is saved: " + paymentIdGrandPrize);
    }

    @And("I create a Verify High Winnings Payment Post payload")
    public void iVerifyPaymentHighWinnings() {
        requestBody = walletServiceData.addVerifyGrandprizePayment(paymentIdGrandPrize);

        res = given().spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec")).body(requestBody);
    }

    @And(
            "I create a POST CreateNewRole payload for Affiliate {string} {string} {string} {string} {string} {string} {string}")
    public void iCreateAPOSTCreateNewRolePayload(
            String email,
            String firstname,
            String language,
            String lastName,
            String loginName,
            String password,
            String passwordRepeated) {
        requestBody =
                adminServiceData.addCreateNewRoleAffiliate(
                        email, firstname, language, lastName, loginName, password, passwordRepeated);
        String specification = "cc_csrftokenSpec";
        res = given().spec(requestSpecWithHeadersSpecification(specification)).body(requestBody);
    }

    @And("I save the access token from LoginNew")
    public void iSaveTheAccessToken() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        accessToken = jsonPathEvaluator.get("access_token");
    }

    @Then(
            "the nameless array response should contain {int} elements with values {string} and {string}")
    public void the_nameless_array_response_should_contain_elements_with_two_values(
            Integer expectedSize, String firstValue, String secondValue) {
        JsonPath js = new JsonPath(response.asString());
        List<String> actual = js.getList("$");

        Assertions.assertEquals(
                expectedSize.intValue(),
                actual.size(),
                "Array does not have the expected number of elements");
        Assertions.assertTrue(actual.contains(firstValue), "Missing expected value: " + firstValue);
        Assertions.assertTrue(actual.contains(secondValue), "Missing expected value: " + secondValue);
    }

    @Then("one of the {string} has {string} equal to {string}")
    public void one_of_the_violations_has_field_equal_to(
            String violationType, String property, String expectedValue) {
        JsonPath js = new JsonPath(response.asString());

        String path =
                violationType + ".findAll { it[\"" + property + "\"] == '" + expectedValue + "' }";
        List<Object> matches = js.getList(path);

        Assertions.assertFalse(
                matches.isEmpty(),
                "No entry found in " + violationType + " with " + property + " = '" + expectedValue + "'");
    }

    @And("I verify the value of groupIds")
    public void iSaveAndVerifyTheGroupIds() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        List<Integer> groupIds = jsonPathEvaluator.getList("groupIds");

        Assertions.assertTrue(
                groupIds.contains(Integer.parseInt(highWinningsRoleId)),
                "Expected groupIds not found: " + groupIds);
    }

    @And("I verify that the {string} array is empty or null")
    public void iVerifyThatTheArrayIsEmptyOrNull(String fieldName) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        List<Object> fieldList = jsonPathEvaluator.getList(fieldName);

        Assertions.assertTrue(
                fieldList == null || fieldList.isEmpty(),
                "Expected " + fieldName + " array to be empty or null, but found: " + fieldList);
    }

    @Given("I copy the value of the sessionMinuteId")
    public void getSessionMinuteId() {
        JsonPath jsonPath = response.jsonPath();
        String sessionMinuteId = jsonPath.getString("sessionMinuteId");

        System.out.println("Session Minute ID: " + sessionMinuteId);
        Assertions.assertTrue(
                sessionMinuteId != null && !sessionMinuteId.trim().isEmpty(),
                "sessionMinuteId should not be null or empty");
    }

    /**
     * Checks if the field has the 1-playerId value e.g 1-04352345235
     *
     * @param field the property to check
     */
    @And("I verify field {string} in response body has 1-playerId value")
    public void iVerifyFieldInResponseBodyHasPlayerIdValue(String field) {
        Assertions.assertEquals("1-" + playerId, getJsonPath(response, field));
    }

    /**
     * Checks if the field has the prefix-playerId value e.g 1-04352345235, 2-123115125,
     * 3-123124124512 depends on prefix and playerId
     *
     * @param field       the property to check E.g. memberId
     * @param groupPrefix player Group prefix . E.g. 1-,2-,3- e.t.c
     */
    @And("the {string} in response body has the prefix {string} and new playerId")
    public void theInResponseBodyHasThePrefixAndNewPlayerId(String field, String groupPrefix) {
        Assertions.assertEquals(groupPrefix + playerId, getJsonPath(response, field));
    }

    @Then("I copy the value of the sessionMinuteId from the response")
    public void iCopyTheValueOfTheSessionMinuteIdFromTheResponse() {
        JsonPath jsonPathEvaluator = response.jsonPath();
        sessionMinuteId = jsonPathEvaluator.getString("rows[0].SESSIONMINUTEID");
        System.out.println("sessionMinuteId saved: " + sessionMinuteId);
        Assertions.assertTrue(
                sessionMinuteId != null && !sessionMinuteId.trim().isEmpty(),
                "SESSIONMINUTEID is null or empty");
    }

    @Then("I copy value of domain and gameId from the response")
    public void iExtractDomainGameIdAndSessionMinuteIdFromTheResponse() {
        JsonPath jsonPath = response.jsonPath();

        sessionDomain = jsonPath.getString("rows[0].DOMAIN");
        sessionGameId = jsonPath.getString("rows[0].GAMEID");

        System.out.println("DOMAIN: " + sessionDomain);
        System.out.println("GAMEID: " + sessionGameId);

        Assertions.assertTrue(
                sessionDomain != null && !sessionDomain.trim().isEmpty(), "DOMAIN is null or empty");
        Assertions.assertTrue(
                sessionGameId != null && !sessionGameId.trim().isEmpty(), "GAMEID is null or empty");
    }

    @And("I create Update Password payload for Web")
    public void iUpdatePasswordWebPayload() {
        requestBody = playerServiceData.addUpdatePassword();

        res = given().spec(requestSpecWithHeadersSpecification("mainSpec")).body(requestBody);
    }

    @And("I create Close Account payload with {string} {string} {string}")
    public void iCreateCloseAccountPayload(
            String status, String statusDescription, String statusReason) {
        requestBody = walletServiceData.addCloseAccount(status, statusDescription, statusReason);

        res = given().spec(requestSpecWithHeadersSpecification("cc_csrftokenSpec")).body(requestBody);
    }

    @And(
            "the property {string} in response body array with index {string} has prefix {string} and new playerId")
    public void thePropertyInResponseBodyArrayWithIndexHasPrefixAndNewPlayerId(
            String property, String arrayWithIndex, String groupPrefix) {

        JsonPath jsonPathEvaluator = response.jsonPath();
        String actualValue =
                jsonPathEvaluator
                        .get(arrayWithIndex + "." + property)
                        .toString()
                        .replace("[", "")
                        .replace("]", "");

        Assertions.assertEquals(
                groupPrefix + playerId,
                actualValue,
                "Expected property value "
                        + groupPrefix
                        + playerId
                        + " is not equal with actual value "
                        + actualValue);
    }

    @And(
            "the property {string} in response body array with index {string} is the calculated newAccessGroupId")
    public void thePropertyInResponseBodyArrayWithIndexIsTheCalculatedNewAccessGroupId(
            String property, String arrayWithIndex) {

        JsonPath jsonPathEvaluator = response.jsonPath();
        String actualValue =
                jsonPathEvaluator
                        .get(arrayWithIndex + "." + property)
                        .toString()
                        .replace("[", "")
                        .replace("]", "");

        Assertions.assertEquals(
                newAccessGroupId,
                actualValue,
                "Expected property value "
                        + newAccessGroupId
                        + " is not equal with actual value "
                        + actualValue);
    }

    /**
     * The api call is successful with either one of the two expected status codes. Mostly used if sth
     * already exists, and we don't want to recreate. Use it rarely byt efficiently.
     *
     * @param code1 the code (201 or 204)
     * @param code2 the other acceptable code
     */
    @Then("the API call is successful with either the status code {int} or {int}")
    public void the_api_call_is_successful_with_status_code(int code1, int code2) {

        String actualStatusCode = String.valueOf(response.getStatusCode());
        boolean success =
                (String.valueOf(code1).equals(actualStatusCode)
                        || String.valueOf(code2).equals(actualStatusCode));
        Assertions.assertTrue(
                success,
                "Actual status Code: "
                        + response.getStatusCode()
                        + " is not what it is expected: "
                        + code1
                        + "or "
                        + code2);
    }

    @Given("I setup authorization header {string} for api login")
    public void iSetupAuthorizationHeaderForApiLogin(String header) {
        String basic_auth;

        if (header.contains("{{api_auth}}")) {
            if (environment.equals("Preprod")) {
                basic_auth =
                        "YmV0d2FyZTpHLV9uT1kwdmZaSnhDdWt5dC1feVNvcHBMQWd1TmhVNHV4MUMzaWJLWm5ZbXFQUlFUVWpjOFJvbQ==";
            } else {
                basic_auth = "YmV0d2FyZTpodHRwczovL2ppcmEuYmV0d2FyZS5jb20vYnJvd3NlL0JXSU1EQ0QtMzcx";
            }

            api_auth = header.replace("{{api_auth}}", basic_auth);

        } else {
            api_auth = header;
        }
    }

    // to be retested
    @And("the response contains {string}")
    public void theResponseContains(String value) {
        String resp = response.toString();
        Assert.assertTrue(resp.contains(value));
    }
}
