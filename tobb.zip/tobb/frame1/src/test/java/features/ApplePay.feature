@applePay
Feature: ApplePay

  ###################################### CONFIGURED USER #################################################################################################

  @applePayConfigured @noDependency
  Scenario: Get Wallet Balance - Copy balance MAIN-1 (Configured User)
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with configured playerId "904649748"
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the balance in wallet "AT_MAIN-1"


# main call
  @applePayConfigured @noDependency
  Scenario Outline: Apple Pay - Configured User
    Given I login as a "configuredPlayerWeb" user
    And I create an ApplePay payload with "<currency>" <amount> "<sessionUrl>"
    And I change url resource of method "ApplePay" of service "ApplePayService" with configured playerId "904649748"
    When I make a "POST" call to "ApplePay" to service "ApplePayService"
    Then the API call is successful with status code 200
    And the "session" in response body has value not null
    And the "paymentId" in response body has value not null
    And I copy the value of the paymentId


    Examples:
      | currency | amount | sessionUrl                                                            |
      | EUR      | 2.00   | https://apple-pay-gateway-cert.apple.com/paymentservices/startSession |

###############################################################################################################################################################

### DOESNT WORK THIS WAY. NEEDS WIREMOCK + APPLE TOKEN CALL + AZURE#####

  #DEPOSIT SCENARIO (WILL BE USED IN DEPOSITS)
  #Scenario: VerifyDepositToTora
   # Given I login as a "configuredPlayerWeb" user
  #  Given I login as an Api user
  #  And I create a VerifyDepositToTora payload
   # And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new paymentId
  #  When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
  #  Then the API call is successful with status code 200
   # And the "paymentStatus" in response body is "VERIFIED"
  #  And I verify the paymentId in response body is the calculated paymentId


  #WILL BE USED WHEN THE MIDDLE STEPS ARE IMPLEMENTED FOR AZURE E.T.C
  Scenario Outline: Get Wallet Balance 2 - TEST
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with configured playerId "904649748"
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the balance in wallet "AT_MAIN-1" is oldAmount "+" <amount>

    Examples:
      | amount |
      | 2.00   |


