Feature: Email Verification

  @nightlySuite @UAT @Preprod @Setup @BalanceService
  Scenario Outline: Get MailId For Fetch Hash - Verify origin has value player
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "<array>" is 1
    And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
    And I copy the value of the mailId from the response

    Examples:
      | key      | value    | property | propertyValue | array | arrayWithIndex |
      | playerId | changeit | origin   | player        | data  | data[0]        |

  @nightlySuite @UAT @Preprod @Setup @BalanceService
  Scenario Outline: Get hash For Mail Verification - Verify event name/owner
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetHashForMailVerification" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the "<property>" in response body is "<propertyValue>"
    And the "<property2>" in response body is "<propertyValue2>"
    And the id in response body is mailIdForHash
    And I copy the value of the hash from the response

    Examples:
      | property  | propertyValue                       | property2  | propertyValue2 |
      | eventName | registrationWelcomeEvent.opaponline | eventOwner | player         |

  @nightlySuite @UAT @Preprod @Setup @BalanceService
  Scenario: Verify Player's Email - Call to verify player's email
    Given I create a VerifyEmail payload with inner playerId and hash
    When I make a "POST" call to "VerifyPlayersEmail" to service "PlayerService"
    Then the API call is successful with status code 204

#### ACCESS RELATED#################################

  #TODO: this call does something bad to Get BO Identity Verification and has no access. Don't get why. Under Investigation
  #@AccessService
  Scenario: Get Player v2
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerV2" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerV2" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify the player id "id" in the response body
    And I verify the username "username" in the response body

  @AccessService
  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

#############################################################

    @BonusService @skipIfNotAzure
    Scenario: Reset Mappings
        And I create a Get "wiremockSpec" header
        When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
        Then the API call is successful with status code 200

    @BonusService @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Mock authentication token
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                   | status | headers          | body                                                                                                                                                                                                                                                                                                                                                               |
            | testScenarioGetToken | Started               |          | ANY    | /bonus_api/auth/login | 500    | application/json | {\"access_token\": \"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.{\"auth_token\": \"eyJ0aW1lc3RhbXAiOiAxNTg2MTgyMTk5LCAiZW5jcnlwdGVkX3Bhc3N3b3JkIjogIlJZYithc3lIekREVUJoc1NjT01HUmtoaVhlTmFkclRWRU1HYmtnaU1USkMrRT0iLCAidXNlcl9pZCI6IDcwLCAiaXNfZXh0ZXJuYWwiOiBmYWxzZSwgInNlc3Npb25faWQiOiAiNzI1MCJ9._wUIyJ6sD57FSGb9ca-jSBOXEL9VcvVqfuKoaKkJBDs=\",\"success\":\"true\"} |

    @BonusService @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Mock for registration event - 500
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                            | status | headers          | body |
            | testScenarioGetToken | Started               |          | ANY    | /bonus_api/events/registration | 500    | application/json |      |

    @BonusService @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Mock for registration event EM - 500
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                 | status | headers          | body |
            | testScenarioGetToken | Started               |          | ANY    | /v1.0/user-mappings | 500    | application/json |      |

    @BonusService
    Scenario Outline: Get MailId For Fetch Hash - Verify origin has value player
        Given I login as a "configuredPlayerCc" user
        And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
        When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
        Then the API call is successful with status code 200
        And the number of results in the first nested array "<array>" is 1
        And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
        And I copy the value of the mailId from the response

        Examples:
            | key      | value    | property | propertyValue | array | arrayWithIndex |
            | playerId | changeit | origin   | player        | data  | data[0]        |

    @BonusService
    Scenario Outline: Get hash For Mail Verification - Verify event name/owner
        Given I create a Get "cc_csrftokenSpec" header
        When I make a "GET" call to "GetHashForMailVerification" to service "CommunicationService"
        Then the API call is successful with status code 200
        And the "<property>" in response body is "<propertyValue>"
        And the "<property2>" in response body is "<propertyValue2>"
        And the id in response body is mailIdForHash
        And I copy the value of the hash from the response

        Examples:
            | property  | propertyValue                       | property2  | propertyValue2 |
            | eventName | registrationWelcomeEvent.opaponline | eventOwner | player         |

    @BonusService
    Scenario: Verify Player's Email - Call to verify player's email
        Given I create a VerifyEmail payload with inner playerId and hash
        When I make a "POST" call to "VerifyPlayersEmail" to service "PlayerService"
        Then the API call is successful with status code 204

    @BonusService @skipIfNotAzure
    Scenario Outline: SQL query after registration- status failed
        Given I create a DrillHost Payload with "<queryType>" and "<query>"
        When I make a "POST" call to "DrillHost" to service "DrillHostService"
        Then the API call is successful with status code 200
        And the property "TYPE" in response body array with index "rows[0]" has value "0.0"
        And the property "STATUS" in response body array with index "rows[0]" has value "2.0"
        And the property "EXTTRANSACTIONID" in response body array with index "rows[0]" contains value "pam-bns-1"
        And the property "TYPE" in response body array with index "rows[0]" has value "3.0"
        And the property "STATUS" in response body array with index "rows[1]" has value "2.0"
        And the property "EXTTRANSACTIONID" in response body array with index "rows[1]" contains value "pam-em-1"

        Examples:
            | queryType | query                                                                                    |  |  |
            | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`BNSBONUSEVENTS` ORDER BY ID DESC LIMIT 2 |  |  |

    @BonusService @skipIfNotAzure
    Scenario: Reset Mappings
        And I create a Get "wiremockSpec" header
        When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
        Then the API call is successful with status code 200

    @BonusService @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Mock authentication token
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                   | status | headers          | body                                                                                                                                                                                                                                                                                                     |
            | testScenarioGetToken | Started               |          | ANY    | /bonus_api/auth/login | 500    | application/json | {\"auth_token\": \"eyJ0aW1lc3RhbXAiOiAxNTg2MTgyMTk5LCAiZW5jcnlwdGVkX3Bhc3N3b3JkIjogIlJZYithc3lIekREVUJoc1NjT01HUmtoaVhlTmFkclRWRU1HYmtnaU1USkMrRT0iLCAidXNlcl9pZCI6IDcwLCAiaXNfZXh0ZXJuYWwiOiBmYWxzZSwgInNlc3Npb25faWQiOiAiNzI1MCJ9._wUIyJ6sD57FSGb9ca-jSBOXEL9VcvVqfuKoaKkJBDs=\",\"success\":\"true\"} |

    @BonusService @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Mock for registration event - 200
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                            | status | headers          | body |
            | testScenarioGetToken | Started               |          | ANY    | /bonus_api/events/registration | 200    | application/json |      |

    @BonusService @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Mock for registration event EM - 500
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                 | status | headers          | body                                                                                                                                                                                    |
            | testScenarioGetToken | Started               |          | ANY    | /v1.0/user-mappings | 201    | application/json | {\"id\":\"3fa85f64-5717-4562-b3fc-2c963f66afa6\",\"externalUserId\":\"1-{{playerId}}\",\"internalUserId\":\"1234\",\"internalUserName\":\"1-{{playerId}}\",\"externalPayload\":\"406\"} |

    @BonusService @skipIfNotAzure
    Scenario Outline: SQL query after registration- 1st retry - status success
        Given I create a DrillHost Payload with "<queryType>" and "<query>"
        When I make a "POST" call to "DrillHost" to service "DrillHostService"
        Then the API call is successful with status code 200
        And the property "TYPE" in response body array with index "rows[0]" has value "0.0"
        And the property "STATUS" in response body array with index "rows[0]" has value "1.0"
        And the property "EXTTRANSACTIONID" in response body array with index "rows[0]" contains value "pam-bns-1"
        And the property "TYPE" in response body array with index "rows[0]" has value "3.0"
        And the property "STATUS" in response body array with index "rows[1]" has value "1.0"
        And the property "EXTTRANSACTIONID" in response body array with index "rows[1]" contains value "pam-em-1"

        Examples:
            | queryType | query                                                                                    |  |  |
            | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`BNSBONUSEVENTS` ORDER BY ID DESC LIMIT 2 |  |  |


   ################### CONFIGURED USER ######################################
  @VerifyConfiguredUser
  Scenario Outline: Get MailId For Fetch Hash - Verify origin has value player
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
    And I copy the value of the mailId from the response

    Examples:
      | key      | value     | property | propertyValue | array | arrayWithIndex |
      | playerId | 568858606 | origin   | player        | data  | data[0]        |

  @VerifyConfiguredUser
  Scenario: Get hash For Mail Verification - Verify event name/owner
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetHashForMailVerification" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the id in response body is mailIdForHash
    And I copy the value of the hash from the response


  @VerifyConfiguredUser
  Scenario Outline: Verify Player's Email - Call to verify player's email
    Given I create a VerifyEmail payload with playerId "<playerId>" and hash
    When I make a "POST" call to "VerifyPlayersEmail" to service "PlayerService"
    Then the API call is successful with status code 204

    Examples:
      | playerId  |
      | 568858606 |
