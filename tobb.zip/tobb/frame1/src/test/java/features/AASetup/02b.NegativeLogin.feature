Feature: Negative Logins

  Scenario Outline: Login Negative Scenarios - Username missing + player Blocked
    Given I create a POST LoginNew payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "<errorProperty1>" in response body is "<errorId>"
    And the "<errorProperty2>" in response body is "<errorDescription>"

    @AccessService
    Examples:
      | username     | password     | group | channel | statusCode | errorId                 | errorDescription                                                               | errorProperty1 | errorProperty2    |
      |              | Qwerty12345! | EP    | WEB     | 400        | invalid_request         | Invalid request                                                                | error          | error_description |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | 403        | NO_PLAYER_LEVEL_BLOCKED | Player Level of user is NO_PLAYER_LEVEL. ([Error Id: NO_PLAYER_LEVEL_BLOCKED]) | errorId        | error_description |
