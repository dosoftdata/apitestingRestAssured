Feature: Set Mandatory Limits


  @AccessService
  Scenario Outline: Deposit via Payment code - Betting wallet (Negative)
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 400
    And the "description" in response body is "The payment.paymentMethod.id: PAYMENT_CODE does not match any existing paymentMethod ([Error Id: NO_PAYMENT_METHOD])"
    And the "errorId" in response body is "NO_PAYMENT_METHOD"
    Examples:
      | paymentMethodId | paymentCode | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE    |             | 20     | COMMIT | WALLET_DEPOSIT | BANK_ACCOUNT      |


  @AccessService
  Scenario Outline: Deposit via Payment code - Lottery wallet (Negative)
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Mandatory limits have not been set for the player"
    And the "errorId" in response body is "MANDATORY_LIMITS_NOT_SET"
    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 20     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  @AccessService
  Scenario Outline: Deposit via Payment code - Betting wallet (Negative)
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Mandatory limits have not been set for the player"
    And the "errorId" in response body is "MANDATORY_LIMITS_NOT_SET"
    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |


  @Setup @BalanceService
  Scenario: Get and Verify Access Groups
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response and copy the access group Ids


  @Setup @BalanceService
  Scenario Outline: Get limits via limit-service
    Given I login as a "newPlayerWeb" user
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerLimits" of service "LimitService" with new playerId
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0
    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |

  @Setup @BalanceService
  Scenario Outline: Set mandatory limits for SPORTSBOOK/CASINO
    Given I setup gameId header to "SPORTSBOOK"
    And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
    And I change url resource of method "PlayerLimitsV2" of service "LimitService" with new playerId
    When I make a "POST" call to "PlayerLimitsV2" to service "LimitService"
    Then the API call is successful with status code 200

    Examples:
      | limitTypes             | limitPeriods            | limitAmounts         | gameIds             |
      | TIME,DEPOSIT,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY | 86000,2000,1000,1000 | ,,SPORTSBOOK,CASINO |

  @Setup @BalanceService
  Scenario Outline: Verify SPORTSBOOK mandatory limits via limit-service
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    And I verify limits for "DAILY" limit period, duration or amount 86000 and limitType "TIME" and gameId "" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 1000 and limitType "LOSS" and gameId "SPORTSBOOK" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 2000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-2" with pending limits false
    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |

  @Setup @BalanceService
  Scenario Outline: Set mandatory limits for JOKER/PROTO/LOTTO/SUPER3/KINO and Verify JOKER mandatory limits
    Given I setup gameId header to "JOKER"
    And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
    And I change url resource of method "PlayerLimitsV2" of service "LimitService" with new playerId
    When I make a "POST" call to "PlayerLimitsV2" to service "LimitService"
    Then the API call is successful with status code 200

    Examples:
      | limitTypes                                 | limitPeriods                                    | limitAmounts                             | gameIds                                     |
      | TIME,DEPOSIT,LOSS,LOSS,LOSS,LOSS,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY,DAILY,DAILY,DAILY,DAILY | 86400,2000,1000,1000,1000,1000,1000,1000 | ,,JOKER,PROTO,KINO,LOTTO,SUPER3,EUROJACKPOT |


  @Setup @BalanceService
  Scenario Outline: Verify JOKER mandatory limits via limit-service
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    And I verify limits for "DAILY" limit period, duration or amount 86000 and limitType "TIME" and gameId "" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 1000 and limitType "LOSS" and gameId "JOKER" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 2000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-1" with pending limits false

    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |
