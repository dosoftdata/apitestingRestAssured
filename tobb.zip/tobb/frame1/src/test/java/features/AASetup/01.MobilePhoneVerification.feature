@nightlySuite @UAT @Preprod @RegisterPlayer @Setup @BalanceService @BonusService
Feature: Mobile Verification

  Scenario: Create OTP Verification
    Given I create a "POST" VerifyOTP payload
    When I make a "POST" call to "VerifyOTP" to service "PlayerService"
    Then the API call is successful with status code 200
    And I copy the value of the uuid from the response


  Scenario: Verify OTP Code
    Given I create a "PUT" VerifyOTP payload
    When I make a "PUT" call to "VerifyOTP" to service "PlayerService"
    Then the API call is successful with status code 204

