#@AccessService
@UnauthorizedCalls
Feature: Unauthorized CC Calls

  Scenario Outline Outline: Get AdminAccessAttributes- Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetAdminAccessAttributes" of service "AccessService" with configured adminId "123"
    When I make a "GET" call to "GetAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-attributes/list/get/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get CustomerAccessAttributes - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured playerId "252885678"
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured parameter "operationalUnit" "123"
    When I make a "GET" call to "CustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-attributes/item/get/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Delete CustomerAccessAttributes - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured playerId "252885678"
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured parameter "operationalUnit" "123"
    When I make a "DEL" call to "CustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-attributes/item/delete/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Post CustomerAccessAttributes - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "PostCustomerAccessAttributes" of service "AccessService" with configured playerId "252885678"
    When I make a "POST" call to "PostCustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-attributes/item/post/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get Modules - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "GET" call to "GetModules" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.modules/list/get/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Login Backoffice - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "POST" call to "LoginBackOffice" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "description" in response body is "CSRF Token mismatch"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 403        | Incorrect Authorization |

  Scenario Outline: Delete Current Session - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "DEL" call to "DeleteCurrentSession" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "description" in response body is "CSRF Token mismatch"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 403        | Incorrect Authorization |

  Scenario Outline: Get SessionMinutes - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I change url resource of method "GetSessionMinutesCC" of service "AccessService" with configured parameter "userGroup" "1"
    And I change url resource of method "GetSessionMinutesCC" of service "AccessService" with configured playerId "252885678"
    And I create a Get "<spec>" header
    When I make a "GET" call to "GetSessionMinutesCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access/sessionminutes/get/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get - Allow AdminAccessAttributes - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "123"
    When I make a "GET" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-attributes/list.admin/get/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Put - Allow AdminAccessAttributes - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "123"
    When I make a "PUT" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-attributes/list.admin/put/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - AllowRoleAccessAttributes  - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AllowRoleAccessAttributes" of service "AccessService" with configured parameter "roleId" "123"
    When I make a "GET" call to "AllowRoleAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-attributes/list.admin-role/get/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Put - AllowRoleAccessAttributes  - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AllowRoleAccessAttributes" of service "AccessService" with configured parameter "roleId" "123"
    When I make a "PUT" call to "AllowRoleAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-attributes/list.admin-role/put/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - GetAdminRoles  - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetAdminRolesCC" of service "AccessService" with configured adminId "123"
    When I make a "GET" call to "GetAdminRolesCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-roles/admin.role-memberships/get/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Post - RolesAdminCC  - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "POST" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-roles/item.admin/post/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - RolesAdminCC  - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "GET" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-roles/list.admin/get/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - RolesAdminRoleIdCC  - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "123"
    When I make a "GET" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-roles/item.admin/get/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Put - RolesAdminRoleIdCC  - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "123"
    When I make a "PUT" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-roles/item.admin/put/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Del - RolesAdminRoleIdCC  - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "123"
    When I make a "DEL" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-roles/item.admin/delete/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_emptySpec                  | 403        | Missing Header          |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |