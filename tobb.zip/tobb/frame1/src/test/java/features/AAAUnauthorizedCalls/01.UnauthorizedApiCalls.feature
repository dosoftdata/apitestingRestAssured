@AccessService @UnauthorizedCalls
Feature: Unauthorized API Calls

  Scenario Outline: Post AccessAttributes - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-attributes/list/post/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Delete AccessAttributes - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-attributes/list/delete/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Get AccessAttributes - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-attributes/list/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Get AccessAttributesCurrent - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetApiAccessAttributes" of service "AccessService" with configured parameter "accessattributes" "current"
    Then I make a "GET" call to "GetApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-attributes/check/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Put Assertions - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "123"
    When I make a "PUT" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.assertions/item/put/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Delete Assertions - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "123"
    When I make a "DEL" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.assertions/item/delete/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Get Assertions - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "123"
    Then I make a "GET" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.assertions/item/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Get AccessAttributesAudit - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetAccessAttributesAudit" of service "AccessService" with configured playerId "123"
    Then I make a "GET" call to "GetAccessAttributesAudit" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access/audit/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Post AccessGroups - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "POST" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-groups/item/post/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |

  Scenario Outline: Get AccessGroupId - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetAccessGroupId" of service "AccessService" with configured parameter "accessgroupId" "123"
    Then I make a "GET" call to "GetAccessGroupId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-groups/item/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |

  Scenario Outline: Get AccessGroups - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-groups/list/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |

  Scenario Outline: Post AccessGroupsMembers - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "123"
    When I make a "POST" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-groupmembers/item/post/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |

  Scenario Outline: Get AccessGroupMemberId - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupId" "123"
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupMemberId" "123"
    When I make a "GET" call to "AccessGroupMemberId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-groupmembers/item/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Get AccessGroupMembers - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "GET" call to "GetAccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-groupmembers/list.members/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Get AccessGroupMembers with specific accessgroupId - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "123"
    When I make a "GET" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-groupmembers/list.membersingroup/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Delete AccessGroupMemberGroupId - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupId" "123"
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupMemberId" "123"
    When I make a "DEL" call to "AccessGroupMemberId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-groupmembers/item/delete/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Get Logintimes (Last & Previous) - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetLoginTimes" of service "AccessService" with configured playerId "123"
    And I change url resource of method "GetLoginTimes" of service "AccessService" with configured parameter "loginTime" "<login>"
    When I make a "GET" call to "GetLoginTimes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.logintime/item/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      | login    |
      | api_emptySpec                  | 403        | Missing Header          | last     |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation | last     |
      | api_emptySpec                  | 403        | Missing Header          | previous |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation | previous |


  Scenario Outline: Get SessionId - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "sessionId" "123"
    When I make a "GET" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.sessions/item/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Get Sessions - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.sessions/list/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Delete SessionId - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "sessionId" "123"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.sessions/item/delete/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Delete Sessions - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "DEL" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.sessions/list/delete/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Delete SessionIdCurrent - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "sessionId" "current"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.sessions/item/delete/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Post SessionAccess - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "SessionAccess" of service "AccessService" with configured parameter "sessionId" "<sessionId>"
    When I make a "POST" call to "SessionAccess" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.sessions/access/post/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      | sessionId |
      | api_emptySpec                  | 403        | Missing Header          | 123       |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation | 123       |
      | api_emptySpec                  | 403        | Missing Header          | current   |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation | current   |


  Scenario Outline: Get AccessAttributesV2 - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetAccessAttributesV2" of service "AccessService" with configured parameter "accessattributes" "current"
    When I make a "GET" call to "GetAccessAttributesV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-attributes/check/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Post AccessCheckV2 - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    When I make a "POST" call to "AccessCheckV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-attributes/check/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Put AdminRolesV2 - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AdminRolesV2" of service "AccessService" with configured parameter "adminId" "123"
    When I make a "PUT" call to "AdminRolesV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-roles/admin.role-memberships/put/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Get AdminMemberIdsV2 - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetMemberIdsV2" of service "AccessService" with configured parameter "roleId" "123"
    When I make a "GET" call to "GetMemberIdsV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-roles/admin.role-members/get/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |


  Scenario Outline: Del MembersV2 - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "DeleteMembersV2" of service "AccessService" with configured parameter "roleId" "123"
    When I make a "DEL" call to "DeleteMembersV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-roles/player.role-members/delete/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |

  Scenario Outline: Put RoleIdV2 - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AccessRoleIdV2" of service "AccessService" with configured parameter "roleId" "123"
    When I make a "PUT" call to "AccessRoleIdV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.access-groups/item/post/WEB"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 403        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorisation |