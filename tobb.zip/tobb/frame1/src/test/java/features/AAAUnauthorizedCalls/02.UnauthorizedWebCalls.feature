@AccessService @UnauthorizedCalls
Feature: Unauthorized Web Calls

  #concat to return the url to previous format
  @Concat
  Scenario Outline: Get- GetSessionMinutesWeb - Missing Header/Incorrect Cookie/ Incorrect Authorization
    Given I create a Get "<spec>" header
    And I save the initial url of method "GetSessionMinutesWeb" of service "AccessService"
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with configured playerId "12345678"
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=rest.sessionminutes/item/get/WEB"

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get - GetSessionWeb - Missing Header
    Given I create a Get "<spec>" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=rest.time/item/get/WEB"

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

