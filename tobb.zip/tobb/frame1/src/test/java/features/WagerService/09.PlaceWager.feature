@WagerService
Feature: Place Wager

#Place Wager - Cancel Reservation

  Scenario Outline: Wager funds
    Given I login as an Api user
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -6     | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | FALSE       | VERIFIED | false    | 0.0       | ""     | 0.0         | test                 |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 500.0    | 494.0        | 494.0                   | 6.0              | 0.0                  | 500.0    | 500.0        | 500.0                   | 0.0              | 0.0                  |


  Scenario Outline: Wager funds - Cancel Reservation
    Given I create a CancelReservation payload with reason "<reason>"
    And I change url resource of method "CancelReservation" of service "WagerService" with new playerId
    And I change url resource of method "CancelReservation" of service "WagerService" with referenceId2
    When I make a "POST" call to "CancelReservation" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "amount" in response body array with index "[0]" has value "<amount>"

    @WagerService
    Examples:
      | amount | type              | status   | reason                 |
      | 0.0    | TT_RESERVE_CANCEL | VERIFIED | Return Reserved Amount |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 500.0    | 500.0        | 500.0                   | 0.0              | 0.0                  | 500.0    | 500.0        | 500.0                   | 0.0              | 0.0                  |

#-------------------------------------------------------------------------------------------------------------------------------------------------

#Place Wager - Lose

  Scenario Outline: Wager funds  - Lose (Sportsbook)
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2.1   | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | 0.0       | ""     | 0.0         | test                 |


  Scenario Outline: CaptureBet -  Bet Capture
    Given I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "amount" in response body array with index "[0]" has value "<amountMain2>"
    And the property "postBalance" in response body array with index "[0]" has value "<postBalanceMain2>"


    Examples:
      | amount | productId  | type | status   | amountMain2 | postBalanceMain2 |
      | -2.1   | SPORTSBOOK | BUY  | VERIFIED | -2.1        | 497.9            |


  Scenario Outline: Get and Verify Wallets Balance (Betting - Lottery)
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 497.9                   | 0.0              | 0.0                  | 500      | 500          | 500                     | 0.0              | 0.0                  |

#-------------------------------------------------------------------------------------------------------------------------------------------------

#Place Wager - Win

  Scenario Outline: Wager funds
    Given I login as an Api user
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -4     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | FALSE       | VERIFIED | false    | 0.0       | ""     | 0.0         | test                 |


  Scenario Outline: CaptureBet - Verify type & status
    Given I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

    @WagerService
    Examples:
      | amount | type | status   | arrayWithIndex |
      | -4     | BUY  | VERIFIED | [0]            |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 497.9                   | 0.0              | 0.0                  | 496.0    | 496.0        | 496.0                   | 0.0              | 0.0                  |


  Scenario Outline: Wager funds
    Given I login as an Api user
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | 11.90  | DEFAULT  | datenow | JOKER     | PRIZE | Bet         | TRUE        | VERIFIED | TRUE     | 0.0       | ""     | 0.0         | test                 |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 497.9                   | 0.0              | 0.0                  | 507.9    | 507.9        | 496.0                   | 0.0              | 11.9                 |
#-------------------------------------------------------------------------------------------------------------------------------------------------

 #Place Wager - Cancel

  Scenario Outline: Wager funds - (temporary Lose)
    Given I login as an Api user
    And I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -1.23  | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | FALSE       | VERIFIED | false    | 0.0       | ""     | 0.0         | test                 |


  Scenario Outline: CaptureBet - Verify type & status
    Given I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

    @WagerService
    Examples:
      | amount | type | status   | arrayWithIndex |
      | -1.23  | BUY  | VERIFIED | [0]            |


  Scenario Outline: Get and Verify Wallets Balance (temporary loss)
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 496.67   | 496.67       | 496.67                  | 0.0              | 0.0                  | 507.9    | 507.9        | 496.0                   | 0.0              | 11.9                 |


  Scenario Outline: Wager funds - Cancel
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | 1.23   | DEFAULT  | datenow | SPORTSBOOK | CANCEL | Bet         | true        | VERIFIED | true     | 0.0       | ""     | 0.0         | test                 |


  Scenario Outline: Get and Verify Wallets Balance (after cancellation)
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 496.67                  | 0.0              | 1.23                 | 507.9    | 507.9        | 496.0                   | 0.0              | 11.9                 |

#-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#Place Wager - Win and Rollback

  Scenario Outline: Wager funds - Win and Rollback - JOKER
    Given I login as an Api user
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -5.01  | DEFAULT  | datenow | JOKER     | BUY  | Bet         | FALSE       | VERIFIED | false    | 0.0       | ""     | 0.0         | test                 |

  Scenario Outline: CaptureBet - Verify type & status
    Given I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

    @WagerService
    Examples:
      | amount | type | status   | arrayWithIndex |
      | -5.01  | BUY  | VERIFIED | [0]            |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 496.67                  | 0.0              | 1.23                 | 502.89   | 502.89       | 490.99                  | 0.0              | 11.9                 |


  Scenario Outline: Wager funds - Prize
    Given I login as an Api user
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | 21     | DEFAULT  | datenow | JOKER     | PRIZE | Bet         | TRUE        | VERIFIED | TRUE     | 0.0       | ""     | 0.0         | test                 |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 496.67                  | 0.0              | 1.23                 | 523.89   | 523.89       | 490.99                  | 0.0              | 32.9                 |


  Scenario Outline: Wager funds - Prize rollback
    Given I login as an Api user
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId | type           | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -21    | DEFAULT  | datenow | JOKER     | PRIZE_ROLLBACK | Bet         | TRUE        | VERIFIED | TRUE     | 0.0       | ""     | 0.0         | test                 |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 496.67                  | 0.0              | 1.23                 | 502.89   | 502.89       | 490.99                  | 0.0              | 11.9                 |

#Place Wager - Win and Cancel- SPORTSBOOK

  Scenario Outline: Wager funds - Win and Cancel - SPORTSBOOK
    Given I login as an Api user
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -12.5   | DEFAULT  | datenow | SPORTSBOOK     | BUY  | Bet         | FALSE       | VERIFIED | false    | 0.0       | ""     | 0.0         | test                 |

  Scenario Outline: CaptureBet - Verify type & status
    Given I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

    @WagerService
    Examples:
      | amount | type | status   | arrayWithIndex |
      | -12.5   | BUY  | VERIFIED | [0]            |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 485.4    | 485.4        | 484.17                  | 0.0              | 1.23                  | 502.89   | 502.89       | 490.99                  | 0.0              | 11.9                   |


  Scenario Outline: Wager funds
    Given I login as an Api user
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | 189.39     | DEFAULT  | datenow | SPORTSBOOK     | PRIZE | Bet         | TRUE        | VERIFIED | TRUE     | 0.0       | ""     | 0.0         | test                 |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 674.79   | 674.79       | 484.17                  | 0.0              | 190.62               | 502.89   | 502.89       | 490.99                  | 0.0              | 11.9                 |


  Scenario Outline: Wager funds
    Given I login as an Api user
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount  | currency | issued  | productId  | type           | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -189.39 | DEFAULT  | datenow | SPORTSBOOK | PRIZE_ROLLBACK | Bet         | TRUE        | VERIFIED | TRUE     | 0.0       | ""     | 0.0         | test                 |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 485.4    | 485.4        | 484.17                  | 0.0              | 1.23                   | 502.89   | 502.89       | 490.99                  | 0.0              | 11.9                 |

  Scenario Outline: Wager funds
    Given I login as an Api user
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | 12.5    | DEFAULT  | datenow | SPORTSBOOK | CANCEL | Bet         | TRUE        | VERIFIED | TRUE     | 0.0       | ""     | 0.0         | test                 |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 484.17                  | 0.0              | 13.73                   | 502.89   | 502.89       | 490.99                  | 0.0              | 11.9                 |



#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    #Place Wager - Cancel & Lose - JOKER
   # Commented examples to change when win added in between

  Scenario Outline: Wager funds - (Temp Loss - Joker)
    Given I login as an Api user
    And I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -2     | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | FALSE       | VERIFIED | false    | 0.0       | ""     | 0.0         | test                 |


  Scenario Outline: CaptureBet - Verify type & status
    Given I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

    @WagerService
    Examples:
      | amount | type | status   | arrayWithIndex |
      | -2     | BUY  | VERIFIED | [0]            |


  Scenario Outline: Get and Verify Wallets Balance (temporary loss)
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 484.17                  | 0.0            | 13.73                 | 500.89     | 500.89        | 488.99                    | 0.0            | 11.9                 |

  Scenario Outline: Wager funds - Refund
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | 2      | DEFAULT  | datenow | SPORTSBOOK | REFUND | Bet         | true        | VERIFIED | true     | 0.0       | ""     | 0.0         | test                 |

  Scenario Outline: Get and Verify Wallets Balance (after refund)
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 484.17                  | 0.0            | 13.73               | 502.89     | 502.89        | 488.99                   | 0.0            | 13.9                 |


  Scenario Outline: Wager funds - Adjust
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -2     | DEFAULT  | datenow | SPORTSBOOK | ADJUST | Bet         | true        | VERIFIED | true     | 0.0       | ""     | 0.0         | test                 |


  Scenario Outline: Get and Verify Wallets Balance (after adjust)
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 484.17                  | 0.0            | 13.73                 |  500.89     | 500.89        | 488.99                  | 0.0            | 11.9                 |

 #--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    #Place Wager - Cancel & Win - SPORTSBOOK

  Scenario Outline: Wager funds - (Temp Loss - Sportsbook)
    Given I login as an Api user
    And I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | FALSE       | VERIFIED | false    | 0.0       | ""     | 0.0         | test                 |


  Scenario Outline: CaptureBet - Verify type & status
    Given I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

    @WagerService
    Examples:
      | amount | type | status   | arrayWithIndex |
      | -2     | BUY  | VERIFIED | [0]            |


  Scenario Outline: Get and Verify Wallets Balance (temporary loss)
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 495.9    | 495.9        | 482.17                  | 0.0              | 13.73                | 500.89   | 500.89       | 488.99                  | 0.0              | 11.9                 |

  Scenario Outline: Wager funds - Refund
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | 2      | DEFAULT  | datenow | SPORTSBOOK | REFUND | Bet         | true        | VERIFIED | true     | 0.0       | ""     | 0.0         | test                 |

  Scenario Outline: Get and Verify Wallets Balance (after refund)
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 497.9    | 497.9        | 482.17                  | 0.0              | 15.73                | 500.89   | 500.89       | 488.99                  | 0.0              | 11.9                 |


  Scenario Outline: Wager funds - Adjust
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | SPORTSBOOK | ADJUST | Bet         | true        | VERIFIED | true     | 0.0       | ""     | 0.0         | test                 |


  Scenario Outline: Get and Verify Wallets Balance (after adjust)
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 495.9    | 495.9        |482.17                  | 0.0              | 13.73                 | 500.89   | 500.89       | 488.99                  | 0.0              | 11.9                 |


  Scenario Outline: Wager funds - Prize
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    @WagerService
    Examples:
      | accountId | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | 6.99   | DEFAULT  | datenow | SPORTSBOOK | PRIZE | Bet         | true        | VERIFIED | true     | 0.0       | ""     | 0.0         | test                 |


  Scenario Outline: Get and Verify Wallets Balance (after prize win)
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 502.89   | 502.89       | 482.17                  | 0.0              | 20.72                 | 500.89   | 500.89       | 488.99                  | 0.0              | 11.9                 |

