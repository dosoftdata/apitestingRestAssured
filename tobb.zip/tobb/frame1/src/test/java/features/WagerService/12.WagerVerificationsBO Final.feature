@WagerService
Feature: Wager Verifications BO

  Scenario Outline: Get All Wagers
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetAllWagers" of service "WagerService" with new playerId
    When I make a "GET" call to "GetAllWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "gameId" in response body array with index "<arrayWithIndex>" has value "<gameId>"
    And the property "priceAmount" in response body array with index "<arrayWithIndex>" has value "<priceAmount>"
    And the property "boPrize" in response body array with index "<arrayWithIndex>" has value "<boPrize>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

    @WagerService @skipIfNotAzure
    Examples:
      | keys                         | values            | arrayWithIndex | gameId | priceAmount | boPrize | status | arrayWithIndex | gameId | priceAmount | boPrize | status | arrayWithIndex | gameId | priceAmount | boPrize | status | arrayWithIndex | gameId | priceAmount | boPrize | status | arrayWithIndex | gameId     | priceAmount | boPrize | status    | arrayWithIndex | gameId | priceAmount | boPrize | status   | arrayWithIndex | gameId     | priceAmount | boPrize | status    | arrayWithIndex | gameId | priceAmount | boPrize | status   | arrayWithIndex | gameId     | priceAmount | boPrize | status |
      | pageSize,fromBought,toBought | 8,datenow,datenow | data[0]        | JOKER  | 21          | 0       | ACTIVE | data[1]        | JOKER  | 10.5        | 0       | ACTIVE | data[2]        | JOKER  | 10.5        | 0       | ACTIVE | data[3]        | JOKER  | 2           | 0       | ACTIVE | data[4]        | Sportsbook | 12.5        | 0       | CANCELLED | data[5 ]       | JOKER  | 5.01        | 0       | FINISHED | data[6]        | SPORTSBOOK | 1.23        | 0       | CANCELLED | data[7]        | JOKER  | 4           | 11.9    | FINISHED | data[8]        | SPORTSBOOK | 2.1         | 0       | ACTIVE |


    @WagerService @skipIfAzure
    Examples:
      | keys                         | values            | arrayWithIndex | gameId | priceAmount | boPrize | status | arrayWithIndex | gameId | priceAmount | boPrize | status | arrayWithIndex | gameId | priceAmount | boPrize | status   | arrayWithIndex | gameId | priceAmount | boPrize | status | arrayWithIndex | gameId     | priceAmount | boPrize | status   | arrayWithIndex | gameId     | priceAmount | boPrize | status | arrayWithIndex | gameId     | priceAmount | boPrize | status    | arrayWithIndex | gameId | priceAmount | boPrize | status   |
      | pageSize,fromBought,toBought | 8,datenow,datenow | data[0]        | JOKER  | 1           | 0       | ACTIVE | data[1]        | JOKER  | 1           | 0       | ACTIVE | data[2]        | JOKER  | 42          | 100     | FINISHED | data[3]        | JOKER  | 1           | 0       | ACTIVE | data[4]        | Sportsbook | 2           | 6.99    | FINISHED | data[5]        | SPORTSBOOK | 2           | 0       | ACTIVE | data[6]        | SPORTSBOOK | 12.5        | 0       | CANCELLED | data[7]        | JOKER  | 5.01        | 0       | FINISHED |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService @skipIfNotAzure
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 502.89   | 502.89       | 482.17                  | 0.0              | 20.72                | 568.39   | 568.39       | 456.49                  | 0.0              | 111.9                |


    @WagerService @skipIfAzure
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 502.89   | 502.89       | 482.17                  | 0.0              | 20.72                | 555.89   | 555.89       | 443.99                  | 0.0              | 111.9                |

