@WagerService
Feature: Wager Verifications BO


  Scenario Outline: Get Wager Product IDs
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetWagerProductIds" to service "WagerService"
    Then the API call is successful with status code 200
    And the response body array at index "<index1>" has value "<selection1>"
    And the response body array at index "<index2>" has value "<selection2>"
    And the response body array at index "<index3>" has value "<selection3>"

    @WagerService
    Examples:
      | index1 | selection1 | index2 | selection2 | index3 | selection3 |
      | 0      | JOKER      | 1      | Sportsbook | 2      | CASINO     |

  Scenario Outline: Get All Wagers
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetAllWagers" of service "WagerService" with new playerId
    When I make a "GET" call to "GetAllWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "gameId" in response body array with index "<arrayWithIndex>" has value "<gameId>"
    And the property "priceAmount" in response body array with index "<arrayWithIndex>" has value "<priceAmount>"
    And the property "boPrize" in response body array with index "<arrayWithIndex>" has value "<boPrize>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

    @WagerService
    Examples:
      | keys                         | values            | arrayWithIndex | gameId     | priceAmount | boPrize | status   | arrayWithIndex | gameId | priceAmount | boPrize | status | arrayWithIndex | gameId     | priceAmount | boPrize | status    | arrayWithIndex | gameId | priceAmount | boPrize | status   | arrayWithIndex | gameId     | priceAmount | boPrize | status    | arrayWithIndex | gameId | priceAmount | boPrize | status   | arrayWithIndex | gameId     | priceAmount | boPrize | status |
      | pageSize,fromBought,toBought | 7,datenow,datenow | data[0]        | SPORTSBOOK | 2           | 6.99    | FINISHED | data[1]        | JOKER  | 2           | 0       | ACTIVE | data[2]        | Sportsbook | 12.5        | 0       | CANCELLED | data[3]        | JOKER  | 5.01        | 0       | FINISHED | data[4]        | Sportsbook | 1.23        | 0       | CANCELLED | data[5 ]       | JOKER  | 4           | 11.9    | FINISHED | data[6]        | SPORTSBOOK | 2.1         | 0       | ACTIVE |
