Feature: Mock Joker Wager

  # Contains Wiremock Stubs that are tagged with @skipIfNotAzure so as tests to be skipped in other environments than Azure.
  # For Debug purposes in other environments comment the above tag otherwise the code won't come up to this feature in Integration for example.
  #There is another safety net that nothing changes in wiremockSpec that throws exception if tag is not included. This will happen in the step that the method call is made.
  #Better to test in Azure thought.
  # In any case leave wiremock.host with an empty value in Integration.properties and we are safe.


  @WagerService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 201 for authorization token 1
    Given I login as a "newPlayerWeb" user
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName         | requiredScenarioState | priority | method | url                   | status | headers          | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
      | testScenarioGetToken | Started               |          | POST   | /authentication/token | 200    | application/json | {\"access_token\": \"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzY29wZSI6WyJvcGVuaWQiXSwiZXhwIjoxNTc0NjgzOTA1LCJqdGkiOiIxM2I5YjQxMy1lNzA4LTQ3YzItODUxZS0yOTAzNzJhODU2MjYiLCJjbGllbnRfaWQiOiJvcGFwIn0.QZ5mp_nVtsRxS9qMMswfsQRSH4qmRxjuup0tczYtf8vWrzXU2VGP58b0_-AzKdl0Y8rlFoIm5mlNqQ7ddNYZMoP4fS986_4z1BDG9GXymuFOvQujYGhYvXYueDg1pT9tXwvthv4y9jFBs7YG3QE0s5eeqjWsC03E2J55TVc91Y2dhbaALnURyZ8Dhew4QsTp-xlz-ORXwVLWLzy0PqlmE3HhAldJoIcC7kM-eUl5_-e8U3RzupgXR9WDaKL-y9n8f-ZKwcRYX5kq2vAGbWxjXxddgiwpJI7OKuMFx7aZ3F1OMs4HRr39gMzPXQ35ne0TqqqRJx7PS8I8oRZyriMyOg\",\"token_type\": \"bearer\",\"expires_in\": \"3599\",\"scope\": \"openid\",\"jti\": \"13b9b413-e708-47c2-851e-290372a85626\"} |


  @WagerService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 200 for Verify Wager
    Given I setup "<guid>" guid and timestamp "<timestamp>" wiremock variable
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | guid    | timestamp | scenarioName           | requiredScenarioState | priority | method | url                                | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
      | datenow | datenow   | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers/verification | 200    | application/json,{{guid}} | {\"promotionOutcomes\":[],\"wager\":{\"dbg\":[{\"addOn\": [{\"columns\":21,\"cost\":10.5,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":5,\"selection\":[1,2,3,4,5,6,7]},{\"requested\":1,\"selection\":[15]}],\"quickPick\":false}],\"columns\":21,\"cost\":10.5,\"creationTime\":\"{{guid}}\",\"updatedTime\":\"{{guid}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{guid}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{guid}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\": 1313},\"status\":\"Played\",\"selectionsType\": 2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\":100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":0}} |

  @WagerService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 200 for Play Wager
    Given I setup creationTime "<creationTime>" and wagerId and serialNumbers wiremock variables
    And I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | creationTime | scenarioName           | requiredScenarioState | priority | method | url                   | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
      | datenow      | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers | 200    | application/json,{{guid}} | {\"wagerId\":\"{{wagerId}}\",\"pilot\":\"false\",\"promotionOutcomes\":[],\"serialNumbers\":[\"{{serialNumbers}}\"],\"wager\":{\"dbg\":[{\"addOn\":[{\"columns\":21,\"cost\":10.5,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":7,\"selection\":[1,2,3,4,5,6,7]},{\"requested\": 1,\"selection\": [15]}],\"quickPick\":false}],\"columns\":21,\"cost\":10.5,\"creationTime\":\"{{creationTime}}\",\"updatedTime\":\"{{creationTime}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{creationTime}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{creationTime}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\":1313},\"status\":\"Played\",\"selectionsType\":2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\": 100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":\"{{wagerId}}\",\"operator\":1}} |


  @WagerService @skipIfNotAzure
  Scenario Outline: Play wager via v1.WEB (multipleWagers)
    Given I login as an Intralot user
    And I setup gameId header to "<gameType>"
    And I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
    And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
    When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "gameType" in response body array with index "<index>" has value "<gameType>"
    And the property "wager.wager.status" in response body array with index "<index>" has value "<status>"
    And the property "wager.wager.cost" in response body array with index "<index>" has value "<cost>"
    And wagerId in response body is the same as stubbed one
    And serialNumbers in response body is the same as stubbed one


    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick | status | cost | index |
      | JOKER    | 1       | 1       | 1 2 3 4 5     | 15             | false     | Played | 10.5 | [0]   |


  @WagerService @skipIfAzure
  Scenario Outline: Play wager via v1.WEB (multipleWagers)
    Given I login as an Intralot user
    And I setup gameId header to "<gameType>"
    And I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
    And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
    When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "gameType" in response body array with index "<index>" has value "<gameType>"
    And the property "wager.wager.status" in response body array with index "<index>" has value "<status>"
    And the property "wager.wager.cost" in response body array with index "<index>" has value "<cost>"


    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick | status | cost | index |
      | JOKER    | 1       | 1       | 1 2 3 4 5     | 15             | false     | Played | 1.0   | [0]   |

#############################################################################################
  @WagerService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 201 for authorization token 2
    Given I login as a "newPlayerWeb" user
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName         | requiredScenarioState | priority | method | url                   | status | headers          | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
      | testScenarioGetToken | Started               |          | POST   | /authentication/token | 200    | application/json | {\"access_token\": \"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzY29wZSI6WyJvcGVuaWQiXSwiZXhwIjoxNTc0NjgzOTA1LCJqdGkiOiIxM2I5YjQxMy1lNzA4LTQ3YzItODUxZS0yOTAzNzJhODU2MjYiLCJjbGllbnRfaWQiOiJvcGFwIn0.QZ5mp_nVtsRxS9qMMswfsQRSH4qmRxjuup0tczYtf8vWrzXU2VGP58b0_-AzKdl0Y8rlFoIm5mlNqQ7ddNYZMoP4fS986_4z1BDG9GXymuFOvQujYGhYvXYueDg1pT9tXwvthv4y9jFBs7YG3QE0s5eeqjWsC03E2J55TVc91Y2dhbaALnURyZ8Dhew4QsTp-xlz-ORXwVLWLzy0PqlmE3HhAldJoIcC7kM-eUl5_-e8U3RzupgXR9WDaKL-y9n8f-ZKwcRYX5kq2vAGbWxjXxddgiwpJI7OKuMFx7aZ3F1OMs4HRr39gMzPXQ35ne0TqqqRJx7PS8I8oRZyriMyOg\",\"token_type\": \"bearer\",\"expires_in\": \"3599\",\"scope\": \"openid\",\"jti\": \"13b9b413-e708-47c2-851e-290372a85626\"} |


  @WagerService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 200 for Verify Wager 2
    Given I setup "<guid>" guid and timestamp "<timestamp>" wiremock variable
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | guid    | timestamp | scenarioName           | requiredScenarioState | priority | method | url                                | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
      | datenow | datenow   | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers/verification | 200    | application/json,{{guid}} | {\"promotionOutcomes\":[],\"wager\":{\"dbg\":[{\"addOn\": [{\"columns\":21,\"cost\":11.5,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":5,\"selection\":[1,2,3,4,5,6,7]},{\"requested\":1,\"selection\":[15]}],\"quickPick\":false}],\"columns\":21,\"cost\":11.5,\"creationTime\":\"{{guid}}\",\"updatedTime\":\"{{guid}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{guid}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{guid}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\": 1313},\"status\":\"Played\",\"selectionsType\": 2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\":100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":0}} |

  @WagerService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 200 for Play Wager 2
    Given I setup creationTime "<creationTime>" and wagerId and serialNumbers wiremock variables
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | creationTime | scenarioName           | requiredScenarioState | priority | method | url                   | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
      | datenow      | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers | 200    | application/json,{{guid}} | {\"wagerId\":\"{{wagerId}}\",\"pilot\":\"false\",\"promotionOutcomes\":[],\"serialNumbers\":[\"{{serialNumbers}}\"],\"wager\":{\"dbg\":[{\"addOn\":[{\"columns\":21,\"cost\":11.5,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":7,\"selection\":[1,2,3,4,5,6,7]},{\"requested\": 1,\"selection\": [15]}],\"quickPick\":false}],\"columns\":21,\"cost\":11.5,\"creationTime\":\"{{creationTime}}\",\"updatedTime\":\"{{creationTime}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{creationTime}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{creationTime}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\":1313},\"status\":\"Played\",\"selectionsType\":2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\": 100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":\"{{wagerId}}\",\"operator\":1}} |


    #quickpick false for now. true has custom stuff. maybe remove?
  @WagerService @skipIfNotAzure
  Scenario Outline: Place Wager (Lottery Wager)
    Given I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
    And I setup gameId header to "<gameType>"
    And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
    When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And I copy the value of the serialNumber from the response
    And the "gameType" in response body is "<gameType>"
    And the "wager.status" in response body is "<status>"
    And the "wager.cost" in response body is "<cost>"
    And wagerId in response body of Place Wager is the same as stubbed one
    And serialNumbers in response body of Place Wager is the same as stubbed one

    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick | status | cost |
      | JOKER    | 1       | 1       | 1 2 3 4 5 6 7 | 15 16          | false     | Played | 11.5 |


  @WagerService @skipIfAzure
  Scenario Outline: Place Wager (Lottery Wager)
    Given I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
    And I setup gameId header to "<gameType>"
    And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
    When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And I copy the value of the serialNumber from the response
    And the "gameType" in response body is "<gameType>"
    And the "wager.status" in response body is "<status>"
    And the "wager.cost" in response body is "<cost>"

    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick | status | cost |
      | JOKER    | 1       | 1       | 1 2 3 4 5 6 7 | 15 16          | false     | Played | 42.0 |


  Scenario Outline: Joker Winning Bet - Verify Wallet, Prize, GameType, status, captured
    Given I login as an Intralot user
    And I create a PayWinningBet payload with <amount> <taxAmount> "<currency>" "<description>" "<issued>" "<partialPayment>" "<productId>"
    When I make a "POST" call to "PayWinningBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "accountId" in response body array with index "<array0>" has value "AT_MAIN-1"
    And the property "type" in response body array with index "<array0>" has value "PRIZE"
    And the property "status" in response body array with index "<array0>" has value "VERIFIED"
    And the property "captured" in response body array with index "<array0>" has value "true"
    And the property "productId" in response body array with index "<array0>" has value "<productId>"

    @WagerService
    Examples:
      | amount | taxAmount | currency | description | issued  | partialPayment | productId | array0 |
      | 100    | 1         | EUR      | Prize       | datenow | false          | JOKER     | [0]    |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @WagerService @skipIfNotAzure
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 502.89   | 502.89       | 482.17                  | 0.0              | 20.72                | 578.89   | 578.89       | 466.99                  | 0.0              | 111.9                |

    @WagerService @skipIfAzure
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 502.89   | 502.89       | 482.17                  | 0.0              | 20.72                | 557.89   | 557.89       | 445.99                  | 0.0              | 111.9                |


  @WagerService @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  #------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  @WagerService
  Scenario: Logout player
    And I create a Get "specwithgameIdOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @WagerService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 201 for authorization token 3
    Given I login as a "newPlayerWeb" user
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName         | requiredScenarioState | priority | method | url                   | status | headers          | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
      | testScenarioGetToken | Started               |          | POST   | /authentication/token | 200    | application/json | {\"access_token\": \"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzY29wZSI6WyJvcGVuaWQiXSwiZXhwIjoxNTc0NjgzOTA1LCJqdGkiOiIxM2I5YjQxMy1lNzA4LTQ3YzItODUxZS0yOTAzNzJhODU2MjYiLCJjbGllbnRfaWQiOiJvcGFwIn0.QZ5mp_nVtsRxS9qMMswfsQRSH4qmRxjuup0tczYtf8vWrzXU2VGP58b0_-AzKdl0Y8rlFoIm5mlNqQ7ddNYZMoP4fS986_4z1BDG9GXymuFOvQujYGhYvXYueDg1pT9tXwvthv4y9jFBs7YG3QE0s5eeqjWsC03E2J55TVc91Y2dhbaALnURyZ8Dhew4QsTp-xlz-ORXwVLWLzy0PqlmE3HhAldJoIcC7kM-eUl5_-e8U3RzupgXR9WDaKL-y9n8f-ZKwcRYX5kq2vAGbWxjXxddgiwpJI7OKuMFx7aZ3F1OMs4HRr39gMzPXQ35ne0TqqqRJx7PS8I8oRZyriMyOg\",\"token_type\": \"bearer\",\"expires_in\": \"3599\",\"scope\": \"openid\",\"jti\": \"13b9b413-e708-47c2-851e-290372a85626\"} |


  @WagerService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 200 for Verify Wager 3
    Given I setup "<guid>" guid and timestamp "<timestamp>" wiremock variable
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | guid    | timestamp | scenarioName           | requiredScenarioState | priority | method | url                                | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
      | datenow | datenow   | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers/verification | 200    | application/json,{{guid}} | {\"promotionOutcomes\":[],\"wager\":{\"dbg\":[{\"addOn\": [{\"columns\":21,\"cost\":10.5,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":5,\"selection\":[1,2,3,4,5,6,7]},{\"requested\":1,\"selection\":[15]}],\"quickPick\":false}],\"columns\":21,\"cost\":10.5,\"creationTime\":\"{{guid}}\",\"updatedTime\":\"{{guid}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{guid}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{guid}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\": 1313},\"status\":\"Played\",\"selectionsType\": 2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\":100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":0}} |


  @WagerService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 200 for Place Wager 3
    Given I setup creationTime "<creationTime>" and wagerId and serialNumbers wiremock variables
    And I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | creationTime | scenarioName           | requiredScenarioState | priority | method | url                   | status | headers          | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
      | datenow      | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers | 200    | application/json | {\"wagerId\":\"{{wagerId}}\",\"pilot\":\"false\",\"promotionOutcomes\":[],\"serialNumbers\":[\"{{serialNumbers}}\"],\"wager\":{\"dbg\":[{\"addOn\":[{\"columns\":21,\"cost\":10.5,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":7,\"selection\":[1,2,3,4,5,6,7]},{\"requested\": 1,\"selection\": [15]}],\"quickPick\":false}],\"columns\":21,\"cost\":10.5,\"creationTime\":\"{{creationTime}}\",\"updatedTime\":\"{{creationTime}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{creationTime}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{creationTime}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\":1313},\"status\":\"Played\",\"selectionsType\":2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\": 100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":\"{{wagerId}}\",\"operator\":1}} |


    #This is currently a bug!!
  @WagerService
  Scenario Outline: Play wager via v1.WEB (multipleWagers) - Status 401 after Logout
    Given I login as an Intralot user
    And I setup gameId header to "<gameType>"
    And I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
    And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
    When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
    Then the API call is successful with status code 401


    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick |
      | JOKER    | 1       | 1       | 1 2 3 4 5     | 15             | false     |


  @WagerService @skipIfNotAzure
  Scenario Outline: Play wager via v1.WEB (multipleWagers)
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "<gameType>"
    And I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
    And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
    When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "gameType" in response body array with index "<index>" has value "<gameType>"
    And the property "wager.wager.status" in response body array with index "<index>" has value "<status>"
    And the property "wager.wager.cost" in response body array with index "<index>" has value "<cost>"
    And wagerId in response body is the same as stubbed one
    And serialNumbers in response body is the same as stubbed one


    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick | status | cost | index |
      | JOKER    | 1       | 1       | 1 2 3 4 5     | 15             | false     | Played | 10.5 | [0]   |

  @WagerService @skipIfAzure
  Scenario Outline: Play wager via v1.WEB (multipleWagers)
    Given I login as an Intralot user
    And I setup gameId header to "<gameType>"
    And I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
    And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
    When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "gameType" in response body array with index "<index>" has value "<gameType>"
    And the property "wager.wager.status" in response body array with index "<index>" has value "<status>"
    And the property "wager.wager.cost" in response body array with index "<index>" has value "<cost>"

    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick | status | cost | index |
      | JOKER    | 1       | 1       | 1 2 3 4 5     | 15             | false     | Played | 1.0   | [0]   |


  @WagerService
  Scenario: Logout player
    And I create a Get "specwithgameIdOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @WagerService @skipIfNotAzure
  Scenario: Reset Scenarios
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllScenarios" to service "WiremockService"
    Then the API call is successful with status code 200

  @WagerService @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200