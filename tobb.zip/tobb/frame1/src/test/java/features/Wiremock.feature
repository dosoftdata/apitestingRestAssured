@Wiremock
Feature: Wiremock

  Scenario: Get All Stubs
    And I create a Get "wiremockSpec" header
    When I make a "GET" call to "GetAllStubs" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario: Reset Scenarios
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllScenarios" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Add A Stub
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName            | requiredScenarioState | priority | method | url          | status | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | headers          |
      | ToraDepositsResponse200 | requiredScenarioState | 100      | ANY    | /v1/payments | 200    | {\"id\":\"pmt_IEuiimeTppo4AZIHKsKgro2Q\",\"object\":\"payment\",\"captured\":true,\"amount\":5000,\"currency\":\"EUR\",\"description\":\"OPAP wallet deposit id:{{deposit_paymentId}}\",\"meta\":{\"paymentId\":\"{{deposit_paymentId}}\",\"playerId\":\"{{playerId}}\"},\"status\":\"captured\",\"merchant_reference\":\"paymentId:{{deposit_paymentId}}\",\"customer\":null,\"method\":\"card\",\"method_info\":{\"holder_name\":\"TEST PROD\",\"exp_year\":2025,\"exp_month\":6,\"last4\":\"0001\",\"brand\":\"visa\",\"bin\":\"465858\",\"fingerprint\":\"{{Card1_fingerprint}}\"},\"created_at\":\"2019-02-25T13:36:14+00:00\",\"updated_at\":\"2019-02-25T13:36:15+00:00\",\"captured_at\":\"2019-02-25T13:36:15+00:00\",\"refunded\":false,\"refunds\":[],\"refunded_amount\":\"0\",\"fee_amount\":0,\"error_code\":null,\"error_message\":null,\"transaction_id\":\"charge_test_0C2919DE543J66FAA618\"} | application/json |