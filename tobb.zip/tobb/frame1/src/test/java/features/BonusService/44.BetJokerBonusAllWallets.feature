@BonusService
Feature: Bet Joker Bonus All Wallets - Main bonusWallet Opaponline

    @skipIfNotAzure
    Scenario Outline:  Create Joker Bonus
        Given I create a Get "cc_csrftokenSpec" header
        And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
        When I make a "POST" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 200

        Examples:
            | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType    | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
            | PRE_WAGER  | SEGMENT         | NONE              | FIXED            | 2030-12-23T00:00:00 | 1           | numbergames | JOKER   | false     | 30               | 10           | 0      |          |         |

    @skipIfNotAzure
    Scenario Outline: Assign Bonus To User - JOKER
        When I create a Get "api_mainSpec_mainHost" header
        And I create a POST assignBonus payload with new playerId
        And I change url resource of method "AssignBonusSegment" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonusSegment" to service "BonusService"
        Then the API call is successful with status code 200
        And the "totalNumberOfPlayers" in response body is "<totalNumberOfPlayers>"
        And the "numberAssigned" in response body is "<numberAssigned>"
        And the "numberOfAlreadyAssignedBonuses" in response body is "<numberOfAlreadyAssignedBonuses>"

        Examples:
            | totalNumberOfPlayers | numberAssigned | numberOfAlreadyAssignedBonuses |
            | 1                    | 1              | 0                              |

    Scenario Outline: Check Player Active BonusPrize - JOKER
        Given I login as an Api user
        And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
        And I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
        When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 200
        And the property "<responseProperty>" and value "<responseValue>" exist in the response body
        And I copy the value of the bonusPrizeId from the field "id"

        Examples:
            | keys          | values       | responseProperty | responseValue |
            | gameId,status | JOKER,ACTIVE | gameId           | JOKER         |

    Scenario Outline:  Create OpapOnline Bonus
        Given I create a Get "cc_csrftokenSpec" header
        And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
        When I make a "POST" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 200

        Examples:
            | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType    | gameIds    | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
            | PRE_WAGER  | SEGMENT         | NONE              | FIXED            | 2030-12-23T00:00:00 | 1           | numbergames | OPAPONLINE | false     | 60               | 30           | 0      | 1        |         |

    Scenario Outline: Get OpapOnline - status ACTIVE
        Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
        When I make a "GET" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 200
#        And the property "bonusAssignment" in response body array with index "pageItems[0]" has value "SEGMENT"
#        And the property "rewardType" in response body array with index "pageItems[0]" has value "PRE_WAGER"
#        And the property "rewardAmountType" in response body array with index "pageItems[0]" has value "FIXED"
#        And the property "activationTrigger" in response body array with index "pageItems[0]" has value "KYC"
#        And the property "rewardAmount" in response body array with index "pageItems[0]" has value "20.0"
#        And the property "status" in response body array with index "pageItems[0]" has value "ACTIVE"
#        And the property "gameIds[0]" in response body array with index "pageItems[0].allowedGames[0]" has value "PBS"
        And I copy the value of the first bonusActiveId of providerId "<providerId>" and rewardType "<rewardType>" from the response

        Examples:
            | keys   | values | providerId | rewardType |  |
            | status | ACTIVE | OPAPONLINE | PRE_WAGER  |  |

    Scenario Outline: Assign Bonus To User - OPAPONLINE
        When I create a Get "api_mainSpec_mainHost" header
        And I create a POST assignBonus payload with new playerId
        And I change url resource of method "AssignBonusSegment" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonusSegment" to service "BonusService"
        Then the API call is successful with status code 200
        And the "totalNumberOfPlayers" in response body is "<totalNumberOfPlayers>"
        And the "numberAssigned" in response body is "<numberAssigned>"
        And the "numberOfAlreadyAssignedBonuses" in response body is "<numberOfAlreadyAssignedBonuses>"

        Examples:
            | totalNumberOfPlayers | numberAssigned | numberOfAlreadyAssignedBonuses |
            | 1                    | 1              | 0                              |

    Scenario Outline: Check Player Active BonusPrize - OPAPONLINE
        Given I login as an Api user
        And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
        And I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
        When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 200
        And the property "<responseProperty>" and value "<responseValue>" exist in the response body
        And I copy the value of the OpapOnline bonusPrizeId from the field "id"

        Examples:
            | keys          | values            | responseProperty | responseValue |
            | gameId,status | OPAPONLINE,ACTIVE | gameId           | OPAPONLINE    |

    Scenario Outline: Get Player Wallet Balances
        Given I add 3 seconds delay
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "OB"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2        | balance3 | reservedBalance3 | wallet3             |
            | 20.0     | 0.0              | AT_MAIN-1 | 10.0     | 0.0              | AT_BONUS_PRIZE | 30.0     | 0.0              | AT_OPAPONLINE_PRIZE |

    @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Intralot response 201 for authorization token 1
        Given I login as a "newPlayerWeb" user
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                   | status | headers          | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
            | testScenarioGetToken | Started               |          | POST   | /authentication/token | 200    | application/json | {\"access_token\": \"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzY29wZSI6WyJvcGVuaWQiXSwiZXhwIjoxNTc0NjgzOTA1LCJqdGkiOiIxM2I5YjQxMy1lNzA4LTQ3YzItODUxZS0yOTAzNzJhODU2MjYiLCJjbGllbnRfaWQiOiJvcGFwIn0.QZ5mp_nVtsRxS9qMMswfsQRSH4qmRxjuup0tczYtf8vWrzXU2VGP58b0_-AzKdl0Y8rlFoIm5mlNqQ7ddNYZMoP4fS986_4z1BDG9GXymuFOvQujYGhYvXYueDg1pT9tXwvthv4y9jFBs7YG3QE0s5eeqjWsC03E2J55TVc91Y2dhbaALnURyZ8Dhew4QsTp-xlz-ORXwVLWLzy0PqlmE3HhAldJoIcC7kM-eUl5_-e8U3RzupgXR9WDaKL-y9n8f-ZKwcRYX5kq2vAGbWxjXxddgiwpJI7OKuMFx7aZ3F1OMs4HRr39gMzPXQ35ne0TqqqRJx7PS8I8oRZyriMyOg\",\"token_type\": \"bearer\",\"expires_in\": \"3599\",\"scope\": \"openid\",\"jti\": \"13b9b413-e708-47c2-851e-290372a85626\"} |

    @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Intralot response 200 for Verify Wager
        Given I setup "<guid>" guid and timestamp "<timestamp>" wiremock variable
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | guid    | timestamp | scenarioName           | requiredScenarioState | priority | method | url                                | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
            | datenow | datenow   | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers/verification | 200    | application/json,{{guid}} | {\"promotionOutcomes\":[],\"wager\":{\"dbg\":[{\"addOn\": [{\"columns\":21,\"cost\":100,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":5,\"selection\":[1,2,3,4,5,6,7,8]},{\"requested\":1,\"selection\":[15,16,17,18,19]}],\"quickPick\":false}],\"columns\":21,\"cost\":100,\"creationTime\":\"{{guid}}\",\"updatedTime\":\"{{guid}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{guid}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{guid}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\": 1313},\"status\":\"Played\",\"selectionsType\": 2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\":100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":0}} |

    @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Intralot response 200 for Play Wager 2
        Given I setup creationTime "<creationTime>" and wagerId and serialNumbers wiremock variables
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | creationTime | scenarioName           | requiredScenarioState | priority | method | url                   | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
            | datenow      | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers | 200    | application/json,{{guid}} | {\"wagerId\":\"{{wagerId}}\",\"pilot\":\"false\",\"promotionOutcomes\":[],\"serialNumbers\":[\"{{serialNumbers}}\"],\"wager\":{\"dbg\":[{\"addOn\":[{\"columns\":21,\"cost\":100,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":7,\"selection\":[1,2,3,4,5,6,7,8]},{\"requested\": 1,\"selection\": [15,16,17,18,19]}],\"quickPick\":false}],\"columns\":21,\"cost\":100,\"creationTime\":\"{{creationTime}}\",\"updatedTime\":\"{{creationTime}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{creationTime}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{creationTime}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\":1313},\"status\":\"Played\",\"selectionsType\":2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\": 100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":\"{{wagerId}}\",\"operator\":1}} |

    Scenario Outline: Play wager via v1.WEB (multipleWagers) - Insufficient Balance
        Given I login as an Intralot user
        And I setup gameId header to "<gameType>"
        And I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
        And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
        When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
        Then the API call is successful with status code 402
        And the "errorId" in response body is "BALANCE_INSUFFICIENT_JOKER"

        Examples:
            | gameType | betType | boardId | mainSelection   | jokerSelection | quickPick | status | cost | index |
            | JOKER    | 1       | 1       | 1 2 3 4 5 6 7 8 | 15 16 17 18 19 | false     | Played | 100  | [0]   |

    @skipIfNotAzure
    Scenario: Reset Mappings
        And I create a Get "wiremockSpec" header
        When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
        Then the API call is successful with status code 200

    @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Intralot response 201 for authorization token 1
        Given I login as a "newPlayerWeb" user
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                   | status | headers          | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
            | testScenarioGetToken | Started               |          | POST   | /authentication/token | 200    | application/json | {\"access_token\": \"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzY29wZSI6WyJvcGVuaWQiXSwiZXhwIjoxNTc0NjgzOTA1LCJqdGkiOiIxM2I5YjQxMy1lNzA4LTQ3YzItODUxZS0yOTAzNzJhODU2MjYiLCJjbGllbnRfaWQiOiJvcGFwIn0.QZ5mp_nVtsRxS9qMMswfsQRSH4qmRxjuup0tczYtf8vWrzXU2VGP58b0_-AzKdl0Y8rlFoIm5mlNqQ7ddNYZMoP4fS986_4z1BDG9GXymuFOvQujYGhYvXYueDg1pT9tXwvthv4y9jFBs7YG3QE0s5eeqjWsC03E2J55TVc91Y2dhbaALnURyZ8Dhew4QsTp-xlz-ORXwVLWLzy0PqlmE3HhAldJoIcC7kM-eUl5_-e8U3RzupgXR9WDaKL-y9n8f-ZKwcRYX5kq2vAGbWxjXxddgiwpJI7OKuMFx7aZ3F1OMs4HRr39gMzPXQ35ne0TqqqRJx7PS8I8oRZyriMyOg\",\"token_type\": \"bearer\",\"expires_in\": \"3599\",\"scope\": \"openid\",\"jti\": \"13b9b413-e708-47c2-851e-290372a85626\"} |

    @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Intralot response 200 for Verify Wager
        Given I setup "<guid>" guid and timestamp "<timestamp>" wiremock variable
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | guid    | timestamp | scenarioName           | requiredScenarioState | priority | method | url                                | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
            | datenow | datenow   | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers/verification | 200    | application/json,{{guid}} | {\"promotionOutcomes\":[],\"wager\":{\"dbg\":[{\"addOn\": [{\"columns\":21,\"cost\":36,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":5,\"selection\":[1,2,3,4,5,6]},{\"requested\":1,\"selection\":[15,16,17,18,19,20]}],\"quickPick\":false}],\"columns\":21,\"cost\":36,\"creationTime\":\"{{guid}}\",\"updatedTime\":\"{{guid}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{guid}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{guid}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\": 1313},\"status\":\"Played\",\"selectionsType\": 2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\":100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":0}} |

    @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Intralot response 200 for Play Wager 2
        Given I setup creationTime "<creationTime>" and wagerId and serialNumbers wiremock variables
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | creationTime | scenarioName           | requiredScenarioState | priority | method | url                   | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
            | datenow      | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers | 200    | application/json,{{guid}} | {\"wagerId\":\"{{wagerId}}\",\"pilot\":\"false\",\"promotionOutcomes\":[],\"serialNumbers\":[\"{{serialNumbers}}\"],\"wager\":{\"dbg\":[{\"addOn\":[{\"columns\":21,\"cost\":36,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":7,\"selection\":[1,2,3,4,5,6]},{\"requested\": 1,\"selection\": [15,16,17,18,19,20]}],\"quickPick\":false}],\"columns\":21,\"cost\":36,\"creationTime\":\"{{creationTime}}\",\"updatedTime\":\"{{creationTime}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{creationTime}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{creationTime}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\":1313},\"status\":\"Played\",\"selectionsType\":2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\": 100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":\"{{wagerId}}\",\"operator\":1}} |

    Scenario Outline: Play wager via v1.WEB (multipleWagers) - Costs from all wallets - Main, Joker, Opaponline
        Given I login as an Intralot user
        And I setup gameId header to "<gameType>"
        And I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
        And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
        When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
        Then the API call is successful with status code 200
#        And the "gameType" in response body is "<gameType>"
#        And the "wager.status" in response body is "<status>"
#        And the "wager.cost" in response body is "<cost>"
#        And wagerId in response body of Place Wager is the same as stubbed one
#        And serialNumbers in response body of Place Wager is the same as stubbed one

        Examples:
            | gameType | betType | boardId | mainSelection | jokerSelection    | quickPick | status | cost | index |
            | JOKER    | 1       | 1       | 1 2 3 4 5 6   | 15 16 17 18 19 20 | true      | Played | 36   | [0]   |

    @skipIfNotAzure
    Scenario: Reset Mappings
        And I create a Get "wiremockSpec" header
        When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
        Then the API call is successful with status code 200

    Scenario Outline: Get Player Wallet Balances
        Given I add 3 seconds delay
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "OB"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2        | balance3 | reservedBalance3 | wallet3             |
            | 0.0      | 0.0              | AT_MAIN-1 | 0.0      | 0.0              | AT_BONUS_PRIZE | 24.0     | 0.0              | AT_OPAPONLINE_PRIZE |

    Scenario Outline: Wager funds Prize - 20 units to Main wallet
        Given I login as an Api user
        Given I setup gameId header to "JOKER"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "productId" in response body array with index "[0]" has value "<productId>"
        And the property "accountId" in response body array with index "[0]" has value "<accountId>"

        @WagerService
        Examples:
            | accountId | amount | currency | issued  | productId | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | AT_MAIN-1 | 20     | DEFAULT  | datenow | JOKER     | PRIZE | Bet         | TRUE        | VERIFIED | TRUE     | 0.0       | ""     | 0.0         | test                 |

    Scenario Outline: Check Player Active BonusPrize - JOKER
        Given I login as an Api user
        And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
        And I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
        When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 200
        And the property "<responseProperty>" and value "<responseValue>" exist in the response body
        And I copy the value of the OpapOnline bonusPrizeId from the field "id"

        Examples:
            | keys          | values        | responseProperty | responseValue |
            | gameId,status | JOKER,REACHED | gameId           | JOKER         |

    Scenario Outline: Get Player Wallet Balances
        Given I add 3 seconds delay
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "OB"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2        | balance3 | reservedBalance3 | wallet3             |
            | 20.0     | 0.0              | AT_MAIN-1 | 0.0      | 0.0              | AT_BONUS_PRIZE | 24.0     | 0.0              | AT_OPAPONLINE_PRIZE |