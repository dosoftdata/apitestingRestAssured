@BonusService
Feature: Test Bet Cancel OB bonus

    Scenario Outline: Deposit via Payment code - Betting wallet
        Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
        When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
        Then the API call is successful with status code 200
        And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
        And the "amount.amount" in response body is "5.0"
        And the "amount.currency" in response body is "EUR"
        And the "paymentStatus" in response body is "APPROVED"
        And the "paymentType" in response body is "PT_TRANSFER_IN"
        And the "serviceProviderId" in response body is "TORA"
        And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
        And I verify the player id "owner.id" in the response body
        And I copy the value of the paymentId

        Examples:
            | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
            | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 5      | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 5.0      | 0.0              | AT_MAIN-2 | 40.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Bet Reserve successful - mixed accounts
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "-5.0"
        And the property "postBalance" in response body array with index "[0]" has value "0.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "BUY"
        And the property "bonusPrizeId" in response body array with index "[1]" has value "bonusPrizeId"
        And the property "amount" in response body array with index "[1]" has value "-10.0"
        And the property "postBalance" in response body array with index "[1]" has value "30.0"
        And the property "status" in response body array with index "[1]" has value "VERIFIED"
        And the property "type" in response body array with index "[1]" has value "BUY"
        And I verify the bonusPrizeId is the field "[1].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -15.00 | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | true     | 0.0       | "OB"   | 0.0         |                      |

    Scenario Outline: Bet cancel -5 main/ -10 bonus- previous batchId
        Given I add 10 seconds delay
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "amount" in response body array with index "[0]" has value "10.0"
        And the property "postBalance" in response body array with index "[0]" has value "40.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body
        And the property "accountId" in response body array with index "[1]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[1]" has value "5.0"
        And the property "postBalance" in response body array with index "[1]" has value "5.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "CANCEL"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | 15.00  | DEFAULT  | datenow | SPORTSBOOK | CANCEL | Bet         | true        | VERIFIED | true     | 0.0       | "OB"   | 0.0         |                      |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 5.0      | 0.0              | AT_MAIN-2 | 40.0     | 0.0              | AT_BONUS_PRIZE |
