@BonusService
Feature: GET WEB /bonus/rest/v1/bonus-prizes endpoint

    Scenario: Get bonus-prizes
        Given I create a Get "mainSpec" header
        Given I change url resource of method "GetWebBonusPrizes" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 200

    Scenario Outline: Get bonus-prizes - GameId parameter
        Given I create a Get "mainSpec" header with query params "<key>" "<value>"
        Given I change url resource of method "GetWebBonusPrizes" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 200

        Examples:
            | key    | value |
            | gameId | OB    |

    Scenario Outline: Get bonus-prize - status active
        Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
        And I change url resource of method "GetBonusPrizes" of service "BonusService" with configured parameter "playerIdGrandPrize" "GrandPrize"
        And I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
        When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 200
        And I copy the value of the bonusPrizeId from the field "id"

        Examples:
            | key           | value     |
            | status,gameId | ACTIVE,OB |


    Scenario Outline: Get bonuses
        Given I create a Get "mainSpec" header with query params "<key>" "<value>"
        Given I change url resource of method "GetWebBonuses" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonuses" to service "BonusService"
        Then the API call is successful with status code 200

        Examples:
            | key                      | value               |
            | rewardType,gameId,status | PRE_WAGER,OB,ACTIVE |

    @NoRetry
    Scenario Outline: Get bonus-prize - status invalid
        Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
        And I change url resource of method "GetBonusPrizes" of service "BonusService" with configured parameter "playerIdGrandPrize" "GrandPrize"
        Given I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 404

        Examples:
            | key    | value |
            | status | test  |
        
    @NoRetry
    Scenario Outline: Get bonus-prize - status invalid
        Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
        And I change url resource of method "GetBonusPrizes" of service "BonusService" with configured parameter "playerIdGrandPrize" "GrandPrize"
        Given I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 200

        Examples:
            | key    | value |
            | gameId | OB    |
