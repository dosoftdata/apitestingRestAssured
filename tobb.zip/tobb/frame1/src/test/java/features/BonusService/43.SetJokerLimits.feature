@BonusService
Feature: Set Mandatory Limits for Joker

    @skipIfNotAzure
    Scenario Outline: Get Nex contract ID
        Given I create a DrillHost Payload with "<queryType>" and "<query>"
        When I make a "POST" call to "DrillHost" to service "DrillHostService"
        Then the API call is successful with status code 200
        And I copy the value of the contractId from the response


        Examples:
            | queryType | query                                                                                            |
            | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`PLRCONTRACTS` WHERE TYPE = 'TERMS_AND_CONDS_NEX' |

    @skipIfNotAzure
    Scenario Outline: DatabaseBridge - Insert NEX Contract ID for player
        Given I create a DataBridge Payload with "<query>"
        When I make a "POST" call to "DatabaseExecute" to service "DatabaseBridgeService"
        Then the API call is successful with status code 200

        Examples:
            | query                                                                                                                                                                            |
            | INSERT INTO PLRCONTRACTAGREEMENTS (CONTRACTID, PLAYERID, CREATED, UPDATED, STATUS, UPDATEDBYUSERID) VALUES ('newContractId','newPlayerId',SYSDATE,SYSDATE,'VALID','newPlayerId') |
        
    Scenario Outline: Delete AccessAttributes - Success  0
        Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
        Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
        Then the API call is successful with status code 204

        Examples:
            | keys                   | values                                              |
            | userId,operationalUnit | changeit,wallet/exclusive-opap/mandatory-limits/ALL |

    Scenario Outline: Add an AccessAttribute - Success
        Given I login as an Api user
        And I create a Get "api_mainSpec_mainHost" header
        Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
        Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
        Then the API call is successful with status code 200
        And the number of results in a nameless array of objects is 1
        And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
        And the property "operationalUnit" in response body array with index "<index>" has value "wallet/nonexclusive-sportsbook/mandatory-limits"
        And the property "accessType" in response body array with index "<index>" has value "<accessType>"
        And the property "reason" in response body array with index "<index>" has value "<reason>"
        And the property "userId" in response body array with index "<index>" has value "<userId>"
    #And the property "valid.from" in response body array with index "<index>" has value "<valid>"
    #And the property "valid.to" in response body array with index "<index>" has value "<valid>"
    #And the property "updated" in response body array with index "<index>" has value "null"
        And the "<index>.created" to include today's date

        Examples:
            | accessType | operationalUnit                                     | userId | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
            | ALLOW      | wallet/nonexclusive-sportsbook/mandatory-limits/ALL | 3-1    |         |         | 3-1             | 0          | Test   | null  | [0]   |              |
