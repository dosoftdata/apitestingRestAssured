Feature: API endpoint /rest/v1/bonus-prizes

  /**
  **
  ** GET, PUT methods
  **
  ** API endpoints /bonus-prizes error cases
  **
  **/

  @BonusService
  Scenario Outline: Get Bonus Prizes - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code <statusCode>
    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  @BonusService @NoRetry
  Scenario Outline: Get Bonus Prizes - Invalid PlayerId Format
    When I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    Given I change url resource of method "GetBonusPrizes" of service "BonusService" with invalid playerId
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 400
    Then the "errorId" in response body is "INVALID_USERID"
    Then the "description" in response body is "UserId is invalid format should be 1-<userId> ([Error Id: INVALID_USERID])"
    Examples:
      | key           | value     |
      | gameId,status | OB,ACTIVE |


  @BonusService @NoRetry
  Scenario Outline: Get Bonus Prizes - Invalid Status parameter
    When I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    Given I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 404
    Examples:
      | key           | value  |
      | gameId,status | OB,NEW |


  @BonusService @NoRetry
  Scenario Outline: Get Bonus Prizes - Invalid GameId parameter
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    Given I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 404
    Examples:
      | key           | value    |
      | gameId,status | test,NEW |


  @BonusService
  Scenario Outline: Get Active Bonus Prizes
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with configured parameter "playerIdGrandPrize" "GrandPrize"
    Given I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And I copy the value of the bonusPrizeId from the response if exists

    Examples:
      | key    | value    |
      | status | ASSIGNED |


  @BonusService @NoRetry
  Scenario Outline: Update Active Bonus Prizes - Invalid PlayerId Format
    Given I create a Get "api_mainSpec_mainHost" header
    Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with invalid playerId
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
    When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_USERID"
    And the "description" in response body is "UserId is invalid format should be 1-<userId> ([Error Id: INVALID_USERID])"

    Examples:
      | providerId | gameId     | status    | amount | closeAccount |
      | PBS        | SPORTSBOOK | CANCELLED | 0.0    | false        |


  @BonusService @NoRetry
  Scenario Outline: Update Active Bonus Prizes - Bonus Prize not found
    Given I create a Get "api_mainSpec_mainHost" header
    And I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with configured parameter "playerIdGrandPrize" "GrandPrize"
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with invalid bonusPrizeId
    When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "BONUS_PRIZE_NOT_FOUND"
    And the "description" in response body is "Bonus prize not found ([Error Id: BONUS_PRIZE_NOT_FOUND])"

    Examples:
      | providerId | gameId     | status    | amount | closeAccount |
      | PBS        | SPORTSBOOK | CANCELLED | 0.0    | false        |


  @BonusService @NoRetry
  Scenario Outline: Update Active Bonus Prizes - No GameId
    Given I create a Get "api_mainSpec_mainHost" header
    And I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
    When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "VALIDATION_ERROR"
    And the "description" in response body is "Constraint(s) violation occurred during json validation process"

    Examples:
      | providerId | gameId | status    | amount | closeAccount |
      | PBS        |        | CANCELLED | 0.0    | false        |


  @BonusService @NoRetry
  Scenario Outline: Update Active Bonus Prizes - No status
    Given I create a Get "api_mainSpec_mainHost" header
    Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
    When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "VALIDATION_ERROR"
    And the "description" in response body is "Constraint(s) violation occurred during json validation process"

    Examples:
      | providerId | gameId     | status | amount | closeAccount |
      | PBS        | SPORTSBOOK |        | 0.0    | false        |


  @BonusService @NoRetry
  Scenario Outline: Update Active Bonus Prizes - No status
    Given I create a Get "api_mainSpec_mainHost" header
    Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
    When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

    Examples:
      | providerId | gameId | status    | amount | closeAccount |
      | OB         | test   | CANCELLED | 0.0    | false        |


  @BonusService @NoRetry
  Scenario Outline: Get Active Bonus Prizes - Invalid gameId parameter
    When I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetAllowedGame" of service "BonusService" with new playerId
    When I make a "GET" call to "GetAllowedGame" to service "BonusService"
    Then the API call is successful with status code 404


    Examples:
      | key    | value |
      | status | test  |


  @BonusService @NoRetry
  Scenario Outline: Get Active Bonus Prizes - Invalid player format parameter
    When I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetAllowedGame" of service "BonusService" with invalid playerId
    When I make a "GET" call to "GetAllowedGame" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_USERID"
    And the "description" in response body is "UserId is invalid format should be 1-<userId> ([Error Id: INVALID_USERID])"

    Examples:
      | key    | value |
      | gameId | test  |