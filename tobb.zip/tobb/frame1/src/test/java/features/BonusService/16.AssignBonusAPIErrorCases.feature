@BonusService
Feature: Test POST API rest/api/bonus/rest/v1/bonuses/{{bonusActiveId}}/users/1-{{playerId}} endpoint

    @NoRetry
    Scenario Outline: Assign Bonus - Invalid bonusId
        Given I login as an Api user
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
        And I change url resource of method "AssignBonus" of service "BonusService" with new playerId
        And I change url resource of method "AssignBonus" of service "BonusService" with invalid bonusActiveId "numeric"
        When I make a "POST" call to "AssignBonus" to service "BonusService"
        Then the API call is successful with status code 404
        And the "description" in response body is "Bonus not found ([Error Id: BONUS_NOT_FOUND])"
        And the "errorId" in response body is "BONUS_NOT_FOUND"

        Examples:
            | providerId | gameId     | amount |
            | PBS        | SPORTSBOOK | 50     |

    Scenario Outline: Assign Bonus - providerId is missing
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
        And I change url resource of method "AssignBonus" of service "BonusService" with new playerId
        And I change url resource of method "AssignBonus" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonus" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "VALIDATION_ERROR"

        Examples:
            | providerId | gameId     | amount |
            |            | SPORTSBOOK | 50     |

    Scenario Outline: Assign Bonus - gameId is missing
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
        And I change url resource of method "AssignBonus" of service "BonusService" with new playerId
        And I change url resource of method "AssignBonus" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonus" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "VALIDATION_ERROR"

        Examples:
            | providerId | gameId | amount |
            | PBS        |        | 50     |

    Scenario Outline: Assign Bonus - Invalid format playerId
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
        And I change url resource of method "AssignBonus" of service "BonusService" with invalid playerId
        And I change url resource of method "AssignBonus" of service "BonusService" with configured parameter "bonus" "bonusId"
        And I change url resource of method "AssignBonus" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonus" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "INVALID_USERID"
        And the "description" in response body is "UserId is invalid format should be 1-<userId> ([Error Id: INVALID_USERID])"

        Examples:
            | providerId | gameId     | amount |
            | PBS        | SPORTSBOOK | 50     |

    Scenario Outline: Assign Bonus - Amount is zero
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
        And I change url resource of method "AssignBonus" of service "BonusService" with new playerId
        And I change url resource of method "AssignBonus" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonus" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "VALIDATION_ERROR"

        Examples:
            | providerId | gameId     | amount |
            | PBS        | SPORTSBOOK | 0      |

    @NoRetry
    Scenario Outline: Assign Bonus - userId not found
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
        And I change url resource of method "AssignBonus" of service "BonusService" with configured parameter "userId" "1-123456789"
        And I change url resource of method "AssignBonus" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonus" to service "BonusService"
        Then the API call is successful with status code 404
        And the "description" in response body is "User id not found ([Error Id: USER_ID_NOT_FOUND])"
        And the "errorId" in response body is "USER_ID_NOT_FOUND"

        Examples:
            | providerId | gameId     | amount |
            | PBS        | SPORTSBOOK | 50     |

    Scenario Outline: Assign Bonus - invalid json
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
        And I change url resource of method "AssignBonus" of service "BonusService" with configured parameter "userId" "1-123456789"
        And I change url resource of method "AssignBonus" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonus" to service "BonusService"
        Then the API call is successful with status code 400
        And the "description" in response body is "Invalid JSON input"
        And the "errorId" in response body is "INVALID_JSON"

        Examples:
            | providerId | gameId     | amount |
            | PBSsss     | SPORTSBOOK | 50     |

    Scenario Outline: Assign Bonus to user - success
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
        And I change url resource of method "AssignBonus" of service "BonusService" with new playerId
        And I change url resource of method "AssignBonus" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonus" to service "BonusService"
        Then the API call is successful with status code 200

        Examples:
            | providerId | gameId     | amount |
            | PBS        | SPORTSBOOK | 50     |

    Scenario Outline: Assign Bonus to user - already assigned
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
        And I change url resource of method "AssignBonus" of service "BonusService" with new playerId
        And I change url resource of method "AssignBonus" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonus" to service "BonusService"
        Then the API call is successful with status code 400
        And the "description" in response body is "User has already active or assigned a bonusPrize of the provided bonus ([Error Id: BONUS_PRIZE_ALREADY_ASSIGNED])"
        And the "errorId" in response body is "BONUS_PRIZE_ALREADY_ASSIGNED"

        Examples:
            | providerId | gameId     | amount |
            | PBS        | SPORTSBOOK | 50     |

    Scenario Outline: Get MailId For Fetch Hash - Verify origin has value player
        Given I login as a "configuredPlayerCc" user
        And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
        When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
        Then the API call is successful with status code 200
#    And the number of results in the first nested array "<array>" is 1
        And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
        And I copy the value of the mailId from the response with template name "<propertyValue>"

        Examples:
            | key      | value    | property | propertyValue | array | arrayWithIndex |
            | playerId | changeit | origin   | bonus-service | data  | data[0]        |

    Scenario Outline: Get hash For Mail Verification - Verify event name/owner
        Given I create a Get "cc_csrftokenSpec" header
        When I make a "GET" call to "GetHashForMailVerification" to service "CommunicationService"
        Then the API call is successful with status code 200
        And the "<property>" in response body is "<propertyValue>"
        And the "<property2>" in response body is "<propertyValue2>"
        And the "<property3>" in response body is "<propertyValue3>"
        And the "<property4>" in response body is "<propertyValue4>"

        Examples:
            | property | propertyValue                                               | property2 | propertyValue2                            | property3  | propertyValue3 | property4 | propertyValue4 |
            | subject  | Το Bonus σου στο ΤΖΟΚΕΡ είναι διαθέσιμο στο λογαριασμό σου! | eventName | email.bonusprize.activated.prewager_joker | eventOwner | bonus-service  | status    | ACTIVE         |

    Scenario Outline: Edit BonusPrize - Invalid user
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with invalid playerId
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId

        Examples:
            | providerId | gameId     | status    | amount | closeAccount |
            | PBS        | SPORTSBOOK | CANCELLED | 0.0    | false        |