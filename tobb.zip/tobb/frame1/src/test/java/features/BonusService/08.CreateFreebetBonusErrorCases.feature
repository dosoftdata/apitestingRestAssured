Feature: Create Freebet bonus - error cases

  @BonusService
  Scenario Outline: Get Active Bonuses
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "AllowedGames" to service "BonusService"
    Then the API call is successful with status code 200
    And the property "gameType" in response body array with index "[0]" has value "instants"
    And the property "gameIds" in response body array with index "[0]" has value "EM"

    Examples:
      | keys                       | values        |  |  |
      | status,pageNumber,pageSize | ACTIVE,1,1000 |  |  |

  @BonusService @NoRetry
  Scenario Outline:  Create Bonus - missing expiryDays
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Activation expiry needs to have a value of at least 1 when activation trigger is set to deposit ([Error Id: ACTIVATION_EXPIRY_DAYS_REQUIRED])"
    And the "errorId" in response body is "ACTIVATION_EXPIRY_DAYS_REQUIRED"

    Examples:
      | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds   | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
      | FREEBET    | SIGNUP          | DEPOSIT           | FIXED            | 2030-12-23T00:00:00 | 1           | sports   | BETGENIUS | false     | 60               | 5            | 0      |          |         |

  @BonusService @NoRetry
  Scenario Outline:  Create Bonus - missing minimumBetAmount
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with extra fields "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<paymentMethodName>" "<paymentMethodPercentage>" "<activationExpiryDays>" "<activationMinimumAmount>" "<rewardAmountType>" "<bonusValidFrom>" "<bonusValidTo>" "<minimumBets>" "<minimumBetAmount>" "<entryRequirement>" "<bonusCode>" "<gameType>" "<gameIds>" "<singleUse>" "<bonusTerms>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Minimum amount needs to be defined when activation trigger is deposit ([Error Id: MINIMUM_AMOUNT_REQUIRED])"
    And the "errorId" in response body is "MINIMUM_AMOUNT_REQUIRED"

    Examples:
      | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | bonusTerms         | gameType | gameIds   | singleUse | rewardExpiryDays | rewardAmount | entryRequirement | bonusCode   | status | rollOver | bonusValidTo        | bonusValidFrom | minimumBets | activationMinimumAmount | minimumBetAmount | program | paymentMethodName | paymentMethodPercentage | activationExpiryDays |
      | FREEBET    | SIGNUP          | DEPOSIT           | FIXED            | 2030-12-23T00:00:00 | http://www.opap.gr | sports   | BETGENIUS | false     | 60               | 5            | CODE             | testercode1 | 0      | 1        | 2030-12-23T00:00:00 |                |             |                         |                  |         |                   |                         | 10                   |

  @BonusService @NoRetry
  Scenario Outline: Create Bonus - missing rollover
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with extra fields "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<name>" "<percentage>" "<activationExpiryDays>" "<activationMinimumAmount>" "<rewardAmountType>" "<bonusValidFrom>" "<bonusValidTo>" "<minimumBets>" "<minimumBetAmount>" "<entryRequirement>" "<bonusCode>" "<gameType>" "<gameIds>" "<singleUse>" "<bonusTerms>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "This bonus reward does not have rollovers ([Error Id: ROLLOVER_NOT_ALLOWED])"
    And the "errorId" in response body is "ROLLOVER_NOT_ALLOWED"

    Examples:
      | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | bonusTerms         | gameType    | gameIds | singleUse | rewardExpiryDays | rewardAmount | entryRequirement | bonusCode | status | rollOver | bonusValidFrom | minimumBets | activationMinimumAmount | minimumBetAmount | program | name | percentage | activationExpiryDays |
      | FREEBET    | SEGMENT         | BET               | EXT_FIXED        | 2030-12-23T00:00:00 | http://www.opap.gr | numbergames | JOKER   | false     | -1               | 5            |                  |           | 0      | 1        |                |             |                         |                  |         |      |            | 10                   |

  @BonusService @NoRetry
  Scenario Outline: Create Bonus - missing payment methods
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with extra fields "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<name>" "<percentage>" "<activationExpiryDays>" "<activationMinimumAmount>" "<rewardAmountType>" "<bonusValidFrom>" "<bonusValidTo>" "<minimumBets>" "<minimumBetAmount>" "<entryRequirement>" "<bonusCode>" "<gameType>" "<gameIds>" "<singleUse>" "<bonusTerms>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "When activation is deposit, payment methods need to be configured  ([Error Id: ALLOWED_PAYMENT_METHODS_MISSING])"
    And the "errorId" in response body is "ALLOWED_PAYMENT_METHODS_MISSING"

    Examples:
      | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | bonusTerms         | bonusValidFrom | minimumBets | gameType | gameIds   | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program | minimumBetAmount | entryRequirement | bonusCode   | name | percentage | activationExpiryDays | activationMinimumAmount |
      | FREEBET    | SIGNUP          | DEPOSIT           | FIXED            | 2030-12-23T00:00:00 | http://www.opap.gr |                | 1           | sports   | BETGENIUS | false     | 60               | 5            | 0      |          |         |                  | CODE             | testercode1 |      |            | 10                   | 5.0                     |

  @BonusService @NoRetry
  Scenario Outline: Create Bonus - missing bonusCode
    Given I create a POST AddBonus payload with extra fields "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<paymentMethodName>" "<paymentMethodPercentage>" "<activationExpiryDays>" "<activationMinimumAmount>" "<rewardAmountType>" "<bonusValidFrom>" "<bonusValidTo>" "<minimumBets>" "<minimumBetAmount>" "<entryRequirement>" "<bonusCode>" "<gameType>" "<gameIds>" "<singleUse>" "<bonusTerms>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Entry requriement is bonus code but no code is available ([Error Id: BONUS_CODE_MISSING])"
    And the "errorId" in response body is "BONUS_CODE_MISSING"

    Examples:
      | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | bonusTerms         | bonusValidFrom | minimumBets | gameType | gameIds   | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program | minimumBetAmount | entryRequirement | bonusCode | paymentMethodName | paymentMethodPercentage | activationExpiryDays | activationMinimumAmount |
      | FREEBET    | SIGNUP          | DEPOSIT           | FIXED            | 2030-12-23T00:00:00 | http://www.opap.gr |                | 1           | sports   | BETGENIUS | false     | 60               | 5            | 0      | 1        |         |                  | CODE             |           | CARD              | 100                     | 10                   | 5.0                     |

  @BonusService @NoRetry
  Scenario Outline: Create Bonus - missing percentage
    Given I create a POST AddBonus payload with extra fields "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<paymentMethodName>" "<paymentMethodPercentage>" "<activationExpiryDays>" "<activationMinimumAmount>" "<rewardAmountType>" "<bonusValidFrom>" "<bonusValidTo>" "<minimumBets>" "<minimumBetAmount>" "<entryRequirement>" "<bonusCode>" "<gameType>" "<gameIds>" "<singleUse>" "<bonusTerms>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Amount type percentage, but no percentage set ([Error Id: PERCENTAGE_MISSING])"
    And the "errorId" in response body is "PERCENTAGE_MISSING"

    Examples:
      | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | bonusTerms         | bonusValidFrom | minimumBets | gameType | gameIds   | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program | minimumBetAmount | entryRequirement | bonusCode   | paymentMethodName | paymentMethodPercentage | activationExpiryDays | activationMinimumAmount |
      | FREEBET    | SIGNUP          | DEPOSIT           | PERCENTAGE       | 2030-12-23T00:00:00 | http://www.opap.gr |                | 1           | sports   | BETGENIUS | false     | 60               | 5            | 0      |          |         |                  | CODE             | testercode1 | CARD              |                         | 10                   | 5.0                     |

  @BonusService @NoRetry
  Scenario Outline: Create Bonus - wrong paymentMethod percentage
    Given I create a POST AddBonus payload with extra fields "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<paymentMethodName>" "<paymentMethodPercentage>" "<activationExpiryDays>" "<activationMinimumAmount>" "<rewardAmountType>" "<bonusValidFrom>" "<bonusValidTo>" "<minimumBets>" "<minimumBetAmount>" "<entryRequirement>" "<bonusCode>" "<gameType>" "<gameIds>" "<singleUse>" "<bonusTerms>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Payment methods are invalid. ([Error Id: INVALID_PAYMENT_METHOD])"
    And the "errorId" in response body is "INVALID_PAYMENT_METHOD"

    Examples:
      | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | bonusTerms         | bonusValidFrom | minimumBets | gameType | gameIds   | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program | minimumBetAmount | entryRequirement | bonusCode   | paymentMethodName | paymentMethodPercentage | activationExpiryDays | activationMinimumAmount |
      | FREEBET    | SIGNUP          | DEPOSIT           | PERCENTAGE       | 2030-12-23T00:00:00 | http://www.opap.gr |                | 1           | sports   | BETGENIUS | false     | 60               | 5            | 0      |          |         |                  | CODE             | testercode1 | test              | 100                     | 10                   | 5.0                     |
