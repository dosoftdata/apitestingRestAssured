@BonusService
Feature: Test Bet Cancel

    Scenario Outline: Set mandatory limits for SPORTSBOOK/CASINO
        Given I setup gameId header to "CASINO"
        And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
        And I change url resource of method "PlayerLimitsV2" of service "LimitService" with new playerId
        When I make a "POST" call to "PlayerLimitsV2" to service "LimitService"
        Then the API call is successful with status code 200

        Examples:
            | limitTypes             | limitPeriods            | limitAmounts         | gameIds             |
            | TIME,DEPOSIT,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY | 86000,2000,1000,1000 | ,,SPORTSBOOK,CASINO |

    Scenario Outline: Deposit via Payment code - Betting wallet
        Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
        When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
        Then the API call is successful with status code 200
        And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
        And the "amount.amount" in response body is "5.0"
        And the "amount.currency" in response body is "EUR"
        And the "paymentStatus" in response body is "APPROVED"
        And the "paymentType" in response body is "PT_TRANSFER_IN"
        And the "serviceProviderId" in response body is "TORA"
        And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
        And I verify the player id "owner.id" in the response body
        And I copy the value of the paymentId

        Examples:
            | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
            | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 5      | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 5.0      | 0.0              | AT_MAIN-2 | 40.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Wager funds - Bet Reserve successful - mixed accounts
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "-5.0"
        And the property "postBalance" in response body array with index "[0]" has value "5.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "BUY"
        And the property "bonusPrizeId" in response body array with index "[1]" has value "bonusPrizeId"
        And the property "amount" in response body array with index "[1]" has value "-15.0"
        And the property "postBalance" in response body array with index "[1]" has value "40.0"
        And the property "status" in response body array with index "[1]" has value "VERIFIED"
        And the property "type" in response body array with index "[1]" has value "BUY"
        And I verify the bonusPrizeId is the field "[1].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -5.00  | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | 0.0       | "PBS"  | -15.0       |                      |

    Scenario Outline: CaptureBet -  Verify type & status
        Given I create a CaptureBet payload with <amount>
        And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
        And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
        When I make a "POST" call to "CaptureBet" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
        And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

        Examples:
            | amount | type | status   | arrayWithIndex |
            | -20    | BUY  | VERIFIED | [0]            |

    Scenario Outline: Bet cancel -5 main/ -15 bonus- previous batchId
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "amount" in response body array with index "[0]" has value "15.0"
        And the property "postBalance" in response body array with index "[0]" has value "40.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body
        And the property "accountId" in response body array with index "[1]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[1]" has value "5.0"
        And the property "postBalance" in response body array with index "[1]" has value "5.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "CANCEL"


        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -5.00  | DEFAULT  | datenow | SPORTSBOOK | CANCEL | Bet         | true        | VERIFIED | true     | 0.0       | "PBS"  | -15.0       |                      |

#    Scenario Outline: Bet cancel -5 main/ -15 bonus- previous batchId
#        Given I setup gameId header to "<xGameId>"
#        And I create a Get "api_specWithGameId_idempotent" header
#        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
#        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
#        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
#        Then the API call is successful with status code 200
#        And the property "amount" in response body array with index "[0]" has value "15.0"
#        And the property "postBalance" in response body array with index "[0]" has value "40.0"
#        And the property "status" in response body array with index "[0]" has value "VERIFIED"
#        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body
#        And the property "accountId" in response body array with index "[1]" has value "AT_MAIN-2"
#        And the property "amount" in response body array with index "[1]" has value "5.0"
#        And the property "postBalance" in response body array with index "[1]" has value "5.0"
#        And the property "status" in response body array with index "[0]" has value "VERIFIED"
#        And the property "type" in response body array with index "[0]" has value "CANCEL"
#
#
#        Examples:
#            | xGameId    | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
#            | SPORTSBOOK | AT_MAIN-2 | -5.00  | DEFAULT  | datenow | SPORTSBOOK | CANCEL | Bet         | true        | VERIFIED | true     | 0.0       | "PBS"  | -15.0       |                      |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 5.0      | 0.0              | AT_MAIN-2 | 40.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Bet Reserve Successful- mixed amounts 5 main 15 bonus
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "-5.0"
        And the property "postBalance" in response body array with index "[0]" has value "5.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "BUY"
        And the property "bonusPrizeId" in response body array with index "[1]" has value "bonusPrizeId"
        And the property "amount" in response body array with index "[1]" has value "-15.0"
        And the property "postBalance" in response body array with index "[1]" has value "40.0"
        And the property "status" in response body array with index "[1]" has value "VERIFIED"
        And the property "type" in response body array with index "[1]" has value "BUY"
        And I verify the bonusPrizeId is the field "[1].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -5.00  | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | 0.0       | "PBS"  | -15.0       |                      |

    Scenario Outline: CaptureBet -  Verify type & status
        Given I create a CaptureBet payload with <amount>
        And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
        And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
        When I make a "POST" call to "CaptureBet" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
        And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

        Examples:
            | amount | type | status   | arrayWithIndex |
            | -20    | BUY  | VERIFIED | [0]            |

    Scenario Outline: Bet cancel 0 main/ -15 bonus- previous batchId
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" does not have value "AT_MAIN-2"
        And the property "accountId" in response body array with index "[0]" does not have value "AT_MAIN-1"
        And the property "amount" in response body array with index "[0]" has value "15.0"
        And the property "postBalance" in response body array with index "[0]" has value "40.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "CANCEL"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | 0.00   | DEFAULT  | datenow | SPORTSBOOK | CANCEL | Bet         | true        | VERIFIED | true     | 0.0       | "PBS"  | -15.0       |                      |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 0.0      | 0.0              | AT_MAIN-2 | 40.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Deposit via Payment code - Betting wallet
        Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
        When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
        Then the API call is successful with status code 200
        And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
        And the "amount.amount" in response body is "5.0"
        And the "amount.currency" in response body is "EUR"
        And the "paymentStatus" in response body is "APPROVED"
        And the "paymentType" in response body is "PT_TRANSFER_IN"
        And the "serviceProviderId" in response body is "TORA"
        And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
        And I verify the player id "owner.id" in the response body
        And I copy the value of the paymentId

        Examples:
            | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
            | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 5      | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

    Scenario Outline: Bet Reserve Successful- mixed amounts 5 main 15 bonus
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "-5.0"
        And the property "postBalance" in response body array with index "[0]" has value "5.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "BUY"
        And the property "bonusPrizeId" in response body array with index "[1]" has value "bonusPrizeId"
        And the property "amount" in response body array with index "[1]" has value "-15.0"
        And the property "postBalance" in response body array with index "[1]" has value "40.0"
        And the property "status" in response body array with index "[1]" has value "VERIFIED"
        And the property "type" in response body array with index "[1]" has value "BUY"
        And I verify the bonusPrizeId is the field "[1].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -5.00  | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | 0.0       | "PBS"  | -15.0       |                      |

    Scenario Outline: CaptureBet -  Verify type & status
        Given I create a CaptureBet payload with <amount>
        And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
        And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
        When I make a "POST" call to "CaptureBet" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
        And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

        Examples:
            | amount | type | status   | arrayWithIndex |
            | -20    | BUY  | VERIFIED | [0]            |

    Scenario Outline: Bet cancel -5 main/ 0 bonus- previous batchId
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "5.0"
        And the property "postBalance" in response body array with index "[0]" has value "5.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "CANCEL"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | 5.00   | DEFAULT  | datenow | SPORTSBOOK | CANCEL | Bet         | true        | VERIFIED | true     | 0.0       | "PBS"  | 0.00        |                      |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 5.0      | 0.0              | AT_MAIN-2 | 25.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Bet Reserve Successful- mixed amounts 5 main 15 bonus
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "-5.0"
        And the property "postBalance" in response body array with index "[0]" has value "5.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "BUY"
        And the property "bonusPrizeId" in response body array with index "[1]" has value "bonusPrizeId"
        And the property "amount" in response body array with index "[1]" has value "-15.0"
        And the property "postBalance" in response body array with index "[1]" has value "25.0"
        And the property "status" in response body array with index "[1]" has value "VERIFIED"
        And the property "type" in response body array with index "[1]" has value "BUY"
        And I verify the bonusPrizeId is the field "[1].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -5.00  | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | 0.0       | "PBS"  | -15.0       |                      |

    Scenario Outline: CaptureBet -  Verify type & status
        Given I create a CaptureBet payload with <amount>
        And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
        And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
        When I make a "POST" call to "CaptureBet" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
        And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

        Examples:
            | amount | type | status   | arrayWithIndex |
            | -20    | BUY  | VERIFIED | [0]            |

    Scenario Outline: Bet cancel -15 main/ -20 bonus- previous batchId
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" does not have value "AT_MAIN-2"
        And the property "accountId" in response body array with index "[0]" does not have value "AT_MAIN-1"
        And the property "amount" in response body array with index "[0]" has value "20.0"
        And the property "postBalance" in response body array with index "[0]" has value "30.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "CANCEL"
        And the property "accountId" in response body array with index "[1]" has value "<accountId>"
        And the property "amount" in response body array with index "[1]" has value "15.0"
        And the property "postBalance" in response body array with index "[1]" has value "15.0"
        And the property "status" in response body array with index "[1]" has value "VERIFIED"
        And the property "type" in response body array with index "[1]" has value "CANCEL"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | 15.00  | DEFAULT  | datenow | SPORTSBOOK | CANCEL | Bet         | true        | VERIFIED | true     | 0.0       | "PBS"  | 20.00       |                      |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 15.0     | 0.0              | AT_MAIN-2 | 30.0     | 0.0              | AT_BONUS_PRIZE |