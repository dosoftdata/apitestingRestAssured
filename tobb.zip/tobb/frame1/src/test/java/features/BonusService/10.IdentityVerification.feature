Feature: Identity Verification

  ############################New Player#####################################

  @BonusService
  Scenario Outline: Get Player Levels - Temporary Account
    Given I login as a "newPlayerWeb" user
    Given I create a Get "specWithGameId" header
    And I change url resource of method "GetPlayerLevels" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerLevels" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "<key>" in response body is "<value>"

    Examples:
      | key         | value             |
      | playerLevel | TEMPORARY_ACCOUNT |

  @BonusService
  Scenario Outline: Get BO Pending Verifications of Player - Verify IBAN values
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Iban Pending Verification with status "<status1>" or status "<status2>" and iban "<iban>"

    Examples:
      | key              | value | status1 | status2     | iban                        |
      | verificationType | IBAN  | PENDING | IN_PROGRESS | GR2202655559367039137283047 |


  @BonusService
  Scenario Outline: Verify IBAN Account
    Given I login as an Api user
    And I create a Post VerifyIBAN payload with iban "<iban>"
    And I change url resource of method "VerifyIBAN" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerifyIBAN" to service "PlayerService"
    Then the API call is successful with status code 204

    Examples:
      | iban                        |
      | GR2202655559367039137283047 |

  @BonusService
  Scenario Outline: Upload id Documents (Other + Utility_Bill)
    Given I create a UploadDocumentsWeb payload with "<fileName>" "<type>"
    And I change url resource of method "UploadDocumentsWeb" of service "PlayerService" with new playerId
    When I make a "POST" call to "UploadDocumentsWeb" to service "PlayerService"
    Then the API call is successful with status code 200
    Examples:
      | fileName           | type         |
      | IDverification.JPG | OTHER        |
      | IDverification.JPG | UTILITY_BILL |

  @BonusService
  Scenario Outline: Get BO Pending Verifications of Player - Verify Identity values
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Identity Pending Verification with status "<status>"

    Examples:
      | key              | value    | status                 |
      | verificationType | IDENTITY | WAITING_ADMIN_APPROVAL |

  @BonusService
  Scenario Outline: Get Uploaded documents - Verify Card Documents (OTHER + UTILITY_BILL)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUploadedDocuments" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetUploadedDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Uploaded Documents with "<types>" "<fileName>" "<fileType>"

    Examples:
      | types              | fileName           | fileType   |
      | OTHER,UTILITY_BILL | IDverification.JPG | image/jpeg |


########### subType : This variable is not send in request but to specify the variable in which the verification is done
########### subType values : FRONT,BACK (for CARD type) - OTHER,UTILITY_BILL (for IDENTITY type)
  @BonusService
  Scenario Outline: Verify Id Documents - IDENTITY - OTHER
    Given I create a VerifyDocuments payload with "<verificationType>" "<statusDescription>" and subcategory "<subType>"
    And I change url resource of method "VerifyDocuments" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerifyDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "verificationType" in response body is "<verificationType>"
    And the "documentType" in response body is "<subType>"
    And the "statusDescription" in response body is "<statusDescription>"
    And the "status" in response body is "<statusValue>"


    Examples:
      | verificationType | statusDescription                | subType      | statusValue |
      | IDENTITY         | Approve uploaded document for ID | OTHER        | APPROVED    |
      | IDENTITY         | Approve uploaded document for ID | UTILITY_BILL | APPROVED    |

  @BonusService
  Scenario Outline: Get Player Levels - Temporary Account
    Given I create a Get "specWithGameId" header
    And I change url resource of method "GetPlayerLevels" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerLevels" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "<key>" in response body is "<value>"

    Examples:
      | key         | value             |
      | playerLevel | TEMPORARY_ACCOUNT |

  @BonusService
  Scenario Outline: Confirm Verification of Player's Id - Verify Type/Status
    Given I create a VerificationConfirm payload with "<verificationType>"
    And I change url resource of method "VerificationConfirm" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerificationConfirm" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "verificationType" in response body is "<verificationType>"
    And the "status" in response body is "<statusValue>"

    Examples:
      | verificationType | statusValue |
      | IDENTITY         | VERIFIED    |

  @BonusService
  Scenario Outline: Get Player Levels - Full Account
    Given I create a Get "specWithGameId" header
    And I change url resource of method "GetPlayerLevels" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerLevels" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "<key>" in response body is "<value>"

    Examples:
      | key         | value        |
      | playerLevel | FULL_ACCOUNT |


