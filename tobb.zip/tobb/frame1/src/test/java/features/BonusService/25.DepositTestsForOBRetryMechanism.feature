@BonusService
Feature: Test Deposits for OB Retry Mechanism

    @skipIfNotAzure
    Scenario: Reset Mappings
        And I create a Get "wiremockSpec" header
        When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
        Then the API call is successful with status code 200

    @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Mock authentication token
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                   | status | headers          | body                                                                                                                                                                                                                                                                                                     |
            | testScenarioGetToken | Started               |          | ANY    | /bonus_api/auth/login | 500    | application/json | {\"auth_token\": \"eyJ0aW1lc3RhbXAiOiAxNTg2MTgyMTk5LCAiZW5jcnlwdGVkX3Bhc3N3b3JkIjogIlJZYithc3lIekREVUJoc1NjT01HUmtoaVhlTmFkclRWRU1HYmtnaU1USkMrRT0iLCAidXNlcl9pZCI6IDcwLCAiaXNfZXh0ZXJuYWwiOiBmYWxzZSwgInNlc3Npb25faWQiOiAiNzI1MCJ9._wUIyJ6sD57FSGb9ca-jSBOXEL9VcvVqfuKoaKkJBDs=\",\"success\":\"true\"} |

    @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Mock for deposit event - 500
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                       | status | headers          | body |
            | testScenarioGetToken | Started               |          | ANY    | /bonus_api/events/deposit | 500    | application/json |      |

    @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Mock for deposit event OB - 500
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                    | status | headers          | body |
            | testScenarioGetToken | Started               |          | ANY    | /opap/wallet/deposited | 500    | application/json |      |

    Scenario Outline: Set mandatory limits for SPORTSBOOK/CASINO
        Given I setup gameId header to "SPORTSBOOK"
        And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
        And I change url resource of method "PlayerLimitsV2" of service "LimitService" with new playerId
        When I make a "POST" call to "PlayerLimitsV2" to service "LimitService"
        Then the API call is successful with status code 200

        Examples:
            | limitTypes             | limitPeriods            | limitAmounts         | gameIds             |
            | TIME,DEPOSIT,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY | 86000,2000,1000,1000 | ,,SPORTSBOOK,CASINO |

    Scenario Outline: Deposit via Payment code - Betting wallet
        Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
        When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
        Then the API call is successful with status code 200
        And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
        And the "amount.amount" in response body is "150.0"
        And the "amount.currency" in response body is "EUR"
        And the "paymentStatus" in response body is "APPROVED"
        And the "paymentType" in response body is "PT_TRANSFER_IN"
        And the "serviceProviderId" in response body is "TORA"
        And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
        And I verify the player id "owner.id" in the response body
        And I copy the value of the paymentId

        Examples:
            | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
            | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 150    | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 150.0    | 0.0              | AT_MAIN-2 | 50.0     | 0.0              | AT_BONUS_PRIZE |

    @skipIfNotAzure
    Scenario Outline: SQL query after 1st failed deposit - deposit event not sent to PBS/EM
        Given I create a DrillHost Payload with "<queryType>" and "<query>"
        When I make a "POST" call to "DrillHost" to service "DrillHostService"
        Then the API call is successful with status code 200
        And the property "TYPE" in response body array with index "rows[0]" does not have value "1.0"
        And the property "TYPE" in response body array with index "rows[1]" does not have value "4.0"

        Examples:
            | queryType | query                                                                                    |  |  |
            | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`BNSBONUSEVENTS` ORDER BY ID DESC LIMIT 2 |  |  |

    Scenario Outline: 2nd Deposit via Payment code - Betting wallet
        Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
        When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
        Then the API call is successful with status code 200
        And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
        And the "amount.amount" in response body is "50.0"
        And the "amount.currency" in response body is "EUR"
        And the "paymentStatus" in response body is "APPROVED"
        And the "paymentType" in response body is "PT_TRANSFER_IN"
        And the "serviceProviderId" in response body is "TORA"
        And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
        And I verify the player id "owner.id" in the response body
        And I copy the value of the paymentId

        Examples:
            | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
            | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 50     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 200.0    | 0.0              | AT_MAIN-2 | 50.0     | 0.0              | AT_BONUS_PRIZE |

    @skipIfNotAzure
    Scenario Outline: SQL query after 2nd failed deposit - deposit event to PBS/EM
        Given I create a DrillHost Payload with "<queryType>" and "<query>"
        When I make a "POST" call to "DrillHost" to service "DrillHostService"
        Then the API call is successful with status code 200
        And the property "TYPE" in response body array with index "rows[0]" has value "7.0"
        And the property "STATUS" in response body array with index "rows[0]" has value "2.0"
        And the property "EXTTRANSACTIONID" in response body array with index "rows[0]" contains value "pam-bns"
        And the property "TYPE" in response body array with index "rows[0]" has value "4.0"
        And the property "STATUS" in response body array with index "rows[1]" has value "2.0"
        And the property "EXTTRANSACTIONID" in response body array with index "rows[1]" contains value "pam-em"

        Examples:
            | queryType | query                                                                                    |  |  |
            | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`BNSBONUSEVENTS` ORDER BY ID DESC LIMIT 2 |  |  |

    @skipIfNotAzure
    Scenario: Reset Mappings
        And I create a Get "wiremockSpec" header
        When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
        Then the API call is successful with status code 200

    @skipIfNotAzure
    Scenario Outline: Wiremock Stub - Mock authentication token
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                   | status | headers          | body                                                                                                                                                                                                                                                                                                     |
            | testScenarioGetToken | Started               |          | ANY    | /bonus_api/auth/login | 500    | application/json | {\"auth_token\": \"eyJ0aW1lc3RhbXAiOiAxNTg2MTgyMTk5LCAiZW5jcnlwdGVkX3Bhc3N3b3JkIjogIlJZYithc3lIekREVUJoc1NjT01HUmtoaVhlTmFkclRWRU1HYmtnaU1USkMrRT0iLCAidXNlcl9pZCI6IDcwLCAiaXNfZXh0ZXJuYWwiOiBmYWxzZSwgInNlc3Npb25faWQiOiAiNzI1MCJ9._wUIyJ6sD57FSGb9ca-jSBOXEL9VcvVqfuKoaKkJBDs=\",\"success\":\"true\"} |

    @skipIfNotAzure
    Scenario Outline: Mock service ticket URL for OB - Request a new Ticket Getting Ticket (TGT)
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url             | status | headers   | body |
            | testScenarioGetToken | Started               |          | ANY    | /cas/v1/tickets | 201    | text/html |      |

    @skipIfNotAzure
    Scenario Outline: Mock service ticket URL for OB - Request a new Service Ticket
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                                                                                                                                                                       | status | headers   | body                                                                                                             |
            | testScenarioGetToken | Started               |          | ANY    | /cas/v1/tickets/TGT-49838-cKuWjpR8Xrt-cLYhOcnbSCPG-EOHHs6qDmFFJTFrMaJDkbQAUqUt4nmJPI7r9MHZSmc-backbonebackoffice-02.internal.devint01.yellow.opap.e02cp.sb-live.obenv.net | 201    | text/html | ST-46812-HOT3xexCz4LGZxp7whZeuG9-6DU-backbonebackoffice-01.internal.devint01.yellow.opap.e02cp.sb-live.obenv.net |

    @skipIfNotAzure
    Scenario Outline: Mock service sports URL for OB - reqUtilPing
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                  | status | headers   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
            | testScenarioGetToken | Started               |          | ANY    | /oxixmlserver_sports | 200    | text/html | <?xml version=\"1.0\" encoding=\"UTF-8\" ?> <!DOCTYPE oxip SYSTEM \"oxip.dtd\"> <oxip version=\"6.0\"> <response requestTime=\"0.2571\"> <returnStatus> <code>001</code> <message>success</message> <debug>03/15-14:19:48 </debug> </returnStatus> <respClientAuth> <token>kutcQ9s6B0lvGUjZLM+i2LLOayq1WK3reUsBQbBRWKVxFgsIvo4X4GQ6Kcf1RKtrV4YCfgzDRHek956tVulQRdxJTJEhHZQRlL3jj0/O0D6T</token> </respClientAuth> <respUtilPing> <clientIP>172.23.115.23</clientIP> <component name=\"db\" status=\"OK\"/> </respUtilPing> </response> </oxip> |

    @skipIfNotAzure
    Scenario Outline: Mock for deposit event- status 200 PBS
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                       | status | headers   | body |
            | testScenarioGetToken | Started               |          | ANY    | /bonus_api/events/deposit | 200    | text/html |      |

    @skipIfNotAzure
    Scenario Outline: Mock for deposit event- status 200 EM
        Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
        When I make a "POST" call to "AddAStub" to service "WiremockService"
        Then the API call is successful with status code 201

        Examples:
            | scenarioName         | requiredScenarioState | priority | method | url                    | status | headers          | body                                                                              |
            | testScenarioGetToken | Started               |          | ANY    | /opap/wallet/deposited | 200    | application/json | {\"attempts\":[{\"bonusCode\":\"DEP_BON_TEST_CC\",\"bonusWalletId\":1793400005}]} |
