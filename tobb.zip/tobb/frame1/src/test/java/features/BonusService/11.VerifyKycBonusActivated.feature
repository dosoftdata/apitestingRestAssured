Feature: Verify KYC Bonus is activated

  ## Verify Bonus is activated after full account KYC
  @BonusService
  Scenario Outline: Get Bonus OB - Verify Allowed Games
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "AllowedGames" of service "BonusService" with new bonusActiveId
    When I make a "GET" call to "AllowedGames" to service "BonusService"
    Then the API call is successful with status code 200
    And the property "gameType" in response body array with index "[0]" has value "<gameId>"
    And the property "gameIds" in response body array with index "[0]" has value "<providerId>"

    Examples:
      | keys                              | values            | providerId | gameId |
      | gameId,status,pageNumber,pageSize | PBS,ACTIVE,1,1000 | PBS        | sports |


  @BonusService
  Scenario Outline: Cancel BonusKYC BonusPrize
    Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
    When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And I verify the 1-playerId is the field "userId" in the response body
    And I verify the bonusPrizeId is the field "bonusPrizeId" in the response body
    And the "status" in response body is "<status>"

    Examples:
      | providerId | gameId     | status    | amount | closeAccount |
      | PBS        | SPORTSBOOK | CANCELLED | 0.0    | false        |


  @BonusService
  Scenario: Cancel BonusKYC
    Given I login as a "configuredPlayerCc" user
    And I create a PUT cancelBonus payload
    And I change url resource of method "UpdateCCBonus" of service "BonusService" with new bonusActiveId
    And I make a "PUT" call to "UpdateCCBonus" to service "BonusService"
    Then the API call is successful with status code 200
    And the "status" in response body is "CANCELLED"
