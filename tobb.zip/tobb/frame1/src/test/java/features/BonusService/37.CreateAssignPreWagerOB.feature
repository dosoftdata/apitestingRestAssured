@BonusService
Feature: Create and assign Prewager OB bonus

    Scenario Outline: Create Bonus - rollOver is missing
        Given I create a Get "cc_csrftokenSpec" header
        And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
        When I make a "POST" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "ROLLOVER_MISSING"
        And the "description" in response body is "For this bonus reward type you must define rollover ([Error Id: ROLLOVER_MISSING])"

        Examples:
            | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
            | PRE_WAGER  | SEGMENT         | NONE              | FIXED            | 2030-12-23T00:00:00 | 1           | sports   | OB      | false     | -1               | 0            | 0      |          |         |


    Scenario Outline: Create Bonus - minimumBets is missing
        Given I create a Get "cc_csrftokenSpec" header
        And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
        When I make a "POST" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "INVALID_MINIMUM_BETS"
        And the "description" in response body is "Minimum bets is missing or must be greater than zero ([Error Id: INVALID_MINIMUM_BETS])"

        Examples:
            | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
            | PRE_WAGER  | SEGMENT         | NONE              | FIXED            | 2030-12-23T00:00:00 |             | sports   | OB      | false     | -1               | 0            | 0      | 1        |         |


    Scenario Outline: Create Bonus - Amount is missing
        Given I create a Get "cc_csrftokenSpec" header
        And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
        When I make a "POST" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "AMOUNT_MISSING"
        And the "description" in response body is "Amount type fixed, but no amount set ([Error Id: AMOUNT_MISSING])"

        Examples:
            | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
            | PRE_WAGER  | SEGMENT         | NONE              | FIXED            | 2030-12-23T00:00:00 | 1           | sports   | OB      | false     | -1               | 0            | 0      | 1        |         |


    Scenario Outline: Create Bonus - success
        Given I create a Get "cc_csrftokenSpec" header
        And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
        When I make a "POST" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 200

        Examples:
            | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
            | PRE_WAGER  | SEGMENT         | NONE              | FIXED            | 2030-12-23T00:00:00 | 1           | sports   | OB      | false     | 60               | 50           | 0      | 1        |         |


    Scenario Outline: Get Active Bonuses - Get BonusActiveId
        Given I login as a "configuredPlayerCc" user
        Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
        When I make a "GET" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 200
#    And the "totalRowCount" in response body is "1"
    # FIll the correct bonusActive details
        And I copy the value of the first bonusActiveId of providerId "<providerId>" and rewardType "<rewardType>" from the response
        And I copy the value of the first bonusName of providerId "<providerId>" and rewardType "<rewardType>" from the response

        Examples:
            | keys                       | values        | providerId | rewardType |
            | status,pageNumber,pageSize | ACTIVE,1,1000 | OB         | PRE_WAGER  |

    Scenario Outline: Get Bonus OB - Verify Allowed Games - success
        Given I create a Get "cc_csrftokenSpec" header
        And I change url resource of method "AllowedGames" of service "BonusService" with configured parameter "bonus" "bonusId"
        And I change url resource of method "AllowedGames" of service "BonusService" with new bonusActiveId
        When I make a "GET" call to "AllowedGames" to service "BonusService"
        Then the API call is successful with status code 200
        And the property "<property1>" in response body array with index "[0]" has value "<value1>"
        And the property "<property2>" in response body array with index "[0]" has value "<value2>"

        Examples:
            | property1 | value1 | property2 | value2 |
            | gameType  | sports | gameIds   | OB     |

    @NoRetry
    Scenario: Get Bonus OB - Verify Allowed Games - not found
        Given I create a Get "cc_csrftokenSpec" header
        And I change url resource of method "AllowedGames" of service "BonusService" with configured parameter "bonus" "bonusId"
        And I change url resource of method "AllowedGames" of service "BonusService" with invalid bonusActiveId "text"
        When I make a "GET" call to "AllowedGames" to service "BonusService"
        Then the API call is successful with status code 404

    Scenario Outline: Post Allowed Games - Cannot edit after bonus activation
        Given I create a Get "cc_csrftokenSpec" header
        And I create a POST AllowedGames payload with "<property1>" "<value1>"
        And I change url resource of method "AllowedGames" of service "BonusService" with configured parameter "bonus" "bonusId"
        And I change url resource of method "AllowedGames" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AllowedGames" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "BONUS_ACTIVE_ALLOWED_GAMES_ERROR"
        And the "description" in response body is "Updating allowed games of the active bonus is not permitted ([Error Id: BONUS_ACTIVE_ALLOWED_GAMES_ERROR])"

        Examples:
            | property1 | value1    |
            | sports    | BETGENIUS |

    Scenario: Get BonusId - success
        Given I create a Get "cc_csrftokenSpec" header
        And I change url resource of method "GetCCBonusWithId" of service "BonusService" with new bonusActiveId
        When I make a "GET" call to "GetCCBonusWithId" to service "BonusService"
        Then the API call is successful with status code 200
        And the "bonusAssignment" in response body is "SEGMENT"
        And the "rewardType" in response body is "PRE_WAGER"
        And the "rewardAmountType" in response body is "FIXED"
        And the "allowedGames[0].gameIds[0]" in response body is "OB"
        And the "status" in response body is "ACTIVE"
        And the "activationTrigger" in response body is "NONE"

    @NoRetry
    Scenario: Get Bonus - Invalid bonusName
        Given I create a Get "cc_csrftokenSpec" header
        And I change url resource of method "GetCCBonusWithName" of service "BonusService" with bonusName "test"
        When I make a "GET" call to "GetCCBonusWithName" to service "BonusService"
        Then the API call is successful with status code 404
        And the "errorId" in response body is "BONUS_NOT_FOUND"
        And the "description" in response body is "Bonus not found ([Error Id: BONUS_NOT_FOUND])"

    @NoRetry
    Scenario: Assign Bonus To User - Invalid bonusId
        When I create a Get "api_mainSpec_mainHost" header
        And I create a POST assignBonus payload with "valid" userId
        And I change url resource of method "AssignBonusSegment" of service "BonusService" with invalid bonusActiveId "numeric"
        When I make a "POST" call to "AssignBonusSegment" to service "BonusService"
        Then the API call is successful with status code 404
        And the "description" in response body is "Bonus not found ([Error Id: BONUS_NOT_FOUND])"
        And the "errorId" in response body is "BONUS_NOT_FOUND"

    Scenario: Assign Bonus To User - Invalid format playerId
        When I create a Get "api_mainSpec_mainHost" header
        And I create a POST assignBonus payload with "invalid" userId
        And I change url resource of method "AssignBonusSegment" of service "BonusService" with configured parameter "bonus" "bonusId"
        And I change url resource of method "AssignBonusSegment" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonusSegment" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "INVALID_USERID"
        And the "description" in response body is "UserId is invalid format should be 1-<userId> ([Error Id: INVALID_USERID])"

    @NoRetry
    Scenario: Assign Bonus - userId not found
        Given I create a Get "api_mainSpec_mainHost" header
        And I create a POST assignBonus payload with "notfound" userId
        And I change url resource of method "AssignBonusSegment" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonusSegment" to service "BonusService"
        Then the API call is successful with status code 200
        And the "totalNumberOfPlayers" in response body is "1"
        And the "numberAssigned" in response body is "0"

    Scenario: Assign Bonus to user - success
        Given I create a Get "api_mainSpec_mainHost" header
        And I create a POST assignBonus payload with "valid" userId
        And I change url resource of method "AssignBonusSegment" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonusSegment" to service "BonusService"
        Then the API call is successful with status code 200
        And the "totalNumberOfPlayers" in response body is "1"
        And the "numberAssigned" in response body is "1"

    Scenario: Assign Bonus to user - already assigned
        Given I create a Get "api_mainSpec_mainHost" header
        And I create a POST assignBonus payload with "valid" userId
        And I change url resource of method "AssignBonusSegment" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonusSegment" to service "BonusService"
        Then the API call is successful with status code 200
        And the "totalNumberOfPlayers" in response body is "1"
        And the "numberAssigned" in response body is "0"

    Scenario Outline: Get MailId For Fetch Hash - Verify origin has value player
        Given I login as a "configuredPlayerCc" user
        And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
        When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
        Then the API call is successful with status code 200
#    And the number of results in the first nested array "<array>" is 1
        And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
        And I copy the value of the mailId from the response with template name "<templateName>"

        Examples:
            | key      | value    | property | propertyValue | array | arrayWithIndex | templateName                                   |
            | playerId | changeit | origin   | bonus-service | data  | data[0]        | email.bonusprize.activated.prewager_sportsbook |

    Scenario Outline: Get hash For Mail Verification - Verify event name/owner
        Given I create a Get "cc_csrftokenSpec" header
        When I make a "GET" call to "GetHashForMailVerification" to service "CommunicationService"
        Then the API call is successful with status code 200
        And the "<property>" in response body is "<propertyValue>"
        And the "<property2>" in response body is "<propertyValue2>"
        And the "<property3>" in response body is "<propertyValue3>"
        And the "<property4>" in response body is "<propertyValue4>"

        Examples:
            | property | propertyValue                                               | property2 | propertyValue2                                 | property3  | propertyValue3 | property4 | propertyValue4 |
            | subject  | Το Bonus σου στο ΤΖΟΚΕΡ είναι διαθέσιμο στο λογαριασμό σου! | eventName | email.bonusprize.activated.prewager_sportsbook | eventOwner | bonus-service  | status    | ACTIVE         |

    Scenario Outline: Edit BonusPrize - Invalid user
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with invalid playerId
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId

        Examples:
            | providerId | gameId     | status    | amount | closeAccount |
            | OB         | SPORTSBOOK | CANCELLED | 0.0    | false        |


        