@BonusService
Feature: GET WEB /bonus/rest/v1/bonus-prizes endpoint

  Scenario: Get bonus-prizes
    Given I create a Get "mainSpec" header
    Given I change url resource of method "GetWebBonusPrizes" of service "BonusService" with new playerId
    And I make a "GET" call to "GetWebBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200

  Scenario Outline: Get bonus-prizes - GameId parameter
    Given I create a Get "mainSpec" header with query params "<key>" "<value>"
    Given I change url resource of method "GetWebBonusPrizes" of service "BonusService" with new playerId
    And I make a "GET" call to "GetWebBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200

    Examples:
      | key    | value |
      | gameId | PBS   |

  Scenario Outline: Get bonus-prizes - status parameter
    Given I create a Get "mainSpec" header with query params "<key>" "<value>"
    Given I change url resource of method "GetWebBonusPrizes" of service "BonusService" with new playerId
    And I make a "GET" call to "GetWebBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And the property "status" in response body array with index "pageItems[0]" has value "ACTIVE"

    Examples:
      | key    | value  |
      | status | ACTIVE |

  Scenario Outline: Get bonus-prizes - rewardType and gameId parameters
    Given I create a Get "mainSpec" header with query params "<key>" "<value>"
    Given I change url resource of method "GetWebBonusPrizes" of service "BonusService" with new playerId
    And I make a "GET" call to "GetWebBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And the property "prizeAmount" in response body array with index "pageItems[0]" contains value "50"
    And the property "accountBalance" in response body array with index "pageItems[0]" contains value "50"
    And the property "bonusTerms" in response body array with index "pageItems[0].bonus" contains value "http://www.opap.gr"
    And the property "rewardType" in response body array with index "pageItems[0].bonus" contains value "EXTERNAL_CAMPAIGN"
    And the property "rewardAmountType" in response body array with index "pageItems[0].bonus" contains value "EXT_FIXED"
    And the property "bonusRollover" in response body array with index "pageItems[0].bonus" contains value "0.0"
    And the property "bonusAssignmentType" in response body array with index "pageItems[0].bonus" contains value "SEGMENT"
    And the property "bonusRewardAmount" in response body array with index "pageItems[0].bonus" contains value "0.0"
    And the property "status" in response body array with index "pageItems[0]" contains value "ACTIVE"

    Examples:
      | key               | value                 |
      | rewardType,gameId | EXTERNAL_CAMPAIGN,PBS |

  Scenario Outline: Get bonus-prizes - all parameters
    Given I create a Get "mainSpec" header with query params "<key>" "<value>"
    Given I change url resource of method "GetWebBonusPrizes" of service "BonusService" with new playerId
    And I make a "GET" call to "GetWebBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And the property "prizeAmount" in response body array with index "pageItems[0]" contains value "50"
    And the property "accountBalance" in response body array with index "pageItems[0]" contains value "50"
    And the property "bonusTerms" in response body array with index "pageItems[0].bonus" contains value "http://www.opap.gr"
    And the property "rewardType" in response body array with index "pageItems[0].bonus" contains value "EXTERNAL_CAMPAIGN"
    And the property "rewardAmountType" in response body array with index "pageItems[0].bonus" contains value "EXT_FIXED"
    And the property "bonusRollover" in response body array with index "pageItems[0].bonus" contains value "0.0"
    And the property "bonusAssignmentType" in response body array with index "pageItems[0].bonus" contains value "SEGMENT"
    And the property "bonusRewardAmount" in response body array with index "pageItems[0].bonus" contains value "0.0"
    And the property "status" in response body array with index "pageItems[0]" contains value "ACTIVE"

    Examples:
      | key                      | value                        |
      | rewardType,gameId,status | EXTERNAL_CAMPAIGN,PBS,ACTIVE |

  Scenario Outline: Get bonuses
    Given I create a Get "mainSpec" header with query params "<key>" "<value>"
    Given I change url resource of method "GetWebBonuses" of service "BonusService" with new playerId
    And I make a "GET" call to "GetWebBonuses" to service "BonusService"
    Then the API call is successful with status code 200

    Examples:
      | key                      | value                        |
      | rewardType,gameId,status | EXTERNAL_CAMPAIGN,PBS,ACTIVE |