Feature: CC Endpoint /rest/v1/bonus-prizes

  @BonusService
  Scenario Outline: Get Active Bonuses
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200
#    And the "totalRowCount" in response body is "0"
    And I copy the value of the first bonusActiveId of providerId "<providerId>" and rewardType "<rewardType>" from the response

    Examples:
      | keys                       | values        | providerId | rewardType        |
      | status,pageNumber,pageSize | ACTIVE,1,1000 | PBS        | EXTERNAL_CAMPAIGN |


  @BonusService
  Scenario Outline: Allowed games - invalid bonusId
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AllowedGames payload with "<gameType>" "<gameId>"
    And I change url resource of method "AllowedGames" of service "BonusService" with invalid bonusActiveId "numeric"
    When I make a "POST" call to "AllowedGames" to service "BonusService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "BONUS_NOT_FOUND"
    And the "description" in response body is "Bonus not found ([Error Id: BONUS_NOT_FOUND])"

    Examples:
      | gameType | gameId |
      | sports   | PBS,OB |

  @BonusService
  Scenario Outline: Allowed games - invalid body
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AllowedGames payload with "<gameType>" "<gameId>"
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with configured parameter "bonus" "bonusId"
    And I change url resource of method "AllowedGames" of service "BonusService" with invalid bonusActiveId "numeric"
    When I make a "POST" call to "AllowedGames" to service "BonusService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "BONUS_NOT_FOUND"
    And the "description" in response body is "Bonus not found ([Error Id: BONUS_NOT_FOUND])"

    Examples:
      | gameType | gameId |
      | test     | test   |

  @BonusService
  Scenario Outline: Get Allowed Games
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetCCAllowedGames" to service "BonusService"
    Then the API call is successful with status code 200
    And the response includes value "<gameType1>"
    And the response includes value "<gameType2>"
    And the response includes value "<gameType3>"
    And the response includes value "<gameId1>"
    And the response includes value "<gameId2>"
    And the response includes value "<gameId3>"
    And the response includes value "<gameId4>"

    Examples:
      | gameType1 | gameType2 | gameType3   | gameId1 | gameId2   | gameId3 | gameId4 |
      | sports    | instants  | numbergames | PBS     | BETGENIUS | EM      | JOKER   |

  @BonusService
  Scenario Outline: Get Bonuses - status CANCELLED
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200

    Examples:
      | keys   | values    |
      | status | CANCELLED |


  @BonusService
  Scenario Outline: Get Bonuses - Invalid status
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 404

    Examples:
      | keys   | values |
      | status | test   |


  Scenario Outline: Bonuses - Get Payment methods
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetCCPaymentMethods" to service "BonusService"
    Then the API call is successful with status code 200
    And the response includes value "<paymentMethod1>"
    And the response includes value "<paymentMethod2>"
    And the response includes value "<paymentMethod3>"
    And the response includes value "<paymentMethod4>"
    And the response includes value "<paymentMethod5>"
    And the response includes value "<paymentMethod6>"

    Examples:
      | paymentMethod1 | paymentMethod2 | paymentMethod3 | paymentMethod4 | paymentMethod5 | paymentMethod6 |
      | CARD           | PAYMENT_CODE   | PAYSAFECARD    | SKRILL         | IBAN           | CASH           |

