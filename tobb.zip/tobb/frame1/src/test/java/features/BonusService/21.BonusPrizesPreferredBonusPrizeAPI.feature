@BonusService
Feature: Test API endpoint rest/v1/bonus-prizes/users/userId/preferred-bonus-prize

  @NoRetry
  Scenario Outline: Get preferred-bonus-prizes
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    Given I change url resource of method "GetPreferredBonusPrize" of service "BonusService" with new playerId
    When I make a "GET" call to "GetPreferredBonusPrize" to service "BonusService"
    Then the API call is successful with status code 200

    Examples:
      | key               | value     |
      | gameId,wagerPrice | PBS,10000 |

  Scenario: Get preferred-bonus-prize - GameId is missing
    Given I create a Get "api_mainSpec_mainHost" header
    Given I change url resource of method "GetPreferredBonusPrize" of service "BonusService" with new playerId
    When I make a "GET" call to "GetPreferredBonusPrize" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "GameId parameter missing ([Error Id: GAME_ID_MISSING])"
    And the "errorId" in response body is "GAME_ID_MISSING"

  Scenario Outline: Get preferred-bonus-prize - WagerPrice is missing
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    Given I change url resource of method "GetPreferredBonusPrize" of service "BonusService" with new playerId
    When I make a "GET" call to "GetPreferredBonusPrize" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Wager price parameter missing ([Error Id: WAGER_PRICE_MISSING])"
    And the "errorId" in response body is "WAGER_PRICE_MISSING"

    Examples:
      | key    | value |
      | gameId | PBS   |

  @NoRetry
  Scenario Outline: Get preferred-bonus-prizes
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    Given I change url resource of method "GetPreferredBonusPrize" of service "BonusService" with new playerId
    When I make a "GET" call to "GetPreferredBonusPrize" to service "BonusService"
    Then the API call is successful with status code 404

    Examples:
      | key               | value    |
      | gameId,wagerPrice | PBS,test |
