@BonusService
Feature: Test API endpoint rest/v1/bonus-prizes/users/userId/allowed-game

    Scenario: Get bonus-prizes - no params
        Given I create a Get "api_mainSpec_mainHost" header
        And I change url resource of method "GetAllowedGame" of service "BonusService" with configured parameter "playerIdGrandPrize" "GrandPrize"
        Given I change url resource of method "GetAllowedGame" of service "BonusService" with new playerId
        When I make a "GET" call to "GetAllowedGame" to service "BonusService"
        Then the API call is successful with status code 200

    Scenario Outline: Get bonus-prizes - gameId param
        Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
        And I change url resource of method "GetAllowedGame" of service "BonusService" with configured parameter "playerIdGrandPrize" "GrandPrize"
        Given I change url resource of method "GetAllowedGame" of service "BonusService" with new playerId
        When I make a "GET" call to "GetAllowedGame" to service "BonusService"
        Then the API call is successful with status code 200
        And the property "gameId" in response body array with index "[0]" has value "PBS"

        Examples:
            | key    | value |
            | gameId | PBS   |


    Scenario Outline: Get bonus-prizes - status param
        Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
        And I change url resource of method "GetAllowedGame" of service "BonusService" with configured parameter "playerIdGrandPrize" "GrandPrize"
        Given I change url resource of method "GetAllowedGame" of service "BonusService" with new playerId
        When I make a "GET" call to "GetAllowedGame" to service "BonusService"
        Then the API call is successful with status code 200
        And the property "status" in response body array with index "[0]" has value "ACTIVE"

        Examples:
            | key    | value  |
            | status | ACTIVE |