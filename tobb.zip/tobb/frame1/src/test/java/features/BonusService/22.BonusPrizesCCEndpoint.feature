@BonusService
Feature: Test CC endpoint rest/v1/bonus-prizes/users/userId

  Scenario: Get bonus-prizes
    Given I create a Get "cc_csrftokenSpec" header
    When I change url resource of method "GetCCBonusPrizesWithId" of service "BonusService" with new bonusPrizeId
    And I make a "GET" call to "GetCCBonusPrizesWithId" to service "BonusService"
    Then the API call is successful with status code 200

  Scenario: Get bonus-prizes - Invalid userId
    Given I create a Get "cc_csrftokenSpec" header
    When I change url resource of method "GetCCBonusPrizesWithUserId" of service "BonusService" with invalid playerId
    And I make a "GET" call to "GetCCBonusPrizesWithUserId" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_USERID"
    And the "description" in response body is "UserId is invalid format should be 1-<userId> ([Error Id: INVALID_USERID])"

  Scenario: Get bonus-prizes - Invalid bonusPrizeId
    Given I create a Get "cc_csrftokenSpec" header
    When I change url resource of method "GetCCBonusPrizesWithId" of service "BonusService" with invalid bonusPrizeId
    And I make a "GET" call to "GetCCBonusPrizesWithId" to service "BonusService"
    Then the API call is successful with status code 404

  Scenario: Get bonus-prizes by userId
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetCCBonusPrizesWithUserId" of service "BonusService" with configured parameter "playerIdGrandPrize" "GrandPrize"
    When I change url resource of method "GetCCBonusPrizesWithUserId" of service "BonusService" with new playerId
    And I make a "GET" call to "GetCCBonusPrizesWithUserId" to service "BonusService"
    Then the API call is successful with status code 200
