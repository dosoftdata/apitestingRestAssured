@BonusService
Feature: Test Bet Prize Rollback

    Scenario Outline: Bet Reserve Successful - -15 main/ 15 bonus
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "<amount>"
        And the property "postBalance" in response body array with index "[0]" has value "15.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "BUY"
        And the property "bonusPrizeId" in response body array with index "[1]" has value "bonusPrizeId"
        And the property "amount" in response body array with index "[1]" has value "<bonusAmount>"
        And the property "postBalance" in response body array with index "[1]" has value "50.0"
        And the property "status" in response body array with index "[1]" has value "VERIFIED"
        And the property "type" in response body array with index "[1]" has value "BUY"
        And I verify the bonusPrizeId is the field "[1].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -15.0  | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | 0.0       | "PBS"  | -15.0       |                      |

    Scenario Outline: CaptureBet -  Verify type & status
        Given I create a CaptureBet payload with <amount>
        And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
        And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
        When I make a "POST" call to "CaptureBet" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
        And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

        Examples:
            | amount | type | status   | arrayWithIndex |
            | -30    | BUY  | VERIFIED | [0]            |

    Scenario Outline: Wager funds - mixed accounts
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
        And the property "postBalance" in response body array with index "[0]" has value "50.0"
        And the property "type" in response body array with index "[1]" has value "<type>"
        And the property "status" in response body array with index "[1]" has value "<status>"
        And the property "amount" in response body array with index "[1]" has value "<amount>"
        And the property "postBalance" in response body array with index "[1]" has value "5.0"

        Examples:
            | accountId | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | 5.0    | DEFAULT  | datenow | SPORTSBOOK | PRIZE | prize       | TRUE        | VERIFIED | TRUE     | 10.0      | "PBS"  | 15.0        | 0.00          | test                 |

    Scenario Outline: Prize Rollback succ - 0 main/ 1 bonus
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
        And the property "postBalance" in response body array with index "[0]" has value "49.0"
        And the property "productId" in response body array with index "[0]" has value "<productId>"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body

        Examples:
            | accountId | amount | currency | issued  | productId  | type           | description    | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | 0.0    | DEFAULT  | datenow | SPORTSBOOK | PRIZE_ROLLBACK | prize-rollback | TRUE        | VERIFIED | TRUE     | 10.0      | "PBS"  | -1.0        | 0.00          | test                 |

    Scenario Outline: Get Player Wallet Balances
        Given I add 2 seconds delay
        And I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 15.0     | 0.0              | AT_MAIN-2 | 49.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Wager funds
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
        And the property "postBalance" in response body array with index "[0]" has value "64.0"
        And the property "type" in response body array with index "[1]" has value "<type>"
        And the property "status" in response body array with index "[1]" has value "<status>"
        And the property "amount" in response body array with index "[1]" has value "<amount>"
        And the property "postBalance" in response body array with index "[1]" has value "20.0"

        Examples:
            | accountId | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | 5.0    | DEFAULT  | datenow | SPORTSBOOK | PRIZE | prize       | TRUE        | VERIFIED | TRUE     | 10.0      | "PBS"  | 15.0        | 0.00          | test                 |

    Scenario Outline: Prize Rollback succ - 10 main/ 15 bonus
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
        And the property "postBalance" in response body array with index "[0]" has value "49.0"
        And the property "productId" in response body array with index "[0]" has value "<productId>"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body
        And the property "type" in response body array with index "[1]" has value "<type>"
        And the property "status" in response body array with index "[1]" has value "<status>"
        And the property "amount" in response body array with index "[1]" has value "<amount>"
        And the property "postBalance" in response body array with index "[1]" has value "20.0"
        And the property "productId" in response body array with index "[1]" has value "<productId>"

        Examples:
            | accountId | amount | currency | issued  | productId  | type           | description    | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | -10.0  | DEFAULT  | datenow | SPORTSBOOK | PRIZE_ROLLBACK | prize-rollback | TRUE        | VERIFIED | TRUE     | 10.0      | "PBS"  | -15.0       | 0.00          | test                 |

    Scenario Outline: Get Player Wallet Balances
        Given I add 3 seconds delay
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 10.0     | 0.0              | AT_MAIN-2 | 49.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Wager funds
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
        And the property "postBalance" in response body array with index "[0]" has value "64.0"
        And the property "type" in response body array with index "[1]" has value "<type>"
        And the property "status" in response body array with index "[1]" has value "<status>"
        And the property "amount" in response body array with index "[1]" has value "<amount>"
        And the property "postBalance" in response body array with index "[1]" has value "15.0"

        Examples:
            | accountId | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | 5.0    | DEFAULT  | datenow | SPORTSBOOK | PRIZE | prize       | TRUE        | VERIFIED | TRUE     | 10.0      | "PBS"  | 15.0        | 0.00          | test                 |

    Scenario Outline: Prize Rollback succ - 5 main/ 15 bonus
        Given I add 2 seconds delay
        And I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
        And the property "postBalance" in response body array with index "[0]" has value "49.0"
        And the property "productId" in response body array with index "[0]" has value "<productId>"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body
        And the property "type" in response body array with index "[1]" has value "<type>"
        And the property "status" in response body array with index "[1]" has value "<status>"
        And the property "amount" in response body array with index "[1]" has value "<amount>"
        And the property "postBalance" in response body array with index "[1]" has value "10.0"
        And the property "productId" in response body array with index "[1]" has value "<productId>"

        Examples:
            | accountId | amount | currency | issued  | productId  | type           | description    | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | -15.0  | DEFAULT  | datenow | SPORTSBOOK | PRIZE_ROLLBACK | prize-rollback | TRUE        | VERIFIED | TRUE     | 10.0      | "PBS"  | -15.0       | 0.00          | test                 |

    Scenario Outline: Get Player Wallet Balances
        Given I add 5 seconds delay
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 0.0      | 0.0              | AT_MAIN-2 | 49.0     | 0.0              | AT_BONUS_PRIZE |
#        Examples:
#            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
#            | 20.0     | 0.0              | AT_MAIN-1 | 10.0     | 0.0              | AT_MAIN-2 | 49.0     | 0.0              | AT_BONUS_PRIZE |
    

    Scenario Outline: Wager funds
        Given I login as an Api user
        And I add 2 seconds delay
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
        And the property "postBalance" in response body array with index "[0]" has value "64.0"
        And the property "type" in response body array with index "[1]" has value "<type>"
        And the property "status" in response body array with index "[1]" has value "<status>"
        And the property "amount" in response body array with index "[1]" has value "<amount>"
        And the property "postBalance" in response body array with index "[1]" has value "5.0"

        Examples:
            | accountId | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | 5.0    | DEFAULT  | datenow | SPORTSBOOK | PRIZE | prize       | TRUE        | VERIFIED | TRUE     | 10.0      | "PBS"  | 15.0        | 0.00          | test                 |

    Scenario Outline: Prize Rollback succ - 5 main/ 15 bonus
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
        And the property "postBalance" in response body array with index "[0]" has value "49.0"
        And the property "productId" in response body array with index "[0]" has value "<productId>"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body

        Examples:
            | accountId | amount | currency | issued  | productId  | type           | description    | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | 0.0    | DEFAULT  | datenow | SPORTSBOOK | PRIZE_ROLLBACK | prize-rollback | TRUE        | VERIFIED | TRUE     | 10.0      | "PBS"  | -15.0       | 0.00          | test                 |

    Scenario Outline: Get Player Wallet Balances
        Given I add 2 seconds delay
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 15.0     | 0.0              | AT_MAIN-2 | 49.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Wager funds
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
        And the property "postBalance" in response body array with index "[0]" has value "64.0"
        And the property "type" in response body array with index "[1]" has value "<type>"
        And the property "status" in response body array with index "[1]" has value "<status>"
        And the property "amount" in response body array with index "[1]" has value "<amount>"
        And the property "postBalance" in response body array with index "[1]" has value "20.0"

        Examples:
            | accountId | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | 5.0    | DEFAULT  | datenow | SPORTSBOOK | PRIZE | prize       | TRUE        | VERIFIED | TRUE     | 5.0       | "PBS"  | 15.0        | 0.00          | test                 |

    Scenario Outline: Prize Rollback succ - 5 main/ 0 bonus
        Given I add 3 seconds delay
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<amount>"
        And the property "postBalance" in response body array with index "[0]" has value "20.0"
        And the property "productId" in response body array with index "[0]" has value "<productId>"

        Examples:
            | accountId | amount | currency | issued  | productId  | type           | description    | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | -5.0   | DEFAULT  | datenow | SPORTSBOOK | PRIZE_ROLLBACK | prize-rollback | TRUE        | VERIFIED | TRUE     | 5.0       | "PBS"  | 0.0         | 0.00          | test                 |

    Scenario Outline: Get Player Wallet Balances
        Given I add 2 seconds delay
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 15.0     | 0.0              | AT_MAIN-2 | 64.0     | 0.0              | AT_BONUS_PRIZE |