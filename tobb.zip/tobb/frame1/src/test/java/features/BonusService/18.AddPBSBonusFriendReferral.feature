@BonusService
Feature: Test bonus with friend referral

  Scenario Outline:  Add PBS bonus friend referral - missing amount
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Amount type fixed, but no amount set ([Error Id: AMOUNT_MISSING])"
    And the "errorId" in response body is "AMOUNT_MISSING"

    Examples:
      | rewardType      | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
      | FRIEND_REFERRAL | FRIEND_REFERRAL | NONE              | FIXED            | 2030-12-23T00:00:00 | 1           | sports   | PBS     | false     | -1               | 0            | 0      |          |         |

  Scenario Outline:  Add PBS bonus friend referral - missing rewardAmountType
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Constraint(s) violation occurred during json validation process"
    And the "errorId" in response body is "VALIDATION_ERROR"

    Examples:
      | rewardType      | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
      | FRIEND_REFERRAL | FRIEND_REFERRAL | NONE              |                  | 2030-12-23T00:00:00 | 1           | sports   | PBS     | false     | -1               | 100          | 0      |          |         |

  Scenario Outline:  Add PBS bonus friend referral - success
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200
    And I copy the bonusActiveId with field "bonusId" in the response body

    Examples:
      | rewardType      | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
      | FRIEND_REFERRAL | FRIEND_REFERRAL | NONE              | FIXED            | 2030-12-23T00:00:00 | 1           | sports   | PBS     | false     | -1               | 100          | 0      |          |         |

  Scenario Outline:  Add second PBS bonus friend referral - success
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Active referral bonus already exists. Only one active referral bonus is allowed ([Error Id: REFERRAL_BONUS_EXISTS])"
    And the "errorId" in response body is "REFERRAL_BONUS_EXISTS"

    Examples:
      | rewardType      | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
      | FRIEND_REFERRAL | FRIEND_REFERRAL | NONE              | FIXED            | 2030-12-23T00:00:00 | 1           | sports   | PBS     | false     | -1               | 100          | 0      |          |         |

  Scenario:  Get referral codes
    Given I create a Get "mainSpec" header
    When I make a "GET" call to "GetWebReferralCode" to service "BonusService"
    Then the API call is successful with status code 200
    And the "type" in response body is "REFERRAL_CODE"
    And the "status" in response body is "ACTIVE"

  Scenario:  Cancel Referral Bonus
    And I create a PUT cancelBonus payload
    And I change url resource of method "UpdateCCBonus" of service "BonusService" with new bonusActiveId
    And I make a "PUT" call to "UpdateCCBonus" to service "BonusService"
    Then the API call is successful with status code 200
    And the "status" in response body is "CANCELLED"
