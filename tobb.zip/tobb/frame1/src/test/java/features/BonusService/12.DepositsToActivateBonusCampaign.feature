Feature: Deposits to activate bonus campaign

  ## Verify Bonus is activated after full account KYC

  @BonusService
  Scenario Outline: Get and Verify Payment Codes
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the values of the Payment Codes

    Examples:
      | keys     | values |
      | category | ALL    |


  @BonusService
  Scenario Outline: Get limits via limit-service
    Given I setup gameId header to "JOKER"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerLimits" of service "LimitService" with new playerId
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |


  @BonusService
  Scenario: Get bonus-prizes
    Given I setup gameId header to "JOKER"
    Given I create a Get "specWithGameId" header
    Given I change url resource of method "GetWebBonusPrizes" of service "BonusService" with new playerId
    And I make a "GET" call to "GetWebBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200


  @BonusService
  Scenario Outline: Set mandatory limits for JOKER/PROTO/LOTTO/SUPER3/KINO and Verify JOKER mandatory limits
    Given I setup gameId header to "JOKER"
    Given I create a Get "specWithGameId" header
    And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
    And I change url resource of method "PlayerLimitsV2" of service "LimitService" with new playerId
    When I make a "POST" call to "PlayerLimitsV2" to service "LimitService"
    Then the API call is successful with status code 200

    Examples:
      | limitTypes                            | limitPeriods                              | limitAmounts                        | gameIds                         |
      | TIME,DEPOSIT,LOSS,LOSS,LOSS,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY,DAILY,DAILY,DAILY | 86000,2000,1000,1000,1000,1000,1000 | ,,JOKER,PROTO,KINO,LOTTO,SUPER3 |


  @BonusService
  Scenario Outline: Deposit via Payment code - Lottery wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_EXCLUSIVE"
    And the "amount.amount" in response body is "20.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 20     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |


  @BonusService
  Scenario Outline: Get and Verify Wallets Balance
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 |
      | 20.0     | 20.0         | 20.0                    | 0.0              | 0.0                  |

