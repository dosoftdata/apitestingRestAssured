@BonusService
Feature: Test Bet Actions Bonus wallet equals 0

    Scenario Outline: Deposit via Payment code - Betting wallet
        Given I add 1 seconds delay
        Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
        When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
        Then the API call is successful with status code 200
        And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
        And the "amount.amount" in response body is "30.0"
        And the "amount.currency" in response body is "EUR"
        And the "paymentStatus" in response body is "APPROVED"
        And the "paymentType" in response body is "PT_TRANSFER_IN"
        And the "serviceProviderId" in response body is "TORA"
        And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
        And I verify the player id "owner.id" in the response body
        And I copy the value of the paymentId

        Examples:
            | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
            | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 30     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 30.0     | 0.0              | AT_MAIN-2 | 10.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Bet Reserve Successful -30 main/ 0 bonus
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "<amount>"
        And the property "postBalance" in response body array with index "[0]" has value "30.0"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "type" in response body array with index "[0]" has value "<type>"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -30.0  | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | 0.0       | "PBS"  | 0.0         |                      |

    Scenario Outline: CaptureBet - Verify type & status
        Given I create a CaptureBet payload with <amount>
        And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
        And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
        When I make a "POST" call to "CaptureBet" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
        And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

        Examples:
            | amount | type | status   | arrayWithIndex |
            | -30    | BUY  | VERIFIED | [0]            |

    Scenario Outline: Bet cancel -30 main/ 0 bonus- previous batchId
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body
        And the property "amount" in response body array with index "[0]" has value "30.0"
        And the property "postBalance" in response body array with index "[0]" has value "30.0"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "type" in response body array with index "[0]" has value "<type>"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -30.00 | DEFAULT  | datenow | SPORTSBOOK | CANCEL | Bet         | true        | VERIFIED | true     | 0.0       | "PBS"  | 0.00        |                      |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 30.0     | 0.0              | AT_MAIN-2 | 10.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Bet Adjust Successful -30 main/ 0 bonus
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "<accountId>"
        And the property "amount" in response body array with index "[0]" has value "<amount>"
        And the property "postBalance" in response body array with index "[0]" has value "0.0"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "type" in response body array with index "[0]" has value "<type>"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type   | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -30.0  | DEFAULT  | datenow | SPORTSBOOK | ADJUST | Bet         | true        | VERIFIED | true     | 0.0       | "PBS"  | 0.0         |                      |

    Scenario Outline: Bet Prize - bonusAmount=0
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<amount>"
        And the property "postBalance" in response body array with index "[0]" has value "30.0"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body

        Examples:
            | accountId | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | 30.0   | DEFAULT  | datenow | SPORTSBOOK | PRIZE | prize       | TRUE        | VERIFIED | TRUE     | 0.0       | "PBS"  | 0.0         | 0.00          | test                 |

    Scenario Outline: Prize Rollback succ 30 main/ 20 bonus
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "<amount>"
        And the property "postBalance" in response body array with index "[0]" has value "0.0"
        And the property "productId" in response body array with index "[0]" has value "<productId>"

        Examples:
            | accountId | amount | currency | issued  | productId  | type           | description    | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | -30.0  | DEFAULT  | datenow | SPORTSBOOK | PRIZE_ROLLBACK | PRIZE_ROLLBACK | TRUE        | VERIFIED | TRUE     | 10.0      | "PBS"  | 0.0         | 0.00          | test                 |

    Scenario Outline: Get Player Wallet Balances
        Given I add 1 seconds delay
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 0.0      | 0.0              | AT_MAIN-2 | 10.0     | 0.0              | AT_BONUS_PRIZE |