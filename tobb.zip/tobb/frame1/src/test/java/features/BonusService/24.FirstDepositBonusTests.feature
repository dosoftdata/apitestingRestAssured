@BonusService
Feature: Test First Deposit bonus tests

    @NoRetry
    Scenario: Get Available Fdb GameIds - SPORTSBOOK header
        Given I setup gameId header to "SPORTSBOOK"
        And I create a Get "specWithGameId" header
        When I change url resource of method "GetWebBonusPrizesFdbGameIds" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonusPrizesFdbGameIds" to service "BonusService"
        Then the API call is successful with status code 200
        And the response includes value "NONE"
        And the response includes value "CASINO"

    @NoRetry
    Scenario: Get Available Fdb GameIds - JOKER header
        Given I setup gameId header to "JOKER"
        And I create a Get "specWithGameId" header
        When I change url resource of method "GetWebBonusPrizesFdbGameIds" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonusPrizesFdbGameIds" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "FDB_USER_NOT_ELIGIBLE"
        And the "description" in response body is "User is not eligible for first deposit bonus ([Error Id: FDB_USER_NOT_ELIGIBLE])"


    Scenario: Get Available Fdb GameIds - CASINO header
        Given I setup gameId header to "CASINO"
        And I create a Get "specWithGameId" header
        When I change url resource of method "GetWebBonusPrizesFdbGameIds" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonusPrizesFdbGameIds" to service "BonusService"
        Then the API call is successful with status code 200
        And the response includes value "NONE"
        And the response includes value "CASINO"

    Scenario: Get Available Fdb - SPORTSBOOK header
        Given I setup gameId header to "SPORTSBOOK"
        And I create a Get "specWithGameId" header
        When I change url resource of method "GetWebBonusPrizesFdb" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonusPrizesFdb" to service "BonusService"
        Then the API call is successful with status code 404
        And the "errorId" in response body is "FDB_USER_SELECTION_NOT_FOUND"
        And the "description" in response body is "User hasn't made a first deposit bonus selection for the NON_EXCLUSIVE group ([Error Id: FDB_USER_SELECTION_NOT_FOUND])"

    Scenario: Get Available Fdb - CASINO header
        Given I setup gameId header to "CASINO"
        And I create a Get "specWithGameId" header
        When I change url resource of method "GetWebBonusPrizesFdb" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonusPrizesFdb" to service "BonusService"
        Then the API call is successful with status code 404
        And the "errorId" in response body is "FDB_USER_SELECTION_NOT_FOUND"
        And the "description" in response body is "User hasn't made a first deposit bonus selection for the NON_EXCLUSIVE group ([Error Id: FDB_USER_SELECTION_NOT_FOUND])"

    Scenario: Get Available Fdb - JOKER header
        Given I setup gameId header to "JOKER"
        And I create a Get "specWithGameId" header
        When I change url resource of method "GetWebBonusPrizesFdb" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonusPrizesFdb" to service "BonusService"
        Then the API call is successful with status code 404
        And the "errorId" in response body is "FDB_USER_SELECTION_NOT_FOUND"
        And the "description" in response body is "User hasn't made a first deposit bonus selection for the EXCLUSIVE group ([Error Id: FDB_USER_SELECTION_NOT_FOUND])"

    Scenario Outline: Add first deposit bonus selection - empty body
        And I create a Get "mainspec" header
        When I create a POST FdbSelection payload with "<gameId>" "<playerId>"
        And I change url resource of method "GetWebBonusPrizesFdbSelection" of service "BonusService" with new playerId
        And I make a "POST" call to "GetWebBonusPrizesFdbSelection" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "VALIDATION_ERROR"
        And the "description" in response body is "Constraint(s) violation occurred during json validation process"

        Examples:
            | gameId | playerId |
            |        |          |

    Scenario Outline: Add first deposit bonus selection - unknown userId
        Given I create a Get "mainspec" header
        When I create a POST FdbSelection payload with "<gameId>" "<playerId>"
        And I change url resource of method "GetWebBonusPrizesFdbSelection" of service "BonusService" with new playerId
        And I make a "POST" call to "GetWebBonusPrizesFdbSelection" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "INVALID_JSON"
        And the "description" in response body is "Unrecognized property in JSON input"

        Examples:
            | gameId | playerId  |
            | 3      | 123456789 |

    Scenario Outline: Get Active Bonuses - Get BonusActiveId
        Given I login as a "configuredPlayerCc" user
        Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
        When I make a "GET" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 200
#    And the "totalRowCount" in response body is "1"
    # FIll the correct bonusActive details
        And I copy the value of the first bonusActiveId of providerId "<providerId>" and rewardType "<rewardType>" from the response
        And I copy the value of the first bonusName of providerId "<providerId>" and rewardType "<rewardType>" from the response

        Examples:
            | keys                       | values        | providerId | rewardType        |
            | status,pageNumber,pageSize | ACTIVE,1,1000 | PBS        | EXTERNAL_CAMPAIGN |

    Scenario Outline: Add first deposit bonus selection - dummy gameId
        Given I create a Get "mainspec" header
        When I create a POST FdbSelection payload with "<gameId>" "<playerId>"
        And I change url resource of method "GetWebBonusPrizesFdbSelection" of service "BonusService" with new playerId
        And I make a "POST" call to "GetWebBonusPrizesFdbSelection" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "FDB_CURRENT_GAME_ID_MISMATCH"
        And the "description" in response body is "First deposit bonus user selection not valid for current game id ([Error Id: FDB_CURRENT_GAME_ID_MISMATCH])"

        Examples:
            | gameId | playerId |
            | 4      |          |

    Scenario Outline: Bonus Update FdbEnalbed - invalid fdbEnabled
        Given I create a Get "cc_csrftokenSpec" header
        When I create a PUT updateFdbBonus payload with "<fdbEnabled>" "<fdbLinkEl>" "<fdbLinkEn>"
        And I change url resource of method "ModifyFdbForBonus" of service "BonusService" with new bonusActiveId
        And I make a "PUT" call to "ModifyFdbForBonus" to service "BonusService"
        Then the API call is successful with status code 400

        Examples:
            | fdbEnabled | fdbLinkEl          | fdbLinkEn |
            | test       | http://www.opap.gr |           |

    Scenario Outline: Bonus Update FdbEnalbed - missing fdbLink
        Given I create a Get "cc_csrftokenSpec" header
        When I create a PUT updateFdbBonus payload with "<fdbEnabled>" "<fdbLinkEl>" "<fdbLinkEn>"
        And I change url resource of method "ModifyFdbForBonus" of service "BonusService" with new bonusActiveId
        And I make a "PUT" call to "ModifyFdbForBonus" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "LINK_IS_EMPTY"
        And the "description" in response body is "Link should not be empty ([Error Id: LINK_IS_EMPTY])"

        Examples:
            | fdbEnabled | fdbLinkEl | fdbLinkEn |
            | true       |           |           |

    Scenario Outline: Bonus Update FdbEnalbed - invalid fdbLink format
        Given I create a Get "cc_csrftokenSpec" header
        When I create a PUT updateFdbBonus payload with "<fdbEnabled>" "<fdbLinkEl>" "<fdbLinkEn>"
        And I change url resource of method "ModifyFdbForBonus" of service "BonusService" with new bonusActiveId
        And I make a "PUT" call to "ModifyFdbForBonus" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "INVALID_LINK_FORMAT"
        And the "description" in response body is "Invalid link format ([Error Id: INVALID_LINK_FORMAT])"

        Examples:
            | fdbEnabled | fdbLinkEl   | fdbLinkEn   |
            | true       | www.opap.gr | www.opap.gr |

    Scenario Outline: Add first deposit bonus selection - no header
        Given I create a Get "mainspec" header
        When I create a POST FdbSelection payload with "<gameId>" "<playerId>"
        And I make a "POST" call to "GetWebBonusPrizesFdbSelection" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "FDB_CURRENT_GAME_ID_MISMATCH"
        And the "description" in response body is "First deposit bonus user selection not valid for current game id ([Error Id: FDB_CURRENT_GAME_ID_MISMATCH])"

        Examples:
            | gameId | playerId |
            | 1      |          |

    Scenario Outline: Add first deposit bonus selection - gameId 1
        Given I setup gameId header to "SPORTSBOOK"
        And I create a Get "specWithGameId" header
        When I create a POST FdbSelection payload with "<gameId>" "<playerId>"
        And I make a "POST" call to "GetWebBonusPrizesFdbSelection" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "FDB_USER_GAME_ID_NOT_ACTIVE"
        And the "description" in response body is "Game id is not part of an active fdb campaign ([Error Id: FDB_USER_GAME_ID_NOT_ACTIVE])"

        Examples:
            | gameId | playerId |
            | 1      |          |

    Scenario Outline: Add first deposit bonus selection - gameId 2
        Given I setup gameId header to "SPORTSBOOK"
        And I create a Get "specWithGameId" header
        When I create a POST FdbSelection payload with "<gameId>" "<playerId>"
        And I make a "POST" call to "GetWebBonusPrizesFdbSelection" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "FDB_CURRENT_GAME_ID_MISMATCH"
        And the "description" in response body is "First deposit bonus user selection not valid for current game id ([Error Id: FDB_CURRENT_GAME_ID_MISMATCH])"

        Examples:
            | gameId | playerId |
            | 2      |          |

    Scenario Outline: Add first deposit bonus selection - gameId 3
        Given I setup gameId header to "SPORTSBOOK"
        And I create a Get "specWithGameId" header
        When I create a POST FdbSelection payload with "<gameId>" "<playerId>"
        And I make a "POST" call to "GetWebBonusPrizesFdbSelection" to service "BonusService"
        Then the API call is successful with status code 204

        Examples:
            | gameId | playerId |
            | 3      |          |

    Scenario Outline: Add first deposit bonus selection - gameId 0
        Given I setup gameId header to "SPORTSBOOK"
        And I create a Get "specWithGameId" header
        When I create a POST FdbSelection payload with "<gameId>" "<playerId>"
        And I make a "POST" call to "GetWebBonusPrizesFdbSelection" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "FDB_USER_SELECTION_ALREADY_EXISTS"
        And the "description" in response body is "User has already made a first deposit bonus selection for the NON_EXCLUSIVE group ([Error Id: FDB_USER_SELECTION_ALREADY_EXISTS])"

        Examples:
            | gameId | playerId |
            | 0      |          |

    Scenario: Get Available Fdb GameIds - SPORTSBOOK header
        Given I setup gameId header to "SPORTSBOOK"
        And I create a Get "specWithGameId" header
        When I change url resource of method "GetWebBonusPrizesFdb" of service "BonusService" with new playerId
        And I make a "GET" call to "GetWebBonusPrizesFdb" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "FDB_USER_SELECTION_ALREADY_EXISTS"
        And the "description" in response body is "User has already made a first deposit bonus selection for the NON_EXCLUSIVE group ([Error Id: FDB_USER_SELECTION_ALREADY_EXISTS])"

    Scenario Outline: Bonus Update Fdb - Disable Fdb Casino
        Given I create a Get "cc_csrftokenSpec" header
        When I create a PUT updateFdbBonus payload with "<fdbEnabled>" "<fdbLinkEl>" "<fdbLinkEn>"
        And I change url resource of method "ModifyFdbForBonus" of service "BonusService" with new bonusActiveId
        And I make a "PUT" call to "ModifyFdbForBonus" to service "BonusService"
        Then the API call is successful with status code 204

        Examples:
            | fdbEnabled | fdbLinkEl          | fdbLinkEn          |
            | false      | http://www.opap.gr | http://www.opap.gr |