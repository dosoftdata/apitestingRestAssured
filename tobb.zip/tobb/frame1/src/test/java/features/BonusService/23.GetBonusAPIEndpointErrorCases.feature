@BonusService
Feature: Test API endpoint rest/api/bonus/rest/v1/bonus-prizes/users/1-{{playerId}}/assigned/{{bonusPrizeId}}

  @NoRetry
  Scenario Outline: Get Assigned bonus Prize - Incorrect bonusPrizeId
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    When I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with new playerId
    When I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with invalid bonusPrizeId
    And I make a "GET" call to "GetBonusPrizesWithId" to service "BonusService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "BONUS_PRIZE_NOT_FOUND"
    And the "description" in response body is "Bonus prize not found ([Error Id: BONUS_PRIZE_NOT_FOUND])"

    Examples:
      | keys   | values |
      | gameId | PBS    |

  Scenario Outline: Get Assigned bonus Prize
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    When I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with new playerId
    And I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with new bonusPrizeId
    And I make a "GET" call to "GetBonusPrizesWithId" to service "BonusService"
    Then the API call is successful with status code 200
    And the "status" in response body is "ACTIVE"

    Examples:
      | keys   | values |
      | gameId | PBS    |

  Scenario: Get Assigned bonus Prize - Missing gameId
    Given I create a Get "api_mainSpec_mainHost" header
    When I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with new bonusPrizeId
    And I make a "GET" call to "GetBonusPrizesWithId" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "GAME_ID_MISSING"
    And the "description" in response body is "GameId parameter missing ([Error Id: GAME_ID_MISSING])"

  Scenario Outline: Get Assigned bonus Prize - Incorrect gameId
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    When I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with new playerId
    When I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with new bonusPrizeId
    And I make a "GET" call to "GetBonusPrizesWithId" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "NOT_CORRECT_GAME_ID"
    And the "description" in response body is "Game id do not match with the allowed games of the assigned bonus. ([Error Id: NOT_CORRECT_GAME_ID])"

    Examples:
      | keys   | values |
      | gameId | TNS    |

  Scenario Outline: Get Assigned bonus Prize - Incorrect playerId
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    When I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with configured playerId "123456789"
    When I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with invalid bonusPrizeId
    And I make a "GET" call to "GetBonusPrizesWithId" to service "BonusService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "BONUS_PRIZE_NOT_FOUND"
    And the "description" in response body is "Bonus prize not found ([Error Id: BONUS_PRIZE_NOT_FOUND])"

    Examples:
      | keys   | values |
      | gameId | PBS    |

  Scenario Outline: Get Assigned bonus Prize - Incorrect format playerId
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    When I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with invalid playerId
    When I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with invalid bonusPrizeId
    And I make a "GET" call to "GetBonusPrizesWithId" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_USERID"
    And the "description" in response body is "UserId is invalid format should be 1-<userId> ([Error Id: INVALID_USERID])"

    Examples:
      | keys   | values |
      | gameId | PBS    |
