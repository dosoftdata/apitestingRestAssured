Feature: Create and assign OB bonus with KYC trigger

  @BonusService
  Scenario Outline: Create KYC Bonus - Success
    And I create a POST AddBonus payload with extra fields "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<paymentMethodName>" "<paymentMethodPercentage>" "<activationExpiryDays>" "<activationMinimumAmount>" "<rewardAmountType>" "<bonusValidFrom>" "<bonusValidTo>" "<minimumBets>" "<minimumBetAmount>" "<entryRequirement>" "<bonusCode>" "<gameType>" "<gameIds>" "<singleUse>" "<bonusTerms>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    And I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200

    Examples:
      | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusTerms         | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | entryRequirement | bonusCode | status | rollOver | bonusValidTo        | bonusValidFrom | minimumBets | activationMinimumAmount | minimumBetAmount | program | paymentMethodName | paymentMethodPercentage | activationExpiryDays |
      | PRE_WAGER  | SEGMENT         | KYC               | FIXED            | http://www.opap.gr | sports   | PBS     | false     | 60               | 20           |                  |           | 0      | 1        | 2030-12-23T00:00:00 |                | 1           |                         |                  |         |                   |                         | 31                   |


  @BonusService
  Scenario Outline: Get OB KYC Bonus - status ACTIVE
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200
    And the property "bonusAssignment" in response body array with index "pageItems[0]" has value "SEGMENT"
    And the property "rewardType" in response body array with index "pageItems[0]" has value "PRE_WAGER"
    And the property "rewardAmountType" in response body array with index "pageItems[0]" has value "FIXED"
    And the property "activationTrigger" in response body array with index "pageItems[0]" has value "KYC"
    And the property "rewardAmount" in response body array with index "pageItems[0]" has value "20.0"
    And the property "status" in response body array with index "pageItems[0]" has value "ACTIVE"
    And the property "gameIds[0]" in response body array with index "pageItems[0].allowedGames[0]" has value "PBS"
    And I copy the value of the first bonusActiveId of providerId "<providerId>" and rewardType "<rewardType>" from the response

    Examples:
      | keys   | values | providerId | rewardType |  |
      | status | ACTIVE | PBS        | PRE_WAGER  |  |

  @BonusService
  Scenario: Get Bonus Prize
    Given I login as an Api user
    When I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with new bonusActiveId
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200

  @BonusService
  Scenario Outline: Assign Bonus To User - OB
    When I create a Get "api_mainSpec_mainHost" header
    And I create a POST assignBonus payload with new playerId
    And I change url resource of method "AssignBonusSegment" of service "BonusService" with new bonusActiveId
    When I make a "POST" call to "AssignBonusSegment" to service "BonusService"
    Then the API call is successful with status code 200
    And the "totalNumberOfPlayers" in response body is "<totalNumberOfPlayers>"
    And the "numberAssigned" in response body is "<numberAssigned>"
    And the "numberOfAlreadyAssignedBonuses" in response body is "<numberOfAlreadyAssignedBonuses>"

    Examples:
      | totalNumberOfPlayers | numberAssigned | numberOfAlreadyAssignedBonuses |
      | 1                    | 1              | 0                              |

  @BonusService
  Scenario Outline: Check Player Assigned Bonus - OB
    When I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And the property "gameId" in response body array with index "[0].bonus.wrappedBonus.allowedGames[0]" has value "PBS"
    And the property "activationTrigger" in response body array with index "[0].bonus.wrappedBonus.activationRestriction" has value "KYC"
    And the property "status" in response body array with index "[0]" has value "ASSIGNED"
    And the property "bonusRewardAmount" in response body array with index "[0].bonus" has value "20.0"
    And I copy the value of the bonusPrizeId from the field "id"

    Examples:
      | keys          | values       |
      | gameId,status | PBS,ASSIGNED |

