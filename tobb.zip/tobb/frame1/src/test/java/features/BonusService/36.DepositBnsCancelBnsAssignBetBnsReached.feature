@BonusService
Feature: Test scenarios with actions: Deposit, Bet, Cancel Bet, Assign Bonus, Bet Reached Bonus

    Scenario Outline: Deposit via Payment code - Betting wallet
        Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
        When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
        Then the API call is successful with status code 200
        And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
        And the "amount.amount" in response body is "30.0"
        And the "amount.currency" in response body is "EUR"
        And the "paymentStatus" in response body is "APPROVED"
        And the "paymentType" in response body is "PT_TRANSFER_IN"
        And the "serviceProviderId" in response body is "TORA"
        And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
        And I verify the player id "owner.id" in the response body
        And I copy the value of the paymentId

        Examples:
            | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
            | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 30     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

    Scenario Outline: Cancel Bonus Prize BonusPrize
        Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with configured parameter "playerIdGrandPrize" "GrandPrize"
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
        When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 200
        And I verify the 1-playerId is the field "userId" in the response body
        And I verify the bonusPrizeId is the field "bonusPrizeId" in the response body
        And the "status" in response body is "<status>"

        Examples:
            | providerId | gameId     | status    | amount | closeAccount |
            | PBS        | SPORTSBOOK | CANCELLED | 0.0    | false        |

    Scenario Outline: Assign Bonus - providerId is PBS
        Given I create a Get "api_mainSpec_mainHost" header
        Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
        And I change url resource of method "AssignBonus" of service "BonusService" with new playerId
        And I change url resource of method "AssignBonus" of service "BonusService" with new bonusActiveId
        When I make a "POST" call to "AssignBonus" to service "BonusService"
        Then the API call is successful with status code 200
        And the "amount" in response body is "<amount>"
        And the "providerId" in response body is "<providerId>"
        And the "gameId" in response body is "<gameId>"
        And I verify the 1-playerId is the field "userId" in the response body
        And I copy the value of the bonusPrizeId from the field "bonusPrizeId"

        Examples:
            | providerId | gameId     | amount |
            | PBS        | SPORTSBOOK | 10     |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 30.0     | 0.0              | AT_MAIN-2 | 10.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Bet Reserve Successful -30 main/  -5 bonus
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "<amount>"
        And the property "postBalance" in response body array with index "[0]" has value "30.0"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "amount" in response body array with index "[1]" has value "<bonusAmount>"
        And the property "postBalance" in response body array with index "[1]" has value "10.0"
        And the property "status" in response body array with index "[1]" has value "<status>"
        And the property "type" in response body array with index "[1]" has value "<type>"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -30.0  | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | 0.0       | "PBS"  | -5.0        |                      |

    Scenario Outline: CaptureBet - Verify type & status
        Given I create a CaptureBet payload with <amount>
        And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
        And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
        When I make a "POST" call to "CaptureBet" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
        And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

        Examples:
            | amount | type | status   | arrayWithIndex |
            | -35    | BUY  | VERIFIED | [0]            |

    Scenario Outline: Get Player Wallet Balances
        Given I add 2 seconds delay
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 0.0      | 0.0              | AT_MAIN-2 | 5.0      | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Update Bonus Prize - status RE_ASSIGNED not supported
        Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
        When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "BONUS_PRIZE_STATUS_NOT_SUPPORTED"

        Examples:
            | providerId | gameId     | status      | amount | closeAccount |
            | PBS        | SPORTSBOOK | RE_ASSIGNED | 0.0    | false        |

    Scenario Outline: Update Bonus Prize - not the owner of the bonusPrizeId
        Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with configured playerId "123456789"
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
        When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "NOT_CORRECT_OWNER"

        Examples:
            | providerId | gameId     | status      | amount | closeAccount |
            | PBS        | SPORTSBOOK | RE_ASSIGNED | 0.0    | false        |

    Scenario Outline: Update Bonus Prize - providerId is missing
        Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with invalid bonusPrizeId
        When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "VALIDATION_ERROR"

        Examples:
            | providerId | gameId     | status      | amount | closeAccount |
            |            | SPORTSBOOK | RE_ASSIGNED | 0.0    | false        |

    Scenario Outline: Update Bonus Prize - status REACHED
        Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
        When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 200
        And I verify the 1-playerId is the field "userId" in the response body
        And I verify the bonusPrizeId is the field "bonusPrizeId" in the response body
        And the "status" in response body is "<status>"

        Examples:
            | providerId | gameId     | status  | amount | closeAccount |
            | PBS        | SPORTSBOOK | REACHED | 0.0    | false        |

    Scenario Outline: Update Bonus Prize - status already REACHED
        Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
        And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
        When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
        Then the API call is successful with status code 400
        And the "errorId" in response body is "INVALID_BONUS_PRIZE_STATUS"
        Examples:
            | providerId | gameId     | status  | amount | closeAccount |
            | PBS        | SPORTSBOOK | REACHED | 0.0    | false        |

#    Scenario Outline: Get Player Wallet Balances
#        Given I add 2 seconds delay
#        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
#        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
#        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
#        Then the API call is successful with status code 200
#        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
#        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
#        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"
#
#        Examples:
#            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
#            | 20.0     | 0.0              | AT_MAIN-1 | 0.0      | 0.0              | AT_MAIN-2 | 10.0     | 0.0              | AT_BONUS_PRIZE |
