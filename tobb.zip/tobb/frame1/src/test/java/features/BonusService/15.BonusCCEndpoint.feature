@BonusService
Feature: CC Bonus Negative Scenarios, Post OB Bonus External Campaign

#  @BonusService
#  Scenario Outline: Add Bonus - Missing bonusName
#    And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
#    When I make a "POST" call to "Bonuses" to service "BonusService"
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "VALIDATION_ERROR"
#
#    Examples:
#      | rewardType        | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
#      | EXTERNAL_CAMPAIGN | SEGMENT         | EXT_EVENT         | EXT_FIXED        | 2030-12-23T00:00:00 | 1           | instants | EM      | false     | -1               | 0            | 0      |          |         |

  Scenario Outline:  Create Bonus - missing bonusAssignment
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Constraint(s) violation occurred during json validation process"
    And the "errorId" in response body is "VALIDATION_ERROR"

    Examples:
      | rewardType        | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
      | EXTERNAL_CAMPAIGN |                 | EXT_EVENT         | EXT_FIXED        | 2030-12-23T00:00:00 | 1           | sports   | OB      | false     | -1               | 0            | 0      |          |         |

  Scenario Outline:  Create Bonus - Invalid GameId
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with extra fields "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<paymentMethodName>" "<paymentMethodPercentage>" "<activationExpiryDays>" "<activationMinimumAmount>" "<rewardAmountType>" "<bonusValidFrom>" "<bonusValidTo>" "<minimumBets>" "<minimumBetAmount>" "<entryRequirement>" "<bonusCode>" "<gameType>" "<gameIds>" "<singleUse>" "<bonusTerms>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Game in bonus being created is not allowed according to allowed games configuration. ([Error Id: GAME_NOT_ALLOWED])"
    And the "errorId" in response body is "GAME_NOT_ALLOWED"

    Examples:
      | rewardType        | bonusAssignment | activationTrigger | rewardAmountType | bonusTerms         | gameType | gameIds    | singleUse | rewardExpiryDays | rewardAmount | entryRequirement | bonusCode | status | rollOver | bonusValidTo        | bonusValidFrom | minimumBets | activationMinimumAmount | minimumBetAmount | program | paymentMethodName | paymentMethodPercentage | activationExpiryDays |
      | EXTERNAL_CAMPAIGN | SEGMENT         | EXT_EVENT         | EXT_FIXED        | http://www.opap.gr | sports   | INVALID_OB | false     | -1               | 20           |                  |           | 0      |          | 2100-12-23T00:00:00 |                |             |                         |                  |         |                   |                         |                      |

  Scenario Outline:  Create Bonus - Date in past
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with extra fields "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<paymentMethodName>" "<paymentMethodPercentage>" "<activationExpiryDays>" "<activationMinimumAmount>" "<rewardAmountType>" "<bonusValidFrom>" "<bonusValidTo>" "<minimumBets>" "<minimumBetAmount>" "<entryRequirement>" "<bonusCode>" "<gameType>" "<gameIds>" "<singleUse>" "<bonusTerms>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Date is in the past ([Error Id: DATE_IN_PAST])"
    And the "errorId" in response body is "DATE_IN_PAST"

    Examples:
      | rewardType        | bonusAssignment | activationTrigger | rewardAmountType | bonusTerms         | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | entryRequirement | bonusCode | status | rollOver | bonusValidTo        | bonusValidFrom | minimumBets | activationMinimumAmount | minimumBetAmount | program | paymentMethodName | paymentMethodPercentage | activationExpiryDays |
      | EXTERNAL_CAMPAIGN | SEGMENT         | EXT_EVENT         | EXT_FIXED        | http://www.opap.gr | sports   | OB      | false     | -1               | 20           |                  |           | 0      |          | 1999-12-23T00:00:00 |                |             |                         |                  |         |                   |                         |                      |

  Scenario Outline:  Create Bonus - rewardType is missing
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with extra fields "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<paymentMethodName>" "<paymentMethodPercentage>" "<activationExpiryDays>" "<activationMinimumAmount>" "<rewardAmountType>" "<bonusValidFrom>" "<bonusValidTo>" "<minimumBets>" "<minimumBetAmount>" "<entryRequirement>" "<bonusCode>" "<gameType>" "<gameIds>" "<singleUse>" "<bonusTerms>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "VALIDATION_ERROR"
    And the property "message" in response body array with index "constraintViolations[0]" contains value "Reward type can not be null"

    Examples:
      | rewardType | bonusAssignment | activationTrigger | rewardAmountType | bonusTerms         | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | entryRequirement | bonusCode | status | rollOver | bonusValidTo        | bonusValidFrom | minimumBets | activationMinimumAmount | minimumBetAmount | program | paymentMethodName | paymentMethodPercentage | activationExpiryDays |
      |            | SEGMENT         | EXT_EVENT         | EXT_FIXED        | http://www.opap.gr | sports   | OB      | false     | 60               | 20           |                  |           | 0      | 1        | 2030-12-23T00:00:00 |                | 1           |                         |                  |         |                   |                         | 31                   |

  Scenario Outline:  Create Bonus - bonusTerms is missing
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with extra fields "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<paymentMethodName>" "<paymentMethodPercentage>" "<activationExpiryDays>" "<activationMinimumAmount>" "<rewardAmountType>" "<bonusValidFrom>" "<bonusValidTo>" "<minimumBets>" "<minimumBetAmount>" "<entryRequirement>" "<bonusCode>" "<gameType>" "<gameIds>" "<singleUse>" "<bonusTerms>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "VALIDATION_ERROR"
#    And the property "message" in response body array with index "constraintViolations[0]" has value "Bonus terms can not be null"

    Examples:
      | rewardType        | bonusAssignment | activationTrigger | rewardAmountType | bonusTerms | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | entryRequirement | bonusCode | status | rollOver | bonusValidTo        | bonusValidFrom | minimumBets | activationMinimumAmount | minimumBetAmount | program | paymentMethodName | paymentMethodPercentage | activationExpiryDays |
      | EXTERNAL_CAMPAIGN | SEGMENT         | EXT_EVENT         | EXT_FIXED        |            | sports   | OB      | false     | 60               | 20           |                  |           | 0      | 1        | 2030-12-23T00:00:00 |                | 1           |                         |                  |         |                   |                         | 31                   |

  Scenario Outline: Create Bonus - success
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200
#    And I copy the value of the first bonusActiveId of providerId "<gameIds>" and rewardType "<rewardType>" from the response
#    And I copy the value of the first bonusName of providerId "<gameIds>" and rewardType "<rewardType>" from the response

    Examples:
      | rewardType        | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
      | EXTERNAL_CAMPAIGN | SEGMENT         | EXT_EVENT         | EXT_FIXED        | 2030-12-23T00:00:00 | 1           | sports   | PBS     | false     | -1               | 0            | 0      |          |         |

  Scenario Outline: Get Active Bonuses - Get BonusActiveId
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200
#    And the "totalRowCount" in response body is "1"
    # FIll the correct bonusActive details
    And I copy the value of the first bonusActiveId of providerId "<providerId>" and rewardType "<rewardType>" from the response
    And I copy the value of the first bonusName of providerId "<providerId>" and rewardType "<rewardType>" from the response

    Examples:
      | keys                       | values        | providerId | rewardType        |
      | status,pageNumber,pageSize | ACTIVE,1,1000 | PBS        | EXTERNAL_CAMPAIGN |

  Scenario Outline: Get Bonus OB - Verify Allowed Games - success
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AllowedGames" of service "BonusService" with configured parameter "bonus" "bonusId"
    And I change url resource of method "AllowedGames" of service "BonusService" with new bonusActiveId
    When I make a "GET" call to "AllowedGames" to service "BonusService"
    Then the API call is successful with status code 200
    And the property "<property1>" in response body array with index "[0]" has value "<value1>"
    And the property "<property2>" in response body array with index "[0]" has value "<value2>"

    Examples:
      | property1 | value1 | property2 | value2 |
      | gameType  | sports | gameIds   | PBS    |

  @NoRetry
  Scenario: Get Bonus OB - Verify Allowed Games - not found
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AllowedGames" of service "BonusService" with configured parameter "bonus" "bonusId"
    And I change url resource of method "AllowedGames" of service "BonusService" with invalid bonusActiveId "text"
    When I make a "GET" call to "AllowedGames" to service "BonusService"
    Then the API call is successful with status code 404

  Scenario Outline: Post Allowed Games - Cannot edit after bonus activation
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST AllowedGames payload with "<property1>" "<value1>"
    And I change url resource of method "AllowedGames" of service "BonusService" with configured parameter "bonus" "bonusId"
    And I change url resource of method "AllowedGames" of service "BonusService" with new bonusActiveId
    When I make a "POST" call to "AllowedGames" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "BONUS_ACTIVE_ALLOWED_GAMES_ERROR"
    And the "description" in response body is "Updating allowed games of the active bonus is not permitted ([Error Id: BONUS_ACTIVE_ALLOWED_GAMES_ERROR])"

    Examples:
      | property1 | value1    |
      | sports    | BETGENIUS |

  Scenario: Get BonusId - success
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetCCBonusWithId" of service "BonusService" with new bonusActiveId
    When I make a "GET" call to "GetCCBonusWithId" to service "BonusService"
    Then the API call is successful with status code 200
    And the "bonusAssignment" in response body is "SEGMENT"
    And the "rewardType" in response body is "EXTERNAL_CAMPAIGN"
    And the "rewardAmountType" in response body is "EXT_FIXED"
    And the "allowedGames[0].gameIds[0]" in response body is "PBS"
    And the "status" in response body is "ACTIVE"
    And the "activationTrigger" in response body is "EXT_EVENT"

  @NoRetry
  Scenario: Get Bonus - Invalid bonusName
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetCCBonusWithName" of service "BonusService" with bonusName "test"
    When I make a "GET" call to "GetCCBonusWithName" to service "BonusService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "BONUS_NOT_FOUND"
    And the "description" in response body is "Bonus not found ([Error Id: BONUS_NOT_FOUND])"

  Scenario Outline: Get Bonus - ValidFrom/ValidTo Param is missing
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200

    Examples:
      | keys                         | values                  |
      | validFrom,validTo,pageNumber | 2019-01-01,2030-12-12,1 |

  Scenario Outline: Get Bonus - ValidTo Param is missing
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "VALID_TO_MISSING"
    And the "description" in response body is "Valid To date is missing. ([Error Id: VALID_TO_MISSING])"

    Examples:
      | keys      | values     |
      | validFrom | 2019-12-12 |

  Scenario Outline: Get Bonus - ValidFrom Param is missing
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "VALID_FROM_MISSING"
    And the "description" in response body is "Valid From date is missing. ([Error Id: VALID_FROM_MISSING])"

    Examples:
      | keys    | values     |
      | validTo | 2030-01-01 |
