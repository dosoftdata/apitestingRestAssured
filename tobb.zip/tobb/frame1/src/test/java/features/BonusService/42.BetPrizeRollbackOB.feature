@BonusService
Feature: Test Bet Prize Rollback OB bonus

    Scenario Outline: Bet Reserve successful - main account
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "-6.0"
        And the property "postBalance" in response body array with index "[0]" has value "50.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "BUY"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -6.00  | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | true     | 0.0       | "OB"   | 0.0         |                      |

    Scenario Outline: Bet Prize - main wallet
        Given I add 3 seconds delay
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "10.0"
        And the property "postBalance" in response body array with index "[0]" has value "60.0"

        Examples:
            | accountId | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | 10.00  | DEFAULT  | datenow | SPORTSBOOK | PRIZE | prize       | TRUE        | VERIFIED | TRUE     | 10.0      | "OB"   | 0.0         | 0.00          | test                 |

    Scenario Outline: Prize Rollback succ - 10 main wallet
        Given I add 3 seconds delay
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "[0]" has value "<type>"
        And the property "status" in response body array with index "[0]" has value "<status>"
        And the property "amount" in response body array with index "[0]" has value "-10.0"
        And the property "postBalance" in response body array with index "[0]" has value "60.0"
        And the property "productId" in response body array with index "[0]" has value "<productId>"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body

        Examples:
            | accountId | amount | currency | issued  | productId  | type           | description    | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | -10.0  | DEFAULT  | datenow | SPORTSBOOK | PRIZE_ROLLBACK | prize-rollback | TRUE        | VERIFIED | TRUE     | 10.0      | "OB"   | 0.0         | 0.00          | test                 |

    Scenario Outline: Get Player Wallet Balances
        Given I add 3 seconds delay
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "OB"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 50.0     | 0.0              | AT_MAIN-2 | 44.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Bet Reserve successful - mixed accounts
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "-50.0"
        And the property "postBalance" in response body array with index "[0]" has value "0.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "BUY"
        And the property "bonusPrizeId" in response body array with index "[1]" has value "bonusPrizeId"
        And the property "amount" in response body array with index "[1]" has value "-14.0"
        And the property "postBalance" in response body array with index "[1]" has value "30.0"
        And the property "status" in response body array with index "[1]" has value "VERIFIED"
        And the property "type" in response body array with index "[1]" has value "BUY"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -64.00 | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | true     | 0.0       | "OB"   | 0.0         |                      |

    Scenario Outline: Bet Prize - mixed wallets
        Given I add 3 seconds delay
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200

        Examples:
            | accountId | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | 100.00 | DEFAULT  | datenow | SPORTSBOOK | PRIZE | prize       | TRUE        | VERIFIED | TRUE     | 10.0      | "OB"   | 0.0         | 0.00          | test                 |

    Scenario Outline: Prize Rollback succ - 10 main wallet
        Given I login as an Api user
        Given I setup gameId header to "SPORTSBOOK"
        And I create a PlayBetFundsExtra payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<bonusRollover>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        When I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200

        Examples:
            | accountId | amount | currency | issued  | productId  | type           | description    | autocapture | status   | captured | taxAmount | gameId | bonusAmount | bonusRollover | metadataBonusPrizeId |
            | AT_MAIN-2 | -100.0 | DEFAULT  | datenow | SPORTSBOOK | PRIZE_ROLLBACK | prize-rollback | TRUE        | VERIFIED | TRUE     | 10.0      | "OB"   | 0.0         | 0.00          | test                 |

    Scenario Outline: Get Player Wallet Balances
        Given I add 3 seconds delay
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "OB"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
#        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 0.0      | 0.0              | AT_MAIN-2 | 30.0     | 0.0              | AT_BONUS_PRIZE |
