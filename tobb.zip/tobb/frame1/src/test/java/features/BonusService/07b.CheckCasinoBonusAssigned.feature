Feature: Check Casino Bonus Prize is assigned

  @BonusService
  Scenario Outline: Get Bonus Prizes with gameId EM and status ASSIGNED
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And I verify the property "remainingRolloverAmount" has value "0.0"
    And I verify the property "bonus.bonusTerms" has value "http://www.opap.gr"
    And I verify the property "bonus.rewardType" has value "EXTERNAL_CAMPAIGN"
    And I verify the property "bonus.rewardAmountType" has value "EXT_FIXED"
    And I verify the property "bonus.bonusRollover" has value "0.0"
    And I verify the property "bonus.bonusAssignmentType" has value "SEGMENT"
    And I verify the property "bonus.bonusRewardAmount" has value "0.0"
    And I verify the property "status" has value "ASSIGNED"
    And I copy the value of the bonusPrizeId from the response if exists


    Examples:
      | keys          | values      |
      | gameId,status | EM,ASSIGNED |

  @BonusService
  Scenario Outline: Update BonusPrize - RE-ASSIGNED not allowed
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
    When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 400
    And the "description" in response body is "BonusPrizeId not in status active ([Error Id: INVALID_BONUS_PRIZE_STATUS])"
    And the "errorId" in response body is "INVALID_BONUS_PRIZE_STATUS"

    Examples:
      | keys          | values      | providerId | gameId | status      | amount | closeAccount |
      | gameId,status | EM,ASSIGNED | EM         | CASINO | RE_ASSIGNED | 40     | false        |
