Feature: Create External Campaign Bonus

    @BonusService
    Scenario Outline: Get Active Bonuses - Verify NO bonuses active
        Given I login as a "configuredPlayerCc" user
        Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
        When I make a "GET" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 200
#    And the "totalRowCount" in response body is "0"

        Examples:
            | keys                       | values        |
            | status,pageNumber,pageSize | ACTIVE,1,1000 |


    @BonusService
    Scenario Outline: Add Bonus - GameType and GameId are missing
        And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
        When I make a "POST" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 400
        And the "description" in response body is "Game in bonus being created is not allowed according to allowed games configuration. ([Error Id: GAME_NOT_ALLOWED])"
        And the "errorId" in response body is "GAME_NOT_ALLOWED"

        Examples:
            | rewardType        | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
            | EXTERNAL_CAMPAIGN | SEGMENT         | EXT_EVENT         | EXT_FIXED        | 2030-12-23T00:00:00 | 1           |          |         | false     | -1               | 0            | 0      |          |         |


    @BonusService
    Scenario Outline: Add Bonus - OB
        Given I create a Get "cc_csrftokenSpec" header
        And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
        When I make a "POST" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 200
        And the "bonusAssignment" in response body is "SEGMENT"
        And the "rewardType" in response body is "EXTERNAL_CAMPAIGN"
        And the "rewardAmountType" in response body is "EXT_FIXED"
        And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
        And the "status" in response body is "ACTIVE"

        Examples:
            | property | arrayWithIndex  | propertyValue | rewardType        |  | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
            | gameIds  | allowedGames[0] | OB            | EXTERNAL_CAMPAIGN |  | SEGMENT         | EXT_EVENT         | EXT_FIXED        | 2030-12-23T00:00:00 | 1           | sports   | OB      | false     | -1               | 0            | 0      |          |         |


    @BonusService
    Scenario Outline: Get Active Bonus - Verify Active Bonus Active
        Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
        When I make a "GET" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 200
#    And the "totalRowCount" in response body is "1"
        And I copy the value of the first bonusActiveId of providerId "<gameIds>" and rewardType "<rewardType>" from the response

        Examples:
            | keys                       | values        | gameIds | rewardType        |
            | status,pageNumber,pageSize | ACTIVE,1,1000 | OB      | EXTERNAL_CAMPAIGN |


    @BonusService
    Scenario Outline: Add Bonus - EM
        And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
        When I make a "POST" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 200
        And the "bonusAssignment" in response body is "SEGMENT"
        And the "rewardType" in response body is "EXTERNAL_CAMPAIGN"
        And the "rewardAmountType" in response body is "EXT_FIXED"
        And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
        And the "status" in response body is "ACTIVE"

        Examples:
            | property | arrayWithIndex  | propertyValue | rewardType        | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
            | gameIds  | allowedGames[0] | EM            | EXTERNAL_CAMPAIGN | SEGMENT         | EXT_EVENT         | EXT_FIXED        | 2030-12-23T00:00:00 | 1           | instants | EM      | false     | -1               | 0            | 0      |          |         |


    @BonusService
    Scenario Outline: Get Active Bonuses EM - Verify Active Bonus Active
        Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
        When I make a "GET" call to "Bonuses" to service "BonusService"
        Then the API call is successful with status code 200
#    And the "totalRowCount" in response body is "2"
        And the property "gameIds[0]" in response body array with index "pageItems[0].allowedGames[0]" has value "EM"
        And the property "rewardType" in response body array with index "pageItems[0]" has value "EXTERNAL_CAMPAIGN"
        And the property "bonusAssignment" in response body array with index "pageItems[0]" has value "SEGMENT"
        And the property "activationTrigger" in response body array with index "pageItems[0]" has value "EXT_EVENT"
        And the property "status" in response body array with index "pageItems[0]" has value "ACTIVE"
        And the property "gameType" in response body array with index "pageItems[0].allowedGames[0]" has value "instants"
        And I copy the value of the first bonusActiveId of providerId "EM" and rewardType "EXTERNAL_CAMPAIGN" from the response

        Examples:
            | keys                       | values        |
            | status,pageNumber,pageSize | ACTIVE,1,1000 |


    @BonusService
    Scenario Outline: Get Bonus EM - Verify Allowed Games
        Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
        And I change url resource of method "AllowedGames" of service "BonusService" with new bonusActiveId
        When I make a "GET" call to "AllowedGames" to service "BonusService"
        Then the API call is successful with status code 200
        And the property "gameType" in response body array with index "[0]" has value "instants"
        And the property "gameIds" in response body array with index "[0]" has value "EM"

        Examples:
            | keys                                | values                     |  |  |
            | bonusId, status,pageNumber,pageSize | bonusPrizeId,ACTIVE,1,1000 |  |  |


    @BonusService
    Scenario Outline: Check Bonus Casino with BonusId
        Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
        And I change url resource of method "GetCCBonusWithId" of service "BonusService" with new bonusActiveId
        When I make a "GET" call to "GetCCBonusWithId" to service "BonusService"
        Then the API call is successful with status code 200
        And the "bonusAssignment" in response body is "SEGMENT"
        And the "rewardType" in response body is "EXTERNAL_CAMPAIGN"
        And the "rewardAmountType" in response body is "EXT_FIXED"
        And the "allowedGames[0].gameIds[0]" in response body is "EM"
        And the "status" in response body is "ACTIVE"
        And the "activationTrigger" in response body is "EXT_EVENT"
        And the property "gameIds[0]" in response body array with index "allowedGames[0]" contains value "EM"

        Examples:
            | keys                       | values        |  |  |
            | status,pageNumber,pageSize | ACTIVE,1,1000 |  |  |

#  @BonusService
#  Scenario Outline: Update Bonus with fdbEnabled
#    Given I create a Get "cc_csrftokenSpec" header
#    When I create a PUT updateFdbBonus payload with "<fdbEnabled>" "<fdbLinkEl>" "<fdbLinkEn>"
#    And I change url resource of method "ModifyFdbForBonus" of service "BonusService" with new bonusActiveId
#    And I make a "PUT" call to "ModifyFdbForBonus" to service "BonusService"
#    Then the API call is successful with status code 204
#
#    Examples:
#      | fdbEnabled | fdbLinkEl          | fdbLinkEn          |
#      | true       | http://www.opap.gr | http://www.opap.gr |
