@BonusService
Feature: Test Bet Reserve


    Scenario Outline: Bet Reserve - Invalid Transaction Type
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 400
        And the "description" in response body is "Invalid type value ([Error Id: INVALID_TRANSACTION_TYPE])"
        And the "errorId" in response body is "INVALID_TRANSACTION_TYPE"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -300   | DEFAULT  | datenow | SPORTSBOOK | TEST | Bet         | true        | VERIFIED | false    | 0.0       | "PBS"  | 0.0         |                      |

    Scenario Outline: Bet Reserve - mainAccountBalance < mainAmount and bonusAmount = 0
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 400
        And the "description" in response body is "Provided amount is greater than main wallet balance ([Error Id: INVALID_MAIN_WALLET_AMOUNT]) ([Error Id: INVALID_MAIN_WALLET_AMOUNT] Provided amount is greater than main wallet balance ([Error Id: INVALID_MAIN_WALLET_AMOUNT]))"
        And the "errorId" in response body is "INVALID_MAIN_WALLET_AMOUNT"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -300   | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | "PBS"  | 0.0         |                      |

    Scenario Outline: Bet Reserve - mainAccountBalance < mainAmount and bonusAmount = 0
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 400
        And the "description" in response body is "Provided amount is greater than main wallet balance ([Error Id: INVALID_MAIN_WALLET_AMOUNT]) ([Error Id: INVALID_MAIN_WALLET_AMOUNT] Provided amount is greater than main wallet balance ([Error Id: INVALID_MAIN_WALLET_AMOUNT]))"
        And the "errorId" in response body is "INVALID_MAIN_WALLET_AMOUNT"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -300   | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | "PBS"  | 0.0         |                      |

    Scenario Outline: Bet Reserve - mainAccountBalance < mainAmount and bonusAmount !=0
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 400
        And the "description" in response body is "Provided amount is greater than main wallet balance ([Error Id: INVALID_MAIN_WALLET_AMOUNT]) ([Error Id: INVALID_MAIN_WALLET_AMOUNT] Provided amount is greater than main wallet balance ([Error Id: INVALID_MAIN_WALLET_AMOUNT]))"
        And the "errorId" in response body is "INVALID_MAIN_WALLET_AMOUNT"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -300   | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | "PBS"  | 50.0        |                      |

    Scenario Outline: Bet Reserve - bonusAccountBalance < bonusAmount and mainAmount!=0
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 400
        And the "description" in response body is "Provided amount is greater than bonus wallet balance ([Error Id: INVALID_BONUS_WALLET_AMOUNT]) ([Error Id: INVALID_BONUS_WALLET_AMOUNT] Provided amount is greater than bonus wallet balance ([Error Id: INVALID_BONUS_WALLET_AMOUNT]))"
        And the "errorId" in response body is "INVALID_BONUS_WALLET_AMOUNT"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -200   | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | "PBS"  | -100.0      |                      |

    Scenario Outline: Bet Reserve - bonusAccountBalance < bonusAmount and mainAmount=0
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 400
        And the "description" in response body is "Provided amount is greater than bonus wallet balance ([Error Id: INVALID_BONUS_WALLET_AMOUNT]) ([Error Id: INVALID_BONUS_WALLET_AMOUNT] Provided amount is greater than bonus wallet balance ([Error Id: INVALID_BONUS_WALLET_AMOUNT]))"
        And the "errorId" in response body is "INVALID_BONUS_WALLET_AMOUNT"

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | 0.00   | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | "PBS"  | -100.0      |                      |

    Scenario Outline: Bet Reserve - mainAccountBalance.isEqualTo(mainAmount + bonusAmount)
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 400
        And the "description" in response body is "Provided amounts are not valid or not correctly distributed ([Error Id: INVALID_TRANSACTION_AMOUNTS]) ([Error Id: INVALID_TRANSACTION_AMOUNTS] Provided amounts are not valid or not correctly distributed ([Error Id: INVALID_TRANSACTION_AMOUNTS]))"
        And the "errorId" in response body is "INVALID_TRANSACTION_AMOUNTS"

        Examples:
            | xGameId    | accountId | amount  | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -190.00 | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | "PBS"  | -10.0       |                      |

    Scenario Outline: Bet Reserve - mainAccountBalance.isGreaterThan(mainAmount + bonusAmount)
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 400
        And the "description" in response body is "Provided amounts are not valid or not correctly distributed ([Error Id: INVALID_TRANSACTION_AMOUNTS]) ([Error Id: INVALID_TRANSACTION_AMOUNTS] Provided amounts are not valid or not correctly distributed ([Error Id: INVALID_TRANSACTION_AMOUNTS]))"
        And the "errorId" in response body is "INVALID_TRANSACTION_AMOUNTS"

        Examples:
            | xGameId    | accountId | amount  | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -180.00 | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | "PBS"  | -10.0       |                      |

    Scenario Outline: Bet Reserve insufficient balance
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 400
        And the "description" in response body is "Provided amount is greater than main wallet balance ([Error Id: INVALID_MAIN_WALLET_AMOUNT]) ([Error Id: INVALID_MAIN_WALLET_AMOUNT] Provided amount is greater than main wallet balance ([Error Id: INVALID_MAIN_WALLET_AMOUNT]))"
        And the "errorId" in response body is "INVALID_MAIN_WALLET_AMOUNT"

        Examples:
            | xGameId    | accountId | amount  | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -300.00 | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | "PBS"  | -100.0      |                      |

    Scenario Outline: Bet Reserve successful - mainWalletOnly
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "-150.0"
        And the property "postBalance" in response body array with index "[0]" has value "200.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "BUY"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount  | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -150.00 | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | 0.0       | "PBS"  | 0.0         |                      |

    Scenario Outline: CaptureBet -  Verify type & status
        Given I create a CaptureBet payload with <amount>
        And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
        And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
        When I make a "POST" call to "CaptureBet" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
        And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

        Examples:
            | amount | type | status   | arrayWithIndex |
            | -150   | BUY  | VERIFIED | [0]            |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 50.0     | 0.0              | AT_MAIN-2 | 50.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Bet Reserve successful - mainWalletOnly
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" has value "AT_MAIN-2"
        And the property "amount" in response body array with index "[0]" has value "-50.0"
        And the property "postBalance" in response body array with index "[0]" has value "50.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "BUY"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | -50.00 | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | 0.0       | "PBS"  | -5.0        |                      |

    Scenario Outline: CaptureBet -  Verify type & status
        Given I create a CaptureBet payload with <amount>
        And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
        And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
        When I make a "POST" call to "CaptureBet" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
        And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

        Examples:
            | amount | type | status   | arrayWithIndex |
            | -55    | BUY  | VERIFIED | [0]            |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 0.0      | 0.0              | AT_MAIN-2 | 45.0     | 0.0              | AT_BONUS_PRIZE |

    Scenario Outline: Wager funds - Bet Reserve successful - bonusPrizeWallet
        Given I setup gameId header to "<xGameId>"
        And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
        And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
        And I make a "POST" call to "PlayBetFunds" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "accountId" in response body array with index "[0]" does not have value "AT_MAIN-2"
        And the property "accountId" in response body array with index "[0]" does not have value "AT_MAIN-1"
        And the property "amount" in response body array with index "[0]" has value "-5.0"
        And the property "postBalance" in response body array with index "[0]" has value "45.0"
        And the property "status" in response body array with index "[0]" has value "VERIFIED"
        And the property "type" in response body array with index "[0]" has value "BUY"
        And I verify the bonusPrizeId is the field "[0].bonusPrizeId" in the response body

        Examples:
            | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
            | SPORTSBOOK | AT_MAIN-2 | 0.00   | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | 0.0       | "PBS"  | -5.0        |                      |

    Scenario Outline: CaptureBet -  Verify type & status
        Given I create a CaptureBet payload with <amount>
        And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
        And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
        When I make a "POST" call to "CaptureBet" to service "WagerService"
        Then the API call is successful with status code 200
        And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
        And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

        Examples:
            | amount | type | status   | arrayWithIndex |
            | -5     | BUY  | VERIFIED | [0]            |

    Scenario Outline: Get Player Wallet Balances
        Given I create a Get "api_mainSpec_mainHost" header with query params "gameId" "PBS"
        And I change url resource of method "GetAPIWalletBalance" of service "WalletService" with new playerId
        When I make a "GET" call to "GetAPIWalletBalance" to service "WalletService"
        Then the API call is successful with status code 200
        And I verify the response for GetAPIWalletBalance for <balance1> <reservedBalance1> for "<wallet1>"
        And I verify the response for GetAPIWalletBalance for <balance2> <reservedBalance2> for "<wallet2>"
        And I verify the response for GetAPIWalletBalance for <balance3> <reservedBalance3> for "<wallet3>"

        Examples:
            | balance1 | reservedBalance1 | wallet1   | balance2 | reservedBalance2 | wallet2   | balance3 | reservedBalance3 | wallet3        |
            | 20.0     | 0.0              | AT_MAIN-1 | 0.0      | 0.0              | AT_MAIN-2 | 40.0     | 0.0              | AT_BONUS_PRIZE |