@AccessService
Feature: Login And Accept Contracts

  Scenario Outline: Login - Negative Cases
    Given I create a POST LoginNew payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code 400
    And the "<errorProperty1>" in response body is "<errorId>"
    And the "<errorProperty2>" in response body is "<description>"


    Examples:
      | username     | password     | group | channel | errorProperty1 | errorProperty2    | errorId         | description                                                       |
      |              | zzzzz        | EP    | WEB     | error          | error_description | invalid_request | Invalid request                                                   |
      | newPlayerWeb | Qwerty12345! | EP    | test    | errorId        | description       | INVALID_CHANNEL | The specified channel is not valid. ([Error Id: INVALID_CHANNEL]) |


  Scenario Outline: Login - Success
    Given I create a POST LoginNew payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code 200

    Examples:
      | username     | password     | group | channel |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     |


  Scenario: Get Session Minutes - Success after 1st Login
    And I create a Get "mainSpec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 200
    And the "logoutMethod" in response body is "LOGOUT_SELECTED"
    And the "channel" in response body is "WEB"
    And the "minutes" in response body is above -1
    # and loginTime in response body to include time?

  @NoRetry
  Scenario Outline: AcceptContractAgreements - Negative Scenario
    Given I create a Get "mainSpec" header
    When I make a "POST" call to "AcceptContractAgreements" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | errorId               | description           |
      | INTERNAL_SERVER_ERROR | Internal Server Error |


  Scenario Outline: AcceptContractAgreements - Empty Body
    Given I create an empty payload with header "mainSpec"
    When I make a "POST" call to "AcceptContractAgreements" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | errorId              | description                                                                       |
      | NO_PENDING_AGREEMENT | No pending contract agreement found in session ([Error Id: NO_PENDING_AGREEMENT]) |


  Scenario: Delete - Delete Current session token web
    Given I create a Get "mainSpec" header
    When I make a "DEL" call to "DeleteCurrentSessionToken" to service "AccessService"
    Then the API call is successful with status code 204


  @NoRetry
  Scenario: Get - GetSessionWeb - Negative Already LoggedOut
    Given I create a Get "mainSpec" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code 401


  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @NoRetry
  Scenario: Get- GetSessionMinutesWeb - Negative - Already LoggedOut
    Given I create a Get "mainSpec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 401

  @NoRetry
  Scenario: Get - GetSessionWeb - Negative Already LoggedOut
    Given I create a Get "mainSpec" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code 401
