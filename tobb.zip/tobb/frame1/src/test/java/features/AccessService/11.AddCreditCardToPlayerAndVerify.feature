@AccessService
Feature: Add Credit Card To Player And Verify

# @skipIfAzure
#  Scenario Outline: Set Master Card Details
#    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
#    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
#    Then the API call is successful with status code 200
#    And I copy the value of the deposit tokenId
#
##    @skipIfPreprod
##    Examples:
##      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
##      | 5000   | 5413330002001031 | TEST PROD  | 100 | 06        | 2025     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |
#    @skipIfPreprod
#    Examples:
#      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
#      | 5000   | 5588686116426417 | TEST PROD  | 100 | 06        | 2025     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |
#
#    @skipIfNotPreprod
#    Examples:
#      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
#      | 5000   | 4543474002249996 | TEST PROD  | 956 | 06        | 2025     | EUR      | pk_U0jMXzvD8cOv0kx0qDHghRVZ56TCELA7 |
#
#
#  Scenario Outline: Deposit via Card - Lottery wallet (JOKER)
#   Given I login as a "newPlayerWeb" user
#    And I setup gameId header to "JOKER"
#    When I create a Post DepositViaCard payload with "<amount>"
#    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
#    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
#    Then the API call is successful with status code 202
#    And I copy the value of the paymentId for deposit via card
#
#    Examples:
#      | amount |
#      | 100    |
#
#
#  @AccessService  @skipIfNotAzure
#  Scenario Outline: Tora response 200 for Deposits via Card1
#    Given I setup deposit paymentId "<paymentId>" and card fingerprint "<cardFingerprint1>"
#    And I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
#    When I make a "POST" call to "AddAStub" to service "WiremockService"
#    Then the API call is successful with status code 201
#
#    Examples:
#      | paymentId | cardFingerprint1                                                 | scenarioName                 | requiredScenarioState | priority | method | url          | status | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | headers          |
#      | random    | 5a8c3cec619b62ed3b4b4d98f1b57ae0fa3f4b65ca483a0954f0e6c885724566 | ToraDepositsResponse200Card1 | Started               | 100      | ANY    | /v1/payments | 200    | {\"id\":\"pmt_IEuiimeTppo4AZIHKsKgro2Q\",\"object\":\"payment\",\"captured\":true,\"amount\": \"5000\",\"currency\":\"EUR\",\"description\":\"OPAP wallet deposit id:{{paymentIdViaPaymentCard}}\",\"meta\":{\"paymentId\":\"{{paymentIdViaPaymentCard}}\",\"playerId\":\"{{playerId}}\"},\"status\":\"captured\",\"merchant_reference\":\"paymentId:\"{{paymentIdViaPaymentCard}}\",\"customer\":null,\"method\":\"card\",\"method_info\":{\"holder_name\":\"TEST PROD\",\"exp_year\":2025,\"exp_month\":6,\"last4\":\"0001\",\"brand\":\"visa\",\"bin\":\"465858\",\"fingerprint\":\"{{Card1_fingerprint}}\"},\"created_at\":\"2019-02-25T13:36:14+00:00\",\"updated_at\":\"2019-02-25T13:36:15+00:00\",\"captured_at\":\"2019-02-25T13:36:15+00:00\",\"refunded\":false,\"refunds\":[],\"refunded_amount\":\"0\",\"fee_amount\":0,\"error_code\":null,\"error_message\":null,\"transaction_id\":\"charge_test_0C2919DE543J66FAA618\"} | application/json |
#
#
#  Scenario: Commit Card Deposit To Tora
#    When I create a CommitCardDeposit to Tora Put payload
#    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
#    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
#    Then the API call is successful with status code 202
#    And the "amount" in response body is "100.0"
#    And I verify the player id "playerId" in the response body
#    And I verify the deposit paymentId via card
#    And

#  Scenario Outline: Get BO Pending Verifications of Player - Verify Card values
#    Given I create a Get "cc_csrftokenSpec" header
#    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with new playerId
#    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
#    Then the API call is successful with status code 200
#    And I verify Card Pending Verification with status "<status>" "<cardExpirationYear>" "<cardName>" "<cardNumber>" "<cardHolderName>" "<cardExpirationMonth>"
#
#    Examples:
#      | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
#      | WAITING_ADMIN_APPROVAL | 2025               | master   | 558868******6417 | TEST PROD      | 06                  |
#
#
#  Scenario Outline: Upload card Documents (Front)
#    When I create a UploadDocumentsWeb payload with "<fileName>" "<type>"
#    And I change url resource of method "UploadDocumentsWeb" of service "PlayerService" with new playerId
#    When I make a "POST" call to "UploadDocumentsWeb" to service "PlayerService"
#    Then the API call is successful with status code 200
#    Examples:
#      | fileName    | type       |
#      | IDfront.JPG | CARD_FRONT |
#
#  Scenario Outline: Get BO Pending Verifications of Player - Verify Card values
#    Given I create a Get "cc_csrftokenSpec" header
#    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with new playerId
#    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
#    Then the API call is successful with status code 200
#    And I verify Card Pending Verification with status "<status>" "<cardExpirationYear>" "<cardName>" "<cardNumber>" "<cardHolderName>" "<cardExpirationMonth>"
#
#    Examples:
#      | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
#      | WAITING_ADMIN_APPROVAL | 2025               | master   | 558868******6417 | TEST PROD      | 06                  |
#
#
############ subType : This variable is not send in request but to specify the variable in which the verification is done
############ subType values : FRONT,BACK (for CARD type) - OTHER,UTILITY (for IDENTITY type)
#  Scenario Outline: Verify Card Documents - CARD FRONT
#    When I create a VerifyDocuments payload with "<verificationType>" "<statusDescription>" and subcategory "<subType>"
#    And I change url resource of method "VerifyDocuments" of service "PlayerService" with new playerId
#    When I make a "POST" call to "VerifyDocuments" to service "PlayerService"
#    Then the API call is successful with status code 200
#    And the "verificationType" in response body is "<verificationType>"
#    And the "documentType" in response body is "<documentTypeResponse>"
#    And the "statusDescription" in response body is "<statusDescription>"
#    And the "status" in response body is "<statusValue>"
#
#    Examples:
#      | verificationType | statusDescription | subType | statusValue | documentTypeResponse |
#      | CARD             | Looks fine        | FRONT   | APPROVED    | CARD_FRONT           |
#
#  Scenario Outline: Confirm Verification of Player's Card - Verify Type/Status and save cardNumber
#    When I create a VerificationConfirm payload with "<verificationType>"
#    And I change url resource of method "VerificationConfirm" of service "PlayerService" with new playerId
#    When I make a "POST" call to "VerificationConfirm" to service "PlayerService"
#    Then the API call is successful with status code 200
#    And the "verificationType" in response body is "<verificationType>"
#    And the "status" in response body is "<statusValue>"
#    And I copy the value of the fingerprint from the response
#    And I copy the value of the cardNumber from the response
#
#    Examples:
#      | verificationType | statusValue |
#      | CARD             | VERIFIED    |
#
#
#  Scenario Outline: Get and Verify Payment Codes
#    Given I login as a "configuredPlayerCc" user
#    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
#    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
#    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
#    Then the API call is successful with status code 200
#    And I copy the values of the Payment Codes
#    #assertions?
#
#    Examples:
#      | keys     | values |
#      | category | ALL    |
#
#  Scenario Outline: Get and Verify - Wallets Balance
#    When I create a Get "cc_csrftokenSpec" header
#    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
#    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
#    Then the API call is successful with status code 200
#    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
#    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
#
#    Examples:
#      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
#      | 620.0    | 620.0        | 20.0                    | 0.0              | 500.0                | 20.0     | 20.0         | 20.0                    | 0.0              | 0.0                  |
#


#  Scenario Outline: Get Player Levels
#    Given I create a Get "specWithGameId" header
#    And I change url resource of method "GetPlayerLevels" of service "PlayerService" with new playerId
#    When I make a "GET" call to "GetPlayerLevels" to service "PlayerService"
#    Then the API call is successful with status code 200
#    And the "<key>" in response body is "<value>"
#
#    Examples:
#      | key         | value             |
#      | playerLevel | TEMPORARY_ACCOUNT |


#  @nightlySuite @Preprod
#  Scenario Outline: Upload card Documents (Front)
#    When I create a UploadDocumentsWeb payload with "<fileName>" "<type>"
#    And I change url resource of method "UploadDocumentsWeb" of service "PlayerService" with new playerId
#    When I make a "POST" call to "UploadDocumentsWeb" to service "PlayerService"
#    Then the API call is successful with status code 200
#    Examples:
#      | fileName    | type       |
#      | IDfront.JPG | CARD_FRONT |
#
#
#  Scenario Outline: Get BO Pending Verifications of Player - Verify Card values
#    Given I create a Get "cc_csrftokenSpec" header
#    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with new playerId
#    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
#    Then the API call is successful with status code 200
#    And I verify Card Pending Verification with status "<status>" "<cardExpirationYear>" "<cardName>" "<cardNumber>" "<cardHolderName>" "<cardExpirationMonth>"
#
##    @nightlySuite
#    @skipIfPreprod
#    Examples:
#      | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
#      | WAITING_ADMIN_APPROVAL | 2025               | master   | 541333******1031 | TEST PROD      | 06                  |
#
#   @Preprod
#    Examples:
#      | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
#      | WAITING_ADMIN_APPROVAL | 2025               | master   | 519999******1465 | TEST PROD      | 06                  |
#
#
##  @nightlySuite @Preprod
#  Scenario Outline: Get Uploaded documents - Verify Card Documents (CARD_FRONT)
#    Given I create a Get "cc_csrftokenSpec" header
#    And I change url resource of method "GetUploadedDocuments" of service "PlayerService" with new playerId
#    When I make a "GET" call to "GetUploadedDocuments" to service "PlayerService"
#    Then the API call is successful with status code 200
#    And I verify Uploaded Documents with "<types>" "<fileName>" "<fileType>"
#
#    Examples:
#      | types      | fileName    | fileType   |
#      | CARD_FRONT | IDfront.JPG | image/jpeg |
#
############ subType : This variable is not send in request but to specify the variable in which the verification is done
############ subType values : FRONT,BACK (for CARD type) - OTHER,UTILITY (for IDENTITY type)
##  @nightlySuite @Preprod
#  Scenario Outline: Verify Card Documents - CARD FRONT
#    When I create a VerifyDocuments payload with "<verificationType>" "<statusDescription>" and subcategory "<subType>"
#    And I change url resource of method "VerifyDocuments" of service "PlayerService" with new playerId
#    When I make a "POST" call to "VerifyDocuments" to service "PlayerService"
#    Then the API call is successful with status code 200
#    And the "verificationType" in response body is "<verificationType>"
#    And the "documentType" in response body is "<documentTypeResponse>"
#    And the "statusDescription" in response body is "<statusDescription>"
#    And the "status" in response body is "<statusValue>"
#
#
#    Examples:
#      | verificationType | statusDescription                  | subType | statusValue | documentTypeResponse |
#      | CARD             | Approve uploaded document for Card | FRONT   | APPROVED    | CARD_FRONT           |
#
#
##  @nightlySuite @Preprod
#  Scenario Outline: Upload card Documents (Back)
#    When I create a UploadDocumentsWeb payload with "<fileName>" "<type>"
#    And I change url resource of method "UploadDocumentsWeb" of service "PlayerService" with new playerId
#    When I make a "POST" call to "UploadDocumentsWeb" to service "PlayerService"
#    Then the API call is successful with status code 200
#    Examples:
#      | fileName   | type      |
#      | IDback.JPG | CARD_BACK |
#
#
##  @nightlySuite @Preprod
#  Scenario Outline: Get Uploaded documents - Verify Card Documents (CARD_BACK)
#    Given I create a Get "cc_csrftokenSpec" header
#    And I change url resource of method "GetUploadedDocuments" of service "PlayerService" with new playerId
#    When I make a "GET" call to "GetUploadedDocuments" to service "PlayerService"
#    Then the API call is successful with status code 200
#    And I verify Uploaded Documents with "<types>" "<fileName>" "<fileType>"
#
#    Examples:
#      | types     | fileName   | fileType   |
#      | CARD_BACK | IDback.JPG | image/jpeg |
#
#
##  @nightlySuite @Preprod
#  Scenario Outline: Verify Card Documents - CARD BACK
#    When I create a VerifyDocuments payload with "<verificationType>" "<statusDescription>" and subcategory "<subType>"
#    And I change url resource of method "VerifyDocuments" of service "PlayerService" with new playerId
#    When I make a "POST" call to "VerifyDocuments" to service "PlayerService"
#    Then the API call is successful with status code 200
#    And the "verificationType" in response body is "<verificationType>"
#    And the "documentType" in response body is "<documentTypeResponse>"
#    And the "statusDescription" in response body is "<statusDescription>"
#    And the "status" in response body is "<statusValue>"
#
#
#    Examples:
#      | verificationType | statusDescription                  | subType | statusValue | documentTypeResponse |
#      | CARD             | Approve uploaded document for Card | BACK    | APPROVED    | CARD_BACK            |
#
#
##  @nightlySuite @Preprod
#  Scenario Outline: Confirm Verification of Player's Card - Verify Type/Status and save cardNumber
#    When I create a VerificationConfirm payload with "<verificationType>"
#    And I change url resource of method "VerificationConfirm" of service "PlayerService" with new playerId
#    When I make a "POST" call to "VerificationConfirm" to service "PlayerService"
#    Then the API call is successful with status code 200
#    And the "verificationType" in response body is "<verificationType>"
#    And the "status" in response body is "<statusValue>"
#    And I copy the value of the fingerprint from the response
#    And I copy the value of the cardNumber from the response
#
#    Examples:
#      | verificationType | statusValue |
#      | CARD             | VERIFIED    |

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |


  @skipIfAzure
  Scenario Outline: Set Master Card Details
    Given I login as an Api user
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId

    @skipIfPreprod
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |


    @skipIfNotPreprod
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5199992312641465 | TEST PROD  | 010 | 06        | 2030     | EUR      | pk_U0jMXzvD8cOv0kx0qDHghRVZ56TCELA7 |


  @skipIfAzure
  Scenario: Commit Card Deposit To Tora
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  @skipIfNotAzure
  Scenario: Commit Card Deposit To Tora
    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card



