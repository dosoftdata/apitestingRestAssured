@AccessService @NoRetry
Feature: Assertions

  @NoRetry
  Scenario: Get Assertion - Assertion not found
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "test"
    Then I make a "GET" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ASSERTION_NOT_FOUND"
    And the "description" in response body is "The assertion was not found ([Error Id: ASSERTION_NOT_FOUND])"

  @skipIfNotAzure @NoRetry
  Scenario: Create an Assertion - Missing body
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "test"
    Then I make a "PUT" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

  @skipIfNotAzure @NoRetry
  Scenario: Create an Assertion - Missing type
    And I create an empty payload with header "api_mainSpec_mainHost"
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "test"
    Then I make a "PUT" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "MISSING_TYPE"
    And the "description" in response body is "Assertion type missing ([Error Id: MISSING_TYPE])"

  @skipIfNotAzure @NoRetry
  Scenario Outline: Create an Assertion - Missing assertionId
    And I create a PUT CreateAssertion payload with "<type>" "<ssoSessionId>" "<userId>" "<securityDomainName>" "<issued>" "<expires>"
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "testAssertion"
    Then I make a "PUT" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | type     | ssoSessionId | issued | expires | userId | securityDomainName |
      | testType |              |        |         |        |                    |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Create an Assertion - Database error
    Given I create a PUT CreateAssertion payload with "<type>" "<ssoSessionId>" "<userId>" "<securityDomainName>" "<issued>" "<expires>"
    Then I make a "PUT" call to "ApiTestAssertion" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | type     | ssoSessionId | issued | expires | userId | securityDomainName |
      | testType |              |        |         |        |                    |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Create an Assertion - SessionId is null
    Given I create a PUT CreateAssertion payload with "<type>" "<ssoSessionId>" "<userId>" "<securityDomainName>" "<issued>" "<expires>"
    Then I make a "PUT" call to "ApiTestAssertion" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | type     | ssoSessionId | issued | expires | userId | securityDomainName |
      | testType |              |        |         |        |                    |

#  @skipIfNotAzure
#  Scenario Outline: Create an Assertion
#    Given I create a PUT CreateAssertion payload with "<type>" "<ssoSessionId>" "<userId>" "<securityDomainName>" "<issued>" "<expires>"
#    Then I make a "GET" call to "ApiSessionId" to service "AccessService"
#    Then the API call is successful with status code 204
#
#    Examples:
#      | type     | ssoSessionId  | userId       | issued  | expires | securityDomainName |
#      | testType | testSessionId | newPlayerWeb | datenow | datenow | testSecDomain      |

  @skipIfNotAzure
  Scenario Outline: Create an Assertion - Duplicate assertion
    Given I create a PUT CreateAssertion payload with "<type>" "<ssoSessionId>" "<userId>" "<securityDomainName>" "<issued>" "<expires>"
    Then I make a "PUT" call to "ApiSessionId" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | type     | ssoSessionId  | userId       | issued  | expires | securityDomainName |
      | testType | testSessionId | newPlayerWeb | datenow | datenow | testSecDomain      |

  @skipIfNotAzure
  Scenario Outline: Create an Assertion - Existing assertion with differences
    Given I create a PUT CreateAssertion payload with "<type>" "<ssoSessionId>" "<userId>" "<securityDomainName>" "<issued>" "<expires>"
    Then I make a "PUT" call to "ApiSessionId" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "ASSERTION_EXISTS_BUT_DIFFERS"
    And the "description" in response body is "Assertion exists, but differs from the one being added! ([Error Id: ASSERTION_EXISTS_BUT_DIFFERS])"

    Examples:
      | type      | ssoSessionId  | userId       | issued  | expires | securityDomainName |
      | testType2 | testSessionId | newPlayerWeb | datenow | datenow | testSecDomain      |

@skipIfNotAzure
  Scenario: Get Assertion
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "testAssertion"
    Then I make a "GET" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code 200
    And the "securityDomainName" in response body is "testSecDomain"
    And the "type" in response body is "testType"
    And the "ssoSessionId" in response body is "testSessionId"

  @skipIfAzure
  Scenario: Get Assertion
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "testAssertion"
    Then I make a "GET" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code 200



  @skipIfNotAzure @NoRetry
  Scenario: Delete Assertion - Assertion not found
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "randomAssertion"
    Then I make a "DEL" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ASSERTION_NOT_FOUND"
    And the "description" in response body is "The assertion was not found ([Error Id: ASSERTION_NOT_FOUND])"

  @skipIfNotAzure @NoRetry
  Scenario: Delete Assertion
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "testAssertion"
    Then I make a "DEL" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code 200
    And the "securityDomainName" in response body is "testSecDomain"
    And the "type" in response body is "testType"
    And the "ssoSessionId" in response body is "testSessionId"

  @skipIfNotAzure @NoRetry
  Scenario: Get Assertion - Assertion not found
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "ApiAssertions" of service "AccessService" with configured parameter "assertionId" "testAssertion"
    Then I make a "GET" call to "ApiAssertions" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ASSERTION_NOT_FOUND"
    And the "description" in response body is "The assertion was not found ([Error Id: ASSERTION_NOT_FOUND])"





