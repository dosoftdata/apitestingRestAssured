@AccessService
Feature: Access Api Endpoints

  @NoRetry
  Scenario Outline: Get AccessAttributes - Negative 400 Scenarios
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | keys                   | values                                        | statusCode | errorId                    | description                                                                      |
      |                        |                                               | 400        | MALFORMED_USERID           | User ID is missing or in the wrong format ([Error Id: MALFORMED_USERID])         |
      | userId                 | changeit                                      | 400        | MISSING_OPERATIONAL_UNIT   | Operational unit is missing ([Error Id: MISSING_OPERATIONAL_UNIT])               |
      | userId,operationalUnit | changeit,null                                 | 400        | MALFORMED_OPERATIONAL_UNIT | Operational unit is in the wrong format ([Error Id: MALFORMED_OPERATIONAL_UNIT]) |
      | userId,operationalUnit | changeit,admin.players\|\manage-access\|\view | 400        | MALFORMED_OPERATIONAL_UNIT | Operational unit is in the wrong format ([Error Id: MALFORMED_OPERATIONAL_UNIT]) |

  @NoRetry
  Scenario Outline: Get AccessAttributes - Negative 404 Scenarios
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code 404


    Examples:
      | keys   | values | GherkinDescription |
      | userId | test   | Unknown PlayerId   |
      | userId | 1-test | Invalid PlayerId   |

  Scenario Outline: Get AccessAttributes - Success 0 Length
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code <statusCode>
    And the number of results in a nameless array of objects is 0


    Examples:
      | keys                                 | values                                      | statusCode |
      | userId,operationalUnit               | changeit,api.access-attributes/list/get/WEB | 200        |
      | userId,operationalUnit,includeGroups | 1-3,api.any/any/any,true                    | 200        |

### Add AccessAtributes Azure only
  #20 negative. 2 positive
  #maybe remove some.

  @NoRetry @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Negative empty non array payload
    Given I create an empty payload with header "api_mainSpec_mainHost"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | errorId      | description        |
      | INVALID_JSON | Invalid JSON input |

  @NoRetry @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Negative 400/500 Scenarios
    Given I login as an Api user
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | errorId                  | description                                                      | statusCode | accessType | operationalUnit    | userId       | created | updated | updatedByUserId | operatorId | reason | valid | notifyStatus |
      | INVALID_JSON             | Invalid JSON input                                               | 400        |            | api/test/test/test | 9879877899   |         |         |                 |            |        |       |              |
      | INVALID_ACCESSTYPE       | Unsupported access type: 'test' ([Error Id: INVALID_ACCESSTYPE]) | 400        | test       |                    |              |         |         |                 |            |        |       |              |
      | MISSING_OPERATIONAL_UNIT | Operational Unit missing ([Error Id: MISSING_OPERATIONAL_UNIT])  | 400        | ALLOW      |                    |              |         |         |                 |            |        |       |              |
      | MISSING_USER_ID          | User ID missing ([Error Id: MISSING_USER_ID])                    | 400        | ALLOW      | api/test/test/test |              |         |         |                 |            |        |       |              |
      | INVALID_JSON             | Invalid JSON input                                               | 400        | ALLOW      | api/test/test/test | 9879877899   |         |         |                 |            |        |       |              |
      | INVALID_JSON             | Invalid JSON input                                               | 400        | ALLOW      | a                  | newPlayerWeb |         |         |                 |            |        |       |              |
      | INTERNAL_SERVER_ERROR    | Internal Server Error                                            | 500        | ALLOW      | api/ANY/ANY/ANY    | newPlayerWeb |         |         |                 |            |        |       |              |
      | INTERNAL_SERVER_ERROR    | Internal Server Error                                            | 500        | ALLOW      | api/test/ANY/ANY   | newPlayerWeb |         |         |                 |            |        |       |              |
      | INTERNAL_SERVER_ERROR    | Internal Server Error                                            | 500        | ALLOW      | api/test/test/ANY  | newPlayerWeb |         |         |                 |            |        |       |              |
      | INVALID_JSON             | Invalid JSON input                                               | 400        | ALLOW      | api/test/test/test | 0-92929292   |         |         |                 |            |        |       |              |


  @NoRetry @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Success
    Given I login as an Api user
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserIdResponse>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"


    Examples:
      | accessType | operationalUnit       | userId       | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus | updatedByUserIdResponse |
      | ALLOW      | api/test/test/test    | newPlayerWeb |         |         |                 |            |        |       | [0]   |              | 0-                      |
      | DENY       | api/test2/test2/test2 | 1-3          |         |         |                 |            |        |       | [0]   |              | 0-                      |
      | ALLOW      | api/test3/test3/test3 | 101-101      |         |         | 1006-1006       | 0          | Test   |       | [0]   |              | 1006-1006               |
      | ALLOW      | api/test4/test4/test4 | 1006-1006    |         |         | 1006-1006       | 0          | Test   |       | [0]   |              | 1006-1006               |
      | ALLOW      | api/test5/test5/test5 | 1006-1006    |         |         | 1006-1006       | 0          | Test   |       | [0]   |              | 1006-1006               |


  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Success Not found
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0


    Examples:
      | keys                                 | values                                 |
      | userId,operationalUnit,includeGroups | changeit,api/random/random/random,true |


  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Success 3
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "operationalUnit" in response body array with index "<index>" has value "api/test/test/test"
    And the property "accessType" in response body array with index "<index>" has value "ALLOW"
    And the property "reason" in response body array with index "<index>" has value ""
    #custom manipulation of playerId inside.
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | keys                                 | values                           | index | userId       | updatedByUserId |
      | userId,operationalUnit,includeGroups | changeit,api/test/test/test,true | [0]   | newPlayerWeb | 0-              |


  @skipIfNotAzure @NoRetry
  Scenario Outline: Get Current Access - Negative without query params
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    Then I make a "GET" call to "GetCurrentAccess" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"


    Examples:
      | errorId          | description                                                              |
      | MALFORMED_USERID | User ID is missing or in the wrong format ([Error Id: MALFORMED_USERID]) |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Get Current Access - Negative with query params
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccess" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"


    Examples:
      | keys                   | values        | statusCode | errorId                    | description                                                                      |
      | userId                 | changeit      | 400        | MISSING_OPERATIONAL_UNIT   | Operational unit is missing ([Error Id: MISSING_OPERATIONAL_UNIT])               |
      | userId,operationalUnit | changeit,test | 400        | MALFORMED_OPERATIONAL_UNIT | Operational unit is in the wrong format ([Error Id: MALFORMED_OPERATIONAL_UNIT]) |


  @skipIfNotAzure @NoRetry
  Scenario Outline: Get Current Access - Negative with query params 2
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccess" to service "AccessService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | keys                   | values                   | statusCode |
      | userId,operationalUnit | changeit,api/fesd/gsdgsd | 404        |

  @skipIfNotAzure
  Scenario Outline: Get Current Access - Success not full data
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccess" to service "AccessService"
    Then the API call is successful with status code 200
    And the "accessType" in response body is "ALLOW"
    And the "reason" in response body is ""


    Examples:
      | keys                   | values                      |
      | userId,operationalUnit | changeit,api/test/test/test |


  @skipIfNotAzure
  Scenario Outline: Get Current Access - Success fullData
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccess" to service "AccessService"
    Then the API call is successful with status code 200
    And the "accessType" in response body is "ALLOW"
    And the "reason" in response body is ""
    And the "operatorId" in response body is "0"
    And the "operationalUnit" in response body is "api/test/test/test"
    And the "updatedByUserId" in response body is "<updatedByUserId>"
    And the "created" to include today's date
    And the "updated" to include today's date


    Examples:
      | keys                                           | values                                | index | userId       | updatedByUserId |
      | userId,operationalUnit,requireAllowed,fullData | changeit,api/test/test/test,true,true | [0]   | newPlayerWeb | 0-              |


  @skipIfNotAzure @NoRetry
  Scenario Outline: Delete AccessAttributes - Negative 1 ( no params)
    Given I create a Get "api_mainSpec_mainHost" header
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | errorId          | description                                                              |
      | MALFORMED_USERID | User ID is missing or in the wrong format ([Error Id: MALFORMED_USERID]) |


  @skipIfNotAzure @NoRetry
  Scenario Outline: Delete AccessAttributes - Negative 2
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | keys                   | values        | errorId                    | description                                                                      |
      | userId                 | changeit      | MISSING_OPERATIONAL_UNIT   | Operational unit is missing ([Error Id: MISSING_OPERATIONAL_UNIT])               |
      | userId,operationalUnit | changeit,test | MALFORMED_OPERATIONAL_UNIT | Operational unit is in the wrong format ([Error Id: MALFORMED_OPERATIONAL_UNIT]) |



  #204? giati?
  @skipIfNotAzure
  Scenario Outline: Delete AccessAttributes - Success??
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | keys                   | values                   |
      | userId,operationalUnit | changeit,api/fesd/gsdgsd |


  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Check Attribute to be deleted
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "operationalUnit" in response body array with index "<index>" has value "api/test/test/test"
    And the property "accessType" in response body array with index "<index>" has value "ALLOW"
    And the property "reason" in response body array with index "<index>" has value ""
    #custom manipulation of playerId inside.
    And the property "userId" in response body array with index "<index>" has value "newPlayerWeb"
    And the property "updatedByUserId" in response body array with index "<index>" has value "0-"


    Examples:
      | keys                                 | values                           | index |
      | userId,operationalUnit,includeGroups | changeit,api/test/test/test,true | [0]   |


  @skipIfNotAzure
  Scenario Outline: Delete AccessAttributes - Success  0
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204


    Examples:
      | keys                   | values                      |
      | userId,operationalUnit | changeit,api/test/test/test |

  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Check Attribute that has been deleted
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0


    Examples:
      | keys                                 | values                           |
      | userId,operationalUnit,includeGroups | changeit,api/test/test/test,true |


  @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Success 2
    Given I login as an Api user
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "0-"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"


    Examples:
      | accessType | operationalUnit       | userId | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | DENY       | api/test2/test2/test2 | 1-3    |         |         |                 |            |        |       | [0]   |              |

  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Check Attribute to be deleted 2
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value ""
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "0-"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"

    #TODO: check 1st example no response?
    Examples:
      | keys                                 | values                                    | operationalUnit       | accessType | userId       | index |
      | userId,operationalUnit,includeGroups | changeit,api.test2/test2/test2/test2,true | api/test2/test2/test2 | DENY       | newPlayerWeb | [0]   |
      | userId,operationalUnit,includeGroups | 1-3,api.test2/test2/test2/test2,true      | api/test2/test2/test2 | DENY       | 1-3          | [0]   |

  @skipIfNotAzure
  Scenario Outline: Delete AccessAttributes - Success 2nd Attribute
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204


    Examples:
      | keys                   | values                         |
      | userId,operationalUnit | changeit,api/test2/test2/test2 |


  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Check Attribute that has been deleted 2
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0


    Examples:
      | keys                                 | values                              |
      | userId,operationalUnit,includeGroups | changeit,api/test2/test2/test2,true |

  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Check Attribute to be deleted 2 (by admin)
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value ""
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "0-"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"


    Examples:
      | keys                                 | values                               | operationalUnit       | accessType | userId | index |
      | userId,operationalUnit,includeGroups | 1-3,api.test2/test2/test2/test2,true | api/test2/test2/test2 | DENY       | 1-3    | [0]   |


  @skipIfNotAzure
  Scenario Outline: Delete AccessAttributes - Success  2nd Attribute (by admin)
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | keys                   | values                    |
      | userId,operationalUnit | 1-3,api/test2/test2/test2 |

  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Check Attribute that has been deleted (by admin)
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0


    Examples:
      | keys                                 | values                              |
      | userId,operationalUnit,includeGroups | 1-3,api/test2/test2/test2,true      |
      | userId,operationalUnit,includeGroups | changeit,api/test2/test2/test2,true |


    #Removed 3-6 access attributes scenarios . Not needed.

  @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Success Allow this/is/a/test
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"


    Examples:
      | accessType | operationalUnit | userId       | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | ALLOW      | this/is/a/test  | newPlayerWeb |         |         | newPlayerWeb    | 0          | test   |       | [0]   |              |


  @skipIfNotAzure
  Scenario Outline: Get Current Access - Negative Scenarios 400
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccess" to service "AccessService"
    And the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | keys                    | values              | statusCode | errorId                    | description                                                                      |
      |                         |                     | 400        | MALFORMED_USERID           | User ID is missing or in the wrong format ([Error Id: MALFORMED_USERID])         |
      | userId                  | changeit            | 400        | MISSING_OPERATIONAL_UNIT   | Operational unit is missing ([Error Id: MISSING_OPERATIONAL_UNIT])               |
      | userId,operationalUnits | changeit,test       | 400        | MALFORMED_OPERATIONAL_UNIT | Operational unit is in the wrong format ([Error Id: MALFORMED_OPERATIONAL_UNIT]) |
      | userId,operationalUnits | changeit,test,test2 | 400        | MALFORMED_OPERATIONAL_UNIT | Operational unit is in the wrong format ([Error Id: MALFORMED_OPERATIONAL_UNIT]) |
      | userId,operationalUnit  | changeit,test       | 400        | MALFORMED_OPERATIONAL_UNIT | Operational unit is in the wrong format ([Error Id: MALFORMED_OPERATIONAL_UNIT]) |


  @skipIfNotAzure
  Scenario Outline: Get Current Access - Negative Scenarios 404
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccess" to service "AccessService"
    And the API call is successful with status code <statusCode>

    Examples:
      | keys                    | values                               | statusCode |
      | userId,operationalUnits | changeit,this/is/test/number2        | 404        |
      | userId,operationalUnit  | changeit,random.random/random/random | 404        |


  @skipIfNotAzure
  Scenario Outline: Get Current Access - Success 2
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccess" to service "AccessService"
    Then the API call is successful with status code 200
    And the "accessType" in response body is "ALLOW"
    And the "reason" in response body is "test"


    Examples:
      | keys                    | values                  |
      | userId,operationalUnits | changeit,this/is/a/test |
      | userId,operationalUnit  | changeit,this/is/a/test |


  @skipIfNotAzure
  Scenario Outline: Get Current Access - Negative Scenarios 400
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccess" to service "AccessService"
    And the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | keys                   | values        | statusCode | errorId                    | description                                                                      |
      | userId,operationalUnit | changeit,test | 400        | MALFORMED_OPERATIONAL_UNIT | Operational unit is in the wrong format ([Error Id: MALFORMED_OPERATIONAL_UNIT]) |


  @skipIfNotAzure
  Scenario Outline: Get Current Access V2 - Negative Scenarios 400
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccessV2" to service "AccessService"
    And the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | keys                    | values              | statusCode | errorId                    | description                                                                      |
      |                         |                     | 400        | MALFORMED_USERID           | User ID is missing or in the wrong format ([Error Id: MALFORMED_USERID])         |
      | userId                  | changeit            | 400        | MISSING_OPERATIONAL_UNIT   | Operational unit is missing ([Error Id: MISSING_OPERATIONAL_UNIT])               |
      | userId,operationalUnit  | changeit,test       | 400        | MALFORMED_OPERATIONAL_UNIT | Operational unit is in the wrong format ([Error Id: MALFORMED_OPERATIONAL_UNIT]) |
      | userId,operationalUnits | changeit,test       | 400        | MALFORMED_OPERATIONAL_UNIT | Operational unit is in the wrong format ([Error Id: MALFORMED_OPERATIONAL_UNIT]) |
      | userId,operationalUnits | changeit,test-test2 | 400        | MALFORMED_OPERATIONAL_UNIT | Operational unit is in the wrong format ([Error Id: MALFORMED_OPERATIONAL_UNIT]) |

 ###?? success? #TODO: note to check logic . I use postman logic in next test below with 200
 #@skipIfNotAzure
 #Scenario Outline: Get Current Access V2 - Negative Scenarios 404
 #  Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
 #  Then I make a "GET" call to "GetCurrentAccessV2" to service "AccessService"
 #  And the API call is successful with status code <statusCode>

 #  Examples:
  #    | keys                    | values                        | statusCode |
   #   | userId,operationalUnits | changeit,this/is/test/number2 | 404        |


  @skipIfNotAzure
  Scenario Outline: Get Current Access V2 - Success
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccessV2" to service "AccessService"
    And the API call is successful with status code 200
    And the "accessType" in response body is "<accessType>"
    And the "reason" in response body is "<reason>"


    Examples:
      | keys                    | values                               | accessType | reason |
      | userId,operationalUnits | changeit,random.random/random/random | ALLOW      |        |
      | userId,operationalUnits | changeit,this/is/a/test              | ALLOW      | test   |
      | userId,operationalUnits | changeit,this/is/test/number2        | ALLOW      |        |


  @skipIfNotAzure
  Scenario Outline: Get Current Access V2 - Success Full Data - Many assertions
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccessV2" to service "AccessService"
    And the API call is successful with status code 200
    And the "accessType" in response body is "<accessType>"
    And the "reason" in response body is "<reason>"
    And the "updatedByUserId" in response body is "<updatedByUserId>"
    And the "operatorId" in response body is "<operatorId>"
    And the "requestedOperationalUnit" in response body is "<requestedOperationalUnit>"
    And the "operationalUnit" in response body is "<operationalUnit>"

    Examples:
      | keys                                           | values                                          | accessType | reason | updatedByUserId | operatorId | requestedOperationalUnit    | operationalUnit             |
      | userId,operationalUnit,requireAllowed,fullData | changeit,random.random/random/random,false,true | ALLOW      |        | 0-              | 0          | random.random/random/random | random.random/random/random |
      | userId,operationalUnit,requireAllowed,fullData | changeit,random.random/random/random,true,true  | DENY       |        | 0-              | 0          | random.random/random/random | random.random/random/random |


  @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Success
    Given I login as an Api user
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"


    Examples:
      | accessType | operationalUnit | userId       | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | DENY       | this/is/a/test  | newPlayerWeb |         |         | newPlayerWeb    | 0          | Test   |       | [0]   |              |


  @skipIfNotAzure
  Scenario Outline: Get Current Access - Success this/is/a/test
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccess" to service "AccessService"
    And the API call is successful with status code 200
    And the "<responseField1>" in response body is "DENY"
    And the "<responseField2>" in response body is "Test"

    Examples:
      | keys                             | values                       | responseField1 | responseField2 |
      | userId,operationalUnits          | changeit,this/is/a/test      | accessType     | reason         |
      | userId,operationalUnits,fullData | changeit,this/is/a/test,true | [0].accessType | [0].reason     |

  @skipIfNotAzure
  Scenario Outline: Get Current Access V2 - Success this/is/a/test
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetCurrentAccessV2" to service "AccessService"
    And the API call is successful with status code 200
    And the "<responseField1>" in response body is "DENY"
    And the "<responseField2>" in response body is "Test"


    Examples:
      | keys                             | values                       | responseField1 | responseField2 |
      | userId,operationalUnits          | changeit,this/is/a/test      | accessType     | reason         |
      | userId,operationalUnits,fullData | changeit,this/is/a/test,true | [0].accessType | [0].reason     |

  @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Invalid access Type
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ACCESSTYPE"
    And the "description" in response body is "Unsupported access type: 'TEST' ([Error Id: INVALID_ACCESSTYPE])"



    Examples:
      | accessType | operationalUnit | userId       | created | updated | updatedByUserId | operatorId | reason | valid | notifyStatus |
      | TEST       | this/is/a/test  | newPlayerWeb |         |         | newPlayerWeb    | 0          | Test   |       |              |

  @skipIfNotAzure
  Scenario Outline: Post AccessCheckV2 - No body
    Given I create a Get "api_mainSpec_mainHost" header
    When I make a "POST" call to "AccessCheckV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | statusCode | errorId          | description     |
      | 400        | INVALID_ARGUMENT | may not be null |

  @skipIfNotAzure
  Scenario Outline: Post AccessCheckV2 - Empty Body
    Given I create an empty payload with header "api_mainSpec_mainHost"
    When I make a "POST" call to "AccessCheckV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And  the property "description" includes value "<description1>"
    And  the property "description" includes value "<description2>"

    Examples:
      | statusCode | errorId          | description1                | description2                    |
      | 400        | INVALID_ARGUMENT | userRequest may not be null | operationalUnit may not be null |

    #maybe more tests here
  #random description order..
  #fix description
  @skipIfNotAzure @NoRetry
  Scenario Outline: Post AccessCheckV2 - Negative Scenarios
    Given I login as an Api user
    Given I create a POST AccessCheckV2 payload with "<userRequest>" "<callerRequest>" "<operationalUnit>"
    When I make a "POST" call to "AccessCheckV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the response includes value "<description>"

    Examples:
      | statusCode | userRequest  | callerRequest | operationalUnit       | errorId                        | description                                          |
      | 400        |              |               |                       | INVALID_ARGUMENT               | operationalUnit may not be null                      |
      | 400        |              |               | api/test2/test2/test2 | INVALID_ARGUMENT               | userRequest may not be null                          |
      | 403        | newPlayerWeb | newPlayerWeb  | api/test7/test7/test7 | CALLER_AUTHENTICATION_REQUIRED | The calling system is not authenticated as required. |


  @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Various Statuses
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"



    Examples:
      | accessType | operationalUnit             | userId       | created | updated | updatedByUserId | operatorId | reason | valid | notifyStatus | index |
      | ALLOW      | api/test/status/test        | newPlayerWeb |         |         | newPlayerWeb    | 0          | Test   |       | TEST         | [0]   |
      | ALLOW      | api/test/status/failed      | newPlayerWeb |         |         | newPlayerWeb    | 0          | Test   |       | FAILED       | [0]   |
      | ALLOW      | api/test/status/published   | newPlayerWeb |         |         | newPlayerWeb    | 0          | Test   |       | PUBLISHED    | [0]   |
      | ALLOW      | api/test/status/unpublished | newPlayerWeb |         |         | newPlayerWeb    | 0          | Test   |       | UNPUBLISHED  | [0]   |

  @Concat
  Scenario Outline: Get CustomerAccessRights  - Operational unit definition is not of the correct form
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetCustomerAccessRightsApi" of service "AccessService" with new playerId
    And I concat the url "<urlToConcat>" to the end of url of method "GetCustomerAccessRightsApi" of service "AccessService"
    When I make a "GET" call to "GetCustomerAccessRightsApi" to service "AccessService"
    #And I return the url of method "GetCustomerAccessRightsApi" of service "AccessService" to its previous state
    Then the API call is successful with status code 400
    And the "errorId" in response body is "BAD_REQUEST"
    And the "description" in response body is "Bad Request"


    Examples:
      | urlToConcat |
      | /test       |

  @Concat
  Scenario: Get CustomerAccessRights  - Access attribute not found
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetCustomerAccessRightsApi" of service "AccessService" with new playerId
    And I concat the url "/test1|test2|test3|test4" to the end of url of method "GetCustomerAccessRightsApi" of service "AccessService"
    When I make a "GET" call to "GetCustomerAccessRightsApi" to service "AccessService"
    #And I return the url of method "GetCustomerAccessRightsApi" of service "AccessService" to its previous state
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ACCESS_ATTRIBUTE_NOT_FOUND"
    And the property "description" includes value "Unable to get access attributes for customer with id: {0} ([Error Id: ACCESS_ATTRIBUTE_NOT_FOUND] Unable to get access attributes for customer with id"


    #NOTE: playerId replace in flow issue
    #it works by itself.
 # @Concat @Standalone
 # Scenario: Get CustomerAccessRights  - Invalid player format
 #   Given I create a Get "api_mainSpec_mainHost" header
 #   And I change url resource of method "GetCustomerAccessRightsApi" of service "AccessService" with configured playerId "1-101534629"
 #   And I concat the url "/test1|test2|test3|test4" to the end of url of method "GetCustomerAccessRightsApi" of service "AccessService"
 #   When I make a "GET" call to "GetCustomerAccessRightsApi" to service "AccessService"
 #   Then the API call is successful with status code 500
 #   And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
 #   And the "description" in response body is "Internal Server Error"

  @Concat
  Scenario: Get CustomerAccessRights  - Player Not Found
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetCustomerAccessRightsApi" of service "AccessService" with configured playerId "1234567890"
    And I concat the url "/test1|test2|test3|test4" to the end of url of method "GetCustomerAccessRightsApi" of service "AccessService"
    When I make a "GET" call to "GetCustomerAccessRightsApi" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ACCESS_ATTRIBUTE_NOT_FOUND"
    And the property "description" includes value "Unable to get access attributes for customer with id: {0} ([Error Id: ACCESS_ATTRIBUTE_NOT_FOUND] Unable to get access attributes for customer with id"


  @skipIfNotAzure @Concat
  Scenario: Get CustomerAccessRights  - Success
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetCustomerAccessRightsApi" of service "AccessService" with new playerId
    And I concat the url "/api|test|status|test" to the end of url of method "GetCustomerAccessRightsApi" of service "AccessService"
    When I make a "GET" call to "GetCustomerAccessRightsApi" to service "AccessService"
    Then the API call is successful with status code 200
    And the "accessType" in response body is "1"
    And the "userType" in response body is "1"
    And the "operationalUnit" in response body is "api/test/status/test"
    And the "reason" in response body is "Test"
    And the "blockHours" in response body is "-1"
    And the "userType" in response body is "1"


  @skipIfNotAzure
  Scenario: Delete Current Session - Logout CC
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "DEL" call to "DeleteCurrentSession" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Negative ValidFrom > ValidTo
    Given I create a POST ApiAccessAttributes validFrom validTo payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<validFrom>" "<validTo>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"



    Examples:
      | accessType | operationalUnit             | userId       | created | updated | updatedByUserId | operatorId | reason | validFrom  | validTo    | notifyStatus |
      | DENY       | limits/cooling-off/test/ALL | newPlayerWeb |         |         | newPlayerWeb    | 0          | Test   | 2025-03-12 | 2025-03-04 |              |


    #note for /test /test/ALL ask
  @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Success cooling off
    Given I create a POST ApiAccessAttributes validFrom validTo payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<validFrom>" "<validTo>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code 200
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnitResponse>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<userId>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the "<index>.valid.from" in response body has value not null
    And the "<index>.valid.to" in response body has value not null
    And the "<index>.created" to include today's date


    Examples:
      | accessType | operationalUnit             | userId       | created | updated | updatedByUserId | operatorId | reason | validFrom | validTo                   | notifyStatus | index | operationalUnitResponse |
      | DENY       | limits/cooling-off/test/ALL | newPlayerWeb |         |         | newPlayerWeb    | 0          | Test   | datenow   | 2030-12-28T21:59:59+03:00 |              | [0]   | limits/cooling-off/test |