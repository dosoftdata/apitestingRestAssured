@skipIfNotAzure @AccessService
Feature: Password max limited

#  Scenario: Get Player
#    Given I login as a "newPlayerWeb" user
#    And I create a Get "mainspec" header
#    And I change url resource of method "GetPlayer" of service "PlayerService" with new playerId
#    When I make a "GET" call to "GetPlayer" to service "PlayerService"
#    Then the API call is successful with status code 200

    @NoRetry
  Scenario: Update user's password via access service point - Missing body
    Given I create a Get "mainSpec" header
    And I change url resource of method "UpdatePendingPasswordWeb" of service "AccessService" with new playerId
    When I make a "PUT" call to "UpdatePendingPasswordWeb" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

  @NoRetry
  Scenario: Update user's password via access service point - No pending password change
    Given I create an empty payload with header "mainSpec"
    And I change url resource of method "UpdatePendingPasswordWeb" of service "AccessService" with new playerId
    When I make a "PUT" call to "UpdatePendingPasswordWeb" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "NO_PENDING_PASSWORD_CHANGE"
    And the "description" in response body is "No pending password change found in session ([Error Id: NO_PENDING_PASSWORD_CHANGE])"

  Scenario: Update user's password via access service point
    Given I create a Get "mainSpec" header
    And I create Update Password payload for Web
    And I change url resource of method "UpdatePasswordWeb" of service "PlayerService" with new playerId
    When I make a "PUT" call to "UpdatePasswordWeb" to service "PlayerService"
    Then the API call is successful with status code 204


  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario Outline: Get all payments
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerPaymentsAsAdmin" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 0

    Examples:
      | keys                           | values          |
      | customerId,pageNumber,pageSize | changeit,1,1000 |

  Scenario Outline: Get and Verify - Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 684.0    | 684.0        | 184.0                   | 0.0              | 500.0                | 300672.0 | 300672.0     | 172.0                   | 0.0              | 300500.0             |

  Scenario Outline: Manual adjustment for Deposit in Legacy wallet via BO - Negative scenario
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Legacy wallet"
    When I change url resource of method "ManuallyAdjustLegacyWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManuallyAdjustLegacyWallet" to service "WalletService"
    Then the API call is successful with status code 400
    And the "description" in response body is "The specified productId is not supported for this accountId ([Error Id: INVALID_PRODUCT])"
    And the "errorId" in response body is "INVALID_PRODUCT"

    Examples:
      | transactionType  | transactionSubType | productId  | operation  | amount |
      | TT_MANUAL_ADJUST | MDRC               | Sportsbook | WITHDRAWAL | 1      |

  Scenario Outline: Get and Verify - Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 684.0    | 684.0        | 184.0                   | 0.0              | 500.0                | 300672.0 | 300672.0     | 172.0                    | 0.0              | 300500.0             |

  Scenario Outline: Manual adjustment for Deposit in Lottery wallet via BO - Erase withdrawable balance of Lottery wallet
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Lottery wallet"
    When I change url resource of method "ManualAdjustLotteryWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustLotteryWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "operation" in response body is "<operation>"
    And the "amount" in response body is "<amount>"

    Examples:
      | transactionType  | transactionSubType | productId | operation  | amount |
      | TT_MANUAL_ADJUST | MDRC               | JOKER     | WITHDRAWAL | 100.0  |

  Scenario Outline: Manual adjustment for Deposit in Lottery wallet via BO - Erase non-withdrawable balance of Lottery wallet
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Lottery wallet"
    When I change url resource of method "ManualAdjustLotteryWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustLotteryWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "operation" in response body is "<operation>"
    And the "amount" in response body is "<amount>"

    Examples:
      | transactionType  | transactionSubType | productId | operation  | amount |
      | TT_MANUAL_ADJUST | MDRC               | JOKER     | WITHDRAWAL | 34.0    |

  Scenario Outline: Get and Verify - Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 550.0    | 550.0        | 184.0                   | 0.0              | 366.0                | 300672.0 | 300672.0     | 172.0                    | 0.0              | 300500.0             |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"
    And the "amount" in response body is "2000.0"

    Examples:
      | transactionType  | transactionSubType | productId  | operation  | amount |
      | TT_MANUAL_ADJUST | MDRC               | SPORTSBOOK | WITHDRAWAL | 2000.0 |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"
    And the "amount" in response body is "52.0"

    Examples:
      | transactionType  | transactionSubType | productId  | operation  | amount |
      | TT_MANUAL_ADJUST | MDRC               | SPORTSBOOK | WITHDRAWAL | 52.0    |

  Scenario Outline: Get and Verify - Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 550.0    | 550.0        | 184.0                   | 0.0              | 366.0                | 298620.0 | 298620.0     | 172.0                    | 0.0              | 298448.0             |

  Scenario Outline: Add closing-state access attribute for player
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload for friendsAndFamilyGroupId with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<validFrom>" "<validTo>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"

    Examples:
      | accessType | operationalUnit                        | userId   | created | updated | updatedByUserId | operatorId | reason | validFrom | validTo | index |
      | DENY       | player/account-status/in-closing-state | playerId |         |         | playerId        |            | Test   |           |         | [0]   |

  Scenario: Get Player v2
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerV2" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerV2" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify the player id "id" in the response body
    And I verify the username "username" in the response body

  Scenario Outline: Get all payments
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerPaymentsAsAdmin" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 0

    Examples:
      | keys       | values   |
      | customerId | changeit |

  Scenario: Close account via BO call
    Given I create a Get "cc_csrftokenSpec" header
    And I create Close Account payload with "CLOSED" "test" "SELF_EXCLUSION"
    And I change url resource of method "OpenCloseAccountCC" of service "PlayerService" with new playerId
    When I make a "PUT" call to "OpenCloseAccountCC" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "status" in response body is "DISABLED"
    And the "statusReason" in response body is "SELF_EXCLUSION"

  Scenario: Get Player v2
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerV2" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerV2" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify the player id "id" in the response body
    And I verify the username "username" in the response body

  Scenario Outline: Deposit via Payment code - Lottery wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 403
    And the "errorId" in response body is "PAYMENT_ACCESS_REJECTED"
    And the "description" in response body is "User cannot deposit."

    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 20     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  Scenario Outline: Deposit via Payment code - Betting wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 403
    And the "errorId" in response body is "PAYMENT_ACCESS_REJECTED"
    And the "description" in response body is "User cannot deposit."

    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 20     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  Scenario: Get bearer token - Web - Casino
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "JOKER"
    Then the API call is successful with status code 403
    And the "errorId" in response body is "PAYMENT_ACCESS_REJECTED"
    And the "description" in response body is "User cannot deposit."

  Scenario: Open account via BO call
    Given I create a Get "cc_csrftokenSpec" header
    And I create Close Account payload with "ENABLED" "Account was opened by admin." "NONE"
    And I change url resource of method "OpenCloseAccountCC" of service "PlayerService" with new playerId
    When I make a "PUT" call to "OpenCloseAccountCC" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "status" in response body is "ENABLED"
    And the "statusReason" in response body is "NONE"

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

#    ---------------------------------------------------------------------------------------------------------

  Scenario Outline: DatabaseBridge - Update query in PLRContractAgreements
    Given I create a DataBridge Payload with "<query>"
    When I make a "POST" call to "DatabaseExecute" to service "DatabaseBridgeService"
    Then the API call is successful with status code 200

    Examples:
      | query                                                                                             |
      | UPDATE PLRCONTRACTAGREEMENTS SET STATUS='VALID' WHERE STATUS='REVOKED' AND PLAYERID='newPlayerId' |

  Scenario: Get bearer token - Web - Attempts 3
    Given I login as a "testPlayerWeb" user
    And I login as a "testPlayerWeb" user
    And I login as a "testPlayerWeb" user
    And I setup gameId header to "JOKER"
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username\/password."

  Scenario: Get bearer token - Web - Attempt 2
    Given I login as a "testPlayerWeb" user
    And I setup gameId header to "JOKER"
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username\/password."

  Scenario: Get bearer token - Web - Attempt 3
    Given I login as a "testPlayerWeb" user
    And I setup gameId header to "JOKER"
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username\/password."

  Scenario: Get bearer token - Web - Attempt 4
    Given I login as a "testPlayerWeb" user
    And I setup gameId header to "JOKER"
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username\/password."

  Scenario: Get bearer token - Web - Session blocked
    Given I login as a "testPlayerWeb" user
    And I setup gameId header to "JOKER"
#    Then the API call is successful with status code 409
#    And the "errorId" in response body is "SESSION_BLOCKED"
#    And the "description" in response body is "User is blocked and cannot login"

  Scenario: Get bearer token - Web - Max login attempts
    Given I login as a "testPlayerWeb" user
    And I setup gameId header to "JOKER"
#    Then the API call is successful with status code 409
#    And the "errorId" in response body is "MAX_LOGIN_ATTEMPTS"
#    And the "description" in response body is "Player reached the maximum login attempt limit."

#    ------------------------------------------------------------------------------------------------------------------

  Scenario: Post - Login BO - Attempts 9
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])"

  Scenario: Post - Login BO - Attempts 9
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])"

  Scenario: Post - Login BO - Attempts 9
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])"

  Scenario: Post - Login BO - Attempts 9
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])"

  Scenario: Post - Login BO - Attempts 9
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])"

  Scenario: Post - Login BO - Attempts 9
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])"

  Scenario: Post - Login BO - Attempts 9
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])"

  Scenario: Post - Login BO - Attempts 9
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])"

  Scenario: Post - Login BO - Attempts 9
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])"

  Scenario: Post - Login BO - Attempts 9
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "INVALID_USER_PASSWORD"
#    And the "description" in response body is "Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])"

  Scenario: Post - Login BO - Session blocked
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "SESSION_BLOCKED"
#    And the "description" in response body is "User is blocked and cannot login ([Error Id: SESSION_BLOCKED])"

  Scenario: Post - Login BO - Max login attempts
    Given I create a Get "cc_csrftokenSpec" header
    And I login as a "testPlayerCc" user
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "MAX_LOGIN_ATTEMPTS"
#    And the "description" in response body is "Player reached the maximum login attempt limit. ([Error Id: MAX_LOGIN_ATTEMPTS])"


