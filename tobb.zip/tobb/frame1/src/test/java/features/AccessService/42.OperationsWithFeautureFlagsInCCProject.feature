@AccessService @skipIfNotAzure
Feature: Operations With Feature Flags In CC Project


  Scenario Outline: Add AccessAttributes - Get list feature
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | accessType | operationalUnit                                  | userId | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | ALLOW      | adminrest.access-attributes/list.feature/get/WEB | 3-1    |         |         | 3-1             | 0          | Test   | null  | [0]   |              |

  Scenario Outline: Get AccessAttributes - Get list feature
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | keys                                 | values                                                    | accessType | operationalUnit                                  | userId | updatedByUserId | operatorId | reason | index |
      | userId,operationalUnit,includeGroups | 3-1,adminrest.access-attributes/list.feature/get/WEB,true | ALLOW      | adminrest.access-attributes/list.feature/get/WEB | 3-1    | 3-1             | 0          | Test   | [0]   |

  Scenario Outline: Add AccessAttributes - Post list feature
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | accessType | operationalUnit                                   | userId | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | ALLOW      | adminrest.access-attributes/list.feature/post/WEB | 3-1    |         |         | 3-1             | 0          | Test   | null  | [0]   |              |

  Scenario Outline: Get AccessAttributes - Post list feature
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | keys                                 | values                                                     | accessType | operationalUnit                                   | userId | updatedByUserId | operatorId | reason | index |
      | userId,operationalUnit,includeGroups | 3-1,adminrest.access-attributes/list.feature/post/WEB,true | ALLOW      | adminrest.access-attributes/list.feature/post/WEB | 3-1    | 3-1             | 0          | Test   | [0]   |

  Scenario Outline: Add AccessAttributes - Delete list feature
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | accessType | operationalUnit                                     | userId | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | ALLOW      | adminrest.access-attributes/list.feature/delete/WEB | 3-1    |         |         | 3-1             | 0          | Test   | null  | [0]   |              |

  Scenario Outline: Get AccessAttributes - Delete list feature
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | keys                                 | values                                                       | accessType | operationalUnit                                     | userId | updatedByUserId | operatorId | reason | index |
      | userId,operationalUnit,includeGroups | 3-1,adminrest.access-attributes/list.feature/delete/WEB,true | ALLOW      | adminrest.access-attributes/list.feature/delete/WEB | 3-1    | 3-1             | 0          | Test   | [0]   |

  Scenario Outline: Add AccessAttributes - Enable feature service
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | accessType | operationalUnit                                     | userId | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | ALLOW      | adminrest.access-attributes/enable.feature/post/WEB | 3-1    |         |         | 3-1             | 0          | Test   | null  | [0]   |              |

  Scenario Outline: Get AccessAttributes - Enable feature service
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | keys                                 | values                                                       | accessType | operationalUnit                                     | userId | updatedByUserId | operatorId | reason | index |
      | userId,operationalUnit,includeGroups | 3-1,adminrest.access-attributes/enable.feature/post/WEB,true | ALLOW      | adminrest.access-attributes/enable.feature/post/WEB | 3-1    | 3-1             | 0          | Test   | [0]   |

  Scenario Outline: Add AccessAttributes - Disable feature service
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | accessType | operationalUnit                                       | userId | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | ALLOW      | adminrest.access-attributes/enable.feature/delete/WEB | 3-1    |         |         | 3-1             | 0          | Test   | null  | [0]   |              |

  Scenario Outline: Get AccessAttributes - Disable feature service
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | keys                                 | values                                                         | accessType | operationalUnit                                       | userId | updatedByUserId | operatorId | reason | index |
      | userId,operationalUnit,includeGroups | 3-1,adminrest.access-attributes/enable.feature/delete/WEB,true | ALLOW      | adminrest.access-attributes/enable.feature/delete/WEB | 3-1    | 3-1             | 0          | Test   | [0]   |

  @skipIfNotAzure
  Scenario Outline: Delete AccessAttributes - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | keys                                 | values                        |
      | userId,operationalUnit,includeGroups | 3-1,dummy.feature/check/,true |

  @skipIfNotAzure
  Scenario Outline: Delete AccessAttributes - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | keys                                 | values                          |
      | userId,operationalUnit,includeGroups | 102-1,dummy.feature/check/,true |

  @skipIfNotAzure
  Scenario Outline: Delete AccessAttributes - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | keys                                 | values                      |
      | userId,operationalUnit,includeGroups | 0-0,dummy.feature/check/,true |

#    ------------------------------------------------------------------------------------------------------------------

  Scenario: Get all enabled features flags of access
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 200
#    And I check that the size of data.length is above 4
    And the nameless array response should contain 5 elements with values "subscription" and "subscriptionTest"

  Scenario: Get and Verify Access Groups
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response and copy the access group Ids

  Scenario Outline: Get an AccessAttribute - dummy.feature does not exist
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                                 | values                                                   |
      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,dummy.feature/check/ALL/ALL,true |

  Scenario Outline: Add an AccessAttribute for dummy.feature
    Given I create a Get "api_mainSpec_mainHost" header
    And I create a POST ApiAccessAttributes payload for friendsAndFamilyGroupId with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<validFrom>" "<validTo>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"

    Examples:
      | accessType | operationalUnit      | userId                  | created | updated | updatedByUserId         | operatorId | reason | validFrom | validTo | index |
      | ALLOW      | dummy.feature/check/ | friendsAndFamilyGroupId |         |         | friendsAndFamilyGroupId | 0          | Test   |           |         | [0]   |

  Scenario Outline: Get an AccessAttribute - dummy.feature exists
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "operationalUnit" in response body array with index "<index>" has value "dummy.feature/check/"
    And the property "accessType" in response body array with index "<index>" has value "ALLOW"
    And the property "reason" in response body array with index "<index>" has value "Test"

    Examples:
      | keys                                 | values                                                   | index |
      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,dummy.feature/check/ALL/ALL,true | [0]   |

  @NoRetry
  Scenario Outline: Check if feature is ready to be delivered to players - Not found
    Given I login as a "newPlayerWeb" user
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "NOT_FOUND"
    And the "description" in response body is "Feature service not found ([Error Id: NOT_FOUND])"

    Examples:
      | key            | value                 |
      | userId,feature | changeit,dummyFeature |

#    -------------------------------------------------------------------------------------------------------------

  Scenario Outline: Get an AccessAttribute - dummy.feature does not exist
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                                 | values                                    |
      | userId,operationalUnit,includeGroups | changeit,dummy.feature/check/ALL/ALL,true |

  @NoRetry
  Scenario: Post - Assign access attribute of feature to users - Missing body
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I make a "POST" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations" has value "PARAMETER"
    And the property "path" in response body array with index "parameterViolations" has value "addFeatureToUsers.arg0"
    And the property "message" in response body array with index "parameterViolations" has value "Payload is required"
    And the property "value" in response body array with index "parameterViolations" has value ""

  @NoRetry
  Scenario: Post - Assign access attribute of feature to users - Empty body
    Given I create an empty payload with header "cc_csrftokenSpec"
    And I make a "POST" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations" has value "PARAMETER, PARAMETER"
#    And the property "path" in response body array with index "parameterViolations" has value "addFeatureToUsers.arg0.customerIds, addFeatureToUsers.arg0.featureService"
#    And the property "message" in response body array with index "parameterViolations" has value "Customer list must not be null, Feature must not be null"

  @NoRetry
  Scenario: Post - Assign access attribute of feature to users - Invalid input json
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature for Negative cases payload
    And I make a "POST" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

  @NoRetry
  Scenario: Post - Assign access attribute of feature to users - At least one customer
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "test" ","
    And I make a "POST" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations" has value "PARAMETER"
    And the property "path" in response body array with index "parameterViolations" has value "addFeatureToUsers.arg0"
    And the property "message" in response body array with index "parameterViolations" has value "Payload is required"
    And the property "value" in response body array with index "parameterViolations" has value ""

  @NoRetry
  Scenario: Post - Assign access attribute of feature to users - Feature cannot be null
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "null" "changeitwrong"
    And I make a "POST" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "addFeatureToUsers.arg0.featureService"
    And the property "message" in response body array with index "parameterViolations[0]" contains either of the values "Feature must not be null"
    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values ""

  @NoRetry
  Scenario: Post - Assign access attribute of feature to users - Feature cannot be empty
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "" "changeitwrong"
    And I make a "POST" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "addFeatureToUsers.arg0.featureService"
    And the property "message" in response body array with index "parameterViolations[0]" contains either of the values "Feature must not be empty"
    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values ""

  @NoRetry
  Scenario: Post - Assign access attribute of feature to users - Feature error
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "testFeatureName" "changeitwrong"
    And I make a "POST" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "FEATURE_ERROR"
    And the "description" in response body is "Feature name not supported ([Error Id: FEATURE_ERROR])"

  @NoRetry
  Scenario: Post - Assign access attribute of feature to users - Wrong operational unit format
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "dummyInvalidFeature" "changeitwrong"
    And I make a "POST" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "OPERATIONAL_UNIT_WRONG_FORMAT"
    And the "description" in response body is "Found Operational Unit with wrong format ([Error Id: OPERATIONAL_UNIT_WRONG_FORMAT])"

  @NoRetry
  Scenario: Post - Assign access attribute of feature to users - database error
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "dummyFeature" "changeitwrong"
    And I make a "POST" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 204
#    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
#    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "addFeatureToUsers.arg0.customerIds"
#    And the property "message" in response body array with index "parameterViolations[0]" contains either of the values "Customer list must not be null"
#    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values ""

  Scenario: Post - Assign access attribute of feature to users
    Given I login as a "newPlayerWeb" user
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "dummyFeature" "changeit"
    And I make a "POST" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario Outline: Get AccessAttributes - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "operationalUnit" in response body array with index "<index>" has value "dummy.feature/check/"
    And the property "accessType" in response body array with index "<index>" has value "ALLOW"
#    And the property "reason" in response body array with index "<index>" has value "Test"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "3-1"

    Examples:
      | keys                                 | values                                    | index | userId       | updatedByUserId |
      | userId,operationalUnit,includeGroups | changeit,dummy.feature/check/ALL/ALL,true | [0]   | newPlayerWeb | newPlayerWeb    |

  Scenario: Get all enabled feature flags
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 200
    And the nameless array response should contain 5 elements with values "subscription" and "subscriptionTest"

  Scenario Outline: Check if feature is ready to be delivered to players - dummy.feature not found
    Given I login as a "newPlayerWeb" user
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | key     | value        |
      | feature | dummyFeature |

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

#    ----------------------------------------------------------------------------------------------------------------------------------------
  @NoRetry
  Scenario: Del - Remove access attribute of feature to users - Missing body
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I make a "DEL" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations" has value "PARAMETER"
    And the property "path" in response body array with index "parameterViolations" has value "removeFeatureFromUsers.arg0"
    And the property "message" in response body array with index "parameterViolations" has value "Payload is required"
    And the property "value" in response body array with index "parameterViolations" has value ""

  @NoRetry
  Scenario: Del - Remove access attribute of feature to users - Empty body
    Given I create an empty payload with header "cc_csrftokenSpec"
    And I make a "DEL" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations" has value "PARAMETER, PARAMETER"
#    And the property "path" in response body array with index "parameterViolations" has value "removeFeatureFromUsers.arg0.customerIds, removeFeatureFromUsers.arg0.featureService"
#    And the property "message" in response body array with index "parameterViolations" contains either of the values "Feature must not be null, Customer list must not be null"
#    And the property "value" in response body array with index "parameterViolations" has value ""

  @NoRetry
  Scenario: Del - Remove access attribute of feature to users - Invalid input json
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature for Negative cases payload
    And I make a "DEL" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

  @NoRetry
  Scenario: Del - Remove access attribute of feature to users - At least one customer
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "test" ","
    And I make a "DEL" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"

  @NoRetry
  Scenario: Del - Remove access attribute of feature to users - Feature cannot be null
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "null" "changeitwrong"
    And I make a "DEL" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations" has value "PARAMETER"
    And the property "path" in response body array with index "parameterViolations" has value "removeFeatureFromUsers.arg0.featureService"
    And the property "message" in response body array with index "parameterViolations" has value "Feature must not be null"
    And the property "value" in response body array with index "parameterViolations" has value ""

  @NoRetry
  Scenario: Del - Remove access attribute of feature to users - Feature cannot be empty
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "" "changeitwrong"
    And I make a "DEL" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations" has value "PARAMETER"
    And the property "path" in response body array with index "parameterViolations" has value "removeFeatureFromUsers.arg0.featureService"
    And the property "message" in response body array with index "parameterViolations" has value "Feature must not be empty"
    And the property "value" in response body array with index "parameterViolations" has value ""

  @NoRetry
  Scenario: Del - Remove access attribute of feature to users - Feature error
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "testFeatureName" "changeitwrong"
    And I make a "DEL" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "FEATURE_ERROR"
    And the "description" in response body is "Feature name not supported ([Error Id: FEATURE_ERROR])"

  @NoRetry
  Scenario: Del - Remove access attribute of feature to users - Wrong operational unit format
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "subscriptionTest" "changeitwrong"
    And I make a "DEL" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "OPERATIONAL_UNIT_WRONG_FORMAT"
    And the "description" in response body is "Found Operational Unit with wrong format ([Error Id: OPERATIONAL_UNIT_WRONG_FORMAT])"

  @NoRetry
  Scenario: Del - Remove access attribute of feature to users - Database error
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "dummyFeature" "changeitwrong"
    And I make a "DEL" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 204
#    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
#    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "removeFeatureFromUsers.arg0.customerIds"
#    And the property "message" in response body array with index "parameterViolations[0]" contains either of the values "Customer list must not be null"
#    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values ""


  @NoRetry
  Scenario: Del - Remove access attribute of feature to users
    Given I login as a "newPlayerWeb" user
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "dummyFeature" "changeit"
    And I make a "DEL" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 204

  @NoRetry
  Scenario: Del - Remove access attribute of feature to users
    Given I login as a "newPlayerWeb" user
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Assign Access Attribute of Feature payload "dummyFeature" "changeit1"
    And I make a "DEL" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario Outline: Get AccessAttributes - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                                 | values                                    | index | userId       | updatedByUserId |
      | userId,operationalUnit,includeGroups | changeit,dummy.feature/check/ALL/ALL,true | [0]   | newPlayerWeb | newPlayerWeb    |

#    -------------------------------------------------------------------------------------------------------------------------------

  Scenario Outline: Get AccessAttributes - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                                 | values                               |
      | userId,operationalUnit,includeGroups | 0-0,dummy.feature/check/ALL/ALL,true |

  @NoRetry
  Scenario: Post - Enable feature service - Missing body
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I make a "POST" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "addFeatureToUsers.arg0"
    And the property "message" in response body array with index "parameterViolations[0]" contains either of the values "Payload is required"
    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values ""

  @NoRetry
  Scenario: Post - Enable feature service - Empty body
    Given I create an empty payload with header "cc_csrftokenSpec"
    And I make a "POST" call to "EnabledFeatureFlagsAll" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "enableFeatureToAllUsers.arg0"
    And the property "message" in response body array with index "parameterViolations[0]" contains either of the values "Feature must not be null"
    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values ""

  @NoRetry
  Scenario: Post - Enable feature service - Feature cannot be empty
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Enable Feature for payload with ""
    And I make a "POST" call to "EnabledFeatureFlagsAll" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "enableFeatureToAllUsers.arg0"
    And the property "message" in response body array with index "parameterViolations[0]" contains either of the values "Feature must not be empty"
    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values ""

  Scenario: Post - Enable feature service
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Enable Feature for payload with "dummyFeature"
    And I make a "POST" call to "EnabledFeatureFlagsAll" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario: Post - Enable feature service - Access attribute already exists
    And I create a Get "cc_csrftokenSpec" header
    And I create a Post Enable Feature for payload with "dummyFeature"
    And I make a "POST" call to "EnabledFeatureFlagsAll" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario Outline: Get AccessAttributes - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "operationalUnit" in response body array with index "<index>" has value "dummy.feature/check/"
    And the property "accessType" in response body array with index "<index>" has value "ALLOW"
    And the property "reason" in response body array with index "<index>" has value "FEATURE_REASON"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | keys                                 | values                               | index | userId | updatedByUserId |
      | userId,operationalUnit,includeGroups | 0-0,dummy.feature/check/ALL/ALL,true | [0]   | 0-0    | 3-1             |

  Scenario Outline: Check if feature is ready to be delivered to players - dummy.feature not found
    Given I login as a "newPlayerWeb" user
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | key            | value                 |
      | userId,feature | changeit,dummyFeature |

#    ----------------------------------------------------------------------------------------------------------------------------------

  Scenario: Del - Disable feature service - Missing body
#    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I make a "DEL" call to "EnabledFeatureFlagsAll" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "disableFeatureFromAllUsers.arg0"
    And the property "message" in response body array with index "parameterViolations[0]" contains either of the values "Payload is required"
    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values ""

  Scenario: Del - Disable feature service - Empty body
    Given I create a Get "cc_csrftokenSpec" header
    And I make a "DEL" call to "EnabledFeatureFlagsAll" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "disableFeatureFromAllUsers.arg0"
    And the property "message" in response body array with index "parameterViolations[0]" contains either of the values "Payload is required"
    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values ""

  Scenario: Del - Disable feature service - Feature cannot be empty
    Given I create a Get "cc_csrftokenSpec" header
    And I make a "DEL" call to "EnabledFeatureFlagsAll" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "disableFeatureFromAllUsers.arg0"
    And the property "message" in response body array with index "parameterViolations[0]" contains either of the values "Payload is required"
    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values ""

  Scenario: Del - Disable feature service
    Given I create a Get "cc_csrftokenSpec" header
    And I make a "DEL" call to "EnabledFeatureFlagsAll" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"

  Scenario: Del - Disable feature service - Access attribute does not exist
    Given I create a Get "cc_csrftokenSpec" header
    And I make a "DEL" call to "EnabledFeatureFlagsAll" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"

  Scenario Outline: Get AccessAttributes - dummy.feature does not exist
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1


    Examples:
      | keys                                 | values                               |
      | userId,operationalUnit,includeGroups | 0-0,dummy.feature/check/ALL/ALL,true |

#   -----------------------------------------------------------------------------------------------------------------------------------------------

  Scenario Outline: Delete an AccessAttribute - dummy.feature
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | keys                   | values                                              |
      | userId,operationalUnit | friendsAndFamilyGroupId,dummy.feature/check/ALL/ALL |

  Scenario Outline: Get an AccessAttribute - dummy.feature does not exist
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1

    Examples:
      | keys                   | values                                              |
      | userId,operationalUnit | friendsAndFamilyGroupId,dummy.feature/check/ALL/ALL |

  Scenario Outline: Delete an AccessAttribute - dummy.feature
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | keys                   | values                                             |
      | userId,operationalUnit | 0-0,dummy.feature/check/ALL/ALL,true,dummy.feature |


  Scenario Outline: Get an AccessAttribute - dummy.feature does not exist
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                   | values                        |
      | userId,operationalUnit | 0-0,dummy.feature/check/ALL/ALL |

  Scenario: Check if feature is ready to be delivered to players - dummy.feature does not exist
    Given I login as a "newPlayerWeb" user
    And I create a Get "mainSpec" header
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "NOT_FOUND"
    And the "description" in response body is "Feature service not found ([Error Id: NOT_FOUND])"


