@AccessService
Feature: Groups

  Scenario Outline: Get and Verify Access Groups - Success
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "memberType" in response body array with index "<index>" has value "1"
    And the property "updatedByUserId" in response body array with index "<index>" has value "0-"
    And the property "description" in response body array with index "<index>" has value "Access group for NO_PLAYER_LEVEL player level."
    And the property "name" in response body array with index "<index>" has value "NO_PLAYER_LEVEL"

    Examples:
      | keys                              | values                  | index |
      | memberType,name,nameCaseSensitive | 1,NO_player_LEVEL,false | [0]   |

  Scenario Outline: Get and Verify Access Groups - Success No objects cause of invalid memberId
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0


    Examples:
      | keys                                       | values                      |
      | memberType,name,nameCaseSensitive,memberId | 1,NO_player_LEVEL,false,1-1 |
      | memberType,name,nameCaseSensitive,memberId | 1,NO_player_LEVEL,true,1-1  |


    #12 Mandatory Groups
  Scenario Outline: Get and Verify ALL Access Groups - Success
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the 12 mandatory groups
    # And the number of results in a nameless array of objects is 12
    And the number of results in a nameless array of objects are greater than <resultsNumber>


    Examples:
      | resultsNumber |
      | 11            |


  @Concat @NoRetry
  Scenario: Get and Verify ALL Access Groups - Negative - Group Not Found
    Given I create a Get "api_mainSpec_mainHost" header
    And I concat the url "/test" to the end of url of method "AccessGroups" of service "AccessService"
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "GROUP_NOT_FOUND"
    And the "description" in response body is "Group does not exist ([Error Id: GROUP_NOT_FOUND])"


    #/7 always or from response?
  # if from response it depends on scenario  Get and Verify ALL Access Groups
  #retest this in flow
  @Concat
  Scenario: Get and Verify Access Groups - Success - Full Account
    Given I create a Get "api_mainSpec_mainHost" header
   # And I concat the url "/7" to the end of url of method "AccessGroups" of service "AccessService"
    And I concat the url "/fullAccountAccessGroupId" to the end of url of method "AccessGroups" of service "AccessService"
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And the "memberType" in response body is "1"
    And the "updatedByUserId" in response body is "0-"
    And the "description" in response body is "Access group for FULL_ACCOUNT player level."
    And the "name" in response body is "FULL_ACCOUNT"


  @NoRetry @skipIfNotAzure
  Scenario: Post Access Groups - Negative - Missing body
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "POST" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

  @NoRetry @skipIfNotAzure
  Scenario: Post Access Groups - Negative - Empty body
    Given I create an empty payload with header "api_mainSpec_mainHost"
    And I make a "POST" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"


  @NoRetry @skipIfNotAzure
  Scenario Outline: Post Access Groups - Negative - Invalid MemberType
    Given I create a POST AccessGroups payload with "<name>" "<description>" "<updatedByUserId>" "<memberType>"
    And I make a "POST" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_MEMBER_TYPE"
    And the "description" in response body is "Member type is not valid ([Error Id: INVALID_MEMBER_TYPE])"

    Examples:
      | name     | description     | updatedByUserId | memberType |
      | testName | testDescription |                 | -100       |


    #improved with testNameRandom -> e.g.g testName1000 or testName2000 or testName30000
    # this is done as to rerun the tests successfully and dont need the environment to restart.
  @NoRetry @skipIfNotAzure
  Scenario Outline: Post Access Groups - Success
    Given I create a POST AccessGroups payload with "<name>" "<description>" "<updatedByUserId>" "<memberType>"
    And I make a "POST" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 201
    And I copy the value of the newAccessGroupId from the response
    And I verify field "updatedByUserId" in response body has 1-playerId value
    And the "description" in response body is "<description>"
    And I verify field "name" in response body has the new calculated accessGroupName value

    Examples:
      | name           | description     | updatedByUserId | memberType |
      | testNameRandom | testDescription | newPlayerWeb    |            |


    #changed name to existingGroup. existingGroup replaces the previously created one. e.g. testName1000
  @NoRetry @skipIfNotAzure
  Scenario Outline: Post Access Groups - Negative - Already Exists
    Given I create a POST AccessGroups payload with "<name>" "<description>" "<updatedByUserId>" "<memberType>"
    And I make a "POST" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 409


    Examples:
      | name          | description     | updatedByUserId | memberType |
      | existingGroup | testDescription |                 |            |

  @skipIfNotAzure
  Scenario: Get AccessGroupId - Success
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccessGroupId" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    Then I make a "GET" call to "GetAccessGroupId" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify field "updatedByUserId" in response body has 1-playerId value
    And the "memberType" in response body is "3"
    And the "description" in response body is "testDescription"
    And I verify field "name" in response body has the new calculated accessGroupName value
    And I verify field "accessGroupId" in response body has the new calculated accessGroupId value


  Scenario: Get AccessGroupMembers - MemberId not specified
    Given I create a Get "api_mainSpec_mainHost" header
    When I make a "GET" call to "GetAccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "MEMBERID_NOT_SPECIFIED"
    And the "description" in response body is "Member ID must be specified ([Error Id: MEMBERID_NOT_SPECIFIED])"

  Scenario Outline: Get AccessGroupMembers - Invalid member id
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetAccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 404


    Examples:
      | keys     | values |
      | memberId | test   |

    #newplayerWeb = 1-playerId here
  @skipIfNotAzure
  Scenario Outline: Get AccessGroupMembers - Success
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetAccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 4
    And the property "updatedByUserId" in response body array with index "<index1>" has value "<updatedByUserId>"
    And the property "memberId" in response body array with index "<index1>" has value "<memberId>"
    And the property "retailerId" in response body array with index "<index1>" has value ""
    And the property "updatedByUserId" in response body array with index "<index2>" has value "<updatedByUserId>"
    And the property "memberId" in response body array with index "<index2>" has value "<memberId>"
    And the property "retailerId" in response body array with index "<index2>" has value ""
    And the property "updatedByUserId" in response body array with index "<index3>" has value "<updatedByUserId>"
    And the property "memberId" in response body array with index "<index3>" has value "<memberId>"
    And the property "retailerId" in response body array with index "<index3>" has value ""
    # + save 2 variables see if needed.
   # And I copy the value of the fullAccount? from the response
    #And I copy the value of the newAccessGroupId from the response


    Examples:
      | keys     | values   | memberId     | index1 | index2 | index3 | updatedByUserId |
      | memberId | changeit | newPlayerWeb | [0]    | [1]    | [2]    | 0-              |

  @skipIfAzure
  Scenario Outline: Get AccessGroupMembers - Success
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetAccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    And the property "updatedByUserId" in response body array with index "<index1>" has value "<updatedByUserId>"
    And the property "memberId" in response body array with index "<index1>" has value "<memberId>"
    And the property "retailerId" in response body array with index "<index1>" has value ""
    And the property "updatedByUserId" in response body array with index "<index2>" has value "<updatedByUserId>"
    And the property "memberId" in response body array with index "<index2>" has value "<memberId>"
    And the property "retailerId" in response body array with index "<index2>" has value ""
    And the property "updatedByUserId" in response body array with index "<index3>" has value "<updatedByUserId>"
    And the property "memberId" in response body array with index "<index3>" has value "<memberId>"
    And the property "retailerId" in response body array with index "<index3>" has value ""



    Examples:
      | keys     | values   | memberId     | index1 | index2 | index3 | updatedByUserId |
      | memberId | changeit | newPlayerWeb | [0]    | [1]    | [2]    | 0-              |

  @skipIfNotAzure
  Scenario: Get AccessGroupMembers - Success - New Created Access Group
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    When I make a "GET" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0


  Scenario Outline: Get AccessGroupMembers - Success - Full Account
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "fullAccountAccessGroupId"
    When I make a "GET" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects are greater than 0
    And the property "accessGroupId" in response body array with index "<index1>" has value "<accessGroupId>"
    And the property "updatedByUserId" in response body array with index "<index1>" has value "<updatedByUserId>"
    And the property "retailerId" in response body array with index "<index1>" has value "<retailerId>"


    Examples:
      | index1 | updatedByUserId | retailerId | accessGroupId            |
      | [0]    | 0-              |            | fullAccountAccessGroupId |

  @NoRetry
  Scenario Outline:  AccessGroupMembers - Negative - Group Not Found
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "123"
    When I make a "GET" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "GROUP_NOT_FOUND"
    And the "description" in response body is "Group does not exist ([Error Id: GROUP_NOT_FOUND])"


    Examples:
      | keys                | values        |
      | memberId,retailerId | 1006-1006,123 |


  @NoRetry
  Scenario Outline:  AccessGroupMembers  - Full Account - Invalid Parameters - Empty Response
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "fullAccountAccessGroupId"
    When I make a "GET" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0



    Examples:
      | keys                | values        |
      | memberId,retailerId | 1006-1006,123 |

### POST METHODS skipIfNotAzure till sure
# ### POST NEGATIVE SCENARIOS

  @NoRetry @skipIfNotAzure
  Scenario:  AccessGroupMembers  - (POST) Add a new member to the newly created access role - Group not found
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "test"
    When I make a "POST" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "GROUP_NOT_FOUND"
    And the "description" in response body is "Group does not exist ([Error Id: GROUP_NOT_FOUND])"


  @NoRetry @skipIfNotAzure
  Scenario:  AccessGroupMembers - (POST) Add a new member to the newly created access role - Missing body
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    When I make a "POST" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"


  @NoRetry @skipIfNotAzure
  Scenario:  AccessGroupMembers - (POST) Add a new member to the newly created access role - Missing memberId
    Given I create an empty payload with header "api_mainSpec_mainHost"
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    When I make a "POST" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "MISSING_MEMBER_ID"
    And the "description" in response body is "Member ID missing ([Error Id: MISSING_MEMBER_ID])"


  @NoRetry @skipIfNotAzure
  Scenario Outline:  AccessGroupMembers - (POST) Add a new member to the newly created access role - Invalid Requests
    Given I create a POST AccessGroupMembers payload with "<memberId>" "<retailerId>" "<updatedByUserId>"
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    When I make a "POST" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"


    Examples:
      | Gherkin Description                | memberId       | retailerId     | updatedByUserId | statusCode | errorId               | description                                                                                                      |
      | MemberId Only = Invalid JSON Input | test           |                |                 | 400        | INVALID_JSON          | Invalid JSON input                                                                                               |
      | Invalid Member Id                  | 1-0            | testRetailerId | 0-              | 400        | INVALID_MEMBER_ID     | Member ID invalid ([Error Id: INVALID_MEMBER_ID])                                                                |
      | Member Type Mismatch               | 1-newPlayerWeb | testRetailerId | 0-              | 400        | MEMBER_TYPE_MISMATCH  | The member type of the role doesn't match that of the role member being added ([Error Id: MEMBER_TYPE_MISMATCH]) |
      | Authorization Error                | 3-newPlayerWeb | testRetailerId | 0-              | 500        | INTERNAL_SERVER_ERROR | Internal Server Error                                                                                            |


    #recheck this
  @NoRetry @skipIfNotAzure
  Scenario Outline:  AccessGroupMembers - (POST) Add a new member to the newly created access role - Success
    Given I create a POST AccessGroupMembers payload with "<memberId>" "<retailerId>" "<updatedByUserId>"
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    When I make a "POST" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 201
    And I copy the value of the newGroupMemberId from the response
    And the "updatedByUserId" in response body is "<updatedByUserId>"
    And the "retailerId" in response body is "<retailerId>"
    And the "memberId" in response body has the prefix "3-" and new playerId
    And the "accessGroupId" in response body is the calculated newAccessGroupId

    Examples:
      | memberId       | retailerId | updatedByUserId |
      | 3-newPlayerWeb | 1          | 0-              |


  @NoRetry @skipIfNotAzure
  Scenario Outline:  AccessGroupMembers - (POST) Add a new member to the newly created access role - Success
    Given I create a POST AccessGroupMembers payload with "<memberId>" "<retailerId>" "<updatedByUserId>"
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    When I make a "POST" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 409


    Examples:
      | memberId       | retailerId | updatedByUserId |
      | 3-newPlayerWeb | 1          | 0-              |

  @skipIfNotAzure
  Scenario Outline:  AccessGroupMembers (Get new role members) - Invalid parameters
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    When I make a "GET" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 404


    Examples:
      | keys                | values    |
      | memberId,retailerId | test,test |

  @skipIfNotAzure
  Scenario Outline:  AccessGroupMembers (Get new role members) - Invalid retailerId, role member not found
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    When I make a "GET" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0


    Examples:
      | keys                | values       |
      | memberId,retailerId | 3-changeit,5 |

#check correct values
  @skipIfNotAzure
  Scenario Outline:  AccessGroupMembers (Get new role members) - Success - Correct Parameters
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    When I make a "GET" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "retailerId" in response body array with index "<index>" has value "1"
    And the property "updatedByUserId" in response body array with index "<index>" has value "0-"
    And the property "memberId" in response body array with index "<index>" has prefix "3-" and new playerId
    And the property "accessGroupId" in response body array with index "<index>" is the calculated newAccessGroupId


    Examples:
      | keys                | values       | index |
      | memberId,retailerId | 3-changeit,1 | [0]   |

  @skipIfNotAzure
  Scenario:  AccessGroupMembers (Get new role members) - Success
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "AccessGroupMembers" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    When I make a "GET" call to "AccessGroupMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "retailerId" in response body array with index "[0]" has value "1"
    And the property "updatedByUserId" in response body array with index "[0]" has value "0-"
    And the property "memberId" in response body array with index "[0]" has prefix "3-" and new playerId
    And the property "accessGroupId" in response body array with index "[0]" is the calculated newAccessGroupId




# check code for newGroupMemberId replace and stuff
  @NoRetry @skipIfNotAzure
  Scenario Outline: Get AccessGroupMemberId = Get specific role member - Negative Scenarios
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupId" "<accessgroupId>"
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupMemberId" "<accessgroupMemberId>"
    When I make a "GET" call to "AccessGroupMemberId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"


    Examples:
      | Gherkin Description      | accessgroupId    | accessgroupMemberId | statusCode | errorId               | description                                                     |
      | Invalid type of memberId | newAccessGroupId | test                | 500        | INTERNAL_SERVER_ERROR | Internal Server Error                                           |
      | Invalid memberId         | newAccessGroupId | 123                 | 404        | GROUPMEMBER_NOT_FOUND | Group member does not exist ([Error Id: GROUPMEMBER_NOT_FOUND]) |
      | Group not found          | test             | newGroupMemberId    | 404        | GROUP_NOT_FOUND       | Group does not exist ([Error Id: GROUP_NOT_FOUND])              |

# check code for newGroupMemberId replace and stuff
  @skipIfNotAzure
  Scenario: Get AccessGroupMemberId = Get specific role member - Success
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupMemberId" "newGroupMemberId"
    When I make a "GET" call to "AccessGroupMemberId" to service "AccessService"
    Then the API call is successful with status code 200
    And the "updatedByUserId" in response body is "0-"
    And the "retailerId" in response body is "1"
    And the "memberId" in response body has the prefix "3-" and new playerId
    And the "accessGroupId" in response body is the calculated newAccessGroupId



# check code for newGroupMemberId replace and stuff
  @NoRetry @skipIfNotAzure
  Scenario Outline: Del AccessGroupMemberId = Delete specific role member - Negative Scenarios
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupId" "<accessgroupId>"
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupMemberId" "<accessgroupMemberId>"
    When I make a "DEL" call to "AccessGroupMemberId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"


    Examples:
      | Gherkin Description      | accessgroupId    | accessgroupMemberId | statusCode | errorId               | description                                                                  |
      | Invalid type of memberId | newAccessGroupId | test                | 500        | INTERNAL_SERVER_ERROR | Internal Server Error                                                        |
      | Group Id Mismatch        | 1                | 1                   | 404        | GROUP_ID_MISMATCH     | The role member is not in the specified role ([Error Id: GROUP_ID_MISMATCH]) |
      | Group not found          | test             | newGroupMemberId    | 404        | GROUP_NOT_FOUND       | Group does not exist ([Error Id: GROUP_NOT_FOUND])                           |


# check code for newGroupMemberId replace and stuff
  @skipIfNotAzure
  Scenario: Del AccessGroupMemberId = Delete specific role member - Success
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupMemberId" "newGroupMemberId"
    When I make a "DEL" call to "AccessGroupMemberId" to service "AccessService"
    Then the API call is successful with status code 204

    # check code for newGroupMemberId replace and stuff
  @skipIfNotAzure @NoRetry @skipIfNotAzure
  Scenario: Del AccessGroupMemberId = Delete specific role member - Group member not found (already deleted)
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupMemberId" "newGroupMemberId"
    When I make a "DEL" call to "AccessGroupMemberId" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "GROUPMEMBER_NOT_FOUND"
    And the "description" in response body is "The role member does not exist ([Error Id: GROUPMEMBER_NOT_FOUND])"

    # check code for newGroupMemberId replace and stuff
  @NoRetry @skipIfNotAzure
  Scenario: Get AccessGroupMemberId = Get specific role member - Already deleted
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupId" "newAccessGroupId"
    And I change url resource of method "AccessGroupMemberId" of service "AccessService" with configured parameter "accessgroupMemberId" "newGroupMemberId"
    When I make a "GET" call to "AccessGroupMemberId" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "GROUPMEMBER_NOT_FOUND"
    And the "description" in response body is "Group member does not exist ([Error Id: GROUPMEMBER_NOT_FOUND])"



    # improved to testNameRandom = testName1000 or testName 1001 or tesName1313 e.t.c
  @skipIfNotAzure
  Scenario Outline: Post Access Groups - Add a new access role - Success
    Given I create a POST AccessGroups payload with "<name>" "<description>" "<updatedByUserId>" "<memberType>"
    And I make a "POST" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 201
    And I copy the value of the newAccessGroupId from the response
    And I verify field "updatedByUserId" in response body has 1-playerId value
    And the "description" in response body is "<description>"
    And I verify field "name" in response body has the new calculated accessGroupName value

    Examples:
      | name           | description            | updatedByUserId | memberType |
      | testNameRandom | thisIsATestDescription | newPlayerWeb    |            |


  @NoRetry @skipIfNotAzure
  Scenario Outline: Post Access Groups - Add a new access role - Same access role
    Given I create a POST AccessGroups payload with "<name>" "<description>" "<updatedByUserId>" "<memberType>"
    And I make a "POST" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 409


    Examples:
      | name          | description            | updatedByUserId | memberType |
      | existingGroup | thisIsATestDescription | newPlayerWeb    |            |


  @NoRetry @skipIfNotAzure
  Scenario Outline: Put Access Groups - Delete & Add Member to Group - Negative Scenarios
    Given I create a PUT AccessGroupsV2 payload with array "<actions>" "<accessGroupIds>" "<accessGroupMemberIds>" "<userIds>"
    And I make a "PUT" call to "AccessGroupsV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"


    Examples:
      | Gherkin Description                    | statusCode | actions    | accessGroupIds                    | accessGroupMemberIds              | userIds                   | errorId                        | description                                                               |
      | Group Not Found                        | 404        | DELETE,ADD | 12345,123456                      | 12345,123456                      | newPlayerWeb,newPlayerWeb | GROUP_NOT_FOUND                | Group does not exist ([Error Id: GROUP_NOT_FOUND])                        |
      | Missing accessGroupId                  | 400        | DELETE,ADD | null,null                         | 12345,123456                      | newPlayerWeb,newPlayerWeb | MISSING_ACCESS_GROUP_ID        | Access group ID missing ([Error Id: MISSING_ACCESS_GROUP_ID])             |
      | Missing userId for ADD                 | 400        | DELETE,ADD | newAccessGroupId,newAccessGroupId | newGroupMemberId,newGroupMemberId | newPlayerWeb,null         | MISSING_MEMBER_ID              | Member ID missing ([Error Id: MISSING_MEMBER_ID])                         |
      | Missing accessGroupMemberId for DELETE | 400        | DELETE,ADD | newAccessGroupId,newAccessGroupId | null,null                         | newPlayerWeb,newPlayerWeb | MISSING_ACCESS_GROUP_MEMBER_ID | AccessGroupMember ID missing ([Error Id: MISSING_ACCESS_GROUP_MEMBER_ID]) |
      | Incorrect userId for ADD               | 400        | DELETE,ADD | newAccessGroupId,newAccessGroupId | newGroupMemberId,newGroupMemberId | newPlayerWeb,1-0          | INVALID_MEMBER_ID              | Member ID invalid ([Error Id: INVALID_MEMBER_ID])                         |


    ##QUERY PARAMS test in azure


  @skipIfNotAzure @Concat
  Scenario: Put Access Groups - Delete & Add Member to Group  - Empty Array (Request) - Success 0 Length
    Given I concat the url "?updatedByUserId=1-newPlayerWeb" to the end of url of method "AccessGroupsV2" of service "AccessService"
    And I create an empty array payload with header "api_mainSpec_mainHost"
    And I make a "PUT" call to "AccessGroupsV2" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0


  @skipIfNotAzure @Concat
  Scenario Outline: Put Access Groups - Delete Member from an access group - Success
    Given I concat the url "?updatedByUserId=1-newPlayerWeb" to the end of url of method "AccessGroupsV2" of service "AccessService"
    And I create a PUT AccessGroupsV2 payload with array "<actions>" "<accessGroupIds>" "<accessGroupMemberIds>" "<userIds>"
    And I make a "PUT" call to "AccessGroupsV2" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0


    Examples:
      | actions | accessGroupIds   | accessGroupMemberIds | userIds      |
      | DELETE  | newAccessGroupId | newGroupMemberId     | newPlayerWeb |


  @NoRetry @skipIfNotAzure @Concat
  Scenario Outline: Put Access Groups - Delete & Add Member from an access group - Missing Arguments
    Given I concat the url "?updatedByUserId=1-newPlayerWeb" to the end of url of method "AccessGroupsV2" of service "AccessService"
    And I create a PUT AccessGroupsV2 payload with array "<actions>" "<accessGroupIds>" "<accessGroupMemberIds>" "<userIds>"
    And I make a "PUT" call to "AccessGroupsV2" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"


    Examples:
      | actions | accessGroupIds | accessGroupMemberIds | userIds | errorId      | description        |
      |         |                |                      |         | INVALID_JSON | Invalid JSON input |


  @skipIfNotAzure @Concat
  Scenario Outline: Put Access Groups - Delete & Add Member from an access group - Success
    Given I concat the url "?updatedByUserId=1-newPlayerWeb" to the end of url of method "AccessGroupsV2" of service "AccessService"
    And I create a PUT AccessGroupsV2 payload with array "<actions>" "<accessGroupIds>" "<accessGroupMemberIds>" "<userIds>"
    And I make a "PUT" call to "AccessGroupsV2" to service "AccessService"
    Then the API call is successful with status code 200


    Examples:
      | actions    | accessGroupIds                    | accessGroupMemberIds    | userIds                   |
      | DELETE,ADD | newAccessGroupId,newAccessGroupId | newGroupMemberId,123123 | newPlayerWeb,newPlayerWeb |

