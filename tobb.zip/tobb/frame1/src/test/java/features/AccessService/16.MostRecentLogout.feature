@AccessService
Feature: Most Recent Logout

  Scenario: Get Session Minutes - Success after 1st Login
    Given I login as a "newPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 200
    And the "logoutMethod" in response body is "LOGOUT_SELECTED"
    And the "channel" in response body is "WEB"
    And the "minutes" in response body is above -1
    # and loginTime in response body to include time?


  @skipIfNotAzure @NoRetry
  Scenario: Get Session Minutes - Negative (Expired after Delay)
    Given I add 810 seconds delay
    And I create a Get "mainSpec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 401
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=rest.sessionminutes/item/get/WEB"


  @skipIfNotAzure
  Scenario: Get Session Minutes - Success After Expired + 1st Login
    Given I login as a "newPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 200
    And the "logoutMethod" in response body is "RELOGIN"
    And the "channel" in response body is "WEB"
    And the "minutes" in response body is above -1
    # and loginTime in response body to include


  Scenario: Get Session Minutes - Success after Relogin
    Given I login as a "newPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 200
    And the "logoutMethod" in response body is "RELOGIN"
    And the "channel" in response body is "WEB"
    And the "minutes" in response body is above -1
    # and loginTime in response body to include time?

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204
