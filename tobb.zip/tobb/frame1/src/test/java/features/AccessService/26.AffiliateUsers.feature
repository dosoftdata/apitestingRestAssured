@AccessService
Feature: Affiliate Users


  Scenario: Get admin session
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetAdminSession" to service "AdminService"
    Then the API call is successful with status code 200
    And the "loginName" in response body is "admin"
    And the "language" in response body is "en_US"
    And the "email" in response body is "support@novomaticls.com"

  @NoRetry  @skipIfNotAzure
  Scenario Outline: Create new role "Clerk" - Password policy invalidation
    And I create a Get "cc_csrftokenSpec" header
    And I create a POST CreateNewRole payload for Affiliate "<email>" "<firstname>" "<language>" "<lastName>" "<loginName>" "<password>" "<passwordRepeated>"
    When I make a "POST" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the property "description" includes value "password INVALID_LENGTH"

    Examples:
      | email                 | firstname | language | lastName | loginName      | password       | passwordRepeated |
      | affiliateuser@opap.gr | Affiliate |          | User     | Affiliateuser1 | Affiliateuser1 | Affiliateuser1   |

  @NoRetry  @skipIfNotAzure
  Scenario Outline: Create new role "Clerk" - Username already taken
    And I create a Get "cc_csrftokenSpec" header
    And I create a POST CreateNewRole payload for Affiliate "<email>" "<firstname>" "<language>" "<lastName>" "<loginName>" "<password>" "<passwordRepeated>"
    When I make a "POST" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    And I check if response code is 400 or 200

    Examples:
      | email                 | firstname | language | lastName | loginName      | password         | passwordRepeated |
      | affiliateuser@opap.gr | Affiliate |          | User     | Affiliateuser1 | Affiliateuser1!! | Affiliateuser1!! |

  Scenario: Get clerk's accessRoleId
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code 200
    And I copy the value of the ClerkAccessRoleId

  Scenario: Get - Verify BO users
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    Then the API call is successful with status code 200
   And I check that the size of data.length is above 1

  Scenario: Get admin session
    And I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetAdminSession" to service "AdminService"
    Then the API call is successful with status code 200
    And the "loginName" in response body is "admin"
    And the "language" in response body is "en_US"
    And the "email" in response body is "support@novomaticls.com"

  Scenario: Get - Verify BO users
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    Then the API call is successful with status code 200
    Then I copy the value of the AffiliateUserRoleId
    And I check that the size of data.length is above 1

  Scenario Outline: Get player's payments as Admin
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerPaymentsAsAdmin" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 0

    Examples:
      | keys       | values   |
      | customerId | changeit |

  Scenario: Get player's transactions as Admin
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerTransactionsAsAdmin1" of service "WalletService" with new playerId
    When I make a "GET" call to "GetPlayerTransactionsAsAdmin1" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 0

  @skipIfNotAzure
  Scenario Outline: Put - Enable Clerk user
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT EnableClerkUser payload with "<email>" "<firstname>" "<language>" "<lastName>" "<loginName>" <status> "<groupIds>"
    And I change url resource of method "EnableClerkUser" of service "AdminService" with new AffiliateUserRoleId
    When I make a "PUT" call to "EnableClerkUser" to service "AdminService"
    Then the API call is successful with status code 200

    Examples:
      | email                 | firstname | language | lastName | loginName      | status | groupIds             |
      | affiliateuser@opap.gr | Affiliate |          | User     | affiliateuser1 | 1      | CLERK_ACCESS_ROLE_ID |

  @skipIfNotAzure @NoRetry
  Scenario: Post - Login as Affiliate user via CC endpoint - Negative scenario
    Given I create a Get "cc_csrftokenSpec" header
    And I create a Login as Affiliate user Post payload with "Affiliateuser1"
    When I make a "POST" call to "LoginBackOffice" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_USER_PASSWORD"
    And the "description" in response body is "Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])"

    @skipIfNotAzure
  Scenario: Get admin session
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetAdminSession" to service "AdminService"
    Then the API call is successful with status code 200
    And the "loginName" in response body is "admin"
    And the "language" in response body is "en_US"
    And the "email" in response body is "support@novomaticls.com"

  Scenario: Get - Verify BO users
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 1
    Then I copy the value of the AffiliateUserRoleId

  @skipIfNotAzure @NoRetry
  Scenario Outline: Put - Update Affiliate's password
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT UpdateAffiliatePassword payload with "<password>" "<passwordRepeated>"
   And I change url resource of method "UpdateAffiliatePassword" of service "AdminService" with new AffiliateUserRoleId
    When I make a "PUT" call to "UpdateAffiliatePassword" to service "AdminService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "password INVALID_LENGTH"

    Examples:
      | password       | passwordRepeated |
      | Affiliateuser1 | Affiliateuser1!  |

  @skipIfNotAzure
  Scenario Outline: Put - Enable Clerk user
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT EnableClerkUser payload with "<email>" "<firstname>" "<language>" "<lastName>" "<loginName>" <status> "<groupIds>"
    And I change url resource of method "EnableClerkUser" of service "AdminService" with new AffiliateUserRoleId
    When I make a "PUT" call to "EnableClerkUser" to service "AdminService"
    Then the API call is successful with status code 200

    Examples:
      | email                 | firstname | language | lastName | loginName      | status | groupIds             |
      | affiliateuser@opap.gr | Affiliate |          | User     | affiliateuser1 | 1      | CLERK_ACCESS_ROLE_ID |

  Scenario: Delete Current Session - LogOut
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "DEL" call to "DeleteCurrentSession" to service "AccessService"
    Then the API call is successful with status code 204




