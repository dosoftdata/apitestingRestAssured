@AccessService
Feature: Rabbit MQ

    #Logic: if already exists check for 201 if not check 204. No need to recreate many queues.
  @skipIfNotAzure
  Scenario Outline: Create Queue - Test Access
    Given I create a PUT CreateQueue payload with <autoDelete> <durable> <arguments> "<vhost>" "<name>"
    And I change url resource of method "CreateQueue" of service "RabbitMQService" with configured parameter "queue" "testAccess"
    When I make a "PUT" call to "CreateQueue" to service "RabbitMQService"
    Then the API call is successful with either the status code 201 or 204

    Examples:
      | autoDelete | durable | arguments | vhost | name       |
      | false      | true    | {}        | /     | testAccess |


  @skipIfNotAzure
  Scenario Outline: Post - Create Exchange/Queue Binding for specific routing key
    Given I create a POST CreateBinding payload with "<source>" "<vhost>" "<routingKey>" "<destination>" "<destinationType>" <arguments>
    And I change url resource of method "CreateBinding" of service "RabbitMQService" with configured parameter "exchange" "access.sessions.notify"
    And I change url resource of method "CreateBinding" of service "RabbitMQService" with configured parameter "queue" "testAccess"
    When I make a "POST" call to "CreateBinding" to service "RabbitMQService"
    Then the API call is successful with status code 201


    Examples:
      | source                 | vhost | routingKey                     | destination | destinationType | arguments |
      | access.sessions.notify | /     | customer.last.accessed.session | testAccess  | q               | {}        |
      | access.sessions.notify | /     | customer.inactive.session      | testAccess  | q               | {}        |
      | access.sessions.notify | /     | customer.login.success         | testAccess  | q               | {}        |
      | access.sessions.notify | /     | customer.logout.success        | testAccess  | q               | {}        |


  @skipIfNotAzure
  Scenario Outline: Post - Publish to Exchange
    Given I create a POST PublishToExchange payload with "<contentType>" "<routingKey>" "<payload>" "<payloadEncoding>"
    And I change url resource of method "PublishToExchange" of service "RabbitMQService" with configured parameter "exchange" "access.sessions.notify"
    When I make a "POST" call to "PublishToExchange" to service "RabbitMQService"
    Then the API call is successful with status code 200


    Examples:
      | contentType      | routingKey                     | payload                                                                                                                                                                                  | payloadEncoding |
      | application/json | customer.last.accessed.session | test                                                                                                                                                                                     | string          |
      | application/json | customer.last.accessed.session | { \\\'sessionId\\\': \\\'QCj7Postjgl1CUWOAq708Fx24Hvl-gR8w-jFfb_s6Scu\\\', \\\'lastAccessed\\\': 1591867972000, \\\'userId\\\': { \\\'id\\\': \\\'{{playerId}}\\\', \\\'type\\\': 1 } }  | string          |
      | application/json | customer.last.accessed.session | test                                                                                                                                                                                     | string          |
      | application/json | customer.last.accessed.session | { \\\'sessionId\\\': \\\'QCj7Postjgl1CUWOAq708Fx24Hvl-gR8w-jFfb_s6Scu\\\', \\\'operationDate\\\': 1591867972000, \\\'userId\\\': { \\\'id\\\': \\\'{{playerId}}\\\', \\\'type\\\': 1 } } | string          |
      | application/json | customer.inactive.session      | test                                                                                                                                                                                     | string          |
      | application/json | customer.inactive.session      | { \\\'sessionId\\\': \\\'QCj7Postjgl1CUWOAq708Fx24Hvl-gR8w-jFfb_s6Scu\\\', \\\'userId\\\': { \\\'id\\\': \\\'{{playerId}}\\\', \\\'type\\\': 1 } }                                       | string          |


  @skipIfNotAzure
  Scenario Outline: Post - Publish login information to access.sessions.notify Exchange
    Given I create a POST PublishToExchange payload with "<contentType>" "<routingKey>" "<payload>" "<payloadEncoding>"
    And I change url resource of method "PublishToExchange" of service "RabbitMQService" with configured parameter "exchange" "access.sessions.notify"
    When I make a "POST" call to "PublishToExchange" to service "RabbitMQService"
    Then the API call is successful with status code 200


    Examples:
      | GherkinDecription   | contentType      | routingKey             | payload                                                                                                                                                                                                                                                                                                                  | payloadEncoding |
      | Invalid Payload     | application/json | customer.login.success | test                                                                                                                                                                                                                                                                                                                     | string          |
      | Invalid api Version | application/json | customer.login.success | { { \\\'sessionId\\\': \\\'QCj7Postjgl1CUWOAq708Fx24Hvl-gR8w-jFfb_s6Scu\\\', \\\'operation\\\': \\\'login\\\', \\\'userId\\\': \\\'1-{{playerId}}\\\', \\\'securityDomainName\\\': \\\'\\\', \\\'channel\\\': \\\'WEB\\\', \\\'subchannel\\\': \\\'\\\', \\\'operationDate\\\': 1592835210337, \\\'apiVersion\\\': 100 } | string          |
      | Valid               | application/json | customer.login.success | { \\\'sessionId\\\': \\\'QCj7Postjgl1CUWOAq708Fx24Hvl-gR8w-jFfb_s6Scu\\\', \\\'operation\\\': \\\'login\\\', \\\'userId\\\': \\\'1-{{playerId}}\\\', \\\'securityDomainName\\\': \\\'\\\', \\\'channel\\\': \\\'WEB\\\', \\\'subchannel\\\': \\\'\\\', \\\'operationDate\\\': 1592835210337, \\\'apiVersion\\\': 1 }     | string          |

  @skipIfNotAzure
  Scenario Outline: Post - Publish logout information to access.sessions.notify Exchange
    Given I create a POST PublishToExchange payload with "<contentType>" "<routingKey>" "<payload>" "<payloadEncoding>"
    And I change url resource of method "PublishToExchange" of service "RabbitMQService" with configured parameter "exchange" "access.sessions.notify"
    When I make a "POST" call to "PublishToExchange" to service "RabbitMQService"
    Then the API call is successful with status code 200


    Examples:
      | GherkinDecription   | contentType      | routingKey              | payload                                                                                                                                                                                                                                                                                                                 | payloadEncoding |
      | Invalid Payload     | application/json | customer.logout.success | test                                                                                                                                                                                                                                                                                                                    | string          |
      | Invalid api Version | application/json | customer.logout.success | { \\\'sessionId\\\': \\\'QCj7Postjgl1CUWOAq708Fx24Hvl-gR8w-jFfb_s6Scu\\\', \\\'operation\\\': \\\'logout\\\', \\\'userId\\\': \\\'1-{{playerId}}\\\', \\\'securityDomainName\\\': \\\'\\\', \\\'channel\\\': \\\'WEB\\\', \\\'subchannel\\\': \\\'\\\', \\\'operationDate\\\': 1592835210337, \\\'apiVersion\\\': 100 } | string          |
      | Valid               | application/json | customer.logout.success | { \\\'sessionId\\\': \\\'QCj7Postjgl1CUWOAq708Fx24Hvl-gR8w-jFfb_s6Scu\\\', \\\'operation\\\': \\\'logout\\\', \\\'userId\\\': \\\'1-{{playerId}}\\\', \\\'securityDomainName\\\': \\\'\\\', \\\'channel\\\': \\\'WEB\\\', \\\'subchannel\\\': \\\'\\\', \\\'operationDate\\\': 1592835210337, \\\'apiVersion\\\': 1 }   | string          |


  @skipIfNotAzure
  Scenario Outline: Post - Get Messages from testAccess Queue
    Given I create a POST GetQueueMessages payload with <count> "<ackMode>" "<encoding>" <truncate>
    And I change url resource of method "GetQueueMessages" of service "RabbitMQService" with configured parameter "queue" "testAccess"
    When I make a "POST" call to "GetQueueMessages" to service "RabbitMQService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects are greater than 5
    And the response includes value "sessionId"
    And the response includes value "userId"
    And the response includes value "customer.last.accessed.session"
    And the response includes value "customer.login.success"
    And the response includes value "customer.logout.success"
    And the response includes value "test"
    And the response includes value "login"
    And the response includes value "logout"
    #this assertion fails in the second run e.t.c cause no new queue is made probably.
    #And the response includes value "customer.inactive.session"




    Examples:
      | count | ackMode           | encoding | truncate |
      | 50    | ack_requeue_false | auto     | 50000    |



