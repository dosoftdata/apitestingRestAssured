@AccessService @NoRetry
Feature: Feature flag for logged in users


  Scenario: Get Session
    Given I login as a "newPlayerWeb" user
    And I create a Get "mainSpec" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code 200


  @skipIfAzure
  Scenario Outline: Check if feature is ready to be delivered to players - Found
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 204


    Examples:
      | key     | value        |
      | feature | subscription |

  @NoRetry @skipIfNotAzure
  Scenario Outline: Check if feature is ready to be delivered to players - Not found
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "NOT_FOUND"
    And the "description" in response body is "Feature service not found ([Error Id: NOT_FOUND])"

    Examples:
      | key     | value        |
      | feature | subscription |

  Scenario: Get AccessGroups
    Given I create a Get "api_mainSpec_mainHost" header
    When I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Get an AccessAttribute - Feature.subscription does not exist
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                                 | values                                                   |
      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,feature.subscription/check/,true |

  @skipIfNotAzure
  Scenario Outline: Add an AccessAttribute - Success
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload for friendsAndFamilyGroupId with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<validFrom>" "<validTo>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"

    Examples:
      | accessType | operationalUnit             | userId                  | created | updated | updatedByUserId         | operatorId | reason | validFrom | validTo | index |
      | ALLOW      | feature.subscription/check/ | friendsAndFamilyGroupId |         |         | friendsAndFamilyGroupId | 0          | Test   | null      | null    | [0]   |

  @skipIfNotAzure
  Scenario Outline: Get an AccessAttribute - Feature.subscription exists
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "operationalUnit" in response body array with index "<index>" has value "feature.subscription/check/"
    And the property "accessType" in response body array with index "<index>" has value "ALLOW"
    And the property "reason" in response body array with index "<index>" has value "Test"

    Examples:
      | keys                                 | values                                                          | index |
      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,feature.subscription/check/ALL/ALL,true | [0]   |

  @skipIfAzure
  Scenario Outline: Get an AccessAttribute - Feature.subscription exists
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1

    Examples:
      | keys                                 | values                                                          |
      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,feature.subscription/check/ALL/ALL,true |

  @NoRetry
  Scenario Outline: Check if feature is ready to be delivered to players
    Given I login as a "newPlayerWeb" user
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | key            | value                 |
      | feature,userId | subscription,changeit |

  @skipIfNotAzure
  Scenario Outline: Delete an AccessAttribute
    And I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    When I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | key                                  | value                                                           |
      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,feature.subscription/check/ALL/ALL,true |

  @skipIfNotAzure
  Scenario Outline: Get an AccessAttribute - Feature.subscription exists
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                                 | values                                                          |
      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,feature.subscription/check/ALL/ALL,true |


  @NoRetry @skipIfNotAzure
  Scenario Outline: Check if feature is ready to be delivered to players - Not found
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "NOT_FOUND"
    And the "description" in response body is "Feature service not found ([Error Id: NOT_FOUND])"

    Examples:
      | key            | value                 |
      | feature,userId | subscription,changeit |

