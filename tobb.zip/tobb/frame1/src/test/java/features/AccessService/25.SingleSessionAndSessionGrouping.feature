@skipIfNotAzure @AccessService
Feature: Single Session And Session Grouping

  Scenario Outline: Get User Sessions 1 - 1 EP ACTIVE
    Given I login as a "newPlayerWeb" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUserSessions" of service "AccessService" with new playerId
    When I make a "GET" call to "GetUserSessions" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify for group "EP" the fields <EPwebActive> <EPwebRememberMeActive> <EPwebRememberMeTotal> for Get User Session

    Examples:
      | EPwebActive | EPwebRememberMeActive | EPwebRememberMeTotal |
      | 1           | 0                     | 0                    |


  Scenario Outline: Force Logout Sessions CC - Success v2
    Given I create a DEL ForceLogoutCC payload with "<reason>" "<group>"
    And I change url resource of method "ForceLogoutSessionsV2CC" of service "AccessService" with new playerId
    When I make a "DEL" call to "ForceLogoutSessionsV2CC" to service "AccessService"
    Then the API call is successful with status code 200
    And the "sessions[0]" in response body has value not null

    Examples:
      | reason | group |
      | FRAUD  | EP    |


  Scenario Outline: DatabaseBridge - INSERT Query in BGPSESSIONS (Add new rememberMe session in EP)
    Given I create a DataBridge Payload with "<query>"
    When I make a "POST" call to "DatabaseExecute" to service "DatabaseBridgeService"
    Then the API call is successful with status code 200

    Examples:
      | query                                                                                                                                                                                                                                                                                                                                                                |
      | INSERT INTO BGPSESSIONS (RETAILERID, USERTYPE, USERID, SESSIONID, SECURITYDOMAINNAME, INACTIVETIMEOUT, EXPIRES, LASTACCESSED, TERMINALID, CLERKID, SESSIONGROUP) VALUES (101, 1,newPlayerId, 'randomSessionId', 'testDomain', 5, TO_DATE('2152-01-27 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2152-01-27 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '101', 101, 'EP') |


  Scenario Outline: DatabaseBridge - INSERT Query in BGPSESSIONMINUTES (Add new rememberMe session in EP)
    Given I create a DataBridge Payload with "<query>"
    When I make a "POST" call to "DatabaseExecute" to service "DatabaseBridgeService"
    Then the API call is successful with status code 200

    Examples:
      | query                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
      | INSERT INTO BGPSESSIONMINUTES (SESSIONMINUTEID, RETAILERID, USERTYPE, USERID, LOGINRESULT, SESSIONID, MINUTES, LOGINTIME, LOGOUTMETHOD, CHANNEL, SUBCHANNEL, USERAGENT, IPADDRESS, SECURITYDOMAINNAME, REASON, TERMINALID, TRIGGEREDBYTYPE, TRIGGEREDBYID, CREDENTIALDOMAIN, CLERKID, UPDATED) VALUES (randomId, 101, 1,newPlayerId, 0, 'calculatedSessionId', 15, TO_DATE('2022-01-27 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 2, 'MOBILE', 'iOS', 'PostmanRuntime/7.29.0', '192.168.33.3', 'testDomain', 'USER_INACTIVE', '101', 1,newPlayerId, 'password', 101, TO_DATE('2022-01-27 00:00:00', 'YYYY-MM-DD HH24:MI:SS')) |

  Scenario Outline: Get user's session group - SELECT Query in BGPSESSIONS
    Given I login as a "newPlayerWeb" user
    And I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And the property "SESSIONGROUP" in response body array with index "rows[0]" has value "EP"

    Examples:
      | queryType | query                                                                                                                                                                 |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`BGPSESSIONS` WHERE USERID = '{{playerId}}' AND SESSIONID IS NOT NULL AND SESSIONGROUP='EP' ORDER BY LASTACCESSED DESC |


  Scenario Outline: Get User Sessions 2 - 1 EP ACTIVE
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUserSessions" of service "AccessService" with new playerId
    When I make a "GET" call to "GetUserSessions" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify for group "EP" the fields <EPwebActive> <EPwebRememberMeActive> <EPwebRememberMeTotal> for Get User Session

    Examples:
      | EPwebActive | EPwebRememberMeActive | EPwebRememberMeTotal |
      | 1           | 0                     | 0                    |

  Scenario Outline: Force Logout Sessions CC - Success v2
    Given I create a DEL ForceLogoutCC payload with "<reason>" "<group>"
    And I change url resource of method "ForceLogoutSessionsV2CC" of service "AccessService" with new playerId
    When I make a "DEL" call to "ForceLogoutSessionsV2CC" to service "AccessService"
    Then the API call is successful with status code 200
    And the "sessions[0]" in response body has value not null

    Examples:
      | reason | group |
      | FRAUD  | EP    |


  Scenario Outline: DatabaseBridge - INSERT Query in BGPSESSIONS (Add new rememberMe session in NEP)
    Given I create a DataBridge Payload with "<query>"
    When I make a "POST" call to "DatabaseExecute" to service "DatabaseBridgeService"
    Then the API call is successful with status code 200

    Examples:
      | query                                                                                                                                                                                                                                                                                                               |
      | INSERT INTO BGPSESSIONS (RETAILERID, USERTYPE, USERID, SESSIONID, SECURITYDOMAINNAME, INACTIVETIMEOUT, EXPIRES, LASTACCESSED, TERMINALID, CLERKID, SESSIONGROUP) VALUES (101, 1,newPlayerId, 'randomSessionId', 'testDomain', 0,  NULL, TO_DATE('2022-01-27 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), '101', 101, 'NEP') |


  Scenario Outline: DatabaseBridge - INSERT Query in BGPSESSIONMINUTES (Add new rememberMe session in NEP)
    Given I create a DataBridge Payload with "<query>"
    When I make a "POST" call to "DatabaseExecute" to service "DatabaseBridgeService"
    Then the API call is successful with status code 200

    Examples:
      | query                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
      | INSERT INTO BGPSESSIONMINUTES (SESSIONMINUTEID, RETAILERID, USERTYPE, USERID, LOGINRESULT, SESSIONID, MINUTES, LOGINTIME, LOGOUTMETHOD, CHANNEL, SUBCHANNEL, USERAGENT, IPADDRESS, SECURITYDOMAINNAME, REASON, TERMINALID, TRIGGEREDBYTYPE, TRIGGEREDBYID, CREDENTIALDOMAIN, CLERKID, UPDATED) VALUES (randomId, 101, 1,newPlayerId, 0, 'calculatedSessionId', 15, TO_DATE('2022-01-27 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 2, 'WEB', 'Chrome', 'PostmanRuntime/7.29.0', '192.168.33.3', 'testDomain', 'USER_INACTIVE', '101', 1,newPlayerId, 'password', 101, TO_DATE('2022-01-27 00:00:00', 'YYYY-MM-DD HH24:MI:SS')) |


  Scenario Outline: LoginNew NEP - rememberMe true
    Given I create a POST LoginNew payload including RememberMe with "<username>" "<password>" "<group>" "<channel>" "<rememberMe>"
    And I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code 200

    Examples:
      | username     | password     | group | channel | rememberMe |
      | newPlayerWeb | Qwerty12345! | NEP   | WEB     | true       |

  Scenario Outline: Get user's session group - SELECT Query in BGPSESSIONS 3
    Given I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And the "rows.length" in response body is "[]"
   # And the "rows[0]" in response body has value null

    Examples:
      | queryType | query                                                                                                                                                                 |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`BGPSESSIONS` WHERE USERID = '{{playerId}}' AND SESSIONID IS NOT NULL AND SESSIONGROUP='EP' ORDER BY LASTACCESSED DESC |


  Scenario Outline: Get User Sessions 3 - NEP - 2-1-2
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUserSessions" of service "AccessService" with new playerId
    When I make a "GET" call to "GetUserSessions" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify for group "NEP" the fields <NEPwebActive> <NEPwebRememberMeActive> <NEPwebRememberMeTotal> for Get User Session

    Examples:
      | NEPwebActive | NEPwebRememberMeActive | NEPwebRememberMeTotal |
      | 2            | 1                      | 2                     |

  Scenario Outline: Force Logout Sessions CC - Success v2
    Given I create a DEL ForceLogoutCC payload with "<reason>" "<group>"
    And I change url resource of method "ForceLogoutSessionsV2CC" of service "AccessService" with new playerId
    When I make a "DEL" call to "ForceLogoutSessionsV2CC" to service "AccessService"
    Then the API call is successful with status code 200
    And the "sessions.length" in response body is above 0
    And the "sessions[0]" in response body has value not null

    Examples:
      | reason | group |
      | FRAUD  | EP    |