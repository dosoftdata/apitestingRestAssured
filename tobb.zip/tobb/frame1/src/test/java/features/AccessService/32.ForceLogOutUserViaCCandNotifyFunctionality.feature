@AccessService
Feature: Force LogOut User Via CC and Notify Functionality


  @skipIfNotAzure
  Scenario Outline: Add an AccessAttribute - Delete access attribute
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload for friendsAndFamilyGroupId with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<validFrom>" "<validTo>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"

    Examples:
      | accessType | operationalUnit                    | userId | created | updated | updatedByUserId | operatorId | reason | validFrom | validTo | index |
      | ALLOW      | adminrest.sessions/list/delete/WEB | 3-1    |         |         | 3-1             | 0          | Test   |           |         | [0]   |


  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Delete access attribute
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the "userId" in response body is "[3-1]"
    And the "updatedByUserId" in response body is "[3-1]"
    And the "reason" in response body is "[Test]"
    And the "operationalUnit" in response body is "[adminrest.sessions/list/delete/WEB]"
    And the "accessType" in response body is "[ALLOW]"

    Examples:
      | keys                                 | values                                      |
      | userId,operationalUnit,includeGroups | 3-1,adminrest.sessions/list/delete/WEB,true |

  @skipIfNotAzure
  Scenario Outline: Add an AccessAttribute - Get access attribute
#    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload for friendsAndFamilyGroupId with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<validFrom>" "<validTo>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"

    Examples:
      | accessType | operationalUnit                 | userId | created | updated | updatedByUserId | operatorId | reason | validFrom | validTo | index |
      | ALLOW      | adminrest.sessions/item/get/WEB | 3-1    |         |         | 3-1             | 0          | Test   |           |         | [0]   |


  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Get access attribute
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the "userId" in response body is "[3-1]"
    And the "updatedByUserId" in response body is "[3-1]"
    And the "reason" in response body is "[Test]"
    And the "operationalUnit" in response body is "[adminrest.sessions/item/get/WEB]"
    And the "accessType" in response body is "[ALLOW]"

    Examples:
      | keys                                 | values                                   |
      | userId,operationalUnit,includeGroups | 3-1,adminrest.sessions/item/get/WEB,true |

  Scenario: Delete Current Session - LogOut
    And I create a Get "cc_csrftokenSpec" header
    When I make a "DEL" call to "DeleteCurrentSession" to service "AccessService"
    Then the API call is successful with status code 204

  @NoRetry
  Scenario Outline: Force Logout Sessions from BO - Negative v1
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "ForceLogoutSessionsV1CC" of service "AccessService" with new playerId
    When I make a "DEL" call to "ForceLogoutSessionsV1CC" to service "AccessService"
    Then the API call is successful with status code 403
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | errorId                 | description                                                  |
      | AUTHENTICATION_REQUIRED | Access not allowed for ou=adminrest.sessions/list/delete/WEB |

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

#  @skipIfNotAzure
  Scenario: Get user's active session - Invalid format of playerId
#    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUserActiveSessionV1" of service "AccessService" with configured parameter "playerIdSessions" "123"
    When I make a "GET" call to "GetUserActiveSessionV1" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "isOnline.arg0"
    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values "123"

#  @skipIfNotAzure
  Scenario: Get user's active session - No active session found
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUserActiveSessionV1" of service "AccessService" with configured parameter "playerIdSessions" "1-123"
    When I make a "GET" call to "GetUserActiveSessionV1" to service "AccessService"
    Then the API call is successful with status code 200
    And the "online" in response body is "false"

  Scenario: Logout Sessions from BO - Invalid format of playerId
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "ForceLogoutSessionsV1CCWithDifferentPlayerId" of service "AccessService" with configured parameter "playerIdSessions" "123"
    When I make a "DEL" call to "ForceLogoutSessionsV1CCWithDifferentPlayerId" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "logoutUser.arg0"
    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values "123"

  Scenario: Logout Sessions from BO - No active session found
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "ForceLogoutSessionsV1CCWithDifferentPlayerId" of service "AccessService" with configured parameter "playerIdSessions" "1-123"
    When I make a "DEL" call to "ForceLogoutSessionsV1CCWithDifferentPlayerId" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "NO_ACTIVE_SESSION_FOUND"
    And the "description" in response body is "No active session found ([Error Id: NO_ACTIVE_SESSION_FOUND])"

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Communication service responds with error 400
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "CommunicationServiceResponse400"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName                    | requiredScenarioState | priority | method | url                                 | status | headers          | body                                                                        |
      | CommunicationServiceResponse400 | Started               | 100      | POST   | /api/communication/rest/v1/messages | 400    | application/json | {\"errorId\": \"BAD_REQUEST\", \"description\": \"This is a bad request!\"} |

  @skipIfNotAzure
  Scenario: Force Logout Sessions from BO - No active session found
#    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "ForceLogoutSessionsV1CC" of service "AccessService" with new playerId
    When I make a "DEL" call to "ForceLogoutSessionsV1CC" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "NO_ACTIVE_SESSION_FOUND"
    And the "description" in response body is "No active session found ([Error Id: NO_ACTIVE_SESSION_FOUND])"

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Communication service responds with error 500
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "CommunicationServiceResponse500"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName                    | requiredScenarioState | priority | method | url                                 | status | headers          | body                                                                                                  |
      | CommunicationServiceResponse500 | Started               | 100      | POST   | /api/communication/rest/v1/messages | 500    | application/json | {\"errorId\": \"COMMUNICATION_SERVICE_ERROR\", \"description\": \"This is a web application error!\"} |

  Scenario: Force Logout Sessions from BO - No active session found
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "ForceLogoutSessionsV1CC" of service "AccessService" with new playerId
    When I make a "DEL" call to "ForceLogoutSessionsV1CC" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "NO_ACTIVE_SESSION_FOUND"
    And the "description" in response body is "No active session found ([Error Id: NO_ACTIVE_SESSION_FOUND])"

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario: Get user's active session - Invalid format of playerId
    Given I login as a "configuredPlayerCc" user
    And I login as a "newPlayerWeb" user
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUserActiveSessionV1" of service "AccessService" with configured parameter "playerIdSessions" "playerId"
    When I make a "GET" call to "GetUserActiveSessionV1" to service "AccessService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario: Force Logout Sessions from BO
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "ForceLogoutSessionsV1CC" of service "AccessService" with new playerId
    When I make a "DEL" call to "ForceLogoutSessionsV1CC" to service "AccessService"
    Then the API call is successful with status code 200
