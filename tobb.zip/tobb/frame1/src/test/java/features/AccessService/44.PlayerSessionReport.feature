@AccessService @skipIfNotAzure
Feature: Player Session Report

  Scenario Outline: Wiremock stub - Wallet balance 404
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "priority" in response body is "100"
    And the "scenarioName" in response body is "WalletBalanceResponse404"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                           | status | body                                                        | headers          |
      | WalletBalanceResponse404 | Started               | 100      | ANY    | /api/wallet/rest/v1/users/.*/accounts/balan.* | 404    | {\"errorId\":\"NOT_FOUND\",\"description\":\"Test error!\"} | application/json |

  Scenario: Get bearer token - Web - Casino
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "CASINO"

  Scenario: Get bearer token - Web - Sportsbook
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "SPORTSBOOK"

  Scenario Outline: Get player session info
    Given I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And I copy the value of the sessionMinuteId from the response
    And the "rows" size in response body is above 0

    Examples:
      | queryType | query                                                                     |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`BGPSESSIONMINUTES` WHERE (USERID = {{playerId}}) ORDER BY SESSIONMINUTEID DESC |

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Wiremock stub - Wallet balance 502
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "priority" in response body is "100"
    And the "scenarioName" in response body is "WalletBalanceResponse502"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                           | status | body                                                                    | headers          |
      | WalletBalanceResponse502 | Started               | 100      | ANY    | /api/wallet/rest/v1/users/.*/accounts/balan.* | 502    | {\"errorId\":\"INTERNAL_SERVER_ERROR\",\"description\":\"Test error!\"} | application/json |

  Scenario: Get bearer token - Web - Casino
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "CASINO"

  Scenario: Get bearer token - Web - Sportsbook
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "SPORTSBOOK"

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Wiremock stub - Wallet Balance - Connection Reset
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "priority" in response body is "100"
    And the "scenarioName" in response body is "WalletBalanceResponseConnRst"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName                 | requiredScenarioState | priority | method | url                                           | status | body | headers |
      | WalletBalanceResponseConnRst | Started               | 100      | ANY    | /api/wallet/rest/v1/users/.*/accounts/balan.* | 201    |      |         |

  Scenario: Get bearer token - Web - Casino
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "CASINO"

  Scenario: Get bearer token - Web - Sportsbook
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "SPORTSBOOK"

  Scenario: Reset Mappings
    Given I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

#    _________________________________________________________________________________________________________________________________________________

  Scenario: Logout player
    And I create a Get "mainspec" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario Outline: Get player session info - ACCSESSIONMINUTEMETADATA
    Given I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And the "rows" size in response body is above 0

    Examples:
      | queryType | query                                                                     |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`ACCSESSIONMINUTEMETADATA` |

  Scenario: Get bearer token - Web - Casino
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "CASINO"

  Scenario: Get bearer token - Web - Sportsbook
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "SPORTSBOOK"

  Scenario Outline: Get player session info - BGPSESSIONMINUTES
    Given I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And I copy the value of the sessionMinuteId from the response
    And the "rows" size in response body is above 0

    Examples:
      | queryType | query                                                                                                                           |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2. `BGPSESSIONMINUTES` WHERE (USERID = {{playerId}}) ORDER BY SESSIONMINUTEID DESC |

  Scenario Outline: Post - Publish a message to access.sessions.notify - Error on sessionMinute metadata command
    Given I create a POST PublishToExchange payload with "<contentType>" "<routingKey>" "<payload>" "<payloadEncoding>"
    And I change url resource of method "PublishToExchange" of service "RabbitMQService" with configured parameter "exchange" "access.session.minute.metadata.failed.dlx"
    When I make a "POST" call to "PublishToExchange" to service "RabbitMQService"
    Then the API call is successful with status code 200


    Examples:
      | contentType      | routingKey                  | payload                                                                                                                                                                                                                                                                                                                                                              | payloadEncoding |
      | application/json | access.session.minute.login | {\"operation\":\"login\",\"sessionId\":\"-DLjQBJxfkJd8BdQUnXz_4cARtgZ43pvgbINintQ8WRY\",\"sessionMinuteId\":\"{{sessionMinuteId}}\",\"userId\":\"1-{{playerId}}\",\"securityDomainName\":\"testSecurityDomainName\",\"channel\":\"WEB\",\"subchannel\":\"testSubChannel\",\"operationDate\":1645715524887,\"domain\":\"casino.opap.gr\",\"gameId\":\"CASINO\",\"apiVersion\":1} | string          |

  Scenario Outline: Get player session info - ACCSESSIONMINUTEMETADATA
    Given I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And the "rows" size in response body is above 0
    And the property "GAMEID" in response body array with index "rows[0]" has value "CASINO"
    And the property "ACCOUNTTYPE" in response body array with index "rows[0]" has value "AT_MAIN"
    And the property "ACCOUNTNUMBER" in response body array with index "rows[0]" has value "2"
    And the property "CURRENCY" in response body array with index "rows[0]" has value "EUR"
    And I copy value of domain and gameId from the response

    Examples:
      | queryType | query                                                                                                   |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`ACCSESSIONMINUTEMETADATA` ORDER BY SESSIONMINUTEID DESC |

  Scenario: Get bearer token - Web - Joker
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "JOKER"

#  Scenario: Get bearer token - Web - PAMESTOIXIMA - Invalid x-gameId
#    Given I login as a "newPlayerWeb" user
#    And I setup gameId header to "PAMESTOIXIMA"

  Scenario: Get bearer token - Web - Casino
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "CASINO"

  Scenario Outline: Get player session info - ACCSESSIONMINUTEMETADATA
    Given I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And the "rows" size in response body is above 0


    Examples:
      | queryType | query                                                                                                   |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`ACCSESSIONMINUTEMETADATA` ORDER BY SESSIONMINUTEID DESC |

  Scenario Outline: Post - Publish a message to access.sessions.notify - Same DB entry already exists
    Given I create a POST PublishToExchange payload with "<contentType>" "<routingKey>" "<payload>" "<payloadEncoding>"
    And I change url resource of method "PublishToExchange" of service "RabbitMQService" with configured parameter "exchange" "access.sessions.notify"
    When I make a "POST" call to "PublishToExchange" to service "RabbitMQService"
    Then the API call is successful with status code 200


    Examples:
      | contentType      | routingKey             | payload                                                                                                                                                                                                                                                                                                                                                                                          | payloadEncoding |
      | application/json | customer.login.success | {\"operation\":\"login\",\"sessionId\":\"D9LGX8DjAz4joVLNHxhe1GUgx0xxUdMnxH8aYNFmpXjD\",\"sessionMinuteId\":\"{{sessionMinuteId}}\",\"userId\":\"1-{{playerId}}\",\"securityDomainName\":\"testSecurityDomainName\",\"channel\":\"MOBILE\",\"subchannel\":\"testSubChannel\",\"operationDate\":1645715524887,\"domain\":\"{{sessionDomain}}\",\"gameId\":\"{{sessionGameId}}\",\"apiVersion\":1} | string          |

  Scenario Outline: Post - Publish a message to access.sessions.notify - Domain is null
    Given I create a POST PublishToExchange payload with "<contentType>" "<routingKey>" "<payload>" "<payloadEncoding>"
    And I change url resource of method "PublishToExchange" of service "RabbitMQService" with configured parameter "exchange" "access.sessions.notify"
    When I make a "POST" call to "PublishToExchange" to service "RabbitMQService"
    Then the API call is successful with status code 200


    Examples:
      | contentType      | routingKey             | payload                                                                                                                                                                                                                                                                                                                                                   | payloadEncoding |
      | application/json | customer.login.success | {\"operation\":\"login\",\"sessionId\":\"D9LGX8DjAz4joVLNHxhe1GUgx0xxUdMnxH8aYNFppXjD\",\"sessionMinuteId\":\"0000\",\"userId\":\"1-{{playerId}}\",\"securityDomainName\":\"testSecurityDomainName\",\"channel\":\"MOBILE\",\"subchannel\":\"testSubChannel\",\"operationDate\":1645715524887,\"domain\":\"null\",\"gameId\":\"CASINO\",\"apiVersion\":1} | string          |

  Scenario Outline: Get player session info - ACCSESSIONMINUTEMETADATA
    Given I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And the "rows" size in response body is above 0
    And the property "rows[0]" includes value "SPORTSBOOK"

    Examples:
      | queryType | query                                                                     |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`ACCSESSIONMINUTEMETADATA` |