@AccessService
Feature: Get Session Time And Modules

  Scenario Outline: Get Modules - Success Scenario
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetModules" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is <objects>
    And I verify get modules response

    @skipIfNotAzure
    Examples:
      | objects |
      | 6       |

    @skipIfAzure
    Examples:
      | objects |
      | 7       |


  #PAGE SIZE TOO BIG DOESN'T FAIL.
  @NoRetry
  Scenario Outline: Get SessionMinutes - Negative Scenarios
    Given I change url resource of method "GetSessionMinutesCC" of service "AccessService" with configured parameter "userGroup" "1"
    And I change url resource of method "GetSessionMinutesCC" of service "AccessService" with new playerId
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetSessionMinutesCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | keys                          | values         | GherkingDescription | statusCode |
      | pagesize,pagenumber,endDate   | 500,10,datenow | Missing StartDate   | 500        |
      | pagesize,pagenumber,startDate | 500,10,datenow | Missing EndDate     | 500        |


  @NoRetry
  Scenario Outline: Get SessionMinutes - Negative Scenarios
    Given I change url resource of method "GetSessionMinutesCC" of service "AccessService" with configured parameter "userGroup" "1"
    And I change url resource of method "GetSessionMinutesCC" of service "AccessService" with new playerId
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetSessionMinutesCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | keys                                  |  | values                      | GherkingDescription | statusCode |
      | pagesize,pagenumber,startDate,endDate |  | 50000,10,2025-02-10,datenow | Page Size Too Big   | 200        |

    #here TODO: configured parameter playerId improvement for replacing step.Scenario: 2-4
  @NoRetry
  Scenario Outline: Get SessionMinutes - Negative Scenarios
    Given I change url resource of method "GetSessionMinutesCC" of service "AccessService" with configured parameter "userGroupPlayerId" "<userGroupPlayerId>"
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetSessionMinutesCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | keys                                  | values                     | userGroupPlayerId | statusCode |
      | pagesize,pagenumber,startDate,endDate | 500,10,2025-02-10,datenow  | 0-0               | 200        |
      | pagesize,pagenumber,startDate,endDate | 500,10,2025-02-10,datenow  | 0-null            | 404        |
      | pagesize,pagenumber,startDate,endDate | 500,10,2025-02-10,datenow  | 0--1              | 200        |
      | pagesize,pagenumber,startDate,endDate | 500,10,2025-02-10,datenow  | 0-test            | 404        |
      | pagesize,pagenumber,startDate,endDate | 5000,10,2025-02-10,datenow | playerId          | 200        |

  Scenario Outline: Get SessionMinutes - Success Scenario
    Given I change url resource of method "GetSessionMinutesCC" of service "AccessService" with configured parameter "userGroup" "1"
    And I change url resource of method "GetSessionMinutesCC" of service "AccessService" with new playerId
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetSessionMinutesCC" to service "AccessService"
    Then the API call is successful with status code 200

    Examples:
      | keys                                  | values                     |
      | pagesize,pagenumber,startDate,endDate | 5000,10,2025-02-10,datenow |

  Scenario: Logout player - Success
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario: Delete Current Session  - Success (CC)
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "DEL" call to "DeleteCurrentSession" to service "AccessService"
    Then the API call is successful with status code 204

  @NoRetry
  Scenario Outline: Get SessionMinutes - Negative Scenario
    Given I change url resource of method "GetSessionMinutesCC" of service "AccessService" with configured parameter "userGroupPlayerId" "<userGroupPlayerId>"
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetSessionMinutesCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access/sessionminutes/get/WEB"

    Examples:
      | keys                                  | values                     | userGroupPlayerId | playerId | statusCode |
      | pagesize,pagenumber,startDate,endDate | 5000,10,2025-02-10,datenow | playerId          | test     | 403        |