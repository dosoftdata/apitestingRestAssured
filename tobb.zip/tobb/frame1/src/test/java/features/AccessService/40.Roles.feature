@AccessService
Feature: Roles


  @skipIfNotAzure @NoRetry
  Scenario Outline: Put AdminRolesV2 - Negative - No Payload
    Given I create a Get "<spec>" header
    And I change url resource of method "AdminRolesV2" of service "AccessService" with configured parameter "adminId" "123"
    When I make a "PUT" call to "AdminRolesV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 500        |


  @skipIfNotAzure @NoRetry
  Scenario Outline: Put AdminRolesV2 - Negative - Empty Payload
    Given I create an empty payload with header "<spec>"
    And I change url resource of method "AdminRolesV2" of service "AccessService" with configured parameter "adminId" "123"
    When I make a "PUT" call to "AdminRolesV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 400        |



    #204 as expected but why 204
  @skipIfNotAzure
  Scenario Outline: Put AdminRolesV2 - Negative - No Role Provided
    Given I create an empty array payload with header "<spec>"
    And I change url resource of method "AdminRolesV2" of service "AccessService" with configured parameter "adminId" "123"
    When I make a "PUT" call to "AdminRolesV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 204        |


  @skipIfNotAzure @NoRetry
  Scenario Outline: Put AdminRolesV2 - Negative - Role Does Not Exist
    Given I create an AdminRolesV2 payload with roleId "<roleId>"
    And I change url resource of method "AdminRolesV2" of service "AccessService" with configured parameter "adminId" "123"
    When I make a "PUT" call to "AdminRolesV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | roleId    | statusCode | errorId      | description                                                                 |
      | testRole1 | 400        | INVALID_ROLE | The specified role 'testRole1' doesn't exist ([Error Id: INVALID_ROLE])     |
      |           | 400        | INVALID_ROLE | The specified role '' doesn't exist ([Error Id: INVALID_ROLE])              |
      | 1         | 400        | INVALID_ROLE | The specified role '1' is not a valid admin role ([Error Id: INVALID_ROLE]) |


    #fix global variable superAdminRoleId
  @skipIfNotAzure
  Scenario Outline: Put AdminRolesV2 - Success - SuperAdminAccessId
    Given I create an AdminRolesV2 payload with roleId "<roleId>"
    And I change url resource of method "AdminRolesV2" of service "AccessService" with configured parameter "adminId" "123"
    When I make a "PUT" call to "AdminRolesV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | roleId             | statusCode |
      | superAdminAccessId | 204        |


  @NoRetry
  Scenario Outline: Get AdminMemberIdsV2 - Incorrect RoleId
    Given I create a Get "<spec>" header
    And I change url resource of method "GetMemberIdsV2" of service "AccessService" with configured parameter "roleId" "test"
    When I make a "GET" call to "GetMemberIdsV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "ROLE_NOT_FOUND"
    And the "description" in response body is "Role does not exist ([Error Id: ROLE_NOT_FOUND])"

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 404        |

  @skipIfNotAzure
  Scenario Outline: Get AdminMemberIdsV2 - SuperAdmin RoleId
    Given I create a Get "<spec>" header
    And I change url resource of method "GetMemberIdsV2" of service "AccessService" with configured parameter "roleId" "superAdminAccessId"
    When I make a "GET" call to "GetMemberIdsV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the response includes value "123"

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 200        |

  @skipIfAzure
  Scenario Outline: Get AdminMemberIdsV2 - SuperAdmin RoleId
    Given I create a Get "<spec>" header
    And I change url resource of method "GetMemberIdsV2" of service "AccessService" with configured parameter "roleId" "superAdminAccessId"
    When I make a "GET" call to "GetMemberIdsV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 200        |



  @skipIfNotAzure @NoRetry
  Scenario Outline: Put RoleIdV2 - Missing body
    Given I create a Get "<spec>" header
    And I change url resource of method "AccessRoleIdV2" of service "AccessService" with configured parameter "roleId" "1"
    When I make a "PUT" call to "AccessRoleIdV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 500        |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Put RoleIdV2 - Missing body
    Given I create an empty payload with header "<spec>"
    And I change url resource of method "AccessRoleIdV2" of service "AccessService" with configured parameter "roleId" "1"
    When I make a "PUT" call to "AccessRoleIdV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "MISSING_MEMBER_ID"
    And the "description" in response body is "Member ID missing ([Error Id: MISSING_MEMBER_ID])"

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 400        |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Put RoleIdV2 - Wrong memberIds
    Given I create a AccessRoleIdV2 payload with "<memberId>"
    And I change url resource of method "AccessRoleIdV2" of service "AccessService" with configured parameter "roleId" "1"
    When I make a "PUT" call to "AccessRoleIdV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | statusCode | memberId | errorId              | description                                                                                                      |
      | 400        | 123      | INVALID_JSON         | Invalid JSON input                                                                                               |
      | 400        | 3-123    | MEMBER_TYPE_MISMATCH | The member type of the role doesn't match that of the role member being added ([Error Id: MEMBER_TYPE_MISMATCH]) |
      | 400        | 1-0      | INVALID_MEMBER_ID    | Member ID invalid ([Error Id: INVALID_MEMBER_ID])                                                                |


  @skipIfNotAzure @NoRetry
  Scenario Outline: Put RoleIdV2 - Wrong roleIds
    Given I create a AccessRoleIdV2 payload with "<memberId>"
    And I change url resource of method "AccessRoleIdV2" of service "AccessService" with configured parameter "roleId" "<urlRoleId>"
    When I make a "PUT" call to "AccessRoleIdV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | urlRoleId   | statusCode | memberId | errorId         | description                                        |
      | thisisatest | 404        | 3-123    | GROUP_NOT_FOUND | Group does not exist ([Error Id: GROUP_NOT_FOUND]) |
      | null        | 404        | 3-123    | GROUP_NOT_FOUND | Group does not exist ([Error Id: GROUP_NOT_FOUND]) |


  @skipIfNotAzure
  Scenario Outline: Put RoleIdV2 - Wrong memberIds
    Given I create a AccessRoleIdV2 payload with "<memberId>"
    And I change url resource of method "AccessRoleIdV2" of service "AccessService" with configured parameter "roleId" "1"
    When I make a "PUT" call to "AccessRoleIdV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "retailerId" in response body is ""
    And the "memberId" in response body is "1-123"
    And the "updatedByUserId" in response body is "0-"
    And the "accessGroupId" in response body is "1"
    And the "accessGroupMemberId" in response body is ""
    # And created and updated is null

    Examples:
      | statusCode | memberId |
      | 200        | 1-123    |


  @skipIfNotAzure @NoRetry
  Scenario: Del MembersV2 - Role Not Found
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "DeleteMembersV2" of service "AccessService" with configured parameter "roleId" "123"
    When I make a "DEL" call to "DeleteMembersV2" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ROLE_NOT_FOUND"
    And the "description" in response body is "Role does not exist ([Error Id: ROLE_NOT_FOUND])"


  @skipIfNotAzure
  Scenario Outline: Put AdminRolesV2 - Success - SuperAdminAccessId
    Given I create an AdminRolesV2 payload with roleId "<roleId>"
    And I change url resource of method "AdminRolesV2" of service "AccessService" with configured parameter "adminId" "newPlayerWeb"
    When I make a "PUT" call to "AdminRolesV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | roleId             | statusCode |
      | superAdminAccessId | 204        |

  @skipIfNotAzure
  Scenario Outline: Get AdminMemberIdsV2 - SuperAdmin RoleId
    Given I create a Get "<spec>" header
    And I change url resource of method "GetMemberIdsV2" of service "AccessService" with configured parameter "roleId" "superAdminAccessId"
    When I make a "GET" call to "GetMemberIdsV2" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the response includes value "123"
    #maybe assertion more

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 200        |

  @skipIfNotAzure
  Scenario: Del MembersV2 - Success
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "DeleteMembersV2" of service "AccessService" with configured parameter "roleId" "1"
    When I make a "DEL" call to "DeleteMembersV2" to service "AccessService"
    Then the API call is successful with status code 204



