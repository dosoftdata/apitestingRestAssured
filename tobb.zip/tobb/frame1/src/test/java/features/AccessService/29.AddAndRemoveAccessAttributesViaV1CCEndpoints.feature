@AccessService
Feature: Add and Remove Access Attributes Via V1 CC Endpoints


  Scenario: Get admin session
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetAdminSession" to service "AdminService"
    Then the API call is successful with status code 200
    And the "loginName" in response body is "admin"
    And the "language" in response body is "en_US"
    And the "email" in response body is "support@novomaticls.com"

  Scenario Outline: Get clerk's accessRoleId
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code 200
    And I copy the value of the ClerkAccessRoleId
    And the "rows" size in response body is above 2
#    And the number of results in a nameless array of objects is <numberOfAdmins>

#  @skipIfNotAzure
#    Examples:
#      | numberOfAdmins |
#      | 5              |
#
#  @skipIfNotIntegration
#    Examples:
#      | numberOfAdmins |
#      | 12             |
#

  @skipIfNotAzure
  Scenario: Put - Assign proper access roles for High Winnings to Clerk
    Given I create a Get "cc_csrftokenSpec" header
    And I create an Assign_Access_Roles_for_Clerk payload
    And I change url resource of method "AllowRoleAccessAttributes" of service "AccessService" with configured parameter "roleId" "clerkAccessRoleId"
    When I make a "PUT" call to "AllowRoleAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario Outline: Delete AccessAttributes - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | keys                   | values                                        |
      | userId,operationalUnit | 3-1,adminrest.access-attributes/item/POST/ALL |

  @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Success
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | accessType | operationalUnit                       | userId | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | ALLOW      | adminrest.access-attributes/item/post | 3-1    |         |         | 3-1             | 0          | Test   | null  | [0]   |              |

  @skipIfNotAzure @NoRetry
  Scenario: Post CustomerAccessAttributesCC - Add an access attribute for customer - Missing body
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PostCustomerAccessAttributes" of service "AccessService" with configured parameter "playerIdCustomers" "3-1"
    When I make a "POST" call to "PostCustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "ACCESS_ATTRIBUTE_DTO_IS_INVALID"
    And the "description" in response body is "The accessAttributeDTO is invalid! ([Error Id: ACCESS_ATTRIBUTE_DTO_IS_INVALID] The accessAttributeDTO is invalid!)"

  @skipIfNotAzure @NoRetry
  Scenario: Post CustomerAccessAttributesCC - Add an access attribute for customer - Invalid data
    Given I create an empty payload with header "cc_csrftokenSpec"
    And I change url resource of method "PostCustomerAccessAttributes" of service "AccessService" with configured parameter "playerIdCustomers" "3-1"
    When I make a "POST" call to "PostCustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

  @skipIfNotAzure @NoRetry
  Scenario Outline: Post CustomerAccessAttributesCC - Add an access attribute for customer - Invalid user
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST CustomerAccessAttributes payload with "<accessType>" "<userType>" "<userId>" "<operationalUnit>" "<validTo>" "<reason>" "<blockHours>"
    And I change url resource of method "PostCustomerAccessAttributes" of service "AccessService" with configured parameter "playerIdCustomers" "3-1"
    When I make a "POST" call to "PostCustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_USER"
    And the "description" in response body is "The user Id specified in the request body must match the path. ([Error Id: INVALID_USER])"

    Examples:
      | accessType | operationalUnit    | userId | userType | reason | validTo | blockHours |
      | 1          | rest.just/for/test | 1      | 3        | test   | null    |            |

  @skipIfNotAzure
  Scenario Outline: Post CustomerAccessAttributesCC - Add an access attribute for customer
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST CustomerAccessAttributes payload with "<accessType>" "<userType>" "<userId>" "<operationalUnit>" "<validTo>" "<reason>" "<blockHours>"
    And I change url resource of method "PostCustomerAccessAttributes" of service "AccessService" with configured parameter "playerIdCustomers" "3"
    When I make a "POST" call to "PostCustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the "accessType" in response body is "1"
    And the "userId" in response body is "3"
    And the "userType" in response body is "1"
    And the "reason" in response body is "test"
    And the "operationalUnit" in response body is "rest.just/for/test"

    Examples:
      | accessType | operationalUnit    | userId | userType | reason | validTo | blockHours |
      | 1          | rest.just/for/test | 3      | 1        | test   | null    |            |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Post CustomerAccessAttributesCC - Add an access attribute for customer - Operational unit already exists
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST CustomerAccessAttributes payload with "<accessType>" "<userType>" "<userId>" "<operationalUnit>" "<validTo>" "<reason>" "<blockHours>"
    And I change url resource of method "PostCustomerAccessAttributes" of service "AccessService" with configured parameter "playerIdCustomers" "3"
    When I make a "POST" call to "PostCustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | accessType | operationalUnit    | userId | userType | reason | validTo | blockHours |
      | 1          | rest.just/for/test | 3      | 1        | test   | null    |            |

  @skipIfNotAzure
  Scenario Outline: Add API AccessAttributes - Success
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | accessType | operationalUnit                             | userId | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | ALLOW      | adminrest.access-attributes/item/delete/ALL | 3-1    |         |         | 3-1             | 0          | Test   | null  | [0]   |              |

  Scenario Outline: Get AccessAttributes - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is <objects>


    @skipIfNotAzure
    Examples:
      | keys                                 | values                      | objects |
      | userId,operationalUnit,includeGroups | 1-3,rest.just/for/test,true | 1       |

    @skipIfAzure
    Examples:
      | keys                                 | values                      | objects |
      | userId,operationalUnit,includeGroups | 1-3,rest.just/for/test,true | 0       |


  @skipIfNotAzure @NoRetry
  Scenario: Delete CustomerAccessAttributes - Operational Unit does not exist
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured parameter "playerIdCustomers" "3"
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured parameter "operationalUnit" "test"
    When I make a "DEL" call to "CustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

  @skipIfNotAzure @NoRetry
  Scenario: Delete CustomerAccessAttributes
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured parameter "playerIdCustomers" "3"
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured parameter "operationalUnit" "rest.just|for|test"
    When I make a "DEL" call to "CustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario Outline: Get AccessAttributes - Success
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                                 | values                      |
      | userId,operationalUnit,includeGroups | 1-3,rest.just/for/test,true |

  @skipIfNotAzure
  Scenario Outline: Add API AccessAttributes - Success
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | accessType | operationalUnit                     | userId | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | ALLOW      | api.access-attributes/list/post/WEB | 3-1    |         |         | 3-1             | 0          | Test   | null  | [0]   |              |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Post CustomerAccessAttributesCC - Add an access attribute for customer - Operational unit cannot be null
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST CustomerAccessAttributes payload with "<accessType>" "<userType>" "<userId>" "<operationalUnit>" "<validTo>" "<reason>" "<blockHours>"
    And I change url resource of method "PostCustomerAccessAttributes" of service "AccessService" with configured parameter "playerIdCustomers" "3"
    When I make a "POST" call to "PostCustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

    Examples:
      | accessType | operationalUnit | userId | userType | reason | validTo | blockHours |
      | 1          | null            | 3      | 1        | test   | null    | 1          |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Post CustomerAccessAttributesCC - Add an access attribute for customer - Date parsing
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST CustomerAccessAttributes payload with "<accessType>" "<userType>" "<userId>" "<operationalUnit>" "<validTo>" "<reason>" "<blockHours>"
    And I change url resource of method "PostCustomerAccessAttributes" of service "AccessService" with configured parameter "playerIdCustomers" "3"
    When I make a "POST" call to "PostCustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

    Examples:
      | accessType | operationalUnit         | userId | userType | reason | validTo | blockHours |
      | 1          | rest.just/another/test2 | 3      | 1        | test   | date    | 1          |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Post CustomerAccessAttributesCC - Add an access attribute for customer
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST CustomerAccessAttributes payload with "<accessType>" "<userType>" "<userId>" "<operationalUnit>" "<validTo>" "<reason>" "<blockHours>"
    And I change url resource of method "PostCustomerAccessAttributes" of service "AccessService" with configured parameter "playerIdCustomers" "3"
    When I make a "POST" call to "PostCustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the "accessType" in response body is "1"
    And the "userId" in response body is "3"
    And the "userType" in response body is "1"
    And the "reason" in response body is "test"
    And the "operationalUnit" in response body is "rest.just/another/test"

    Examples:
      | accessType | operationalUnit        | userId | userType | reason | validTo | blockHours |
      | 1          | rest.just/another/test | 3      | 1        | test   | datenow | 0          |

  @skipIfNotAzure @NoRetry
  Scenario: Delete CustomerAccessAttributes
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured parameter "playerIdCustomers" "3"
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured parameter "operationalUnit" "rest.just|for|test"
    When I make a "DEL" call to "CustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario: Delete Current Session - LogOut
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "DEL" call to "DeleteCurrentSession" to service "AccessService"
    Then the API call is successful with status code 204