@AccessService
Feature: Restrict user from depositing via card and withdrawing via IBAN - Manage access operations via Backoffice


  Scenario Outline: Get access operations V1
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "GET" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of elements in array "deposit" is <deposit>
    And I check that the size of elements in array "buy" is <buy>
    And I check that the size of elements in array "withdraw" is <withdraw>
    And I check that the size of elements in array "payout" is <payout>
#    And I check buy, withdrawals, payout, deposits operations with "<depositAccessType>" "<withdrawAccessType>" "<buyAccessType>"

    @skipIfNotAzure
    Examples:
      | deposit | buy | withdraw | payout | depositAccessType                                           | withdrawAccessType                        | buyAccessType                                         |
      | 11      | 9   | 8        | 1      | ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,ALLOW,ALLOW,DENY,DENY,DENY,DENY,ALLOW,DENY,DENY |

    @skipIfAzure
    Examples:
      | deposit | buy | withdraw | payout | depositAccessType                                           | withdrawAccessType                        | buyAccessType                                         |
      | 11      | 10  | 8        | 1      | ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,ALLOW,ALLOW,DENY,DENY,DENY,DENY,ALLOW,DENY,DENY |

  Scenario Outline: Post - Restrict user from depositing via card and withdrawing via IBAN
    Given I create a Get "cc_csrftokenSpec" header
    And I create a Post RestrictUser payload with "<depositId>" "<depositAccessType>" "<withdrawId>" "<withdrawAccessType>"
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of elements in array "deposit" is <deposit>
    And I check that the size of elements in array "buy" is <buy>
    And I check that the size of elements in array "payout" is <payout>
    And I check that the size of elements in array "withdraw" is <withdraw>

    @skipIfNotAzure
    Examples:
      | depositId | depositAccessType | withdrawId | withdrawAccessType | deposit | buy | payout | withdraw |
      | CARD      | DENY              | IBAN       | DENY               | 11      | 9   | 1      | 8        |

    @skipIfAzure
    Examples:
      | depositId | depositAccessType | withdrawId | withdrawAccessType | deposit | buy | payout | withdraw |
      | CARD      | DENY              | IBAN       | DENY               | 11      | 10  | 1      | 8        |

  Scenario Outline: Get access operations V1
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "GET" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of elements in array "deposit" is <deposit>
    And I check that the size of elements in array "buy" is <buy>
    And I check that the size of elements in array "withdraw" is <withdraw>
    And I check that the size of elements in array "payout" is <payout>
#    And I check buy, withdrawals, payout, deposits operations with "<depositAccessType>" "<withdrawAccessType>" "<buyAccessType>"


    @skipIfNotAzure
    Examples:
      | deposit | buy | withdraw | payout | depositAccessType                                          | withdrawAccessType                       | buyAccessType                                         |
      | 11      | 9   | 8        | 1      | DENY,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,DENY,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,ALLOW,ALLOW,DENY,DENY,DENY,DENY,ALLOW,DENY,DENY |

    @skipIfAzure
    Examples:
      | deposit | buy | withdraw | payout | depositAccessType                                          | withdrawAccessType                       | buyAccessType                                         |
      | 11      | 10  | 8        | 1      | DENY,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,DENY,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,ALLOW,ALLOW,DENY,DENY,DENY,DENY,ALLOW,DENY,DENY |

  Scenario: Get access operations V2
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AccessOperationsV2" of service "WalletService" with new playerId
    Then I make a "GET" call to "AccessOperationsV2" to service "WalletService"
    Then the API call is successful with status code 200
    And I check EP, NEP wallets

  @NoRetry
  Scenario Outline: Deposit via Card - User cannot deposit via card - Negative scenario
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 403
    And the "errorId" in response body is "PAYMENT_ACCESS_REJECTED"
    And the "description" in response body is "User cannot deposit."

    Examples:
      | amount |
      | 20     |

  Scenario Outline: Withdrawal via IBAN - Header X-GameId is missing
    Given I create a Post Withdrawal without X-GameId via "<viaMethod>" payload with <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "ValidWithdrawalViaCardOrIBAN" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "ACCOUNT_NOT_DEFINED"
    And the "description" in response body is "No account was found matching the specified product."

    Examples:
      | amount    | action | operation         | paymentMethodType | viaMethod |
      | 999999999 | COMMIT | WALLET_WITHDRAWAL | BANK_ACCOUNT      | IBAN      |

  Scenario Outline: Withdrawal via IBAN - User cannot withdraw via IBAN
    Given I setup gameId header to "JOKER"
    When I create a Post Withdrawal via "<viaMethod>" payload with <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "ValidWithdrawalViaCardOrIBAN" to service "WalletService"
    Then the API call is successful with status code 403
    And the "errorId" in response body is "PAYMENT_ACCESS_REJECTED"
    And the "description" in response body is "User cannot withdraw."

    Examples:
      | amount | action | operation         | paymentMethodType | viaMethod |
      | 20     | COMMIT | WALLET_WITHDRAWAL | BANK_ACCOUNT      | IBAN      |

  Scenario Outline: Post - Restrict user from depositing via card and withdrawing via IBAN
    Given I create a Get "cc_csrftokenSpec" header
    And I create a Post RestrictUser payload with "<depositId>" "<depositAccessType>" "<withdrawId>" "<withdrawAccessType>"
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of elements in array "deposit" is <deposit>
    And I check that the size of elements in array "buy" is <buy>
    And I check that the size of elements in array "payout" is <payout>
    And I check that the size of elements in array "withdraw" is <withdraw>

    @skipIfNotAzure
    Examples:
      | depositId | depositAccessType | withdrawId | withdrawAccessType | deposit | buy | payout | withdraw |
      | CARD      | DENY              | IBAN       | DENY               | 11      | 9   | 1      | 8        |

    @skipIfAzure
    Examples:
      | depositId | depositAccessType | withdrawId | withdrawAccessType | deposit | buy | payout | withdraw |
      | CARD      | DENY              | IBAN       | DENY               | 11      | 10  | 1      | 8        |

  Scenario Outline: Get access operations V1
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "GET" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of elements in array "deposit" is <deposit>
    And I check that the size of elements in array "buy" is <buy>
    And I check that the size of elements in array "withdraw" is <withdraw>
    And I check that the size of elements in array "payout" is <payout>
#    And I check buy, withdrawals, payout, deposits operations with "<depositAccessType>" "<withdrawAccessType>" "<buyAccessType>"

    @skipIfNotAzure
    Examples:
      | deposit | buy | withdraw | payout | depositAccessType                                          | withdrawAccessType                       | buyAccessType                                         |
      | 11      | 9   | 8        | 1      | DENY,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,DENY,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,ALLOW,ALLOW,DENY,DENY,DENY,DENY,ALLOW,DENY,DENY |

    @skipIfAzure
    Examples:
      | deposit | buy | withdraw | payout | depositAccessType                                          | withdrawAccessType                       | buyAccessType                                         |
      | 11      | 10  | 8        | 1      | DENY,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,DENY,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,ALLOW,ALLOW,DENY,DENY,DENY,DENY,ALLOW,DENY,DENY |

  Scenario: Get access operations V2
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AccessOperationsV2" of service "WalletService" with new playerId
    Then I make a "GET" call to "AccessOperationsV2" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I check EP, NEP wallets
