@AccessService
Feature: Session

  @NoRetry
  Scenario Outline: Get Session - Missing userId
    Given I login as an Api user
    And I create a Get "<spec>" header
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "PARAMETER_REQUIRED"
    And the "description" in response body is "Parameter userId is required ([Error Id: PARAMETER_REQUIRED])"

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 400        |

  Scenario Outline: Get Session
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I check that the size of elements in array "data" is 0

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  Scenario Outline: Get Session - Invalid securityDomainName
    Given I login as a "newPlayerWeb" user
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I check that the size of elements in array "data" is 0

    Examples:
      | spec                  | statusCode | keys                      | values        |
      | api_mainSpec_mainHost | 200        | userId,securityDomainName | changeit,test |

  Scenario Outline: Get Session - Invalid terminalId
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
#    And I check that the size of elements in array "data" is 0

    Examples:
      | spec                  | statusCode | keys             | values        |
      | api_mainSpec_mainHost | 200        | userId,termnalId | changeit,test |

  Scenario Outline: Get Session
    Given I login as an Api user
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionId from the response
    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is "[]"
    And the "operatorId" in response body is "[]"
    And the "retailerId" in response body is "[]"
    And the "terminalId" in response body is "[]"
    And the "subchannel" in response body is "[]"
    And the "originServer" in response body is "[]"
    And the "credentialDomain" in response body is "[password]"
    And the "inactiveTimeoutMinutes" in response body is "[5]"
    And the "channel" in response body is "[WEB]"
#    And I verify the 1-playerId is the field "userId" in the response body

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  @NoRetry
  Scenario Outline: Get Session - Session not found
    Given I create a Get "<spec>" header
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "test"
    When I make a "GET" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "SESSION_NOT_FOUND"
    And the "description" in response body is "Session not found with sessionId test ([Error Id: SESSION_NOT_FOUND])"

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 404        |

  Scenario Outline: Get specific Session
    Given I create a Get "<spec>" header
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "accessSessionId"
    When I make a "GET" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionLastAccessedTime from the response
#    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is ""
    And the "operatorId" in response body is ""
    And the "retailerId" in response body is ""
    And the "terminalId" in response body is ""
    And the "subchannel" in response body is ""
    And the "originServer" in response body is ""
    And the "credentialDomain" in response body is "password"
    And the "inactiveTimeoutMinutes" in response body is "5"
    And the "channel" in response body is "WEB"
#    And I verify the 1-playerId is the field "userId" in the response body

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 200        |

  @NoRetry
  Scenario Outline: Post SessionAccess - Update the last accessed time of a specific session - Session not found
    Given I create a Get "<spec>" header
    And I change url resource of method "SessionAccess" of service "AccessService" with configured parameter "playerIdSessions" "<sessionId>"
    When I make a "POST" call to "SessionAccess" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "SESSION_NOT_FOUND"
    And the "description" in response body is "Session not found with sessionId test ([Error Id: SESSION_NOT_FOUND])"

    Examples:
      | spec                  | statusCode | sessionId |
      | api_mainSpec_mainHost | 404        | test      |

  Scenario Outline: Post SessionAccess - Update the last accessed time of a specific session
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionAccess" of service "AccessService" with configured parameter "playerIdSessions" "accessSessionId"
    When I make a "POST" call to "SessionAccess" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode | keys    | values |
      | api_mainSpec_mainHost | 204        | ignored | true   |

  Scenario Outline: Get specific Session - Verify lastAccessed is updated with new timestamp
    Given I create a Get "<spec>" header
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "accessSessionId"
    When I make a "GET" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionLastAccessedTime from the response
#    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is ""
    And the "operatorId" in response body is ""
    And the "retailerId" in response body is ""
    And the "terminalId" in response body is ""
    And the "subchannel" in response body is ""
    And the "originServer" in response body is ""
    And the "credentialDomain" in response body is "password"
    And the "inactiveTimeoutMinutes" in response body is "5"
    And the "channel" in response body is "WEB"
#    And I verify the 1-playerId is the field "userId" in the response body
    And I verify the sessionId is the field "sessionId" in the response body

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 200        |

  @NoRetry
  Scenario Outline: Post SessionAccess - Update the last accessed time of a specific session - Session not found
    Given I create a Get "<spec>" header
    And I change url resource of method "SessionAccess" of service "AccessService" with configured parameter "playerIdSessions" "<sessionId>"
    When I make a "POST" call to "SessionAccess" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.sessions/access/post/WEB"

    Examples:
      | spec                  | statusCode | sessionId |
      | api_mainSpec_mainHost | 403        | current   |

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario Outline: Post SessionAccess - Update the last accessed time of a specific session - User is logged out
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionAccess" of service "AccessService" with configured parameter "playerIdSessions" "accessSessionId"
    When I make a "POST" call to "SessionAccess" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "SESSION_NOT_FOUND"
    And the property "description" includes value "([Error Id: SESSION_NOT_FOUND])"


    Examples:
      | spec                  | statusCode | keys    | values |
      | api_mainSpec_mainHost | 404        | ignored | true   |

#    -------------------------------------------------------------------------------------------------------------

  Scenario Outline: Get Session
    Given I login as a "newPlayerWeb" user
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionId from the response
    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is "[]"
    And the "operatorId" in response body is "[]"
    And the "retailerId" in response body is "[]"
    And the "terminalId" in response body is "[]"
    And the "subchannel" in response body is "[]"
    And the "originServer" in response body is "[]"
    And the "credentialDomain" in response body is "[password]"
    And the "inactiveTimeoutMinutes" in response body is "[5]"
    And the "channel" in response body is "[WEB]"
#    And I verify the 1-playerId is the field "userId" in the response body

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  @NoRetry
  Scenario Outline: Del specific session - Missing logoutMethod
    Given I create a Get "<spec>" header
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdTest" "test"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "PARAMETER_REQUIRED"
    And the "description" in response body is "Parameter logoutMethod is required ([Error Id: PARAMETER_REQUIRED])"

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 400        |

  @NoRetry
  Scenario Outline: Del specific session - Invalid sessionId
    Given I create a Get "<spec>" header
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "<parameter>" "<value>"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode | keys         | values          | parameter        | value |
      | api_mainSpec_mainHost | 204        | logoutMethod | LOGOUT_SELECTED | playerIdSessions | test  |

  @NoRetry
  Scenario Outline: Del specific session - method logoutSelected
    Given I create a Get "<spec>" header
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "accessSessionId"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode | keys         | values          |
      | api_mainSpec_mainHost | 204        | logoutMethod | LOGOUT_SELECTED |

  Scenario Outline: Get Session - Already logged out
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I check that the size of elements in array "data" is 0

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  Scenario Outline: Get Session
    Given I login as a "newPlayerWeb" user
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionId from the response
    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is "[]"
    And the "operatorId" in response body is "[]"
    And the "retailerId" in response body is "[]"
    And the "terminalId" in response body is "[]"
    And the "subchannel" in response body is "[]"
    And the "originServer" in response body is "[]"
    And the "credentialDomain" in response body is "[password]"
    And the "inactiveTimeoutMinutes" in response body is "[5]"
    And the "channel" in response body is "[WEB]"
#    And I verify the 1-playerId is the field "userId" in the response body

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  @NoRetry
  Scenario Outline: Del specific session - method INACTIVE_TIMEOUT
    Given I create a Get "<spec>" header
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "accessSessionId"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode | keys         | values           |
      | api_mainSpec_mainHost | 204        | logoutMethod | INACTIVE_TIMEOUT |

  Scenario Outline: Get Session - Already logged out
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I check that the size of elements in array "data" is 0

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  Scenario Outline: Get Session
    Given I login as a "newPlayerWeb" user
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionId from the response
    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is "[]"
    And the "operatorId" in response body is "[]"
    And the "retailerId" in response body is "[]"
    And the "terminalId" in response body is "[]"
    And the "subchannel" in response body is "[]"
    And the "originServer" in response body is "[]"
    And the "credentialDomain" in response body is "[password]"
    And the "inactiveTimeoutMinutes" in response body is "[5]"
    And the "channel" in response body is "[WEB]"
#    And I verify the 1-playerId is the field "userId" in the response body

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  @NoRetry
  Scenario Outline: Del specific session - method SESSION_TIMEOUT
    Given I create a Get "<spec>" header
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "accessSessionId"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode | keys         | values          |
      | api_mainSpec_mainHost | 204        | logoutMethod | SESSION_TIMEOUT |

  Scenario Outline: Get Session - Already logged out
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I check that the size of elements in array "data" is 0

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  Scenario Outline: Get Session
    Given I login as a "newPlayerWeb" user
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionId from the response
    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is "[]"
    And the "operatorId" in response body is "[]"
    And the "retailerId" in response body is "[]"
    And the "terminalId" in response body is "[]"
    And the "subchannel" in response body is "[]"
    And the "originServer" in response body is "[]"
    And the "credentialDomain" in response body is "[password]"
    And the "inactiveTimeoutMinutes" in response body is "[5]"
    And the "channel" in response body is "[WEB]"
#    And I verify the 1-playerId is the field "userId" in the response body

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  @NoRetry
  Scenario Outline: Del specific session - method RELOGIN
    Given I create a Get "<spec>" header
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "accessSessionId"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode | keys                | values       |
      | api_mainSpec_mainHost | 204        | logoutMethod,reason | RELOGIN,test |

  Scenario Outline: Get Session - Already logged out
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I check that the size of elements in array "data" is 0

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  Scenario Outline: Get Session
    Given I login as a "newPlayerWeb" user
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionId from the response
    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is "[]"
    And the "operatorId" in response body is "[]"
    And the "retailerId" in response body is "[]"
    And the "terminalId" in response body is "[]"
    And the "subchannel" in response body is "[]"
    And the "originServer" in response body is "[]"
    And the "credentialDomain" in response body is "[password]"
    And the "inactiveTimeoutMinutes" in response body is "[5]"
    And the "channel" in response body is "[WEB]"
#    And I verify the 1-playerId is the field "userId" in the response body

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  @NoRetry
  Scenario Outline: Del specific session - method FORCED
    Given I create a Get "<spec>" header
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "accessSessionId"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode | keys                | values      |
      | api_mainSpec_mainHost | 204        | logoutMethod,reason | FORCED,test |

  Scenario Outline: Get Session - Already logged out
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I check that the size of elements in array "data" is 0

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

#   --------------------------------------------------------------------------------------------------------------

  Scenario Outline: Get Session
    Given I login as a "newPlayerWeb" user
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionId from the response
    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is "[]"
    And the "operatorId" in response body is "[]"
    And the "retailerId" in response body is "[]"
    And the "terminalId" in response body is "[]"
    And the "subchannel" in response body is "[]"
    And the "originServer" in response body is "[]"
    And the "credentialDomain" in response body is "[password]"
    And the "inactiveTimeoutMinutes" in response body is "[5]"
    And the "channel" in response body is "[WEB]"
#    And I verify the 1-playerId is the field "userId" in the response body

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  @NoRetry
  Scenario Outline: Del user's session - Missing userId or retailerId
    Given I create a Get "<spec>" header
    When I make a "DEL" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | spec                  | statusCode | errorId            | description                                                                    |
      | api_mainSpec_mainHost | 400        | PARAMETER_REQUIRED | Either userId or retailerId must be specified ([Error Id: PARAMETER_REQUIRED]) |

  @NoRetry
  Scenario Outline: Del user's session - Invalid parameters
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "DEL" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "PARAMETER_INVALID"
    And the "description" in response body is "Either userId or retailerId must be specified (but not both) ([Error Id: PARAMETER_INVALID])"

    Examples:
      | spec                  | statusCode | keys              | values             |
      | api_mainSpec_mainHost | 400        | userId,retailerId | 1-123,testRetailer |

  @NoRetry
  Scenario Outline: Del user's session - Missing logoutMethod
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "DEL" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "PARAMETER_REQUIRED"
    And the "description" in response body is "Parameter logoutMethod is required ([Error Id: PARAMETER_REQUIRED])"

    Examples:
      | spec                  | statusCode | keys       | values       |
      | api_mainSpec_mainHost | 400        | retailerId | testRetailer |

  @NoRetry
  Scenario Outline: Del user's session - Invalid retailerId length
    And I create a Get "<spec>" header
    When I make a "DEL" call to "SessionsInvalidRetailerLength" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "PARAMETER_LENGTH_EXCEEDED"
    And the "description" in response body is "A maximum of 100 retailerId values can be specified ([Error Id: PARAMETER_LENGTH_EXCEEDED])"

    Examples:
      | spec                  | statusCode |  |  |
      | api_mainSpec_mainHost | 400        |  |  |

  @NoRetry
  Scenario Outline: Del user's session - Retailer does not exist
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "DEL" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | spec                  | statusCode | keys                    | values                            |
      | api_mainSpec_mainHost | 500        | logoutMethod,retailerId | SESSION_TIMEOUT,superTestRetailer |

  @NoRetry
  Scenario Outline: Del user's session - Security domain does not match
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "DEL" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode | keys                                          | values                                    |
      | api_mainSpec_mainHost | 204        | userId,securityDomainName,logoutMethod,reason | changeit,testDomain,INACTIVE_TIMEOUT,test |

  @NoRetry
  Scenario Outline: Get Session - Missing userId
    Given I login as an Api user
    And I create a Get "<spec>" header
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "PARAMETER_REQUIRED"
    And the "description" in response body is "Parameter userId is required ([Error Id: PARAMETER_REQUIRED])"

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 400        |

  Scenario Outline: Get Session
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is "[]"
    And the "operatorId" in response body is "[]"
    And the "retailerId" in response body is "[]"
    And the "terminalId" in response body is "[]"
    And the "subchannel" in response body is "[]"
    And the "originServer" in response body is "[]"
    And the "credentialDomain" in response body is "[password]"
    And the "inactiveTimeoutMinutes" in response body is "[5]"
    And the "channel" in response body is "[WEB]"

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  @NoRetry
  Scenario Outline: Del user's session - Security domain does not match
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "DEL" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode | keys                                          | values                                    |
      | api_mainSpec_mainHost | 204        | userId,securityDomainName,logoutMethod,reason | changeit,testDomain,INACTIVE_TIMEOUT,test |

  @NoRetry
  Scenario Outline: Del user's session - Security domain does not match
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "DEL" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode | keys                       | values                         |
      | api_mainSpec_mainHost | 204        | userId,logoutMethod,reason | changeit,INACTIVE_TIMEOUT,test |

  Scenario Outline: Get Session - Already logged out
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I check that the size of elements in array "data" is 0

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

#    --------------------------------------------------------------------------------------------------------------
  Scenario Outline: Get Session
    Given I login as a "newPlayerWeb" user
    And I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionId from the response
    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is "[]"
    And the "operatorId" in response body is "[]"
    And the "retailerId" in response body is "[]"
    And the "terminalId" in response body is "[]"
    And the "subchannel" in response body is "[]"
    And the "originServer" in response body is "[]"
    And the "credentialDomain" in response body is "[password]"
    And the "inactiveTimeoutMinutes" in response body is "[5]"
    And the "channel" in response body is "[WEB]"
#    And I verify the 1-playerId is the field "userId" in the response body

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  @NoRetry
  Scenario Outline: Del current session - Missing logoutMethod
    Given I create a Get "<spec>" header
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "current"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "PARAMETER_REQUIRED"
    And the "description" in response body is "Parameter logoutMethod is required ([Error Id: PARAMETER_REQUIRED])"

    Examples:
      | spec                  | statusCode |
      | api_mainSpec_mainHost | 400        |

  @NoRetry
  Scenario Outline: Del user's session - Invalid request (HTTP Authorization header - Second part)
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "current"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.sessions/item/delete/WEB"

    Examples:
      | spec                           | statusCode | keys         | values           |
      | api_incorrectAuthorizationSpec | 401        | logoutMethod | INACTIVE_TIMEOUT |

  @NoRetry
  Scenario Outline: Del user's session - Invalid request (HTTP Authorization header - First part)
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "current"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.sessions/item/delete/WEB"

    Examples:
      | spec                                    | statusCode | keys         | values           |
      | api_incorrectAuthorizationSpecFirstPart | 401        | logoutMethod | INACTIVE_TIMEOUT |

  @NoRetry
  Scenario Outline: Del user's session - Invalid request (HTTP Authorization header - both parts)
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "current"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "CALLER_AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=api.sessions/item/delete/WEB"

    Examples:
      | spec                                    | statusCode | keys         | values           |
      | api_incorrectAuthorizationSpecBothParts | 401        | logoutMethod | INACTIVE_TIMEOUT |

  Scenario Outline: Get Session
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionId from the response
    And I check that the size of elements in array "data" is 1
    And the "securityDomainName" in response body is "[]"
    And the "operatorId" in response body is "[]"
    And the "retailerId" in response body is "[]"
    And the "terminalId" in response body is "[]"
    And the "subchannel" in response body is "[]"
    And the "originServer" in response body is "[]"
    And the "credentialDomain" in response body is "[password]"
    And the "inactiveTimeoutMinutes" in response body is "[5]"
    And the "channel" in response body is "[WEB]"
#    And I verify the 1-playerId is the field "userId" in the response body

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |

  @NoRetry
  Scenario Outline: Del current session - session is null
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    And I change url resource of method "SessionId" of service "AccessService" with configured parameter "playerIdSessions" "current"
    When I make a "DEL" call to "SessionId" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                  | statusCode | keys         | values |
      | api_mainSpec_mainHost | 204        | logoutMethod | FORCED |

  Scenario Outline: Get Session - Already logged out
    Given I create a Get "<spec>" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Sessions" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the sessionId from the response

    Examples:
      | spec                  | statusCode | keys   | values   |
      | api_mainSpec_mainHost | 200        | userId | changeit |
