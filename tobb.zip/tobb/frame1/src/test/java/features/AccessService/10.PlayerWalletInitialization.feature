@AccessService
Feature: Player Wallet Initialization

  Scenario Outline: Login New missing data
    Given I create a POST LoginNew payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "<errorProperty1>" in response body is "<errorId>"
    And the "<errorProperty2>" in response body is "<errorDescription>"

    Examples:
      | username   | password | group | channel | statusCode | errorProperty1 | errorProperty2    | errorId               | errorDescription                                               |
      |            |          | EP    |         | 400        | error          | error_description | invalid_request       | Invalid request                                                |
      | idontexist | testtest | EP    | WEB     | 400        | errorId        | error_description | INVALID_USER_PASSWORD | Invalid username/password. ([Error Id: INVALID_USER_PASSWORD]) |


  Scenario Outline: Login New success scenario
    Given I create a POST LoginNew payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | username     | password     | group | channel | statusCode |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | 200        |


  Scenario Outline: Valid deposit payment code  - Exclusive Games
    When I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_EXCLUSIVE"
    And the "amount.amount" in response body is "20.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 20     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  Scenario Outline: Valid deposit payment code   - Non Exclusive Games
    Given I login as an Api user
    When I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
    And the "amount.amount" in response body is "20.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 20     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |


  Scenario Outline: Get and Verify - Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 20.0     | 20.0         | 20.0                    | 0.0              | 0.0                  | 20.0     | 20.0         | 20.0                    | 0.0              | 0.0                  |


    #Comment: Azure has not set bonus to 10
  Scenario Outline: Get and Verify - Wallet Bonus Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBonusBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBonusBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the "amount" in response body is "<amount>"
    And the "currency" in response body is "EUR"

    @skipIfAzure
    Examples:
      | amount |
      | 10.0   |

    @skipIfNotAzure
    Examples:
      | amount |
      | 0.0    |


  Scenario Outline: Manual adjustment for Deposit in Lottery wallet via BO
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Lottery wallet"
    When I change url resource of method "ManualAdjustLotteryWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustLotteryWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "operation" in response body is "<operation>"
    And the "amount" in response body is "<amount>"

    Examples:
      | transactionType  | transactionSubType | productId | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | JOKER     | DEPOSIT   | 500.0  |

  Scenario Outline: Get and Verify - Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 520.0    | 520.0        | 20.0                    | 0.0              | 500.0                | 20.0     | 20.0         | 20.0                    | 0.0              | 0.0                  |


  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"
    And the "amount" in response body is "500.0"

    Examples:
      | transactionType  | transactionSubType | productId | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | CASINO    | DEPOSIT   | 500    |


  Scenario Outline: Get and Verify - Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 520.0    | 520.0        | 20.0                    | 0.0              | 500.0                | 520.0    | 520.0        | 20.0                    | 0.0              | 500.0                |


  Scenario Outline: Valid deposit payment code   - Non Exclusive Games
    Given I login as an Api user
    When I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
    And the "amount.amount" in response body is "20.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 20     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  Scenario Outline: Manual adjustment for Deposit in Legacy wallet via BO - Negative scenario
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Legacy wallet"
    When I change url resource of method "ManuallyAdjustLegacyWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManuallyAdjustLegacyWallet" to service "WalletService"
    Then the API call is successful with status code 400
    And the "description" in response body is "The specified productId is not supported for this accountId ([Error Id: INVALID_PRODUCT])"
    And the "errorId" in response body is "INVALID_PRODUCT"


    Examples:
      | transactionType  | transactionSubType | productId | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | KINO      | DEPOSIT   | 1      |