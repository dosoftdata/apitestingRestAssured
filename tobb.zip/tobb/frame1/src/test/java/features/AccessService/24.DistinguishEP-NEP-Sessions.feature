@AccessService @skipIfNotAzure
Feature: Distinguish EP-NEP Sessions

  Scenario Outline: Get user's session group - SELECT Query in BGPSESSIONS
    Given I login as a "newPlayerWeb" user
    And I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And the property "SESSIONGROUP" in response body array with index "rows[0]" has value "EP"

    Examples:
      | queryType | query                                                                                                                 |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`BGPSESSIONS` WHERE USERID = '{{playerId}}' ORDER BY LASTACCESSED DESC |


  Scenario Outline: Get user's session group - SELECT Query in BGPSESSIONS 2
    Given I login as a "newPlayerWeb" user
    And I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And the property "SESSIONGROUP" in response body array with index "rows[0]" has value "EP"

    Examples:
      | queryType | query                                                                                                                 |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`BGPSESSIONS` WHERE USERID = '{{playerId}}' ORDER BY LASTACCESSED DESC |


  Scenario Outline: LoginNew NEP
    Given I create a POST LoginNew payload with "<username>" "<password>" "<group>" "<channel>"
    And I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code 200

    Examples:
      | username     | password     | group | channel |
      | newPlayerWeb | Qwerty12345! | NEP   | WEB     |

  Scenario Outline: Get user's session group - SELECT Query in BGPSESSIONS
    Given I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And the property "SESSIONGROUP" in response body array with index "rows[0]" has value "NEP"

    Examples:
      | queryType | query                                                                                                                 |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`BGPSESSIONS` WHERE USERID = '{{playerId}}' ORDER BY LASTACCESSED DESC |


  Scenario Outline: LoginNew Negative Scenarios
    Given I create a POST LoginNew payload with "<username>" "<password>" "<group>" "<channel>"
    And I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_GROUP"
    And the "description" in response body is "<description>"

    Examples:
      | username     | password     | group | channel | description                               |
      | newPlayerWeb | Qwerty12345! | Test  | WEB     | Session group Test does not exist         |
      | newPlayerWeb | Qwerty12345! |       | WEB     | Session group is missing from the request |

  Scenario Outline: Get user's session group - SELECT Query in BGPSESSIONS
    Given I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And the property "SESSIONGROUP" in response body array with index "rows[0]" has value "NEP"

    Examples:
      | queryType | query                                                                                                                 |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`BGPSESSIONS` WHERE USERID = '{{playerId}}' ORDER BY LASTACCESSED DESC |

  Scenario: Get Previous Login Times 1
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetPreviousLoginTimes" of service "AccessService" with new playerId
    When I make a "GET" call to "GetPreviousLoginTimes" to service "AccessService"
    Then the API call is successful with status code 200
    And the "loginTime" to include today's date

#bug -- https://opapgr.atlassian.net/issues/PAM-21294?filter=-2&jql=reporter%20%3D%20currentUser%28%29%20order%20by%20status%20ASC%2C%20created%20DESC
  Scenario Outline: Get User Sessions 1
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUserSessions" of service "AccessService" with new playerId
    When I make a "GET" call to "GetUserSessions" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify for group "NEP" the fields <NEPwebActive> <NEPwebRememberMeActive> <NEPwebRememberMeTotal> for Get User Session
    And I verify for group "EP" the fields <EPwebActive> <EPwebRememberMeActive> <EPwebRememberMeTotal> for Get User Session

    Examples:
      | NEPwebActive | NEPwebRememberMeActive | NEPwebRememberMeTotal | EPwebActive | EPwebRememberMeActive | EPwebRememberMeTotal |
      | 1            | 0                      | 0                     | 2           | 0                     | 2                    |

  Scenario: Force Logout Sessions CC - Success v1
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "ForceLogoutSessionsV1CC" of service "AccessService" with new playerId
    When I make a "DEL" call to "ForceLogoutSessionsV1CC" to service "AccessService"
    Then the API call is successful with status code 200
    Then the "sessions[0]" in response body has value not null

  Scenario Outline: Force Logout Sessions CC - Negative v1
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "ForceLogoutSessionsV1CC" of service "AccessService" with new playerId
    When I make a "DEL" call to "ForceLogoutSessionsV1CC" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | errorId                 | description                                                   |
      | NO_ACTIVE_SESSION_FOUND | No active session found ([Error Id: NO_ACTIVE_SESSION_FOUND]) |

  Scenario Outline: Force Logout Sessions CC - Negative v2
    Given I create a DEL ForceLogoutCC payload with "<reason>" "<group>"
    And I change url resource of method "ForceLogoutSessionsV2CC" of service "AccessService" with new playerId
    When I make a "DEL" call to "ForceLogoutSessionsV2CC" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | errorId                 | description                                                   | reason | group |
      | NO_ACTIVE_SESSION_FOUND | No active session found ([Error Id: NO_ACTIVE_SESSION_FOUND]) |        |       |
      | NO_ACTIVE_SESSION_FOUND | No active session found ([Error Id: NO_ACTIVE_SESSION_FOUND]) | FRAUD  | NEP   |


  Scenario Outline: Get User Sessions - 0 EP/NEP Sessions left
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUserSessions" of service "AccessService" with new playerId
    When I make a "GET" call to "GetUserSessions" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify for group "NEP" the fields <NEPwebActive> <NEPwebRememberMeActive> <NEPwebRememberMeTotal> for Get User Session
    And I verify for group "EP" the fields <EPwebActive> <EPwebRememberMeActive> <EPwebRememberMeTotal> for Get User Session

    Examples:
      | NEPwebActive | NEPwebRememberMeActive | NEPwebRememberMeTotal | EPwebActive | EPwebRememberMeActive | EPwebRememberMeTotal |
      | 0            | 0                      | 0                     | 0           | 0                     | 0                    |