@AccessService
Feature: Geo-blocking

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @NoRetry
  Scenario: Get SessionWeb Negative
    And I create a Get "mainSpec" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code 401

  @NoRetry
  Scenario Outline: Login New - Negative - xSourceAllow false
    Given I create a POST LoginNew GeoBlocking with allow <xSourceAllow> and payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<errorDescription>"

    Examples:
      | username     | password     | group | channel | statusCode | xSourceAllow | errorId   | errorDescription                     |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | 403        | false        | GEO_BLOCK | Access is blocked from your location |

  @NoRetry
  Scenario: Get SessionWeb Negative
    And I create a Get "mainSpec" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code 401

  Scenario Outline: Login New - Negative - xSourceAllow true - random player
    Given I create a POST LoginNew GeoBlocking with allow <xSourceAllow> and payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "error_description" in response body is "<errorDescription>"

    Examples:
      | username | password     | group | channel | statusCode | xSourceAllow | errorId               | errorDescription                                               |
      | shalala1 | Qwerty12345! | EP    | WEB     | 400        | true         | INVALID_USER_PASSWORD | Invalid username/password. ([Error Id: INVALID_USER_PASSWORD]) |


  @NoRetry
  Scenario: Get SessionWeb Negative
    And I create a Get "mainSpec" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code 401

  Scenario Outline: Login New - Success - xSourceAllow true - New player
    Given I create a POST LoginNew GeoBlocking with allow <xSourceAllow> and payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | username     | password     | group | channel | statusCode | xSourceAllow |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | 200        | true         |

  Scenario: Get SessionWeb Success -
    And I create a Get "mainSpec" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code 200

  @NoRetry
  Scenario Outline: Login New - Negative - xSourceAllow false
    Given I create a POST LoginNew GeoBlocking with allow <xSourceAllow> and payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<errorDescription>"

    Examples:
      | username     | password     | group | channel | statusCode | xSourceAllow | errorId   | errorDescription                     |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | 403        | false        | GEO_BLOCK | Access is blocked from your location |

  @NoRetry
  Scenario: Get SessionWeb Negative
    And I create a Get "mainSpec" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code 401

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario Outline: Get AccessAttributes - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                                 | values                         |
      | userId,operationalUnit,includeGroups | changeit,rest.geo/access/,true |

###AZURE ONLY###########################################################################################

  @skipIfNotAzure
  Scenario Outline: Add AccessAttributes - Success
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnitResponse>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    #custom manipulation of playerId inside.
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | accessType | operationalUnit     | userId       | created | updated | updatedByUserId | operatorId | reason           | valid | index | operationalUnitResponse | notifyStatus |
      | ALLOW      | rest.geo/access/ALL | newPlayerWeb |         |         | newPlayerWeb    | 0          | Geolocation Test | null  | [0]   | rest.geo/access/        |              |

  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Success 2
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "operationalUnit" in response body array with index "<index>" has value "rest.geo/access/"
    And the property "accessType" in response body array with index "<index>" has value "ALLOW"
    And the property "reason" in response body array with index "<index>" has value "Geolocation Test"
    #custom manipulation of playerId inside.
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | keys                                 | values                         | index | userId       | updatedByUserId |
      | userId,operationalUnit,includeGroups | changeit,rest.geo/access/,true | [0]   | newPlayerWeb | newPlayerWeb    |

  @skipIfNotAzure
  Scenario Outline: Login New - Success - xSourceAllow false - Reason AccessAttributes
    Given I create a POST LoginNew GeoBlocking with allow <xSourceAllow> and payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | username     | password     | group | channel | statusCode | xSourceAllow |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | 200        | false        |

  @skipIfNotAzure
  Scenario: Get - GetSessionWeb - Success
    Given I create a Get "mainSpec" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code 200


  @skipIfNotAzure
  Scenario Outline: Delete AccessAttributes - Success
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | keys                                 | values                         |
      | userId,operationalUnit,includeGroups | changeit,rest.geo/access/,true |

  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Success 2
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                                 | values                         |
      | userId,operationalUnit,includeGroups | changeit,rest.geo/access/,true |


  @NoRetry @skipIfNotAzure
  Scenario Outline: Login New - Negative - xSourceAllow false 2
    Given I create a POST LoginNew GeoBlocking with allow <xSourceAllow> and payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<errorDescription>"

    Examples:
      | username     | password     | group | channel | statusCode | xSourceAllow | errorId   | errorDescription                     |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | 403        | false        | GEO_BLOCK | Access is blocked from your location |


  @NoRetry @skipIfNotAzure
  Scenario: Get - GetSessionWeb - Success
    Given I create a Get "mainSpec" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code 401