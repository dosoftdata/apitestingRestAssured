@AccessService
Feature: Login Times

  @NoRetry
  Scenario: Get Last Login Times - Negative -  Login Time Not Found
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetLastLoginTimes" of service "AccessService" with configured playerId "12345678"
    Then I make a "GET" call to "GetLastLoginTimes" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "LOGIN_TIME_NOT_FOUND"
    And the "description" in response body is "Login time not found ([Error Id: LOGIN_TIME_NOT_FOUND])"

  @NoRetry
  Scenario: Get Last Login Times - Success - New Player
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetLastLoginTimes" of service "AccessService" with configured parameter "loginTimes" "playerId"
    Then I make a "GET" call to "GetLastLoginTimes" to service "AccessService"
    Then the API call is successful with status code 200
    And the "loginTime" to include today's date

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario: Delete Current Session - Logout CC
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "DEL" call to "DeleteCurrentSession" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario: Get Last Login Times - Success - New Player - Login Time Still showing
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetLastLoginTimes" of service "AccessService" with configured parameter "loginTimes" "playerId"
    Then I make a "GET" call to "GetLastLoginTimes" to service "AccessService"
    Then the API call is successful with status code 200
    And the "loginTime" to include today's date

  Scenario: Get Previous Login Times - Success
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetPreviousLoginTimes" of service "AccessService" with new playerId
    When I make a "GET" call to "GetPreviousLoginTimes" to service "AccessService"
    Then the API call is successful with status code 200
    And the "loginTime" to include today's date

