@AccessService
Feature: Mocks

  Scenario: Logout player - Error status in requests for Login
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 500/Password check
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse500"
    And the "requiredScenarioState" in response body is "Started"


    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                               | status | headers          | body |
      | PlayerServiceResponse500 | Started               | 100      | POST   | /api/customer/rest/v1/customers/.*/password/check | 500    | application/json |      |

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 404/Password check
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse404"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                               | status | headers          | body |
      | PlayerServiceResponse404 | Started               | 100      | POST   | /api/customer/rest/v1/customers/.*/password/check | 404    | application/json |      |

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 400/Password check
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse400"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                               | status | headers          | body |
      | PlayerServiceResponse400 | Started               | 100      | POST   | /api/customer/rest/v1/customers/.*/password/check | 400    | application/json |      |

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 302/Password check
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse302"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                               | status | headers          | body |
      | PlayerServiceResponse302 | Started               | 100      | POST   | /api/customer/rest/v1/customers/.*/password/check | 302    | application/json |      |

#-------------------------------

  @skipIfNotAzure
  Scenario: Reset Scenarios
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllScenarios" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

#-------------------------------
  @skipIfNotAzure
  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Access service responds with error 500//Accessgroups/members
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "AccessServiceResponse500"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                        | status | headers          | body |
      | AccessServiceResponse500 | Started               | 100      | GET    | /api/access/rest/v1/accessgroups/members.* | 500    | application/json |      |

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 404/Accessgroups/members
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "AccessServiceResponse404"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                        | status | headers          | body |
      | AccessServiceResponse404 | Started               | 100      | GET    | /api/access/rest/v1/accessgroups/members.* | 404    | application/json |      |

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 400/Accessgroups/members
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "AccessServiceResponse400"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                        | status | headers          | body |
      | AccessServiceResponse400 | Started               | 100      | GET    | /api/access/rest/v1/accessgroups/members.* | 400    | application/json |      |

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 302/Accessgroups/members
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "AccessServiceResponse302"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                        | status | headers          | body |
      | AccessServiceResponse302 | Started               | 100      | GET    | /api/access/rest/v1/accessgroups/members.* | 302    | application/json |      |

#    ----------------------------------

  @skipIfNotAzure
  Scenario: Reset Scenarios
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllScenarios" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

#   ------------------------
  @skipIfNotAzure
  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Access service responds with error 500/Get player
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse500"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                  | status | headers          | body |
      | PlayerServiceResponse500 | Started               | 100      | GET    | /api/customer/rest/v1-opap/players.* | 500    | application/json |      |

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 404/Get player
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse404"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                  | status | headers          | body |
      | PlayerServiceResponse404 | Started               | 100      | GET    | /api/customer/rest/v1-opap/players.* | 404    | application/json |      |

  @skipIfNotAzure
  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 400/Get player
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse400"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                  | status | headers          | body |
      | PlayerServiceResponse400 | Started               | 100      | GET    | /api/customer/rest/v1-opap/players.* | 400    | application/json |      |

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 302/Get player
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse302"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                  | status | headers          | body |
      | PlayerServiceResponse302 | Started               | 100      | GET    | /api/customer/rest/v1-opap/players.* | 302    | application/json |      |

#    -----------------------

  @skipIfNotAzure
  Scenario: Reset Scenarios
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllScenarios" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

#    --------------------
  @skipIfNotAzure
  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Access service responds with error 500/Get contract-agreement/status
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse500"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                                           | status | headers          | body |
      | PlayerServiceResponse500 | Started               | 100      | GET    | /api/customer/rest/v1/customers/.*/contract-agreements/status | 500    | application/json |      |

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 404/Get contract-agreement/status
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse404"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                                           | status | headers          | body |
      | PlayerServiceResponse404 | Started               | 100      | GET    | /api/customer/rest/v1/customers/.*/contract-agreements/status | 404    | application/json |      |

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 400/Get contract-agreement/status
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse400"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                                           | status | headers          | body |
      | PlayerServiceResponse400 | Started               | 100      | GET    | /api/customer/rest/v1/customers/.*/contract-agreements/status | 400    | application/json |      |

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 302/Get contract-agreement/status
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse302"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                                           | status | headers          | body |
      | PlayerServiceResponse302 | Started               | 100      | GET    | /api/customer/rest/v1/customers/.*/contract-agreements/status | 302    | application/json |      |

#   ---------------------

  @skipIfNotAzure
  Scenario: Reset Scenarios
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllScenarios" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200


   #    --------------------

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - - Error status in requests for Logout
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse500"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                               | status | headers          | body |
      | PlayerServiceResponse500 | Started               | 100      | GET    | /api/customer/rest/v1/customers.* | 500    | application/json |      |

  @skipIfNotAzure
  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 404/Get contract-agreement/status
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse404"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                               | status | headers          | body |
      | PlayerServiceResponse404 | Started               | 100      | GET    | /api/customer/rest/v1/customers.* | 404    | application/json |      |

  @skipIfNotAzure
  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 400/Get contract-agreement/status
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse400"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                               | status | headers          | body |
      | PlayerServiceResponse400 | Started               | 100      | GET    | /api/customer/rest/v1/customers.* | 400    | application/json |      |

  @skipIfNotAzure
  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Player service responds with error 302/Get contract-agreement/status
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201
    And the "scenarioName" in response body is "PlayerServiceResponse302"
    And the "requiredScenarioState" in response body is "Started"

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                               | status | headers          | body |
      | PlayerServiceResponse302 | Started               | 100      | GET    | /api/customer/rest/v1/customers.* | 302    | application/json |      |

  @skipIfNotAzure
  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure @NoRetry
  Scenario Outline: Get - GetSessionMinutesWeb
    Given I create a Get "<spec>" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with configured playerId "12345678"
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=rest.sessionminutes/item/get/WEB"

    Examples:
      | spec           | statusCode |
      | specWithOrigin | 401        |

  @skipIfNotAzure
  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure @NoRetry
  Scenario Outline: Get - GetSessionMinutesWeb
    Given I create a Get "<spec>" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with configured playerId "12345678"
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=rest.sessionminutes/item/get/WEB"

    Examples:
      | spec           | statusCode |
      | specWithOrigin | 401        |

    #   ---------------------

  @skipIfNotAzure
  Scenario: Reset Scenarios
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllScenarios" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200
