@AccessService
Feature: Get Session Time



  #this passes but ruins the url. Works on other qa?
  @NoRetry @Concat
  Scenario Outline: Get Session Minutes - Negative
    Given I create a Get "mainSpec" header
    And I save the initial url of method "GetSessionMinutesWeb" of service "AccessService"
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with configured playerId "<playerId>"
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "description" in response body is "<description>"

    Examples:
      | statusCode | playerId | description             |
      | 403        | 123      | Access denied           |
      | 400        | test     | Badly formed customerId |


  Scenario: Get Session Minutes - Success
    Given I create a Get "mainSpec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 200

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

    #TODO:  401 and not 403? discuss
  @NoRetry
  Scenario: Get- GetSessionMinutesWeb - Negative - Already LoggedOut
    Given I create a Get "mainSpec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 401
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=rest.sessionminutes/item/get/WEB"

  @NoRetry
  Scenario: Get - GetSessionWeb - Negative Already LoggedOut
    Given I create a Get "mainSpec" header
    When I make a "GET" call to "GetSessionWeb" to service "AccessService"
    Then the API call is successful with status code 401
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=rest.time/item/get/WEB"
