@AccessService
Feature: Manage Roles Via CC V2 Endpoints

  #its most relevant to Azure but it can run in Integration for now.
  #verifies the Technician,Super Admin & clerk roles. Other roles may exist in other environments but they are not checked.
  Scenario Outline: Get - RolesAdminCC  - Success Scenario
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the admin roles Technician Super Admin Clerk
    And the "rows" size in response body is above 2
#    And the number of results in a nameless array of objects is <numberOfAdmins>


    @skipIfNotAzure
    Examples:
      | numberOfAdmins |
      | 3              |

    @skipIfNotIntegration
    Examples:
      | numberOfAdmins |
      | 12             |

  @NoRetry
  Scenario: Get - RolesAdminRoleIdCC  - Role Not Found 404
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "2784526852"
    When I make a "GET" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ROLE_NOT_FOUND"
    And the "description" in response body is "Role does not exist ([Error Id: ROLE_NOT_FOUND])"


  Scenario: Get - RolesAdminRoleIdCC  - Success Scenario
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "superAdminAccessId"
    When I make a "GET" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code 200
    And the "description" in response body is "Group of admins that have full access to all Backoffice functionality"
    And the "name" in response body is "Super Admin"


    #to check what happens with body.
  @skipIfNotAzure @NoRetry
  Scenario Outline: Post - RolesAdminCC  - Add a new access role - Missing body
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "POST" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | statusCode | errorId               | description           |
      | 500        | INTERNAL_SERVER_ERROR | Internal Server Error |


  @skipIfNotAzure
  Scenario Outline: Post - RolesAdminCC  - Add a new access role - Success Scenario
    Given I create a RolesAdminCC payload with "<name>" "<description>"
    When I make a "POST" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And I copy the value of the roleId from the response


    Examples:
      | name              | description              | statusCode |
      | testRoleNameViaCC | testRoleDescriptionViaCC | 201        |


  @skipIfNotAzure @NoRetry
  Scenario Outline: Post - RolesAdminCC  - Add a new access role - Missing body - Role Already Exists
    Given I create a RolesAdminCC payload with "<name>" "<description>"
    When I make a "POST" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<errorDescription>"

    Examples:
      | name              | description              | statusCode | errorId             | errorDescription                               |
      |                   |                          | 400        | INVALID_ROLENAME    | Role name empty ([Error Id: INVALID_ROLENAME]) |
      | testRoleNameViaCC | testRoleDescriptionViaCC | 409        | ROLE_ALREADY_EXISTS | Role already exists                            |


    #we use the calculated roleIdCC
  @skipIfNotAzure
  Scenario: Get - RolesAdminRoleIdCC  - Success Scenario
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "roleIdCC"
    When I make a "GET" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code 200
    And the "description" in response body is "testRoleDescriptionViaCC"
    And the "name" in response body is "testRoleNameViaCC"

  @skipIfNotAzure @NoRetry
  Scenario: Del - RolesAdminRoleIdCC  - Negative - Role Not Found
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "12345678"
    When I make a "DEL" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ROLE_NOT_FOUND"
    And the "description" in response body is "Role does not exist ([Error Id: ROLE_NOT_FOUND])"


  @skipIfNotAzure @NoRetry
  Scenario: Put - RolesAdminRoleIdCC  - Success Scenario
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "roleIdCC"
    When I make a "PUT" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

  @skipIfNotAzure @NoRetry
  Scenario Outline: Put - RolesAdminRoleIdCC  - Empty Body
    Given I create a RolesAdminCC payload with "<name>" "<description>"
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "roleIdCC"
    When I make a "PUT" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<errorDescription>"

    Examples:
      | name | description | statusCode | errorId          | errorDescription                               |
      |      |             | 400        | INVALID_ROLENAME | Role name empty ([Error Id: INVALID_ROLENAME]) |

  @skipIfNotAzure
  Scenario Outline: Put - RolesAdminRoleIdCC  - Success Scenario
    Given I create a RolesAdminCC payload with "<name>" "<description>"
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "roleIdCC"
    When I make a "PUT" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | name           | description           | statusCode |
      | thisIsAnewName | thisIsAnewDescription | 204        |

  @skipIfNotAzure
  Scenario: Get - RolesAdminRoleIdCC  - Success Scenario
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "roleIdCC"
    When I make a "GET" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code 200
    And the "description" in response body is "thisIsAnewDescription"
    And the "name" in response body is "thisIsAnewName"

  @skipIfNotAzure
  Scenario: Del - RolesAdminRoleIdCC  - Negative - Role Not Found
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "roleIdCC"
    When I make a "DEL" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code 204


  @skipIfNotAzure @NoRetry
  Scenario: Get - RolesAdminRoleIdCC  - Negative Scenario - Role Not Found
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "roleId" "roleIdCC"
    When I make a "GET" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ROLE_NOT_FOUND"
    And the "description" in response body is "Role does not exist ([Error Id: ROLE_NOT_FOUND])"

  @NoRetry
  Scenario: Get - GetAdminRoles  - TestUser - Not Found
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetAdminRolesCC" of service "AccessService" with configured adminId "testUser"
    When I make a "GET" call to "GetAdminRolesCC" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "USER_NOT_FOUND"
    And the "description" in response body is "The specified admin doesn't exist ([Error Id: USER_NOT_FOUND])"


  Scenario: Get - GetAdminRoles  - Success - AdminId = 1
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetAdminRolesCC" of service "AccessService" with configured adminId "1"
    When I make a "GET" call to "GetAdminRolesCC" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "name" in response body array with index "[0]" has value "Super Admin"
    And the property "description" in response body array with index "[0]" has value "Group of admins that have full access to all Backoffice functionality"


  Scenario: Delete - Delete Current session token web
    Given I create a Get "mainSpec" header
    When I make a "DEL" call to "DeleteCurrentSessionToken" to service "AccessService"
    Then the API call is successful with status code 204