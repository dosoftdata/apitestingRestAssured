@AccessService
Feature: Feature flag for non logged in users


  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @NoRetry
  Scenario: Check if feature is ready to be delivered to players - Missing feature parameter
    And I create a Get "mainSpec" header
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 400
    And the "fieldViolations" in response body is "[]"
    And the "propertyViolations.length" in response body is "[]"
    And the "classViolations.length" in response body is "[]"
    And the property "constraintType" in response body array with index "parameterViolations[0]" contains either of the values "PARAMETER"
    And the property "path" in response body array with index "parameterViolations[0]" contains either of the values "check.arg0"
    And the property "message" in response body array with index "parameterViolations[0]" contains either of the values "may not be null"
    And the property "value" in response body array with index "parameterViolations[0]" contains either of the values ""


  @NoRetry
  Scenario Outline: Check if feature is ready to be delivered to players - Invalid feature name
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "FEATURE_ERROR"
    And the "description" in response body is "Feature name not supported ([Error Id: FEATURE_ERROR])"

    Examples:
      | key     | value |
      | feature | test  |

  @NoRetry
  Scenario Outline: Check if feature is ready to be delivered to players - Feature is missing
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "FEATURE_MISSING"
    And the "description" in response body is "Feature name is missing ([Error Id: FEATURE_MISSING])"

    Examples:
      | key     | value |
      | feature |       |

  @NoRetry @skipIfAzure
  Scenario Outline: Check if feature is ready to be delivered to players - Wrong operationalUnit format
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "FEATURE_ERROR"
    And the "description" in response body is "Feature name not supported ([Error Id: FEATURE_ERROR])"

    Examples:
      | key     | value            |
      | feature | subscriptionTest |

  @NoRetry @skipIfNotAzure
  Scenario Outline: Check if feature is ready to be delivered to players - Wrong operationalUnit format
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "OPERATIONAL_UNIT_WRONG_FORMAT"
    And the "description" in response body is "Found Operational Unit with wrong format ([Error Id: OPERATIONAL_UNIT_WRONG_FORMAT])"

    Examples:
      | key     | value            |
      | feature | subscriptionTest |

  @NoRetry @skipIfNotAzure
    #question to verify existence in environments
  Scenario Outline: Check if feature is ready to be delivered to players - Not found
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "NOT_FOUND"
    And the "description" in response body is "Feature service not found ([Error Id: NOT_FOUND])"

    Examples:
      | key     | value        |
      | feature | subscription |

  @skipIfAzure
    #question to verify existence in environments
  Scenario Outline: Check if feature is ready to be delivered to players - Found
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 204


    Examples:
      | key     | value        |
      | feature | subscription |

  Scenario: Get and Verify Access Groups
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response and copy the access group Ids

  @skipIfNotAzure @NoRetry
  Scenario: Add new member to Friends&Family group - Member type mismatch
    Given I create an AddUserToFriendsAndFamilyGroup payload for Member Id mismatch
    And I change url resource of method "AddUserToEpGroup" of service "AccessService" with new "friendsAndFamilyGroupId"
    When I make a "POST" call to "AddUserToEpGroup" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "MEMBER_TYPE_MISMATCH"
    And the "description" in response body is "The member type of the role doesn't match that of the role member being added ([Error Id: MEMBER_TYPE_MISMATCH])"

  @skipIfNotAzure
  Scenario: Add new member to Friends&Family group
    Given I create an AddUserToFriendsAndFamilyGroup payload
    And I change url resource of method "AddUserToEpGroup" of service "AccessService" with new "friendsAndFamilyGroupId"
    When I make a "POST" call to "AddUserToEpGroup" to service "AccessService"
    Then the API call is successful with status code 201

  @skipIfNotAzure
  Scenario Outline: Get an AccessAttribute - Feature.subscription does not exist
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                                 | values                                                          |
      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,feature.subscription/check/ALL/ALL,true |

  @skipIfNotAzure
  Scenario Outline: Add an AccessAttribute - Success
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload for friendsAndFamilyGroupId with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<validFrom>" "<validTo>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"

    Examples:
      | accessType | operationalUnit             | userId                  | created | updated | updatedByUserId         | operatorId | reason | validFrom | validTo | index |
      | ALLOW      | feature.subscription/check/ | friendsAndFamilyGroupId |         |         | friendsAndFamilyGroupId | 0          | Test   | null      | null    | [0]   |

  Scenario Outline: Get an AccessAttribute - Feature.subscription exists
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "operationalUnit" in response body array with index "<index>" has value "feature.subscription/check/"
    And the property "accessType" in response body array with index "<index>" has value "ALLOW"
    And the property "reason" in response body array with index "<index>" has value "Test"

    Examples:
      | keys                                 | values                                                          | index |
      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,feature.subscription/check/ALL/ALL,true | [0]   |


  @NoRetry @skipIfNotAzure
  Scenario Outline: Check if feature is ready to be delivered to players - Not found
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "NOT_FOUND"
    And the "description" in response body is "Feature service not found ([Error Id: NOT_FOUND])"

    Examples:
      | key     | value        |
      | feature | subscription |

   @skipIfAzure
  Scenario Outline: Check if feature is ready to be delivered to players -  Found
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 204


    Examples:
      | key     | value        |
      | feature | subscription |

  @skipIfNotAzure
  Scenario Outline: Delete an AccessAttribute
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    When I make a "DEL" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | keys                                 | values                                                          |
      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,feature.subscription/check/ALL/ALL,true |

  @skipIfNotAzure
  Scenario Outline: Get an AccessAttribute - Feature.subscription exists
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                                 | values                                                          |
      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,feature.subscription/check/ALL/ALL,true |

  @NoRetry @skipIfNotAzure
  Scenario Outline: Check if feature is ready to be delivered to players - Not found
    And I create a Get "mainSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "CheckIfFeatureIsReady" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "NOT_FOUND"
    And the "description" in response body is "Feature service not found ([Error Id: NOT_FOUND])"

    Examples:
      | key            | value                 |
      | feature,userId | subscription,changeit |
