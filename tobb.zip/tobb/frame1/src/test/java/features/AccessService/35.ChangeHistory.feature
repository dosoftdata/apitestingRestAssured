@AccessService @ChangeHistory
Feature: Change History

  @NoRetry
  Scenario Outline: Get Accessattributes change history - no query params - no errorId - User Not Found 404
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccessAttributesChangeHistory" of service "AccessService" with configured parameter "userId" "<userId>"
    Then I make a "GET" call to "GetAccessAttributesChangeHistory" to service "AccessService"
    And the API call is successful with status code <statusCode>


    Examples:
      | userId | statusCode |
      | test   | 404        |


  @NoRetry
  Scenario Outline: Get Accessattributes change history - no query params (Missing DateFrom)
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccessAttributesChangeHistory" of service "AccessService" with configured parameter "userId" "<userId>"
    Then I make a "GET" call to "GetAccessAttributesChangeHistory" to service "AccessService"
    And the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | userId | statusCode | errorId               | description           | Gherkin Description |
      | 1013-0 | 500        | INTERNAL_SERVER_ERROR | Internal Server Error | Missing dateFrom    |


  @NoRetry
  Scenario Outline: Get Accessattributes change history - with query params - Negative
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "GetAccessAttributesChangeHistory" of service "AccessService" with configured parameter "userId" "3-1"
    Then I make a "GET" call to "GetAccessAttributesChangeHistory" to service "AccessService"
    And the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | keys     | values  | statusCode | errorId               | description           | Gherkin Description |
      | dateFrom | datenow | 500        | INTERNAL_SERVER_ERROR | Internal Server Error | Missing DateTo      |

  Scenario Outline: Get Accessattributes change history - with query params - Success - User Id = ALL
    Given I login as an Api user
    And I change url resource of method "GetAccessAttributesChangeHistory" of service "AccessService" with configured parameter "userId" "<userId>"
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetAccessAttributesChangeHistory" to service "AccessService"
    And the API call is successful with status code 200
    And the number of results in a nameless array of objects are greater than <numberOfReturnedItems>

    @skipIfNotAzure
    Examples:
      | keys            | values          | userId | numberOfReturnedItems |
      | dateFrom,dateTo | datenow,datenow | 0-0    | 0                     |

    @skipIfAzure
    Examples:
      | keys            | values          | userId | numberOfReturnedItems |
      | dateFrom,dateTo | datenow,datenow | 0-0    | -1                    |


    #recheck after Run Azure . 1 item in response or 2? depends on del?
  @skipIfNotAzure
  Scenario Outline: Get Accessattributes change history - with query params - Success - User Id = Service Providers
    Given I login as an Api user
    And I change url resource of method "GetAccessAttributesChangeHistory" of service "AccessService" with configured parameter "userId" "<userId>"
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "GetAccessAttributesChangeHistory" to service "AccessService"
    And the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And the property "field" in response body array with index "[0].primaryKey[0]" has value "userId"
    And the property "value" in response body array with index "[0].primaryKey[0]" has value "1006-1006"
    And the property "field" in response body array with index "[0].primaryKey[1]" has value "accessType"
    And the property "value" in response body array with index "[0].primaryKey[1]" has value "ALLOW"
    And the property "field" in response body array with index "[0].primaryKey[2]" has value "operationalUnit"
    And the property "value" in response body array with index "[0].primaryKey[2]" has value "api/test5/test5/test5"
    And the property "field" in response body array with index "[0].primaryKey[3]" has value "validFrom"
    #And the property "value" in response body array with index "[0].primaryKey[3]" has value "null"
    And the property "field" in response body array with index "[0].primaryKey[4]" has value "validTo"
   # And the property "value" in response body array with index "[0].primaryKey[4]" has value "null"
    And the property "field" in response body array with index "[0].updates[0]" has value "reason"
    And the property "fromValue" in response body array with index "[0].updates[0]" has value ""
    And the property "toValue" in response body array with index "[0].updates[0]" has value "Test"
    And the property "field" in response body array with index "[0].updates[1]" has value "updatedByUserId"
    And the property "fromValue" in response body array with index "[0].updates[1]" has value ""
    And the property "toValue" in response body array with index "[0].updates[1]" has value "1006-1006"
    And the property "id" in response body array with index "[0].updatedBy" has value "1006"
    And the property "type" in response body array with index "[0].updatedBy" has value "1006"
    #And the property "timeStamp" in response body array with index "[0].updates[1]" has value "1006-1006"




    Examples:
      | keys            | values          | userId    |
      | dateFrom,dateTo | datenow,datenow | 1006-1006 |
