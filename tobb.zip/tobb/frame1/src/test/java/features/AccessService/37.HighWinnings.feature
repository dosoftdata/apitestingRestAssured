@AccessService
Feature: High Winnings


  Scenario: Get admin session
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetAdminSession" to service "AdminService"
    Then the API call is successful with status code 200
    And the "loginName" in response body is "admin"
    And the "language" in response body is "en_US"
    And the "email" in response body is "support@novomaticls.com"

  Scenario Outline: Get - RolesAdminCC  - Success Scenario
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code 200
    And I copy the value of the HighWinningsRoleId
    And the "rows" size in response body is above 2
#    And the number of results in a nameless array of objects is <numberOfAdmins>

    @skipIfNotAzure
    Examples:
      | numberOfAdmins |
      | 3              |

    @skipIfNotIntegration
    Examples:
      | numberOfAdmins |
      | 12             |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: Manual adjustment for Deposit in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWalletv2" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWalletv2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "<operation>"

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | SPORTSBOOK | DEPOSIT   | 20000  |

  Scenario Outline: PlayBetFunds (PAME STOIXIMA winning ticket)
    Given I login as an Api user
    And I setup gameId header to "<xGameId>"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And I copy the value of the paymentId for Grand prize
    And the property "accountId" in response body array with index "<arrayWithIndex>" has value "<accountId>"
    And the property "productId" in response body array with index "<arrayWithIndex>" has value "<productId>"
    And the property "description" in response body array with index "<arrayWithIndex>" has value "<description>"
    And the property "amount" in response body array with index "<arrayWithIndex>" has value "<decimalAmount>"
    And the property "type" in response body array with index "<arrayWithIndex>" has value "TT_PRIZE_OUT"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"
    And the property "autocapture" in response body array with index "<arrayWithIndex>" has value "<autocapture>"
    And the property "captured" in response body array with index "<arrayWithIndex>" has value "<autocapture>"

    Examples:
      | xGameId    | accountId | decimalAmount | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | arrayWithIndex | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | SPORTSBOOK | AT_MAIN-2 | -160000.0     | 160000 | DEFAULT  | datenow | SPORTSBOOK | PRIZE | Bet         | true        | VERIFIED |          | [0]            | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify - Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
#    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 520.0    | 520.0        | 20.0                    | 0.0              | 500.0                | 300672.0 | 300672.0     | 172.0                   | 0.0              | 300500.0             |


  @skipIfNotAzure
  Scenario Outline: Post - RolesAdminCC  - Add a new access role - Success Scenario
    Given I create a RolesAdminCC payload with "<name>" "<description>"
    When I make a "POST" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | name         | description                                           | statusCode |
      | HighWinnings | Group of admins that have full access to HighWinnings | 201        |

  Scenario: Get High Winnings' accessRoleId
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code 200
    And I copy the value of the HighWinningsRoleId

  @skipIfNotAzure
  Scenario: Put - Assign proper access roles for High Winnings
    Given I create a Get "cc_csrftokenSpec" header
    And I create an Assign_Access_Roles_for_Clerk payload
    And I change url resource of method "AllowRoleAccessAttributes" of service "AccessService" with configured parameter "highWinningsRoleId" "highWinnings"
    When I make a "PUT" call to "AllowRoleAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotIntegration
  Scenario: Get - Verify BO users
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 1
    And I check if BO user exists with loginName "highw3" and lastName "winning"

  @skipIfNotAzure
  Scenario: Get - Verify BO users
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 1
    And I check if BO user exists with loginName "highw3" and lastName "winning"
    And I create new High Winnings user for Azure

  @NoRetry  @skipIfNotAzure @skipIfUserExists
  Scenario Outline: Create new "HighWinnings" user
    And I create a Get "cc_csrftokenSpec" header
    And I create a POST CreateNewRole payload "<email>" "<firstname>" "<language>" "<lastName>" "<loginName>" "<password>" "<passwordRepeated>" <status> "<groupIds>"
    When I make a "POST" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    And I check if response code is 400 or 200
#    And I verify the value of groupIds

    Examples:
      | email             | firstname | language | lastName | loginName         | password        | passwordRepeated | status | groupIds     |
      | azureHighWinnings | highqqqq  |          | winning  | azureHighWinnings | Fabola12345678! | Fabola12345678!  | 1      | highWinnings |

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfUserExists @skipIfNotAzure @NoRetry
  Scenario: Post - Login as HighWinnings user via CC endpoint
    Given I create a Get "cc_csrftokenSpec" header
    And I Login as HighWinnings user Post payload for Azure before password update
    When I make a "POST" call to "LoginBackOffice" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "MUST_CHANGE_PASSWORD"
    And the "description" in response body is "The user must change the password, so can't login with the current one. ([Error Id: MUST_CHANGE_PASSWORD])"

  @skipIfUserExists @skipIfNotAzure @NoRetry
  Scenario Outline: Put - Update password
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT UpdatePassword payload with "<password>"
    And I change url resource of method "UpdatePassword" of service "AdminService" with configured parameter "highWinningsEnable" "highWinnings"
    When I make a "PUT" call to "UpdatePassword" to service "AdminService"
    Then the API call is successful with status code 204

    Examples:
      | password        |
      | Fabola12345678@ |

   @skipIfNotIntegration
  Scenario: Post - Login as HighWinnings user via CC endpoint
    Given I create a Get "cc_csrftokenSpec" header
    And I create a Login as HighWinnings user Post payload with "highw3" "Fabola12345678@"
    When I make a "POST" call to "LoginBackOffice" to service "AccessService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario: Post - Login as HighWinnings user via CC endpoint
    Given I create a Get "cc_csrftokenSpec" header
    And I Login as HighWinnings user Post payload for Azure after password update
    When I make a "POST" call to "LoginBackOffice" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario Outline: Get BO payments for High winnings
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetGrandPrizePayments" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the paymentId for Grand prize
    And the property "paymentType" and value "PT_GRAND_PRIZE" exist in the response body

    Examples:
      | keys                                          | values                                                                         |
      | paymentType,dateTo,ordering,dateFrom,statuses | PT_GRAND_PRIZE,2026-03-26T14:40:29+00:00,DESC,2024-03-26T14:40:29+00:00,REVIEW |

  @skipIfNotAzure
  Scenario: Post - Approve payment for High winnings
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "ApprovePayment" of service "WalletService" with configured parameter "paymentId" "highWinnings"
    When I make a "POST" call to "ApprovePayment" to service "WalletService"
    Then the API call is successful with status code 204

  @skipIfNotAzure
  Scenario: Post - Verify payment for high winnings
    Given I create a Get "cc_csrftokenSpec" header
    And I create a Verify High Winnings Payment Post payload
    And I change url resource of method "VerifyPayment" of service "WalletService" with configured parameter "paymentId" "highWinnings"
    When I make a "POST" call to "VerifyPayment" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentType" in response body is "PT_GRAND_PRIZE"
    And the "status" in response body is "VERIFIED"

  Scenario Outline: Get player's transactions as Admin
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPlayerTransactionsAsAdmin2" of service "WalletService" with configured parameter "playerIdGrandPrize" "GrandPrize"
    When I make a "GET" call to "GetPlayerTransactionsAsAdmin2" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify that payment Grand prize exists in the response body

    Examples:
      | keys                                  | values                                                    |
      | pagenumber,pagesize,startDate,endDate | 1,600,2024-03-26T14:40:29+00:00,2026-03-26T14:40:29+00:00 |

  Scenario Outline: Get player's account payments
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerPaymentsAsAdmin" to service "WalletService"
    Then the API call is successful with status code 200
    And the property "paymentType" in response body array with index "data[0]" has value "PT_GRAND_PRIZE"
    And I check that the size of data.length is above 3

    Examples:
      | keys                            | values                 |
      | pagenumber,customerId,accountId | 1,changeit,AT_MAIN-2 |

  @skipIfNotAzure @NoRetry
  Scenario: Del - RolesAdminRoleIdCCGiven
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "RolesAdminRoleIdCC" of service "AccessService" with configured parameter "highWinningsRoleId" "highWinnings"
    When I make a "DEL" call to "RolesAdminRoleIdCC" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario Outline: Get - RolesAdminCC - Success Scenario
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code 200
    And I copy the value of the HighWinningsRoleId
    And the "rows" size in response body is above 2
#    And the number of results in a nameless array of objects is <numberOfAdmins>

    @skipIfNotAzure
    Examples:
      | numberOfAdmins |
      | 3              |

    @skipIfNotIntegration
    Examples:
      | numberOfAdmins |
      | 12             |
