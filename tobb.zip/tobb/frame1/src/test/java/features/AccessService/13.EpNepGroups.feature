@AccessService
Feature: EP NEP Groups 2

#  User is not a member of EP/NEP group

  @AccessService
  Scenario: Get and Verify Access Groups
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response and copy the access group Ids


  @AccessService
  Scenario: Remove the user from EP & NEP groups
    When I create payload with EpGroup "false" and NepGroup "false"
    And I change url resource of method "AddAndRemoveUsersFromGroups" of service "PlayerService" with new playerId
    And I make a "PUT" call to "AddAndRemoveUsersFromGroups" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "isExclusiveGamesGroupActive" in response body is "false"
    And the "isNonExclusiveGamesGroupActive" in response body is "false"


  @AccessService
  Scenario Outline: Get and Verify Payment Codes
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the values of the Payment Codes

    Examples:
      | keys     | values |
      | category | ALL    |

  @AccessService
  Scenario: Deposit via Payment code - Betting wallet - Negative scenario
    Given I login as an Api user
    When I create a Post DepositViaPayment payload for "Betting Wallet" wallet
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

  @AccessService
  Scenario: Deposit via Payment code - Lottery wallet - Negative scenario
    Given I create a Post DepositViaPayment payload for "Lottery Wallet" wallet
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

  @AccessService @skipIfAzure
  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId


    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |

  @AccessService
  Scenario Outline: Deposit via Card - Betting wallet (Sportsbook) - Negative scenario
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | amount |
      | 50     |

  @AccessService
  Scenario Outline: Deposit via Card - Betting wallet (Casino) - Negative scenario
    Given I setup gameId header to "CASINO"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | amount |
      | 50     |

  @AccessService
  Scenario Outline: Deposit via Card - Lottery wallet (Joker) - Negative scenario
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | amount |
      | 50     |


  @AccessService
  Scenario Outline: Wallet funds - User cannot play with Lottery account
    Given I setup gameId header to "<xGameId>"
    When I create a PostWalletFunds payload with "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<batchId>"
    And I change url resource of method "PostWalletFunds" of service "WalletService" with new playerId
    And I make a "POST" call to "PostWalletFunds" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | xGameId | accountId | batchId | amount | currency | issued  | productId | type | description | autocapture | status | captured |
      | JOKER   | AT_MAIN-1 | 1       | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | true        | TEST   | false    |


  @AccessService
  Scenario Outline: Wager funds - User is blocked for exclusive games
    Given I setup gameId header to "<xGameId>"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    And I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Game currently unavailable for player ([Error Id: PLAYER_CONSENT_REQUIRED])"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | xGameId | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | JOKER   | AT_MAIN-1 | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  @AccessService
  Scenario Outline: Wallet funds - User cannot play with Betting account
    Given I setup gameId header to "<xGameId>"
    When I create a PostWalletFunds payload with "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<batchId>"
    And I change url resource of method "PostWalletFunds" of service "WalletService" with new playerId
    And I make a "POST" call to "PostWalletFunds" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | xGameId    | accountId | batchId | amount | currency | issued  | productId  | type | description | autocapture | status | captured |
      | SPORTSBOOK | AT_MAIN-2 | 1       | -2     | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | TEST   | false    |

  Scenario Outline: Wager funds - User is blocked for non-exclusive games
    Given I setup gameId header to "<xGameId>"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    And I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Game currently unavailable for player ([Error Id: PLAYER_CONSENT_REQUIRED])"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | xGameId | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | CASINO  | AT_MAIN-2 | -2     | DEFAULT  | datenow | CASINO    | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"


    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 570.0    | 570.0        | 70.0                    | 0.0              | 500.0                | 540.0    | 540.0        | 40.0                    | 0.0              | 500.0                |


  Scenario: Verify User still a member of EP/NEP
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetRoleMembers" of service "AccessService" with new playerId
    When I make a "GET" call to "GetRoleMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response for Role Members for "NotInExclusiveAndNonExclusive"
#------------
  Scenario Outline: Upload card Documents (Front)
    When I create a UploadDocumentsWeb payload with "<fileName>" "<type>"
    And I change url resource of method "UploadDocumentsWeb" of service "PlayerService" with new playerId
    When I make a "POST" call to "UploadDocumentsWeb" to service "PlayerService"
    Then the API call is successful with status code 200
    Examples:
      | fileName    | type       |
      | IDfront.JPG | CARD_FRONT |

  @skipIfAzure
  Scenario Outline: Get BO Pending Verifications of Player - Verify Card values
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Card Pending Verification with status "<status>" "<cardExpirationYear>" "<cardName>" "<cardNumber>" "<cardHolderName>" "<cardExpirationMonth>"

#    @Preprod
#    Examples:
#      | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
#      | WAITING_ADMIN_APPROVAL | 2025               | master     | 519999******1465 | TEST PROD      | 12                  |

    @Integration @UAT
    Examples:
      | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
      | WAITING_ADMIN_APPROVAL | 2025               | master   | 541333******1031 | TEST PROD      | 12                  |

  Scenario Outline: Get BO Pending Verifications of Player - Verify Card values
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Card Pending Verification with status "<status>" "<cardExpirationYear>" "<cardName>" "<cardNumber>" "<cardHolderName>" "<cardExpirationMonth>"

    @skipIfNotAzure
    Examples:
      | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
      | WAITING_ADMIN_APPROVAL | 2025               | visa     | 465858******0001 | TEST PROD      | 06                  |

  Scenario Outline: Get Uploaded documents - Verify Card Documents (CARD_FRONT)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUploadedDocuments" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetUploadedDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Uploaded Documents with "<types>" "<fileName>" "<fileType>"

    Examples:
      | types      | fileName    | fileType   |
      | CARD_FRONT | IDfront.JPG | image/jpeg |

########### subType : This variable is not send in request but to specify the variable in which the verification is done
########### subType values : FRONT,BACK (for CARD type) - OTHER,UTILITY (for IDENTITY type)
  Scenario Outline: Verify Card Documents - CARD FRONT
    When I create a VerifyDocuments payload with "<verificationType>" "<statusDescription>" and subcategory "<subType>"
    And I change url resource of method "VerifyDocuments" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerifyDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "verificationType" in response body is "<verificationType>"
    And the "documentType" in response body is "<documentTypeResponse>"
    And the "statusDescription" in response body is "<statusDescription>"
    And the "status" in response body is "<statusValue>"


    Examples:
      | verificationType | statusDescription                  | subType | statusValue | documentTypeResponse |
      | CARD             | Approve uploaded document for Card | FRONT   | APPROVED    | CARD_FRONT           |


  Scenario Outline: Upload card Documents (Back)
    When I create a UploadDocumentsWeb payload with "<fileName>" "<type>"
    And I change url resource of method "UploadDocumentsWeb" of service "PlayerService" with new playerId
    When I make a "POST" call to "UploadDocumentsWeb" to service "PlayerService"
    Then the API call is successful with status code 200
    Examples:
      | fileName   | type      |
      | IDback.JPG | CARD_BACK |


  Scenario Outline: Get Uploaded documents - Verify Card Documents (CARD_BACK)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUploadedDocuments" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetUploadedDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Uploaded Documents with "<types>" "<fileName>" "<fileType>"

    Examples:
      | types     | fileName   | fileType   |
      | CARD_BACK | IDback.JPG | image/jpeg |


  Scenario Outline: Verify Card Documents - CARD BACK
    When I create a VerifyDocuments payload with "<verificationType>" "<statusDescription>" and subcategory "<subType>"
    And I change url resource of method "VerifyDocuments" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerifyDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "verificationType" in response body is "<verificationType>"
    And the "documentType" in response body is "<documentTypeResponse>"
    And the "statusDescription" in response body is "<statusDescription>"
    And the "status" in response body is "<statusValue>"


    Examples:
      | verificationType | statusDescription                  | subType | statusValue | documentTypeResponse |
      | CARD             | Approve uploaded document for Card | BACK    | APPROVED    | CARD_BACK            |


  Scenario Outline: Confirm Verification of Player's Card - Verify Type/Status and save cardNumber
    When I create a VerificationConfirm payload with "<verificationType>"
    And I change url resource of method "VerificationConfirm" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerificationConfirm" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "verificationType" in response body is "<verificationType>"
    And the "status" in response body is "<statusValue>"
    And I copy the value of the fingerprint from the response
    And I copy the value of the cardNumber from the response

    Examples:
      | verificationType | statusValue |
      | CARD             | VERIFIED    |

#------------
    ## User is a member of EP group only

  Scenario: Add user to EP group
    Given I create an AddUserToEpGroup payload
    And I change url resource of method "AddUserToEpGroup" of service "AccessService" with new "accessGroupIdExclusive"
    When I make a "POST" call to "AddUserToEpGroup" to service "AccessService"
    Then the API call is successful with status code 201
    And I copy and verify the member Id


  Scenario: Get and Verify Role Members
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetRoleMembers" of service "AccessService" with new playerId
    And I make a "GET" call to "GetRoleMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response for Role Members for "Exclusive"


  Scenario Outline: Deposit via Payment code - Lottery wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_EXCLUSIVE"
    And the "amount.amount" in response body is "10.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via paymentCode paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId


  Scenario Outline: Deposit via Payment code - Betting wallet (Negative)
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |


  Scenario Outline: Deposit via Card - Lottery wallet (Joker)
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 50     |

  @skipIfAzure
  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId

    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |


  @skipIfNotAzure
  Scenario: Commit Card Deposit To Tora
    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card

  @skipIfAzure
  Scenario: Commit Card Deposit To Tora
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId via card

  Scenario Outline: Deposit via Card - Betting wallet (Sportsbook) - Negative scenario
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | amount |
      | 50     |


  Scenario Outline: Deposit via Card - Betting wallet (Casino) - Negative scenario
    Given I setup gameId header to "CASINO"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | amount |
      | 50     |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"


    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 630.0    | 630.0        | 130.0                   | 0.0              | 500.0                | 540.0    | 540.0        | 40.0                    | 0.0              | 500.0                |


  Scenario Outline: Wager funds - User can play for exclusive games
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"


    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 628.0    | 628.0        | 128.0                   | 0.0              | 500.0                | 540.0    | 540.0        | 40.0                    | 0.0              | 500.0                |


  Scenario Outline: Wallet funds - User can play for exclusive games
    Given I setup gameId header to "<xGameId>"
    When I create a PostWalletFunds payload with "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<batchId>"
    And I change url resource of method "PostWalletFunds" of service "WalletService" with new playerId
    And I make a "POST" call to "PostWalletFunds" to service "WalletService"
    Then the API call is successful with status code 201


    Examples:
      | xGameId | accountId | batchId | amount | currency | issued  | productId | type | description | autocapture | status | captured |
      | JOKER   | AT_MAIN-1 | 1       | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | true        | TEST   | false    |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"


    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 626.0    | 626.0        | 126.0                   | 0.0              | 500.0                | 540.0    | 540.0        | 40.0                    | 0.0              | 500.0                |


  Scenario Outline: Wager funds - User cannot play for non-exclusive games (SPORTSBOOK)
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Game currently unavailable for player ([Error Id: PLAYER_CONSENT_REQUIRED])"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Wager funds - User cannot play for non-exclusive games (CASINO)
    Given I setup gameId header to "CASINO"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Game currently unavailable for player ([Error Id: PLAYER_CONSENT_REQUIRED])"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | CASINO    | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"


    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 626.0    | 626.0        | 126.0                   | 0.0              | 500.0                | 540.0    | 540.0        | 40.0                    | 0.0              | 500.0                |


    #  User is a member of NEP group only

  Scenario: Get Player Level
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerLevel" of service "PlayerService" with new playerId
    And I make a "GET" call to "GetPlayerLevel" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "accessGroups[0]" in response body is "FULL_ACCOUNT"


  Scenario: Remove the user from EP group && Add user to NEP group
    When I create payload with EpGroup "false" and NepGroup "true"
    And I change url resource of method "AddAndRemoveUsersFromGroups" of service "PlayerService" with new playerId
    And I make a "PUT" call to "AddAndRemoveUsersFromGroups" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "isExclusiveGamesGroupActive" in response body is "false"
    And the "isNonExclusiveGamesGroupActive" in response body is "true"


  Scenario: Get and Verify Role Members
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetRoleMembers" of service "AccessService" with new playerId
    And I make a "GET" call to "GetRoleMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response for Role Members for "NonExclusive"


  Scenario: Deposit via Payment code - Lottery wallet - Negative scenario
    Given I create a Post DepositViaPayment payload for "Lottery Wallet" wallet
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"


  Scenario Outline: Deposit via Payment code - Betting wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
    And the "amount.amount" in response body is "10.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId


    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via paymentCode paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId


  Scenario Outline: Deposit via Card - Lottery wallet (Joker) - Negative scenario
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | amount |
      | 50     |


  Scenario Outline: Deposit via Card - Betting wallet (SPORTSBOOK)
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 50     |

  @skipIfAzure
  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200

    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |


  Scenario: Commit Card Deposit To Tora
#    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId via card


  Scenario Outline: Deposit via Card - Betting wallet (CASINO)
    Given I setup gameId header to "CASINO"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 50     |

  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200

    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |


  Scenario: Commit Card Deposit To Tora
#    And I setup a random deposit token Id
    Given I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId via card


  Scenario Outline: Get and Verify Wallets Balance
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 626.0    | 626.0        | 126.0                   | 0.0              | 500.0                | 650.0    | 650.0        | 150.0                   | 0.0              | 500.0                |


  Scenario Outline: Wager funds - User can play for non-exclusive games (SPORTSBOOK)
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"


    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 626.0    | 626.0        | 126.0                   | 0.0              | 500.0                | 648.0    | 648.0        | 148.0                   | 0.0              | 500.0                |


  Scenario Outline: Wallet funds - User can play for non-exclusive games
    Given I setup gameId header to "<xGameId>"
    When I create a PostWalletFunds payload with "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<batchId>"
    And I change url resource of method "PostWalletFunds" of service "WalletService" with new playerId
    And I make a "POST" call to "PostWalletFunds" to service "WalletService"
    Then the API call is successful with status code 201


    Examples:
      | xGameId | accountId | batchId | amount | currency | issued  | productId | type | description | autocapture | status | captured |
      | CASINO  | AT_MAIN-2 | 1       | -2     | DEFAULT  | datenow | CASINO    | BUY  | Bet         | true        | TEST   | false    |


  Scenario Outline: Get and Verify Wallets Balance
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 626.0    | 626.0        | 126.0                   | 0.0              | 500.0                | 646.0    | 646.0        | 146.0                   | 0.0              | 500.0                |


  Scenario Outline: Wager funds - User cannot play for exclusive games (JOKER)
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Game currently unavailable for player ([Error Id: PLAYER_CONSENT_REQUIRED])"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 626.0    | 626.0        | 126.0                   | 0.0              | 500.0                | 646.0    | 646.0        | 146.0                   | 0.0              | 500.0                |


 #  User is a member of both EP and NEP groups


  Scenario: Get Player Level
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerLevel" of service "PlayerService" with new playerId
    And I make a "GET" call to "GetPlayerLevel" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "accessGroups[0]" in response body is "FULL_ACCOUNT"
    And the "accessGroups[1]" in response body is "NON_EXCLUSIVE_GAMES_ONLY"


  Scenario: Add user to EP and NEP groups
    When I create payload with EpGroup "true" and NepGroup "true"
    And I change url resource of method "AddAndRemoveUsersFromGroups" of service "PlayerService" with new playerId
    And I make a "PUT" call to "AddAndRemoveUsersFromGroups" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "isExclusiveGamesGroupActive" in response body is "true"
    And the "isNonExclusiveGamesGroupActive" in response body is "true"


  Scenario: Get and Verify Role Members
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetRoleMembers" of service "AccessService" with new playerId
    And I make a "GET" call to "GetRoleMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response for Role Members for "ExclusiveAndNonExclusive"

  Scenario Outline: Deposit via Payment code - Lottery wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_EXCLUSIVE"
    And the "amount.amount" in response body is "10.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"


    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 636.0    | 636.0        | 136.0                   | 0.0              | 500.0                | 646.0    | 646.0        | 146.0                   | 0.0              | 500.0                |


  Scenario Outline: Deposit via Payment code - Betting wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
    And the "amount.amount" in response body is "10.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"


    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 636.0    | 636.0        | 136.0                   | 0.0              | 500.0                | 656.0    | 656.0        | 156.0                   | 0.0              | 500.0                |


  Scenario Outline: Deposit via Card - Lottery wallet (JOKER)
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 50     |

  @skipIfAzure
  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId


    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |


  Scenario: Commit Card Deposit To Tora
#    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId via card

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 686.0    | 686.0        | 186.0                   | 0.0              | 500.0                | 656.0    | 656.0        | 156.0                   | 0.0              | 500.0                |


  Scenario Outline: Deposit via Card - Lottery wallet
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 10     |

  @skipIfAzure
  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId

    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 1000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |


  Scenario: Commit Card Deposit To Tora
#    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId via card


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"


    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 686.0    | 686.0        | 186.0                   | 0.0              | 500.0                | 666.0    | 666.0        | 166.0                   | 0.0              | 500.0                |


  Scenario Outline: Deposit via Card - Betting wallet (SPORTSBOOK)
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 10     |

  @skipIfAzure
  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId


    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 1000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |


  Scenario: Commit Card Deposit To Tora
#    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId via card


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 686.0    | 686.0        | 186.0                   | 0.0              | 500.0                | 676.0    | 676.0        | 176.0                   | 0.0              | 500.0                |


  Scenario Outline: Wager funds - User can play for non-exclusive games (SPORTSBOOK)
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 686.0    | 686.0        | 186.0                   | 0.0              | 500.0                | 674.0    | 674.0        | 174.0                   | 0.0              | 500.0                |


  Scenario Outline: Wager funds - User can play for non-exclusive games (CASINO)
    Given I setup gameId header to "CASINO"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | CASINO    | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 686.0    | 686.0        | 186.0                   | 0.0              | 500.0                | 672.0    | 672.0        | 172.0                   | 0.0              | 500.0                |


  Scenario Outline: Wager funds - User can play for exclusive games (JOKER)
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 684.0    | 684.0        | 184.0                   | 0.0              | 500.0                | 672.0    | 672.0        | 172.0                   | 0.0              | 500.0                |


