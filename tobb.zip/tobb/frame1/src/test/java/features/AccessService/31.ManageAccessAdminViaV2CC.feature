#AZURE ONLY
@AccessService
Feature: Manage Access Admin Via V2 CC

  @skipIfNotAzure
  Scenario Outline: Add an AccessAttribute - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    #And the property "valid.from" in response body array with index "<index>" has value "<valid>"
    #And the property "valid.to" in response body array with index "<index>" has value "<valid>"
    #And the property "updated" in response body array with index "<index>" has value "null"
    And the "<index>.created" to include today's date

    Examples:
      | accessType | operationalUnit                                | userId | created | updated | updatedByUserId | operatorId | reason | valid | index | notifyStatus |
      | ALLOW      | adminrest.access-attributes/list.admin/get/WEB | 3-1    |         |         | 3-1             | 0          | Test   | null  | [0]   |              |

  @NoRetry @skipIfNotAzure
  Scenario: Get - Allow AdminAccessAttributes (v2) - USER NOT FOUND
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "test"
    When I make a "GET" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "USER_NOT_FOUND"
    And the "description" in response body is "The specified admin doesn't exist ([Error Id: USER_NOT_FOUND])"

  @skipIfNotAzure
  Scenario: Get - Allow AdminAccessAttributes (v2) - Success
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "1"
    When I make a "GET" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects are greater than 3
#    And the property "operationalUnit" in response body array with index "[0]" contains value "adminrest.access-attributes/list.admin/get/WEB"
#    And the property "operationalUnit" in response body array with index "[7]" contains value "adminrest.access-attributes/item/delete"
#    And the property "operationalUnit" in response body array with index "[3]" contains value "adminrest.access-attributes/item/post"
#    And the property "operationalUnit" in response body array with index "[11]" contains value "api.access-attributes/list/post/WEB"

  @skipIfNotAzure
  Scenario Outline: Add an AccessAttribute - Success
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
   # And the property "valid.from" in response body array with index "<index>" has value "<valid>"
   # And the property "valid.to" in response body array with index "<index>" has value "<valid>"
   # And the property "updated" in response body array with index "<index>" has value "null"
    And the "<index>.created" to include today's date

    Examples:
      | accessType | operationalUnit                                | userId | created | updated | updatedByUserId | operatorId | reason | index | valid | notifyStatus |
      | ALLOW      | adminrest.access-attributes/list.admin/put/WEB | 3-1    |         |         | 3-1             | 0          | Test   | [0]   | null  |              |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Put - Allow AdminAccessAttributes (v2) - Negative Scenarios
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "<adminId>"
    When I make a "PUT" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | adminId | statusCode | errorId               | description                                                    | GherkinDescription |
      | test    | 404        | USER_NOT_FOUND        | The specified admin doesn't exist ([Error Id: USER_NOT_FOUND]) | Invalid User       |
      | 1       | 500        | INTERNAL_SERVER_ERROR | Internal Server Error                                          | Missing Body       |


  @skipIfNotAzure @NoRetry
  Scenario Outline: Put - Allow AdminAccessAttributes (v2) - Wrong Json format
    Given I create an empty payload with header "cc_csrftokenSpec"
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "<adminId>"
    When I make a "PUT" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | adminId | statusCode | errorId      | description        | GherkinDescription    |
      | 1       | 400        | INVALID_JSON | Invalid JSON input | {} and not [] in body |


  @skipIfNotAzure @NoRetry
  Scenario Outline: Put - Allow AdminAccessAttributes (v2) - Empty Array - Success
    Given I create an empty array payload with header "cc_csrftokenSpec"
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "<adminId>"
    When I make a "PUT" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | adminId | statusCode |
      | 1       | 204        |


  @skipIfNotAzure
  Scenario Outline: Add an AccessAttribute - Success
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    #And the property "valid.from" in response body array with index "<index>" has value "<valid>"
    #And the property "valid.to" in response body array with index "<index>" has value "<valid>"
    #And the property "updated" in response body array with index "<index>" has value "null"
    And the "<index>.created" to include today's date

    Examples:
      | accessType | operationalUnit                                | userId | created | updated | updatedByUserId | operatorId | reason | index | valid | notifyStatus |
      | ALLOW      | adminrest.access-attributes/list.admin/put/WEB | 3-1    |         |         | 3-1             | 0          | Test   | [0]   | null  |              |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Put - Allow AdminAccessAttributes (v2) - Success Scenario
    Given I create A PUT AllowAdminAccessAttributes payload with "<operationalUnit>"
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "1"
    When I make a "PUT" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | operationalUnit                             | statusCode |
      | testOpUnit/testOpUnit/testOpUnit/testOpUnit | 204        |

  @skipIfNotAzure
  Scenario Outline: Add an AccessAttribute - Success
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    #And the property "valid.from" in response body array with index "<index>" has value "<valid>"
    #And the property "valid.to" in response body array with index "<index>" has value "<valid>"
    #And the property "updated" in response body array with index "<index>" has value "null"
    And the "<index>.created" to include today's date

    Examples:
      | accessType | operationalUnit                                | userId | created | updated | updatedByUserId | operatorId | reason | index | valid | notifyStatus |
      | ALLOW      | adminrest.access-attributes/list.admin/put/WEB | 3-1    |         |         | 3-1             | 0          | Test   | [0]   | null  |              |

  @skipIfNotAzure @NoRetry
  Scenario Outline: Put - Allow AdminAccessAttributes (v2) - Empty Array - Success
    Given I create an empty array payload with header "cc_csrftokenSpec"
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "<adminId>"
    When I make a "PUT" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | adminId | statusCode |
      | 1       | 204        |

  @skipIfNotAzure
  Scenario Outline: Add an AccessAttribute - Success
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    #And the property "valid.from" in response body array with index "<index>" has value "<valid>"
    #And the property "valid.to" in response body array with index "<index>" has value "<valid>"
    #And the property "updated" in response body array with index "<index>" has value "null"
    And the "<index>.created" to include today's date

    Examples:
      | accessType | operationalUnit                                | userId | created | updated | updatedByUserId | operatorId | reason | index | valid | notifyStatus |
      | ALLOW      | adminrest.access-attributes/list.admin/put/WEB | 3-1    |         |         | 3-1             | 0          | Test   | [0]   | null  |              |


  @skipIfNotAzure @NoRetry
  Scenario Outline: Put - Allow AdminAccessAttributes (v2) - Invalid AccessAttribute
    Given I create A PUT AllowAdminAccessAttributes payload with "<operationalUnit>"
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "<adminId>"
    When I make a "PUT" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | operationalUnit | adminId | statusCode | errorId                  | description                                                                       |
      | test            | 1       | 400        | INVALID_ACCESS_ATTRIBUTE | The specified access attribute is invalid. ([Error Id: INVALID_ACCESS_ATTRIBUTE]) |


  @skipIfNotAzure
  Scenario Outline: Put - Allow AdminAccessAttributes (v2) - Success
    Given I create A PUT AllowAdminAccessAttributes payload with "<operationalUnit>"
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "<adminId>"
    When I make a "PUT" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | operationalUnit     | adminId | statusCode |
      | test.test/test/test | 1       | 204        |

  @skipIfNotAzure
  Scenario Outline: Add an AccessAttribute - Success PUT/GET
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    #And the property "valid.from" in response body array with index "<index>" has value "<valid>"
    #And the property "valid.to" in response body array with index "<index>" has value "<valid>"
    #And the property "updated" in response body array with index "<index>" has value "null"
    And the "<index>.created" to include today's date


    Examples:
      | accessType | operationalUnit                                | userId | created | updated | updatedByUserId | operatorId | reason | index | valid | notifyStatus |
      | ALLOW      | adminrest.access-attributes/list.admin/put/WEB | 3-1    |         |         | 3-1             | 0          | Test   | [0]   | null  |              |
      | ALLOW      | adminrest.access-attributes/list.admin/get/WEB | 3-1    |         |         | 3-1             | 0          | Test   | [0]   | null  |              |

  @skipIfNotAzure
  Scenario: Get - Allow AdminAccessAttributes (v2) - Success
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AllowAdminAccessAttributes" of service "AccessService" with configured adminId "1"
    When I make a "GET" call to "AllowAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    And the property "operationalUnit" in response body array with index "[0]" contains either of the values "adminrest.access-attributes/list.admin/"
    And the property "operationalUnit" in response body array with index "[1]" contains either of the values "adminrest.access-attributes/list.admin/"
    And the property "operationalUnit" in response body array with index "[2]" contains either of the values "test.test/test/test"

  @skipIfNotAzure
  Scenario Outline: Get AccessAttributes - Success ( The test unit)
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"
    #And the property "valid.from" in response body array with index "<index>" has value "<validFrom>"
    #And the property "valid.to" in response body array with index "<index>" has value "<validTo>"
    And the "<index>.created" to include today's date
    And the "<index>.updated" to include today's date


    Examples:
      | keys                   | values                  | userId | updatedByUserId | operatorId | reason | index | accessType | operationalUnit     | validFrom | validTo |
      | userId,operationalUnit | 3-1,test.test/test/test | 3-1    | 3-1             | 0          |        | [0]   | ALLOW      | test.test/test/test | null      | null    |

  Scenario: Delete Current Session - Logout CC
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "DEL" call to "DeleteCurrentSession" to service "AccessService"
    Then the API call is successful with status code 204
