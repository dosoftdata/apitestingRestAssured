#For Azure some 500 codes have been written because there is no configuration for external provider plus this is
  #is a deprecated feature that will be removed in the future.
@AccessService @NoRetry @ExternalProvider
Feature: External Provider

  # /randomProvider/start
  Scenario: Login External Provider - Random Provider Start (Provider Not found)
    Given I login as a "newPlayerWeb" user
    Given I create a Get "mainSpec" header
    When I make a "POST" call to "LoginExternalRandomProviderStart" to service "AccessService"
    Then the API call is successful with status code 404

  #/testProvider/start
  Scenario Outline: Login External Provider (testProvider) - Missing Body
    Given I create a Get "mainSpec" header
    When I make a "POST" call to "LoginExternalTestProviderStart" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    @skipIfAzure
    Examples:
      | statusCode |
      | 404        |

    @skipIfNotAzure
    Examples:
      | statusCode |
      | 500        |


  #/testProvider/start
  Scenario Outline: Login External Provider (testProvider) - Invalid Target
    Given I create a LoginExternal Post payload with "<target>"
    When I make a "POST" call to "LoginExternalTestProviderStart" to service "AccessService"
    Then the API call is successful with status code <statusCode>


    @skipIfAzure
    Examples:
      | target     | statusCode |
      | testTarget | 404        |

    @skipIfNotAzure
    Examples:
      | target     | statusCode |
      | testTarget | 500        |


      #/testProvider/start
  Scenario Outline: Login External Provider (testProvider) - Unrecognized Property
    Given I create a LoginExternal WrongRequest Post payload with "<request>"
    When I make a "POST" call to "LoginExternalTestProviderStart" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<errorDescription>"

    Examples:
      | errorId      | errorDescription   | request                                                                                                                                |
      | INVALID_JSON | Invalid JSON input | {\"target\":{\"startTarget\":\"\",\"finishTarget\":\"\",\"ssnValidationTarget\":\"\",\"cookieForwarder\":\"\",\"validStatuses\":\"\"}} |



    #/testProvider/start
  Scenario Outline: Login External Provider (testProvider) - Unrecognized Property
    Given I create a LoginExternal WrongRequest Post payload with "<request>"
    When I make a "POST" call to "LoginExternalTestProviderStart" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<errorDescription>"


    Examples:
      | errorId      | errorDescription                    | request                                                                                                                                                                                                |
      | INVALID_JSON | Unrecognized property in JSON input | {\"target\":\"test/test\",\"channel\":\"WEB\",\"subChannel\":\"\"}                                                                                                                                     |
      | INVALID_JSON | Invalid JSON input                  | {\"target\":\"test/test\",\"target\":{\"startTarget\":\"\",\"finishTarget\":\"\",\"ssnValidationTarget\":\"\",\"cookieForwarder\":\"\",\"validStatuses\":\"\"}\"channel\":\"WEB\",\"subchannel\":\"\"} |


    #/randomProvider/finish
  Scenario: Login External Provider Random Provider Pending  - Complete a login flow with an external provider - Provider not found
    Given I create a Get "mainSpec" header
    When I make a "POST" call to "LoginExternalRandomProviderFinish" to service "AccessService"
    Then the API call is successful with status code 404



  #/testProvider/finish
  Scenario Outline: Login External Provider Test Provider Pending - Complete a login flow with an external provider - Provider not found 2
    Given I create a Get "mainSpec" header
    When I make a "POST" call to "LoginExternalTestProviderFinish" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    @skipIfAzure
    Examples:
      | statusCode |
      | 404        |

    @skipIfNotAzure
    Examples:
      | statusCode |
      | 400        |


  #/randomProvider/pending/ssn
  Scenario: Login External Provider Random Provider Pending  - Map a customer to an Id provided by an external provider and logs in the customer - Provider not found
    Given I create a Get "mainSpec" header
    When I make a "POST" call to "LoginExternalRandomProviderPending" to service "AccessService"
    Then the API call is successful with status code 404


  #/testProvider/pending/ssn
  Scenario Outline: Login External Provider Test Provider Pending - Map a customer to an Id provided by an external provider and logs in the customer - No pending external userId
    Given I create a LoginExternal Pending Post payload with "<ssn>"
    When I make a "POST" call to "LoginExternalTestProviderPending" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    @skipIfAzure
    Examples:
      | ssn     | statusCode |
      | testSSN | 404        |

    @skipIfNotAzure
    Examples:
      | ssn     | statusCode |
      | testSSN | 400        |