@AccessService
Feature: Get Access Rights Via V1 CC Endpoints

  @NoRetry
  Scenario: Get administrator's access rights - Invalid adminId
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetAdminAccessAttributes" of service "AccessService" with configured adminId "test"
    When I make a "GET" call to "GetAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

  @NoRetry
  Scenario: Get administrator's access rights - Too long adminId
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetAdminAccessAttributes" of service "AccessService" with configured adminId "453463563563576467346865785657857876846145346356356357467346865785657857876846145346356356357646734686578565785787684614534635635635764673468657856578578768461453463563563574673468657856578578768461453463563563576467346865785657857876846"
    When I make a "GET" call to "GetAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

  @NoRetry
  Scenario: Get administrator's access rights
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetAdminAccessAttributes" of service "AccessService" with configured adminId "1"
    When I make a "GET" call to "GetAdminAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 50
    And I log response's info

  @NoRetry
  Scenario: Get CustomerAccessAttributes - Operational Unit does not exist
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured playerId "1"
    And I change url resource of method "CustomerAccessAttributes" of service "AccessService" with configured parameter "operationalUnit" "test"
    When I make a "GET" call to "CustomerAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

  @NoRetry
  Scenario: Get CustomerAccessAttributes - Customer does not exist
    Given I create a Get "cc_csrftokenSpec" header
   And I change url resource of method GetCustomerAccessRights "GetCustomerAccessRights" of service "AccessService" with configured playerId "test"
    When I make a "GET" call to "GetCustomerAccessRights" to service "AccessService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

  @NoRetry
  Scenario: Get CustomerAccessAttributes - Access attribute not found
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method GetCustomerAccessRights "GetCustomerAccessRights" of service "AccessService" with configured playerId ""
    When I make a "GET" call to "GetCustomerAccessRights" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ACCESS_ATTRIBUTE_NOT_FOUND"
    And the property "description" includes value "Unable to get access attributes for customer with id: {0} ([Error Id: ACCESS_ATTRIBUTE_NOT_FOUND]"

  @NoRetry
  Scenario: Get CustomerAccessAttributes - Invalid playerId for this access attribute
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetCustomerAccessRightsView" of service "AccessService" with new playerId
    When I make a "GET" call to "GetCustomerAccessRightsView" to service "AccessService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ACCESS_ATTRIBUTE_NOT_FOUND"
    And the property "description" includes value "Unable to get access attributes for customer with id: {0} ([Error Id: ACCESS_ATTRIBUTE_NOT_FOUND]"

  Scenario: Delete Current Session - LogOut
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "DEL" call to "DeleteCurrentSession" to service "AccessService"
    Then the API call is successful with status code 204

  Scenario: Delete Current Session - Already Loggged Out
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "DEL" call to "DeleteCurrentSession" to service "AccessService"
    Then the API call is successful with status code 204