@AccessService
Feature: Remember Me

#  Login, Logout, VerifySession

  Scenario Outline: Login New - Login, Logout, VerifySession
    Given I create a POST LoginNew payload including RememberMe with "<username>" "<password>" "<group>" "<channel>" "<rememberMe>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code 200

    Examples:
      | username     | password     | group | channel | rememberMe |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | true       |

  Scenario: Get Player's Legacy Wallet
    And I create a Get "mainSpec" header
    And I clear all cookies from CookieStore
    And I change url resource of method "GetPlayerLegacyWallet" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerLegacyWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "buyingPower" in response body exists
    And the "reservedBalance" in response body exists
    And the "withdrawableBalance" in response body exists
    And the "nonWithdrawableBalance" in response body exists
    And the "balance" in response body exists
    And the "currency" in response body exists
    And the "AT_MAIN-0" in response body exists


  Scenario: Get Player's Lottery Wallet
    And I create a Get "mainSpec" header
    And I change url resource of method "GetPlayerLotteryWallet" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerLotteryWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "buyingPower" in response body exists
    And the "reservedBalance" in response body exists
    And the "withdrawableBalance" in response body exists
    And the "nonWithdrawableBalance" in response body exists
    And the "balance" in response body exists
    And the "currency" in response body exists
    And the "AT_MAIN-1" in response body exists


  Scenario: Get Player's Betting Wallet
    And I create a Get "mainSpec" header
    And I change url resource of method "GetPlayerBettingWallet" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerBettingWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "buyingPower" in response body exists
    And the "reservedBalance" in response body exists
    And the "withdrawableBalance" in response body exists
    And the "nonWithdrawableBalance" in response body exists
    And the "balance" in response body exists
    And the "currency" in response body exists
    And the "AT_MAIN-2" in response body exists


  Scenario: Get - GetSessionMinutesWeb
    Given I create a Get "mainspec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with configured parameter "playerIdCustomers" "playerIdCustomer"
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 200
    And the "loginTime" in response body exists

#  Scenario: Get Player
#    Given I create a Get "mainspec" header
#    And I change url resource of method "GetPlayer" of service "PlayerService" with new playerId
#    When I make a "GET" call to "GetPlayer" to service "PlayerService"
#    Then the API call is successful with status code 200

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @NoRetry
  Scenario: Get - GetSessionMinutesWeb
    Given I create a Get "mainspec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 401


    #  Login, DeleteCookies, Check that cookies are created again

  Scenario Outline: Login New - Login, DeleteCookies, Check that cookies are created again
    Given I create a POST LoginNew payload including RememberMe with "<username>" "<password>" "<group>" "<channel>" "<rememberMe>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code 200

    Examples:
      | username     | password     | group | channel | rememberMe |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | true       |

  Scenario: Get Player's Legacy Wallet
    And I create a Get "mainSpec" header
    And I change url resource of method "GetPlayerLegacyWallet" of service "WalletService" with new playerId
    And I clear all cookies from CookieStore
    And I make a "GET" call to "GetPlayerLegacyWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that JSessionId exists

  Scenario: Get - GetSessionMinutesWeb
    Given I create a Get "mainspec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with configured parameter "playerIdCustomers" "playerIdCustomer"
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 200
    And the "loginTime" in response body exists

#  Scenario: Get Player
#    Given I create a Get "mainspec" header
#    And I change url resource of method "GetPlayer" of service "PlayerService" with new playerId
#    When I make a "GET" call to "GetPlayer" to service "PlayerService"
#    Then the API call is successful with status code 200

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @NoRetry
  Scenario: Get - GetSessionMinutesWeb
    Given I create a Get "mainspec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 401

#    Login, Wait, Check session time

  Scenario Outline: Login New - Login, Wait, Check session time
    Given I create a POST LoginNew payload including RememberMe with "<username>" "<password>" "<group>" "<channel>" "<rememberMe>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code 200

    Examples:
      | username     | password     | group | channel | rememberMe |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | true       |

  Scenario: Get Player's Legacy Wallet
    And I create a Get "mainSpec" header
    And I change url resource of method "GetPlayerLegacyWallet" of service "WalletService" with new playerId
    And I clear all cookies from CookieStore
    And I make a "GET" call to "GetPlayerLegacyWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "buyingPower" in response body exists
    And the "reservedBalance" in response body exists
    And the "withdrawableBalance" in response body exists
    And the "nonWithdrawableBalance" in response body exists
    And the "balance" in response body exists
    And the "currency" in response body exists

  Scenario: Get - GetSessionMinutesWeb
    Given I create a Get "mainspec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with configured parameter "playerIdCustomers" "playerIdCustomer"
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 200
    And the "loginTime" in response body exists


#  Scenario: Get Player
#    Given I create a Get "mainspec" header
#    And I change url resource of method "GetPlayer" of service "PlayerService" with new playerId
#    When I make a "GET" call to "GetPlayer" to service "PlayerService"
#    Then the API call is successful with status code 200

  Scenario: Get - GetSessionMinutesWeb - Before rememberMe session expires
    Given I create a Get "mainspec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with configured parameter "playerIdCustomers" "playerIdCustomer"
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 200
    And the "loginTime" in response body exists

#  @NoRetry
#  Scenario: Get - GetSessionMinutesWeb - After rememberMe session has expired
#    Given I add 620 seconds delay
#    Given I create a Get "mainspec" header
#    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
#    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
#    Then the API call is successful with status code 401

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

# Login-norememberMe, Logout, Verify cookies

  Scenario Outline: Login New - Login-norememberMe, Logout, Verify cookies
    Given I create a POST LoginNew payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | username     | password     | group | channel | statusCode |
      | newPlayerWeb | Qwerty12345! | EP    | WEB      | 200        |

  Scenario: Get Player's Legacy Wallet
#    Given I login as a "newPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "GetPlayerLegacyWallet" of service "WalletService" with new playerId
    And I clear all cookies from CookieStore
    And I make a "GET" call to "GetPlayerLegacyWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "buyingPower" in response body exists
    And the "reservedBalance" in response body exists
    And the "withdrawableBalance" in response body exists
    And the "nonWithdrawableBalance" in response body exists
    And the "balance" in response body exists
    And the "currency" in response body exists

  Scenario: Get - GetSessionMinutesWeb
    Given I create a Get "mainspec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with configured parameter "playerIdCustomers" "playerIdCustomer"
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 200
    And the "loginTime" in response body exists

#  Scenario: Get Player
#    Given I create a Get "mainspec" header
#    And I change url resource of method "GetPlayer" of service "PlayerService" with new playerId
#    When I make a "GET" call to "GetPlayer" to service "PlayerService"
#    Then the API call is successful with status code 200

  Scenario: Logout player
    And I create a Get "specWithOrigin" header
    When I make a "DEL" call to "LogOut" to service "AccessService"
    Then the API call is successful with status code 204

  @NoRetry
  Scenario: Get - GetSessionMinutesWeb
    Given I create a Get "mainspec" header
    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
    Then the API call is successful with status code 401

#    Login, Wait for clean up task to run

  Scenario Outline: Login New - Login, Wait for clean up task to run
    Given I create a POST LoginNew payload including RememberMe with "<username>" "<password>" "<group>" "<channel>" "<rememberMe>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code 200

    Examples:
      | username     | password     | group | channel | rememberMe |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | true       |

#  @NoRetry
#  Scenario: Get - GetSessionMinutesWeb
#    Given I add 620 seconds delay
#    And I create a Get "mainspec" header
#    And I change url resource of method "GetSessionMinutesWeb" of service "AccessService" with new playerId
#    When I make a "GET" call to "GetSessionMinutesWeb" to service "AccessService"
#    Then the API call is successful with status code 401

