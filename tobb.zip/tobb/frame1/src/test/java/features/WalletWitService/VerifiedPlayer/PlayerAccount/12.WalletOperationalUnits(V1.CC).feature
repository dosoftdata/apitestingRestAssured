#AZURE ONLY FEATURE
@WalletWitService @skipIfNotAzure @VerifiedAccountSetup
Feature: Wallet Operational Units Via v1.CC


  @NoRetry
  Scenario: Post access operations V2 - Set status of wallet operational units via v2.CC - Missing body - Negative Scenario
    Given I create an empty payload with header "cc_csrftokenSpec"
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 400


  #Retest
  @NoRetry
  Scenario Outline: Post access operations V2 - "Set status of wallet operational units via v2.CC - Invalid values
    Given I create a POST AccessOperations payload with "<buyListId>" "<buyListAccessType>" "<payoutListId>" "<payoutListAccessType>" "<depositListId>" "<depositListAccessType>" "<withdrawListId>" "<withdrawListAccessType>" "<reason>"
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

    Examples:
      | buyListId | buyListAccessType | payoutListId | payoutListAccessType | depositListId | depositListAccessType | withdrawListId | withdrawListAccessType | reason |
      | {}        | {}                |              |                      |               |                       |                |                        |        |

  #Retest
  Scenario Outline: Post access operations V2 - "Set status of wallet operational units via v2.CC - Empty array
    Given I create a POST AccessOperations payload with "<buyListId>" "<buyListAccessType>" "<payoutListId>" "<payoutListAccessType>" "<depositListId>" "<depositListAccessType>" "<withdrawListId>" "<withdrawListAccessType>" "<reason>"
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    #+ assertions

    Examples:
      | buyListId | buyListAccessType | payoutListId | payoutListAccessType | depositListId | depositListAccessType | withdrawListId | withdrawListAccessType | reason |
      |           |                   |              |                      |               |                       |                |                        | test   |


    #############STUBS#########################

  Scenario Outline: Wiremock Stub - Access-service responding with 500
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                  | status | headers          | body                                                                    |
      | AccessServiceResponse500 | Started               | 100      | ANY    | /api/access/rest/v1/accessattributes | 500    | application/json | {\"errorId\":\"TEST_RESPONSE_500\",\"description\": \"This is a test\"} |


  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200


  ########################################

  #Retest
  @NoRetry
  Scenario Outline: Post access operations V2 - Set status of wallet operational units via v2.CC - Access Service not responding (communication error)
    Given I create a POST AccessOperations payload with "<buyListId>" "<buyListAccessType>" "<payoutListId>" "<payoutListAccessType>" "<depositListId>" "<depositListAccessType>" "<withdrawListId>" "<withdrawListAccessType>" "<reason>"
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | buyListId | buyListAccessType | payoutListId | payoutListAccessType | depositListId | depositListAccessType | withdrawListId | withdrawListAccessType | reason |
      | 123       | DENY              | 123          | ALLOW                | 123           | DENY                  | 123            | ALLOW                  | test   |


        #############STUBS#########################

  Scenario Outline: Wiremock Stub - Access-service responding with 400
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                                  | status | headers          | body                                                                    |
      | AccessServiceResponse400 | Started               | 100      | ANY    | /api/access/rest/v1/accessattributes | 400    | application/json | {\"errorId\":\"TEST_RESPONSE_400\",\"description\": \"This is a test\"} |

    #######################################################

    #Retest
  @NoRetry
  Scenario Outline: Post access operations V2 - Set status of wallet operational units via v2.CC - Access Service not responding (bad request error)
    Given I create a POST AccessOperations payload with "<buyListId>" "<buyListAccessType>" "<payoutListId>" "<payoutListAccessType>" "<depositListId>" "<depositListAccessType>" "<withdrawListId>" "<withdrawListAccessType>" "<reason>"
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | buyListId | buyListAccessType | payoutListId | payoutListAccessType | depositListId | depositListAccessType | withdrawListId | withdrawListAccessType | reason |
      | 123       | DENY              | 123          | ALLOW                | 123           | DENY                  | 123            | ALLOW                  | test   |


        #############STUBS#########################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200
