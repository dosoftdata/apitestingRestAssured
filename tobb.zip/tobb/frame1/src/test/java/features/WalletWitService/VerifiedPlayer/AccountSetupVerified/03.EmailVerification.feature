@WalletWitService @VerifiedAccountSetup
Feature: Email Verification

  Scenario Outline: Get MailId For Fetch Hash - Verify origin has value player
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "<array>" is 1
    And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
    And I copy the value of the mailId from the response

    Examples:
      | key      | value    | property | propertyValue | array | arrayWithIndex |
      | playerId | changeit | origin   | player        | data  | data[0]        |

  Scenario Outline: Get hash For Mail Verification - Verify event name/owner
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetHashForMailVerification" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the "<property>" in response body is "<propertyValue>"
    And the "<property2>" in response body is "<propertyValue2>"
    And the id in response body is mailIdForHash
    And I copy the value of the hash from the response

    Examples:
      | property  | propertyValue                       | property2  | propertyValue2 |
      | eventName | registrationWelcomeEvent.opaponline | eventOwner | player         |

  Scenario: Verify Player's Email - Call to verify player's email
    Given I create a VerifyEmail payload with inner playerId and hash
    When I make a "POST" call to "VerifyPlayersEmail" to service "PlayerService"
    Then the API call is successful with status code 204

