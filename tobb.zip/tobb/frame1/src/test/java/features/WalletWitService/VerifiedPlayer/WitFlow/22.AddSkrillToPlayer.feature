#IN PROGRESS
#@WalletWitService
Feature: Add Skrill To Player


  Scenario Outline: Commit Payment Method - Skrill
    Given I login as an Api user
    When I create a PUT CommitPaymentMethod payload with "<serviceProviderId>" "<paymentMethodType>" "<directionIn>" "<paymentMethodId>" "<serviceProviderTargetId>" "<email>" "<createdById>" <createdByType> "<updatedById>" <updatedByType>
    And I change url resource of method "CommitSkrillToWallet" of service "WalletService" with new playerId
    And I make a "PUT" call to "CommitSkrillToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceProviderId | paymentMethodType | directionIn | paymentMethodId | serviceProviderTargetId | email             | createdById  | createdByType | updatedById  | updatedByType |
      | TORA              | 8                 | 1           | SKRILL_IN       | SKRILL                  | uattest22@opap.gr | newPlayerWeb | 1             | newPlayerWeb | 1             |


  Scenario: Get and Verify Payment Codes Web - Success Scenario
    Given I login as a "newPlayerWeb" user
    When I create a Get "mainSpec" header
    And I change url resource of method "GetPaymentCodesWeb" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodesWeb" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 6
    # + some assertions



 #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |


