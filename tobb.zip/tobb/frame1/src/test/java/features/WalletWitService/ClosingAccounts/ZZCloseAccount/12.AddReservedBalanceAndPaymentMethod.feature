@WalletWitService
Feature: Add Reserved Balance And Payment Method

  @skipIfNotAzure
  Scenario Outline: DatabaseBridge - Update Query in PLCONTRACTAGREEMENT
    Given I create a DataBridge Payload with "<query>"
    When I make a "POST" call to "DatabaseExecute" to service "DatabaseBridgeService"
    Then the API call is successful with status code 200

    Examples:
      | query                                                                                           |
      | UPDATE PLRCONTRACTAGREEMENTS SET STATUS='VALID' WHERE STATUS='REVOKED' AND PLAYERID=newPlayerId |


  Scenario Outline: Create a buy transaction (MANUAL ADJUST) - Betting Wallet  (+Reserved)
    Given I create a CreateBettingTransaction payload with "<issued>" <prizeLevel> "<type>" "<amount>" "<productId>" "<currency>" "<description>" "<fromDescription>" "<toDescription>" "<state>" "<batchId>" "<subBatchId>" "<transactionId>" "<callerServiceProviderId>" <autocapture> "<metadataValue>"
    And I change url resource of method "CreateBettingTransaction" of service "WalletService" with new playerId
    When I make a "POST" call to "CreateBettingTransaction" to service "WalletService"
    Then the API call is successful with status code 201


    Examples:
      | issued  | prizeLevel | type          | amount | productId | currency | description      | fromDescription | toDescription | state     | batchId     | subBatchId     | transactionId     | callerServiceProviderId     | autocapture | metadataValue      |
      | datenow | 1          | MANUAL_ADJUST | 1      | JOKER     | EUR      | Transaction: Buy | fromDescription | toDescription | testState | testBatchId | testSubBatchId | testTransactionId | testCallerServiceProviderId | true        | below-zero-allowed |
      | datenow | 1          | MANUAL_ADJUST | -1     | JOKER     | EUR      | Transaction: Buy | fromDescription | toDescription | testState | testBatchId | testSubBatchId | testTransactionId | testCallerServiceProviderId | false       | below-zero-allowed |


  Scenario Outline: Get and Verify Wallets Balance
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 1.0      | 1.0          | 0.0                     | 0.0              | 1.0                  | 120.0    | 120.0        | 70.0                    | 0.0              | 50.0                 |


  Scenario Outline: Deposit via Card - Lottery wallet (Joker) - Success
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 100    |


  Scenario: Commit Card Deposit To Tora
    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  # CLOSES ACCOUNT careful there
  # fix userType
  Scenario Outline: Close Account v4 - 200 - OPEN_PAYMENTS_EXIST
    Given I create a CloseAccountV4 Put payload with "<status>" "<statusDescription>" "<statusReason>"
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with configured parameter "userType" "1"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with new playerId
    When I make a "PUT" call to "CloseAccountV4" to service "WalletService"
    Then the API call is successful with status code 200
    And the property "reason" in response body array with index "reasons[0]" has value "OPEN_PAYMENTS_EXIST"
    And the "closeable" in response body is "false"


    Examples:

      | keys                     | values                          | status | statusDescription | statusReason   |
      | statusReason,playerLevel | SELF_EXCLUSION,VERIFIED_ACCOUNT | CLOSED | test              | SELF_EXCLUSION |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 1.0      | 1.0          | 0.0                     | 0.0              | 1.0                  | 220.0    | 220.0        | 170.0                   | 0.0              | 50.0                 |


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId via card


  Scenario Outline: Deposit via Card - Lottery wallet (Joker) - Success
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 100    |

  Scenario: Commit Card Deposit To Tora
    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card




  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 1.0      | 1.0          | 0.0                     | 0.0              | 1.0                  | 320.0    | 320.0        | 270.0                   | 0.0              | 50.0                 |


      # CLOSES ACCOUNT careful there
  # fix userType
  Scenario Outline: Close Account v4 - 200 - OPEN_PAYMENTS_EXIST
    Given I create a CloseAccountV4 Put payload with "<status>" "<statusDescription>" "<statusReason>"
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with configured parameter "userType" "1"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with new playerId
    When I make a "PUT" call to "CloseAccountV4" to service "WalletService"
    Then the API call is successful with status code 200
    And the property "reason" in response body array with index "reasons[0]" has value "PAYMENT_METHOD_NOT_REGISTERED"
    And the property "reason" in response body array with index "reasons[1]" has value "PAYMENT_METHOD_NOT_REGISTERED"
    And the "closeable" in response body is "false"
    #check boolean other way if not working


    Examples:

      | keys                     | values                          | status | statusDescription | statusReason   |
      | statusReason,playerLevel | SELF_EXCLUSION,VERIFIED_ACCOUNT | CLOSED | test              | SELF_EXCLUSION |