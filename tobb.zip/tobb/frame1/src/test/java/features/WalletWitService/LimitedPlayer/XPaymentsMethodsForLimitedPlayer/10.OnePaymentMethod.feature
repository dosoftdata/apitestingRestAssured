@LimitedAccountSetup @skipIfNotAzure @WalletWitService
Feature:One Payment Method

  Scenario: Get and Verify Payment Codes Web - Success Scenario
    Given I login as a "newPlayerWeb" user
    When I create a Get "mainSpec" header
    And I change url resource of method "GetPaymentCodesWeb" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodesWeb" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
#    And the property "paymentMethodId" in response body array with index "data[0]" contains either of the values "PAYMENT_CODE_EXCLUSIVE,PAYMENT_CODE_NON_EXCLUSIVE"

  Scenario Outline: Get and Verify - Wallets Balance
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
#    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
#    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 20.0     | 20.0         | 20.0                    | 0.0              | 0.0                  | 20.0     | 20.0         | 20.0                    | 0.0              | 0.0                  |

  Scenario Outline: Get latest verified deposit in exclusive wallet - No such amount
    Given I setup gameId header to "JOKER"
    Given I create a Get "specWithGameIdOrigin" header with query params "<keys>" "<values>"
    And I change url resource of method "GetQuickDeposit" of service "WalletService" with new playerId
    When I make a "GET" call to "GetQuickDeposit" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethodInfo" in response body has value null

    Examples:
      | keys   | values |
      | amount | -5     |

  Scenario Outline: Get latest verified deposit in exclusive wallet - Positive amount??
    Given I setup gameId header to "JOKER"
    Given I create a Get "specWithGameIdOrigin" header with query params "<keys>" "<values>"
    And I change url resource of method "GetQuickDeposit" of service "WalletService" with new playerId
    When I make a "GET" call to "GetQuickDeposit" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethodInfo" in response body has value null

    Examples:
      | keys   | values |
      | amount | 5      |

  Scenario Outline: Prepare deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card

    Examples:
      | amount |
      | 100    |

  Scenario Outline: Get latest verified deposit in exclusive wallet - Account not defined
    Given I setup gameId header to "JOKER"
    Given I create a Get "specWithGameIdOrigin" header with query params "<keys>" "<values>"
    And I change url resource of method "GetQuickDeposit" of service "WalletService" with new playerId
    When I make a "GET" call to "GetQuickDeposit" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "ACCOUNT_NOT_DEFINED"
    And the "description" in response body is "No account was found matching the specified product."

    Examples:
      | keys   | values |
      | amount | 5      |

  Scenario Outline: Get latest verified deposit in exclusive wallet - No approved or verified payment in legacy wallet
    Given I setup gameId header to "JOKER"
    Given I create a Get "specWithGameIdOrigin" header with query params "<keys>" "<values>"
    And I change url resource of method "GetQuickDeposit" of service "WalletService" with new playerId
    When I make a "GET" call to "GetQuickDeposit" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethodInfo" in response body has value null

    Examples:
      | keys   | values |
      | amount | 5      |

  Scenario Outline: Get latest verified deposit in exclusive wallet - No approved or verified payment in exclusive wallet
    Given I setup gameId header to "JOKER"
    Given I create a Get "specWithGameIdOrigin" header with query params "<keys>" "<values>"
    And I change url resource of method "GetQuickDeposit" of service "WalletService" with new playerId
    When I make a "GET" call to "GetQuickDeposit" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethodInfo" in response body has value null

    Examples:
      | keys   | values |
      | amount | 5      |

  Scenario Outline: Get latest verified deposit in exclusive wallet - No approved or verified payment in non-exclusive wallet
    Given I setup gameId header to "JOKER"
    Given I create a Get "specWithGameIdOrigin" header with query params "<keys>" "<values>"
    And I change url resource of method "GetQuickDeposit" of service "WalletService" with new playerId
    When I make a "GET" call to "GetQuickDeposit" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethodInfo" in response body has value null

    Examples:
      | keys   | values |
      | amount | 5      |

  Scenario: Commit Card Deposit To Tora
    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via paymentCode paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId

  Scenario: Commit Card Deposit To Tora
    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card




  Scenario Outline: Manual adjustment for Deposit in Lottery wallet via BO - Non-withdrawable
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Lottery wallet"
    When I change url resource of method "ManualAdjustLotteryWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustLotteryWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "operation" in response body is "<operation>"
    And the "amount" in response body is "<amount>"

    Examples:
      | transactionType                   | transactionSubType | productId | operation | amount |
      | TT_MANUAL_ADJUST_NON_WITHDRAWABLE | MFDD               | JOKER     | WITHDRAWAL   | 99.80  |

  Scenario Outline: Get latest verified deposit in exclusive wallet - No approved or verified payment in non-exclusive wallet
    Given I setup gameId header to "JOKER"
    Given I create a Get "specWithGameIdOrigin" header with query params "<keys>" "<values>"
    And I change url resource of method "GetQuickDeposit" of service "WalletService" with new playerId
    When I make a "GET" call to "GetQuickDeposit" to service "WalletService"
    Then the API call is successful with status code 200

    Examples:
      | keys   | values |
      | amount | 5      |

  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via paymentCode paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId



  Scenario Outline: Get Uploaded documents - Verify Card Documents (CARD_FRONT)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUploadedDocuments" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetUploadedDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Uploaded Documents with "<types>" "<fileName>" "<fileType>"

    Examples:
      | types      | fileName    | fileType   |
      | CARD_FRONT | IDfront.JPG | image/jpeg |

  Scenario Outline: Get BO Pending Verifications of Player - Verify IBAN values
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Iban Pending Verification with status "<status1>" or status "<status2>" and iban "<iban>"

    Examples:
      | key              | value | status1 | status2     | iban                        |
      | verificationType | IBAN  | PENDING | IN_PROGRESS | GR2202655559367039137283047 |

  Scenario Outline: Verify Card Documents - CARD BACK
    When I create a VerifyDocuments payload with "<verificationType>" "<statusDescription>" and subcategory "<subType>"
    And I change url resource of method "VerifyDocuments" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerifyDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "verificationType" in response body is "<verificationType>"
    And the "documentType" in response body is "<documentTypeResponse>"
    And the "statusDescription" in response body is "<statusDescription>"
    And the "status" in response body is "<statusValue>"

    Examples:
      | verificationType | statusDescription                  | subType | statusValue | documentTypeResponse |
      | CARD             | Approve uploaded document for Card | BACK    | APPROVED    | CARD_BACK            |
