@WalletWitService
Feature: Deposit Via Paypal

  @skipIfNotAzure
  Scenario: Reset Scenarios
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllScenarios" to service "WiremockService"
    Then the API call is successful with status code 200

  @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

 #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

# cardfingerprint isn't used here but it doesn't matter cause it's not in body.
# variables :
# randomId
#deposit_paymentId
#playerId
  @skipIfNotAzure
  Scenario Outline: Tora Response 200 for Deposits via Paypal
    Given I setup deposit paymentId "<paymentId>" and card fingerprint "<cardFingerprint1>"
    And I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | paymentId | cardFingerprint1                                                 | scenarioName            | requiredScenarioState | priority | method | url          | status | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | headers          |
      | random    | 5a8c3cec619b62ed3b4b4d98f1b57ae0fa3f4b65ca483a0954f0e6c885724566 | ToraDepositsResponse200 | Started               | 100      | ANY    | /v1/payments | 400    | {\"id\":\"pmt_IEuiimeTppo4AZIHKsK{{randomId}}\",\"object\":\"payment\",\"captured\":true,\"amount\":5000,\"currency\":\"EUR\",\"description\":\"OPAP wallet deposit id:{{deposit_paymentId}}\",\"meta\":{\"paymentId\":\"{{deposit_paymentId}}\",\"playerId\":\"{{playerId}}\"},\"status\":\"captured\",\"merchant_reference\":\"paymentId:{{deposit_paymentId}}\",\"customer\":null,\"method\":\"paypalorder\",\"method_info\":{\"email\":\"walletinterfacetora@mailsac.com\", \"payer_id\": \"SotirisWit\", \"full_name\": \"Pam Platform\", \"country\": \"GR\", \"address_line_1\": \"Athens City\", \"admin_area_1\": \"test1\", \"admin_area_2\": \"test2\", \"postal_code\": \"11111\"},\"created_at\":\"2019-02-25T13:36:14+00:00\",\"updated_at\":\"2019-02-25T13:36:15+00:00\",\"captured_at\":\"2019-02-25T13:36:15+00:00\",\"refunded\":false,\"refunds\":[],\"refunded_amount\":\"0\",\"fee_amount\":0,\"error_code\":null,\"error_message\":null,\"transaction_id\":\"charge_test_0C2919DE543J66FAA618\"} | application/json |


# cardfingerprint isn't used here but it doesn't matter cause it's not in body.
# variables :
# randomId
#deposit_paymentId
#playerId
  @skipIfNotAzure
  Scenario Outline: Tora response 200 for Deposits Token
    Given I setup deposit paymentId "<paymentId>" and card fingerprint "<cardFingerprint1>"
    And I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | paymentId | cardFingerprint1                                                 | scenarioName              | requiredScenarioState | priority | method | url             | status | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | headers          |
      | random    | 5a8c3cec619b62ed3b4b4d98f1b57ae0fa3f4b65ca483a0954f0e6c885724566 | ToraDepositsToken200Card1 | Started               | 100      | ANY    | .*tokens/ppo_.* | 400    | {\"id\":\"ppo_IEuiimeTppo4AZIHKsK{{randomId}}\",\"object\":\"token\",\"status\":\"captured\", \"is_used\":false,\"amount\": \"5000\",\"currency\":\"EUR\",\"description\":\"OPAP wallet deposit id:{{deposit_paymentId}}\", \"type\": \"paypalorder\", \"merchant_reference\":\"{{deposit_paymentId}}\", \"created_at\":\"2019-02-25T13:36:14+00:00\",\"expires_at\":\"2180-02-25T13:36:15+00:00\",\"used_at\":\"2019-02-25T13:36:15+00:00\",\"transaction_id\":\"charge_test_0C2919DE543J66FAA618\", \"source\" : { \"email\":\"walletinterfacetora@mailsac.com\",\"payer_id\":\"SotirisWit\",\"full_name\":\"Pam Platform\",\"country\":\"GR\" } } | application/json |


  Scenario Outline: Valid deposit via paypal - Exclusive games JOKER
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaPaypal payload with "<amount>" "<payerId>" "<email>" "<fullName>" "<country>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card


    Examples:
      | amount | payerId    | email                           | fullName     | country |
      | 50     | SotirisWit | walletinterfacetora@mailsac.com | Pam Platform | GR      |


  Scenario: Commit Card Deposit To Tora
    Given I setup a random deposit token Id
    Given I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card

  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId via card

  Scenario Outline: Get and Verify Payment Codes
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify paypal values "<playerId>" "<paymentMethodId>" "<paymentMethodStatus>" "<email>" in get payment codes
    Examples:
      | keys     | values | playerId     | paymentMethodId   | paymentMethodStatus | email                           |
      | category | ALL    | newPlayerWeb | paypal.SotirisWit | ACTIVE              | walletinterfacetora@mailsac.com |


     #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 110.0   | 110.0       | 110.0                  | 0.0             | 0.0                 |