@WalletWitService @VerifiedAccountSetup
Feature: Verifications Web

  @NoRetry
  Scenario: Get - PlayerAccountsV1 - Invalid Account Id
    #Given I login as a "configuredPlayerWeb" user
    Given I create a Get "mainSpec" header
    #And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with new playerId
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured parameter "accountId" "0"
    When I make a "GET" call to "PlayerAccountsV1" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Account id incorrect"


  Scenario: Get - PlayerAccountsV2 (GetPlayerAccountsWebWithId) - Invalid Account Id - Empty Wallet (AT_MAIN-21)
    Given I login as a "configuredPlayerWeb" user
    Given I create a Get "mainSpec" header
    And I change url resource of method "GetPlayerAccountsWebWithId" of service "WalletService" with configured playerId "101534629"
    #And I change url resource of method "GetPlayerAccountsWebWithId" of service "WalletService" with new playerId
    And I change url resource of method "GetPlayerAccountsWebWithId" of service "WalletService" with configured parameter "accountId" "AT_MAIN-21"
    When I make a "GET" call to "GetPlayerAccountsWebWithId" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "reservedBalance" in response body is "0.0"
    And the "buyingPower" in response body is "0.0"
    And the "nonWithdrawableBalance" in response body is "0.0"
    And the "withdrawableBalance" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-21"
    And the "accountNumber" in response body is "21"
    And the "currency" in response body is "EUR"

  @NoRetry
  Scenario: Get - PlayerAccountsV2 (GetPlayerAccountsWebWithId) - Invalid Account Id - Wallet Not found (AT_BONUS-1)
    #Given I login as a "configuredPlayerWeb" user
    Given I create a Get "mainSpec" header
    #And I change url resource of method "GetPlayerAccountsWebWithId" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetPlayerAccountsWebWithId" of service "WalletService" with new playerId
    And I change url resource of method "GetPlayerAccountsWebWithId" of service "WalletService" with configured parameter "accountId" "AT_BONUS-1"
    When I make a "GET" call to "GetPlayerAccountsWebWithId" to service "WalletService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ACCOUNT_NOT_FOUND"
    And the "description" in response body is "No account was found matching the specified accountId. ([Error Id: ACCOUNT_NOT_FOUND])"


  Scenario: Get - GetPlayerAccountsWebV1 - Get Account's wallet overview (v1.WEB) - Lottery wallet and associated bonus wallets
    Given I setup gameId header to "JOKER"
   # Given I login as a "configuredPlayerWeb" user
    Given I create a Get "specWithGameId" header
   # And I change url resource of method "GetPlayerAccountsWebV1" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetPlayerAccountsWebV1" of service "WalletService" with new playerId
    When I make a "GET" call to "GetPlayerAccountsWebV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0


  Scenario: Get - GetPlayerAccountsWebV1 - Get Account's wallet overview (v1.WEB) - Betting wallet and associated bonus wallets
    Given I setup gameId header to "SPORTSBOOK"
   # Given I login as a "configuredPlayerWeb" user
    Given I create a Get "specWithGameId" header
   # And I change url resource of method "GetPlayerAccountsWebV1" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetPlayerAccountsWebV1" of service "WalletService" with new playerId
    When I make a "GET" call to "GetPlayerAccountsWebV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

  @NoRetry
  Scenario: Get - GetPlayerAccountsWeb (V2) - Get Account's wallet overview (v2.WEB) - Invalid PlayerId
    #Given I login as a "configuredPlayerWeb" user
    Given I create a Get "mainSpec" header
    And I change url resource of method "GetPlayerAccountsWeb" of service "WalletService" with configured playerId "12345678"
    When I make a "GET" call to "GetPlayerAccountsWeb" to service "WalletService"
    Then the API call is successful with status code 403
    And the "description" in response body is "Access denied"

  @NoRetry
  Scenario: Get - GetPlayerAccountsWeb (V2) - Get Account's wallet overview (v2.WEB) - Without xGame Id
   # Given I login as a "configuredPlayerWeb" user
    Given I create a Get "mainSpec" header
   # And I change url resource of method "GetPlayerAccountsWeb" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetPlayerAccountsWeb" of service "WalletService" with new playerId
    When I make a "GET" call to "GetPlayerAccountsWeb" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "ACCOUNT_NOT_DEFINED"
    And the "description" in response body is "No account was found matching the specified product."


  Scenario: Get - GetPlayerAccountsWeb (V2) - Get Account's wallet overview (v2.WEB) - Betting Wallet
   # Given I login as a "configuredPlayerWeb" user
    Given I setup gameId header to "SPORTSBOOK"
    And I create a Get "specWithGameId" header
   # And I change url resource of method "GetPlayerAccountsWeb" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetPlayerAccountsWeb" of service "WalletService" with new playerId
    When I make a "GET" call to "GetPlayerAccountsWeb" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "primary" is 0
    And the number of results in the first nested array "secondary" is 0

  Scenario: Get - GetPlayerAccountsWeb (V2) - Get Account's wallet overview (v2.WEB) - Lottery Wallet
   # Given I login as a "configuredPlayerWeb" user
    Given I setup gameId header to "JOKER"
    And I create a Get "specWithGameId" header
   # And I change url resource of method "GetPlayerAccountsWeb" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetPlayerAccountsWeb" of service "WalletService" with new playerId
    When I make a "GET" call to "GetPlayerAccountsWeb" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "primary" is 1
    And the number of results in the first nested array "secondary" is 1


  Scenario: Get - GetPlayerLegacyWallet (V2)
    Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "GetPlayerLegacyWallet" of service "WalletService" with configured playerId "101534629"
    #And I change url resource of method "GetPlayerLegacyWallet" of service "WalletService" with new playerId
    When I make a "GET" call to "GetPlayerLegacyWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "reservedBalance" in response body is "0.0"
    And the "buyingPower" in response body is "0.0"
    And the "nonWithdrawableBalance" in response body is "0.0"
    And the "withdrawableBalance" in response body is "0.0"
    And the "accountNumber" in response body is "0"
    And the "currency" in response body is "EUR"

  Scenario: Get - GetPlayerLotteryWallet (V2)
    Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "GetPlayerLotteryWallet" of service "WalletService" with configured playerId "101534629"
   # And I change url resource of method "GetPlayerLotteryWallet" of service "WalletService" with new playerId
    When I make a "GET" call to "GetPlayerLotteryWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "reservedBalance" in response body is "0.0"
    And the "buyingPower" in response body is "0.0"
    And the "nonWithdrawableBalance" in response body is "0.0"
    And the "withdrawableBalance" in response body is "0.0"
    And the "accountNumber" in response body is "1"
    And the "currency" in response body is "EUR"

  Scenario: Get - GetPlayerLotteryWallet (V2)
    Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "GetPlayerBettingWallet" of service "WalletService" with configured playerId "101534629"
   # And I change url resource of method "GetPlayerBettingWallet" of service "WalletService" with new playerId
    When I make a "GET" call to "GetPlayerBettingWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "reservedBalance" in response body is "0.0"
    And the "buyingPower" in response body is "0.0"
    And the "nonWithdrawableBalance" in response body is "0.0"
    And the "withdrawableBalance" in response body is "0.0"
    And the "accountNumber" in response body is "2"
    And the "currency" in response body is "EUR"

  @NoRetry
  Scenario: Get - GetWalletBalanceWeb (V2) - Invalid account Type
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    #And I change url resource of method "GetWalletBalanceWeb" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetWalletBalanceWeb" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceWeb" of service "WalletService" with configured parameter "accountId" "123"
    And I make a "GET" call to "GetWalletBalanceWeb" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "INVALID_ACCOUNT_TYPE"


  Scenario: Get - GetWalletBalanceWeb (V2) - Success
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    #And I change url resource of method "GetWalletBalanceWeb" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetWalletBalanceWeb" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceWeb" of service "WalletService" with configured parameter "accountId" "AT_MAIN"
    And I make a "GET" call to "GetWalletBalanceWeb" to service "WalletService"
    Then the API call is successful with status code 200
    And the "currency" in response body is "EUR"
    And the "amount" in response body is "0"

  @NoRetry
  Scenario: Get - PlayerAccountsV1 (V1) - Invalid CustomerId
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured playerId "userTest"
    #And I change url resource of method "PlayerAccountsV1" of service "WalletService" with new playerId
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured parameter "accountId" "AT_MAIN-0"
    And I make a "GET" call to "PlayerAccountsV1" to service "WalletService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Badly formed customerId"

  @NoRetry
  Scenario: Get - PlayerAccountsV1 (V1) - Invalid account Type
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    #And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with new playerId
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured parameter "accountId" "testAccount"
    And I make a "GET" call to "PlayerAccountsV1" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Account id incorrect"

  Scenario: Get - PlayerAccountsV1 (V1) - Legacy Wallet
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured playerId "101534629"
    #And I change url resource of method "PlayerAccountsV1" of service "WalletService" with new playerId
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured parameter "accountId" "AT_MAIN-0"
    And I make a "GET" call to "PlayerAccountsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the "currency" in response body is "EUR"
    And the "id" in response body is "AT_MAIN-0"
    And the "balance" in response body is "0"

  Scenario: Get - PlayerAccountsV1 (V1) - Lottery Wallet
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured playerId "101534629"
    #And I change url resource of method "PlayerAccountsV1" of service "WalletService" with new playerId
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured parameter "accountId" "AT_MAIN-1"
    And I make a "GET" call to "PlayerAccountsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the "currency" in response body is "EUR"
    And the "id" in response body is "AT_MAIN-1"
    And the "balance" in response body is "0"

  Scenario: Get - PlayerAccountsV1 (V1) - Betting Wallet
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured playerId "101534629"
    #And I change url resource of method "PlayerAccountsV1" of service "WalletService" with new playerId
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured parameter "accountId" "AT_MAIN-2"
    And I make a "GET" call to "PlayerAccountsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the "currency" in response body is "EUR"
    And the "id" in response body is "AT_MAIN-2"
    And the "balance" in response body is "0"


    ########### WEB V3 CALLS ####################################################################

  @NoRetry
  Scenario: Get - GetPlayerAccountsWebV3 (V3) - Invalid Customer Id
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "GetPlayerAccountsWebV3" of service "WalletService" with configured playerId "userTest"
    And I make a "GET" call to "GetPlayerAccountsWebV3" to service "WalletService"
    Then the API call is successful with status code 400
    And the "description" in response body is "Badly formed customerId"

  @NoRetry
  Scenario: Get - GetPlayerAccountsWebV3 (V3) - Missing Header X-GAME-ID
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    #And I change url resource of method "GetPlayerAccountsWebV3" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetPlayerAccountsWebV3" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerAccountsWebV3" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "ACCOUNT_NOT_DEFINED"
    And the "description" in response body is "No account was found matching the specified product."

  Scenario: Get - GetPlayerAccountsWebV3 (V3) - Betting Wallet
    Given I setup gameId header to "SPORTSBOOK"
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "specWithGameId" header
    #And I change url resource of method "GetPlayerAccountsWebV3" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetPlayerAccountsWebV3" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerAccountsWebV3" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

  Scenario: Get - GetPlayerAccountsWebV3 (V3) - Lottery Wallet
    Given I setup gameId header to "JOKER"
    # Given I login as a "configuredPlayerWeb" user
    And I create a Get "specWithGameId" header
    #And I change url resource of method "GetPlayerAccountsWebV3" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetPlayerAccountsWebV3" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerAccountsWebV3" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0


################# WEB V4 CALLS ##########################################################################################

  Scenario: Get - GetPlayerAccountsWebV3 (V4) - Betting Wallet
    Given I setup gameId header to "SPORTSBOOK"
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "specWithGameId" header
    #And I change url resource of method "GetPlayerAccountsWebV4" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetPlayerAccountsWebV4" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerAccountsWebV4" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "primary" is 0
    And the number of results in the first nested array "secondary" is 0

  Scenario: Get - GetPlayerAccountsWebV3 (V4) - Lottery Wallet
    Given I setup gameId header to "JOKER"
    #Given I login as a "configuredPlayerWeb" user
    And I create a Get "specWithGameId" header
    #And I change url resource of method "GetPlayerAccountsWebV4" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetPlayerAccountsWebV4" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerAccountsWebV4" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "primary" is 0
    And the number of results in the first nested array "secondary" is 0



##########################################################################################################


