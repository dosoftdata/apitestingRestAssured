@WalletWitService @UnauthorizedCalls @NoRetry
Feature: Unauthorized Web Calls


  #Background:   Given I login as a "configuredPlayerWeb" user
  #Given I login as a "newPlayerWeb" user


  #check with new playerWeb + 1- in url

  Scenario Outline: Get - PlayerAccountsV1 - Missing Header/Incorrect Cookie/ Incorrect Authorization
    Given I login as a "configuredPlayerWeb" user
    Given I create a Get "<spec>" header
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "PlayerAccountsV1" of service "WalletService" with new playerId
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured parameter "accountId" "123"
    When I make a "GET" call to "PlayerAccountsV1" to service "WalletService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: GetPlayerTransactionsV1 - Missing Header/Incorrect Cookie/ Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetPlayerTransactionsV1" of service "WalletService" with configured playerId "12345678"
     #And I change url resource of method "GetPlayerTransactionsV1" of service "WalletService" with new playerId
    And I change url resource of method "GetPlayerTransactionsV1" of service "WalletService" with configured parameter "accountId" "123"
    When I make a "GET" call to "GetPlayerTransactionsV1" to service "WalletService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: GetPlayerTransactionsV1 - Missing Header/Incorrect Cookie/ Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetPlayerTransactionTypesV1" of service "WalletService" with configured playerId "12345678"
         #And I change url resource of method "GetPlayerTransactionTypesV1" of service "WalletService" with new playerId
    And I change url resource of method "GetPlayerTransactionTypesV1" of service "WalletService" with configured parameter "accountId" "123"
    When I make a "GET" call to "GetPlayerTransactionTypesV1" to service "WalletService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |



  #check with new playerWeb + 1- in url
  Scenario Outline: Get - PlayerAccountsV1 - Missing Header/Incorrect Cookie/ Incorrect Authorization
    #Given I login as a "configuredPlayerWeb" user
    Given I create a Get "<spec>" header
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "PlayerAccountsV1" of service "WalletService" with new playerId
    And I change url resource of method "PlayerAccountsV1" of service "WalletService" with configured parameter "accountId" "123"
    When I make a "POST" call to "PlayerAccountsV1" to service "WalletService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get Player Limits - Missing Header/Incorrect Cookie/ Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "PlayerLimits" of service "LimitService" with configured playerId "12345678"
    #And I change url resource of method "PlayerLimits" of service "LimitService" with new playerId
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

    #Check if this endpoint still exists
  Scenario Outline: Approve Limits - Missing Header/Incorrect Cookie/ Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "ApproveLimits" of service "LimitService" with configured playerId "12345678"
    #And I change url resource of method "PlayerLimits" of service "LimitService" with new playerId
    And I make a "POST" call to "ApproveLimits" to service "LimitService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |


    #Check if this endpoint still exists
  Scenario Outline: Reject Limits - Missing Header/Incorrect Cookie/ Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "RejectLimits" of service "LimitService" with configured playerId "12345678"
    #And I change url resource of method "PlayerLimits" of service "LimitService" with new playerId
    And I make a "POST" call to "RejectLimits" to service "LimitService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get Payment Codes - Missing Header/Incorrect Cookie/ Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get Payment Method With Id - Missing Header/Incorrect Authorization
    And I create a Get "<spec>" header
    And I change url resource of method "PaymentMethodWithIdWeb" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "PaymentMethodWithIdWeb" of service "WalletService" with configured parameter "paymentMethodId" "123"
    And I make a "PUT" call to "PaymentMethodWithIdWeb" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Post Payment Via Card - Missing Header/Incorrect Authorization
    And I create a Get "<spec>" header
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with configured playerId "12345678"
        #And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "PUT" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Cancel Refund - Missing Header/Incorrect Authorization
    And I create a Get "<spec>" header
    And I change url resource of method "CancelRefund" of service "WalletService" with configured playerId "12345678"
        #And I change url resource of method "CancelRefund" of service "WalletService" with new playerId
    And I make a "POST" call to "CancelRefund" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - GetPlayerAccountsWeb - Missing Header/Incorrect Authorization
    And I create a Get "<spec>" header
    And I change url resource of method "GetPlayerAccountsWeb" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerAccountsWeb" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - GetPlayerAccountsWeb - Missing Header/Incorrect Authorization
    And I create a Get "<spec>" header
    And I change url resource of method "GetPlayerAccountsWebWithId" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "GetPlayerAccountsWebWithId" of service "WalletService" with new playerId
    And I change url resource of method "GetPlayerAccountsWebWithId" of service "WalletService" with configured parameter "accountId" "123"
    And I make a "GET" call to "GetPlayerAccountsWebWithId" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get - GetWalletBalanceWeb - Missing Header/Incorrect Authorization
    And I create a Get "<spec>" header
    And I change url resource of method "GetWalletBalanceWeb" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "GetWalletBalanceWeb" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceWeb" of service "WalletService" with configured parameter "accountId" "123"
    And I make a "GET" call to "GetWalletBalanceWeb" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Put - PaymentMethodWithIdWebV2- Missing Header/Incorrect Authorization
    And I create a Get "<spec>" header
    And I change url resource of method "PaymentMethodWithIdWebV2" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "PaymentMethodWithIdWebV2" of service "WalletService" with new playerId
    And I change url resource of method "PaymentMethodWithIdWebV2" of service "WalletService" with configured parameter "paymentMethodId" "123"
    And I make a "PUT" call to "PaymentMethodWithIdWebV2" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - GetPlayerAccountsWebV3- Missing Header/Incorrect Authorization
    And I create a Get "<spec>" header
    And I change url resource of method "GetPlayerAccountsWebV3" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "GetPlayerAccountsWebV3" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerAccountsWebV3" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - GetPlayerTransactionsV1OPAP- Missing Header/Incorrect Authorization
    And I create a Get "<spec>" header
    And I change url resource of method "GetPlayerTransactionsV1OPAP" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "GetPlayerTransactionsV1OPAP" of service "WalletService" with new playerId
    And I change url resource of method "GetPlayerTransactionsV1OPAP" of service "WalletService" with configured parameter "accountId" "123"
    And I make a "GET" call to "GetPlayerTransactionsV1OPAP" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - GetPlayerTransactionsTypesV1OPAP- Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetPlayerTransactionTypesV1OPAP" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "GetPlayerTransactionTypesV1OPAP" of service "WalletService" with new playerId
    And I change url resource of method "GetPlayerTransactionTypesV1OPAP" of service "WalletService" with configured parameter "accountId" "123"
    When I make a "GET" call to "GetPlayerTransactionTypesV1OPAP" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Post - PaymentsVoucher- Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "PaymentsVoucher" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "PaymentsVoucher" of service "WalletService" with new playerId
    And I change url resource of method "PaymentsVoucher" of service "WalletService" with configured parameter "voucherId" "123"
    When I make a "POST" call to "PaymentsVoucher" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Post - CashoutVoucher- Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "CashoutVoucher" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "CashoutVoucher" of service "WalletService" with new playerId
    And I change url resource of method "CashoutVoucher" of service "WalletService" with configured parameter "voucherId" "123"
    When I make a "POST" call to "CashoutVoucher" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Del - PaymentMethodWithIdWebV1OPAP - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "PaymentMethodWithIdWebV1OPAP" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "PaymentMethodWithIdWebV1OPAP" of service "WalletService" with new playerId
    And I change url resource of method "PaymentMethodWithIdWebV1OPAP" of service "WalletService" with configured parameter "paymentMethodId" "123"
    When I make a "DEL" call to "PaymentMethodWithIdWebV1OPAP" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get - GetSsbtAccounts - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "GetSsbtAccounts" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "GetSsbtAccounts" of service "WalletService" with new playerId
    When I make a "GET" call to "GetSsbtAccounts" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Post - PaymentsRollover - Missing Header/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "PaymentsRollover" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "PaymentsRollover" of service "WalletService" with new playerId
    And I change url resource of method "PaymentsRollover" of service "WalletService" with configured parameter "wagerId" "123"
    When I make a "POST" call to "PaymentsRollover" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                       | statusCode | GherkinDescription      |
      | emptySpec                  | 403        | Missing Header          |
      | incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | incorrectAuthorizationSpec | 401        | Incorrect Authorization |






