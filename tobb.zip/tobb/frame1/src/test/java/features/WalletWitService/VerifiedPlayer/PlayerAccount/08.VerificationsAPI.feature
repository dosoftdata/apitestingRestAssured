@WalletWitService @VerifiedAccountSetup
Feature: VerificationsAPI

    #returns empty wallet?
  #@ResetUrl (similar to concat but do everything here)
  Scenario: Get Player Wallet API - Non existing wallet 1
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    #And I change url resource of method "GetPlayerWalletV1" of service "WalletService" with new playerId
    And I change url resource of method "GetPlayerWalletV1" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "GetPlayerWalletV1" of service "WalletService" with configured parameter "accountId" "AT_MAIN-21"
    When I make a "GET" call to "GetPlayerWalletV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance.amount" in response body is "0.0"
    And the "reservedBalance.amount" in response body is "0.0"
    And the "buyingPower.amount" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-21"
    And the "owner.type" in response body is "1"


  Scenario: Get Player Wallet API - Non existing wallet
    Given I create a Get "api_mainSpec_mainHost" header
    #And I change url resource of method "GetPlayerWalletV1" of service "WalletService" with new playerId
    And I change url resource of method "GetPlayerWalletV1" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "GetPlayerWalletV1" of service "WalletService" with configured parameter "accountId" "AT_BONUS-21"
    When I make a "GET" call to "GetPlayerWalletV1" to service "WalletService"
    Then the API call is successful with status code 404
    And the "description" in response body is "No account was found matching the specified accountId. ([Error Id: ACCOUNT_NOT_FOUND])"
    And the "errorId" in response body is "ACCOUNT_NOT_FOUND"


    #resp not tested
  @Concat
  Scenario Outline: Get Player account by id via V2.API - Legacy, Betting, Lottery
    Given I create a Get "api_mainSpec_mainHost" header
    #And I change url resource of method "GetAccountV2" of service "WalletService" with new playerId
    And I change url resource of method "GetAccountV2" of service "WalletService" with configured playerId "12345678"
    And I concat the url "/<accountId>" to the end of url of method "GetAccountV2" of service "WalletService"
    And I make a "GET" call to "GetAccountV2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "accountId" in response body is "<accountId>"
    And the "currency" in response body is "EUR"
    And the "balance" in response body is "0.0"
    And the "reservedBalance" in response body is "0.0"

    Examples:
      | accountId |
      | AT_MAIN-0 |
      | AT_MAIN-1 |
      | AT_MAIN-2 |

  @Concat @NoRetry
  Scenario Outline: Get Player account by id via V2.API - Non existing wallet
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountV2" of service "WalletService" with new playerId
    #And I change url resource of method "GetAccountV2" of service "WalletService" with configured playerId "12345678"
    And I concat the url "/<accountId>" to the end of url of method "GetAccountV2" of service "WalletService"
    And I make a "GET" call to "GetAccountV2" to service "WalletService"
    Then the API call is successful with status code 400
    And the "description" in response body is "INVALID_ARGUMENT"
    And the "errorId" in response body is "Account id incorrect"

    Examples:
      | accountId   |
      | testAccount |


 #  #GET PLAYER V1 HERE
 #@Concat @NoRetry
 #Scenario Outline: Get Player account by id via V2.API - Non existing wallet
 #  Given I create a Get "api_mainSpec_mainHost" header
 #  And I change url resource of method "GetAccountV2" of service "WalletService" with new playerId
 #  #And I change url resource of method "GetAccountV2" of service "WalletService" with configured playerId "12345678"
 #  And I concat the url "/<accountId>" to the end of url of method "GetAccountV2" of service "WalletService"
 #  And I make a "GET" call to "GetAccountV2" to service "WalletService"
 #  Then the API call is successful with status code 400
 #  And the "description" in response body is "INVALID_ARGUMENT"
 #  And the "errorId" in response body is "Account id incorrect"

 #  Examples:#| accountId |
   #   | TEST-0      |


  Scenario Outline: Get Player Wallet API v1.API - Non existing wallet
    Given I create a Get "api_mainSpec_mainHost" header
    #And I change url resource of method "GetPlayerWalletV1" of service "WalletService" with new playerId
    And I change url resource of method "GetPlayerWalletV1" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "GetPlayerWalletV1" of service "WalletService" with configured parameter "accountId" "<accountId>"
    When I make a "GET" call to "GetPlayerWalletV1" to service "WalletService"
    Then the API call is successful with status code 400
    And the "description" in response body is "INVALID_ARGUMENT"
    And the "errorId" in response body is "Account id incorrect"


    Examples:
      | accountId |
      | TEST-0    |
      | AT_MAIN-1 |
      | AT_MAIN-2 |

      ### LEGACY WALLET CALLS ####
  Scenario: Get Player's Legacy Wallet v1
    And I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetUserLegacyWalletV1" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetUserLegacyWalletV1" of service "WalletService" with new playerId
    And I make a "GET" call to "GetUserLegacyWalletV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance.amount" in response body is "0.0"
    And the "reservedBalance.amount" in response body is "0.0"
    And the "buyingPower.amount" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-0"
    And the "owner.type" in response body is "1"

  Scenario: Get Player's Lottery Wallet v1.API
    And I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetPlayerLotteryWalletV1" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetPlayerLotteryWalletV1" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerLotteryWalletV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance.amount" in response body is "0.0"
    And the "reservedBalance.amount" in response body is "0.0"
    And the "buyingPower.amount" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-1"
    And the "owner.type" in response body is "1"

  Scenario: Get Player's Betting Wallet v1.API
    And I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetPlayerBettingWalletV1" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetPlayerBettingWalletV1" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPlayerBettingWalletV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance.amount" in response body is "0.0"
    And the "reservedBalance.amount" in response body is "0.0"
    And the "buyingPower.amount" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-2"
    And the "owner.type" in response body is "1"

#####

  Scenario: Get Player's Wallet v3.API - No GameId
    And I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountInformation" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetAccountInformation" of service "WalletService" with new playerId
    And I make a "GET" call to "GetAccountInformation" to service "WalletService"
    Then the API call is successful with status code 400
    And the "description" in response body is "ACCOUNT_NOT_DEFINED"
    And the "errorId" in response body is "No account was found matching the specified product."

  Scenario: Get Player's Lottery Wallet v3.API
    Given I setup gameId header to "JOKER"
    And I create a Get "api_specWithGameId" header
    And I change url resource of method "GetAccountInformation" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetAccountInformation" of service "WalletService" with new playerId
    And I make a "GET" call to "GetAccountInformation" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "reservedBalance" in response body is "0.0"
    And the "buyingPower" in response body is "0.0"
    And the "accountId" in response body is "AT_MAIN-1"
    And the "currency" in response body is "EUR"

  Scenario: Get Player's Betting Wallet v3.API
    Given I setup gameId header to "CASINO"
    And I create a Get "api_specWithGameId" header
    And I change url resource of method "GetAccountInformation" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetAccountInformation" of service "WalletService" with new playerId
    And I make a "GET" call to "GetAccountInformation" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "reservedBalance" in response body is "0.0"
    And the "buyingPower" in response body is "0.0"
    And the "accountId" in response body is "AT_MAIN-2"
    And the "currency" in response body is "EUR"

  Scenario: Get Player's Lottery Wallet v3.API - With Bonus associated wallets
    Given I setup gameId header to "JOKER"
    And I create a Get "api_specWithGameId" header with query params "gameId" "PBS"
    And I change url resource of method "GetAccountInformation" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetAccountInformation" of service "WalletService" with new playerId
    And I make a "GET" call to "GetAccountInformation" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "reservedBalance" in response body is "0.0"
    And the "buyingPower" in response body is "0.0"
    And the "accountId" in response body is "AT_MAIN-1"
    And the "currency" in response body is "EUR"

  @NoRetry
  Scenario: Cancel a transaction for the given user and account - Invalid accountId
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "CancelTransaction" of service "WalletService" with configured parameter "accountId" "test"
    And I change url resource of method "CancelTransaction" of service "WalletService" with configured parameter "transactionId" "123"
    When I make a "POST" call to "CancelTransaction" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Account id incorrect"


  @NoRetry
  Scenario: Cancel a transaction for the given user and account - Missing body
    #Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "CancelTransaction" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "CancelTransaction" of service "WalletService" with configured parameter "accountId" "AT_MAIN-0"
    And I change url resource of method "CancelTransaction" of service "WalletService" with configured parameter "transactionId" "123"
    When I make a "POST" call to "CancelTransaction" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"


  @NoRetry
  Scenario: Cancel a transaction for the given user and account - Missing Fields
    Given I create an empty payload with header "api_mainSpec_mainHost"
    And I change url resource of method "CancelTransaction" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "CancelTransaction" of service "WalletService" with configured parameter "accountId" "AT_MAIN-0"
    And I change url resource of method "CancelTransaction" of service "WalletService" with configured parameter "transactionId" "123"
    When I make a "POST" call to "CancelTransaction" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Either id or referenceId must be included in the request"

  @NoRetry
  Scenario Outline: Cancel a transaction for the given user and account - Invalid id type
    #Given I login as an Api user
    Given I create a Post CancelTransaction payload with "<id>" "<referenceId>"
    And I change url resource of method "CancelTransaction" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "CancelTransaction" of service "WalletService" with configured parameter "accountId" "AT_MAIN-0"
    And I change url resource of method "CancelTransaction" of service "WalletService" with configured parameter "transactionId" "123"
    When I make a "POST" call to "CancelTransaction" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "The id must be numeric"

    Examples:
      | id   | referenceId |
      | test |             |

###### ACCESS OPERATIONS REGION####################################################################################################


  ##################################NEGATIVE SCENARIOS##########################################################################################################

  @NoRetry
  Scenario: Get Access Operations  -  Invalid accessOperationId - Endpoint Not found
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccessOperationsWithId" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "GetAccessOperationsWithId" of service "WalletService" with configured parameter "accessoperationsId" "test"
   #And I change url resource of method "GetAccessOperationsWithId" of service "WalletService" with new playerId
    And I make a "GET" call to "GetAccessOperationsWithId" to service "WalletService"
    Then the API call is successful with status code 404

  ########################################################################################################################################


  Scenario: Get Access Operations - Deposits
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetDepositAccessOperations" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetDepositAccessOperations" of service "WalletService" with new playerId
    And I make a "GET" call to "GetDepositAccessOperations" to service "WalletService"
    Then the API call is successful with status code 200


  Scenario: Get Access Operations - Withdrawals
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetWithdrawAccessOperations" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetWithdrawAccessOperations" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWithdrawAccessOperations" to service "WalletService"
    Then the API call is successful with status code 200

  Scenario: Get Access Operations - Buy
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetWithdrawAccessOperations" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetWithdrawAccessOperations" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWithdrawAccessOperations" to service "WalletService"
    Then the API call is successful with status code 200

  Scenario: Get Access Operations - Payout
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetWithdrawAccessOperations" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetWithdrawAccessOperations" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWithdrawAccessOperations" to service "WalletService"
    Then the API call is successful with status code 200

  Scenario: Get Access Operations - General - Get player's access status of all wallet/xxx/xxx operational units
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccessOperations" of service "WalletService" with configured playerId "12345678"
   #And I change url resource of method "GetAccessOperations" of service "WalletService" with new playerId
    And I make a "GET" call to "GetAccessOperations" to service "WalletService"
    Then the API call is successful with status code 200


  Scenario: Get Account Products
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "GET" call to "GetAccountProductsV4" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And the property "productIds" in response body array with index "[0]" contains value "CASINO"
    And the property "productIds" in response body array with index "[0]" contains value "SPORTSBOOK"
    And the property "productIds" in response body array with index "[1]" contains value "JOKER"
    And the property "productIds" in response body array with index "[1]" contains value "PROTO"
    And the property "productIds" in response body array with index "[1]" contains value "LOTTO"
    And the property "productIds" in response body array with index "[1]" contains value "OPAPONLINE"
    And the property "productIds" in response body array with index "[1]" contains value "KINO"
    And the property "productIds" in response body array with index "[1]" contains value "SUPER3"
    And the property "productIds" in response body array with index "[1]" contains value "EUROJACKPOT"

