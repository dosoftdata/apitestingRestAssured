#recheck if we need the scenarios of access here.
@skipIfNotAzure @WalletWitService @VerifiedAccountSetup
Feature:Manually Adjust Wallet

  #VARIOUS NEGATIVE
  @NoRetry
  Scenario Outline: Manual adjustment for Withdrawal in Lottery wallet via BO - NEGATIVE
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Lottery wallet"
    When I change url resource of method "ManualAdjustLotteryWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustLotteryWallet" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

    Examples:
      | transactionType  | transactionSubType | productId | operation  | amount |
      | TT_MANUAL_ADJUST | MDWO               | JOKER     | WITHDRAW   | 10.0   |
      | TT_MANUAL_ADJUST | MDWO               | JOKER     | WITHDRAWAL | test   |
  #################

  Scenario Outline: Manual adjustment for Deposit in Lottery wallet via BO
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Lottery wallet"
    When I change url resource of method "ManualAdjustLotteryWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustLotteryWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "operation" in response body is "<operation>"
    And the "amount" in response body is "<amount>"

    Examples:
      | transactionType  | transactionSubType | productId | operation | amount |
      | TT_MANUAL_ADJUST | MDWO               | JOKER     | DEPOSIT   | 500.0  |

  Scenario Outline: Get and Verify - Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 500.0    | 500.0        | 0.0                     | 0.0              | 500.0                | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  |

      #Revert wallets to 0 balance
  Scenario Outline: Manual adjustment for Withdrawal in Lottery wallet
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Lottery wallet"
    When I change url resource of method "ManualAdjustLotteryWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustLotteryWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "currency" in response body is "EUR"
    And the "operation" in response body is "WITHDRAWAL"
    And I verify the the amount for "exclWalletUnspentDeposits"

    Examples:
      | transactionType  | transactionSubType | productId | operation  | amount |
      | TT_MANUAL_ADJUST | MDWO               | JOKER     | WITHDRAWAL | 500    |

  Scenario Outline: Get and Verify - Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  |
