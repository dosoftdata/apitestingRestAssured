Feature: Wiremock Setup

  @WalletWitService  @skipIfNotAzure
  Scenario Outline: Tora response 200 for Deposits via Card 3
    Given I setup deposit paymentId "<paymentId>" and card fingerprint "<cardFingerprint1>"
    And I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | paymentId | cardFingerprint1                                                 | scenarioName                 | requiredScenarioState | priority | method | url          | status | body                                                                                                                                              | headers          |
      | random    | 5a8c3cec619b62ed3b4b4d98f1b57ae0fa3f4b65ca483a0954f0e6c885724566 | ToraDepositsResponse400Card3 | Started               | 100      | ANY    | /v1/payments | 400    | {\"errorId\":\"PAYMENT_ILLEGAL_STATE\",\"description\":\"The payment status is illegal for this operation. ([Error Id: PAYMENT_ILLEGAL_STATE])\"} | application/json |

  @WalletWitService  @skipIfNotAzure
  Scenario Outline: Tora response 200 for Deposits Token
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName              | requiredScenarioState | priority | method | url             | status | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | headers          |
      | ToraDepositsToken200Card1 | Started               | 100      | ANY    | .*tokens/tok_.* | 200    | {\"id\":\"pmt_IEuiimeTppo4AZIHKsKgro2Q\",\"object\":\"payment\",\"captured\":true,\"amount\":5000,\"currency\":\"EUR\",\"description\":\"OPAP wallet deposit id:{{deposit_paymentId}}\",\"meta\":{\"paymentId\":\"{{deposit_paymentId}}\",\"playerId\":\"{{playerId}}\"},\"status\":\"captured\",\"merchant_reference\":\"paymentId:{{deposit_paymentId}}\",\"customer\":null,\"method\":\"card\",\"method_info\":{\"holder_name\":\"TEST PROD\",\"exp_year\":2025,\"exp_month\":6,\"last4\":\"0001\",\"brand\":\"visa\",\"bin\":\"465858\",\"fingerprint\":\"{{Card1_fingerprint}}\"},\"created_at\":\"2019-02-25T13:36:14+00:00\",\"updated_at\":\"2019-02-25T13:36:15+00:00\",\"captured_at\":\"2019-02-25T13:36:15+00:00\",\"refunded\":false,\"refunds\":[],\"refunded_amount\":\"0\",\"fee_amount\":0,\"error_code\":null,\"error_message\":null,\"transaction_id\":\"charge_test_0C2919DE543J66FAA618\",\"type\":\"card\",\"source\":{\"holder_name\":\"TEST PROD\",\"exp_year\":2025,\"exp_month\":6,\"last4\":\"0001\",\"brand\":\"visa\",\"bin\":\"465858\",\"fingerprint\":\"{{Card1_fingerprint}}\"}} | application/json |