@WalletWitService
Feature: Set Mandatory Limits

  Scenario: Get and Verify Access Groups
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response and copy the access group Ids


  Scenario Outline: Get limits via limit-service
    Given I login as a "newPlayerWeb" user
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerLimits" of service "LimitService" with new playerId
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0
    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |


  Scenario Outline: Set mandatory limits for SPORTSBOOK/CASINO
    Given I setup gameId header to "SPORTSBOOK"
    And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
    And I change url resource of method "PlayerLimitsV2" of service "LimitService" with new playerId
    When I make a "POST" call to "PlayerLimitsV2" to service "LimitService"
    Then the API call is successful with status code 200

    Examples:
      | limitTypes             | limitPeriods            | limitAmounts         | gameIds             |
      | TIME,DEPOSIT,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY | 86000,2000,1000,1000 | ,,SPORTSBOOK,CASINO |


  Scenario Outline: Verify SPORTSBOOK mandatory limits via limit-service
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    And I verify limits for "DAILY" limit period, duration or amount 86000 and limitType "TIME" and gameId "" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 1000 and limitType "LOSS" and gameId "SPORTSBOOK" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 2000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-2" with pending limits false
    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |


  Scenario Outline: Set mandatory limits for JOKER/PROTO/LOTTO/SUPER3/KINO and Verify JOKER mandatory limits
    Given I setup gameId header to "JOKER"
    And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
    And I change url resource of method "PlayerLimitsV2" of service "LimitService" with new playerId
    When I make a "POST" call to "PlayerLimitsV2" to service "LimitService"
    Then the API call is successful with status code 200

    Examples:
      | limitTypes                            | limitPeriods                              | limitAmounts                        | gameIds                         |
      | TIME,DEPOSIT,LOSS,LOSS,LOSS,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY,DAILY,DAILY,DAILY | 86000,2000,1000,1000,1000,1000,1000 | ,,JOKER,PROTO,KINO,LOTTO,SUPER3 |


  Scenario Outline: Verify JOKER mandatory limits via limit-service
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    And I verify limits for "DAILY" limit period, duration or amount 86000 and limitType "TIME" and gameId "" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 1000 and limitType "LOSS" and gameId "JOKER" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 2000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-1" with pending limits false

    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |

######## More Wallet Related #################################

  Scenario Outline: Get AccessAttributes - Operational Unit = wallet/non exclusive = ALLOW
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"

    Examples:
      | keys                                 | values                                                         | accessType | operationalUnit                              | userId       | updatedByUserId | operatorId | reason | index |
      | userId,operationalUnit,includeGroups | changeit,wallet/nonexclusive-deposit/mandatory-limits/ALL,true | ALLOW      | wallet/nonexclusive-deposit/mandatory-limits | newPlayerWeb | 0-              | 0          |        | [0]   |




