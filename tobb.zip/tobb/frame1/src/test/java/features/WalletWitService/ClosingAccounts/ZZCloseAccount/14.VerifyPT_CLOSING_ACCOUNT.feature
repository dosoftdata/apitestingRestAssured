@WalletWitService
Feature: Verify PT_CLOSING_ACCOUNT Payment And Close

#some more here
  Scenario: Get All Users Payments
    When I create a Get "cc_csrftokenSpec" header with query params "customerId,pageNumber" "changeit,1"
    And I change url resource of method "GetAllUsersPayments" of service "WalletService" with new playerId
    And I make a "GET" call to "GetAllUsersPayments" to service "WalletService"
    Then the API call is successful with status code 200
    And the property "paymentType" in response body array with index "data[0]" has value "PT_CLOSING_ACCOUNT"
    And the property "status" in response body array with index "reasons[1]" has value "REJECTED"

    #And the property "accountId" in response body array with index "data[0]" has value "PAYMENT_METHOD_NOT_REGISTERED"
   # And the property "paymentMethodAccountNumber" in response body array with index "reasons[1]" has value "PAYMENT_METHOD_NOT_REGISTERED"
    #And the property "destination" in response body array with index "reasons[1]" has value "PAYMENT_METHOD_NOT_REGISTERED"


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "PAYMENT_INVALID_STATUS"
    And the "description" in response body is "The requested payment operation is not permitted since the payment status is not appropriate for the requested operation ([Error Id: PAYMENT_INVALID_STATUS])"


  Scenario Outline: Get and Verify Wallets Balance - Lottery 0 - Betting 1
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 1.0      | 1.0          | 0.0                     | 0.0              | 1.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  |


  Scenario: Close account via BO call
    Given I create Close Account payload with "CLOSED" "test" "SELF_EXCLUSION"
    And I change url resource of method "OpenCloseAccountCC" of service "PlayerService" with new playerId
    When I make a "PUT" call to "OpenCloseAccountCC" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "status" in response body is "DISABLED"
    And the "statusReason" in response body is "SELF_EXCLUSION"