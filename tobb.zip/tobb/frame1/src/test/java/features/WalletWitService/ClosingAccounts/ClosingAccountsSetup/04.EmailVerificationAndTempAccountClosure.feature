@WalletWitService @skipIfNotAzure @CloseAccountSetup
Feature: Email Verification & Temp Account Closure

  Scenario Outline: Get MailId For Fetch Hash - Verify origin has value player
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "<array>" is 1
    And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
    And I copy the value of the mailId from the response

    Examples:
      | key      | value    | property | propertyValue | array | arrayWithIndex |
      | playerId | changeit | origin   | player        | data  | data[0]        |

  Scenario Outline: Get hash For Mail Verification - Verify event name/owner
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetHashForMailVerification" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the "<property>" in response body is "<propertyValue>"
    And the "<property2>" in response body is "<propertyValue2>"
    And the id in response body is mailIdForHash
    And I copy the value of the hash from the response

    Examples:
      | property  | propertyValue                       | property2  | propertyValue2 |
      | eventName | registrationWelcomeEvent.opaponline | eventOwner | player         |

  Scenario: Verify Player's Email - Call to verify player's email
    Given I create a VerifyEmail payload with inner playerId and hash
    When I make a "POST" call to "VerifyPlayersEmail" to service "PlayerService"
    Then the API call is successful with status code 204

#### Close Account Related#################################

    # CLOSES ACCOUNT careful there
  # fix userType
  Scenario Outline: Close Account v4 - Success
    Given I create a CloseAccountV4 Put payload with "<status>" "<statusDescription>" "<statusReason>"
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with configured parameter "userType" "1"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with new playerId
    When I make a "PUT" call to "CloseAccountV4" to service "WalletService"
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "statusReason" in response body is "<statusReason>"

    Examples:

      | keys                     | values                          | status | statusDescription | statusReason   |
      | statusReason,playerLevel | SELF_EXCLUSION,VERIFIED_ACCOUNT | CLOSED | test              | SELF_EXCLUSION |


# OPEN ACCOUNT in progress
  Scenario Outline: Open Account - Backoffice
    Given I create a OpenAccount Put payload with "<status>" "<statusDescription>" "<statusReason>"
    And I change url resource of method "OpenCloseAccountCC" of service "PlayerService" with new playerId
    When I make a "PUT" call to "OpenCloseAccountCC" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "statusReason" in response body is "<statusReason>"

    Examples:

      | status  | statusDescription            | statusReason |
      | ENABLED | Account was opened by admin. | NONE         |

