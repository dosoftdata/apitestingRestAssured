#AZURE ONLY FEATURE
#RETEST AZURE
@WalletWitService @VerifiedAccountSetup @skipIfNotAzure
Feature: Wallet Wiremock Stubs For Identity

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Add A Stub - Wiremock - Stub "Payments via v2 endpoint 500"
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName | requiredScenarioState | priority | method | url                          | status | body                                                                               | headers          |
      | Refund       | Started               | 100      | ANY    | /api/wallet/rest/v2/payments | 500    | {\"errorId\":\"INTERNAL_SERVER_ERROR\", \"description\":\"Internal Server Error\"} | application/json |

    #204 or 409? refund missing from flow not used anymore
  Scenario: Verify payment via Tora webhooks
    Given I add 5 seconds delay
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 499995000
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 204

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

    #204 or 409? refund missing from flow not used anymore
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 499995000
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 204


  Scenario: Get all requests and verify that bankPaymentId and not PaymentId is sent to Tora
    Given I create a Get "emptySpec" header
    And I make a "GET" call to "GetAllRequests" to service "WiremockService"
    Then the API call is successful with status code 200


  Scenario Outline: Get 2 latest transactions
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerPaymentsAsAdmin" to service "WalletService"
    Then the API call is successful with status code 200

    Examples:
      | keys                           | values       |
      | customerId,pageNumber,pageSize | changeit,1,2 |

  Scenario Outline: Get and Verify - Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  |


  Scenario: Reset Scenarios
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllScenarios" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200