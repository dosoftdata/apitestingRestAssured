@WalletWitService @CloseAccountSetup @skipIfNotAzure
Feature:Wiremock Teardown

  Scenario: Reset Scenarios
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllScenarios" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200