@WalletWitService  @skipIfNotAzure
Feature: Assign Role To BackOffice For Verifying Payments

  Scenario: Get Admin Users
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetAdminUsers" to service "AdminService"
    Then the API call fails with status code 200
    And the number of results in the array "data" is greater than 0


  Scenario Outline: Add an AccessAttribute - Success
    And I create a Get "api_mainSpec_mainHost" header
    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "<operatorId>"
    And the property "operationalUnit" in response body array with index "<index>" has value "<operationalUnit>"
    And the property "accessType" in response body array with index "<index>" has value "<accessType>"
    And the property "reason" in response body array with index "<index>" has value "<reason>"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the "<index>.created" to include today's date

    Examples:
      | accessType | operationalUnit                       | userId | created | updated | updatedByUserId | operatorId | reason | index | valid | notifyStatus |
      | ALLOW      | adminrest.players/payments/verify/WEB | 102-1  |         |         | 3-1             | 0          | Test   | [0]   | null  |              |

  Scenario Outline: Get AccessAttributes - Success
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    Then I make a "GET" call to "ApiAccessAttributes" to service "AccessService"
    And the API call is successful with status code <statusCode>
    And the number of results in a nameless array of objects is 1
    And the property "operatorId" in response body array with index "<index>" has value "0"
    And the property "operationalUnit" in response body array with index "<index>" has value "adminrest.players/payments/verify/WEB"
    And the property "accessType" in response body array with index "<index>" has value "ALLOW"
    And the property "reason" in response body array with index "<index>" has value "Test"
    And the property "userId" in response body array with index "<index>" has value "<userId>"
    And the property "updatedByUserId" in response body array with index "<index>" has value "<updatedByUserId>"


    Examples:
      | keys                                 | values                                           | statusCode | index | userId | updatedByUserId |
      | userId,operationalUnit,includeGroups | 102-1,adminrest.players/payments/verify/WEB,true | 200        | [0]   | 102-1  | 3-1             |


  Scenario: Get and Verify Access Groups - Verify 12 groups and copy important roles
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the 12 mandatory groups

  Scenario Outline: Put - Assign proper access roles for verifying payments to Technician
    Given I create a PUT AllowRoleAccessAttributes payload with "<operationalUnits>"
    And I change url resource of method "AllowRoleAccessAttributes" of service "AccessService" with configured parameter "roleId" "technicianRoleId"
    When I make a "PUT" call to "AllowRoleAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | operationalUnits                                                                  |
      | admin.players/accounts/verify-payment-by-id,adminrest.players/payments/verify/WEB |

  Scenario Outline: Put - Assign proper access roles for verifying payments to Clerk
    Given I create a PUT AllowRoleAccessAttributes payload with "<operationalUnits>"
    And I change url resource of method "AllowRoleAccessAttributes" of service "AccessService" with configured parameter "roleId" "clerkAccessRoleId"
    When I make a "PUT" call to "AllowRoleAccessAttributes" to service "AccessService"
    Then the API call is successful with status code 204

    Examples:
      | operationalUnits                                                                  |
      | admin.players/accounts/verify-payment-by-id,adminrest.players/payments/verify/WEB |

