@VerifiedAccountSetup
Feature: EP/NEP Groups


## User is a member of EP group only
  @WalletWitService
  Scenario: Get and Verify Access Groups
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response and copy the access group Ids


  @WalletWitService
  Scenario Outline: Get and Verify Payment Codes
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the values of the Payment Codes
    Examples:
      | keys     | values |
      | category | ALL    |


  @WalletWitService
  Scenario Outline: Deposit via Payment code - Betting wallet (Negative)
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"
    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |


  @WalletWitService
  Scenario: Add user to EP group
    Given I create an AddUserToEpGroup payload
    And I change url resource of method "AddUserToEpGroup" of service "AccessService" with new "accessGroupIdExclusive"
    When I make a "POST" call to "AddUserToEpGroup" to service "AccessService"
    Then the API call is successful with status code 201
    And I copy and verify the member Id


  @WalletWitService
  Scenario: Add user to NEP group
    Given I create an AddUserToNepGroup payload
    And I change url resource of method "AddUserToNepGroup" of service "AccessService" with new "accessGroupIdNonExclusive"
    When I make a "POST" call to "AddUserToNepGroup" to service "AccessService"
    Then the API call is successful with status code 201
    And I copy and verify the member Id


  @WalletWitService
  Scenario: Get and Verify Role Members
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetRoleMembers" of service "AccessService" with new playerId
    And I make a "GET" call to "GetRoleMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response for Role Members for "ExclusiveAndNonExclusive"

