@WalletWitService @VerifiedAccountSetup
Feature: Verifications CC


  Scenario: Get - GetAccountV1CC (v1.CC) - Success No Wallets
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetAccountV1CC" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetAccountV1CC" of service "WalletService" with new playerId
    When I make a "GET" call to "GetAccountV1CC" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

  Scenario: Get - GetWalletBalance (v2.CC) - Success No Wallets
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetAccountV1CC" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetAccountV1CC" of service "WalletService" with new playerId
    When I make a "GET" call to "GetAccountV1CC" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    #NEGATIVE SCENARIO
  @NoRetry
  Scenario: Get - GetAccountV1CCWithId (v1.CC) - Invalid account Id
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with new playerId
    And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with configured parameter "accountId" "0"
    When I make a "GET" call to "GetAccountV1CCWithId" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Account id incorrect"

  Scenario: Get - GetAccountV1CCWithId (v1.CC) - Legacy Account
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with new playerId
    And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with configured parameter "accountId" "AT_MAIN-0"
    When I make a "GET" call to "GetAccountV1CCWithId" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-0"
    And the "accountNumber" in response body is "0"
    And the "accountType" in response body is "AT_MAIN"
    And the "currency" in response body is "EUR"

  Scenario: Get - GetAccountV1CCWithId (v1.CC) - Lottery Account
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with new playerId
    And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with configured parameter "accountId" "AT_MAIN-1"
    When I make a "GET" call to "GetAccountV1CCWithId" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-1"
    And the "accountNumber" in response body is "1"
    And the "accountType" in response body is "AT_MAIN"
    And the "currency" in response body is "EUR"


  Scenario: Get - GetAccountV1CCWithId (v1.CC) - Betting Account
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with new playerId
    And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with configured parameter "accountId" "AT_MAIN-2"
    When I make a "GET" call to "GetAccountV1CCWithId" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-2"
    And the "accountNumber" in response body is "2"
    And the "accountType" in response body is "AT_MAIN"
    And the "currency" in response body is "EUR"

    #NEGATIVE SCENARIO
  @NoRetry
  Scenario: Get - GetWalletBalanceWithId (v2.CC) - Invalid account Id
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with configured parameter "accountId" "0"
    When I make a "GET" call to "GetWalletBalanceWithId" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Account id incorrect"

  Scenario: Get - GetWalletBalanceWithId (v2.CC) - Legacy Account
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with configured parameter "accountId" "AT_MAIN-0"
    When I make a "GET" call to "GetWalletBalanceWithId" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-0"
    And the "accountNumber" in response body is "0"
    And the "accountType" in response body is "AT_MAIN"
    And the "currency" in response body is "EUR"

  Scenario: Get - GetWalletBalanceWithId (v2.CC) - Lottery Account
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with configured parameter "accountId" "AT_MAIN-1"
    When I make a "GET" call to "GetWalletBalanceWithId" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-1"
    And the "accountNumber" in response body is "1"
    And the "accountType" in response body is "AT_MAIN"
    And the "currency" in response body is "EUR"


  Scenario: Get - GetWalletBalanceWithId (v2.CC) - Betting Account
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with configured parameter "accountId" "AT_MAIN-2"
    When I make a "GET" call to "GetWalletBalanceWithId" to service "WalletService"
    Then the API call is successful with status code 200
    And the "balance" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-2"
    And the "accountNumber" in response body is "2"
    And the "accountType" in response body is "AT_MAIN"
    And the "currency" in response body is "EUR"

    #NEGATIVE SCENARIO
  @NoRetry
  Scenario: Get - GetWalletBalanceCC (v2.CC) - Invalid account Id
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetWalletBalanceCC" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceCC" of service "WalletService" with configured parameter "accountId" "0"
    When I make a "GET" call to "GetWalletBalanceCC" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Account id incorrect"

  Scenario: Get - GetWalletBalanceCC (v2.CC) - Legacy Account
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetWalletBalanceCC" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetWalletBalanceCC" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceCC" of service "WalletService" with configured parameter "accountId" "AT_MAIN-0"
    When I make a "GET" call to "GetWalletBalanceCC" to service "WalletService"
    Then the API call is successful with status code 200
    And the "currency" in response body is "EUR"
    And the "amount" in response body is "0.0"


  Scenario: Get - GetWalletBalanceCC (v2.CC) - Lottery Account
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetWalletBalanceCC" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceCC" of service "WalletService" with configured parameter "accountId" "AT_MAIN-1"
    When I make a "GET" call to "GetWalletBalanceCC" to service "WalletService"
    Then the API call is successful with status code 200
    And the "currency" in response body is "EUR"
    And the "amount" in response body is "0.0"


  Scenario: Get - GetWalletBalanceCC (v2.CC) - Betting Account
    #Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    #And I change url resource of method "GetWalletBalanceCC" of service "WalletService" with configured playerId "101534629"
    And I change url resource of method "GetWalletBalanceCC" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceCC" of service "WalletService" with configured parameter "accountId" "AT_MAIN-2"
    When I make a "GET" call to "GetWalletBalanceCC" to service "WalletService"
    Then the API call is successful with status code 200
    And the "currency" in response body is "EUR"
    And the "amount" in response body is "0.0"



