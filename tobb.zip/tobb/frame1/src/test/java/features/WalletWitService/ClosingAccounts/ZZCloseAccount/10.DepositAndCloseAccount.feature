@WalletWitService @skipIfNotAzure
Feature: Deposit And Close Account


  Scenario Outline: Close Account via Backoffice - Success
    Given I create Close Account payload with "<status>" "<statusDescription>" "<statusReason>"
    And I change url resource of method "OpenCloseAccountCC" of service "PlayerService" with new playerId
    When I make a "PUT" call to "OpenCloseAccountCC" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "statusReason" in response body is "<statusReason>"

    Examples:

      | status | statusDescription | statusReason   |
      | CLOSED | test              | SELF_EXCLUSION |



    # CLOSES ACCOUNT careful there
  # fix userType
  Scenario Outline: Close Account v4 (API) - Success (again)
    Given I create a CloseAccountV4 Put payload with "<status>" "<statusDescription>" "<statusReason>"
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with configured parameter "userType" "1"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with new playerId
    When I make a "PUT" call to "CloseAccountV4" to service "WalletService"
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "statusReason" in response body is "<statusReason>"

    Examples:

      | keys                     | values                          | status | statusDescription | statusReason   |
      | statusReason,playerLevel | SELF_EXCLUSION,VERIFIED_ACCOUNT | CLOSED | test              | SELF_EXCLUSION |


  Scenario Outline: Open account via BO call - Success
    And I create a OpenAccount Put payload with "<status>" "<statusDescription>" "<statusReason>"
    And I change url resource of method "OpenCloseAccountCC" of service "PlayerService" with new playerId
    When I make a "PUT" call to "OpenCloseAccountCC" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "statusReason" in response body is "<statusReason>"

    Examples:

      | status  | statusDescription            | statusReason |
      | ENABLED | Account was opened by admin. | NONE         |


  @skipIfNotAzure
  Scenario Outline: DatabaseBridge - Update Query in PLCONTRACTAGREEMENT
    Given I create a DataBridge Payload with "<query>"
    When I make a "POST" call to "DatabaseExecute" to service "DatabaseBridgeService"
    Then the API call is successful with status code 200

    Examples:
      | query                                                                                           |
      | UPDATE PLRCONTRACTAGREEMENTS SET STATUS='VALID' WHERE STATUS='REVOKED' AND PLAYERID=newPlayerId |


  Scenario Outline: Deposit via Card - Lottery wallet (Joker) - Success
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 20     |


  Scenario: Commit Card Deposit To Tora
    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card



  Scenario Outline: Close Account via Backoffice - Success
    Given I create Close Account payload with "<status>" "<statusDescription>" "<statusReason>"
    And I change url resource of method "OpenCloseAccountCC" of service "PlayerService" with new playerId
    When I make a "PUT" call to "OpenCloseAccountCC" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "statusReason" in response body is "<statusReason>"

    Examples:

      | status | statusDescription | statusReason   |
      | CLOSED | test              | SELF_EXCLUSION |


  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId via card


  Scenario Outline: Close Account via Backoffice - Success
    Given I create Close Account payload with "<status>" "<statusDescription>" "<statusReason>"
    And I change url resource of method "OpenCloseAccountCC" of service "PlayerService" with new playerId
    When I make a "PUT" call to "OpenCloseAccountCC" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "statusReason" in response body is "<statusReason>"

    Examples:

      | status | statusDescription | statusReason   |
      | CLOSED | test              | SELF_EXCLUSION |

