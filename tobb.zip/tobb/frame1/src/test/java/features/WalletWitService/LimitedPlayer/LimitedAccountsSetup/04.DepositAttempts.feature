@WalletWitService @skipIfNotAzure @LimitedAccountSetup
Feature: Deposit attempts

  @NoRetry
  Scenario Outline: Invalid deposit - User cannot be empty
    Given I login as an Api user
    When I create a Post DepositViaBankAccount payload with "<paymentMethodId>" "<paymentCode>" "<amount>" "<action>" "<operation>" "<paymentType>" "<paymentMethodType>" "<bankId>" "<pspId>" "<pspTargetId>" "<currency>" "<owner>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

    Examples:
      | paymentMethodId        | paymentCode | amount | action  | operation      | paymentMethodType | paymentType    | bankId | pspId          | pspTargetId | currency | owner |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | null   | PREPARE | WALLET_DEPOSIT | BANK_ACCOUNT      | PT_TRANSFER_IN | 112233 | voucherPSPDemo | pspTargetId | EUR      | empty |

  Scenario Outline: Get and Verify - Wallets Balance
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
#    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
#    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 520.0    | 520.0        | 20.0                    | 0.0              | 500.0                | 20.0     | 20.0         | 20.0                    | 0.0              | 0.0                  |

  Scenario Outline: Get and Verify Payment Codes - Category ALL
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 200

    Examples:
      | keys     | values |
      | category | ALL    |

  Scenario Outline: Get and Verify Payment Codes - Category NO_BANK
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 200

    Examples:
      | keys     | values  |
      | category | NONBANK |

  Scenario Outline: Get and Verify Payment Codes - Category IBAN
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 200

    Examples:
      | keys     | values |
      | category | IBAN   |

  Scenario Outline: Wiremock Stub - "Player Service Error"
    Given I setup deposit paymentId "<paymentId>" and card fingerprint "<cardFingerprint1>"
    And I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | paymentId | cardFingerprint1                                                 | scenarioName     | requiredScenarioState | priority | method | url                                              | status | body | headers          |
      | random    | 5a8c3cec619b62ed3b4b4d98f1b57ae0fa3f4b65ca483a0954f0e6c885724566 | PlayerService400 | Started               | 100      | ANY    | /api/customer/rest/v2/customers/.*/verifications | 400    | {\"id\":\"pmt_IEuiimeTppo4AZIHKsKgro2Q\",\"object\":\"payment\",\"captured\":true,\"amount\":5000,\"currency\":\"EUR\",\"description\":\"OPAP wallet deposit id:{{deposit_paymentId}}\",\"meta\":{\"paymentId\":\"{{deposit_paymentId}}\",\"playerId\":\"{{playerId}}\"},\"status\":\"captured\",\"merchant_reference\":\"paymentId:{{deposit_paymentId}}\",\"customer\":null,\"method\":\"card\",\"method_info\":{\"holder_name\":\"TEST PROD\",\"exp_year\":2025,\"exp_month\":6,\"last4\":\"0001\",\"brand\":\"visa\",\"bin\":\"465858\",\"fingerprint\":\"{{Card1_fingerprint}}\"},\"created_at\":\"2019-02-25T13:36:14+00:00\",\"updated_at\":\"2019-02-25T13:36:15+00:00\",\"captured_at\":\"2019-02-25T13:36:15+00:00\",\"refunded\":false,\"refunds\":[],\"refunded_amount\":\"0\",\"fee_amount\":0,\"error_code\":null,\"error_message\":null,\"transaction_id\":\"charge_test_0C2919DE543J66FAA618\"}     | application/json |

  Scenario Outline: Get and Verify Payment Codes via v2CC
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | keys     | values |
      | category | ALL    |

  Scenario: Reset Scenarios
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllScenarios" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Get and Verify Payment Codes - Invalid Category
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Invalid enum value."

    Examples:
      | keys     | values |
      | category | test   |

  Scenario: Get player's payments as Admin - Terminal id is missing
    And I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetPlayerPaymentsAsAdminV2" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Terminal id is missing"


  Scenario Outline: Get player's payments as Admin - Invalid status
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerPaymentsAsAdminV2" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "BAD_REQUEST"
    And the "description" in response body is "Bad Request"

    Examples:
      | keys                          | values      |
      | terminalId,paymentType,status | 0,test,test |

  Scenario Outline: Get player's payments as Admin
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerPaymentsAsAdminV2" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of elements in array "data" is 0

    Examples:
      | keys                          | values          |
      | terminalId,paymentType,status | 0,test,VERIFIED |

