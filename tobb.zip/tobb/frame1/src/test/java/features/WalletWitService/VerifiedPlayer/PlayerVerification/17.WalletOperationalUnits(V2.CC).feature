#AZURE ONLY FEATURE
@WalletWitService @skipIfNotAzure @VerifiedAccountSetup
Feature: Wallet Operational Units Via v2.CC


  Scenario Outline: Post access operations V2 - Deny Operational Units
    Given I create a POST AccessOperations payload with "<buyListId>" "<buyListAccessType>" "<payoutListId>" "<payoutListAccessType>" "<depositListId>" "<depositListAccessType>" "<withdrawListId>" "<withdrawListAccessType>" "<reason>"
    And I change url resource of method "AccessOperationsV2" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV2" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
   # And I check EP, NEP wallets

    Examples:
      | buyListId | buyListAccessType | payoutListId | payoutListAccessType | depositListId | depositListAccessType | withdrawListId | withdrawListAccessType | reason |
      | 123       | DENY              | 123          | DENY                 | 123           | DENY                  | 123            | DENY                   | test   |

  Scenario Outline: Post access operations V2 - Mixed Operational Access Types
    Given I create a POST AccessOperations payload with "<buyListId>" "<buyListAccessType>" "<payoutListId>" "<payoutListAccessType>" "<depositListId>" "<depositListAccessType>" "<withdrawListId>" "<withdrawListAccessType>" "<reason>"
    And I change url resource of method "AccessOperationsV2" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV2" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
   # And I check EP, NEP wallets

    Examples:
      | buyListId | buyListAccessType | payoutListId | payoutListAccessType | depositListId | depositListAccessType | withdrawListId | withdrawListAccessType | reason |
      | 123       | DENY              | 123          | ALLOW                | 123           | DENY                  | 123            | ALLOW                  | test   |


  Scenario Outline: Post access operations V2 - Restore Status Of wallet Operational Units (ALLOW)
    Given I create a POST AccessOperations payload with "<buyListId>" "<buyListAccessType>" "<payoutListId>" "<payoutListAccessType>" "<depositListId>" "<depositListAccessType>" "<withdrawListId>" "<withdrawListAccessType>" "<reason>"
    And I change url resource of method "AccessOperationsV2" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV2" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
   # And I check EP, NEP wallets

    Examples:
      | buyListId | buyListAccessType | payoutListId | payoutListAccessType | depositListId | depositListAccessType | withdrawListId | withdrawListAccessType | reason |
      | 123       | ALLOW             | 123          | ALLOW                | 123           | ALLOW                 | 123            | ALLOW                  |        |

  Scenario: Get access operations V2 - Assertions
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AccessOperationsV2" of service "WalletService" with new playerId
    Then I make a "GET" call to "AccessOperationsV2" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    #And I check EP, NEP wallets


