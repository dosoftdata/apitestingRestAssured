#recheck why we need this
@WalletWitService @VerifiedAccountSetup
Feature: Add Credit Card To Player And Verify

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |


  @skipIfAzure
  Scenario Outline: Set Master Card Details
    Given I login as an Api user
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId

    @skipIfPreprod
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |


    @skipIfNotPreprod
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5199992312641465 | TEST PROD  | 010 | 06        | 2030     | EUR      | pk_U0jMXzvD8cOv0kx0qDHghRVZ56TCELA7 |


  @skipIfAzure
  Scenario: Commit Card Deposit To Tora
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  @skipIfNotAzure
  Scenario: Commit Card Deposit To Tora
    And I setup a random deposit token Id
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card



