#IN PROGRESS AZURE ONLY
#IF paymentId is empty it takes the default one.
@WalletWitService @skipIfNotAzure
Feature: Refund Card Deposit In Case Of Wallet Failure

  #########################################################REASON INSUFFICIENT BALANCE###########################################################

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 150    |


  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


    ###STUBS
  Scenario Outline: Wiremock Stub 1- Wallet Service Response 500 - Insufficient Balance
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                             |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 400    | application/json | {\"errorId\":\"BALANCE_INSUFFICIENT\",\"description\":\"No sufficient balance\"} |

  Scenario Outline: Wiremock Stub 2 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |


  ######
#TODO: Check if this is ok (request e.t.c)
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "BALANCE_INSUFFICIENT"
    And the "description" in response body is "No sufficient balance"


  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 150    | AT_MAIN     | CARD   | EUR      | 1         |


   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

    #########################################################################################################

  ####################################### REASON: Insufficient funds   #######################################################################
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 3 - Wallet Service Response 500 - Insufficient Funds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                         |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 400    | application/json | {\"errorId\":\"INSUFFICIENT_FUNDS\",\"description\":\"No sufficient funds\"} |

  Scenario Outline: Wiremock Stub 4 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INSUFFICIENT_FUNDS"
    And the "description" in response body is "No sufficient funds"


  Scenario Outline: Reject deposit via Tora - Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |


   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |



  ####################################### REASON: Invalid Argument  #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 5 - Wallet Service Response 500 - Insufficient Funds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                   |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 400    | application/json | {\"errorId\":\"INVALID_ARGUMENT\",\"description\":\"Invalid argument\" |

  Scenario Outline: Wiremock Stub 6 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######

        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "The payment request contains invalid argument"


  Scenario Outline: Reject deposit via Tora - Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |


    ####################################### REASON: Reason: No verified Skrill deposit exists  #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 7 - Wallet Service Response 500 - Insufficient Funds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                                                      |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 400    | application/json | {\"errorId\":\"NO_VERIFIED_SKRILL_DEPOSIT_EXISTS\",\"description\":\"No verified Skrill deposit exists\"} |

  Scenario Outline: Wiremock Stub 8 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "NO_VERIFIED_SKRILL_DEPOSIT_EXISTS"
    And the "description" in response body is "No verified Skrill deposit exists"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

        ####################################### Reason: Payment method not supported  #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 7 - Wallet Service Response 500 - Insufficient Funds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                                            |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 400    | application/json | {\"errorId\":\"PAYMENT_METHOD_NOT_SUPPORTED\",\"description\":\"Payment method not supported\"} |

  Scenario Outline: Wiremock Stub 8 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "PAYMENT_METHOD_NOT_SUPPORTED"
    And the "description" in response body is "Payment method not supported"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

   ####################################### Reason: Invalid Payment Code #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 12 - Wallet Service Response 500 - Invalid Payment Code
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                            |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 500    | application/json | {\"errorId\":\"INVALID_PAYMENT_CODE\",\"description\":\"Invalid payment code\"} |

  Scenario Outline: Wiremock Stub 13 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INVALID_PAYMENT_CODE"
    And the "description" in response body is "Invalid payment code"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |


   ####################################### Reason: No Payment Method #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 12 - Wallet Service Response 500 - Invalid Payment Code
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                      |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 500    | application/json | {\"errorId\":\"NO_PAYMENT_METHOD\",\"description\":\"No payment method\"} |

  Scenario Outline: Wiremock Stub 13 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "NO_PAYMENT_METHOD"
    And the "description" in response body is "No payment method"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

   ####################################### Reason: Payment Access Rejected #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 12 - Wallet Service Response 500 - Invalid Payment Code
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                                  |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 500    | application/json | {\"errorId\":\"PAYMENT_ACCESS_REJECTED\",\"description\":\"Payment access rejected\"} |

  Scenario Outline: Wiremock Stub 13 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "PAYMENT_ACCESS_REJECTED"
    And the "description" in response body is "Payment access rejected"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

   ####################################### Reason: Exceeded Skrill Withdrawals #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 12 - Wallet Service Response 500 - Invalid Payment Code
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                                          |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 500    | application/json | {\"errorId\":\"EXCEEDED_SKRILL_WITHDRAWALS\",\"description\":\"Exceeded Skrill withdrawals\"} |

  Scenario Outline: Wiremock Stub 13 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "EXCEEDED_SKRILL_WITHDRAWALS"
    And the "description" in response body is "Exceeded Skrill withdrawals"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

       ####################################### Reason: Invalid Payments #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 12 - Wallet Service Response 500 - Invalid Payment Code
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                    |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 500    | application/json | {\"errorId\":\"INVALID_PAYMENTS\",\"description\":\"Invalid payments\"} |

  Scenario Outline: Wiremock Stub 13 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INVALID_PAYMENTS"
    And the "description" in response body is "Invalid payments"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |


       ####################################### Reason: Invalid Payments #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 12 - Wallet Service Response 500 - Payment Code Not Found
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                                |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 500    | application/json | {\"errorId\":\"PAYMENT_CODE_NOT_FOUND\",\"description\":\"Payment code not found\"} |

  Scenario Outline: Wiremock Stub 13 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "PAYMENT_CODE_NOT_FOUND"
    And the "description" in response body is "Payment code not found"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

         ####################################### Reason: Unverified Player Withdrawals #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 18 - Wallet Service Response 500 - Payment Code Not Found
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                                                                  |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 500    | application/json | {\"errorId\":\"RESPONSE_WALLET_ERROR_UNVERIFIED_PLAYER_WITHDRAWAL\",\"description\":\"Unverified player withdrawal\"} |

  Scenario Outline: Wiremock Stub 19 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "RESPONSE_WALLET_ERROR_UNVERIFIED_PLAYER_WITHDRAWAL"
    And the "description" in response body is "Unverified player withdrawal"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

         ####################################### Reason: Player Consent Required #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 18 - Wallet Service Response 500 - Player Consent Required
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                                     |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 451    | application/json | {\"errorId\":\"PLAYER_CONSENT_REQUIRED\",\"description\":\"Player consent is required\"} |

  Scenario Outline: Wiremock Stub 19 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks - Player consent is required
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 451
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"
    And the "description" in response body is "Player consent is required"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

             ####################################### Reason: Mandatory Limits Not Set #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 18 - Wallet Service Response 500 - Player Consent Required
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                                     |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 451    | application/json | {\"errorId\":\"MANDATORY_LIMITS_NOT_SET\",\"description\":\"Mandatory limits not set!\"} |

  Scenario Outline: Wiremock Stub 19 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks - Mandatory limits not set
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 451
    And the "errorId" in response body is "MANDATORY_LIMITS_NOT_SET"
    And the "description" in response body is "Mandatory limits not set!"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

         ####################################### Reason: Communication Error #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 18 - Wallet Service Response 500 - Communication Error
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                          |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 500    | application/json | {\"errorId\":\"COMMUNICATION_ERROR\",\"description\":\"Communication error\"} |

  Scenario Outline: Wiremock Stub 19 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks - Communication error
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "COMMUNICATION_ERROR"
    And the "description" in response body is "Communication error"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |


 ####################################### Reason: Random Error #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |


        ###STUBS
  Scenario Outline: Wiremock Stub 18 - Wallet Service Response 500 - Communication Error
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                  |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 500    | application/json | {\"errorId\":\"RANDOM_ERROR\",\"description\":\"Random error by QA\"} |

  Scenario Outline: Wiremock Stub 19 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks - Communication error
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "RANDOM_ERROR"
    And the "description" in response body is "Random error by QA"

  Scenario Outline: Reject deposit via Tora -Previous call leaves it in PENDING VERIFY
    Given I login as an Api user
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      |           | REVIEW             | 30     | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |



 ####################################### Payment has already been approved - Header not included in /v1/events call #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Non Exclusive games SPORTSBOOK
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |

    #1.
    ######### TORA SENDING CAPTURE REQUEST
  #2.Verify payment via Tora Events (Method Card)


        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks - Communication error
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 204

  #Verify payment via wallet api

  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |


 ####################################### Payment has already been approved - Different Header in /v1/events than the one in preparing the payment #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Non Exclusive games SPORTSBOOK
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |

    #1.
    ######### TORA SENDING CAPTURE REQUEST
  #2.Verify payment via Tora Events (Method Card)


        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks - Communication error
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 204

  #Verify payment via wallet api

  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

 ####################################### Payment has already been approved - Different Header in /v1/events than the one in preparing the payment #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Non Exclusive games SPORTSBOOK
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |

    #1.
    ######### TORA SENDING CAPTURE REQUEST
  #2.Verify payment via Tora Events (Method Card)


        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks - Communication error
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 204

  #Verify payment via wallet api

  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

     ####################################### Payment has already been approved  #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Non Exclusive games SPORTSBOOK
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |

    #1.
    ######### TORA SENDING CAPTURE REQUEST


  #2.Verify payment via Tora Events (Method Card) - RECHECK
        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks - Already Approved
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 204

#TODO: here deposit id maybe not same with verify? -withdrawal/deposit
  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId via card

  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

     ####################################### Reason: Limited Exceeded (Fail to deposit and refund) #######################################################################

  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  Scenario Outline: Valid deposit card - Non Exclusive games SPORTSBOOK
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card


    Examples:
      | amount |
      | 50     |

  Scenario Outline: Put - Precommit payment directly to wallet
    Given I create a PUT PrecommitPaymentToWallet payload with <serviceCostAmount> "<issuerId>" "<cardType>" "<cardName>" "<cardNumber>" "<expiryMonth>" "<expiryYear>" "<accountNumber>" "<paymentCode>" "<fingerprint>"
    And I make a "PUT" call to "PrecommitPaymentToWallet" to service "WalletService"
    Then the API call is successful with status code 204

    Examples:
      | serviceCostAmount | issuerId | cardType | cardName  | cardNumber | expiryMonth | expiryYear | accountNumber    | paymentCode | fingerprint |
      | 1                 |          | CARD     | TESP PROD |            | 12          | 2025       | 0000011047025496 |             |             |

        ###STUBS
  Scenario Outline: Wiremock Stub 12 - Wallet Service Response 500 - Invalid Payment Code
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName             | requiredScenarioState | priority | method | url                             | status | headers          | body                                                                |
      | WalletServiceResponse500 | Started               |          | PUT    | .*api/wallet/rest/v3/payments.* | 500    | application/json | {\"errorId\":\"LIMIT_EXCEEDED\",\"description\":\"Limit exceeded\"} |

  Scenario Outline: Wiremock Stub 13 - Tora Response 200 for Refunds
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName           | requiredScenarioState | priority | method | url           | status | headers          | body                                   |
      | ToraRefundsResponse200 | Started               |          | ANY    | .*/v1/refunds | 200    | application/json | {\"id\":\"1\",\"status\":\"captured\"} |

  ######

        #TODO: Check change body or not needed.Is this ok cause of mocks?
  Scenario: Verify payment via Tora webhooks - Communication error
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 50
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 409
    And the "errorId" in response body is "LIMIT_EXCEEDED"
    And the "description" in response body is "The payment exceeded a limit for player"


  #Check amount and deposit id
  Scenario Outline: Get Last Transaction
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetLastTransaction" to service "WalletService"
    And I change url resource of method "GetLastTransaction" of service "WalletService" with new via card deposit paymentId
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And the "paymentType" in response body is "<paymentType>"
    And the "paymentMethodType" in response body is "<paymentMethodType>"
    And the "origin" in response body is "<origin>"
    And the "amount" in response body is "<amount>"
    And the "destination" in response body is "<destination>"
    And the "currency" in response body is "<currency>"
    And the "owner.type" in response body is "<ownerType>"

    Examples:
      | status   | paymentType    | paymentMethodType | amount | destination | origin | currency | ownerType |
      | REJECTED | PT_TRANSFER_IN | PMT_CARD          | 50     | AT_MAIN     | CARD   | EUR      | 1         |

   #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |



