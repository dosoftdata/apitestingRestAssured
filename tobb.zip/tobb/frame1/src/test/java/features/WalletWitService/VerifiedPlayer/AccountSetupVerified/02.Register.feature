@WalletWitService @VerifiedAccountSetup
Feature: Register Feature

  Scenario Outline: Register - Verify same request values in response
    Given I setup gameId header to "<xGameId>"
    And I create a Register payload with "<username>" "<password>" "<email>" "<identityType>" "<firstName>" "<middleName>" "<lastName>" "<gender>" "<dateOfBirth>" "<country>" "<address1>" "<profession>" "<city>" "<zipCode>" "<bonusCode>" "<secretQuestion>" "<secretAnswer>" "<ibanNumber>" "<permanentResidenceCountry>"
    When I make a "POST" call to "RegisterPlayer" to service "PlayerService"
    Then the API call is successful with status code 200
    And I copy the value of the player id "id" from the response
    And the "sendOtpOnRegistration" in response body has value not null
    And the "dateOfBirth" in response body is "<dateOfBirth>"
    And the "firstName" in response body is "<firstName>"
    And the "middleName" in response body is "<middleName>"
    And the "lastName" in response body is "<lastName>"
    And the "address1" in response body is "<address1>"
    And the "identityType" in response body is "<identityType>"
    And the "country" in response body is "<country>"
    And the "gender" in response body is "<gender>"
    And the "zip" in response body is "<zipCode>"
    And the "city" in response body is "<city>"
    And the "permanentResidenceCountry" in response body is "<permanentResidenceCountry>"

    Examples:
      | xGameId | username    | password     | email       | identityType | firstName | middleName | lastName | gender | dateOfBirth | country | address1           | profession | city   | zipCode | bonusCode            | secretQuestion     | secretAnswer  | ibanNumber                  | permanentResidenceCountry |
      | JOKER   | restAssured | Qwerty12345! | restAssured | OTHER        | PAM       | LOTTERY    | PLATFORM | M      | 1940-09-29  | GR      | First Address 0100 | Unemployed | Athens | 15125   | THIS_IS_A_BONUS_CODE | What is your name? | restAssuredAI | GR2202655559367039137283047 | GRC                       |

