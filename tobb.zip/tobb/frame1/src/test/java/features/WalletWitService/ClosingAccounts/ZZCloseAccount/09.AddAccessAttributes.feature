#Maybe this feature is optional check flow.
@WalletWitService @skipIfNotAzure
Feature: Add Access Attributes





