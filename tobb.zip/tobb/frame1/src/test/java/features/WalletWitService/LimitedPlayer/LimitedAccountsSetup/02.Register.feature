@WalletWitService @LimitedAccountSetup
Feature: Register - Limited player

  Scenario Outline: Register - Limited Accounts
    Given I setup gameId header to "<xGameId>"
    And I create a Register payload with "<username>" "<password>" "<email>" "<identityType>" "<firstName>" "<middleName>" "<lastName>" "<gender>" "<dateOfBirth>" "<country>" "<address1>" "<profession>" "<city>" "<zipCode>" "<bonusCode>" "<secretQuestion>" "<secretAnswer>" "<ibanNumber>" "<permanentResidenceCountry>"
    When I make a "POST" call to "RegisterPlayer" to service "PlayerService"
    Then the API call is successful with status code 200
    And I copy the value of the player id "id" from the response
    And the "sendOtpOnRegistration" in response body has value not null
    And the "dateOfBirth" in response body is "<dateOfBirth>"
    And the "firstName" in response body is "<firstName>"
    And the "middleName" in response body is "<middleName>"
    And the "lastName" in response body is "<lastName>"
    And the "address1" in response body is "<address1>"
    And the "identityType" in response body is "<identityType>"
    And the "country" in response body is "<country>"
    And the "gender" in response body is "<gender>"
    And the "zip" in response body is "<zipCode>"
    And the "city" in response body is "<city>"
    And the "permanentResidenceCountry" in response body is "<permanentResidenceCountry>"

    Examples:
      | xGameId | username          | password     | email                   | identityType | firstName | middleName | lastName | gender | dateOfBirth | country | address1           | profession | city   | zipCode | bonusCode            | secretQuestion     | secretAnswer            | ibanNumber                  | permanentResidenceCountry |
      | JOKER   | opapwalletlimited | Qwerty12345! | opapwalletlimitedplayer | OTHER        | TEST      | WALLET     | LIMITED  | M      | 1940-09-29  | GR      | First Address 0100 | Unemployed | Athens | 15125   | THIS_IS_A_BONUS_CODE | What is your name? | opapwalletlimitedplayer | GR2202655559367039137283047 | GRC                       |

  @Concat @NoRetry
  Scenario: Get Legacy account by id via V1.API - Missing accountId - Negative
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountV1" of service "WalletService" with new playerId
    And I concat the url "/test" to the end of url of method "GetAccountV1" of service "WalletService"
    And I make a "GET" call to "GetAccountV1" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Account id incorrect"

  @Concat @NoRetry
  Scenario: Get Legacy account by id via V1.API - Invalid wallet type - Negative
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountV1" of service "WalletService" with new playerId
    And I concat the url "/AT-1" to the end of url of method "GetAccountV1" of service "WalletService"
    And I make a "GET" call to "GetAccountV1" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Account id incorrect"

  @Concat @NoRetry
  Scenario: Get Legacy account by id via V1.API - Invalid wallet number - Negative
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountV1" of service "WalletService" with new playerId
    And I concat the url "/AT_MAIN-" to the end of url of method "GetAccountV1" of service "WalletService"
    And I make a "GET" call to "GetAccountV1" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Account id incorrect"

  @Concat @NoRetry
  Scenario: Get Legacy account by id via V1.API - AT_MAIN-0
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountV1" of service "WalletService" with new playerId
    And I concat the url "/AT_MAIN-0" to the end of url of method "GetAccountV1" of service "WalletService"
    And I make a "GET" call to "GetAccountV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the "reservedBalance.currency" in response body is "EUR"
    And the "reservedBalance.amount" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-0"
    And the "buyingPower.amount" in response body is "0.0"
    And the "buyingPower.currency" in response body is "EUR"
    And the "balance.amount" in response body is "0.0"
    And the "balance.currency" in response body is "EUR"

  @Concat @NoRetry
  Scenario: Get Legacy account by id via V1.API - AT_MAIN-1
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountV1" of service "WalletService" with new playerId
    And I concat the url "/AT_MAIN-1" to the end of url of method "GetAccountV1" of service "WalletService"
    And I make a "GET" call to "GetAccountV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the "reservedBalance.currency" in response body is "EUR"
    And the "reservedBalance.amount" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-1"
    And the "buyingPower.amount" in response body is "0.0"
    And the "buyingPower.currency" in response body is "EUR"
    And the "balance.amount" in response body is "0.0"
    And the "balance.currency" in response body is "EUR"

  @Concat @NoRetry
  Scenario: Get Legacy account by id via V1.API - AT_MAIN-2
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountV1" of service "WalletService" with new playerId
    And I concat the url "/AT_MAIN-2" to the end of url of method "GetAccountV1" of service "WalletService"
    And I make a "GET" call to "GetAccountV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the "reservedBalance.currency" in response body is "EUR"
    And the "reservedBalance.amount" in response body is "0.0"
    And the "id" in response body is "AT_MAIN-2"
    And the "buyingPower.amount" in response body is "0.0"
    And the "buyingPower.currency" in response body is "EUR"
    And the "balance.amount" in response body is "0.0"
    And the "balance.currency" in response body is "EUR"

  @Concat @NoRetry
  Scenario: Get Legacy account by id via V1.API - AT_MAIN-0
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountV2" of service "WalletService" with new playerId
    And I concat the url "/AT_MAIN-0" to the end of url of method "GetAccountV2" of service "WalletService"
    And I make a "GET" call to "GetAccountV2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "accountId" in response body is "AT_MAIN-0"
    And the "currency" in response body is "EUR"
    And the "balance" in response body is "0.0"
    And the "reservedBalance" in response body is "0.0"

  @Concat @NoRetry
  Scenario: Get Legacy account by id via V1.API - AT_MAIN-1
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountV2" of service "WalletService" with new playerId
    And I concat the url "/AT_MAIN-1" to the end of url of method "GetAccountV2" of service "WalletService"
    And I make a "GET" call to "GetAccountV2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "accountId" in response body is "AT_MAIN-1"
    And the "currency" in response body is "EUR"
    And the "balance" in response body is "0.0"
    And the "reservedBalance" in response body is "0.0"

  @Concat @NoRetry
  Scenario: Get Legacy account by id via V1.API - AT_MAIN-2
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountV2" of service "WalletService" with new playerId
    And I concat the url "/AT_MAIN-2" to the end of url of method "GetAccountV2" of service "WalletService"
    And I make a "GET" call to "GetAccountV2" to service "WalletService"
    Then the API call is successful with status code 200
    And the "accountId" in response body is "AT_MAIN-2"
    And the "currency" in response body is "EUR"
    And the "balance" in response body is "0.0"
    And the "reservedBalance" in response body is "0.0"

  @NoRetry
  Scenario Outline: Invalid deposit - Amount cannot be null
    Given I login as an Api user
    When I create a Post DepositViaBankAccount payload with "<paymentMethodId>" "<paymentCode>" "<amount>" "<action>" "<operation>" "<paymentType>" "<paymentMethodType>" "<bankId>" "<pspId>" "<pspTargetId>" "<currency>" "<owner>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

    Examples:
      | paymentMethodId        | paymentCode | amount | action  | operation      | paymentMethodType | paymentType    | bankId | pspId          | pspTargetId | currency | owner           |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | null   | PREPARE | WALLET_DEPOSIT | BANK_ACCOUNT      | PT_TRANSFER_IN | 112233 | voucherPSPDemo | pspTargetId | EUR      | PlayerIdLimited |

  @NoRetry
  Scenario Outline: Invalid deposit - User cannot be empty
    Given I login as an Api user
    When I create a Post DepositViaBankAccount payload with "<paymentMethodId>" "<paymentCode>" "<amount>" "<action>" "<operation>" "<paymentType>" "<paymentMethodType>" "<bankId>" "<pspId>" "<pspTargetId>" "<currency>" "<owner>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

    Examples:
      | paymentMethodId        | paymentCode | amount | action  | operation      | paymentMethodType | paymentType    | bankId | pspId          | pspTargetId | currency | owner |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | null   | PREPARE | WALLET_DEPOSIT | BANK_ACCOUNT      | PT_TRANSFER_IN | 112233 | voucherPSPDemo | pspTargetId | EUR      | empty |


  @NoRetry
  Scenario Outline: Invalid deposit - User cannot deposit, different payments
    Given I login as an Api user
    And I setup gameId header to "JOKER"
    And I create a Get "api_specWithGameId" header
    When I create a Post DepositViaBankAccount payload with "<paymentMethodId>" "<paymentCode>" "<amount>" "<action>" "<operation>" "<paymentType>" "<paymentMethodType>" "<bankId>" "<pspId>" "<pspTargetId>" "<currency>" "<owner>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"

    Examples:
      | paymentMethodId        | paymentCode | amount | action    | operation      | paymentMethodType | paymentType    | bankId | pspId          | pspTargetId | currency | owner           |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 800.0  | PREPARE   | WALLET_DEPOSIT | BANK_ACCOUNT      | PT_TRANSFER_IN | 112233 | voucherPSPDemo | pspTargetId | EUR      | PlayerIdLimited |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 800.0  | AUTHORIZE | WALLET_DEPOSIT | BANK_ACCOUNT      | PT_TRANSFER_IN | 112233 | voucherPSPDemo | pspTargetId | EUR      | PlayerIdLimited |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 800.0  | COMMIT    | WALLET_DEPOSIT | BANK_ACCOUNT      | PT_TRANSFER_IN | 112233 | voucherPSPDemo | pspTargetId | EUR      | PlayerIdLimited |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 800.0  | PREPARE   | WALLET_DEPOSIT | BANK_ACCOUNT      | PT_TRANSFER_IN | 112233 | voucherPSPDemo | pspTargetId | EUR      | PlayerIdLimited |

  Scenario Outline: Get MailId For Fetch Hash - Verify origin has value player
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "<array>" is 1
    And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
    And I copy the value of the mailId from the response

    Examples:
      | key      | value    | property | propertyValue | array | arrayWithIndex |
      | playerId | changeit | origin   | player        | data  | data[0]        |

  Scenario Outline: Get hash For Mail Verification - Verify event name/owner
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetHashForMailVerification" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the "<property>" in response body is "<propertyValue>"
    And the "<property2>" in response body is "<propertyValue2>"
    And the id in response body is mailIdForHash
    And I copy the value of the hash from the response

    Examples:
      | property  | propertyValue                       | property2  | propertyValue2 |
      | eventName | registrationWelcomeEvent.opaponline | eventOwner | player         |

  Scenario: Verify Player's Email - Call to verify player's email
    Given I create a VerifyEmail payload with inner playerId and hash
    When I make a "POST" call to "VerifyPlayersEmail" to service "PlayerService"
    Then the API call is successful with status code 204

