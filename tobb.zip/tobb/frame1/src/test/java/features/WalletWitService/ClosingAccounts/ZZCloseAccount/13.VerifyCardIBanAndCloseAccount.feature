#generally written needs some fixes here
@WalletWitService
Feature: Verify Card Iban And Close Account


  Scenario Outline: Get BO Pending Verifications of Player - Verify Card values
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    #change assertion? not sure about card her
 #   And I verify Card Pending Verification with status "<status>" "<cardExpirationYear>" "<cardName>" "<cardNumber>" "<cardHolderName>" "<cardExpirationMonth>"


    Examples:
      | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
      | WAITING_ADMIN_APPROVAL | 2025               | master   | 541333******1031 | TEST PROD      | 06                  |


  Scenario Outline: Upload card Documents (Front)
    When I create a UploadDocumentsWeb payload with "<fileName>" "<type>"
    And I change url resource of method "UploadDocumentsWeb" of service "PlayerService" with new playerId
    When I make a "POST" call to "UploadDocumentsWeb" to service "PlayerService"
    Then the API call is successful with status code 200
    Examples:
      | fileName    | type       |
      | IDfront.JPG | CARD_FRONT |

#not sure about card number here
  Scenario Outline: Get BO Pending Verifications of Player - Verify Card values
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Card Pending Verification with status "<status>" "<cardExpirationYear>" "<cardName>" "<cardNumber>" "<cardHolderName>" "<cardExpirationMonth>"

    Examples:
      | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
      | WAITING_ADMIN_APPROVAL | 2025               | master   | 541333******1031 | TEST PROD      | 06                  |

  #  Examples:
  #    | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
    #  | WAITING_ADMIN_APPROVAL | 2025               | master   | 519999******1465 | TEST PROD      | 06                  |


  Scenario Outline: Get Uploaded documents - Verify Card Documents (CARD_FRONT)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUploadedDocuments" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetUploadedDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Uploaded Documents with "<types>" "<fileName>" "<fileType>"

    Examples:
      | types      | fileName    | fileType   |
      | CARD_FRONT | IDfront.JPG | image/jpeg |


########### subType : This variable is not send in request but to specify the variable in which the verification is done
########### subType values : FRONT,BACK (for CARD type) - OTHER,UTILITY (for IDENTITY type)
  Scenario Outline: Verify Card Documents - CARD FRONT
    When I create a VerifyDocuments payload with "<verificationType>" "<statusDescription>" and subcategory "<subType>"
    And I change url resource of method "VerifyDocuments" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerifyDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "verificationType" in response body is "<verificationType>"
    And the "documentType" in response body is "<documentTypeResponse>"
    And the "statusDescription" in response body is "<statusDescription>"
    And the "status" in response body is "<statusValue>"


    Examples:
      | verificationType | statusDescription                  | subType | statusValue | documentTypeResponse |
      | CARD             | Approve uploaded document for Card | FRONT   | APPROVED    | CARD_FRONT           |

  Scenario Outline: Confirm Verification of Player's Card - Verify Type/Status and save cardNumber
    When I create a VerificationConfirm payload with "<verificationType>"
    And I change url resource of method "VerificationConfirm" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerificationConfirm" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "verificationType" in response body is "<verificationType>"
    And the "status" in response body is "<statusValue>"
    And I copy the value of the fingerprint from the response
    And I copy the value of the cardNumber from the response

    Examples:
      | verificationType | statusValue |
      | CARD             | VERIFIED    |


    #new method
  Scenario: Get and Verify Payment Codes Web - Success Scenario
    When I create a Get "mainSpec" header
    And I change url resource of method "GetPaymentCodesWeb" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodesWeb" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    #MORE ASSERTIONS HERE
   # And I copy the values of the Payment Codes




# CLOSES ACCOUNT careful there
  # fix userType
  Scenario Outline: Close Account v4 - 200 - OPEN_PAYMENTS_EXIST
    Given I create a CloseAccountV4 Put payload with "<status>" "<statusDescription>" "<statusReason>"
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with configured parameter "userType" "1"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with new playerId
    When I make a "PUT" call to "CloseAccountV4" to service "WalletService"
    Then the API call is successful with status code 200
    And the property "reason" in response body array with index "reasons[0]" has value "PAYMENT_METHOD_NOT_REGISTERED"
    And the property "reason" in response body array with index "reasons[1]" has value "PAYMENT_METHOD_NOT_REGISTERED"
    And the "closeable" in response body is "false"
    #check boolean other way if not working


    Examples:

      | keys                     | values                          | status | statusDescription | statusReason   |
      | statusReason,playerLevel | SELF_EXCLUSION,VERIFIED_ACCOUNT | CLOSED | test              | SELF_EXCLUSION |


    #in progress.. which iban?
  Scenario Outline: Verify IBAN Account
    Given I login as an Api user
    And I create a Post VerifyIBAN payload with iban "<iban>"
    And I change url resource of method "VerifyIBAN" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerifyIBAN" to service "PlayerService"
    Then the API call is successful with status code 204

    Examples:
      | iban                        |
      | GR2202655559367039137283047 |


    # CLOSES ACCOUNT careful there
  # fix userType
  Scenario Outline: Close Account v4 - 200 - OPEN_PAYMENTS_EXIST
    Given I create a CloseAccountV4 Put payload with "<status>" "<statusDescription>" "<statusReason>"
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with configured parameter "userType" "1"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with new playerId
    When I make a "PUT" call to "CloseAccountV4" to service "WalletService"
    Then the API call is successful with status code 200
    And the property "reason" in response body array with index "reasons[0]" has value "WALLET_CLOSING_IN_PROGRESS"


    Examples:

      | keys                     | values                          | status | statusDescription | statusReason   |
      | statusReason,playerLevel | SELF_EXCLUSION,VERIFIED_ACCOUNT | CLOSED | test              | SELF_EXCLUSION |


  Scenario Outline: Get player's payments as Admin
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerPaymentsAsAdmin" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 0
    #extra assertions

    Examples:
      | keys                           | values          |
      | customerId,pageNumber,pageSize | changeit,1,1000 |

   # CLOSES ACCOUNT careful there
  # fix userType
  Scenario Outline: Close Account v4 - 200 - OPEN_PAYMENTS_EXIST
    Given I create a CloseAccountV4 Put payload with "<status>" "<statusDescription>" "<statusReason>"
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with configured parameter "userType" "1"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with new playerId
    When I make a "PUT" call to "CloseAccountV4" to service "WalletService"
    Then the API call is successful with status code 200
    And the property "reason" in response body array with index "reasons[0]" has value "OPEN_PAYMENTS_EXIST"
    And the "closeable" in response body is "false"
    #check boolean other way if not working


    Examples:

      | keys                     | values                          | status | statusDescription | statusReason   |
      | statusReason,playerLevel | SELF_EXCLUSION,VERIFIED_ACCOUNT | CLOSED | test              | SELF_EXCLUSION |
