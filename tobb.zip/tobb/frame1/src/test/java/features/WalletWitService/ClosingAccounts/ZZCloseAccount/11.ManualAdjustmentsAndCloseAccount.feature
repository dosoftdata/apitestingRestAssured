@WalletWitService
Feature: Manual Adjustments And Close Account

    #should have 1 wallet? check
  Scenario Outline: Get and Verify Wallets Balance
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
   # And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 1390.0   | 1390.0       | 890.0                   | 0.0              | 500.0                | 20.0     | 20.0         | 20.0                    | 0.0              | 0.0                  |


  Scenario Outline: Manual adjustment for Deposit in Lottery wallet via BO - Non-withdrawable & Withdrawable
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Lottery wallet"
    When I change url resource of method "ManualAdjustLotteryWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustLotteryWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "<productId>"
    And the "transactionType" in response body is "<transactionType>"
    And the "transactionSubType" in response body is "<transactionSubType>"
    And the "operation" in response body is "<operation>"
    And the "amount" in response body is "<amount>"

    Examples:
      | transactionType                   | transactionSubType | productId | operation | amount |
      | TT_MANUAL_ADJUST_NON_WITHDRAWABLE | MFDD               | JOKER     | DEPOSIT   | 50.0   |
      | TT_MANUAL_ADJUST                  | MFDD               | JOKER     | DEPOSIT   | 50.0   |

#check only 1 wallet?
  Scenario Outline: Get and Verify Wallets Balance
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
   # And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 1390.0   | 1390.0       | 890.0                   | 0.0              | 500.0                | 120.0    | 70.0         | 50.0                    | 0.0              | 50.0                 |




    # CLOSES ACCOUNT careful there
  # fix userType
  @skipIfNotAzure
  Scenario Outline: Close Account v4 - Success
    Given I create a CloseAccountV4 Put payload with "<status>" "<statusDescription>" "<statusReason>"
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with configured parameter "userType" "1"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with new playerId
    When I make a "PUT" call to "CloseAccountV4" to service "WalletService"
    Then the API call is successful with status code 200
    And the property "reason" in response body array with index "reasons[0]" has value "PAYMENT_METHOD_NOT_REGISTERED"
    And the "closable" in response body is "false"


    Examples:

      | keys                     | values                          | status | statusDescription | statusReason   |
      | statusReason,playerLevel | SELF_EXCLUSION,VERIFIED_ACCOUNT | CLOSED | test              | SELF_EXCLUSION |
