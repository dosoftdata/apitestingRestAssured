@WalletWitService  @skipIfNotAzure
Feature: Reject Payments

 #Check how much balance should be here.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

  Scenario Outline: Deposit via Card - Betting wallet (Casino)
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "CASINO"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And the "status" in response body is "APPROVED"

    Examples:
      | amount |
      | 30     |


  Scenario: Reject deposit via Tora - Missing Information
    Given I login as an Api user
    And I create an empty payload with header "api_mainSpec_mainHost"
    #Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "VALIDATION_ERROR"
    And the response contains "Withdraw Data object is empty"
    And the response contains "Webhook token object is empty"
    And the response contains "EventId object is empty"
    And the response contains "Event object is empty"


  Scenario Outline: Reject deposit via Tora - Invalid Data
    Given I login as an Api user
    And I create an empty payload with header "api_mainSpec_mainHost"
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_JSON"
    And the "description" in response body is "Invalid JSON input"



    Examples:
      | paymentId | preconditionStatus | amount | iban | name | bankName | accountNumber |
      |           |                    | 0      |      |      |          |               |

  Scenario Outline: Reject deposit via Tora - Wrong Payment Id
    Given I login as an Api user
    And I create an empty payload with header "api_mainSpec_mainHost"
    Given I create a POST RejectDepositViaTora payload with "<paymentId>" "<preconditionStatus>" <amount> "<iban>" "<name>" "<bankName>" "<accountNumber>"
    And I make a "POST" call to "RejectDepositViaTora" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"


    Examples:
      | paymentId | preconditionStatus | amount | iban                        | name               | bankName                     | accountNumber    |
      | 9999990   | REVIEW             | 0      | GR6501101100000011047025496 | Sotiris Antoniadis | NATIONAL BANK OF GREECE S.A. | 0000011047025496 |
