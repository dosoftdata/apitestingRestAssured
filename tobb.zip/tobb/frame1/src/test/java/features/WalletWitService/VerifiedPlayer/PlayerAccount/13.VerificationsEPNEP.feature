@WalletWitService @VerifiedAccountSetup
Feature: Verifications for EP NEP (API CALLS)

#NEGATIVE SCENARIO
  @NoRetry
  Scenario: Get - GetPlayersMainAccounts (v4) - No xGame Id
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header
    When I make a "GET" call to "GetPlayersMainAccounts" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "ACCOUNT_NOT_DEFINED"
    And the "description" in response body is "No account was found matching the specified product."

  Scenario: Get - GetPlayersMainAccounts (v4) - Betting Wallet
    Given I setup gameId header to "SPORTSBOOK"
    And I create a Get "api_specWithGameId" header
    When I make a "GET" call to "GetPlayersMainAccounts" to service "WalletService"
    Then the API call is successful with status code 200
    And the "accountType" in response body is "AT_MAIN"
    And the "accountNumber" in response body is "2"

  Scenario: Get - GetPlayersMainAccounts (v4) - Lottery Wallet
    Given I setup gameId header to "JOKER"
    And I create a Get "api_specWithGameId" header
    When I make a "GET" call to "GetPlayersMainAccounts" to service "WalletService"
    Then the API call is successful with status code 200
    And the "accountType" in response body is "AT_MAIN"
    And the "accountNumber" in response body is "1"

  Scenario Outline: Get - GetPlayersMainAccounts (v4) - Invalid Product Id
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayersMainAccounts" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "ACCOUNT_NOT_DEFINED"
    And the "description" in response body is "No account was found matching the specified product."

    Examples:
      | keys      | values |
      | productId | test   |


  Scenario Outline: Get - GetPlayersMainAccounts (v4) - With Query Params
    Given I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayersMainAccounts" to service "WalletService"
    Then the API call is successful with status code 200
    And the "accountType" in response body is "AT_MAIN"
    And the "accountNumber" in response body is "<accountNumber>"


    Examples:
      | keys      | values     | accountNumber |
      | productId | JOKER      | 1             |
      | productId | CASINO     | 2             |
      | productId | SPORTSBOOK | 2             |

  Scenario Outline: Get - GetAccountsGroup (v4) - Lottery, Betting
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountsGroup" of service "WalletService" with configured parameter "accountId" "<accountId>"
    When I make a "GET" call to "GetAccountsGroup" to service "WalletService"
    Then the API call is successful with status code 200
    And the "group" in response body is "<group>"


    Examples:
      | accountId | group         |
      | AT_MAIN-1 | EXCLUSIVE     |
      | AT_MAIN-2 | NON_EXCLUSIVE |

  @NoRetry
  Scenario Outline: Get - GetAccountsGroup (v4) - Negative Non Existing
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountsGroup" of service "WalletService" with configured parameter "accountId" "<accountId>"
    When I make a "GET" call to "GetAccountsGroup" to service "WalletService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "ACCOUNT_ID_NOT_FOUND"
    And the "description" in response body is "AccountId not found ([Error Id: ACCOUNT_ID_NOT_FOUND])"

    Examples:
      | accountId |
      | AT_MAIN-3 |
