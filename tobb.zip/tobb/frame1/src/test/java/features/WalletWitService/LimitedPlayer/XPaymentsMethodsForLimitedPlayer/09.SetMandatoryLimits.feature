@WalletWitService @LimitedAccountSetup @skipIfNotAzure
Feature:Set Mandatory limits

#  ?????
#  Scenario Outline: Deposit via Payment code - Lottery wallet (Negative)
#    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
#    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
#    Then the API call is successful with status code 451
#    And the "description" in response body is "Mandatory limits have not been set for the player"
#    And the "errorId" in response body is "MANDATORY_LIMITS_NOT_SET"
#    Examples:
#      | paymentMethodId            | paymentCode | amount | action | operation      | paymentMethodType |
#      | PAYMENT_CODE_NON_EXCLUSIVE | Exclusive   | 1      | COMMIT | WALLET_DEPOSIT | BANK_ACCOUNT      |

  @NoRetry
  Scenario Outline: Invalid deposit - Mandatory limits not set
    Given I login as an Api user
    When I create a Post DepositViaBankAccount payload with "<paymentMethodId>" "<paymentCode>" "<amount>" "<action>" "<operation>" "<paymentType>" "<paymentMethodType>" "<bankId>" "<pspId>" "<pspTargetId>" "<currency>" "<owner>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "errorId" in response body is "MANDATORY_LIMITS_NOT_SET"
    And the "description" in response body is "Mandatory limits have not been set for the player"

    Examples:
      | paymentMethodId            | paymentCode | amount | action | operation      | paymentMethodType | paymentType    | bankId | pspId | pspTargetId | currency | owner           |
      | PAYMENT_CODE_NON_EXCLUSIVE | Exclusive   | 1      | COMMIT | WALLET_DEPOSIT | BANK_ACCOUNT      | PT_TRANSFER_IN | 112233 | TORA  | SKRILL      | EUR      | PlayerIdLimited |


  Scenario: Get user's limits
    And I login as a "newPlayerWeb" user
    Given I setup gameId header to "SPORTSBOOK"
    And I change url resource of method "PlayerLimits" of service "LimitService" with new playerId
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200

#  Scenario Outline: Set mandatory limits for SPORTSBOOK
#    Given I setup gameId header to "<header>"
#    And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
#    And I change url resource of method "PlayerLimits" of service "LimitService" with new playerId
#    When I make a "POST" call to "PlayerLimits" to service "LimitService"
#    Then the API call is successful with status code 200
#
#    Examples:
#      | limitTypes            | limitPeriods            | limitAmounts         | gameIds | header     |
#      | DEPOSIT,BUY,LOSS,TIME | DAILY,DAILY,DAILY,DAILY | 1000,1000,1000,86000 |         | SPORTSBOOK |
#      | DEPOSIT,BUY,LOSS,TIME | DAILY,DAILY,DAILY,DAILY | 1000,1000,1000,86000 |         | CASINO     |
#      | DEPOSIT,BUY,LOSS,TIME | DAILY,DAILY,DAILY,DAILY | 1000,1000,1000,86000 |         | JOKER      |
#
#  Scenario Outline: Get an AccessAttribute - Feature.subscription exists
#    Given I login as an Api user
#    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
#    Given I create a POST ApiAccessAttributes payload with "<accessType>" "<operationalUnit>" "<userId>" "<created>" "<updated>" "<updatedByUserId>" "<operatorId>" "<reason>" "<valid>" "<notifyStatus>"
#    Then I make a "POST" call to "ApiAccessAttributes" to service "AccessService"
#    Then the API call is successful with status code 200
#    And the number of results in a nameless array of objects is 1
#    And the property "operatorId" in response body array with index "<index>" has value "0"
#    And the property "operationalUnit" in response body array with index "<index>" has value "feature.subscription/check/"
#    And the property "accessType" in response body array with index "<index>" has value "ALLOW"
#    And the property "reason" in response body array with index "<index>" has value "Test"
#
#    Examples:
#      | keys                                 | values                                                          | index |
#      | userId,operationalUnit,includeGroups | friendsAndFamilyGroupId,feature.subscription/check/ALL/ALL,true | [0]   |


  Scenario Outline: Set mandatory limits for SPORTSBOOK/CASINO
    Given I setup gameId header to "SPORTSBOOK"
    And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
    And I change url resource of method "PlayerLimitsV2" of service "LimitService" with new playerId
    When I make a "POST" call to "PlayerLimitsV2" to service "LimitService"
    Then the API call is successful with status code 200

    Examples:
      | limitTypes             | limitPeriods            | limitAmounts         | gameIds             |
      | TIME,DEPOSIT,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY | 86000,2000,1000,1000 | ,,SPORTSBOOK,CASINO |


  Scenario Outline: Verify SPORTSBOOK mandatory limits via limit-service
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    And I verify limits for "DAILY" limit period, duration or amount 86000 and limitType "TIME" and gameId "" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 1000 and limitType "LOSS" and gameId "SPORTSBOOK" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 2000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-2" with pending limits false
    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |


  Scenario Outline: Set mandatory limits for JOKER/PROTO/LOTTO/SUPER3/KINO and Verify JOKER mandatory limits
    Given I setup gameId header to "JOKER"
    And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
    And I change url resource of method "PlayerLimitsV2" of service "LimitService" with new playerId
    When I make a "POST" call to "PlayerLimitsV2" to service "LimitService"
    Then the API call is successful with status code 200

    Examples:
      | limitTypes                            | limitPeriods                              | limitAmounts                        | gameIds                         |
      | TIME,DEPOSIT,LOSS,LOSS,LOSS,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY,DAILY,DAILY,DAILY | 86000,2000,1000,1000,1000,1000,1000 | ,,JOKER,PROTO,KINO,LOTTO,SUPER3 |


  Scenario Outline: Verify JOKER mandatory limits via limit-service
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    And I verify limits for "DAILY" limit period, duration or amount 86000 and limitType "TIME" and gameId "" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 1000 and limitType "LOSS" and gameId "JOKER" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 2000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-1" with pending limits false

    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |
