@UnauthorizedCalls @WalletWitService @NoRetry
Feature: Unauthorized CC Calls

  Scenario Outline: Get AccessOperationsV1- Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with configured playerId "123455678"
    When I make a "GET" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-attributes/list/get/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Post AccessOperationsV1 - Missing Header/Incorrect Cookie/Incorrect Authorization
    Given I create a Get "<spec>" header
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with configured playerId "12345678"
    When I make a "POST" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "AUTHENTICATION_REQUIRED"
    And the "description" in response body is "Access not allowed for ou=adminrest.access-attributes/list/get/WEB"

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

###########################################################################################

  Scenario Outline: Get Player's Account  v1
    Given I create a Get "<spec>" header
    And I change url resource of method "GetAccountV1CC" of service "WalletService" with configured playerId "12345678"
    And I make a "GET" call to "GetAccountV1CC" to service "WalletService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get Player's Account  v1 With AccountId
    Given I create a Get "<spec>" header
    And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "GetAccountV1CCWithId" of service "WalletService" with configured parameter "accountId" "123"
    And I make a "GET" call to "GetAccountV1CCWithId" to service "WalletService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get Player's Account  v1 With History
    Given I create a Get "<spec>" header
    And I change url resource of method "GetAccountHistoryCC" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "GetAccountHistoryCC" of service "WalletService" with configured parameter "accountId" "123"
    And I change url resource of method "GetAccountHistoryCC" of service "WalletService" with configured parameter "daysBack" "123"
    And I make a "GET" call to "GetAccountHistoryCC" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get Player's Transactions Backoffice
    Given I create a Get "<spec>" header
    And I change url resource of method "GetPlayerTransactionsCC" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "GetPlayerTransactionsCC" of service "WalletService" with configured parameter "accountId" "123"
    And I make a "GET" call to "GetPlayerTransactionsCC" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get Player's Transaction Types Backoffice
    Given I create a Get "<spec>" header
    And I change url resource of method "GetPlayerTransactionTypesCC" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "GetPlayerTransactionTypesCC" of service "WalletService" with configured parameter "accountId" "123"
    And I make a "GET" call to "GetPlayerTransactionTypesCC" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get Player's Limits Backoffice
    Given I create a Get "<spec>" header
    And I change url resource of method "PlayerLimitsCC" of service "LimitService" with configured playerId "12345678"
    And I make a "GET" call to "PlayerLimitsCC" to service "LimitService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Post Player's Limits Backoffice
    Given I create a Get "<spec>" header
    And I change url resource of method "PlayerLimitsCC" of service "LimitService" with configured playerId "12345678"
    And I make a "POST" call to "PlayerLimitsCC" to service "LimitService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Post - Approve Player's Limits Backoffice
    Given I create a Get "<spec>" header
    And I change url resource of method "ApproveLimitsCC" of service "LimitService" with configured playerId "12345678"
    And I make a "POST" call to "ApproveLimitsCC" to service "LimitService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Post - Reject Player's Limits Backoffice
    Given I create a Get "<spec>" header
    And I change url resource of method "RejectLimitsCC" of service "LimitService" with configured playerId "12345678"
    And I make a "POST" call to "RejectLimitsCC" to service "LimitService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Put -  PaymentMethodWithIdCC
    Given I create a Get "<spec>" header
    And I change url resource of method "PaymentMethodWithIdCC" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "PaymentMethodWithIdCC" of service "WalletService" with configured parameter "paymentMethodId" "123"
    And I make a "PUT" call to "PaymentMethodWithIdCC" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Del -  PaymentMethodWithIdCC
    Given I create a Get "<spec>" header
    And I change url resource of method "PaymentMethodWithIdCC" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "PaymentMethodWithIdCC" of service "WalletService" with configured parameter "paymentMethodId" "123"
    And I make a "DEL" call to "PaymentMethodWithIdCC" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get -  GetPaymentMethodsPayments
    Given I create a Get "<spec>" header
    And I change url resource of method "GetPaymentMethodsPayments" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "GetPaymentMethodsPayments" of service "WalletService" with configured parameter "paymentMethodId" "123"
    And I make a "GET" call to "GetPaymentMethodsPayments" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get -  Get All Users Payments
    Given I create a Get "<spec>" header
    And I make a "GET" call to "GetAllUsersPayments" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get -  Get Grand Prize Payments - Manually Handled
    Given I create a Get "<spec>" header
    And I change url resource of method "GetGrandPrizePayments" of service "WalletService" with configured playerId "12345678"
    And I make a "GET" call to "GetGrandPrizePayments" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get -  Get Rejected Out Payments
    Given I create a Get "<spec>" header
    And I make a "GET" call to "GetRejectedOutPayments" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get -  Payment With Id
    Given I create a Get "<spec>" header
    And I change url resource of method "PaymentWithId" of service "WalletService" with configured parameter "paymentId" "123"
    And I make a "GET" call to "PaymentWithId" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Put -  Payment With Id
    Given I create a Get "<spec>" header
    And I change url resource of method "PaymentWithId" of service "WalletService" with configured parameter "paymentId" "123"
    And I make a "PUT" call to "PaymentWithId" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Post -  ApprovePayment
    Given I create a Get "<spec>" header
    And I change url resource of method "ApprovePayment" of service "WalletService" with configured parameter "paymentId" "123"
    When I make a "POST" call to "ApprovePayment" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Post -  Reject Payment
    Given I create a Get "<spec>" header
    And I change url resource of method "RejectPayment" of service "WalletService" with configured parameter "paymentId" "123"
    When I make a "POST" call to "RejectPayment" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Post -  Cancel Payment
    Given I create a Get "<spec>" header
    And I change url resource of method "CancelPayment" of service "WalletService" with configured parameter "paymentId" "123"
    When I make a "POST" call to "CancelPayment" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Post -  Verify Payment
    Given I create a Get "<spec>" header
    And I change url resource of method "VerifyPayment" of service "WalletService" with configured parameter "paymentId" "123"
    When I make a "POST" call to "VerifyPayment" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Post -  RetryOut Payment
    Given I create a Get "<spec>" header
    And I change url resource of method "RetryOutPayment" of service "WalletService" with configured parameter "paymentId" "123"
    When I make a "POST" call to "RetryOutPayment" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - Transfer In Payments
    Given I create a Get "<spec>" header
    When I make a "GET" call to "GetTransferInPayments" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get - Transfer Out Payments
    Given I create a Get "<spec>" header
    When I make a "GET" call to "GetTransferOutPayments" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Post - Record Payments
    Given I create a Get "<spec>" header
    When I make a "POST" call to "RecordPayments" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get - Service Providers
    Given I create a Get "<spec>" header
    When I make a "GET" call to "GetServiceProviders" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - Payouts
    Given I create a Get "<spec>" header
    When I make a "GET" call to "GetPayouts" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get - GetWalletBalance
    Given I create a Get "<spec>" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with configured playerId "12345678"
    #And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Get - GetWalletBalanceWithId
    Given I create a Get "<spec>" header
    And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "GetWalletBalanceWithId" of service "WalletService" with configured parameter "accountId" "123"
    #And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalanceWithId" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: POST - ManuallyAdjustWallet
    Given I create a Get "<spec>" header
    And I change url resource of method "ManuallyAdjustWallet" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "ManuallyAdjustWallet" of service "WalletService" with configured parameter "accountId" "123"
    #And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "POST" call to "ManuallyAdjustWallet" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: GET - GetWalletBalanceWithAccountType
    Given I create a Get "<spec>" header
    And I change url resource of method "GetWalletBalanceWithAccountType" of service "WalletService" with configured playerId "12345678"
        #And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I change url resource of method "GetWalletBalanceWithAccountType" of service "WalletService" with configured parameter "accountType" "123"
    When I make a "GET" call to "GetWalletBalanceWithAccountType" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: GET - PlayerLimitsCCv2
    Given I create a Get "<spec>" header
    And I change url resource of method "PlayerLimitsCCv2" of service "LimitService" with configured playerId "12345678"
        #And I change url resource of method "PlayerLimitsCCv2" of service "LimitService" with new playerId
    When I make a "GET" call to "PlayerLimitsCCv2" to service "LimitService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: GET - GetPlayerPaymentsAsAdminV2
    Given I create a Get "<spec>" header
    When I make a "GET" call to "GetPlayerPaymentsAsAdminV2" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: GET - GetPaymentCodes
    Given I create a Get "<spec>" header
    When I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code <statusCode>

    Examples:
      | spec                          | statusCode | GherkinDescription      |
      | cc_incorrectCookieSpec        | 403        | Incorrect Cookie        |
      | cc_incorrectAuthorizationSpec | 401        | Incorrect Authorization |







