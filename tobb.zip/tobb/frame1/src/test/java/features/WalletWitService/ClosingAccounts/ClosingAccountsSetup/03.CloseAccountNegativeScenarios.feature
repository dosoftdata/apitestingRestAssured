@WalletWitService @skipIfNotAzure @CloseAccountSetup
Feature: Close Account Setup

  #This is Deprecated - Negative
  Scenario: Close Account v2 - Deprecated - Negative Scenario
    Given I login as an Api user
    And I create an empty payload with header "api_mainSpec"
    And I change url resource of method "CloseAccountV2" of service "WalletService" with new playerId
    When I make a "PUT" call to "CloseAccountV2" to service "WalletService"
    Then the API call is successful with status code 405
    #And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    #And the "description" in response body is "Internal Server Error"


  Scenario: Get Player v2 - Success
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerV2" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerV2" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify the player id "id" in the response body
    And I verify the username "username" in the response body


    #test to save the initial. maybe add in some hooks/tags ?
  # maybe improve userType/userGroup?
  @Concat
  Scenario Outline: Close Account v4 - Negative Invalid PlayerId format
    Given I login as an Api user
    And I save the initial url of method "CloseAccountV4" of service "WalletService"
    And I create a CloseAccountV4 Put payload with "<status>" "<statusDescription>" "<statusReason>"
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with configured parameter "userType" "98212"
    And I change url resource of method "CloseAccountV4" of service "WalletService" with new playerId
    When I make a "PUT" call to "CloseAccountV4" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Invalid user ID format; format must be 'type-id', where both type and id are integers"

    Examples:

      | keys                     | values                          | status | statusDescription | statusReason   |
      | statusReason,playerLevel | SELF_EXCLUSION,VERIFIED_ACCOUNT | CLOSED | test              | SELF_EXCLUSION |


  Scenario: Get Player v2 - Success
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerV2" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerV2" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify the player id "id" in the response body
    And I verify the username "username" in the response body
