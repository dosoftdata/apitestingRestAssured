#AZURE ONLY FEATURE
@WalletWitService @skipIfNotAzure @VerifiedAccountSetup
Feature: Wallet Operational Units Via v1.CC


  Scenario Outline: Post access operations V2 - Deny Operational Units
    Given I create a POST AccessOperations payload with "<buyListId>" "<buyListAccessType>" "<payoutListId>" "<payoutListAccessType>" "<depositListId>" "<depositListAccessType>" "<withdrawListId>" "<withdrawListAccessType>" "<reason>"
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
   # And I check EP, NEP wallets

    Examples:
      | buyListId | buyListAccessType | payoutListId | payoutListAccessType | depositListId | depositListAccessType | withdrawListId | withdrawListAccessType | reason |
      | 123       | DENY              | 123          | DENY                 | 123           | DENY                  | 123            | DENY                   | test   |

  Scenario Outline: Post access operations V2 - Mixed Operational Access Types
    Given I create a POST AccessOperations payload with "<buyListId>" "<buyListAccessType>" "<payoutListId>" "<payoutListAccessType>" "<depositListId>" "<depositListAccessType>" "<withdrawListId>" "<withdrawListAccessType>" "<reason>"
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
   # And I check EP, NEP wallets

    Examples:
      | buyListId | buyListAccessType | payoutListId | payoutListAccessType | depositListId | depositListAccessType | withdrawListId | withdrawListAccessType | reason |
      | 123       | DENY              | 123          | ALLOW                | 123           | DENY                  | 123            | ALLOW                  | test   |


  Scenario Outline: Post access operations V2 - Restore Status Of wallet Operational Units (ALLOW)
    Given I create a POST AccessOperations payload with "<buyListId>" "<buyListAccessType>" "<payoutListId>" "<payoutListAccessType>" "<depositListId>" "<depositListAccessType>" "<withdrawListId>" "<withdrawListAccessType>" "<reason>"
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "POST" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
   # And I check EP, NEP wallets

    Examples:
      | buyListId | buyListAccessType | payoutListId | payoutListAccessType | depositListId | depositListAccessType | withdrawListId | withdrawListAccessType | reason |
      | 123       | ALLOW             | 123          | ALLOW                | 123           | ALLOW                 | 123            | ALLOW                  |        |

  Scenario: Get access operations V2 - Assertions
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "GET" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 2
    #And I check EP, NEP wallets

  Scenario Outline: Get access operations V1
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "AccessOperationsV1" of service "WalletService" with new playerId
    Then I make a "GET" call to "AccessOperationsV1" to service "WalletService"
    Then the API call is successful with status code 200
    And I check that the size of elements in array "withdraw" is <withdraw>
    And I check that the size of elements in array "payout" is <payout>
    #And I check that the size of elements in array "deposit" is <deposit>
   # And I check that the size of elements in array "buy" is <buy>
#    And I check buy, withdrawals, payout, deposits operations with "<depositAccessType>" "<withdrawAccessType>" "<buyAccessType>"

    Examples:
      | deposit | buy | withdraw | payout | depositAccessType                                           | withdrawAccessType                        | buyAccessType                                         |
      | 11      | 9   | 6        | 1      | ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW,ALLOW | ALLOW,ALLOW,ALLOW,DENY,DENY,DENY,DENY,ALLOW,DENY,DENY |

