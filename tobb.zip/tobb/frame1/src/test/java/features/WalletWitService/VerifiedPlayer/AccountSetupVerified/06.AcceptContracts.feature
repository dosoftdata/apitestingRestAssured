@VerifiedAccountSetup
Feature: Accept Contracts

  @WalletWitService  @skipIfNotAzure
  Scenario Outline: Get Nex contract ID
    Given I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And I copy the value of the contractId from the response


    Examples:
      | queryType | query                                                                                            |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`PLRCONTRACTS` WHERE TYPE = 'TERMS_AND_CONDS_NEX' |

  @WalletWitService  @skipIfNotAzure
  Scenario Outline: DatabaseBridge - Insert NEX Contract ID for player
    Given I create a DataBridge Payload with "<query>"
    When I make a "POST" call to "DatabaseExecute" to service "DatabaseBridgeService"
    Then the API call is successful with status code 200

    Examples:
      | query                                                                                                                                                                            |
      | INSERT INTO PLRCONTRACTAGREEMENTS (CONTRACTID, PLAYERID, CREATED, UPDATED, STATUS, UPDATEDBYUSERID) VALUES ('newContractId','newPlayerId',SYSDATE,SYSDATE,'VALID','newPlayerId') |


    # currently not needed. preemptive only
  Scenario Outline: DatabaseBridge - Update Query in PLCONTRACTAGREEMENT
    Given I create a DataBridge Payload with "<query>"
    When I make a "POST" call to "DatabaseExecute" to service "DatabaseBridgeService"
    Then the API call is successful with status code 200

    Examples:
      | query                                                                                           |
      | UPDATE PLRCONTRACTAGREEMENTS SET STATUS='VALID' WHERE STATUS='REVOKED' AND PLAYERID=newPlayerId |


  @WalletWitService @AcceptExContracts @skipIfNotAzure
  Scenario Outline: Get EX contract ID
    Given I create a DrillHost Payload with "<queryType>" and "<query>"
    When I make a "POST" call to "DrillHost" to service "DrillHostService"
    Then the API call is successful with status code 200
    And I copy the value of the contractId from the response


    Examples:
      | queryType | query                                                                                           |
      | SQL       | SELECT * FROM connection_to_oracle.opap_test_2.`PLRCONTRACTS` WHERE TYPE = 'TERMS_AND_CONDS_EX' |

  @WalletWitService @AcceptExContracts @skipIfNotAzure
  Scenario Outline: DatabaseBridge - Insert EX Contract ID for player
    Given I create a DataBridge Payload with "<query>"
    When I make a "POST" call to "DatabaseExecute" to service "DatabaseBridgeService"
    Then the API call is successful with status code 200

    Examples:
      | query                                                                                                                                                                            |
      | INSERT INTO PLRCONTRACTAGREEMENTS (CONTRACTID, PLAYERID, CREATED, UPDATED, STATUS, UPDATEDBYUSERID) VALUES ('newContractId','newPlayerId',SYSDATE,SYSDATE,'VALID','newPlayerId') |

