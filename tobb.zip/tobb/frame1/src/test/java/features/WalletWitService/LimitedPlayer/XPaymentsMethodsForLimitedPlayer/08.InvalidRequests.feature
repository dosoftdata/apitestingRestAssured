@WalletWitService @LimitedAccountSetup @skipIfNotAzure
Feature:Invalid requests

  @NoRetry
  Scenario Outline: Invalid withdrawal via IBAN - No valid playerId
    Given I login as an Api user
    When I create a Post DepositViaBankAccount payload with "<paymentMethodId>" "<paymentCode>" "<amount>" "<action>" "<operation>" "<paymentType>" "<paymentMethodType>" "<bankId>" "<pspId>" "<pspTargetId>" "<currency>" "<owner>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "userId is either null, not on the form TYPE-ID (where both TYPE and ID are numeric) or ID is longer than 18 digits. "

    Examples:
      | paymentMethodId | paymentCode | amount | action  | operation         | paymentMethodType | paymentType     | bankId | pspId | pspTargetId | currency | owner |
      | DEFAULT_OUT     | Exclusive   | 20     | PREPARE | WALLET_WITHDRAWAL | BANK_ACCOUNT      | PT_TRANSFER_OUT | 112233 | TORA  | SEPA        | EUR      | empty |

  @NoRetry
  Scenario Outline: Invalid withdrawal - No verified IBAN
    Given I login as an Api user
    When I create a Post DepositViaBankAccount payload with "<paymentMethodId>" "<paymentCode>" "<amount>" "<action>" "<operation>" "<paymentType>" "<paymentMethodType>" "<bankId>" "<pspId>" "<pspTargetId>" "<currency>" "<owner>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "NO_PAYMENT_METHOD"
    And the "description" in response body is "The payment.paymentMethod.id: DEFAULT_OUT does not match any existing paymentMethod ([Error Id: NO_PAYMENT_METHOD])"

    Examples:
      | paymentMethodId | paymentCode | amount | action  | operation         | paymentMethodType | paymentType     | bankId | pspId | pspTargetId | currency | owner           |
      | DEFAULT_OUT     | Exclusive   | 20     | PREPARE | WALLET_WITHDRAWAL | BANK_ACCOUNT      | PT_TRANSFER_OUT | 112233 | TORA  | SEPA        | EUR      | PlayerIdLimited |

  @NoRetry
  Scenario Outline: Invalid withdrawal - No payment method
    Given I login as an Api user
    When I create a Post DepositViaBankAccount payload with "<paymentMethodId>" "<paymentCode>" "<amount>" "<action>" "<operation>" "<paymentType>" "<paymentMethodType>" "<bankId>" "<pspId>" "<pspTargetId>" "<currency>" "<owner>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "NO_PAYMENT_METHOD"
    And the "description" in response body is "The payment.paymentMethod.id: CARD does not match any existing paymentMethod ([Error Id: NO_PAYMENT_METHOD])"

    Examples:
      | paymentMethodId | paymentCode | amount | action  | operation         | paymentMethodType | paymentType     | bankId | pspId | pspTargetId | currency | owner           |
      | CARD            | Exclusive   | 29.9   | PREPARE | WALLET_WITHDRAWAL | CARD              | PT_TRANSFER_OUT | 112233 | TORA  | SEPA        | EUR      | PlayerIdLimited |

  @NoRetry
  Scenario Outline: Invalid withdrawal - No verified SKRILL
    Given I login as an Api user
    When I create a Post DepositViaBankAccount payload with "<paymentMethodId>" "<paymentCode>" "<amount>" "<action>" "<operation>" "<paymentType>" "<paymentMethodType>" "<bankId>" "<pspId>" "<pspTargetId>" "<currency>" "<owner>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "NO_PAYMENT_METHOD"
    And the "description" in response body is "The payment.paymentMethod.id: SKRILL_OUT does not match any existing paymentMethod ([Error Id: NO_PAYMENT_METHOD])"

    Examples:
      | paymentMethodId | paymentCode | amount | action  | operation         | paymentMethodType | paymentType     | bankId | pspId  | pspTargetId | currency | owner           |
      | SKRILL_OUT      | Exclusive   | 50     | PREPARE | WALLET_WITHDRAWAL | EXTERNAL          | PT_TRANSFER_OUT | 112233 | SKRILL | SEPA        | EUR      | PlayerIdLimited |

  @NoRetry
  Scenario Outline: Invalid withdrawal - Invalid currency
    Given I login as an Api user
    When I create a Post DepositViaBankAccount payload with "<paymentMethodId>" "<paymentCode>" "<amount>" "<action>" "<operation>" "<paymentType>" "<paymentMethodType>" "<bankId>" "<pspId>" "<pspTargetId>" "<currency>" "<owner>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "NO_PAYMENT_METHOD"
    And the "description" in response body is "The payment.paymentMethod.id: SKRILL_OUT does not match any existing paymentMethod ([Error Id: NO_PAYMENT_METHOD])"

    Examples:
      | paymentMethodId | paymentCode | amount | action  | operation         | paymentMethodType | paymentType     | bankId | pspId  | pspTargetId | currency | owner           |
      | SKRILL_OUT      | Exclusive   | 50     | PREPARE | WALLET_WITHDRAWAL | EXTERNAL          | PT_TRANSFER_OUT | 112233 | SKRILL | SEPA        | USD      | PlayerIdLimited |


  @NoRetry
  Scenario Outline: Invalid withdrawal - Invalid owner type
    Given I login as an Api user
    When I create a Post DepositViaBankAccount payload with "<paymentMethodId>" "<paymentCode>" "<amount>" "<action>" "<operation>" "<paymentType>" "<paymentMethodType>" "<bankId>" "<pspId>" "<pspTargetId>" "<currency>" "<owner>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 500
    And the "errorId" in response body is "INTERNAL_SERVER_ERROR"
    And the "description" in response body is "Internal Server Error"

    Examples:
      | paymentMethodId            | paymentCode | amount | action  | operation         | paymentMethodType | paymentType     | bankId | pspId  | pspTargetId | currency | owner |
      | PAYMENT_CODE_NON_EXCLUSIVE | Exclusive   | 50     | PREPARE | WALLET_WITHDRAWAL | PAYMENT_CODE      | PT_TRANSFER_OUT | 112233 | SKRILL | SEPA        | EUR      | test  |

  Scenario Outline: Get and Verify Wallets Balance
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
#    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
#    Then the API call is successful with status code 200
#    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
#  And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  |

  Scenario Outline: Get player's payments as Admin
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerPaymentsAsAdmin" to service "WalletService"
    Then the API call is successful with status code 200
#    And I check that the size of data.length is above 0

    Examples:
      | keys       | values   |
      | customerId | changeit |