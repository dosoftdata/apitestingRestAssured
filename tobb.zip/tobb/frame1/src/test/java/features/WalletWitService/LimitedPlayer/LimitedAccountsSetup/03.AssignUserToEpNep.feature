@WalletWitService @skipIfNotAzure @LimitedAccountSetup
Feature: Assign User To EpNep

  Scenario: Get and Verify Access Groups
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response and copy the access group Ids

  Scenario: Add user to EP group
    Given I create an AddUserToEpGroup payload
    And I change url resource of method "AddUserToEpGroup" of service "AccessService" with new "accessGroupIdExclusive"
    When I make a "POST" call to "AddUserToEpGroup" to service "AccessService"
    Then the API call is successful with status code 201
    And I copy and verify the member Id

  Scenario: Add user to NEP group
    Given I create an AddUserToNepGroup payload
    And I change url resource of method "AddUserToNepGroup" of service "AccessService" with new "accessGroupIdNonExclusive"
    When I make a "POST" call to "AddUserToNepGroup" to service "AccessService"
    Then the API call is successful with status code 201
    And I copy and verify the member Id

  Scenario: Get and Verify Role Members
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetRoleMembers" of service "AccessService" with new playerId
    And I make a "GET" call to "GetRoleMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response for Role Members for "ExclusiveAndNonExclusive"
