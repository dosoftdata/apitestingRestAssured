@WalletWitService @UnauthorizedCalls @NoRetry
Feature: Unauthorized API Calls

  ### LEGACY WALLET CALLS ####
  Scenario Outline: Get Player's Legacy Wallet v1 - Missing Header/Incorrect Authorization
   # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "GetUserLegacyWalletV1" of service "WalletService" with configured playerId "12345678"
    And I make a "GET" call to "GetUserLegacyWalletV1" to service "WalletService"
    Then the API call is successful with status code <statusCode>
   #And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Block Legacy Wallet - Missing Header/Incorrect Authorization
   # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "BlockLegacyWallet" of service "WalletService" with configured playerId "12345678"
    And I make a "PUT" call to "BlockLegacyWallet" to service "WalletService"
    Then the API call is successful with status code <statusCode>
    #And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: Close Legacy Account v1 - Missing Header/Incorrect Authorization
   # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "CloseLegacyAccountV1" of service "WalletService" with configured playerId "12345678"
    And I make a "PUT" call to "CloseLegacyAccountV1" to service "WalletService"
    Then the API call is successful with status code <statusCode>
   # And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Post Legacy Transaction - Missing Header/Incorrect Authorization
   # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "LegacyTransaction" of service "WalletService" with configured playerId "12345678"
    And I make a "POST" call to "LegacyTransaction" to service "WalletService"
    Then the API call is successful with status code <statusCode>
   # And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Capture Legacy Account - Missing Header/Incorrect Authorization
   # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "CaptureLegacyTransaction" of service "WalletService" with configured playerId "12345678"
    And I make a "PUT" call to "CaptureLegacyTransaction" to service "WalletService"
    Then the API call is successful with status code <statusCode>
   # And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Capture Legacy Account With Id  - Missing Header/Incorrect Authorization
   # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "CaptureLegacyTransactionWithId" of service "WalletService" with configured playerId "12345678"
  #  And I change url resource of method "CaptureLegacyTransactionWithId" of service "WalletService" with accountId "123"
    And I make a "PUT" call to "CaptureLegacyTransactionWithId" to service "WalletService"
    Then the API call is successful with status code <statusCode>
   # And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get Legacy Transaction - Missing Header/Incorrect Authorization
   # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "LegacyTransaction" of service "WalletService" with configured playerId "12345678"
    And I make a "GET" call to "LegacyTransaction" to service "WalletService"
    Then the API call is successful with status code <statusCode>
   # And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get Legacy Transaction With Id - Missing Header/Incorrect Authorization
   # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "GetLegacyTransactionWithId" of service "WalletService" with configured playerId "12345678"
    And I change url resource of method "GetLegacyTransactionWithId" of service "WalletService" with configured parameter "transactionId" "123"
    And I make a "GET" call to "GetLegacyTransactionWithId" to service "WalletService"
    Then the API call is successful with status code <statusCode>
   # And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Reject Legacy Transaction - Missing Header/Incorrect Authorization
   # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "RejectLegacyTransaction" of service "WalletService" with configured playerId "12345678"
    And I make a "POST" call to "RejectLegacyTransaction" to service "WalletService"
    Then the API call is successful with status code <statusCode>
   # And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  ### END OF LEGACY WALLET CALLS ####



  Scenario Outline: Get Audit- Missing Header/Incorrect Authorization
   # Given I login as an Api user
    And I create a Get "<spec>" header
    And I make a "GET" call to "GetAudit" to service "WalletService"
    Then the API call is successful with status code <statusCode>
   # And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get Player Audit - Missing Header/Incorrect Authorization
   # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "GetPlayerAudit" of service "WalletService" with configured playerId "12345678"
    And I make a "GET" call to "GetPlayerAudit" to service "WalletService"
    Then the API call is successful with status code <statusCode>
   # And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Validate Iban - Missing Header/Incorrect Authorization
    And I create a Get "<spec>" header
    And I make a "GET" call to "ValidateIban" to service "WalletService"
    Then the API call is successful with status code <statusCode>
  # And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get Payment Method With Id - Missing Header/Incorrect Authorization
 # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "PaymentMethodWithId" of service "WalletService" with configured playerId "12345678"
   # And I change url resource of method "GetPaymentMethodWithId" of service "WalletService" with configured paymentMethodId "12345678"
    And I make a "GET" call to "PaymentMethodWithId" to service "WalletService"
    Then the API call is successful with status code <statusCode>
 # And the response contains "unauthorized"
    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get Payment Method V1 - Missing Header/Incorrect Authorization
 # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "PaymentMethodV1" of service "WalletService" with configured playerId "12345678"
    And I make a "GET" call to "PaymentMethodV1" to service "WalletService"
    Then the API call is successful with status code <statusCode>
 # And the response contains "unauthorized"


    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Put Payment Method With Id - Missing Header/Incorrect Authorization
 # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "PaymentMethodWithId" of service "WalletService" with configured playerId "12345678"
   # And I change url resource of method "GetPaymentMethodWithId" of service "WalletService" with configured paymentMethodId "12345678"
    And I make a "PUT" call to "PaymentMethodWithId" to service "WalletService"
    Then the API call is successful with status code <statusCode>
 # And the response contains "unauthorized"
    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Delete Payment Method V1 - Missing Header/Incorrect Authorization
 # Given I login as an Api user
    And I create a Get "<spec>" header
    And I change url resource of method "DeletePaymentMethodV1" of service "WalletService" with configured playerId "12345678"
    And I make a "DEL" call to "DeletePaymentMethodV1" to service "WalletService"
    Then the API call is successful with status code <statusCode>
 # And the response contains "unauthorized"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Post Payment via Payment Code V1 - Missing Header/Incorrect Authorization
 # Given I login as an Api user
    And I create a Get "<spec>" header
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code <statusCode>
 # And the response contains "unauthorized"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  Scenario Outline: Get Payment via Payment Code V1 - Missing Header/Incorrect Authorization
 # Given I login as an Api user
    And I create a Get "<spec>" header
    And I make a "GET" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code <statusCode>
 # And the response contains "unauthorized"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

   ###

  Scenario Outline: CommitCardWithdrawalToTora - Missing Header/Incorrect Authorization
 # Given I login as an Api user
    And I create a Get "<spec>" header
    And I make a "PUT" call to "CommitCardWithdrawalToTora" to service "WalletService"
    #And I change url resource of method "CommitCardWithdrawalToTora" of service "WalletService" with new withdrawal payment Id
    Then the API call is successful with status code <statusCode>
 # And the response contains "unauthorized"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |


  Scenario Outline: CommitCardWithdrawalToTora - Missing Header/Incorrect Authorization
 # Given I login as an Api user
    And I create a Get "<spec>" header
    And I make a "GET" call to "CommitCardWithdrawalToTora" to service "WalletService"
    #And I change url resource of method "CommitCardWithdrawalToTora" of service "WalletService" with new withdrawal payment Id
    Then the API call is successful with status code <statusCode>
    # And the response contains "unauthorized"

    Examples:
      | spec                           | statusCode | GherkinDescription      |
      | api_emptySpec                  | 401        | Missing Header          |
      | api_incorrectAuthorizationSpec | 401        | Incorrect Authorization |

  @Concat @NoRetry
  Scenario: Get Legacy account by id via V1.API - Missing accountId - Negative
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetAccountV1" of service "WalletService" with new playerId
    And I make a "GET" call to "GetAccountV1" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Account id incorrect"



