Feature: Change personal admin info - Negative Scenarios

  @AdminService
  Scenario Outline: Change personal admin info - Missing Login Name
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT UpdateAdminInfo payload with "<firstName>" "<lastName>" "<email>" "<loginName>" "<groupIds>" <status>
    When I change url resource of method "UpdateAdminInfo" of service "AdminService" with saved AdminId
    And I make a "PUT" call to "UpdateAdminInfo" to service "AdminService"
    Then the API call fails with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "loginName REQUIRED"

    Examples:
      | firstName | lastName  | email                 | loginName | groupIds | status |
      | TestAdmin | TestAdmin | TestAdmin@mailsac.com |           | 23       | 1      |

  @AdminService
  Scenario Outline: Change personal admin info - Missing First Name
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT UpdateAdminInfo payload with "<firstName>" "<lastName>" "<email>" "<loginName>" "<groupIds>" <status>
    When I change url resource of method "UpdateAdminInfo" of service "AdminService" with saved AdminId
    And I make a "PUT" call to "UpdateAdminInfo" to service "AdminService"
    Then the API call fails with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "firstName REQUIRED"

    Examples:
      | firstName | lastName  | email                 | loginName    | groupIds | status |
      |           | TestAdmin | TestAdmin@mailsac.com | USE_EXISTING | 23       | 1      |

  @AdminService
  Scenario Outline: Change personal admin info - Missing Last Name
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT UpdateAdminInfo payload with "<firstName>" "<lastName>" "<email>" "<loginName>" "<groupIds>" <status>
    When I change url resource of method "UpdateAdminInfo" of service "AdminService" with saved AdminId
    And I make a "PUT" call to "UpdateAdminInfo" to service "AdminService"
    Then the API call fails with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "lastName REQUIRED"

    Examples:
      | firstName | lastName | email                 | loginName    | groupIds | status |
      | TestAdmin |          | TestAdmin@mailsac.com | USE_EXISTING | 23       | 1      |

  @AdminService
  Scenario Outline: Change personal admin info - Missing Email
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT UpdateAdminInfo payload with "<firstName>" "<lastName>" "<email>" "<loginName>" "<groupIds>" <status>
    When I change url resource of method "UpdateAdminInfo" of service "AdminService" with saved AdminId
    And I make a "PUT" call to "UpdateAdminInfo" to service "AdminService"
    Then the API call fails with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the property "description" includes value "email INVALID"
    And the property "description" includes value "email REQUIRED"

    Examples:
      | firstName | lastName  | email | loginName    | groupIds | status |
      | TestAdmin | TestAdmin |       | USE_EXISTING | 23       | 1      |

  @AdminService
  Scenario Outline: Change personal admin info - Invalid AdminId (string)
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT UpdateAdminInfo payload with "<firstName>" "<lastName>" "<email>" "<loginName>" "<groupIds>" <status>
    When I change url resource of method "UpdateAdminInfo" of service "AdminService" with configured adminId "testId"
    And I make a "PUT" call to "UpdateAdminInfo" to service "AdminService"
    Then the API call fails with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Admin Id must be numeric"

    Examples:
      | firstName | lastName  | email                 | loginName    | groupIds | status |
      | TestAdmin | TestAdmin | TestAdmin@mailsac.com | USE_EXISTING | 23       | 1      |