Feature: Create Admin - Get Admin

  @AdminService
  Scenario Outline: Create Super Admin - Verify admin user is created successfully
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST CreateNewAdmin payload "<email>" "<firstName>" "<language>" "<lastName>" "<loginName>" "<password>" "<passwordRepeated>" <status> "<groupIds>"
    When I make a "POST" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    Then the API call is successful with status code 200
    And the "status" in response body is "1"
    And I verify the "created" admin "loginName" in the response body
    And I verify the "created" admin "email" in the response body
    And I copy the value of the admin "id" from the response
    And I copy the value of the admin "loginName" from the response
    And I copy the value of the admin "email" from the response

    Examples:
      | email     | firstName | language | lastName  | loginName | password          | passwordRepeated  | status | groupIds   |
      | testadmin | testadmin |          | testadmin | testadmin | AdminQwerty12345! | AdminQwerty12345! | 1      | superAdmin |

  @AdminService @NoRetry
  Scenario Outline: Create new Super Admin - Login Name already taken
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST CreateNewAdmin payload "<email>" "<firstName>" "<language>" "<lastName>" "<loginName>" "<password>" "<passwordRepeated>" <status> "<groupIds>"
    When I make a "POST" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    Then the API call fails with status code 400
    And the "errorId" in response body is "USERNAME_ALREADY_TAKEN"
    And the property "description" includes value "already taken ([Error Id: USERNAME_ALREADY_TAKEN])"

    Examples:
      | email     | firstName | language | lastName  | loginName    | password          | passwordRepeated  | status | groupIds   |
      | testadmin | testadmin |          | testadmin | USE_EXISTING | AdminQwerty12345! | AdminQwerty12345! | 1      | superAdmin |

  @AdminService @NoRetry
  Scenario Outline: Create new Super Admin - Password invalid length
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST CreateNewAdmin payload "<email>" "<firstName>" "<language>" "<lastName>" "<loginName>" "<password>" "<passwordRepeated>" <status> "<groupIds>"
    When I make a "POST" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    Then the API call fails with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the property "description" includes value "password INVALID_LENGTH"

    Examples:
      | email     | firstName | language | lastName  | loginName | password     | passwordRepeated | status | groupIds   |
      | testadmin | testadmin |          | testadmin | testadmin | Qwerty12345! | Qwerty12345!     | 1      | superAdmin |

  @AdminService @NoRetry
  Scenario Outline: Create new Super Admin - Invalid password confirmation
    Given I create a Get "cc_csrftokenSpec" header
    And I create a POST CreateNewAdmin payload "<email>" "<firstName>" "<language>" "<lastName>" "<loginName>" "<password>" "<passwordRepeated>" <status> "<groupIds>"
    When I make a "POST" call to "CreateOrCheckNewClerkUser" to service "AdminService"
    Then the API call fails with status code 400
    And the "errorId" in response body is "PASSWORD_AND_PASSWORD_REPEATED_NOT_THE_SAME"
    And the property "description" includes value "Password and password repeated are not the same ([Error Id: PASSWORD_AND_PASSWORD_REPEATED_NOT_THE_SAME])"

    Examples:
      | email     | firstName | language | lastName  | loginName | password          | passwordRepeated  | status | groupIds   |
      | testadmin | testadmin |          | testadmin | testadmin | AdminQwerty12345! | AdminQwerty54321! | 1      | superAdmin |

  @AdminService
  Scenario: Get Admin by adminId
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetAdminById" of service "AdminService" with saved AdminId
    When I make a "GET" call to "GetAdminById" to service "AdminService"
    Then the API call is successful with status code 200
    And the "status" in response body is "1"
    And I verify the "existing" admin "loginName" in the response body
    And I verify the "existing" admin "email" in the response body

  @AdminService @NoRetry
  Scenario: Get Admin by adminId - Invalid adminId
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetAdminById" of service "AdminService" with new InvalidAdminId
    When I make a "GET" call to "GetAdminById" to service "AdminService"
    Then the API call fails with status code 404
    And the "description" in response body is "Admin with id 500 not found ([Error Id: ADMIN_NOT_FOUND_BY_ID])"
    And the "errorId" in response body is "ADMIN_NOT_FOUND_BY_ID"

