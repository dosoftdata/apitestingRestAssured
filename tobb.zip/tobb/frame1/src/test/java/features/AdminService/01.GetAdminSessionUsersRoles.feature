Feature: Get Admin Session-Users-Roles

  @AdminService
  Scenario: Get Admin Session - Verify response contains session info
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header
    And I make a "GET" call to "GetAdminSession" to service "AdminService"
    Then the API call is successful with status code 200
    And the "status" in response body is "1"
    And the "loginName" in response body is "admin"

  @AdminService
  Scenario: Get Admin Session - Owner Application Backoffice
    Given I create a Get "cc_csrftokenSpec" header with query params "ownerApplication" "backoffice"
    When I make a "GET" call to "GetAdminSession" to service "AdminService"
    Then the API call is successful with status code 200

  @AdminService
  Scenario: Get Admin Users - Verify response contains users
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetAdminUsers" to service "AdminService"
    Then the API call is successful with status code 200
    And the number of results in the array "data" is greater than 0

  @AdminService @NoRetry
  Scenario: Get Admin Users - Invalid sortBy parameter
    Given I create a Get "cc_csrftokenSpec" header with query params "sortby" "test"
    When I make a "GET" call to "GetAdminUsers" to service "AdminService"
    Then the API call fails with status code 400
    And the "description" in response body is "Illegal sortby value ([Error Id: ILLEGAL_SORTBY])"
    And the "errorId" in response body is "ILLEGAL_SORTBY"

  @AdminService @NoRetry
  Scenario: Get Admin Users - Empty sortBy value
    Given I create a Get "cc_csrftokenSpec" header with query params "sortby" ""
    When I make a "GET" call to "GetAdminUsers" to service "AdminService"
    Then the API call fails with status code 400
    And the "description" in response body is "Illegal sortby value ([Error Id: ILLEGAL_SORTBY])"
    And the "errorId" in response body is "ILLEGAL_SORTBY"

  @AdminService @NoRetry
  Scenario: Get Admin Users - Empty order value
    Given I create a Get "cc_csrftokenSpec" header with query params "order" ""
    When I make a "GET" call to "GetAdminUsers" to service "AdminService"
    Then the API call fails with status code 400
    And the "description" in response body is "Illegal order value ([Error Id: ILLEGAL_ORDER])"
    And the "errorId" in response body is "ILLEGAL_ORDER"

  @AdminService @NoRetry
  Scenario: Get Admin Users - roleId not found
    Given I create a Get "cc_csrftokenSpec" header with query params "roleId" "test"
    When I make a "GET" call to "GetAdminUsers" to service "AdminService"
    Then the API call fails with status code 404
    And the "description" in response body is "Role does not exist ([Error Id: ROLE_NOT_FOUND]) ([Error Id: ROLE_NOT_FOUND])"
    And the "errorId" in response body is "ROLE_NOT_FOUND"

  @AdminService
  Scenario Outline: Get Admin Roles - Verify response contains roles
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "RolesAdminCC" to service "AccessService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects are greater than 0
    And the property "<name>" and value "<value1>" exist in the response body
    And the property "<description>" and value "<value2>" exist in the response body
    And I copy the value of the "<adminAccessRoleType>" admin accessRoleId from the response

    Examples:
      | name | value1      | description | value2                                                                | adminAccessRoleType |
      | name | Super Admin | description | Group of admins that have full access to all Backoffice functionality | Super Admin         |
      | name | clerk       | description | Group of admins that have full access to Affiliate app                | clerk               |

  @AdminService
  Scenario: Export Super Admin Role to CSV
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "ExportSuperAdminUsers" of service "AdminService" with new SuperAdminAccessRoleId
    When I make a "GET" call to "ExportSuperAdminUsers" to service "AdminService"
    Then the API call is successful with status code 200

  @AdminService @NoRetry
  Scenario: Export Admin Role to CSV - Role Not Found
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "ExportSuperAdminUsers" of service "AdminService" with new InvalidAdminRoleId
    When I make a "GET" call to "ExportSuperAdminUsers" to service "AdminService"
    Then the API call fails with status code 404
    And the "description" in response body is "Role does not exist ([Error Id: ROLE_NOT_FOUND]) ([Error Id: ROLE_NOT_FOUND])"
    And the "errorId" in response body is "ROLE_NOT_FOUND"