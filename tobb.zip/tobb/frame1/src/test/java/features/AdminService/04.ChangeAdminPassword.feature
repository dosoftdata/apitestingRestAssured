Feature: Change Admin Password

  @AdminService
  Scenario Outline: Change Admin password for invalid adminId - adminId string
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT UpdateAdminPassword payload "<newPassword>" "<newPasswordRepeated>"
    When I change url resource of method "UpdateAdminPassword" of service "AdminService" with configured adminId "testId"
    And I make a "PUT" call to "UpdateAdminPassword" to service "AdminService"
    Then the API call fails with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the "description" in response body is "Admin Id must be numeric"

    Examples:
      | newPassword      | newPasswordRepeated  |
      | Qwerty123456789! | Qwerty123456789!     |

  @AdminService
  Scenario Outline: Change Admin password for adminId - Invalid password length
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT UpdateAdminPassword payload "<newPassword>" "<newPasswordRepeated>"
    When I change url resource of method "UpdateAdminPassword" of service "AdminService" with saved AdminId
    And I make a "PUT" call to "UpdateAdminPassword" to service "AdminService"
    Then the API call fails with status code 400
    And the "errorId" in response body is "INVALID_ARGUMENT"
    And the property "description" includes value "passwordRepeated INVALID_LENGTH"

    Examples:
      | newPassword | newPasswordRepeated |
      | Admin12345! | Admin12345!         |

  @AdminService
  Scenario Outline: Change Admin password for adminId - Password and repeated password do not match
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT UpdateAdminPassword payload "<newPassword>" "<newPasswordRepeated>"
    When I change url resource of method "UpdateAdminPassword" of service "AdminService" with saved AdminId
    And I make a "PUT" call to "UpdateAdminPassword" to service "AdminService"
    Then the API call fails with status code 400
    And the "errorId" in response body is "PASSWORD_AND_PASSWORD_REPEATED_NOT_THE_SAME"
    And the "description" in response body is "Password and password repeated are not the same ([Error Id: PASSWORD_AND_PASSWORD_REPEATED_NOT_THE_SAME])"

    Examples:
      | newPassword      | newPasswordRepeated  |
      | Qwerty123456789! | Qwerty1234567899!    |

  @AdminService
  Scenario Outline: Change Admin password for adminId - Verify password is changed successfully
    Given I create a Get "cc_csrftokenSpec" header
    And I create a PUT UpdateAdminPassword payload "<newPassword>" "<newPasswordRepeated>"
    When I change url resource of method "UpdateAdminPassword" of service "AdminService" with saved AdminId
    And I make a "PUT" call to "UpdateAdminPassword" to service "AdminService"
    Then the API call is successful with status code 200
    And the "status" in response body is "1"

    Examples:
      | newPassword      | newPasswordRepeated  |
      | Qwerty123456789! | Qwerty123456789!     |