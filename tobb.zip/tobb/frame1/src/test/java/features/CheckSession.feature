#This feature is to check for BUG FIX PAM-18127
 # Please run each scenario alone for now.
@CheckSessionConfigured @access-service-tbd
Feature: Check Session

  #Works independently
  Scenario: Check Session - With Cookies
    Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    When I make a "GET" call to "CheckSession" to service "AccessService"
    Then the API call is successful with status code 204

    # Please run alone.
  @StandaloneSession1
  Scenario: Check Session - Without Cookies
    Given I login as a "configuredPlayerWeb" user
    And I clear all cookies from CookieStore
    And I create a Get "mainSpec" header
    When I make a "GET" call to "CheckSession" to service "AccessService"
    Then the API call is successful with status code 204

   #Please run alone
  @StandaloneSession2
  Scenario: Check Session - No Login
    And I create a Get "mainSpec" header
    When I make a "GET" call to "CheckSession" to service "AccessService"
    Then the API call is successful with status code 403