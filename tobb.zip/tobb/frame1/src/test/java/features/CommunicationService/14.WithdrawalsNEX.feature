Feature: WithdrawalsNEX

  @CommunicationService
  Scenario Outline: Manual adjustment for Withdrawal in Betting wallet via BO
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Lottery wallet"
    When I change url resource of method "ManualAdjustBettingWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "transactionType" in response body array with index "[0]" has value "<transactionType>"
    And the property "transactionSubType" in response body array with index "[0]" has value "<transactionSubType>"
    And the property "currency" in response body array with index "[0]" has value "EUR"
    And the property "description" in response body array with index "[0]" has value "Closing account manual adjustment"
    And the property "operation" in response body array with index "[0]" has value "<operation>"
    And the property "amount" in response body array with index "[0]" has value "50.0"
    And the number of results in a nameless array of objects is 1

    Examples:
      | transactionType  | transactionSubType | productId  | operation | amount |
      | TT_MANUAL_ADJUST | MDWC               | SPORTSBOOK | DEPOSIT   | 50     |


  @CommunicationService @skipIfNotAzure
  Scenario: Reset Mappings
    Given I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200


  @CommunicationService  @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Tora Response 200 for Withdrawal via IBAN
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName               | requiredScenarioState | priority | method | url             | status | body | headers          |
      | ToraWithdrawalsResponse200 | Started               |          | ANY    | .*/v1/transfers | 200    |      | application/json |

  @CommunicationService
  Scenario Outline: Valid withdrawal via IBAN - SPORTSBOOK
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post Withdrawal via "<viaMethod>" payload with <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "ValidWithdrawalViaCardOrIBAN" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "PENDING"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "IBAN"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "paymentMethod.type" in response body is "BANK_ACCOUNT"
    And the "paymentMethod.id" in response body is "IBAN"
    And the "amount.currency" in response body is "EUR"
    And the "paymentMethod.bankAccount.accountNumber" in response body is "GR2202655559367039137283047"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the withdrawal paymentId

    Examples:
      | amount | action  | operation         | paymentMethodType | viaMethod |
      | 10     | PREPARE | WALLET_WITHDRAWAL | BANK_ACCOUNT      | IBAN      |

  @CommunicationService
  Scenario: Approve Withdrawal via IBAN
    Given I create a ApproveWithdrawal Put payload with amount 10
    When I change url resource of method "ApproveWithdrawal" of service "WalletService" with new withdrawal payment Id
    And I make a "PUT" call to "ApproveWithdrawal" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "APPROVED"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "IBAN"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "paymentMethod.type" in response body is "BANK_ACCOUNT"
    And the "paymentMethod.id" in response body is "IBAN"
    And the "amount.currency" in response body is "EUR"
    And the "paymentMethod.bankAccount.accountNumber" in response body is "GR2202655559367039137283047"
    And I verify the player id "owner.id" in the response body


  Scenario Outline: Get and Verify Wallets Balance
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    @CommunicationService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 80.0     | 80.0         | 40.0                    | 0.0              | 40.0                 | 80.0     | 80.0         | 40.0                    | 0.0              | 40.0                 |


  #Sto integration dn vlepw to 3o example
  #no new oti itan prin

  @CommunicationService
  Scenario Outline: Get Player Notifications (JOKER,CASINO,SPORTSBOOK) - SPORTSBOOK NOTIFICATION VERIFICATION - OTHER OLD VALUES
    Given I setup gameId header to "<xGameId>"
    And I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I copy the value of the notificationId from the response of GetPlayerNotifications
    And I copy the value of the notificationIdOnly from the response of GetPlayerNotifications
    And I copy the value of the userType from the response of GetPlayerNotifications
    And the property "read" in response body array with index "data[0]" has value "<readValue>"
    And the property "subject" in response body array with index "data[0]" contains either of the values "<subjectValue>"
    And the property "body" in response body array with index "data[0]" contains either of the values "<bodyValue>"

    @skipIfAzure
    Examples:
      | xGameId    | keys                | values | readValue | bodyValue                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | subjectValue                                                                                             |
      | JOKER      | pageNumber,pageSize | 1,1    | false     | Θα θέλαμε να σε ενημερώσουμε ότι το αίτημα για ανάληψη στο opaponline.gr εγκρίθηκε,Το αίτημα ανάληψης από τον λογαριασμό σου εγκρίθηκε,Ο λογαριασμός σου έχει πιστωθεί,Συγχαρητήρια! Ο λογαριασμός σας έχει πιστωθεί με επιτυχία και τώρα μπορείτε να αρχίσετε να παίζετε online ποδόσφαιρο, μπάσκετ, τένις και πολλά άλλα, 24 ώρες την ημέρα, ακόμη και ζωντανά κατά τη διάρκεια των παιχνιδιών! Καλή τύχη στο επόμενο στοίχημα! ###Δες τις λεπτομέρειες των συναλλαγών σου### | Το αίτημα ανάληψης εγκρίθηκε,Ο λογαριασμός σου έχει πιστωθεί,Ο λογαριασμός σας έχει πιστωθεί με επιτυχία |
      | CASINO     | pageNumber,pageSize | 1,1    | false     | Θα θέλαμε να σε ενημερώσουμε ότι ο αριθμός IBAN του τραπεζικού σου λογαριασμού έχει επαληθευτεί με επιτυχία,Συγχαρητήρια! Ο λογαριασμός σας έχει πιστωθεί με επιτυχία,Το αίτημα ανάληψης από τον λογαριασμό σου εγκρίθηκε                                                                                                                                                                                                                                                       | Επιτυχημένη επαλήθευση IBAN,Ο λογαριασμός σου έχει πιστωθεί,Έγκριση πληρωμής                             |
      | SPORTSBOOK | pageNumber,pageSize | 1,1    | false     | Θα θέλαμε να σε ενημερώσουμε ότι ο αριθμός IBAN του τραπεζικού σου λογαριασμού έχει επαληθευτεί με επιτυχία,Συγχαρητήρια! Ο λογαριασμός σας έχει πιστωθεί με επιτυχία,Το αίτημα ανάληψης από τον λογαριασμό σου εγκρίθηκε                                                                                                                                                                                                                                                       | Επιτυχημένη επαλήθευση IBAN,Ο λογαριασμός σου έχει πιστωθεί,Έγκριση πληρωμής                             |

    @skipIfNotAzure
    Examples:
      | xGameId    | keys                | values | readValue | bodyValue                                                                                                                                                                                                                                                                                                                                                                                                                                       | subjectValue                          |
      | JOKER      | pageNumber,pageSize | 1,1    | true      | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς. Θα θέλαμε να σε ενημερώσουμε ότι αυτές οι αλλαγές μπορεί να επηρεάσουν πληρωμές ή αναλήψεις. Μπορείς να ελέγξεις ή να διορθώσεις οποιοδήποτε στοιχείο, εάν είναι απαραίτητο, κάνοντας κλικ στον παρακάτω σύνδεσμο: ### Έλεγξε / τροποποίησε τα στοιχεία του τραπεζικού σου λογαριασμού ### Καλή τύχη στο επόμενό σου στοίχημα! | Τροποποιημένος τραπεζικός λογαριασμός |
      | CASINO     | pageNumber,pageSize | 1,1    | true      | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς. Θα θέλαμε να σε ενημερώσουμε ότι αυτές οι αλλαγές μπορεί να επηρεάσουν πληρωμές ή αναλήψεις. Μπορείς να ελέγξεις ή να διορθώσεις οποιοδήποτε στοιχείο, εάν είναι απαραίτητο, κάνοντας κλικ στον παρακάτω σύνδεσμο: ### Έλεγξε / τροποποίησε τα στοιχεία του τραπεζικού σου λογαριασμού ### Καλή τύχη στο επόμενό σου στοίχημα! | Τροποποιημένος τραπεζικός λογαριασμός |
      | SPORTSBOOK | pageNumber,pageSize | 1,1    | true      | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς. Θα θέλαμε να σε ενημερώσουμε ότι αυτές οι αλλαγές μπορεί να επηρεάσουν πληρωμές ή αναλήψεις. Μπορείς να ελέγξεις ή να διορθώσεις οποιοδήποτε στοιχείο, εάν είναι απαραίτητο, κάνοντας κλικ στον παρακάτω σύνδεσμο: ### Έλεγξε / τροποποίησε τα στοιχεία του τραπεζικού σου λογαριασμού ### Καλή τύχη στο επόμενό σου στοίχημα! | Τροποποιημένος τραπεζικός λογαριασμός |

#old message in DEV email not even shown in notifications

  @CommunicationService
  Scenario Outline: Get Player Unseen Notifications (SPORTSBOOK,CASINO,JOKER)
    Given I setup gameId header to "<xGameId>"
    And I create a Get "specWithGameId" header
    When I make a "GET" call to "GetPlayerUnseenNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the response body has single value "<singleValue>"

    @skipIfPreprod @skipIfAzure
    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 0           |
      | CASINO     | 0           |
      | JOKER      | 0           |

    @skipIfIntegration @skipIfUAT
    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 1           |
      | CASINO     | 1           |
      | JOKER      | 0           |

  @CommunicationService
  Scenario Outline: Mark Notifications As Seen - Success case - Calculated Notification Id
    Given I setup gameId header to "<xGameId>"
    And I create a MarkNotificationAsSeen payload with "<id>"
    When I make a "PUT" call to "MarkNotificationAsSeen" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | xGameId | id             | statusCode |
      | CASINO  | notificationId | 204        |


  @CommunicationService
  Scenario Outline: Get Player Unseen Notifications - SPORTSBOOK,CASINO
    Given I setup gameId header to "<xGameId>"
    And I create a Get "specWithGameId" header
    When I make a "GET" call to "GetPlayerUnseenNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the response body has single value "<singleValue>"
    And I setup gameId header to "JOKER"

    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 0           |
      | CASINO     | 0           |

