Feature: Mock Joker Wager

  # Contains Wiremock Stubs that are tagged with @skipIfNotAzure so as tests to be skipped in other environments than Azure.
  # For Debug purposes in other environments comment the above tag otherwise the code won't come up to this feature in Integration for example.
  #There is another safety net that nothing changes in wiremockSpec that throws exception if tag is not included. This will happen in the step that the method call is made.
  #Better to test in Azure thought.
  # In any case leave wiremock.host with an empty value in Integration.properties and we are safe.

  @CommunicationService @skipIfNotAzure
  Scenario: Reset Mappings
    And I create a Get "wiremockSpec" header
    When I make a "POST" call to "ResetAllMappings" to service "WiremockService"
    Then the API call is successful with status code 200

  @CommunicationService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 201 for authorization token 1
    Given I login as a "newPlayerWeb" user
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName         | requiredScenarioState | priority | method | url                   | status | headers          | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
      | testScenarioGetToken | Started               |          | POST   | /authentication/token | 200    | application/json | {\"access_token\": \"eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzY29wZSI6WyJvcGVuaWQiXSwiZXhwIjoxNTc0NjgzOTA1LCJqdGkiOiIxM2I5YjQxMy1lNzA4LTQ3YzItODUxZS0yOTAzNzJhODU2MjYiLCJjbGllbnRfaWQiOiJvcGFwIn0.QZ5mp_nVtsRxS9qMMswfsQRSH4qmRxjuup0tczYtf8vWrzXU2VGP58b0_-AzKdl0Y8rlFoIm5mlNqQ7ddNYZMoP4fS986_4z1BDG9GXymuFOvQujYGhYvXYueDg1pT9tXwvthv4y9jFBs7YG3QE0s5eeqjWsC03E2J55TVc91Y2dhbaALnURyZ8Dhew4QsTp-xlz-ORXwVLWLzy0PqlmE3HhAldJoIcC7kM-eUl5_-e8U3RzupgXR9WDaKL-y9n8f-ZKwcRYX5kq2vAGbWxjXxddgiwpJI7OKuMFx7aZ3F1OMs4HRr39gMzPXQ35ne0TqqqRJx7PS8I8oRZyriMyOg\",\"token_type\": \"bearer\",\"expires_in\": \"3599\",\"scope\": \"openid\",\"jti\": \"13b9b413-e708-47c2-851e-290372a85626\"} |

  @CommunicationService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 200 for Verify Wager
    Given I setup "<guid>" guid and timestamp "<timestamp>" wiremock variable
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | guid    | timestamp | scenarioName           | requiredScenarioState | priority | method | url                                | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
      | datenow | datenow   | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers/verification | 200    | application/json,{{guid}} | {\"promotionOutcomes\":[],\"wager\":{\"dbg\":[{\"addOn\": [{\"columns\":21,\"cost\":10.5,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":7,\"selection\":[1,2,3,4,5,6,7]},{\"requested\":1,\"selection\":[15]}],\"quickPick\":false}],\"columns\":21,\"cost\":10.5,\"creationTime\":\"{{guid}}\",\"updatedTime\":\"{{guid}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{guid}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{guid}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\": 1313},\"status\":\"Played\",\"selectionsType\": 2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\":100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":0}} |

  @CommunicationService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 200 for Get Time
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName     | requiredScenarioState | priority | method | url                                                                    | status | headers          | body                                          |
      | testScenariotIME | Started               |          | GET    | /api/opap/v3.0/draws/5104/upcoming/1?property=drawId&property=drawTime | 200    | application/json | {\"drawId\":10001,\"drawTime\":1610275678000} |

  @CommunicationService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 200 for Play Wager
    Given I setup creationTime "<creationTime>" and wagerId and serialNumbers wiremock variables
    And I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | creationTime | scenarioName           | requiredScenarioState | priority | method | url                   | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
      | datenow      | testScenarioWagerVerif | Started               |          | POST   | /api/opap/v1.0/wagers | 200    | application/json,{{guid}} | {\"wagerId\":\"{{wagerId}}\",\"pilot\":\"false\",\"promotionOutcomes\":[],\"serialNumbers\":[\"{{serialNumbers}}\"],\"wager\":{\"dbg\":[{\"addOn\":[{\"columns\":21,\"cost\":10.5,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":7,\"selection\":[1,2,3,4,5,6,7]},{\"requested\": 1,\"selection\": [15]}],\"quickPick\":false}],\"columns\":21,\"cost\":10.5,\"creationTime\":\"{{creationTime}}\",\"updatedTime\":\"{{creationTime}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{creationTime}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{creationTime}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\":1313},\"status\":\"Played\",\"selectionsType\":2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\": 100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":\"{{wagerId}}\",\"operator\":1}} |


  @CommunicationService @skipIfNotAzure
  Scenario Outline: Wiremock Stub - Intralot response 200 for Email my ticket
    Given I setup creationTime "<creationTime>" and wagerId and serialNumbers wiremock variables
    And I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "GET" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 200

    Examples:
      | creationTime | scenarioName           | requiredScenarioState | priority | method | url                      | status | headers                   | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
      | datenow      | testScenarioWagerVerif | Started               |          | GET    | /api/opap/v1.0/wagers/.* | 200    | application/json,{{guid}} | {\"wagerId\":\"{{wagerId}}\",\"pilot\":\"false\",\"promotionOutcomes\":[],\"serialNumbers\":[\"{{serialNumbers}}\"],\"wager\":{\"dbg\":[{\"addOn\":[{\"columns\":21,\"cost\":10.5,\"gameTypeId\":0,\"discount\":0}],\"blockStatus\":\"Unblocked\",\"boards\":[{\"boardId\": 1,\"panels\":[{\"requested\":7,\"selection\":[1,2,3,4,5,6,7]},{\"requested\": 1,\"selection\": [15]}],\"quickPick\":false}],\"columns\":21,\"cost\":10.5,\"creationTime\":\"{{creationTime}}\",\"updatedTime\":\"{{creationTime}}\",\"discount\":0.0,\"gameId\":5104,\"multipliers\":[1],\"participatingDraws\":{\"draws\":[1313],\"firstDraw\":1313,\"firstDrawTime\":\"{{creationTime}}\",\"firstVisualDraw\":1313,\"lastDraw\":1313,\"lastDrawTime\":\"{{creationTime}}\",\"lastVisualDraw\":1313,\"multipleDraws\":1,\"playedDraw\":1313},\"status\":\"Played\",\"selectionsType\":2}]},\"metadata\":{\"trnsTime\":\"{{timestamp}}\",\"posInfo\":{\"retailerId\": 100000,\"terminalId\":-1,\"userName\":\"-1\"},\"channel\":3,\"wagerId\":\"{{wagerId}}\",\"operator\":1}} |

    #gameType check removed - preprod stubbed
  @CommunicationService
  Scenario Outline: Place Wager (Lottery Wager)
    Given I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
    And I setup gameId header to "<gameType>"
    And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
    When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And I copy the value of the serialNumber from the response

    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick |
      | JOKER    | 0       |         | 1 2 3 4 5 6 7 | 15             | false     |

  @CommunicationService
  Scenario: Email my ticket
    Given I create a Get "mainSpec" header
    And I change url resource of method "EmailMyTicket" of service "WagerService" with new playerId
    And I change url resource of method "EmailMyTicket" of service "WagerService" with new serialNumber
    When I make a "POST" call to "EmailMyTicket" to service "WagerService"
    Then the API call is successful with status code 204

  @CommunicationService
  Scenario Outline: Check that user betslip mail is sent
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the property "data[0].messageText" includes value "δες εδώ το online δελτίο σου!"
    And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
    And the property "<property1>" in response body array with index "<arrayWithIndex>" has value "<propertyValue1>"

    Examples:
      | keys                         | values       | arrayWithIndex | property | propertyValue | property1 | propertyValue1 |
      | pageNumber,pageSize,playerId | 1,1,changeit | data[0]        | origin   | wager-service | status    | CONFIRMED      |

