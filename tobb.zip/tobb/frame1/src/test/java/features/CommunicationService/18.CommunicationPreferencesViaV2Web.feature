Feature: CommunicationPreferencesViaV2Web

  Scenario Outline: Get player preferences - Joker
    Given I setup gameId header to "<xGameId>"
    And I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"

    @CommunicationService
    Examples:
      | keys           | values    | categories                       | subCategories                    | xGameId |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | JOKER   |


  Scenario Outline:  Edit player preferences V2 - Selected equals to false for EP, NEP, campaign OPAP
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                          | subCategory                                                                                                       | selected                            | messageType                              | preferenceType                                              | xGameId    |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP | false,false,false,false,false,false | EMAIL,SMS,VIBER,CALL,NOTIFY,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | JOKER      |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP               | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP               | false,false,false,false,false       | EMAIL,SMS,VIBER,CALL,NOTIFY              | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING           | SPORTSBOOK |
      | CAMPAIGN_OPAP,CAMPAIGN_OPAP,CAMPAIGN_OPAP,CAMPAIGN_OPAP                                                           | CAMPAIGN_OPAP,CAMPAIGN_OPAP,CAMPAIGN_OPAP,CAMPAIGN_OPAP                                                           | false,false,false,false             | EMAIL,SMS,VIBER,CALL                     | MARKETING,MARKETING,MARKETING,MARKETING                     | CASINO     |


  Scenario Outline: Get player preferences - Joker, Sportsbook, Casino
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the property "selected" has value "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | JOKER      |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     |

  Scenario Outline:  Edit player preferences V2 - EP for Email
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                          | subCategory                                                                                                       | selected                           | messageType                              | preferenceType                                              | xGameId |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP | true,false,false,false,false,false | EMAIL,SMS,VIBER,CALL,NOTIFY,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | JOKER   |

  Scenario Outline: Get player preferences - Joker - EP for Email
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category,messageType" has values "CAMPAIGN_OFFERS_EP,EMAIL" with prefix "&&" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                       | subCategories                    | xGameId |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | JOKER   |

  Scenario Outline: Get player preferences - Sportbook/Casino - EP for Email
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the property "selected" has value "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     |


  Scenario Outline:  Edit player preferences V2 - EP for Viber
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                | subCategory                                                                                                                                                                             | selected                                                         | messageType                                                                | preferenceType                                                                                                | xGameId |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | false,false,false,false,true,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | JOKER   |


  Scenario Outline: Get player preferences - Joker -  EP for Viber
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category,messageType" has values "CAMPAIGN_OFFERS_EP,VIBER" with prefix "&&" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                       | subCategories                    | xGameId |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | JOKER   |

  Scenario Outline: Get player preferences - Sportbook/Casino -  EP for Viber
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the property "selected" has value "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     |


  Scenario Outline:  Edit player preferences V2 - EP only for Calls
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                               | subCategory                                                                                                                                            | selected                                             | messageType                                      | preferenceType                                                                            | xGameId |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | false,false,false,false,false,false,true,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | JOKER   |

  Scenario Outline: Get player preferences - Joker - EP only for Calls
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category,messageType" has values "CAMPAIGN_OFFERS_EP,CALL" with prefix "&&" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                       | subCategories                    | xGameId |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | JOKER   |

  Scenario Outline: Get player preferences - Sportbook/Casino - EP only for Calls
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the property "selected" has value "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     |


  Scenario Outline:  Edit player preferences V2 - EP only for SMS
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                               | subCategory                                                                                                                                            | selected                                             | messageType                                      | preferenceType                                                                            | xGameId |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | false,false,true,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | JOKER   |

  Scenario Outline: Get player preferences - Joker - EP only for SMS
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category,messageType" has values "CAMPAIGN_OFFERS_EP,SMS" with prefix "&&" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                       | subCategories                    | xGameId |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | JOKER   |

  Scenario Outline: Get player preferences - Sportbook/Casino - EP only for SMS
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the property "selected" has value "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     |

  Scenario Outline:  Edit player preferences V2 - EP for Viber and SMS
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                | subCategory                                                                                                                                                                             | selected                                                        | messageType                                                                | preferenceType                                                                                                | xGameId |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | false,false,true,false,true,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | JOKER   |

  Scenario Outline: Get player preferences - Joker - EP for Viber and SMS
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify channels activation for EP and message type SMS and VIBER have selected "true"

    @CommunicationService
    Examples:
      | keys           | values    | categories                       | subCategories                    | xGameId |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | JOKER   |

  Scenario Outline: Get player preferences - Sportbook/Casino - EP for Viber and SMS
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the property "selected" has value "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     |


  Scenario Outline:  Edit player preferences V2 - EP for All channels
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                | subCategory                                                                                                                                                                             | selected                                                    | messageType                                                                       | preferenceType                                                                                                          | xGameId |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | true,false,true,false,true,false,true,false,true,true,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | JOKER   |

  Scenario Outline: Get player preferences - Joker - EP for All channels
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category" has values "CAMPAIGN_OFFERS_EP" with prefix "" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                       | subCategories                    | xGameId |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | JOKER   |

  Scenario Outline: Get player preferences - Sportbook/Casino - EP for All channels
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the property "selected" has value "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     |


  Scenario Outline:  Edit player preferences V2 - NEP for Call
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                                                        | subCategory                                                                                                                                                                     | selected                                                   | messageType                                                   | preferenceType                                                                                      | xGameId    |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP | false,false,false,false,false,false,true,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | SPORTSBOOK |

  Scenario Outline: Get player preferences - Joker - NEP for Call
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category,messageType" has values "<values>" with prefix "&&" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    | values                   |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | JOKER      | CAMPAIGN_OFFERS_EP,CALL  |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK | CAMPAIGN_OFFERS_NEP,CALL |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     | CAMPAIGN_OFFERS_NEP,CALL |

  Scenario Outline:  Edit player preferences V2 - NEP for Email
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                                    | subCategory                                                                                                                                                 | selected                                             | messageType                                      | preferenceType                                                                            | xGameId    |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | true,false,false,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | SPORTSBOOK |

  Scenario Outline: Get player preferences - Joker - NEP for Email
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category,messageType" has values "<values>" with prefix "&&" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           | values    |  | categories                        | subCategories                     | xGameId    | values                    |
      | preferenceType | MARKETING |  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | JOKER      | CAMPAIGN_OFFERS_EP,EMAIL  |
      | preferenceType | MARKETING |  | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK | CAMPAIGN_OFFERS_NEP,EMAIL |
      | preferenceType | MARKETING |  | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     | CAMPAIGN_OFFERS_NEP,EMAIL |

  Scenario Outline:  Edit player preferences V2 - NEP for SMS
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                                    | subCategory                                                                                                                                                 | selected                                             | messageType                                      | preferenceType                                                                            | xGameId    |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | false,false,true,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | SPORTSBOOK |

  Scenario Outline: Get player preferences - Joker/Sportsbook/Casino - NEP for SMS
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category,messageType" has values "<values>" with prefix "&&" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    | values                  |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | JOKER      | CAMPAIGN_OFFERS_EP,SMS  |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK | CAMPAIGN_OFFERS_NEP,SMS |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     | CAMPAIGN_OFFERS_NEP,SMS |


  Scenario Outline:  Edit player preferences V2 - NEP for Viber
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                                    | subCategory                                                                                                                                                 | selected                                             | messageType                                      | preferenceType                                                                            | xGameId    |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | false,false,false,false,true,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | SPORTSBOOK |

  Scenario Outline: Get player preferences - Joker - NEP for Viber
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category,messageType" has values "<values>" with prefix "&&" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           |  | values    | categories                        | subCategories                     | xGameId    | values                    |
      | preferenceType |  | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | JOKER      | CAMPAIGN_OFFERS_EP,VIBER  |
      | preferenceType |  | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK | CAMPAIGN_OFFERS_NEP,VIBER |
      | preferenceType |  | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     | CAMPAIGN_OFFERS_NEP,VIBER |


  Scenario Outline:  Edit player preferences V2 - NEP for Email and Call
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                                    | subCategory                                                                                                                                                 | selected                                            | messageType                                      | preferenceType                                                                            | xGameId    |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | true,false,false,false,false,false,true,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | SPORTSBOOK |

  Scenario Outline: Get player preferences - Joker/Sportsbook/Casino - NEP for Email and Call
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify channels activation for category "<category>" and message type CALL and EMAIL have selected "true"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    | category            |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | JOKER      | CAMPAIGN_OFFERS_EP  |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK | CAMPAIGN_OFFERS_NEP |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     | CAMPAIGN_OFFERS_NEP |


  Scenario Outline:  Edit player preferences V2 - NEP for All Channels
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                      | subCategory                                                                                                                                                                                   | selected                                                     | messageType                                                                | preferenceType                                                                                                | xGameId    |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | true,false,true,false,true,false,true,false,false,false,true | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | SPORTSBOOK |

  Scenario Outline: Get player preferences - Joker/Sportsbook/Casino - NEP for All Channels
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify channels activation for category "<category>" and message type not equals to notify have selected "true"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    | category            |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | JOKER      | CAMPAIGN_OFFERS_EP  |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK | CAMPAIGN_OFFERS_NEP |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     | CAMPAIGN_OFFERS_NEP |


  Scenario Outline:  Edit player preferences V2 - NEP - Add email as communication channel
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                      | subCategory                                                                                                                                                                                   | selected                                                         | messageType                                                                | preferenceType                                                                                                | xGameId    |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | false,true,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | SPORTSBOOK |

  Scenario Outline: Get player preferences - Joker - Add email as communication channel
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify channels activations for EP and campaign OPAP and message type "EMAIL" have selected "true"

    @CommunicationService
    Examples:
      | keys           | values    | categories                       | subCategories                    | xGameId |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | JOKER   |

  Scenario Outline: Get player preferences - Sportbook/Casino - Add email as communication channel
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category,messageType" has values "CAMPAIGN_OPAP,EMAIL" with prefix "&&" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                        | subCategories                     | xGameId    |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | SPORTSBOOK |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CASINO     |


  Scenario Outline:  Edit player preferences V2 - Negative scanarios (Invalid vertical Id/Invalid preference/disable email preferences)
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    @CommunicationService
    Examples:
      | category                                                                                                                                                    | subCategory                                                                                                                                                 | selected                                             | messageType                                      | preferenceType                                                                            | xGameId    | errorId               | description                                                                                                                                                      |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP     | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP     | false,true,false,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | SPORTSBOOK | NOT_VALID_VERTICAL_ID | vertical id is not valid ([Error Id: NOT_VALID_VERTICAL_ID])                                                                                                     |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | false,true,false,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY | test,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING      | SPORTSBOOK | PREFERENCE_NOT_VALID  | Preference with type=test, category=CAMPAIGN_OFFERS_NEP, subCategory=CAMPAIGN_OFFERS_NEP and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID])  |
      | ACCOUNTSECURITY                                                                                                                                             | CHANGE                                                                                                                                                      | false                                                | EMAIL                                            | EVENTS                                                                                    | JOKER      | PREFERENCE_NOT_VALID  | Preference with messageType=2, category=ACCOUNTSECURITY, subcategory=CHANGE is not adjustable. ([Error Id: PREFERENCE_NOT_VALID])                                |
      | PAYMENTS                                                                                                                                                    | BANKACCCHANGE                                                                                                                                               | false                                                | EMAIL                                            | EVENTS                                                                                    | JOKER      | PREFERENCE_NOT_VALID  | Preference with messageType=2, category=PAYMENTS, subcategory=BANKACCCHANGE is not adjustable. ([Error Id: PREFERENCE_NOT_VALID])                                |
      | PAYMENTS                                                                                                                                                    | WITHDRAWAL                                                                                                                                                  | false                                                | EMAIL                                            | EVENTS                                                                                    | JOKER      | PREFERENCE_NOT_VALID  | Preference with messageType=2, category=PAYMENTS, subcategory=WITHDRAWAL is not adjustable. ([Error Id: PREFERENCE_NOT_VALID])                                   |
      | PERSONALDETAILSCHANGED                                                                                                                                      | CUSTOMERACCOUNT                                                                                                                                             | false                                                | EMAIL                                            | EVENTS                                                                                    | JOKER      | PREFERENCE_NOT_VALID  | Preference with type=EVENTS, category=PERSONALDETAILSCHANGED, subCategory=CUSTOMERACCOUNT and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID]) |

  Scenario Outline:  Edit player preferences V2 - Events/payments/deposit/email changed
    Given I setup gameId header to "<xGameId>"
    When I create a PutPlayerPreferences payload with "specWithGameId" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesWebV2" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesWebV2" to service "CommunicationService"
    Then the API call is successful with status code 204

    @CommunicationService
    Examples:
      | category | subCategory | selected | messageType | preferenceType | xGameId |
      | PAYMENTS | DEPOSIT     | true     | EMAIL       | EVENTS         | JOKER   |
      | PAYMENTS | DEPOSIT     | false    | EMAIL       | EVENTS         | JOKER   |

