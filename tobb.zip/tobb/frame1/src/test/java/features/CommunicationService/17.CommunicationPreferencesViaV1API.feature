Feature: CommunicationPreferencesViaV1API

  @CommunicationService
  Scenario Outline: Edit player preferences V1 EP - Negative Scenarios
    When I create a "API" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1EP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1EP" to service "CommunicationService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | category           | subCategory        | selected | messageType | preferenceType | errorId              | description                                                                                                                                                   |
      | CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP | true     | EMAIL       | test           | PREFERENCE_NOT_VALID | Preference with type=test, category=CAMPAIGN_OFFERS_EP, subCategory=CAMPAIGN_OFFERS_EP and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID]) |
      | test               | CAMPAIGN_OFFERS_EP | true     | EMAIL       | MARKETING      | PREFERENCE_NOT_VALID | Preference with type=MARKETING, category=test, subCategory=CAMPAIGN_OFFERS_EP and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID])          |
      | CAMPAIGN_OFFERS_EP | test               | true     | EMAIL       | MARKETING      | PREFERENCE_NOT_VALID | Preference with type=MARKETING, category=CAMPAIGN_OFFERS_EP, subCategory=test and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID])          |
      | CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP | true     | test        | MARKETING      | INVALID_JSON         | Invalid JSON input                                                                                                                                            |
      |                    | CAMPAIGN_OFFERS_EP | true     | EMAIL       | MARKETING      | INVALID_ARGUMENT     | may not be empty                                                                                                                                              |
      | CAMPAIGN_OFFERS_EP |                    | true     | EMAIL       | MARKETING      | INVALID_ARGUMENT     | may not be empty                                                                                                                                              |
      | CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP | true     | EMAIL       |                | INVALID_ARGUMENT     | may not be empty                                                                                                                                              |

  @CommunicationService
  Scenario Outline: Edit player preferences V1 NEP - No opt-in for NEP
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1NEP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1NEP" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | categories          | subCategories       | selected | messageType | preferenceType |
      | CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP | false    | NOTIFY      | MARKETING      |


  @CommunicationService
  Scenario Outline: Edit player preferences V1 NEP - No opt-in for NEP
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1NEP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1NEP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories          | subCategories       | selected | messageType | preferenceType |
      | CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP | false    | NOTIFY      | MARKETING      |


  @CommunicationService
  Scenario Outline: Edit player preferences V1 EP - SuccessScenario
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1EP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1EP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                                                              | subCategories                                                                                                                                                                           | selected                                                                        | messageType                                                                | preferenceType                                                                                                |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |


  @CommunicationService
  Scenario Outline: Get player preferences V1 ALL - Verify categories
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array if field "category" has values "CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP" with prefix "||" the field "selected" has value "true" and the rest "false"

    Examples:
      | key                     | value         | categories                                           | subCategories                                        |
      | preferenceType,category | MARKETING,ALL | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP |



    #### NEP
  @CommunicationService
  Scenario Outline: Edit player preferences V1 NEP - Negative Scenarios
    When I create a "API" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1NEP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1NEP" to service "CommunicationService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | category           | subCategory        | selected | messageType | preferenceType | errorId               | description                                                  |
      | CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP | false    | EMAIL       | MARKETING      | NOT_VALID_VERTICAL_ID | vertical id is not valid ([Error Id: NOT_VALID_VERTICAL_ID]) |

  @CommunicationService
  Scenario Outline: Edit player preferences V1 NEP - Success Scenario
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1NEP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1NEP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                                                                    | subCategories                                                                                                                                                                                 | selected                                               | messageType                                                                | preferenceType                                                                                                |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | true,true,true,true,true,true,true,true,true,true,true | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |


  @CommunicationService
  Scenario Outline: Get player preferences V1 - NEP First , EP After
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array with field "selected" has one of values "true"

    Examples:
      | key                     | value             | categories                        | subCategories                     |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |
      | preferenceType,category | MARKETING,ALL_EP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  |


  @CommunicationService
  Scenario Outline: Edit player preferences V1 EP - Success Scenario - EP & EMAIL true
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1EP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1EP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                                                              | subCategories                                                                                                                                                                           | selected                                                                                       | messageType                                                                | preferenceType                                                                                                |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | true,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |


  @CommunicationService
  Scenario Outline: Get player preferences V1 - EP & EMAIL, NEP & NO EMAIL
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array if field "<conditionFields>" has values "<conditionValues>" with prefix "<prefix>" the field "selected" has value "true" and the rest "<restValues>"

    Examples:
      | key                     | value             | categories                        | subCategories                     | conditionFields      | conditionValues          | prefix | restValues |
      | preferenceType,category | MARKETING,ALL_EP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | category,messageType | CAMPAIGN_OFFERS_EP,EMAIL | &&     | false      |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | category             | CAMPAIGN_OFFERS_NEP      |        |            |


  @CommunicationService
  Scenario Outline: Edit player preferences V1 EP - Campaign Offers EP for VIBER true
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1EP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1EP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                                                              | subCategories                                                                                                                                                                           | selected                                                                                      | messageType                                                                | preferenceType                                                                                                |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | true,false,false,false,true,false,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |


    #custom last step can be improved with super step
  @CommunicationService
  Scenario Outline: Get player preferences V1 - ALL_EP for VIBER
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify ALL EP for viber true

    Examples:
      | key                     | value            | categories                       | subCategories                    |
      | preferenceType,category | MARKETING,ALL_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP |

  @CommunicationService
  Scenario Outline: Get player preferences V1 - ALL_NEP & NO EMAIL NO VIBER
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array if field "category" has values "CAMPAIGN_OFFERS_NEP" with prefix "" the field "selected" has value "true" and the rest ""

    Examples:
      | key                     | value             | categories                        | subCategories                     |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |


  @CommunicationService
  Scenario Outline: Edit player preferences V1 NEP - Campaign Offers NEP for SMS & SOCIAL_MEDIA true
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1NEP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1NEP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                                                      | subCategories                                                                                                                                                                   | selected                                                 | messageType                                                   | preferenceType                                                                                      |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP | false,false,true,false,false,false,false,false,true,true | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |

    #custom last step can be improved with super step
  @CommunicationService
  Scenario Outline: Get player preferences V1 - ALL_EP & VIBER
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify ALL EP for viber true

    Examples:
      | key                     | value            | categories                       | subCategories                    |
      | preferenceType,category | MARKETING,ALL_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP |


    #custom last step
  @CommunicationService
  Scenario Outline: Get player preferences V1 -  ALL_NEP & NO EMAIL NO VIBER
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify ALL NEP without email and viber

    Examples:
      | key                     | value             | categories                        | subCategories                     |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |


  @CommunicationService
  Scenario Outline: Edit player preferences V1 EP - All EP but no campaign OPAP
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1EP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1EP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                                                              | subCategories                                                                                                                                                                           | selected                                                    | messageType                                                                | preferenceType                                                                                                |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | true,false,true,false,true,false,true,false,true,false,true | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |


  @CommunicationService
  Scenario Outline: Get player preferences V1 -ALL EP and CAMPAIGN_OPAP only for SMS (NEP)
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array if field "category" has values "CAMPAIGN_OPAP" with prefix "" the field "selected" has value "false" and the rest ""
    Examples:
      | key                     | value         | categories                                           | subCategories                                        |
      | preferenceType,category | MARKETING,ALL | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP |


  @CommunicationService
  Scenario Outline: Edit player preferences V1 EP - EP FOR SMS true
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1EP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1EP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                                                              | subCategories                                                                                                                                                                           | selected                                                         | messageType                                                                | preferenceType                                                                                                |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | false,false,true,false,false,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |


  @CommunicationService
  Scenario Outline: Edit player preferences V1 NEP - NEP for EMAIL true
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1NEP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1NEP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                                                                    | subCategories                                                                                                                                                                                 | selected                                                         | messageType                                                                | preferenceType                                                                                                |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | true,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |

  #specific assertion last
  @CommunicationService
  Scenario Outline: Get player preferences V1 -EP FOR SMS and NEP for EMAIL
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify EP for SMS and NEP for EMAIL

    Examples:
      | key                     | value         | categories                                           | subCategories                                        |
      | preferenceType,category | MARKETING,ALL | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP |


  @CommunicationService
  Scenario Outline: Edit player preferences V1 NEP - SMS for NEP
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1NEP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1NEP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                                  | subCategories                                                                                                                                               | selected                                             | messageType                                      | preferenceType                                                                            |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | false,false,true,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |


  @CommunicationService
  Scenario Outline: Get player preferences V1 - SMS for NEP
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify NEP for SMS

    Examples:
      | key                     | value         | categories                                           | subCategories                                        |
      | preferenceType,category | MARKETING,ALL | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP |


  @CommunicationService
  Scenario Outline: Edit player preferences V1 NEP - No communication preferences
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1NEP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1NEP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                                  | subCategories                                                                                                                                               | selected                                              | messageType                                      | preferenceType                                                                            |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,NOTIFY,CALL | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |

  @CommunicationService
  Scenario Outline: Edit player preferences V1 EP - No communication preferences
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV1EP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV1EP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                             | subCategories                                                                                                                                          | selected                                              | messageType                                      | preferenceType                                                                            |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |

#reached should exist?
  @CommunicationService
  Scenario Outline: Get player preferences V1 - Preference ALL, Category ALL
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array with field "preferenceType" has one of values "<preferenceTypes>"

    Examples:
      | key                     | value   | categories                                                                                                   | subCategories                                                                                                               | preferenceTypes                |
      | preferenceType,category | ALL,ALL | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,PAYMENTS | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CHANGE,PERSONALDETAILSCHANGED,CHANGED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | EVENTS,MARKETING,CAMPAIGN_OPAP |


  @CommunicationService
  Scenario Outline: Get player preferences V1 - Preference MARKETING, Category ALL_EP
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array with field "selected" has one of values "false"


    Examples:
      | key                     | value            | categories                       | subCategories                    |
      | preferenceType,category | MARKETING,ALL_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP |

  @CommunicationService
  Scenario Outline: Get player preferences V1 - Preference MARKETING, Category ALL_NEP
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array with field "selected" has one of values "false"

    Examples:
      | key                     | value             | categories                        | subCategories                     |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |


  @CommunicationService
  Scenario Outline: Add Message Preferences - EMAIL (NEP)
    Given I create a AddMessageTypes Post payload with "<messageTypes>"
    And I change url resource of method "AddMessageTypesNEP" of service "CommunicationService" with new playerId
    When I make a "POST" call to "AddMessageTypesNEP" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | messageTypes |
      | EMAIL        |


    ##############
  @CommunicationService
  Scenario Outline: Get EP Preferences
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array with field "selected" has one of values "false"


    Examples:
      | key                     | value            | categories                       | subCategories                    |
      | preferenceType,category | MARKETING,ALL_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP |

  @CommunicationService
  Scenario Outline: Get NEP Preferences - Email is included
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
      #specific assertion ->

    Examples:
      | key                     | value             | categories                        | subCategories                     |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |


  @CommunicationService
  Scenario Outline: Add Message Preferences - CALL (EP)
    Given I create a AddMessageTypes Post payload with "<messageTypes>"
    And I change url resource of method "AddMessageTypesEP" of service "CommunicationService" with new playerId
    When I make a "POST" call to "AddMessageTypesEP" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | messageTypes |
      | CALL         |

        ##############
  @CommunicationService
  Scenario Outline: Get EP Preferences - Call is included
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array if field "category,messageType" has values "CAMPAIGN_OFFERS_EP,CALL" with prefix "&&" the field "selected" has value "true" and the rest "false"

    Examples:
      | key                     | value            | categories                       | subCategories                    |
      | preferenceType,category | MARKETING,ALL_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP |


  @CommunicationService
  Scenario Outline: Get NEP Preferences - Email is included
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array if field "category,messageType" has values "CAMPAIGN_OFFERS_NEP,EMAIL" with prefix "&&" the field "selected" has value "true" and the rest "false"

    Examples:
      | key                     | value             | categories                        | subCategories                     |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |


  @CommunicationService
  Scenario Outline: Add Message Preferences - Empty Body (NEP)
    Given I create a AddMessageTypes Post payload with "<messageTypes>"
    And I change url resource of method "AddMessageTypesNEP" of service "CommunicationService" with new playerId
    When I make a "POST" call to "AddMessageTypesNEP" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | messageTypes |
      |              |


  @CommunicationService
  Scenario Outline: Get EP Preferences - Call Included - Not modified
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array if field "category,messageType" has values "CAMPAIGN_OFFERS_EP,CALL" with prefix "&&" the field "selected" has value "true" and the rest "false"

    Examples:
      | key                     | value            | categories                       | subCategories                    |
      | preferenceType,category | MARKETING,ALL_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP |


  @CommunicationService
  Scenario Outline: Get NEP Preferences - Call Included - Not modified
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify email and call is included "NEP"

    Examples:
      | key                     | value             | categories                        | subCategories                     |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |

  @CommunicationService
  Scenario Outline: Add Message Preferences - Empty Body (EP)
    Given I create a AddMessageTypes Post payload with "<messageTypes>"
    And I change url resource of method "AddMessageTypesEP" of service "CommunicationService" with new playerId
    When I make a "POST" call to "AddMessageTypesEP" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | messageTypes |
      |              |

  @CommunicationService
  Scenario Outline: Get EP Preferences - Email Included
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify email and call is included "EP"

    Examples:
      | key                     | value            | categories                       | subCategories                    |
      | preferenceType,category | MARKETING,ALL_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP |


  @CommunicationService
  Scenario Outline: Get NEP Preferences - Not modified (call - email incl)
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify email and call is included "NEP"

    Examples:
      | key                     | value             | categories                        | subCategories                     |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |