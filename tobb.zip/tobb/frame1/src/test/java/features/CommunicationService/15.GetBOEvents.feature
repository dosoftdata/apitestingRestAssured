Feature: Get BO events


  @CommunicationService
  Scenario: Get BO events
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetBOEvents" to service "CommunicationService"
    Then the API call is successful with status code 200
    Then I copy the value of the event id from the response

    #modified only a bit from postman. (does some extra check)
    # we don't specifically check for all values here. mostly we want to check if name,status exists and at least one of the expected values (not all)
  Scenario Outline: Get BO events details
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    And the "<property1>" in response body exists
    And the "<property2>" in response body exists
    And the property "name" in response body array with index "<property3>" contains either of the values "NOTIFY,EMAIL,SMS,INTERNAL"
    And the property "status" in response body array with index "<property3>" contains either of the values "ACTIVE,INACTIVE"
    And the "<property4>" in response body exists



    @CommunicationService
    Examples:
      | key     | value          | method             | statusCode | property1 | property2 | property3       | property4 |
      | eventId | replaceEventId | GetBOEventsDetails | 200        | name      | id        | messageTypes[0] | owner     |

  Scenario Outline: Get BO email-templates for specific eventId
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    Then I copy the value of the email template id from the response
    Then the "<property1>" in response body exists
    Then the "<property2>" in response body exists
    Then the "<property3>" in response body exists
    Then the "<property4>" in response body exists
    Then the "<property5>" in response body exists
    Then the "<property6>" in response body exists
    Then the "<property7>" in response body exists
    Then the "<property8>" in response body exists
    Then the "<property9>" in response body exists
    Then the "<property10>" in response body exists
    Then the "<property11>" in response body exists
    Then the "<property12>" in response body exists

    @CommunicationService
    Examples:
      | key     | value          | method                       | statusCode | object      | property1 | property2 | property3  | property4     | property5      | property6 | property7   | property8   | property9  | property10 | property11 | property12 |
      | eventId | replaceEventId | GetBOEmailTemplateForEventId | 200        | jsonData[0] | subject   | body      | senderName | senderAddress | replyToAddress | status    | description | messageType | parameters | locale     | priority   | id         |

  Scenario Outline: Get BO EventId & Email-TemplateId details (Negative scenarios when eventId is random text & eventId not found)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method>" of service "CommunicationService" with path params "eventId" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    @CommunicationService
    Examples:
      | value | method                       | statusCode | errorId          | description                                                     |
      | test  | GetBOEventsDetails           | 400        | INVALID_EVENT_ID | Event id should be numeric ([Error Id: INVALID_EVENT_ID])       |
      | 000   | GetBOEventsDetails           | 404        | EVENT_NOT_FOUND  | Event with id: 000 was not found. ([Error Id: EVENT_NOT_FOUND]) |
      | test  | GetBOEmailTemplateForEventId | 400        | INVALID_EVENT_ID | Event id should be numeric ([Error Id: INVALID_EVENT_ID])       |
      | 000   | GetBOEmailTemplateForEventId | 400        | EVENT_NOT_FOUND  | Event with id: 000 not found ([Error Id: EVENT_NOT_FOUND])      |


  Scenario Outline: Get BO email-templates for specific eventId & email-templateId
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method1>" of service "CommunicationService" with path params "<key1>" "<value1>"
    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    Then the "<property1>" in response body exists
    Then the "<property2>" in response body exists
    Then the "<property3>" in response body exists
    Then the "<property4>" in response body exists
    Then the "<property5>" in response body exists
    Then the "<property6>" in response body exists
    Then the "<property7>" in response body exists
    Then the "<property8>" in response body exists
    Then the "<property9>" in response body exists
    Then the "<property10>" in response body exists
    Then the "<property11>" in response body exists
    Then the "<property12>" in response body exists

    @CommunicationService
    Examples:
      | key             | value                  | method            | statusCode | key1    | value1         | method1           | property1 | property2 | property3  | property4     | property5      | property6 | property7   | property8   | property9  | property10 | property11 | property12 |
      | emailTemplateId | replaceEmailTemplateId | BOEmailTemplateId | 200        | eventId | replaceEventId | BOEmailTemplateId | subject   | body      | senderName | senderAddress | replyToAddress | status    | description | messageType | parameters | locale     | priority   | id         |

  Scenario Outline: Get BO email-templates (Negative scenarios when email template id is random text & email template id not found)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method>" of service "CommunicationService" with path params "eventId" "replaceEventId"
    And I change url resource of method "<method>" of service "CommunicationService" with path params "emailTemplateId" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "<description>" in response body exists

    @CommunicationService
    Examples:
      | method            | value | statusCode | errorId             | description                                                     |
      | BOEmailTemplateId | test  | 400        | INVALID_TEMPLATE_ID | Template id should be numeric ([Error Id: INVALID_TEMPLATE_ID]) |
      | BOEmailTemplateId | 0     | 404        | TEMPLATE_NOT_FOUND  | Template not found for eventId                                  |


#  @CommunicationService
#  Scenario Outline: Change specific template id values - Missing property of body
#    Given I create a Get "cc_csrftokenSpec" header
#    Given I create a ChangeTemplateIdValues payload with "<subject>" "<status>" "<senderAddress>" "<senderName>" "<replyToAddress>" "<body>"
#    And I change url resource of method "BOEmailTemplateId" of service "CommunicationService" with path params "eventId" "replaceEventId"
#    And I change url resource of method "BOEmailTemplateId" of service "CommunicationService" with path params "emailTemplateId" "replaceEmailTemplateId"
#    When I make a "PUT" call to "BOEmailTemplateId" to service "CommunicationService"
#    Then the API call is successful with status code <statusCode>
#    And the "errorId" in response body is "<errorId>"
#    And the "description" in response body is "<description>"
#
#    Examples:
#      | subject | status   | senderAddress   | senderName  | replyToAddress  | body | statusCode | errorId          | description          |
#      | test    | DISABLED | noreply@opap.gr | OPAP Online | support@opap.gr |      | 400        | INVALID_ARGUMENT | body may not be null |
#
#  @CommunicationService
#  Scenario Outline: Change specific template id values - Missing property of status
#    Given I create a Get "cc_csrftokenSpec" header
#    Given I create a ChangeTemplateIdValues payload with "<subject>" "<status>" "<senderAddress>" "<senderName>" "<replyToAddress>" "<body>"
#    And I change url resource of method "BOEmailTemplateId" of service "CommunicationService" with path params "eventId" "replaceEventId"
#    And I change url resource of method "BOEmailTemplateId" of service "CommunicationService" with path params "emailTemplateId" "replaceEmailTemplateId"
#    When I make a "PUT" call to "BOEmailTemplateId" to service "CommunicationService"
#    Then the API call is successful with status code <statusCode>
#    And the "errorId" in response body is "<errorId>"
#    And the "description" in response body is "<description>"
#
#    Examples:
#      | subject | status | body | senderAddress   | senderName  | replyToAddress  | statusCode | errorId          | description     |
#      | test    |        | body | noreply@opap.gr | OPAP Online | support@opap.gr | 400        | INVALID_ARGUMENT | status REQUIRED |
#
#
#  @CommunicationService
#  Scenario Outline: Change specific template id values - Incomplete payload
#    Given I create a Get "cc_csrftokenSpec" header
#    Given I create a ChangeTemplateIdValues payload with "<subject>" "<status>" "<senderAddress>" "<senderName>" "<replyToAddress>" "<body>"
#    And I change url resource of method "BOEmailTemplateId" of service "CommunicationService" with path params "eventId" "replaceEventId"
#    And I change url resource of method "BOEmailTemplateId" of service "CommunicationService" with path params "emailTemplateId" "replaceEmailTemplateId"
#    When I make a "PUT" call to "BOEmailTemplateId" to service "CommunicationService"
#    Then the API call is successful with status code <statusCode>
#    And the "errorId" in response body is "<errorId>"
#
#
#    Examples:
#      | subject | status | senderAddress | senderName | replyToAddress | body | statusCode | errorId          |
#      | test    |        |               |            |                |      | 400        | INVALID_ARGUMENT |
#
#
#  @CommunicationService
#  Scenario Outline: Change specific template id values
#    Given I create a Get "cc_csrftokenSpec" header
#    Given I create a ChangeTemplateIdValues payload with "<subject>" "<status>" "<senderAddress>" "<senderName>" "<replyToAddress>" "<body>"
#    And I change url resource of method "BOEmailTemplateId" of service "CommunicationService" with path params "eventId" "replaceEventId"
#    And I change url resource of method "BOEmailTemplateId" of service "CommunicationService" with path params "emailTemplateId" "replaceEmailTemplateId"
#    When I make a "PUT" call to "BOEmailTemplateId" to service "CommunicationService"
#    Then the API call is successful with status code <statusCode>
#
#    Examples:
#      | subject | status   | senderAddress   | senderName  | replyToAddress  | body | statusCode |
#      | test    | DISABLED | noreply@opap.gr | OPAP Online | support@opap.gr | body | 204        |
#

  Scenario Outline: Get BO email-templates for specific eventId & email-templateId
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key1>" "<value1>"
    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    Then the "<property1>" in response body exists
    Then the "<property2>" in response body exists
    Then the "<property3>" in response body exists
    Then the "<property4>" in response body exists
    Then the "<property5>" in response body exists
    Then the "<property6>" in response body exists
    Then the "<property7>" in response body exists
    Then the "<property8>" in response body exists
    Then the "<property9>" in response body exists
    Then the "<property10>" in response body exists
    Then the "<property11>" in response body exists
    Then the "<property12>" in response body exists

    @CommunicationService
    Examples:
      | key             | value                  | method            | statusCode | key1    | value1         | property1 | property2 | property3  | property4     | property5      | property6 | property7   | property8   | property9  | property10 | property11 | property12 |
      | emailTemplateId | replaceEmailTemplateId | BOEmailTemplateId | 200        | eventId | replaceEventId | subject   | body      | senderName | senderAddress | replyToAddress | status    | description | messageType | parameters | locale     | priority   | id         |

   #removed due to uncertainty of test -> Note securityPasswordExpirationNotifyEvent is not shown in any environment. Maybe check sth else
  Scenario Outline: Get BO notification templates for specific eventId
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    Then the "<property1>" in response body exists
    Then the "<property2>" in response body exists
    Then the "<property3>" in response body exists
    Then the "<property4>" in response body exists
    Then the "<property5>" in response body exists
    Then the "<property6>" in response body exists
    Then the "<property7>" in response body exists
    Then the "<property8>" in response body exists
    Then the "<property9>" in response body exists
    Then the "<property10>" in response body exists
    And I verify the array with field "parameters" has one of values "<properties>"

    #@CommunicationService
    Examples:
      | statusCode | key     | value          | method                      | property1 | property2 | property3 | property4 | property5   | property6   | property7  | property8 | property9 | property10 | properties                                                                  |
      | 200        | eventId | replaceEventId | GeBONotificationsForEventId | subject   | body      | targetUrl | status    | description | messageType | parameters | locale    | priority  | id         | user.contact.email,user.name.last,user.name,user.login.name,user.name.first |

  Scenario Outline: Get BO notification templates (Negative scenarios when eventId is random text and eventId not found)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method>" of service "CommunicationService" with path params "eventId" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    @CommunicationService
    Examples:
      | value | method                      | statusCode | errorId          | description                                               |
      | test  | GeBONotificationsForEventId | 400        | INVALID_EVENT_ID | Event id should be numeric ([Error Id: INVALID_EVENT_ID]) |
      | 0     | GeBONotificationsForEventId | 400        | EVENT_NOT_FOUND  | Event with id: 0 not found ([Error Id: EVENT_NOT_FOUND])  |

#  Scenario Outline: Get BO notification templates for specific eventId & notificationId
#    Given I create a Get "cc_csrftokenSpec" header
#    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key1>" "<value1>"
#    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
#    When I make a "GET" call to "<method>" to service "CommunicationService"
#    Then the API call is successful with status code <statusCode>
#    Then I copy the value of the subject, body and status of the BO notifications templates from the response
#    Then the "<property1>" in response body exists
#    Then the "<property2>" in response body exists
#    Then the "<property3>" in response body exists
#    Then the "<property4>" in response body exists
#    Then the "<property5>" in response body exists
#    Then the "<property6>" in response body exists
#    Then the "<property7>" in response body exists
#    Then the "<property8>" in response body exists
#    Then the "<property9>" in response body exists
#    Then the "<property10>" in response body exists
#    Then the "<property11>" in response body exists
#    Then the "<property12>" in response body exists
#    Then I copy the value of the subject, body and status of the BO notifications templates from the response
#
#    @CommunicationService
#    Examples:
#      | key            | value                 | method                              | statusCode | key1    | value1         | property1 | property2 | property3  | property4     | property5      | property6 | property7   | property8   | property9  | property10 | property11 | property12 |
#      | notificationId | replaceNotificationId | BONotificationsForNotificationId | 200        | eventId | replaceEventId | subject   | body      | senderName | senderAddress | replyToAddress | status    | description | messageType | parameters | locale     | priority   | id         |

#  Scenario Outline: Get BO notification templates for specific eventId &  wrong notificationId
#    Given I create a Get "cc_csrftokenSpec" header
#    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key1>" "<value1>"
#    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
#    When I make a "GET" call to "<method>" to service "CommunicationService"
#    Then the API call is successful with status code <statusCode>
#    Then the "<property1>" in response body exists
#    Then the "<property2>" in response body exists
#    Then the "<property3>" in response body exists
#    Then the "<property4>" in response body exists
#    Then the "<property5>" in response body exists
#    Then the "<property6>" in response body exists
#    Then the "<property7>" in response body exists
#    Then the "<property8>" in response body exists
#    Then the "<property9>" in response body exists
#    Then the "<property10>" in response body exists
#    Then the "<property11>" in response body exists
#    Then the "<property12>" in response body exists
#    And the "errorId" in response body is "<errorId>"
#    And the "description" in response body is "<description>"
#
#    @CommunicationService
#    Examples:
#      | key            | value | method                              | statusCode | key1    | value1         | property1 | property2 | property3  | property4     | property5      | property6 | property7   | property8   | property9  | property10 | property11 | property12 | errorId            | description                                                                         |
#      | notificationId | 0     | BONotificationsForNotificationId | 404        | eventId | replaceEventId | subject   | body      | senderName | senderAddress | replyToAddress | status    | description | messageType | parameters | locale     | priority   | id         | TEMPLATE_NOT_FOUND | Template not found for eventId=27946, templateId=0 ([Error Id: TEMPLATE_NOT_FOUND]) |

#  @CommunicationService
#  Scenario Outline: Change specific notification id values - TargetUrl is null
#    Given I create a Get "cc_csrftokenSpec" header
#    Given I create a ChangeNotificationIdValues payload with "<subject>" "<status>" "<senderAddress>" "<senderName>" "<replyToAddress>" "<body>" "<targetUrl>"
#    And I change url resource of method "BONotificationsForNotificationId" of service "CommunicationService" with path params "eventId" "replaceEventId"
#    And I change url resource of method "BONotificationsForNotificationId" of service "CommunicationService" with path params "notificationId" "replaceNotificationId"
#    When I make a "PUT" call to "BONotificationsForNotificationId" to service "CommunicationService"
#    Then the API call is successful with status code <statusCode>
#
#    Examples:
#      | subject | status   | senderAddress   | senderName  | replyToAddress  | body | targetUrl | statusCode |
#      | test    | oldStatus | noreply@opap.gr | OPAP Online | support@opap.gr | oldBody | null      | 400          |
#
#  @CommunicationService
#  Scenario Outline: Change specific notification id values
#    Given I create a Get "cc_csrftokenSpec" header
#    Given I create a ChangeNotificationIdValues payload with "<subject>" "<status>" "<senderAddress>" "<senderName>" "<replyToAddress>" "<body>" "<targetUrl>"
#    And I change url resource of method "BONotificationsForNotificationId" of service "CommunicationService" with path params "eventId" "replaceEventId"
#    And I change url resource of method "BONotificationsForNotificationId" of service "CommunicationService" with path params "notificationId" "replaceNotificationId"
#    When I make a "PUT" call to "BONotificationsForNotificationId" to service "CommunicationService"
#    Then the API call is successful with status code <statusCode>
#
#    Examples:
#      | subject | status   | senderAddress   | senderName  | replyToAddress  | body | targetUrl | statusCode |
#      | test    | oldStatus | noreply@opap.gr | OPAP Online | support@opap.gr | oldBody | OPAP      | 204          |

#  Scenario Outline: Get BO notification templates for specific eventId & notificationId after manual change
#    Given I create a Get "cc_csrftokenSpec" header
#    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key1>" "<value1>"
#    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
#    When I make a "GET" call to "<method>" to service "CommunicationService"
#    Then the API call is successful with status code <statusCode>
#    Then the "<property1>" in response body exists
#    Then the "<property2>" in response body exists
#    Then the "<property3>" in response body exists
#    Then the "<property4>" in response body exists
#    Then the "<property5>" in response body exists
#    Then the "<property6>" in response body exists
#    Then the "<property7>" in response body exists
#    Then the "<property8>" in response body exists
#    Then the "<property9>" in response body exists
#    Then the "<property10>" in response body exists
#    Then the "<property11>" in response body exists
#    Then the "<property12>" in response body exists
#
#    @CommunicationService
#    Examples:
#      | key            | value                 | method                              | statusCode | key1    | value1         | property1 | property2 | property3  | property4     | property5      | property6 | property7   | property8   | property9  | property10 | property11 | property12 |
#      | notificationId | replaceNotificationId | BONotificationsForNotificationId | 200        | eventId | replaceEventId | subject   | body      | senderName | senderAddress | replyToAddress | status    | description | messageType | parameters | locale     | priority   | id         |
#

#    @CommunicationService
#  Scenario Outline: Change specific notification id values - Old values
#    Given I create a Get "cc_csrftokenSpec" header
#    Given I create a ChangeNotificationIdValues payload with "<subject>" "<status>" "<senderAddress>" "<senderName>" "<replyToAddress>" "<body>" "<targetUrl>"
#    And I change url resource of method "BONotificationsForNotificationId" of service "CommunicationService" with path params "eventId" "replaceEventId"
#    And I change url resource of method "BONotificationsForNotificationId" of service "CommunicationService" with path params "notificationId" "replaceNotificationId"
#    When I make a "PUT" call to "BONotificationsForNotificationId" to service "CommunicationService"
#    Then the API call is successful with status code <statusCode>
#
#    Examples:
#      | subject    | status    | senderAddress   | senderName  | replyToAddress  | body    | targetUrl | statusCode |
#      | oldSubject | oldStatus | noreply@opap.gr | OPAP Online | support@opap.gr | oldBody | OPAP      | 204        |

#
#  Scenario Outline: Get BO notification templates for specific eventId & notificationId - Old Values
#    Given I create a Get "cc_csrftokenSpec" header
#    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key1>" "<value1>"
#    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
#    When I make a "GET" call to "<method>" to service "CommunicationService"
#    Then the API call is successful with status code <statusCode>
#    Then the "<property1>" in response body exists
#    Then the "<property2>" in response body exists
#    Then the "<property3>" in response body exists
#    Then the "<property4>" in response body exists
#    Then the "<property5>" in response body exists
#    Then the "<property6>" in response body exists
#    Then the "<property7>" in response body exists
#    Then the "<property8>" in response body exists
#    Then the "<property9>" in response body exists
#    Then the "<property10>" in response body exists
#    Then the "<property11>" in response body exists
#    Then the "<property12>" in response body exists
#
#    @CommunicationService
#    Examples:
#      | key            | value                 | method                           | statusCode | key1    | value1         | property1 | property2 | property3  | property4     | property5      | property6 | property7   | property8   | property9  | property10 | property11 | property12 |
#      | notificationId | replaceNotificationId | BONotificationsForNotificationId | 200        | eventId | replaceEventId | subject   | body      | senderName | senderAddress | replyToAddress | status    | description | messageType | parameters | locale     | priority   | id         |


  Scenario Outline: Get BO sms templates for specific eventId
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>

    @CommunicationService
    Examples:
      | key     | value          | method                      | statusCode |
      | eventId | replaceEventId | GetBOSmsTemplatesForEventId | 200        |


  Scenario Outline: Get BO sms templates for wrong eventId (eventId random text and event not found)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    @CommunicationService
    Examples:
      | key     | value | method                      | statusCode | errorId          | description                                               |
      | eventId | 0     | GetBOSmsTemplatesForEventId | 400        | EVENT_NOT_FOUND  | Event with id: 0 not found ([Error Id: EVENT_NOT_FOUND])  |
      | eventId | test  | GetBOSmsTemplatesForEventId | 400        | INVALID_EVENT_ID | Event id should be numeric ([Error Id: INVALID_EVENT_ID]) |


  Scenario Outline: Get BO internal messages templates for specific eventId
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>

    @CommunicationService
    Examples:
      | key     | value          | method                          | statusCode |
      | eventId | replaceEventId | GetBOInternalMessagesForEventId | 200        |


  Scenario Outline: Get BO internal messages templates for wrong eventId (eventId random text and event not found)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "<method>" of service "CommunicationService" with path params "<key>" "<value>"
    When I make a "GET" call to "<method>" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    @CommunicationService
    Examples:
      | key     | value | method                          | statusCode | errorId          | description                                               |
      | eventId | 0     | GetBOInternalMessagesForEventId | 400        | EVENT_NOT_FOUND  | Event with id: 0 not found ([Error Id: EVENT_NOT_FOUND])  |
      | eventId | test  | GetBOInternalMessagesForEventId | 400        | INVALID_EVENT_ID | Event id should be numeric ([Error Id: INVALID_EVENT_ID]) |