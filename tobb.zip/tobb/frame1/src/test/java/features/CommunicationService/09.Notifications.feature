Feature: Notifications

  @CommunicationService
  Scenario Outline: Get Player Notifications (SPORTSBOOK,CASINO,JOKER)
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I copy the value of the notificationId from the response of GetPlayerNotifications
    And I copy the value of the notificationIdOnly from the response of GetPlayerNotifications
    And I copy the value of the userType from the response of GetPlayerNotifications
    And the property "read" in response body array with index "data[0]" has value "<readValue>"
    And the property "subject" in response body array with index "data[0]" contains either of the values "<subjectValue>"
    And the property "body" in response body array with index "data[0]" contains either of the values "<bodyValue>"


    Examples:
      | xGameId    | keys                | values | readValue | bodyValue                                                                                                                                                                                                                   | subjectValue                                                          |
      | SPORTSBOOK | pageNumber,pageSize | 1,1    | false     | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς,Θα θέλαμε να σε ενημερώσουμε ότι ο αριθμός IBAN του τραπεζικού σου λογαριασμού έχει επαληθευτεί με επιτυχία | Τροποποιημένος τραπεζικός λογαριασμός,Επιτυχημένη επαλήθευση IBAN     |
      | CASINO     | pageNumber,pageSize | 1,1    | false     | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς,Θα θέλαμε να σε ενημερώσουμε ότι ο αριθμός IBAN του τραπεζικού σου λογαριασμού έχει επαληθευτεί με επιτυχία | Τροποποιημένος τραπεζικός λογαριασμός,Επιτυχημένη επαλήθευση IBAN     |
      | JOKER      | pageNumber,pageSize | 1,1    | false     | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς,ο λογαριασμός σου έχει επαληθευτεί επιτυχώς                                                                 | Τροποποιημένος τραπεζικός λογαριασμός,Επιτυχής επαλήθευση λογαριασμού |

  @CommunicationService
  Scenario Outline: Get Player Unseen Notifications (SPORTSBOOK,CASINO,JOKER)
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header
    When I make a "GET" call to "GetPlayerUnseenNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the response body has single value "<singleValue>"

#Value =2  in joker in uat . Check when revisit for suite.
    @skipIfPreprod @skipIfAzure
    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 1           |
      | CASINO     | 1           |
      | JOKER      | 2           |

    @skipIfIntegration @skipIfUAT
    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 1           |
      | CASINO     | 1           |
      | JOKER      | 1           |


  @CommunicationService
  Scenario Outline: Mark Notifications As Seen - Negative cases (7)
    Given I create a MarkNotificationAsSeen payload with "<id>"
    When I make a "PUT" call to "MarkNotificationAsSeen" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | id                             | statusCode | errorId                  | description                                                                                                                                                                            |
      | 1-123-1                        | 400        | BAD_REQUEST              | UserId parameter not found in session ([Error Id: BAD_REQUEST])                                                                                                                        |
      | 123                            | 400        | INVALID_NOTIFICATION_ID  | Invalid messageNotificationId format. The format must be 'userType-userId-notificationId', where userType ,userId and notificationId are numbers ([Error Id: INVALID_NOTIFICATION_ID]) |
      |                                | 400        | REQUIRED_NOTIFICATION_ID | Notification id must be set. ([Error Id: REQUIRED_NOTIFICATION_ID])                                                                                                                    |
      | 1-playerId-789                 | 400        | NOTIFICATION_NOT_FOUND   | Notification not found ([Error Id: NOTIFICATION_NOT_FOUND])                                                                                                                            |
      | 1-987654324-notificationIdOnly | 400        | BAD_REQUEST              | UserId parameter not found in session ([Error Id: BAD_REQUEST])                                                                                                                        |
      | 21-playerId-notificationIdOnly | 400        | INVALID_USER_ID          | Unknown user type specified ([Error Id: INVALID_USER_ID])                                                                                                                              |
      | empty                          | 400        | REQUIRED_NOTIFICATION_ID | Notification id must be set. ([Error Id: REQUIRED_NOTIFICATION_ID])                                                                                                                    |

  @CommunicationService
  Scenario Outline: Mark Notifications As Seen - Success case - Calculated Notification Id
    Given I setup gameId header to "<xGameId>"
    Given I create a MarkNotificationAsSeen payload with "<id>"
    When I make a "PUT" call to "MarkNotificationAsSeen" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | xGameId    | id             | statusCode |
      | SPORTSBOOK | notificationId | 204        |


  @CommunicationService
  Scenario Outline: Get Player Unseen Notifications (SPORTSBOOK,CASINO,JOKER)
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header
    When I make a "GET" call to "GetPlayerUnseenNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the response body has single value "<singleValue>"

    #Value 1 in joker in uat . from 2->1
    @skipIfAzure @skipIfPreprod
    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 0           |
      | CASINO     | 0           |
      | JOKER      | 1           |

    @skipIfIntegration @skipIfUAT
    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 0           |
      | CASINO     | 0           |
      | JOKER      | 0           |

  @CommunicationService
  Scenario Outline: Mark Notifications As Read - Negative Cases (5)
    Given I create a MarkNotificationAsRead payload with "<read>"
    And I change url resource of method "MarkNotificationAsRead" of service "CommunicationService" with "<notificationId>" notificationId
    When I make a "PUT" call to "MarkNotificationAsRead" to service "CommunicationService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | notificationId                             | read  | errorId                | description                                                                              |
      | new                                        | false | INVALID_READ_STATUS    | Set notification read status to false is not supported ([Error Id: INVALID_READ_STATUS]) |
      | new                                        |       | REQUIRED_READ_STATUS   | Read status must be set. ([Error Id: REQUIRED_READ_STATUS])                              |
      | randomUserType-playerId-notificationIdOnly | true  | INVALID_USER_ID        | Unknown user type specified ([Error Id: INVALID_USER_ID])                                |
      | userType-randomPlayerId-notificationIdOnly | true  | BAD_REQUEST            | UserId parameter not found in session ([Error Id: BAD_REQUEST])                          |
      | userType-playerId-randomNotificationId     | true  | NOTIFICATION_NOT_FOUND | Notification not found ([Error Id: NOTIFICATION_NOT_FOUND])                              |


  @CommunicationService
  Scenario Outline: Mark Notifications As Read - Success Case (1)
    Given I create a MarkNotificationAsRead payload with "<read>"
    And I change url resource of method "MarkNotificationAsRead" of service "CommunicationService" with "new" notificationId
    When I make a "PUT" call to "MarkNotificationAsRead" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | read |
      | true |

  ########################