Feature: Communication Preferences Via 1 CC Notifications

  #GET player -> SEARCHES with current order:
  # EMAIL, SMS, NOTIFY in ACCOUNTSECURITY (1-3 cases),
  # CUSTOMERACCOUNT (4-6 cases),CUSTOMERLIMITS(7-12 cases, CHANGED before REACHED), PAYMENTS (13-21 cases)
  #order maybe different from postman for more speed + same pattern but checks are eventually the same.

  @CommunicationService
  Scenario Outline: Get player preferences BO - Full Notifications
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>

    Examples:
      | selectedValues                                                                                           |
      | true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true |


  @CommunicationService
  Scenario Outline: Edit player preferences - Security Email
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                           | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | true,false,false,false,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Get player preferences BO - Security Email
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                        |
      | true,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false |

  @CommunicationService
  Scenario Outline: Edit player preferences - Security email and pop-up
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                          | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | true,false,false,false,false,false,false,true,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |

  @CommunicationService
  Scenario Outline: Get player preferences BO - Security email and pop-up
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                       |
      | true,true,true,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false |


  @CommunicationService
  Scenario Outline: Edit player preferences - Player email
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                           | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,true,false,false,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Get player preferences BO - Player email
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                        |
      | false,true,false,true,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false |


  @CommunicationService
  Scenario Outline: Edit player preferences - Player email and popup
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                          | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,true,false,false,false,false,false,false,true,false,false,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Get player preferences BO - Player email and popup
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                       |
      | false,true,false,true,true,true,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false |


  @CommunicationService
  Scenario Outline: Edit player preferences - Customer limit change email
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                           | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,false,true,false,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |

  @CommunicationService
  Scenario Outline: Get player preferences - Customer limit change email
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>



    Examples:
      | selectedValues                                                                                                        |
      | false,true,false,false,true,false,true,true,false,false,true,false,false,true,false,false,true,false,false,true,false |


  @CommunicationService
  Scenario Outline: Edit player preferences - Customer limit change email and pop-up
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                          | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,false,true,false,false,false,false,false,false,true,false,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Get player preferences - Customer limit change email and pop-up
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                       |
      | false,true,false,false,true,false,true,true,true,false,true,false,false,true,false,false,true,false,false,true,false |


  @CommunicationService
  Scenario Outline: Edit player preferences - Customer limit reached email
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                           | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,false,false,true,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |

  @CommunicationService
  Scenario Outline: Get player preferences - Customer limit reached email
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                        |
      | false,true,false,false,true,false,false,true,false,true,true,false,false,true,false,false,true,false,false,true,false |


  @CommunicationService
  Scenario Outline: Edit player preferences - Customer limit reached email and pop-up
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                          | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,false,false,true,false,false,false,false,false,false,true,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Get player preferences -  Customer limit reached email and pop-up
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                      |
      | false,true,false,false,true,false,false,true,true,true,true,true,false,true,false,false,true,false,false,true,false |

  @CommunicationService
  Scenario Outline: Edit player preferences - Payments IBAN email
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                           | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,false,false,false,true,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Get player preferences - Payments IBAN email
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                        |
      | false,true,false,false,true,false,false,true,false,false,true,false,true,true,false,false,true,false,false,true,false |

  @CommunicationService
  Scenario Outline: Edit player preferences - Payments IBAN email and pop-up
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                          | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,false,false,false,true,false,false,false,false,false,false,true,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Get player preferences - Payments IBAN email and pop-up
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                       |
      | false,true,false,false,true,false,false,true,false,false,true,false,true,true,true,false,true,false,false,true,false |

  @CommunicationService
  Scenario Outline: Edit player preferences - Payments Deposit email
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                           | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,false,false,false,false,true,false,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Get player preferences - Payments Deposit email
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>

    Examples:
      | selectedValues                                                                                                        |
      | false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,true,true,false,false,true,false |

  @CommunicationService
  Scenario Outline: Edit player preferences - Payments Deposit email and pop-up
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                          | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,false,false,false,false,true,false,false,false,false,false,false,true,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Get player preferences - Payments Deposit email and pop-up
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                       |
      | false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,true,true,true,false,true,false |

  @CommunicationService
  Scenario Outline: Edit player preferences - Payments Withdrawal email
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                           | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,false,false,false,false,false,true,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Get player preferences - Payments Withdrawal email
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                        |
      | false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,true,true,false |

  @CommunicationService
  Scenario Outline: Edit player preferences - Payments Withdrawal email and pop-up
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                          | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,false,false,false,false,false,true,false,false,false,false,false,false,true | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Get player preferences - Payments Withdrawal email and pop-up
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify specific conditions for preferences with values for selected <selectedValues>


    Examples:
      | selectedValues                                                                                                       |
      | false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,false,true,false,true,true,true |


  @CommunicationService
  Scenario Outline: Revert player preferences - No notifications
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                   | selected                                                                            | messageType                                                                                | category                                                                                                                                                                          | preferenceType                                                                                    |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | false,false,false,false,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |


  @CommunicationService
  Scenario Outline: Check email
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I copy the value of the mailId from the response
    And the property "origin" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
    And the property "messageText" in response body array with index "<arrayWithIndex>" has value "<propertyValue2>"

    Examples:
      | key                          | value        | propertyValue | propertyValue2                                     | arrayWithIndex |
      | playerId,pageNumber,pageSize | changeit,1,1 | player        | Your profile information has been changed by admin | data[0]        |


  @CommunicationService
  Scenario Outline: Get hash For Mail Verification - Verify event name/owner
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetHashForMailVerification" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the "<property>" in response body is "<propertyValue>"
    And the "<property2>" in response body is "<propertyValue2>"
    And the "<property3>" in response body is "<propertyValue3>"
    And the id in response body is mailIdForHash

    Examples:
      | property  | propertyValue             | property2  | propertyValue2 | property3 | propertyValue3                                     |
      | eventName | playerUpdatedByAdminEvent | eventOwner | player         | subject   | Your profile information has been changed by admin |

