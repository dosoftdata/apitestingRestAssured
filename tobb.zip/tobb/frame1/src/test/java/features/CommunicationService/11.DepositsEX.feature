Feature: DepositsEX

  Scenario Outline: Deposit via Payment code - Lottery wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId
    And the "paymentMethod.id" in response body is "<paymentMethodId>"
    And the "amount.amount" in response body is "40.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "<paymentMethodType>"
    And the "paymentStatus" in response body is "<paymentStatus>"

    #Differentiate between Azure & Integration cause of stubs.

    @CommunicationService @skipIfAzure
    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType | paymentStatus |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 40     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      | APPROVED      |

    @CommunicationService @skipIfNotAzure
    Examples:
      | paymentMethodId        | paymentCode | amount | action  | operation      | paymentMethodType | paymentStatus |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 40     | PREPARE | WALLET_DEPOSIT | PAYMENT_CODE      | PENDING       |


  @CommunicationService
  Scenario: Commit Deposit To Tora - Via Payment Code
    Given I setup gameId header to "JOKER"
    And I setup a random deposit token Id
    And I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via paymentCode paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via paymentCode

  @CommunicationService
  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via paymentCode paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"

    @CommunicationService
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 40.0    | 40.0        | 40.0                   | 0.0             | 0.0                 |


  @CommunicationService
  Scenario Outline: Get MailId - Check that mail for deposit is received
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array "data" with field "origin" has at least one value "wallet-service"
    And I verify the array "data" with field "status" has at least one value "SENT"
    And I verify the array "data" with field "templateName" has at least one value "<templateName>"


    Examples:
      | key                          | value        | templateName                    |
      | playerId,pageNumber,pageSize | changeit,1,2 | successfulDepositExclusiveEvent |


    #differences in body of the templates in dev -not important after discussion- contains either of the values
  @CommunicationService
  Scenario Outline: Get Player Notifications (SPORTSBOOK,CASINO,JOKER) - New Notification for JOKER
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I copy the value of the notificationId from the response of GetPlayerNotifications
    And I copy the value of the notificationIdOnly from the response of GetPlayerNotifications
    And I copy the value of the userType from the response of GetPlayerNotifications
    And the property "read" in response body array with index "data[0]" has value "<readValue>"
    And the property "subject" in response body array with index "data[0]" contains either of the values "<subjectValue>"
    And the property "body" in response body array with index "data[0]" contains either of the values "<bodyValue>"


    @skipIfNotIntegration
    Examples:
      | xGameId    | keys                | values | readValue | bodyValue                                                                                                                                    | subjectValue                                      |
      | SPORTSBOOK | pageNumber,pageSize | 1,1    | false     | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς.,Επιτυχημένη επαλήθευση IBAN | Τροποποιημένος τραπεζικός λογαριασμός             |
      | CASINO     | pageNumber,pageSize | 1,1    | false     | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς.,Επιτυχημένη επαλήθευση IBAN | Τροποποιημένος τραπεζικός λογαριασμός             |
      | JOKER      | pageNumber,pageSize | 1,1    | false     | ολοκληρώθηκε με επιτυχία!,Το αίτημα ανάληψης από τον λογαριασμό σου εγκρίθηκε,Ο λογαριασμός σας έχει πιστωθεί,Επιτυχημένη επαλήθευση IBAN    | Επιτυχής κατάθεση,Ο λογαριασμός σου έχει πιστωθεί |

    @skipIfIntegration @skipIfPreprod
    Examples:
      | xGameId    | keys                | values | readValue | bodyValue                                                                                                                                                                                                                                                                                                                                                                                                                                         | subjectValue                                                                      |
      | SPORTSBOOK | pageNumber,pageSize | 1,1    | false     | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς.,Θα θέλαμε να σε ενημερώσουμε ότι ο αριθμός IBAN του τραπεζικού σου λογαριασμού έχει επαληθευτεί με επιτυχία.                                                                                                                                                                                                                     | Τροποποιημένος τραπεζικός λογαριασμός,Επιτυχημένη επαλήθευση IBAN                 |
      | CASINO     | pageNumber,pageSize | 1,1    | false     | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς.,Θα θέλαμε να σε ενημερώσουμε ότι ο αριθμός IBAN του τραπεζικού σου λογαριασμού έχει επαληθευτεί με επιτυχία.                                                                                                                                                                                                                     | Τροποποιημένος τραπεζικός λογαριασμός,Επιτυχημένη επαλήθευση IBAN                 |
      | JOKER      | pageNumber,pageSize | 1,1    | true      | ολοκληρώθηκε με επιτυχία!,Το αίτημα ανάληψης από τον λογαριασμό σου εγκρίθηκε,Ο λογαριασμός σας έχει πιστωθεί.,Θα θέλαμε να σε ενημερώσουμε ότι ο αριθμός IBAN του τραπεζικού σου λογαριασμού έχει επαληθευτεί με επιτυχία.,Συγχαρητήρια! Μετά από έλεγχο των απαραίτητων εγγράφων ο λογαριασμός σου έχει επαληθευτεί επιτυχώς. Σε διαβεβαιώνουμε πως τα στοιχεία σου παραμένουν ασφαλή, σύμφωνα με την Πολιτική Προστασίας Προσωπικών Δεδομένων. | Επιτυχής κατάθεση,Ο λογαριασμός σου έχει πιστωθεί,Επιτυχής επαλήθευση λογαριασμού |

    @skipIfNotPreprod
    Examples:
      | xGameId    | keys                | values | readValue | bodyValue                                                                                                                                                                                                                     | subjectValue                                                      |
      | SPORTSBOOK | pageNumber,pageSize | 1,1    | true      | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς.,Θα θέλαμε να σε ενημερώσουμε ότι ο αριθμός IBAN του τραπεζικού σου λογαριασμού έχει επαληθευτεί με επιτυχία. | Τροποποιημένος τραπεζικός λογαριασμός,Επιτυχημένη επαλήθευση IBAN |
      | CASINO     | pageNumber,pageSize | 1,1    | true      | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς.,Θα θέλαμε να σε ενημερώσουμε ότι ο αριθμός IBAN του τραπεζικού σου λογαριασμού έχει επαληθευτεί με επιτυχία. | Τροποποιημένος τραπεζικός λογαριασμός,Επιτυχημένη επαλήθευση IBAN |
      | JOKER      | pageNumber,pageSize | 1,1    | false     | Συγχαρητήρια! Ο λογαριασμός σας έχει πιστωθεί με επιτυχία                                                                                                                                                                     | Επιτυχής κατάθεση,Ο λογαριασμός σου έχει πιστωθεί                 |


  @CommunicationService
  Scenario Outline: Get Player Unseen Notifications (SPORTSBOOK,CASINO,JOKER) - 1 for JOKER
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header
    When I make a "GET" call to "GetPlayerUnseenNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the response body has single value "<singleValue>"

    @skipIfNotIntegration
    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 0           |
      | CASINO     | 0           |
      | JOKER      | 2           |

    @skipIfIntegration
    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 0           |
      | CASINO     | 0           |
      | JOKER      | 1           |


  @CommunicationService
  Scenario Outline: Mark Notifications As Seen - Success case - Calculated Notification Id
    Given I setup gameId header to "<xGameId>"
    Given I create a MarkNotificationAsSeen payload with "<id>"
    When I make a "PUT" call to "MarkNotificationAsSeen" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | xGameId | id             | statusCode |
      | JOKER   | notificationId | 204        |

  @CommunicationService
  Scenario Outline: Get Player Unseen Notifications - JOKER = 0
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header
    When I make a "GET" call to "GetPlayerUnseenNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the response body has single value "<singleValue>"

    @skipIfAzure
    Examples:
      | xGameId | singleValue |
      | JOKER   | 0           |

    @skipIfUAT @skipIfIntegration @skipIfPreprod
    Examples:
      | xGameId | singleValue |
      | JOKER   | 1           |
