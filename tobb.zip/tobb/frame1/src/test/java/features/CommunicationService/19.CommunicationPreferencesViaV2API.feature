Feature: CommunicationPreferencesViaV2API

  @CommunicationService
  Scenario Outline: Edit player preferences V2 EP - Negative Scenarios
    When I create a "API" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV2EP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV2EP" to service "CommunicationService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | category           | subCategory        | selected | messageType | preferenceType | errorId              | description                                                                                                                                                   |
      | CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP | true     | EMAIL       | test           | PREFERENCE_NOT_VALID | Preference with type=test, category=CAMPAIGN_OFFERS_EP, subCategory=CAMPAIGN_OFFERS_EP and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID]) |
      | test               | CAMPAIGN_OFFERS_EP | true     | EMAIL       | MARKETING      | PREFERENCE_NOT_VALID | Preference with type=MARKETING, category=test, subCategory=CAMPAIGN_OFFERS_EP and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID])          |
      | CAMPAIGN_OFFERS_EP | test               | true     | EMAIL       | MARKETING      | PREFERENCE_NOT_VALID | Preference with type=MARKETING, category=CAMPAIGN_OFFERS_EP, subCategory=test and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID])          |
      | CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP | true     | test        | MARKETING      | INVALID_JSON         | Invalid JSON input                                                                                                                                            |
      |                    | CAMPAIGN_OFFERS_EP | true     | EMAIL       | MARKETING      | INVALID_ARGUMENT     | may not be empty                                                                                                                                              |
      | CAMPAIGN_OFFERS_EP |                    | true     | EMAIL       | MARKETING      | INVALID_ARGUMENT     | may not be empty                                                                                                                                              |
      | CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP | true     | EMAIL       |                | INVALID_ARGUMENT     | may not be empty                                                                                                                                              |


  @CommunicationService
  Scenario Outline: Edit player preferences V2 EP - SuccessScenario
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV2EP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV2EP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                             | subCategories                                                                                                                                          | selected                                     | messageType                                                    | preferenceType                                                                            |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | true,true,true,true,true,true,true,true,true | SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |


  @CommunicationService
  Scenario Outline: Get player preferences V1 ALL - Verify categories
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array if field "category" has values "CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP" with prefix "||" the field "selected" has value "true" and the rest "false"

    Examples:
      | key                     | value         | categories                                           | subCategories                                        |
      | preferenceType,category | MARKETING,ALL | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP |

  @CommunicationService
  Scenario Outline: Edit player preferences V2 NEP - Negative Scenarios
    When I create a "API" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV2NEP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV2NEP" to service "CommunicationService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | category           | subCategory        | selected | messageType | preferenceType | errorId               | description                                                  |
      | CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP | false    | EMAIL       | MARKETING      | NOT_VALID_VERTICAL_ID | vertical id is not valid ([Error Id: NOT_VALID_VERTICAL_ID]) |


  @CommunicationService
  Scenario Outline: Edit player preferences V2 NEP - SuccessScenario NEP true
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV2NEP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV2NEP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                              | subCategories                                                                                                           | selected                      | messageType                              | preferenceType                                              |
      | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_NEP | true,true,true,true,true,true | EMAIL,SMS,VIBER,CALL,NOTIFY,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |


  @CommunicationService
  Scenario Outline: Get player preferences V1 - NEP First , EP After - Selected true
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array with field "selected" has one of values "true"

    Examples:
      | key                     | value             | categories                        | subCategories                     |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |
      | preferenceType,category | MARKETING,ALL_EP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP  |


  @CommunicationService
  Scenario Outline: Edit player preferences V2 EP - Success Scenario - Set ALL campaign false
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV2EP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV2EP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                                                                                                                                                                              | subCategories                                                                                                                                                                           | selected                                                          | messageType                                                                | preferenceType                                                                                                |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | false,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING |


  @CommunicationService
  Scenario Outline: Get player preferences V1 - ALL_EP for EMAIL
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array with field "selected" has one of values "false"

    Examples:
      | key                     | value            | categories                       | subCategories                    |
      | preferenceType,category | MARKETING,ALL_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP |


  @CommunicationService
  Scenario Outline: Get player preferences V1 - ALL_NEP without EMAIL
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array if field "category" has values "CAMPAIGN_OFFERS_NEP" with prefix "" the field "selected" has value "true" and the rest "<restValues>"



    Examples:
      | key                     | value             | categories                        | subCategories                     |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |

  @CommunicationService
  Scenario Outline: Edit player preferences V2 EP - CAMPAIGN_OFFERS_EP for VIBER
    When I create a "API" PutPlayerPreferences payload with "<subCategories>" "<selected>" "<messageType>" "<categories>" "<preferenceType>"
    And I change url resource of method "EditPlayerPreferencesApiV2EP" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "EditPlayerPreferencesApiV2EP" to service "CommunicationService"
    Then the API call is successful with status code 204


    Examples:
      | categories                            | subCategories                         | selected  | messageType | preferenceType      |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_EP | true,true | VIBER,EMAIL | MARKETING,MARKETING |


  @CommunicationService
  Scenario Outline: Get player preferences V1 - ALL_EP for VIBER
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify ALL EP for viber true

    Examples:
      | key                     | value            | categories                       | subCategories                    |
      | preferenceType,category | MARKETING,ALL_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP |

  @CommunicationService
  Scenario Outline: Get player preferences V1 - ALL_NEP & NO EMAIL NO VIBER
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetPlayerPreferencesApiV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesApiV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the array if field "category" has values "CAMPAIGN_OFFERS_NEP" with prefix "" the field "selected" has value "true" and the rest ""

    Examples:
      | key                     | value             | categories                        | subCategories                     |
      | preferenceType,category | MARKETING,ALL_NEP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |