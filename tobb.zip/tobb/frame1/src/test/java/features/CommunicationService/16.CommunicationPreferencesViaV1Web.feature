Feature: CommunicationPreferencesViaV1Web

  Scenario Outline: Get player preferences
    Given I setup gameId header to "JOKER"
    And I login as a "newPlayerWeb" user
    And I create a Get "mainSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPlayerPreferencesWebV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "GetPlayerPreferencesWebV1" to service "CommunicationService"
    Then the API call is successful with status code 200

    @CommunicationService
    Examples:
      | keys                     | values   |
      | preferenceType, category | ALL, ALL |
