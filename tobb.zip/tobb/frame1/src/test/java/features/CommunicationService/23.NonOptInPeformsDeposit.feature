Feature: Non Opt In Performs Deposit

  Scenario Outline: Deposit via Payment code - Lottery wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the paymentId
    And the "paymentMethod.id" in response body is "<paymentMethodId>"
    And the "amount.amount" in response body is "160.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "<paymentStatus>"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body


    @CommunicationService @skipIfAzure
    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType | paymentStatus |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 160    | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      | APPROVED      |

    @CommunicationService @skipIfNotAzure
    Examples:
      | paymentMethodId        | paymentCode | amount | action  | operation      | paymentMethodType | paymentStatus |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 160    | PREPARE | WALLET_DEPOSIT | PAYMENT_CODE      | PENDING       |


  @CommunicationService
  Scenario: Commit Card Deposit To Tora
    Given I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via paymentCode paymentId
    When I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via paymentCode

  @CommunicationService
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 |
      | 240.00   | 240.00       | 200.0                   | 0.0              | 40.0                 |


#Don't receive this in UAT . check.
  @CommunicationService
  Scenario Outline: Check email
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I copy the value of the mailId from the response
    And the property "origin" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
    And the property "messageText" in response body array with index "<arrayWithIndex>" has value "<propertyValue2>"

    Examples:
      | key                          | value        | propertyValue  | propertyValue2                  | arrayWithIndex |
      | playerId,pageNumber,pageSize | changeit,1,2 | wallet-service | Ο λογαριασμός σου έχει πιστωθεί | data[0]        |
