Feature: CommunicationPreferencesViaV1CC

  Scenario Outline: Get player preferences - Non existing player
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with configured playerId "111111111"
    When I make a "GET" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    @CommunicationService
    Examples:
      | errorId          | description                                          |
      | PLAYER_NOT_FOUND | Could not find player ([Error Id: PLAYER_NOT_FOUND]) |


  Scenario Outline:  Edit player preferences V1 - Negative scenarios
    Given I create a Get "cc_csrftokenSpec" header
    When I create a PutPlayerPreferences payload with "cc_csrftokenSpec" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    @CommunicationService
    Examples:
      | category                                                                                                                                | subCategory                                                                                                                             | selected                                     | messageType                                      | preferenceType                                                                            | statusCode | errorId              | description                                                                                                                                                  |
      | CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP | CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP | true,true,true,true,true,true,true,true,true | EMAIL,EMAIL,SMS,SMS,NOTIFY,VIBER,VIBER,CALL,CALL | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | 400        | PREFERENCE_NOT_VALID | Preference with type=MARKETING, category=CAMPAIGN_OFFERS, subCategory=CAMPAIGN_OFFERS and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID]) |
      | CAMPAIGN_OFFERS                                                                                                                         | CAMPAIGN_OFFERS                                                                                                                         | true                                         | EMAIL                                            | MARKETING                                                                                 | 400        | PREFERENCE_NOT_VALID | Preference with type=MARKETING, category=CAMPAIGN_OFFERS, subCategory=CAMPAIGN_OFFERS and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID]) |
      | CAMPAIGN_OFFERS                                                                                                                         | CAMPAIGN_OFFERS                                                                                                                         | true                                         | EMAIL                                            | MARKETING                                                                                 | 400        | PREFERENCE_NOT_VALID | Preference with type=MARKETING, category=CAMPAIGN_OFFERS, subCategory=CAMPAIGN_OFFERS and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID]) |
      | ACCOUNTSECURITY                                                                                                                         | CAMPAIGN_OFFERS                                                                                                                         | true                                         |                                                  | MARKETING,MARKETING,MARKETING,MARKETING                                                   | 500        | INVALID_ARGUMENT     | []                                                                                                                                                           |


  Scenario Outline:  Edit player preferences V1 - Full notifications & opt-in
    Given I create a Get "cc_csrftokenSpec" header
    When I create a PutPlayerPreferences payload with "cc_csrftokenSpec" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                                                                                                                                        | subCategory                                                                                                                                                                                                                                                                                                     | selected                                                                             | messageType                                                                                                         | preferenceType                                                                                                                                                            | statusCode |
      | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS                                                                                                                               | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL                                                                                                                                                   | true,true,true,true,true,true,true,true,true,true,true,true,true,true                | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY                          | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS                                                                         | 204        |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OFFERS_EP | true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true | EMAIL,EMAIL,EMAIL,SMS,SMS,SMS,VIBER,VIBER,VIBER,CALL,CALL,CALL,NOTIFY,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | 204        |


  Scenario Outline: Get player preferences - Full opt-in
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the property "selected" has value "true"

  @CommunicationService
    Examples:
      | keys                    | values        | categories                                           | subCategories                                        |
      | preferenceType,category | MARKETING,ALL | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |

  Scenario Outline:  Edit player preferences V1 - EP only
    Given I create a Get "cc_csrftokenSpec" header
    When I create a PutPlayerPreferences payload with "cc_csrftokenSpec" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                                                                                                                                        | subCategory                                                                                                                                                                                                                                                                                                     | selected                                                                                        | messageType                                                                                                         | preferenceType                                                                                                                                                            | statusCode |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP | true,false,false,true,false,false,true,false,false,true,false,false,true,false,true,false,false | EMAIL,EMAIL,EMAIL,SMS,SMS,SMS,VIBER,VIBER,VIBER,CALL,CALL,CALL,NOTIFY,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | 204        |

  Scenario Outline: Get player preferences - EP only
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category" has values "CAMPAIGN_OFFERS_EP" with prefix "" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                                           | subCategories                                        |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |


  Scenario Outline:  Edit player preferences V1 - Only SMS for EP
    Given I create a Get "cc_csrftokenSpec" header
    When I create a PutPlayerPreferences payload with "cc_csrftokenSpec" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                                                                                                                    | subCategory                                                                                                                                                                                                                                                                                 | selected                                                                                       | messageType                                                                                            | preferenceType                                                                                                                                                  | statusCode |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | false,false,false,true,false,false,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,SMS,SMS,SMS,VIBER,VIBER,VIBER,CALL,CALL,CALL,NOTIFY,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | 204        |


  Scenario Outline: Get player preferences - Only SMS for EP
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify the array if field "category,messageType" has values "CAMPAIGN_OFFERS_EP,SMS" with prefix "&&" the field "selected" has value "true" and the rest "false"

    @CommunicationService
    Examples:
      | keys           | values    | categories                                           | subCategories                                        |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |


  Scenario Outline:  Edit player preferences V1 - SMS for EP and campaign OPAP
    Given I create a Get "cc_csrftokenSpec" header
    When I create a PutPlayerPreferences payload with "cc_csrftokenSpec" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                                                                                                                    | subCategory                                                                                                                                                                                                                                                                                 | selected                                                                                      | messageType                                                                                            | preferenceType                                                                                                                                                  | statusCode |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | false,false,false,true,false,true,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,SMS,SMS,SMS,VIBER,VIBER,VIBER,CALL,CALL,CALL,NOTIFY,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | 204        |


  Scenario Outline: Get player preferences - SMS for EP and campaign OPAP
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify channels activations for EP and campaign OPAP and message type "SMS" have selected "true"

    @CommunicationService
    Examples:
      | keys           | values    | categories                                           | subCategories                                        |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |


  Scenario Outline:  Edit player preferences V1 - SMS for EP and campaign OPAP and Email for NEP
    Given I create a Get "cc_csrftokenSpec" header
    When I create a PutPlayerPreferences payload with "cc_csrftokenSpec" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                                                                                                                    | subCategory                                                                                                                                                                                                                                                                                 | selected                                                                                     | messageType                                                                                            | preferenceType                                                                                                                                                  | statusCode |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | false,true,false,true,false,true,false,false,false,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,SMS,SMS,SMS,VIBER,VIBER,VIBER,CALL,CALL,CALL,NOTIFY,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | 204        |


  Scenario Outline: Get player preferences - SMS for EP and campaign OPAP and Email for NEP
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify channels activation for EP and OPAP and message type SMS and for NEP and EMAIL have selected "true"

    @CommunicationService
    Examples:
      | keys           | values    | categories                                           | subCategories                                        |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |


  Scenario Outline:  Edit player preferences V1 - SMS/Viber for EP and NEP and Email for NEP
    Given I create a Get "cc_csrftokenSpec" header
    When I create a PutPlayerPreferences payload with "cc_csrftokenSpec" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                                                                                                                    | subCategory                                                                                                                                                                                                                                                                                 | selected                                                                                   | messageType                                                                                            | preferenceType                                                                                                                                                  | statusCode |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP | false,true,false,true,false,true,true,true,false,false,false,false,false,false,false,false | EMAIL,EMAIL,EMAIL,SMS,SMS,SMS,VIBER,VIBER,VIBER,CALL,CALL,CALL,NOTIFY,NOTIFY,SOCIAL_MEDIA,SOCIAL_MEDIA | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | 204        |


  Scenario Outline: Get player preferences - SMS/Viber for EP and NEP and Email for NEP
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify the property "preferenceType" has value "MARKETING"
    And I verify channels activation for EP and message type SMS, Viber, for NEP and message type EMAIL, Viber and OPAP and message type SMS have selected "true"

    @CommunicationService
    Examples:
      | keys           | values    | categories                                           | subCategories                                        |
      | preferenceType | MARKETING | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP |


  Scenario Outline:  Edit player preferences V1 - Negative scenario- Preference not valid
    Given I create a Get "cc_csrftokenSpec" header
    When I create a PutPlayerPreferences payload with "cc_csrftokenSpec" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    @CommunicationService
    Examples:
      | category                                                                                                                | subCategory                                                                                                             | selected                                      | messageType                               | preferenceType                                                                  | statusCode | errorId              | description                                                                                                                                                  |
      | CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP | CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP,CAMPAIGN_OFFERS,CAMPAIGN_OPAP | false,false,false,false,false,false,true,true | EMAIL,EMAIL,SMS,SMS,VIBER,VIBER,CALL,CALL | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | 400        | PREFERENCE_NOT_VALID | Preference with type=MARKETING, category=CAMPAIGN_OFFERS, subCategory=CAMPAIGN_OFFERS and messageType=EMAIL is not valid. ([Error Id: PREFERENCE_NOT_VALID]) |

  Scenario Outline:  Edit player preferences V1 - No opt-in
    Given I create a Get "cc_csrftokenSpec" header
    When I create a PutPlayerPreferences payload with "cc_csrftokenSpec" "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferencesCCV1" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferencesCCV1" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>

    @CommunicationService
    Examples:
      | category                                                                                                                                                                                                                                                   | subCategory                                                                                                                                                                                                                                                | selected                                                                           | messageType                                                                  | preferenceType                                                                                                                              | statusCode |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP | CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP | false,false,false,false,false,false,false,false,false,false,false,false,false,true | EMAIL,EMAIL,EMAIL,SMS,SMS,SMS,NOTIFY,NOTIFY,VIBER,VIBER,VIBER,CALL,CALL,CALL | MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING,MARKETING | 204        |

