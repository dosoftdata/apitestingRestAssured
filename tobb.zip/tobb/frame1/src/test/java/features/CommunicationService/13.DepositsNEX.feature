Feature: DepositsNEX

  @CommunicationService  @skipIfNotAzure
  Scenario Outline: Tora response 200 for Deposits via Card1
    Given I setup deposit paymentId "<paymentId>" and card fingerprint "<cardFingerprint1>"
    And I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | paymentId | cardFingerprint1                                                 | scenarioName                 | requiredScenarioState | priority | method | url          | status | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | headers          |
      | random    | 5a8c3cec619b62ed3b4b4d98f1b57ae0fa3f4b65ca483a0954f0e6c885724566 | ToraDepositsResponse200Card1 | Started               | 100      | ANY    | /v1/payments | 200    | {\"id\":\"pmt_IEuiimeTppo4AZIHKsKgro2Q\",\"object\":\"payment\",\"captured\":true,\"amount\":5000,\"currency\":\"EUR\",\"description\":\"OPAP wallet deposit id:{{deposit_paymentId}}\",\"meta\":{\"paymentId\":\"{{deposit_paymentId}}\",\"playerId\":\"{{playerId}}\"},\"status\":\"captured\",\"merchant_reference\":\"paymentId:{{deposit_paymentId}}\",\"customer\":null,\"method\":\"card\",\"method_info\":{\"holder_name\":\"TEST PROD\",\"exp_year\":2025,\"exp_month\":6,\"last4\":\"0001\",\"brand\":\"visa\",\"bin\":\"465858\",\"fingerprint\":\"{{Card1_fingerprint}}\"},\"created_at\":\"2019-02-25T13:36:14+00:00\",\"updated_at\":\"2019-02-25T13:36:15+00:00\",\"captured_at\":\"2019-02-25T13:36:15+00:00\",\"refunded\":false,\"refunds\":[],\"refunded_amount\":\"0\",\"fee_amount\":0,\"error_code\":null,\"error_message\":null,\"transaction_id\":\"charge_test_0C2919DE543J66FAA618\"} | application/json |

  @CommunicationService  @skipIfNotAzure
  Scenario Outline: Tora response 200 for Deposits Token
    Given I create a POST AddAStub payload with "<scenarioName>" "<requiredScenarioState>" "<priority>" "<method>" "<url>" "<status>" "<body>" "<headers>"
    When I make a "POST" call to "AddAStub" to service "WiremockService"
    Then the API call is successful with status code 201

    Examples:
      | scenarioName              | requiredScenarioState | priority | method | url             | status | body                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | headers          |
      | ToraDepositsToken200Card1 | Started               | 100      | ANY    | .*tokens/tok_.* | 200    | {\"id\":\"pmt_IEuiimeTppo4AZIHKsKgro2Q\",\"object\":\"payment\",\"captured\":true,\"amount\": \"5000\",\"currency\":\"EUR\",\"description\":\"OPAP wallet deposit id:{{deposit_paymentId}}\",\"meta\":{\"paymentId\":\"{{deposit_paymentId}}\",\"playerId\":\"{{playerId}}\"},\"status\":\"captured\",\"merchant_reference\":\"paymentId:{{deposit_paymentId}}\",\"customer\":null,\"method\":\"card\",\"method_info\":{\"holder_name\":\"TEST PROD\",\"exp_year\":2025,\"exp_month\":6,\"last4\":\"0001\",\"brand\":\"visa\",\"bin\":\"465858\",\"fingerprint\":\"{{Card1_fingerprint}}\"},\"created_at\":\"2019-02-25T13:36:14+00:00\",\"updated_at\":\"2019-02-25T13:36:15+00:00\",\"captured_at\":\"2019-02-25T13:36:15+00:00\",\"refunded\":false,\"refunds\":[],\"refunded_amount\":\"0\",\"fee_amount\":0,\"error_code\":null,\"error_message\":null,\"transaction_id\":\"charge_test_0C2919DE543J66FAA618\", \"type\":\"card\", \"source\" : { \"holder_name\":\"TEST PROD\",\"exp_year\":2025,\"exp_month\":6,\"last4\":\"0001\",\"brand\":\"visa\",\"bin\":\"465858\",\"fingerprint\":\"{{Card1_fingerprint}}\" } } | application/json |

  Scenario Outline: Deposit via Payment code - Lottery wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId
    And the "paymentMethod.id" in response body is "<paymentMethodId>"
    And the "amount.amount" in response body is "40.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "<paymentMethodType>"
    And the "paymentStatus" in response body is "<paymentStatus>"

    #Differentiate between Azure & Integration cause of stubs.

    @CommunicationService @skipIfAzure
    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType | paymentStatus |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 40     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      | APPROVED      |

    @CommunicationService @skipIfNotAzure
    Examples:
      | paymentMethodId            | paymentCode  | amount | action  | operation      | paymentMethodType | paymentStatus |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 40     | PREPARE | WALLET_DEPOSIT | PAYMENT_CODE      | PENDING       |


  @CommunicationService
  Scenario: Commit Deposit To Tora - Via Payment Code
    Given I setup gameId header to "SPORTSBOOK"
    And I setup a random deposit token Id
    And I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via paymentCode paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via paymentCode


  @CommunicationService
  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via paymentCode paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And I verify the paymentId in response body is the calculated paymentId


  Scenario Outline: Get and Verify Wallets Balance - (Lottery & Betting)
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    @CommunicationService
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 80.0     | 80.0         | 40.0                    | 0.0              | 40.0                 | 40.0     | 40.0         | 40.0                    | 0.0              | 0.0                  |


    #This message doesnt exist currently in integration only in UAT.

  @CommunicationService
  Scenario Outline: Get Player Notifications (SPORTSBOOK) - New Notification for SPORTSBOOK
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I copy the value of the notificationId from the response of GetPlayerNotifications
    And I copy the value of the notificationIdOnly from the response of GetPlayerNotifications
    And I copy the value of the userType from the response of GetPlayerNotifications
    And the property "read" in response body array with index "data[0]" has value "<readValue>"
    And the property "subject" in response body array with index "data[0]" contains either of the values "<subjectValue>"
    And the property "body" in response body array with index "data[0]" contains either of the values "<bodyValue>"

    @skipIfAzure
    Examples:
      | xGameId    | keys                | values | readValue | bodyValue                                                                                                                                                                          | subjectValue                                                                  |
      | SPORTSBOOK | pageNumber,pageSize | 1,1    | false     | ολοκληρώθηκε με επιτυχία!,Ο λογαριασμός σας έχει πιστωθεί με επιτυχία,Θα θέλαμε να σε ενημερώσουμε ότι ο αριθμός IBAN του τραπεζικού σου λογαριασμού έχει επαληθευτεί με επιτυχία. | Επιτυχής κατάθεση,Ο λογαριασμός σου έχει πιστωθεί,Επιτυχημένη επαλήθευση IBAN |

    @skipIfNotAzure
    Examples:
      | xGameId    | keys                | values | readValue | bodyValue                                                                                                                                                                                                                                                                                                                                                                                                                                       | subjectValue                          |
      | SPORTSBOOK | pageNumber,pageSize | 1,1    | true      | Έχεις πραγματοποιήσει αλλαγές στον τραπεζικό λογαριασμό που συνδέεται με το λογαριασμό παίκτη που χρησιμοποιείς. Θα θέλαμε να σε ενημερώσουμε ότι αυτές οι αλλαγές μπορεί να επηρεάσουν πληρωμές ή αναλήψεις. Μπορείς να ελέγξεις ή να διορθώσεις οποιοδήποτε στοιχείο, εάν είναι απαραίτητο, κάνοντας κλικ στον παρακάτω σύνδεσμο: ### Έλεγξε / τροποποίησε τα στοιχεία του τραπεζικού σου λογαριασμού ### Καλή τύχη στο επόμενό σου στοίχημα! | Τροποποιημένος τραπεζικός λογαριασμός |


  @CommunicationService
  Scenario Outline: Get Player Unseen Notifications (SPORTSBOOK,CASINO,JOKER) - 1 for SPORTSBOOK,CASINO
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header
    When I make a "GET" call to "GetPlayerUnseenNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the response body has single value "<singleValue>"

    @skipIfIntegration @skipIfPreprod
    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 0           |
      | CASINO     | 0           |
      | JOKER      | 1           |

    @skipIfUAT @skipIfAzure
    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 1           |
      | CASINO     | 1           |
      | JOKER      | 0           |


  @CommunicationService
  Scenario Outline: Mark Notifications As Seen - Success case - Calculated Notification Id
    Given I setup gameId header to "<xGameId>"
    Given I create a MarkNotificationAsSeen payload with "<id>"
    When I make a "PUT" call to "MarkNotificationAsSeen" to service "CommunicationService"
    Then the API call is successful with status code <statusCode>


    Examples:
      | xGameId    | id             | statusCode |
      | SPORTSBOOK | notificationId | 204        |

  @CommunicationService
  Scenario Outline: Get Player Unseen Notifications - SPORTSBOOK,CASINO = 0
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header
    When I make a "GET" call to "GetPlayerUnseenNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the response body has single value "<singleValue>"
    And I setup gameId header to "JOKER"

    Examples:
      | xGameId    | singleValue |
      | SPORTSBOOK | 0           |
      | CASINO     | 0           |


