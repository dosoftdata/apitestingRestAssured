Feature: CC Notifications

  @CommunicationService
  Scenario Outline:  Get BO Notifications - No Params
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetBONotifications" to service "CommunicationService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"


    Examples:
      | errorId                        | description                                                                                                                                         |
      | NO_USERTYPE_PARAMETERS_DEFINED | No userType parameters defined. UserTypes allowed=[playerId, adminId, clerkId, retailerId, terminalId] ([Error Id: NO_USERTYPE_PARAMETERS_DEFINED]) |

  @CommunicationService
  Scenario Outline: Get BO Notifications - Various success params
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetBONotifications" to service "CommunicationService"
    Then the API call is successful with status code 200


    Examples:
      | key        | value    |
      | playerId   | changeit |
      | adminId    | 1        |
      | clerkId    | 1        |
      | retailerId | 1        |
      | terminalId | 1        |

 #uat does not have this message. why check.
  @CommunicationService
  Scenario Outline: Get Player Notifications (SPORTSBOOK,CASINO,JOKER)
    Given I setup gameId header to "<xGameId>"
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerNotifications" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I copy the value of the notificationId from the response of GetPlayerNotifications
    And I copy the value of the notificationIdOnly from the response of GetPlayerNotifications
    And I copy the value of the userType from the response of GetPlayerNotifications
    And the property "subject" in response body array with index "data[0]" contains either of the values "<subjectValue>"


    Examples:
      | xGameId | keys                | values | subjectValue                                                                                                                       |
      | JOKER   | pageNumber,pageSize | 1,1    | Ο λογαριασμός σου έχει πιστωθεί,Τροποποιημένος τραπεζικός λογαριασμός,Επιτυχής επαλήθευση λογαριασμού,Το αίτημα ανάληψης εγκρίθηκε |


  @CommunicationService
  Scenario: Get BO notifications WithId - Successful NotificationId
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetBONotificationsWithId" of service "CommunicationService" with notificationId "changeit"
    When I make a "GET" call to "GetBONotificationsWithId" to service "CommunicationService"
    Then the API call is successful with status code 200

  @CommunicationService
  Scenario Outline: Get BO notifications WithId - Notification not found
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetBONotificationsWithId" of service "CommunicationService" with notificationId "<notificationId>"
    When I make a "GET" call to "GetBONotificationsWithId" to service "CommunicationService"
    Then the API call is successful with status code 404
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"


    Examples:
      | notificationId | errorId                | description                                                 |
      | 1-1-1          | NOTIFICATION_NOT_FOUND | Notification not found ([Error Id: NOTIFICATION_NOT_FOUND]) |