Feature: Player Preferences

  @CommunicationService
  Scenario Outline: Get player preferences - Full notifications
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify notified channels have selected "<selected>"

    Examples:
      | categories                                                                                                   | subCategories                                                                                                                       | selected |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,ACCOUNTSECURITY,CUSTOMERLIMITS,PAYMENTS,CUSTOMERACCOUNT | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | false    |


  @CommunicationService
  Scenario Outline: Edit player preferences - Set email and notifications true for all categories
    When I create a "CC" PutPlayerPreferences payload with "<subCategory>" "<selected>" "<messageType>" "<category>" "<preferenceType>"
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "PUT" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 204

    Examples:
      | subCategory                                                                                                                                                                                          | selected                                                                        | messageType                                                                                              | category                                                                                                                                                                                                                 | preferenceType                                                                                                        |
      | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL | true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true | EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,EMAIL,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY,NOTIFY | ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,ACCOUNTSECURITY,CUSTOMERACCOUNT,CUSTOMERLIMITS,CUSTOMERLIMITS,PAYMENTS,PAYMENTS,PAYMENTS | EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,MARKETING,MARKETING,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS,EVENTS |

  @CommunicationService
  Scenario Outline: Get player preferences - All notifications are ON
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "PlayerPreferences" of service "CommunicationService" with new playerId
    When I make a "GET" call to "PlayerPreferences" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I verify the array with field "category" has one of values "<categories>"
    And I verify the array with field "subCategory" has one of values "<subCategories>"
    And I verify notified channels have selected "<selected>"

    Examples:
      | categories                                                                                                   | subCategories                                                                                                                       | selected |
      | CAMPAIGN_OFFERS_EP,CAMPAIGN_OPAP,CAMPAIGN_OFFERS_NEP,ACCOUNTSECURITY,CUSTOMERLIMITS,PAYMENTS,CUSTOMERACCOUNT | CHANGE,PERSONALDETAILSCHANGED,CHANGED,REACHED,BANKACCCHANGE,DEPOSIT,WITHDRAWAL,CAMPAIGN_OFFERS_EP,CAMPAIGN_OFFERS_NEP,CAMPAIGN_OPAP | true     |
