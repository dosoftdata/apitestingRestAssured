Feature: Api Internal Messages


  @CommunicationService
  Scenario Outline: Get Internal Messages - Missing Player Id
    Given I create a Get "api_mainSpec_mainHost" header
    When I make a "GET" call to "GetInternalMessages" to service "CommunicationService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"


    Examples:
      | errorId          | description                                         |
      | REQUIRED_USER_ID | User id must be set. ([Error Id: REQUIRED_USER_ID]) |

  @CommunicationService
  Scenario Outline: Get Internal Messages - Invalid UserId, UserType
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetInternalMessages" to service "CommunicationService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "description" in response body is "<description>"

    Examples:
      | key     | value      | errorId               | description                                                                                                          |
      | ownerId | changeit   | INVALID_USER_ID       | Invalid user id format; format must be 'type-id', where both type and id are integers. ([Error Id: INVALID_USER_ID]) |
      | ownerId | 1-12345678 | USER_TYPE_NOT_ALLOWED | User type not allowed. ([Error Id: USER_TYPE_NOT_ALLOWED])                                                           |
