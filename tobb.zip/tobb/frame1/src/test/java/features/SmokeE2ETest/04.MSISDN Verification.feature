Feature: MSISDN

  #MSISDN Verification

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get User Info - Verify UserInfo new fields are not null
    Given I login as a "newPlayerWeb" user
    Given I create a Get "specWithGameId" header
    When I make a "GET" call to "GetUserInfo" to service "AccessService"
    Then the API call is successful with status code 200
    And the "<property1>" in response body has value not null
    And the "<property2>" in response body has value not null
    And the "<property3>" in response body has value not null
    And the "<property4>" in response body has value not null
    And the "<property5>" in response body has value not null
    And the "<property6>" in response body has value not null
    And the "<property7>" in response body does not exist
    And I verify the "mobilePhone" in response body is masked
    And I verify the "firstName" in response body is masked
    And I verify the "lastName" in response body is masked
    And I verify the "email" in response body is masked
    And I verify the "phone" in response body is masked
    And I verify the "middleName" in response body is masked
    And I verify the "identityNumber" in response body is masked
    And I verify the "zip" in response body is masked
    And I verify the "address1" in response body is masked
    And I verify the mobilePhone in response body has the calculated first and "new" last digit

    Examples:
      | property1 | property2 | property3 | property4 | property5 | property6  | property7                 |
      | username  | status    | firstName | lastName  | id        | signedUser | pendingMsisdnVerification |


  @nightlySuite @UAT  @Preprod
  Scenario: Get Player's Account Info - masked
    Given I create a Get "specWithGameId" header
    And I change url resource of method "GetPlayerInfoMasked" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerInfoMasked" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify the "mobilePhone" in response body is masked
    And I verify the "firstName" in response body is masked
    And I verify the "lastName" in response body is masked
    And I verify the "email" in response body is masked
    And I verify the "phone" in response body is masked
    And I verify the "middleName" in response body is masked
    And I verify the "identityNumber" in response body is masked
    And I verify the "zip" in response body is masked
    And I verify the "address1" in response body is masked
    And I verify the mobilePhone in response body has the calculated first and "new" last digit

  @nightlySuite @UAT  @Preprod
  Scenario: Get Player's Account Info v2-opap - OTP Request
    Given I create a Get "specWithGameId" header
    And I change url resource of method "GetPlayerInfoEnableOtp" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerInfoEnableOtp" to service "PlayerService"
    Then the API call is successful with status code 417
    And the "id" in response body exists
    And the "resource" in response body exists
    And the "resourceValue" in response body exists
    And the "channel" in response body exists
    And the "expirationTime" in response body exists
    And the "otpGenerationTime" in response body exists
    And I copy the value of the resourceValue from the response
    And I copy the value of the resource from the response
    And I copy the value of the otpId from the response


    #IN UAT one property flag is up and OTP is not 0000 so we need to take this value for otpCode.

  @UAT
  Scenario Outline: Get BO Sms - Verify origin has value player
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetBoSms" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I copy the value of otpCode from messageText from the response


    Examples:
      | key      | value    |
      | playerId | changeit |

  @nightlySuite @Preprod
  Scenario: Get Player's Account Info v2-opap - OTP Verify
    Given I setup X-OTP header to "0000"
    And I create a Get "specWithResourceValue" header
    And I change url resource of method "GetPlayerInfoEnableOtp" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerInfoEnableOtp" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify the "mobilePhone" in response body is not masked
    And I verify the "dateOfBirth" in response body is not masked
    And I verify the "email" in response body is not masked
    And I verify the "firstName" in response body is not masked
    And I verify the "lastName" in response body is not masked
    And I verify the "address1" in response body is not masked
    And I verify the "zip" in response body is not masked
    And I verify the "city" in response body is not masked
    And I verify the "phone" in response body is not masked
    And I verify the "middleName" in response body is not masked
    And I verify the "identityNumber" in response body is not masked

    #dont setup header here to 0000
  @UAT
  Scenario: Get Player's Account Info v2-opap - OTP Verify
    And I create a Get "specWithResourceValue" header
    And I change url resource of method "GetPlayerInfoEnableOtp" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerInfoEnableOtp" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify the "mobilePhone" in response body is not masked
    And I verify the "dateOfBirth" in response body is not masked
    And I verify the "email" in response body is not masked
    And I verify the "firstName" in response body is not masked
    And I verify the "lastName" in response body is not masked
    And I verify the "address1" in response body is not masked
    And I verify the "zip" in response body is not masked
    And I verify the "city" in response body is not masked
    And I verify the "phone" in response body is not masked
    And I verify the "middleName" in response body is not masked
    And I verify the "identityNumber" in response body is not masked


  @nightlySuite @UAT @Preprod
  Scenario: Put MSISDN Registration Verification - Register new MSISDN with new /msisdn method : OTP NULL
    Given I create a MSISDN RegisterNew PUT payload with calculated MSISDN and OTP null
    When I make a "PUT" call to "MSISDNRegisterNew" to service "PlayerService"
    Then the API call is successful with status code 200


  @nightlySuite @UAT @Preprod
  Scenario Outline: Get User Info - Verify Correct MSISDN Pending Old & New
    Given I create a Get "specWithGameId" header
    When I make a "GET" call to "GetUserInfo" to service "AccessService"
    Then the API call is successful with status code 200
    And the "<property>" in response body has value not null
    And I verify the "mobilePhone" in response body is masked
    And I verify the mobilePhone in response body has the calculated first and "old" last digit
    And I verify the "pendingMsisdnVerification.msisdn" in response body has all digits masked but the first and the last three

    Examples:
      | property                  |
      | pendingMsisdnVerification |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Get BO Pending Verifications - Verify Status/mobile of player
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetBoPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify MSISDN BO Pending Verifications with status "<value>"

    Examples:
      | key    | value   |
      | status | PENDING |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get BO Sms - Verify origin has value player
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetBoSms" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
    And I copy the value of the smsId from the response

    Examples:
      | key      | value    | property | propertyValue | arrayWithIndex |
      | playerId | changeit | origin   | player        | data[0]        |

  @nightlySuite @UAT @Preprod
  Scenario: Get BO Sms Description - Verify smsId/toAddress
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetBoSmsDescription" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the "eventName" in response body is "playerOtpVerification"
    And the "eventOwner" in response body is "player"
    And I verify the id in response body is smsId
    And I verify the "toAddress" in response body is "30" plus mobilePrefix plus randomIntGenerated


  @nightlySuite @UAT @Preprod
  Scenario: Put Verify MSISDN - with new /msisdn : Correct OTP
    Given I create a PUT MSISDN Verify payload with calculated MSISDN and OTP
    And I change url resource of method "MSISDNRegisterVerify" of service "PlayerService" with new playerId
    When I make a "PUT" call to "MSISDNRegisterVerify" to service "PlayerService"
    Then the API call is successful with status code 200


  @nightlySuite @UAT @Preprod
  Scenario Outline: Get User Info - Verify Correct MSISDN : No Pending MSISDN
    Given I create a Get "specWithGameId" header
    When I make a "GET" call to "GetUserInfo" to service "AccessService"
    Then the API call is successful with status code 200
    And the "<property>" in response body does not exist
    And I verify the "mobilePhone" in response body is masked
    And I verify the mobilePhone in response body has the calculated first and "new" last digit

    Examples:
      | property                  |
      | pendingMsisdnVerification |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Get BO Pending Verifications - Verify playerId not found
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetBoPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    And the property "<property>" in response body array with index "<arrayWithIndex>" does not have playerId value

    Examples:
      | keys                    | values         | arrayWithIndex | property |
      | verificationType,status | MSISDN,PENDING | data[0]        | playerId |

  @nightlySuite @UAT @Preprod
  Scenario: Get BO KYC MSISDN Status - Verify status/mobile: AlreadyVerified True
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetBoKycMsisdnStatus" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetBoKycMsisdnStatus" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify KYC MSISDN Status with status "VERIFIED" and alreadyVerified true

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get BO Changes  - Verify changes in updates array
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetBoChangesTab" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetBoChangesTab" to service "PlayerService"
    Then the API call is successful with status code 200
    And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
    And the property "<property2>" in response body array with index "<arrayWithIndex>" has mobilePrefix plus oldRandomIntGenerated
    And the property "<property3>" in response body array with index "<arrayWithIndex>" has mobilePrefix plus randomIntGenerated

    Examples:
      | keys            | values          | arrayWithIndex | property | propertyValue | property2 | property3 |
      | dateFrom,dateTo | datenow,datenow | updates[0]     | field    | mobilePhone   | fromValue | toValue   |


