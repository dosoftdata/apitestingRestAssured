#This feature is to check for security enhancements
@access-service-tbd @LoginSecurity
Feature: Login Security Check


#alt way of login full scenario
#  Scenario Outline: Login - Already Expired User
#    Given I create a POST LoginNew payload with "<username>" "<password>" "<group>" "<channel>"
#    When I make a "POST" call to "LoginNew" to service "AccessService"
#    Then the API call is successful with status code 400
#    And the "errorId" in response body is "<errorId>"
#
#    @nightlySuite @LoginConfiguredDEV
#    Examples:
#      | username            | password     | group | channel | errorId          |
#      | restassured86759524 | zzzzz        | EP    | WEB     | PASSWORD_EXPIRED |
#      | restassured86759524 | Qwerty12345! | EP    | WEB     | PASSWORD_EXPIRED |
#
#    @UAT @LoginConfiguredUAT
#    Examples:
#      | username            | password     | group | channel | errorId          |
#      | restassured92495359 | zzzzz        | EP    | WEB     | PASSWORD_EXPIRED |
#      | restassured92495359 | Qwerty12345! | EP    | WEB     | PASSWORD_EXPIRED |
#
#    @Preprod @LoginConfiguredPreprod
#    Examples:
#      | username            | password     | group | channel | errorId          |
#      | restAssured51209218 | zzzzz        | EP    | WEB     | PASSWORD_EXPIRED |
#      | restAssured51209218 | Qwerty12345! | EP    | WEB     | PASSWORD_EXPIRED |


    ############# 5 FAIL ATTEMPTS NEW USER #############################################
  @nightlySuite @UAT @Preprod
  Scenario: Create OTP Verification
    Given I create a "POST" VerifyOTP payload
    When I make a "POST" call to "VerifyOTP" to service "PlayerService"
    Then the API call is successful with status code 200
    And I copy the value of the uuid from the response

  @nightlySuite @UAT @Preprod
  Scenario: Verify OTP Code
    Given I create a "PUT" VerifyOTP payload
    When I make a "PUT" call to "VerifyOTP" to service "PlayerService"
    Then the API call is successful with status code 204

  @nightlySuite @UAT @Preprod
  Scenario Outline: Register - Copy Player Id
    Given I setup gameId header to "<xGameId>"
    And I create a Register payload with "<username>" "<password>" "<email>" "<identityType>" "<firstName>" "<middleName>" "<lastName>" "<gender>" "<dateOfBirth>" "<country>" "<address1>" "<profession>" "<city>" "<zipCode>" "<bonusCode>" "<secretQuestion>" "<secretAnswer>" "<ibanNumber>" "<permanentResidenceCountry>"
    When I make a "POST" call to "RegisterPlayer" to service "PlayerService"
    Then the API call is successful with status code 200
    And I copy the value of the player id "id" from the response

    Examples:
      | xGameId | username    | password     | email       | identityType | firstName | middleName | lastName | gender | dateOfBirth | country | address1           | profession | city   | zipCode | bonusCode            | secretQuestion     | secretAnswer  | ibanNumber                  | permanentResidenceCountry |
      | JOKER   | restAssured | Qwerty12345! | restAssured | OTHER        | PAM       | LOTTERY    | PLATFORM | M      | 1940-09-29  | GR      | First Address 0100 | Unemployed | Athens | 15125   | THIS_IS_A_BONUS_CODE | What is your name? | restAssuredAI | GR2202655559367039137283047 | GRC                       |


# New Unverified User - 3 Fail Logins - Wrong Token
  #removed in nightly cause some other config there. in preprod and higher envs its valid scenario.
  Scenario Outline: Login - 3 Fail Attempts With New User - Recaptcha - Wrong token
    Given I create a POST LoginNew payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "error_description" in response body is "<errorDescription>"

    @nightlySuite @UAT @Preprod
    Examples:
      | username     | password     | group | channel | statusCode | errorId                 | errorDescription                                                               |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | 403        | NO_PLAYER_LEVEL_BLOCKED | Player Level of user is NO_PLAYER_LEVEL. ([Error Id: NO_PLAYER_LEVEL_BLOCKED]) |
      | newPlayerWeb | zzzzz        | EP    | WEB     | 400        | INVALID_USER_PASSWORD   | Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])                 |
      | newPlayerWeb | zzzzz        | EP    | WEB     | 400        | INVALID_USER_PASSWORD   | Invalid username/password. ([Error Id: INVALID_USER_PASSWORD])                 |

    @UAT @Preprod
    Examples:
      | username     | password | group | channel | statusCode | errorId         | errorDescription                                               |
      | newPlayerWeb | zzzzz    | EP    | WEB     | 403        | INVALID_REQUEST | User performs an invalid request ([Error Id: INVALID_REQUEST]) |

# New Unverified User - 3 Fail Logins - Wrong Token
  Scenario Outline: Login - 3 fail Attempts With New User - Recaptcha - No Token
    Given I create a POST LoginNew payload with no token "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code <statusCode>
    And the "errorId" in response body is "<errorId>"
    And the "error_description" in response body is "<errorDescription>"

    @nightlySuite @UAT @Preprod
    Examples:
      | username     | password     | group | channel | statusCode | errorId                      | errorDescription                                                                                     |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | 403        | INVALID_VERIFICATION_REQUEST | User performs an invalid request by not providing a token ([Error Id: INVALID_VERIFICATION_REQUEST]) |
