@epNepGroups
Feature: EP/NEP Groups

  ############################New Player#########################

#  User is not a member of EP/NEP groups (by default)
  @nightlySuite @UAT @Preprod
  Scenario Outline: Get and Verify Payment Codes
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the values of the Payment Codes

    Examples:
      | keys     | values |
      | category | ALL    |

  @nightlySuite @UAT @Preprod
  Scenario: Deposit via Payment code - Betting wallet - Negative scenario
    Given I login as an Api user
    When I create a Post DepositViaPayment payload for "Betting Wallet" wallet
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

  @nightlySuite @UAT @Preprod
  Scenario: Deposit via Payment code - Lottery wallet - Negative scenario
    Given I create a Post DepositViaPayment payload for "Lottery Wallet" wallet
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"


  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Betting wallet (Sportsbook) - Negative scenario
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | amount |
      | 50     |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Betting wallet (Casino) - Negative scenario
    Given I setup gameId header to "CASINO"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | amount |
      | 50     |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Lottery wallet (Joker) - Negative scenario
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | amount |
      | 50     |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Wallet funds - User cannot play with Lottery account (requireAllow=true)
    Given I setup gameId header to "<xGameId>"
    When I create a PostWalletFunds payload with "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<batchId>"
    And I change url resource of method "PostWalletFunds" of service "WalletService" with new playerId
    And I make a "POST" call to "PostWalletFunds" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | xGameId | accountId | batchId | amount | currency | issued  | productId | type | description | autocapture | status   | captured |
      | JOKER   | AT_MAIN-1 | 1       | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | true        | VERIFIED | false    |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User is blocked for exclusive games
    Given I setup gameId header to "<xGameId>"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    And I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Game currently unavailable for player ([Error Id: PLAYER_CONSENT_REQUIRED])"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | xGameId | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | JOKER   | AT_MAIN-1 | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Wallet funds - User cannot play with Betting account
    Given I setup gameId header to "<xGameId>"
    When I create a PostWalletFunds payload with "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<batchId>"
    And I change url resource of method "PostWalletFunds" of service "WalletService" with new playerId
    And I make a "POST" call to "PostWalletFunds" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | xGameId    | accountId | batchId | amount | currency | issued  | productId  | type | description | autocapture | status | captured |
      | SPORTSBOOK | AT_MAIN-2 | 1       | -2     | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | true        | TEST   | false    |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User is blocked for non-exclusive games
    Given I setup gameId header to "<xGameId>"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    And I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Game currently unavailable for player ([Error Id: PLAYER_CONSENT_REQUIRED])"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | xGameId | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | CASINO  | AT_MAIN-2 | -2     | DEFAULT  | datenow | CASINO    | BUY  | Bet         | true        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |



#  User is a member of EP group only
  @nightlySuite @UAT @Preprod
  Scenario: Get and Verify Access Groups
    Given I login as an Api user
    Given I create a Get "api_mainSpec_mainHost" header
    And I make a "GET" call to "AccessGroups" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response and copy the access group Ids

  @nightlySuite @UAT @Preprod
  Scenario: Add user to EP group
    Given I create an AddUserToEpGroup payload
    And I change url resource of method "AddUserToEpGroup" of service "AccessService" with new "accessGroupIdExclusive"
    When I make a "POST" call to "AddUserToEpGroup" to service "AccessService"
    Then the API call is successful with status code 201
    And I copy and verify the member Id

  @nightlySuite @UAT @Preprod
  Scenario: Get and Verify Role Members
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetRoleMembers" of service "AccessService" with new playerId
    And I make a "GET" call to "GetRoleMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response for Role Members for "Exclusive"

  @nightlySuite @UAT @Preprod
  Scenario: Deposit via Payment code - Lottery wallet - Negative scenario
    Given I create a Post DepositViaPayment payload for "Lottery Wallet" wallet
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Mandatory limits have not been set for the player"
    And the "errorId" in response body is "MANDATORY_LIMITS_NOT_SET"

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get limits via limit-service
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerLimits" of service "LimitService" with new playerId
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 0

    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |

  Scenario Outline: Set mandatory limits for JOKER/PROTO/LOTTO/SUPER3/KINO/EUROJACKPOT and Verify JOKER mandatory limits
    Given I setup gameId header to "JOKER"
    And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
    And I change url resource of method "PlayerLimitsV2" of service "LimitService" with new playerId
    When I make a "POST" call to "PlayerLimitsV2" to service "LimitService"
    Then the API call is successful with status code 200

    @nightlySuite
    Examples:
      | limitTypes                                 | limitPeriods                                    | limitAmounts                             | gameIds                                     |
      | TIME,DEPOSIT,LOSS,LOSS,LOSS,LOSS,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY,DAILY,DAILY,DAILY,DAILY | 86400,3000,3000,3000,3000,3000,3000,3000 | ,,JOKER,PROTO,KINO,LOTTO,SUPER3,EUROJACKPOT |

    @UAT @Preprod
    Examples:
      | limitTypes                            | limitPeriods                              | limitAmounts                        | gameIds                         |
      | TIME,DEPOSIT,LOSS,LOSS,LOSS,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY,DAILY,DAILY,DAILY | 86400,3000,3000,3000,3000,3000,3000 | ,,JOKER,PROTO,KINO,LOTTO,SUPER3 |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Verify JOKER mandatory limits via limit-service
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    And I verify limits for "DAILY" limit period, duration or amount 86400 and limitType "TIME" and gameId "" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 3000 and limitType "LOSS" and gameId "JOKER" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 3000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-1" with pending limits false

    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Payment code - Lottery wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_EXCLUSIVE"
    And the "amount.amount" in response body is "10.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Payment code - Betting wallet (Negative)
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Lottery wallet (Joker)
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 50     |


  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId

    @nightlySuite
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |

    @UAT
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_ucnmwjkspFMybrr42iBaYsZilhuUcxBs |

    @Preprod
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5199992312641465 | TEST PROD  | 010 | 12        | 2030     | EUR      | pk_U0jMXzvD8cOv0kx0qDHghRVZ56TCELA7 |


  @nightlySuite @UAT @Preprod
  Scenario: Commit Card Deposit To Tora
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card

  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Betting wallet (Sportsbook) - Negative scenario
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"


    Examples:
      | amount |
      | 50     |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Betting wallet (Casino) - Negative scenario
    Given I setup gameId header to "CASINO"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | amount |
      | 50     |

  # IN UAT 3D Secured is ON so commit doesn't pass so balance is the same as before.
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"


    @nightlySuite @Preprod
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 60.0    | 60.0        | 60.0                   | 0.0             | 0.0                 |

    @UAT
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 10.0    | 10.0        | 10.0                   | 0.0             | 0.0                 |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User can play for exclusive games
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 58.0    | 58.0        | 58.0                   | 0.0             | 0.0                 |

    @UAT
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 8.0     | 8.0         | 8.0                    | 0.0             | 0.0                 |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User can play for exclusive games
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 56.0    | 56.0        | 56.0                   | 0.0             | 0.0                 |

    @UAT
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 6.0     | 6.0         | 6.0                    | 0.0             | 0.0                 |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User cannot play for non-exclusive games (SPORTSBOOK)
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Game currently unavailable for player ([Error Id: PLAYER_CONSENT_REQUIRED])"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User is blocked for non-exclusive games (CASINO)
    Given I setup gameId header to "CASINO"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Game currently unavailable for player ([Error Id: PLAYER_CONSENT_REQUIRED])"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | CASINO    | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 56.0    | 56.0        | 56.0                   | 0.0             | 0.0                 |

    @UAT
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 6.0     | 6.0         | 6.0                    | 0.0             | 0.0                 |



#  User is a member of NEP group only
  @nightlySuite @UAT @Preprod
  Scenario: Get Player Level
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerLevel" of service "PlayerService" with new playerId
    And I make a "GET" call to "GetPlayerLevel" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "accessGroups[0]" in response body is "TEMPORARY_ACCOUNT"

  @nightlySuite @UAT @Preprod
  Scenario: Remove the user from EP group && Add user to NEP group
    When I create payload with EpGroup "false" and NepGroup "true"
    And I change url resource of method "AddAndRemoveUsersFromGroups" of service "PlayerService" with new playerId
    And I make a "PUT" call to "AddAndRemoveUsersFromGroups" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "isExclusiveGamesGroupActive" in response body is "false"
    And the "isNonExclusiveGamesGroupActive" in response body is "true"

  @nightlySuite @UAT @Preprod
  Scenario: Get and Verify Role Members
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetRoleMembers" of service "AccessService" with new playerId
    And I make a "GET" call to "GetRoleMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response for Role Members for "NonExclusive"

  @nightlySuite @UAT @Preprod
  Scenario: Deposit via Payment code - Lottery wallet - Negative scenario
    Given I create a Post DepositViaPayment payload for "Lottery Wallet" wallet
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

  @nightlySuite @UAT @Preprod
  Scenario: Deposit via payment code - Mandatory limits not set in Betting wallet
    Given I login as an Api user
    When I create a Post DepositViaPayment payload for "Betting Wallet" wallet
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Mandatory limits have not been set for the player"
    And the "errorId" in response body is "MANDATORY_LIMITS_NOT_SET"

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get limits via limit-service
    Given I setup gameId header to "JOKER"
    When I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerLimits" of service "LimitService" with new playerId
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3

    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Set mandatory limits for SPORTSBOOK/CASINO
    Given I setup gameId header to "SPORTSBOOK"
    And I create SetMandatoryLimits payload with "<limitTypes>" "<limitPeriods>" "<limitAmounts>" "<gameIds>"
    And I change url resource of method "PlayerLimitsV2" of service "LimitService" with new playerId
    When I make a "POST" call to "PlayerLimitsV2" to service "LimitService"
    Then the API call is successful with status code 200


    Examples:
      | limitTypes             | limitPeriods            | limitAmounts         | gameIds             |
      | TIME,DEPOSIT,LOSS,LOSS | DAILY,DAILY,DAILY,DAILY | 86400,3000,3000,3000 | ,,SPORTSBOOK,CASINO |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Verify SPORTSBOOK mandatory limits via limit-service
    Given I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    And I verify limits for "DAILY" limit period, duration or amount 86400 and limitType "TIME" and gameId "" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 3000 and limitType "LOSS" and gameId "SPORTSBOOK" for account "" with pending limits false
    And I verify limits for "DAILY" limit period, duration or amount 3000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-2" with pending limits false

    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Payment code - Betting wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
    And the "amount.amount" in response body is "10.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId


    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Lottery wallet (Joker)
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Player consent is required"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | amount |
      | 50     |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Betting wallet (SPORTSBOOK)
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 50     |


  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId

    @nightlySuite
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |

    @UAT
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_ucnmwjkspFMybrr42iBaYsZilhuUcxBs |

    @Preprod
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5199992312641465 | TEST PROD  | 010 | 12        | 2030     | EUR      | pk_U0jMXzvD8cOv0kx0qDHghRVZ56TCELA7 |


  @nightlySuite @UAT @Preprod
  Scenario: Commit Card Deposit To Tora
    Given I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Betting wallet (CASINO)
    Given I setup gameId header to "CASINO"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 50     |


  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId

    @nightlySuite
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |

    @UAT
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_ucnmwjkspFMybrr42iBaYsZilhuUcxBs |

    @Preprod
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5199992312641465 | TEST PROD  | 010 | 12        | 2030     | EUR      | pk_U0jMXzvD8cOv0kx0qDHghRVZ56TCELA7 |


  @nightlySuite @UAT @Preprod
  Scenario: Commit Card Deposit To Tora
    Given I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  Scenario Outline: Get and Verify Wallets Balance
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 110.0    | 110.0        | 110.0                   | 0.0              | 0.0                  | 56.0     | 56.0         | 56.0                    | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 10.0     | 10.0         | 10.0                    | 0.0              | 0.0                  | 6.0      | 6.0          | 6.0                     | 0.0              | 0.0                  |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User can play for non-exclusive games (SPORTSBOOK)
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 108.0    | 108.0        | 108.0                   | 0.0              | 0.0                  | 56.0     | 56.0         | 56.0                    | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 8.0      | 8.0          | 8.0                     | 0.0              | 0.0                  | 6.0      | 6.0          | 6.0                     | 0.0              | 0.0                  |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User can play for non-exclusive games (CASINO)
    Given I setup gameId header to "CASINO"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | CASINO    | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"


    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 106.0    | 106.0        | 106.0                   | 0.0              | 0.0                  | 56.0     | 56.0         | 56.0                    | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 6.0      | 6.0          | 6.0                     | 0.0              | 0.0                  | 6.0      | 6.0          | 6.0                     | 0.0              | 0.0                  |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User cannot play for exclusive games (JOKER)
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 451
    And the "description" in response body is "Game currently unavailable for player ([Error Id: PLAYER_CONSENT_REQUIRED])"
    And the "errorId" in response body is "PLAYER_CONSENT_REQUIRED"

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"


    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 106.0    | 106.0        | 106.0                   | 0.0              | 0.0                  | 56.0     | 56.0         | 56.0                    | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 6.0      | 6.0          | 6.0                     | 0.0              | 0.0                  | 6.0      | 6.0          | 6.0                     | 0.0              | 0.0                  |


    #  User is a member of both EP and NEP groups
  @nightlySuite @UAT @Preprod
  Scenario: Get Player Level
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerLevel" of service "PlayerService" with new playerId
    And I make a "GET" call to "GetPlayerLevel" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "accessGroups[0]" in response body is "TEMPORARY_ACCOUNT"
    And the "accessGroups[1]" in response body is "NON_EXCLUSIVE_GAMES_ONLY"


  @nightlySuite @UAT @Preprod
  Scenario: Add user to EP and NEP groups
    When I create payload with EpGroup "true" and NepGroup "true"
    And I change url resource of method "AddAndRemoveUsersFromGroups" of service "PlayerService" with new playerId
    And I make a "PUT" call to "AddAndRemoveUsersFromGroups" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "isExclusiveGamesGroupActive" in response body is "true"
    And the "isNonExclusiveGamesGroupActive" in response body is "true"

  @nightlySuite @UAT @Preprod
  Scenario: Get and Verify Role Members
    Given I create a Get "api_mainSpec_mainHost" header
    And I change url resource of method "GetRoleMembers" of service "AccessService" with new playerId
    And I make a "GET" call to "GetRoleMembers" to service "AccessService"
    Then the API call is successful with status code 200
    And I verify the response for Role Members for "ExclusiveAndNonExclusive"

  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Payment code - Lottery wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_EXCLUSIVE"
    And the "amount.amount" in response body is "10.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"


    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 106.0    | 106.0        | 106.0                   | 0.0              | 0.0                  | 66.0     | 66.0         | 66.0                    | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 6.0      | 6.0          | 6.0                     | 0.0              | 0.0                  | 16.0     | 16.0         | 16.0                    | 0.0              | 0.0                  |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Payment code - Betting wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
    And the "amount.amount" in response body is "10.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 10     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"


    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 116.0    | 116.0        | 116.0                   | 0.0              | 0.0                  | 66.0     | 66.0         | 66.0                    | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 16.0     | 16.0         | 16.0                    | 0.0              | 0.0                  | 16.0     | 16.0         | 16.0                    | 0.0              | 0.0                  |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Lottery wallet (JOKER)
    Given I login as a "newPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 50     |

  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId

    @nightlySuite
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |

    @UAT
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_ucnmwjkspFMybrr42iBaYsZilhuUcxBs |

    @Preprod
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5199992312641465 | TEST PROD  | 010 | 12        | 2030     | EUR      | pk_U0jMXzvD8cOv0kx0qDHghRVZ56TCELA7 |


  @nightlySuite @UAT @Preprod
  Scenario: Commit Card Deposit To Tora
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"


    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 116.0    | 116.0        | 116.0                   | 0.0              | 0.0                  | 116.0    | 116.0        | 116.0                   | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 16.0     | 16.0         | 16.0                    | 0.0              | 0.0                  | 16.0     | 16.0         | 16.0                    | 0.0              | 0.0                  |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Lottery wallet (SPORTSBOOK)
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 10     |

  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId

    @nightlySuite
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 1000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |

    @UAT
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 1000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_ucnmwjkspFMybrr42iBaYsZilhuUcxBs |

    @Preprod
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 1000   | 5199992312641465 | TEST PROD  | 010 | 12        | 2030     | EUR      | pk_U0jMXzvD8cOv0kx0qDHghRVZ56TCELA7 |


  @nightlySuite @UAT @Preprod
  Scenario: Commit Card Deposit To Tora
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 126.0    | 126.0        | 126.0                   | 0.0              | 0.0                  | 116.0    | 116.0        | 116.0                   | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 16.0     | 16.0         | 16.0                    | 0.0              | 0.0                  | 16.0     | 16.0         | 16.0                    | 0.0              | 0.0                  |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Lottery wallet (CASINO)
    Given I setup gameId header to "CASINO"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 10     |

  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId

    @nightlySuite
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 1000   | 5413330002001031 | TEST PROD  | 956 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |

    @UAT
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 1000   | 5413330002001031 | TEST PROD  | 956 | 12        | 2030     | EUR      | pk_ucnmwjkspFMybrr42iBaYsZilhuUcxBs |

    @Preprod
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 1000   | 5199992312641465 | TEST PROD  | 010 | 12        | 2030     | EUR      | pk_U0jMXzvD8cOv0kx0qDHghRVZ56TCELA7 |


  @nightlySuite @UAT @Preprod
  Scenario: Commit Card Deposit To Tora
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 136.0    | 136.0        | 136.0                   | 0.0              | 0.0                  | 116.0    | 116.0        | 116.0                   | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 16.0     | 16.0         | 16.0                    | 0.0              | 0.0                  | 16.0     | 16.0         | 16.0                    | 0.0              | 0.0                  |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User can play for non-exclusive games (SPORTSBOOK)
    Given I setup gameId header to "SPORTSBOOK"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 134.0    | 134.0        | 134.0                   | 0.0              | 0.0                  | 116.0    | 116.0        | 116.0                   | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 14.0     | 14.0         | 14.0                    | 0.0              | 0.0                  | 16.0     | 16.0         | 16.0                    | 0.0              | 0.0                  |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User can play for non-exclusive games (CASINO)
    Given I setup gameId header to "CASINO"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -2     | DEFAULT  | datenow | CASINO    | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 132.0    | 132.0        | 132.0                   | 0.0              | 0.0                  | 116.0    | 116.0        | 116.0                   | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 12.0     | 12.0         | 12.0                    | 0.0              | 0.0                  | 16.0     | 16.0         | 16.0                    | 0.0              | 0.0                  |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - User can play for non-exclusive games (JOKER)
    Given I setup gameId header to "JOKER"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId | type | description | autocapture | status   | captured | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | AT_MAIN-1 | -2     | DEFAULT  | datenow | JOKER     | BUY  | Bet         | TRUE        | VERIFIED | false    | 0.0       | ""     | 0.0         |                      |


  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 132.0    | 132.0        | 132.0                   | 0.0              | 0.0                  | 114.0    | 114.0        | 114.0                   | 0.0              | 0.0                  |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 12.0     | 12.0         | 12.0                    | 0.0              | 0.0                  | 14.0     | 14.0         | 14.0                    | 0.0              | 0.0                  |



    #  Revert wallets to 0 balance
  @nightlySuite @UAT @Preprod
  Scenario Outline: Manual adjustment for Withdrawal in Lottery wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "" for "Lottery wallet"
    When I change url resource of method "ManualAdjustLotteryWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustLotteryWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the "productId" in response body is "KINO"
    And the "transactionType" in response body is "TT_MANUAL_ADJUST_NON_WITHDRAWABLE"
    And the "transactionSubType" in response body is "MCAM"
    And the "currency" in response body is "EUR"
    And the "description" in response body is "Closing account manual adjustment"
    And the "operation" in response body is "WITHDRAWAL"
    And I verify the the amount for "exclWalletUnspentDeposits"

    Examples:
      | transactionType                   | transactionSubType | productId | operation  | amount |
      | TT_MANUAL_ADJUST_NON_WITHDRAWABLE | MCAM               | KINO      | WITHDRAWAL | 0      |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Manual adjustment for Withdrawal in Betting wallet (non-withdrawable)
    Given I create a Post ManualAdjustment payload with "<transactionType>" "<transactionSubType>" "<productId>" "<operation>" "<amount>" "<transactionBetweenWallets>" for "Betting wallet"
    When I change url resource of method "ManualAdjustBettingWallet" of service "WalletService" with new playerId
    And I make a "POST" call to "ManualAdjustBettingWallet" to service "WalletService"
    Then the API call is successful with status code 200
    And the property "productId" in response body array with index "[0]" has value "CASINO"
    And the property "transactionType" in response body array with index "[0]" has value "TT_MANUAL_ADJUST_NON_WITHDRAWABLE"
    And the property "transactionSubType" in response body array with index "[0]" has value "MTCN"
    And the property "currency" in response body array with index "[0]" has value "EUR"
    And the property "description" in response body array with index "[0]" has value "Casino Tax Withhold U/B"
    And the property "operation" in response body array with index "[0]" has value "WITHDRAWAL"
    And I verify the the amount for "nonExclWalletUnspentDeposits"
    And the number of results in a nameless array of objects is 1

    Examples:
      | transactionType                   | transactionSubType | productId | operation  | amount | transactionBetweenWallets |
      | TT_MANUAL_ADJUST_NON_WITHDRAWABLE | MTCN               | CASINO    | WITHDRAWAL | 0      | false                     |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  |




############################Configured Player#########################
  @epNepGroups
  Scenario Outline: Get and Verify Payment Codes
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with configured playerId "904649748"
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the values of the Payment Codes

    Examples:
      | keys     | values |
      | category | ALL    |

  Scenario: Deposit via Payment code - Betting wallet
    Given I login as an Api user
    When I create a Post DepositViaPayment payload for configured player with playerId "904649748" and "Betting Wallet" wallet
    And I make a "POST" call to "PostPayment" to service "WalletService"
    Then the API call is successful with status code 200

  Scenario: Deposit via Payment code - Lottery wallet
    Given I create a Post DepositViaPayment payload for configured player with playerId "904649748" and "Lottery Wallet" wallet
    When I make a "POST" call to "PostPayment" to service "WalletService"
    Then the API call is successful with status code 200

  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200

    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 1000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |



