Feature: Bonus EM Casino

  Scenario Outline: Check Player Bonus - EM
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And I copy the value of the bonusPrizeId from the response if exists

  #ASSIGNED in Integration, Preprod, UAT
    @nightlySuite @Preprod @UAT
    Examples:
      | keys          | values      |
      | gameId,status | EM,ASSIGNED |

  @nightlySuite @UAT @Preprod @skipIfAssignedBonusExists
  Scenario Outline: Get Active Bonuses EM - Copy the First BonusActiveId
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200
    And I copy the value of the first bonusActiveId of providerId "<providerId>" and rewardType "<rewardType>" from the response

    Examples:
      | keys                       | values        | providerId | rewardType        |
      | status,pageNumber,pageSize | ACTIVE,1,1000 | EM         | EXTERNAL_CAMPAIGN |


#  This is called only when bonusActiveId not found above.
    # tag skipIfBonusActiveIdExists is necessary here

  @nightlySuite @skipIfBonusActiveIdExists @UAT @Preprod @ConfiguredBonusEM
  Scenario Outline: Add Bonus - EM
    And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200

    Examples:
      | rewardType        | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
      | EXTERNAL_CAMPAIGN | SEGMENT         | EXT_EVENT         | EXT_FIXED        | 2028-12-23T00:00:00 | 1           | instants | EM      | false     | -1               | 30           | 0      |          |         |
  #   | PRE_WAGER         | SEGMENT         | NONE              | FIXED            | 2025-128-23T00:00:00 | 1           | instants | EM      | false     | 5                | 30           | 0      | 1        | OTHER   |

  @nightlySuite @UAT @Preprod @skipIfBonusActiveIdExists @ConfiguredBonusEM
  Scenario Outline: Get Active Bonuses - Copy the First BonusActiveId
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200
    And I copy the value of the first bonusActiveId of providerId "<providerId>" and rewardType "<rewardType>" from the response

    Examples:
      | keys                       | values        | providerId | rewardType        |
      | status,pageNumber,pageSize | ACTIVE,1,1000 | EM         | EXTERNAL_CAMPAIGN |


  @nightlySuite @UAT @Preprod @skipIfAssignedBonusExists
  Scenario Outline: Assign Bonus To User - EM
    Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
    And I change url resource of method "AssignBonus" of service "BonusService" with new playerId
    And I change url resource of method "AssignBonus" of service "BonusService" with new bonusActiveId
    When I make a "POST" call to "AssignBonus" to service "BonusService"
    Then the API call is successful with status code 200
    And the "amount" in response body is "<amount>"
    And the "providerId" in response body is "<providerId>"
    And the "gameId" in response body is "<gameId>"
    And I verify the 1-playerId is the field "userId" in the response body
    And I copy the value of the bonusPrizeId from the field "bonusPrizeId"


    Examples:
      | amount | gameId | providerId |
      | 30     | CASINO | EM         |

  @nightlySuite
  Scenario Outline: Update Prize Status EM - Active
    Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
    When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And I verify the 1-playerId is the field "userId" in the response body
    And I verify the bonusPrizeId is the field "bonusPrizeId" in the response body

    Examples:
      | providerId | gameId | status | amount | closeAccount |
      | EM         | CASINO | ACTIVE | 30.0   | false        |


  Scenario Outline: Get web v1 balance header JOKER
    And I setup gameId header to "JOKER"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV1" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV1" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV1 for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 1019.0  | 1019.0      | 949.0                  | 0.0             | 70.0                |

    @UAT
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 999.0   | 999.0       | 899.0                  | 0.0             | 100.0               |


  @nightlySuite  @skipPreprodUATForNow
  Scenario Outline: Get web v1 balance header CASINO
    Given I setup gameId header to "CASINO"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV1" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV1" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV1 for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetBalanceV1 for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Bonus Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 30.0     | 30.0         | 0.0                     | 0.0              | 30.0                 |


  @nightlySuite  @skipPreprodUATForNow
  Scenario Outline: Get web v1 balance header SPORTSBOOK
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV1" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV1" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV1 for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetBalanceV1 for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Bonus Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 30.0     | 30.0         | 0.0                     | 0.0              | 30.0                 |


  Scenario Outline: Get web v2 balance header JOKER
    Given I setup gameId header to "JOKER"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV2" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV2" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV2 for primary <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet" and secondary <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetBalanceV2 for "secondary" <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Betting Bonus Wallet"

    @nightlySuite
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 30.0     | 30.0         | 0.0                     | 0.0              | 30.0                 |

    @skipPreprodUATForNow
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 30.0     | 30.0         | 0.0                     | 0.0              | 30.0                 |


  Scenario Outline: Get web v2 balance header CASINO
    Given I setup gameId header to "CASINO"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV2" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV2" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV2 for primary <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet" and secondary <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"
    And I verify the response for GetBalanceV2 for "primary" <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Betting Bonus Wallet"

    @nightlySuite
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 | 30.0     | 30.0         | 0.0                     | 0.0              | 30.0                 |

    @skipPreprodUATForNow
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                | 30.0     | 30.0         | 0.0                     | 0.0              | 30.0                 |


  Scenario Outline: Get web v2 balance header SPORTSBOOK
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV2" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV2" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV2 for primary <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet" and secondary <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"
    And I verify the response for GetBalanceV2 for "primary" <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Betting Bonus Wallet"


    @nightlySuite
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 | 30.0     | 30.0         | 0.0                     | 0.0              | 30.0                 |

    @skipPreprodUATForNow
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                | 30.0     | 30.0         | 0.0                     | 0.0              | 30.0                 |



    ############################ Configured Player ##########################################################

  @ConfiguredEmBonus
  Scenario Outline: Check Player Active Bonus - EM - Configured
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with configured playerId "979813083"
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And I copy the value of the bonusPrizeId from the response if exists

    Examples:
      | keys          | values      |
      | gameId,status | EM,ASSIGNED |

  @ConfiguredEmBonus
  Scenario Outline: Update Prize Status EM - Active - Configured
    Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with configured playerId "979813083"
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
    When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
  #  And I verify the 1-playerId is the field "userId" in the response body
    And I verify the bonusPrizeId is the field "bonusPrizeId" in the response body


    Examples:
      | providerId | gameId | status | amount | closeAccount |
      | EM         | CASINO | ACTIVE | 0.0    | false        |

  @ConfiguredEMBonus
  Scenario Outline: Adjust Bonus Prize for User
    Given I login as a "configuredPlayerCc" user
    Given I create a PUT AdjustBonusPrizes payload with <amount>
    And I change url resource of method "AdjustBonusPrizes" of service "BonusService" with configured playerId "895383449"
    #change this line with bonus Prize Id
    And I change url resource of method "AdjustBonusPrizes" of service "BonusService" with new bonusPrizeId
    When I make a "PUT" call to "AdjustBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200

    Examples:
      | amount |
      | 30     |