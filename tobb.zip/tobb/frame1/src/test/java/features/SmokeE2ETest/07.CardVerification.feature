@cardVerification
Feature: Card Verification

  ############################New Player#####################################


  @nightlySuite @Preprod
  Scenario Outline: Get Player Levels
    Given I create a Get "specWithGameId" header
    And I change url resource of method "GetPlayerLevels" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetPlayerLevels" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "<key>" in response body is "<value>"

    Examples:
      | key         | value             |
      | playerLevel | TEMPORARY_ACCOUNT |


  @nightlySuite @Preprod
  Scenario Outline: Upload card Documents (Front)
    When I create a UploadDocumentsWeb payload with "<fileName>" "<type>"
    And I change url resource of method "UploadDocumentsWeb" of service "PlayerService" with new playerId
    When I make a "POST" call to "UploadDocumentsWeb" to service "PlayerService"
    Then the API call is successful with status code 200
    Examples:
      | fileName    | type       |
      | IDfront.JPG | CARD_FRONT |


  Scenario Outline: Get BO Pending Verifications of Player - Verify Card values
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Card Pending Verification with status "<status>" "<cardExpirationYear>" "<cardName>" "<cardNumber>" "<cardHolderName>" "<cardExpirationMonth>"

    @nightlySuite
    Examples:
      | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
      | WAITING_ADMIN_APPROVAL | 2030               | master   | 541333******1031 | TEST PROD      | 12                  |

    @Preprod
    Examples:
      | status                 | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
      | WAITING_ADMIN_APPROVAL | 2030               | master   | 519999******1465 | TEST PROD      | 12                  |


  @nightlySuite @Preprod
  Scenario Outline: Get Uploaded documents - Verify Card Documents (CARD_FRONT)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUploadedDocuments" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetUploadedDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Uploaded Documents with "<types>" "<fileName>" "<fileType>"

    Examples:
      | types      | fileName    | fileType   |
      | CARD_FRONT | IDfront.JPG | image/jpeg |

########### subType : This variable is not send in request but to specify the variable in which the verification is done
########### subType values : FRONT,BACK (for CARD type) - OTHER,UTILITY (for IDENTITY type)
  @nightlySuite @Preprod
  Scenario Outline: Verify Card Documents - CARD FRONT
    When I create a VerifyDocuments payload with "<verificationType>" "<statusDescription>" and subcategory "<subType>"
    And I change url resource of method "VerifyDocuments" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerifyDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "verificationType" in response body is "<verificationType>"
    And the "documentType" in response body is "<documentTypeResponse>"
    And the "statusDescription" in response body is "<statusDescription>"
    And the "status" in response body is "<statusValue>"


    Examples:
      | verificationType | statusDescription                  | subType | statusValue | documentTypeResponse |
      | CARD             | Approve uploaded document for Card | FRONT   | APPROVED    | CARD_FRONT           |


  @nightlySuite @Preprod
  Scenario Outline: Upload card Documents (Back)
    When I create a UploadDocumentsWeb payload with "<fileName>" "<type>"
    And I change url resource of method "UploadDocumentsWeb" of service "PlayerService" with new playerId
    When I make a "POST" call to "UploadDocumentsWeb" to service "PlayerService"
    Then the API call is successful with status code 200
    Examples:
      | fileName   | type      |
      | IDback.JPG | CARD_BACK |


  @nightlySuite @Preprod
  Scenario Outline: Get Uploaded documents - Verify Card Documents (CARD_BACK)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUploadedDocuments" of service "PlayerService" with new playerId
    When I make a "GET" call to "GetUploadedDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Uploaded Documents with "<types>" "<fileName>" "<fileType>"

    Examples:
      | types     | fileName   | fileType   |
      | CARD_BACK | IDback.JPG | image/jpeg |


  @nightlySuite @Preprod
  Scenario Outline: Verify Card Documents - CARD BACK
    When I create a VerifyDocuments payload with "<verificationType>" "<statusDescription>" and subcategory "<subType>"
    And I change url resource of method "VerifyDocuments" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerifyDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "verificationType" in response body is "<verificationType>"
    And the "documentType" in response body is "<documentTypeResponse>"
    And the "statusDescription" in response body is "<statusDescription>"
    And the "status" in response body is "<statusValue>"


    Examples:
      | verificationType | statusDescription                  | subType | statusValue | documentTypeResponse |
      | CARD             | Approve uploaded document for Card | BACK    | APPROVED    | CARD_BACK            |


  @nightlySuite @Preprod
  Scenario Outline: Confirm Verification of Player's Card - Verify Type/Status and save cardNumber
    When I create a VerificationConfirm payload with "<verificationType>"
    And I change url resource of method "VerificationConfirm" of service "PlayerService" with new playerId
    When I make a "POST" call to "VerificationConfirm" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "verificationType" in response body is "<verificationType>"
    And the "status" in response body is "<statusValue>"
    And I copy the value of the fingerprint from the response
    And I copy the value of the cardNumber from the response

    Examples:
      | verificationType | statusValue |
      | CARD             | VERIFIED    |


    ##################### Configured Player ###################################


  @ConfiguredCardVerification @noDependency @uploadConfigured
  Scenario Outline: Upload card Documents (Front) - Configured User
    Given I login as a "configuredPlayerWeb" user
    And I change url resource of method "UploadDocumentsWeb" of service "PlayerService" with configured playerId "636403758"
    When I create a UploadDocumentsWeb payload with "<fileName>" "<type>"
    When I make a "POST" call to "UploadDocumentsWeb" to service "PlayerService"
    Then the API call is successful with status code 200
    Examples:
      | fileName    | type       |
      | IDfront.JPG | CARD_FRONT |


  @ConfiguredCardVerification @noDependency
  Scenario Outline: Get BO Pending Verifications of Player - Verify Card values - Configured User
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetBoPlayerPendingVerifications" of service "PlayerService" with configured playerId "918760699"
    When I make a "GET" call to "GetBoPlayerPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Card Pending Verification with status "<status>" "<cardExpirationYear>" "<cardName>" "<cardNumber>" "<cardHolderName>" "<cardExpirationMonth>"

    Examples:
      | status  | cardExpirationYear | cardName | cardNumber       | cardHolderName | cardExpirationMonth |
      | PENDING | 2025               | master   | 541333******1031 | TEST PROD      | 06                  |

# Change playerId with configured player Id (playerId= 904649748) in last assertion and check
  @ConfiguredCardVerification @noDependency
  Scenario Outline: Get Uploaded documents - Configured User
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetUploadedDocuments" of service "PlayerService" with configured playerId "904649748"
    When I make a "GET" call to "GetUploadedDocuments" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Uploaded Documents with "<types>" "<fileName>" "<fileType>"

    Examples:
      | types                         | fileName  | fileType   |
      | OTHER,UTILITY_BILL,CARD_FRONT | image.JPG | image/jpeg |