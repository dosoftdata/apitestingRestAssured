Feature: Access all tabs of player in BO

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get - Player overview
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetPlayerOverview" to service "PlayerService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 0

    Examples:
      | keys                         | values    |
      | pagenumber,pagesize,filterBy | 1,200,all |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get - BO Pending Verifications
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetBoPendingVerifications" to service "PlayerService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 0

    Examples:
      | key                                     | value                                   |
      | verificationType,status,status,pageSize | IBAN,WAITING_ADMIN_APPROVAL,PENDING,100 |

  @nightlySuite
  Scenario Outline: Get - Account closure
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetAccountClosure" to service "PlayerService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 0

    Examples:
      | key      | value |
      | pageSize | 20    |

  @skipIfNotAzure
  Scenario Outline: Get - Account closure
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetAccountClosure" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify that the "data" array is empty or null

    Examples:
      | key      | value |
      | pageSize | 20    |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get - Manual adjustments
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    And I change url resource of method "GetManualAdjustments" of service "WalletService" with new playerId
    When I make a "GET" call to "GetManualAdjustments" to service "WalletService"
    Then the API call is successful with status code 200
    And the nameless array response should contain 2 elements with values "CASINO" and "SPORTSBOOK"

    Examples:
      | key                          | value     |
      | pageNumber,pageSize,filterBy | 1,100,all |

  @nightlySuite @UAT @Preprod
  Scenario: Get - Feature management
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "EnabledFeatureFlags" to service "AccessService"
    Then the API call is successful with status code 200

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get - IBAN management
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetIbanManagement" to service "PlayerService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 0

    Examples:
      | key                                     | value                                   |
      | verificationType,status,status,pageSize | IBAN,WAITING_ADMIN_APPROVAL,PENDING,100 |

  @nightlySuite
  Scenario Outline: Get - Inactivity management
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetInactivityManagement" to service "PlayerService"
    Then the API call is successful with status code 200
    And I check that the size of data.length is above 0

    Examples:
      | key                     | value            |
      | accountActions,pageSize | EP_INACTIVITY,50 |

  @skipIfNotAzure
  Scenario Outline: Get - Inactivity management
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetInactivityManagement" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify that the "data" array is empty or null

    Examples:
      | key                     | value            |
      | accountActions,pageSize | EP_INACTIVITY,50 |
