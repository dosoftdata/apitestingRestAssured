Feature: MFA Login

  @nightlySuite @UAT @Preprod
  Scenario: Enable MFA Login
    Given I login as a "newPlayerWeb" user
    And I create a Get "specWithGameId" header
    And I change url resource of method "EnableMFALogin" of service "PlayerService" with new playerId
    When I make a "PUT" call to "EnableMFALogin" to service "PlayerService"
    Then the API call is successful with status code 204

  @nightlySuite @UAT @Preprod
  Scenario Outline: Login - MFA Required
    Given I create a POST LoginNew payload with "<username>" "<password>" "<group>" "<channel>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "<errorId>"
    And the "error" in response body is "<errorId>"
    And the "betware_error_id" in response body is "<errorId>"
    And the "description" in response body is "<description>"
    And the "error_description" in response body is "<description>"
    And the "otpChannel" in response body is "SMS"


    Examples:
      | username     | password     | group | channel | errorId      | description                                                                        |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | MFA_REQUIRED | The user must pass through multi factor authentication. ([Error Id: MFA_REQUIRED]) |


  @UAT
  Scenario Outline: Get BO Sms - Save Otp
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetBoSms" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I copy the value of otpCode from messageText from the response

    Examples:
      | key      | value    |
      | playerId | changeit |


  Scenario Outline: Login - Success With OtpCode
    Given I create a POST LoginNew payload with otpCode "<username>" "<password>" "<group>" "<channel>" "<otpCode>"
    When I make a "POST" call to "LoginNew" to service "AccessService"
    Then the API call is successful with status code 200
    And I save the access token from LoginNew

    @nightlySuite @Preprod
    Examples:
      | username     | password     | group | channel | otpCode |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | 0000    |

    @UAT
    Examples:
      | username     | password     | group | channel | otpCode    |
      | newPlayerWeb | Qwerty12345! | EP    | WEB     | newOtpCode |


  @nightlySuite @UAT @Preprod
  Scenario: Disable MFA Login - First Try
    Given I create a Get "specWithGameId" header
    And I change url resource of method "DisableMFALogin" of service "PlayerService" with new playerId
    When I make a "PUT" call to "DisableMFALogin" to service "PlayerService"
    Then the API call is successful with status code 417
    And I copy the value of the resourceValue from the response
    And the "id" in response body has value not null
    And the "resource" in response body has value not null
    And the "resourceValue" in response body has value not null
    And the "channel" in response body has value not null
    And the "expirationTime" in response body has value not null
    And the "otpGenerationTime" in response body has value not null
    And the "resource " in response body is "updateLoginMFA"
    And the "channel" in response body is "SMS"

  @UAT
  Scenario Outline: Get BO Sms - Save Otp
    Given I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetBoSms" to service "CommunicationService"
    Then the API call is successful with status code 200
    And I copy the value of otpCode from messageText from the response

    Examples:
      | key      | value    |
      | playerId | changeit |


  @nightlySuite @Preprod
  Scenario: Disable MFA Login - Success
    Given I setup X-OTP header to "0000"
    And I create a Get "specWithResourceValue" header
    And I change url resource of method "DisableMFALogin" of service "PlayerService" with new playerId
    When I make a "PUT" call to "DisableMFALogin" to service "PlayerService"
    Then the API call is successful with status code 204


#don't send otpCode to 0000 but the correct value is passed from the flow.
  @UAT
  Scenario: Disable MFA Login - Success
    Given I create a Get "specWithResourceValue" header
    And I change url resource of method "DisableMFALogin" of service "PlayerService" with new playerId
    When I make a "PUT" call to "DisableMFALogin" to service "PlayerService"
    Then the API call is successful with status code 204
