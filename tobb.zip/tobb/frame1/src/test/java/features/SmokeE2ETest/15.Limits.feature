Feature: Limits

  @limits @nightlySuite @UAT @Preprod
  Scenario Outline: Add and verify Joker deposit limits
    Given I setup gameId header to "JOKER"
    And I login as a "newPlayerWeb" user
    When I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "PlayerLimits" of service "LimitService" with new playerId
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 3
    When I create a Post PlayerLimits payload for "DAILY" limit period, duration or amount 3000 and limitType "DEPOSIT"
    And I make a "POST" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    When I create a Post PlayerLimits payload for "WEEKLY" limit period, duration or amount 10000 and limitType "DEPOSIT"
    And I make a "POST" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    When I create a Post PlayerLimits payload for "MONTHLY" limit period, duration or amount 15000 and limitType "DEPOSIT"
    And I make a "POST" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    When I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then I verify limits for "DAILY" limit period, duration or amount 3000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-1" with pending limits false
    And I verify limits for "WEEKLY" limit period, duration or amount 10000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-1" with pending limits false
    And I verify limits for "MONTHLY" limit period, duration or amount 15000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-1" with pending limits false

    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |

  @limits @nightlySuite @UAT @Preprod
  Scenario Outline: Add and verify Loss Limits
    Given I create PlayerLimits payload with "<limitTypes>", "<limitPeriods>", "<limitAmounts>"
    When I make a "POST" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    When I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then I verify limits for "DAILY" limit period, duration or amount 3 and limitType "LOSS" and gameId "JOKER" for account "" with pending limits false
    And I verify limits for "WEEKLY" limit period, duration or amount 10 and limitType "LOSS" and gameId "JOKER" for account "" with pending limits false
    And I verify limits for "MONTHLY" limit period, duration or amount 15 and limitType "LOSS" and gameId "JOKER" for account "" with pending limits false

    Examples:
      | limitTypes     | limitPeriods         | limitAmounts | keys                  | values |
      | LOSS,LOSS,LOSS | DAILY,WEEKLY,MONTHLY | 3,10,15      | includePendingAmounts | true   |

  @limits @nightlySuite @UAT @Preprod
  Scenario Outline: Add and verify Buy Limits
    Given I create PlayerLimits payload with "<limitTypes>", "<limitPeriods>", "<limitAmounts>"
    When I make a "POST" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    When I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then I verify limits for "DAILY" limit period, duration or amount 3 and limitType "BUY" and gameId "JOKER" for account "" with pending limits false
    And I verify limits for "WEEKLY" limit period, duration or amount 10 and limitType "BUY" and gameId "JOKER" for account "" with pending limits false
    And I verify limits for "MONTHLY" limit period, duration or amount 15 and limitType "BUY" and gameId "JOKER" for account "" with pending limits false

    Examples:
      | limitTypes  | limitPeriods         | limitAmounts | keys                  | values |
      | BUY,BUY,BUY | DAILY,WEEKLY,MONTHLY | 3,10,15      | includePendingAmounts | true   |


  @limits @nightlySuite @UAT @Preprod
  Scenario Outline: Add and verify Time Limits
    Given I create a Post PlayerLimits payload for "DAILY" limit period, duration or amount 86400 and limitType "TIME"
    When I make a "POST" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    When I create a Post PlayerLimits payload for "WEEKLY" limit period, duration or amount 600000 and limitType "TIME"
    And I make a "POST" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    When I create a Post PlayerLimits payload for "MONTHLY" limit period, duration or amount 1500000 and limitType "TIME"
    And I make a "POST" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    When I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then I verify limits for "DAILY" limit period, duration or amount 86400 and limitType "TIME" and gameId "" for account "" with pending limits false
    And I verify limits for "WEEKLY" limit period, duration or amount 600000 and limitType "TIME" and gameId "" for account "" with pending limits false
    And I verify limits for "MONTHLY" limit period, duration or amount 1500000 and limitType "TIME" and gameId "" for account "" with pending limits false

    Examples:
      | keys                  | values |
      | includePendingAmounts | true   |


#################### Attempts to Deposit And Play ################################################################

  @limits @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit Payment Code - Exclusive - Limits Exceeded -  Status Code 409
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 409
    And the "errorId" in response body is "LIMIT_EXCEEDED"
    And the property "quantityType" in response body array with index "exceededLimits[0]" has value "MAX_AMOUNT"
    And the property "limitType" in response body array with index "exceededLimits[0]" has value "DEPOSIT"
    And the property "amount" in response body array with index "exceededLimits[0].quantity" has value "4999.0"
    And the property "currency" in response body array with index "exceededLimits[0].quantity" has value "EUR"
    And the property "amount" in response body array with index "exceededLimits[0].balance" has value "0.0"
    And the property "currency" in response body array with index "exceededLimits[0].balance" has value "EUR"

    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 8000   | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  @limits @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Card - Lottery wallet (Joker)
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 8000   |

 #Scenario Outline: Set Master Card Details
 #  Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
 #  When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
 #  Then the API call is successful with status code 200
 #  And I copy the value of the deposit tokenId

 #  @nightlySuite @limitsDEV
 #  Examples:
 #     | amount | cardNumber | holderName | cvv | exp_month | exp_year | currency | primaryKey |
  #    | 8000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2025     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |

 #  @UAT @limitsUAT
 #  Examples:
 #     | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
 #     | 8000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2025     | EUR      | pk_ucnmwjkspFMybrr42iBaYsZilhuUcxBs |

 #  @Preprod @limitsPreprod
 #  Examples:
 #     | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
 #     | 8000   | 5199992312641465 | TEST PROD  | 010 | 12        | 2025     | EUR      | pk_U0jMXzvD8cOv0kx0qDHghRVZ56TCELA7 |


  @limits @nightlySuite @UAT @Preprod
  Scenario: Commit Card Deposit To Tora
    # IN PROGRESS MAYBE BECOMES GENERAL IN RETRY MECHANISM
    Given I override retry values field "statusDescription" and value "LIMIT_EXCEEDED" for CommitDepositToTora
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card


  @limits @nightlySuite @UAT @Preprod
  Scenario: VerifyDepositToTora
    Given I create a VerifyDepositToTora payload
    And I change url resource of method "VerifyDepositToTora" of service "WalletService" with new via card deposit paymentId
    When I make a "PUT" call to "VerifyDepositToTora" to service "WalletService"
    Then the API call is successful with status code 400
    And the "errorId" in response body is "PAYMENT_INVALID_STATUS"
    And the "description" in response body is "The requested payment operation is not permitted since the payment status is not appropriate for the requested operation ([Error Id: PAYMENT_INVALID_STATUS])"


  @limits @nightlySuite @UAT @Preprod
  Scenario Outline: Create a buy transaction (BUY)  - Limits are exceeded in Lottery wallet
    Given I create a CreateTransaction payload with "<issued>" "<type>" "<amount>" "<productId>"
    And I change url resource of method "CreateTransaction" of service "WalletService" with new playerId
    When I make a "POST" call to "CreateTransaction" to service "WalletService"
    Then the API call is successful with status code 409
    And the "errorId" in response body is "LIMIT_EXCEEDED"
    And the "description" in response body is "Limit exceeded"
    And the property "limitType" in response body array with index "exceededLimits[0]" has value "BUY"
    And the property "quantityType" in response body array with index "exceededLimits[0]" has value "MAX_AMOUNT"
    And the property "period" in response body array with index "exceededLimits[0]" has value "DAILY"
    And the property "amount" in response body array with index "exceededLimits[0].quantity" has value "3.0"
    And the property "currency" in response body array with index "exceededLimits[0].quantity" has value "EUR"

    Examples:
      | issued  | type | amount | productId |
      | datenow | BET  | -30    | JOKER     |


############ Monetary Limits ####################################################

  @limits @nightlySuite @UAT @Preprod
  Scenario Outline: Update and verify Deposit Limits - Check Pending Limits
    Given I create PlayerLimits payload with "<limitTypes>", "<limitPeriods>", "<limitAmounts>"
    When I make a "POST" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    When I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then I verify limits for "DAILY" limit period, duration or amount 3000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-1" with pending limits true
    And I verify limits for "WEEKLY" limit period, duration or amount 10000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-1" with pending limits true
    And I verify limits for "MONTHLY" limit period, duration or amount 15000 and limitType "DEPOSIT" and gameId "" for account "AT_MAIN-1" with pending limits true

    Examples:
      | limitTypes              | limitPeriods         | limitAmounts     | keys                  | values |
      | DEPOSIT,DEPOSIT,DEPOSIT | DAILY,WEEKLY,MONTHLY | 4000,11000,16000 | includePendingAmounts | true   |

  @limits @nightlySuite @UAT @Preprod
  Scenario Outline: Update and verify Buy Limits - Check Pending Limits
    Given I create PlayerLimits payload with "<limitTypes>", "<limitPeriods>", "<limitAmounts>"
    When I make a "POST" call to "PlayerLimits" to service "LimitService"
    Then the API call is successful with status code 200
    When I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I make a "GET" call to "PlayerLimits" to service "LimitService"
    Then I verify limits for "DAILY" limit period, duration or amount 3 and limitType "BUY" and gameId "JOKER" for account "" with pending limits true
    And I verify limits for "WEEKLY" limit period, duration or amount 10 and limitType "BUY" and gameId "JOKER" for account "" with pending limits true
    And I verify limits for "MONTHLY" limit period, duration or amount 15 and limitType "BUY" and gameId "JOKER" for account "" with pending limits true

    Examples:
      | limitTypes  | limitPeriods         | limitAmounts     | keys                  | values |
      | BUY,BUY,BUY | DAILY,WEEKLY,MONTHLY | 4000,11000,16000 | includePendingAmounts | true   |

    ########################## Configured Player ######################################################


  @ConfiguredLimits
  Scenario Outline: Create a buy transaction (BUY)  - Limits are exceeded in Lottery wallet - Configured Player
    Given I login as an Api user
    Given I create a CreateTransaction payload with "<issued>" "<type>" "<amount>" "<productId>"
    #Change playerId here
    And I change url resource of method "CreateTransaction" of service "WalletService" with configured playerId "512987609"
    When I make a "POST" call to "CreateTransaction" to service "WalletService"
    Then the API call is successful with status code 409
    And the "errorId" in response body is "LIMIT_EXCEEDED"
    And the "description" in response body is "Limit exceeded"
    And the property "limitType" in response body array with index "exceededLimits[0]" has value "BUY"
    And the property "quantityType" in response body array with index "exceededLimits[0]" has value "MAX_AMOUNT"
    And the property "period" in response body array with index "exceededLimits[0]" has value "DAILY"
    And the property "amount" in response body array with index "exceededLimits[0].quantity" has value "3.0"
    And the property "currency" in response body array with index "exceededLimits[0].quantity" has value "EUR"

    Examples:
      | issued  | type | amount | productId |
      | datenow | BET  | -30    | JOKER     |
