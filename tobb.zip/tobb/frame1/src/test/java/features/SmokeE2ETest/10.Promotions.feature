Feature: Promotions

  ############################New Player#####################################

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get Universal Promotions
    Given I create a Get "mainSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetUniversalPromotions" to service "PromotionService"
    Then the API call is successful with status code 200
    And I verify the properties "<responseProperties>" have values "<responseValues>" in each index in the nameless array

    Examples:
      | keys                                | values                    | responseProperties   | responseValues        |
      | type,status,onlyWeb,onlyNonConsumed | BUYXGETY,Active,true,true | type,status,consumed | BUYXGETY,Active,false |

  @nightlySuite @UAT @Preprod
  Scenario: Get Players Promotion
    Given I create a Get "mainSpec" header
    And I change url resource of method "GetPlayersPromotions" of service "PromotionService" with new playerId
    When I make a "GET" call to "GetPlayersPromotions" to service "PromotionService"
    Then the API call is successful with status code 200

  @nightlySuite @UAT @Preprod
  Scenario: Get Players Active Promotion
    Given I create a Get "mainSpec" header
    And I change url resource of method "GetActivePlayersPromotions" of service "PromotionService" with new playerId
    When I make a "GET" call to "GetActivePlayersPromotions" to service "PromotionService"
    Then the API call is successful with status code 200

  @nightlySuite @UAT @Preprod
  Scenario Outline: Check Bet Eligibility
    Given I create a Post CheckBetEligibility payload with <gameId> <boards> <consecutiveDraws> <simpleBet> <cost>
    And I change url resource of method "CheckBetEligibility" of service "PromotionService" with new playerId
    When I make a "POST" call to "CheckBetEligibility" to service "PromotionService"
    Then the API call is successful with status code 200

    Examples:
      | gameId | boards | consecutiveDraws | simpleBet | cost |
      | 5104   | 2      | 1                | true      | 5    |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get Players Promotion - Active - Redeemed - Expired
    Given I create a Get "mainSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPlayersPromotions" of service "PromotionService" with new playerId
    When I make a "GET" call to "GetPlayersPromotions" to service "PromotionService"
    Then the API call is successful with status code 200

    Examples:
      | keys               | values                   |
      | status,outcomeType | ACTIVE,FREEBET           |
      | status,outcomeType | REDEEMED,REBATE_DISCOUNT |
      | status,outcomeType | EXPIRED,FREEBET          |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Check User Eligibility - Get With different params
    Given I create a Get "mainSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetEligiblePromotions" of service "PromotionService" with new playerId
    When I make a "GET" call to "GetEligiblePromotions" to service "PromotionService"
    Then the API call is successful with status code 200

    Examples:
      | keys                           | values                |
      | consumed,campaignType          | false,Universal       |
      | consumed,campaignType          | true,Universal        |
      | consumed,campaignType,language | false,Universal,en-GB |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Check if user is PROMO eligible
    Given I setup gameId header to "<xGameId>"
    And I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPromoEligibility" of service "PromotionService" with new playerId
    When I make a "GET" call to "GetPromoEligibility" to service "PromotionService"
    Then the API call is successful with status code 200
    And the "promoEligible" in response body is "true"

    Examples:
      | xGameId | keys       | values |
      | JOKER   | channelIds | WEB    |

  @nightlySuite @UAT @Preprod
  Scenario:  Get Player Promotions BackOffice
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerPromotionsCC" of service "PromotionService" with new playerId
    When I make a "GET" call to "GetPlayerPromotionsCC" to service "PromotionService"
    Then the API call is successful with status code 200


  @nightlySuite @UAT @Preprod
  Scenario:  Get Promotions History BackOffice
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPromotionsHistoryCC" of service "PromotionService" with new playerId
    When I make a "GET" call to "GetPromotionsHistoryCC" to service "PromotionService"
    Then the API call is successful with status code 200


          ##################### Configured Player ###################################
  @ConfiguredPromotions
  Scenario Outline: Get Universal Promotions - Configured Player
    Given I login as a "configuredPlayerWeb" user
    Given I create a Get "mainSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "GetUniversalPromotions" to service "PromotionService"
    Then the API call is successful with status code 200
    And the number of results in a nameless array of objects is 8
    And I verify the properties "<responseProperties>" have values "<responseValues>" in each index in the nameless array

    Examples:
      | keys                                | values                    | responseProperties   | responseValues        |
      | type,status,onlyWeb,onlyNonConsumed | BUYXGETY,Active,true,true | type,status,consumed | BUYXGETY,Active,false |

  @ConfiguredPromotions
  Scenario: Get Players Promotion - Configured Player
    Given I login as a "configuredPlayerWeb" user
    Given I create a Get "mainSpec" header
    And I change url resource of method "GetPlayersPromotions" of service "PromotionService" with configured playerId "904649748"
    When I make a "GET" call to "GetPlayersPromotions" to service "PromotionService"
    Then the API call is successful with status code 200

  @ConfiguredPromotions
  Scenario: Get Players Active Promotion - Configured Player
    Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    And I change url resource of method "GetActivePlayersPromotions" of service "PromotionService" with configured playerId "904649748"
    When I make a "GET" call to "GetActivePlayersPromotions" to service "PromotionService"
    Then the API call is successful with status code 200

  @ConfiguredPromotions
  Scenario Outline: Check Bet Eligibility - no promo available - board number does not match - Configured Player
    Given I login as a "configuredPlayerWeb" user
    And I create a Post CheckBetEligibility payload with <gameId> <boards> <consecutiveDraws> <simpleBet> <cost>
    And I change url resource of method "CheckBetEligibility" of service "PromotionService" with configured playerId "904649748"
    When I make a "POST" call to "CheckBetEligibility" to service "PromotionService"
    Then the API call is successful with status code 200

    Examples:
      | gameId | boards | consecutiveDraws | simpleBet | cost |
      | 5104   | 2      | 1                | true      | 5    |

  @ConfiguredPromotions
  Scenario Outline: Get Players Promotion - Active - Redeemed - Expired - Configured Player
    Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPlayersPromotions" of service "PromotionService" with configured playerId "904649748"
    When I make a "GET" call to "GetPlayersPromotions" to service "PromotionService"
    Then the API call is successful with status code 200

    Examples:
      | keys               | values                   |
      | status,outcomeType | ACTIVE,FREEBET           |
      | status,outcomeType | REDEEMED,REBATE_DISCOUNT |
      | status,outcomeType | EXPIRED,FREEBET          |


  @ConfiguredPromotions
  Scenario Outline: Check User Eligibility - Get With different params - Configured Player
    Given I login as a "configuredPlayerWeb" user
    Given I create a Get "mainSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetEligiblePromotions" of service "PromotionService" with configured playerId "904649748"
    When I make a "GET" call to "GetEligiblePromotions" to service "PromotionService"
    Then the API call is successful with status code 200

    Examples:
      | keys                           | values                |
      | consumed,campaignType          | false,Universal       |
      | consumed,campaignType          | true,Universal        |
      | consumed,campaignType,language | false,Universal,en-GB |

  @ConfiguredPromotions
  Scenario Outline: Check if user is PROMO eligible - Configured User
    Given I login as a "configuredPlayerWeb" user
    And I setup gameId header to "<xGameId>"
    And I create a Get "specWithGameId" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPromoEligibility" of service "PromotionService" with configured playerId "904649748"
    When I make a "GET" call to "GetPromoEligibility" to service "PromotionService"
    Then the API call is successful with status code 200
    And the "promoEligible" in response body is "true"
    Examples:
      | keys       | values | xGameId |
      | channelIds | WEB    | JOKER   |

  @ConfiguredPromotions
  Scenario:  Get Player Promotions BackOffice  - Configured User
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPlayerPromotionsCC" of service "PromotionService" with configured playerId "904649748"
    When I make a "GET" call to "GetPlayerPromotionsCC" to service "PromotionService"
    Then the API call is successful with status code 200

  @ConfiguredPromotions
  Scenario:  Get Promotions History BackOffice  - Configured User
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetPromotionsHistoryCC" of service "PromotionService" with configured playerId "904649748"
    When I make a "GET" call to "GetPromotionsHistoryCC" to service "PromotionService"
    Then the API call is successful with status code 200


  #################################################################################################################################