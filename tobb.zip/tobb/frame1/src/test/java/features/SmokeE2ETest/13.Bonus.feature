Feature: Bonus

  @nightlySuite @UAT @Preprod
  Scenario Outline: Check Player Active Bonus - PBS - Should exist from previous run not by default
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And I copy the value of the bonusPrizeId from the response if exists

    Examples:
      | keys          | values     |
      | gameId,status | PBS,ACTIVE |


    #Update PBS to cancel conditionally
    # tag skipIfAssignedBonusDoesNotExist is necessary here
  @nightlySuite @skipIfAssignedBonusDoesNotExist @UAT @Preprod
  Scenario Outline: Update Prize Status PBS - Cancelled
    Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
    When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And I verify the player id "userId" in the response body
    And I verify the bonusPrizeId is the field "bonusPrizeId" in the response body
    And the "status" in response body is "<status>"


    Examples:
      | providerId | gameId     | status    | amount | closeAccount |
      | PBS        | SPORTSBOOK | CANCELLED | 0.0    | false        |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Check Player Assigned Bonus - OB
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with new playerId
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And I copy the value of the bonusPrizeId from the response if exists


    Examples:
      | keys          | values      |
      | gameId,status | OB,ASSIGNED |


    # This endpoint does not work for OB in the moment
    # Tags will be uncommented and checked in the future for OB.

 ## @nightlySuite
  Scenario Outline: Update Prize Status OB - Cancelled
    Given I create a PUT UpdateBonusPrizes payload with "<providerId>" "<gameId>" "<status>" <amount> <closeAccount>
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new playerId
    And I change url resource of method "UpdateBonusPrizes" of service "BonusService" with new bonusPrizeId
    When I make a "PUT" call to "UpdateBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And I verify the player id "userId" in the response body
    And I verify the bonusPrizeId is the field "bonusPrizeId" in the response body

    Examples:
      | providerId | gameId     | status    | amount | closeAccount |
      | OB         | SPORTSBOOK | CANCELLED | 0.0    | false        |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Get Active Bonuses - Copy the First BonusActiveId
    Given I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200
    And I copy the value of the first bonusActiveId of providerId "<providerId>" and rewardType "<rewardType>" from the response

    Examples:
      | keys                       | values        | providerId | rewardType        |
      | status,pageNumber,pageSize | ACTIVE,1,1000 | PBS        | EXTERNAL_CAMPAIGN |


#  This is called only when bonusActiveId not found above.
    # tag skipIfBonusActiveIdExists is necessary here

  @nightlySuite @skipIfBonusActiveIdExists @UAT @Preprod
  Scenario Outline: Add Bonus - PBS
    And I create a POST AddBonus payload with "<rewardType>" "<bonusAssignment>" "<activationTrigger>" "<rewardAmountType>" "<bonusValidTo>" "<minimumBets>" "<gameType>" "<gameIds>" "<singleUse>" "<rewardExpiryDays>" "<rewardAmount>" "<status>" "<rollOver>" "<program>"
    When I make a "POST" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200

    Examples:
      | rewardType        | bonusAssignment | activationTrigger | rewardAmountType | bonusValidTo        | minimumBets | gameType | gameIds | singleUse | rewardExpiryDays | rewardAmount | status | rollOver | program |
      | EXTERNAL_CAMPAIGN | SEGMENT         | EXT_EVENT         | EXT_FIXED        | 2025-12-23T00:00:00 | 1           | sports   | PBS     | false     | -1               | 0            | 0      |          |         |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Assign Bonus To User - PBS
    Given I create a POST AssignBonus payload with "<amount>" "<gameId>" "<providerId>"
    And I change url resource of method "AssignBonus" of service "BonusService" with new playerId
    And I change url resource of method "AssignBonus" of service "BonusService" with new bonusActiveId
    When I make a "POST" call to "AssignBonus" to service "BonusService"
    Then the API call is successful with status code 200
    And the "amount" in response body is "<amount>"
    And the "providerId" in response body is "<providerId>"
    And the "gameId" in response body is "<gameId>"
    And I verify the 1-playerId is the field "userId" in the response body
    And I copy the value of the bonusPrizeId from the field "bonusPrizeId"


    Examples:
      | amount | gameId     | providerId |
      | 50     | SPORTSBOOK | PBS        |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Check status of the assigned bonusPrizeId
    Given I create a Get "api_mainSpec_mainHost" header with query params "<key>" "<value>"
    And I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with new playerId
    And I change url resource of method "GetBonusPrizesWithId" of service "BonusService" with new bonusPrizeId
    When I make a "GET" call to "GetBonusPrizesWithId" to service "BonusService"
    Then the API call is successful with status code 200
    And the "status" in response body is "<status>"
    And I verify the bonusActiveId is the field "bonusId" in the response body


    Examples:
      | key    | value | status |
      | gameId | PBS   | ACTIVE |


    # valid wallets in GetWalletBalance : Bonus Wallet, Betting Wallet, Lottery Wallet.

  Scenario Outline: Get and Verify Wallets Balance
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |

      # valid wallets in GetBalanceV1 :  Betting Wallet,Lottery Wallet,Betting Bonus Wallet,Lottery Bonus Wallet

  Scenario Outline: Get web v1 balance header JOKER
    Given I setup gameId header to "JOKER"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV1" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV1" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV1 for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 1019    | 1019        | 949                    | 0.0             | 70.0                |

    @UAT
    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 999     | 999         | 899                    | 0.0             | 100.0               |

      # valid wallets in GetBalanceV1 :  Betting Wallet,Lottery Wallet,Betting Bonus Wallet,Lottery Bonus Wallet
  @nightlySuite @UAT @Preprod
  Scenario Outline: Get web v1 balance header SPORTSBOOK
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV1" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV1" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV1 for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetBalanceV1 for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Bonus Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 |


 # valid wallets in GetBalanceV1 :  Betting Wallet,Lottery Wallet,Betting Bonus Wallet,Lottery Bonus Wallet
  @nightlySuite @UAT @Preprod
  Scenario Outline: Get web v1 balance header CASINO
    Given I setup gameId header to "CASINO"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV1" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV1" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV1 for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetBalanceV1 for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Bonus Wallet"


    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 |

 # valid wallets in GetBalanceV2 :  Betting Wallet,Lottery Wallet,Betting Bonus Wallet,Lottery Bonus Wallet

  Scenario Outline: Get web v2 balance header JOKER
    Given I setup gameId header to "JOKER"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV2" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV2" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV2 for primary <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet" and secondary <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetBalanceV2 for "secondary" <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Betting Bonus Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 |


  Scenario Outline: Get web v2 balance header CASINO
    Given I setup gameId header to "CASINO"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV2" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV2" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV2 for primary <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet" and secondary <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"
    And I verify the response for GetBalanceV2 for "primary" <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Betting Bonus Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 |

  Scenario Outline: Get web v2 balance header SPORTSBOOK
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV2" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV2" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV2 for primary <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet" and secondary <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"
    And I verify the response for GetBalanceV2 for "primary" <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Betting Bonus Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Bet Reserve Successful from both wallets
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"
    And the property "description" in response body array with index "[0]" has value "<description>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<amount>"
    And the property "postBalance" in response body array with index "[0]" has value "<postBalanceMain2>"
    And the property "type" in response body array with index "[1]" has value "<type>"
    And the property "status" in response body array with index "[1]" has value "<status>"
    And the property "productId" in response body array with index "[1]" has value "<productId>"
    And the property "amount" in response body array with index "[1]" has value "<bonusAmount>"
    And the property "autocapture" in response body array with index "[1]" has value "<autocapture>"
    And the property "captured" in response body array with index "[1]" has value "<captured>"
    And the property "postBalance" in response body array with index "[1]" has value "<bonusPostBalance>"

    Examples:
      | accountId | amount  | currency | issued                  | productId  | type | description | autocapture | status   | captured | gameId | bonusAmount | postBalanceMain2 | bonusPostBalance | taxAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -1380.0 | DEFAULT  | 2019-7-8T13:30:26+03:00 | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | PBS    | -10.0       | 1380.0           | 50.0             | 0.0       |                      |


  @nightlySuite @UAT @Preprod
  Scenario Outline: CaptureBet -  Bet Reserve Capture for Both Wallets
    Given I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"
    And the property "description" in response body array with index "[0]" has value "<description>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<amountResponse>"
    And the property "postBalance" in response body array with index "[0]" has value "<postBalanceMain2>"
    And the property "type" in response body array with index "[1]" has value "<type>"
    And the property "status" in response body array with index "[1]" has value "<status>"
    And the property "productId" in response body array with index "[1]" has value "<productId>"
    And the property "amount" in response body array with index "[1]" has value "<bonusAmount>"
    And the property "autocapture" in response body array with index "[1]" has value "<autocapture>"
    And the property "captured" in response body array with index "[1]" has value "<captured>"
    And the property "postBalance" in response body array with index "[1]" has value "<bonusPostBalance>"


    Examples:
      | accountId | amount | amountResponse | productId  | type | description | autocapture | status   | captured | bonusAmount | postBalanceMain2 | bonusPostBalance |
      | AT_MAIN-2 | -1390  | -1380.0        | SPORTSBOOK | BUY  | Bet         | true        | VERIFIED | true     | -10.0       | 0.0              | 40.0             |


  Scenario Outline: Get wallet balance after 1st reserve from both wallets
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 40.0     | 40.0         | 0.0                     | 0.0              | 40.0                 | 0        | 0            | 0                       | 0                | 0                    | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 40.0     | 40.0         | 0.0                     | 0.0              | 40.0                 | 0        | 0            | 0                       | 0                | 0                    | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Bet Cancel Successful to both wallets
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "description" in response body array with index "[0]" has value "<description>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
    And the property "postBalance" in response body array with index "[0]" has value "<bonusPostBalance>"
    And the property "type" in response body array with index "[1]" has value "<type>"
    And the property "status" in response body array with index "[1]" has value "<status>"
    And the property "productId" in response body array with index "[1]" has value "<productId>"
    And the property "accountId" in response body array with index "[1]" has value "<accountId>"
    And the property "description" in response body array with index "[1]" has value "<description>"
    And the property "autocapture" in response body array with index "[1]" has value "<autocapture>"
    And the property "captured" in response body array with index "[1]" has value "<captured>"
    And the property "amount" in response body array with index "[1]" has value "<amount>"
    And the property "postBalance" in response body array with index "[1]" has value "<amount>"


    Examples:
      | accountId | amount | currency | issued                  | productId  | type   | description | autocapture | status   | captured | gameId | bonusAmount | bonusPostBalance | taxAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | 1380.0 | DEFAULT  | 2019-7-8T13:30:26+03:00 | SPORTSBOOK | CANCEL | Bet         | true        | VERIFIED | true     | PBS    | 10.0        | 50.0             | 0.0       |                      |


  Scenario Outline: Get wallet balance after 1st cancellation
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 | 1380.0   | 1380.0       | 0.0                     | 0.0              | 1380.0               | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 50.0     | 50.0         | 0.0                     | 0.0              | 50.0                 | 1380.0   | 1380.0       | 0.0                     | 0.0              | 1380.0               | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Bet Adjust successful both wallets
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "description" in response body array with index "[0]" has value "<description>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
    And the property "postBalance" in response body array with index "[0]" has value "<bonusPostBalance>"
    And the property "type" in response body array with index "[1]" has value "<type>"
    And the property "status" in response body array with index "[1]" has value "<status>"
    And the property "productId" in response body array with index "[1]" has value "<productId>"
    And the property "accountId" in response body array with index "[1]" has value "<accountId>"
    And the property "description" in response body array with index "[1]" has value "<description>"
    And the property "autocapture" in response body array with index "[1]" has value "<autocapture>"
    And the property "captured" in response body array with index "[1]" has value "<captured>"
    And the property "amount" in response body array with index "[1]" has value "<amount>"
    And the property "postBalance" in response body array with index "[1]" has value "<postBalanceMain2>"

    Examples:
      | accountId | amount  | currency | issued                  | productId  | type   | description | autocapture | status   | captured | gameId | bonusAmount | bonusPostBalance | postBalanceMain2 | taxAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -1380.0 | DEFAULT  | 2019-7-8T13:30:26+03:00 | SPORTSBOOK | ADJUST | Bet         | true        | VERIFIED | true     | PBS    | -10.0       | 40.0             | 0.0              | 0.0       |                      |

  Scenario Outline: Get wallet balance after 1st bet ADJUST
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 40.0     | 40.0         | 0.0                     | 0.0              | 40.0                 | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 40.0     | 40.0         | 0.0                     | 0.0              | 40.0                 | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Bet Prize successful to both wallets
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
    And the property "postBalance" in response body array with index "[0]" has value "<bonusPostBalance>"
    And the property "type" in response body array with index "[1]" has value "<type>"
    And the property "status" in response body array with index "[1]" has value "<status>"
    And the property "productId" in response body array with index "[1]" has value "<productId>"
    And the property "accountId" in response body array with index "[1]" has value "AT_MAIN-2"
    And the property "description" in response body array with index "[1]" has value "<description>"
    And the property "autocapture" in response body array with index "[1]" has value "<autocapture>"
    And the property "captured" in response body array with index "[1]" has value "<captured>"
    And the property "amount" in response body array with index "[1]" has value "<amount>"
    And the property "postBalance" in response body array with index "[1]" has value "<amount>"

    Examples:
      | accountId | amount | currency | issued                  | productId  | type  | description | autocapture | status   | captured | gameId | bonusAmount | taxAmount | bonusPostBalance | metadataBonusPrizeId |
      | null      | 1500.0 | DEFAULT  | 2019-7-8T13:30:26+03:00 | SPORTSBOOK | PRIZE | Prize       | true        | VERIFIED | true     | PBS    | 100.0       | 10.0      | 140.0            |                      |

  Scenario Outline: Get wallet balance after 1st bet PRIZE
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 140.0    | 140.0        | 0.0                     | 0.0              | 140.0                | 1510.0   | 1510.0       | 0.0                     | 0.0              | 1510.0               | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 140.0    | 140.0        | 0.0                     | 0.0              | 140.0                | 1510.0   | 1510.0       | 0.0                     | 0.0              | 1510.0               | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Prize Rollback successful both wallets
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
    And the property "postBalance" in response body array with index "[0]" has value "<bonusPostBalance>"
    And the property "type" in response body array with index "[1]" has value "<type>"
    And the property "status" in response body array with index "[1]" has value "<status>"
    And the property "productId" in response body array with index "[1]" has value "<productId>"
    And the property "accountId" in response body array with index "[1]" has value "AT_MAIN-2"
    And the property "description" in response body array with index "[1]" has value "<description>"
    And the property "autocapture" in response body array with index "[1]" has value "<autocapture>"
    And the property "captured" in response body array with index "[1]" has value "<captured>"
    And the property "amount" in response body array with index "[1]" has value "<amount>"
    And the property "postBalance" in response body array with index "[1]" has value "<postBalanceMain2>"

    Examples:
      | accountId | amount  | currency | issued                  | productId  | type           | description    | autocapture | status   | captured | gameId | bonusAmount | taxAmount | postBalanceMain2 | bonusPostBalance | metadataBonusPrizeId |
      | null      | -1500.0 | EUR      | 2019-07-30T05:43:01.409 | SPORTSBOOK | PRIZE_ROLLBACK | PRIZE_ROLLBACK | true        | VERIFIED | true     | PBS    | -100.0      | 10.0      | 10.0             | 40.0             |                      |


  Scenario Outline: Get wallet balance after 1st prize ROLLBACK
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 40.0     | 40.0         | 0.0                     | 0.0              | 40.0                 | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 40.0     | 40.0         | 0.0                     | 0.0              | 40.0                 | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Prize Reserve Successful only from Bonus wallet
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
    And the property "postBalance" in response body array with index "[0]" has value "<bonusPostBalance>"


    Examples:
      | accountId | amount | currency | issued                    | productId  | type | description | autocapture | status   | captured | gameId | bonusAmount | bonusPostBalance | taxAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | 0.00   | EUR      | 2019-07-30T13:30:26+03:00 | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | PBS    | -40.0       | 40.0             | 0.0       |                      |


  @nightlySuite @UAT @Preprod
  Scenario Outline: CaptureBet -  Bet Reserve Capture Only Bonus Wallet
    Given I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
    And the property "postBalance" in response body array with index "[0]" has value "<bonusPostBalance>"


    Examples:
      | amount | productId  | type | autocapture | status   | captured | bonusAmount | bonusPostBalance |
      | -40    | SPORTSBOOK | BUY  | true        | VERIFIED | true     | -40.0       | 0.0              |


  Scenario Outline: Get wallet balance after reserve from Bonus Wallet
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Bet Cancel Successful to Bonus Wallet
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "description" in response body array with index "[0]" has value "<description>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
    And the property "postBalance" in response body array with index "[0]" has value "<bonusAmount>"
    Examples:
      | accountId | amount | currency | issued                  | productId  | type   | description | autocapture | status   | captured | gameId | bonusAmount | taxAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | 0.00   | DEFAULT  | 2019-7-8T13:30:26+03:00 | SPORTSBOOK | CANCEL | Bet         | true        | VERIFIED | true     | PBS    | 40.0        | 0.0       |                      |

  Scenario Outline: Get wallet balance after 2nd Cancellation
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"


    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 40.0     | 40.0         | 0.0                     | 0.0              | 40.0                 | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 40.0     | 40.0         | 0.0                     | 0.0              | 40.0                 | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Bet ADJUST successful bonus wallet
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "description" in response body array with index "[0]" has value "<description>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
    And the property "postBalance" in response body array with index "[0]" has value "<bonusPostBalance>"
    Examples:
      | accountId | amount | currency | issued                  | productId  | type   | description | autocapture | status   | captured | gameId | bonusAmount | bonusPostBalance | taxAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | 0.0    | DEFAULT  | 2019-7-8T13:30:26+03:00 | SPORTSBOOK | ADJUST | Bet         | true        | VERIFIED | true     | PBS    | -40.0       | 0.0              | 0.0       |                      |

  Scenario Outline: Get wallet balance after 2nd bet ADJUST
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Bet PRIZE successful bonus wallet
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
    And the property "postBalance" in response body array with index "[0]" has value "<bonusPostBalance>"

    Examples:
      | accountId | amount | currency | issued                  | productId  | type  | description | autocapture | status   | captured | gameId | bonusAmount | taxAmount | bonusPostBalance | metadataBonusPrizeId |
      | AT_MAIN-2 | 0.0    | DEFAULT  | 2019-7-8T13:30:26+03:00 | SPORTSBOOK | PRIZE | Prize       | true        | VERIFIED | true     | PBS    | 100.0       | 10.0      | 100.0            |                      |

  Scenario Outline: Get wallet balance after 2nd bet PRIZE
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"


    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 100.0    | 100.0        | 0.0                     | 0.0              | 100.0                | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 100.0    | 100.0        | 0.0                     | 0.0              | 100.0                | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Prize Rollback Successful - Bonus Wallet
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<bonusAmount>"
    And the property "postBalance" in response body array with index "[0]" has value "<bonusPostBalance>"

    Examples:
      | accountId | amount | currency | issued                  | productId  | type           | description    | autocapture | status   | captured | gameId | bonusAmount | taxAmount | bonusPostBalance | metadataBonusPrizeId |
      | null      | 0.0    | EUR      | 2019-07-30T05:43:01.409 | SPORTSBOOK | PRIZE_ROLLBACK | PRIZE_ROLLBACK | true        | VERIFIED | true     | PBS    | -100.0      | 10.0      | 0.0              |                      |

  Scenario Outline: Get wallet balance after 2nd prize rollback - (Betting / Bonus = 0 , Lottery = same)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Deposit via Payment code - Betting wallet
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "<paymentMethodId>"
    And the "amount.amount" in response body is "<decimalAmount>"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"

    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType | decimalAmount |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 100    | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      | 100.0         |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Bet Reserve Successful - Main Wallet
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<amount>"
    And the property "postBalance" in response body array with index "[0]" has value "<postBalanceMain2>"

    Examples:
      | accountId | amount | currency | issued                    | productId  | type | description | autocapture | status   | captured | gameId | bonusAmount | postBalanceMain2 | taxAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -100.0 | DEFAULT  | 2019-07-30T13:30:26+03:00 | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | PBS    | 0.00        | 100.0            | 0.0       |                      |

  @nightlySuite @UAT @Preprod
  Scenario Outline: CaptureBet -  Bet Reserve Capture Main
    Given I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<amountMain2>"
    And the property "postBalance" in response body array with index "[0]" has value "<postBalanceMain2>"


    Examples:
      | amount | productId  | type | autocapture | status   | captured | amountMain2 | postBalanceMain2 |
      | -100   | SPORTSBOOK | BUY  | true        | VERIFIED | true     | -100.0      | 0.0              |


  Scenario Outline: Get wallet balance after reserve main wallet - (Betting / Bonus = 0 , Lottery = same)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |


    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Bet Cancel Successful to Main Wallet
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "description" in response body array with index "[0]" has value "<description>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<amount>"
    And the property "postBalance" in response body array with index "[0]" has value "<amount>"

    Examples:
      | accountId | amount | currency | issued                  | productId  | type   | description | autocapture | status   | captured | gameId | bonusAmount | taxAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | 100.0  | DEFAULT  | 2019-7-8T13:30:26+03:00 | SPORTSBOOK | CANCEL | Bet         | true        | VERIFIED | true     | PBS    | 0.00        | 0.0       |                      |

  Scenario Outline: Get wallet balance after cancel main wallet - (Bonus = 0 , Lottery = same)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 100.0    | 100.0        | 0.0                     | 0.0              | 100.0                | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 100.0    | 100.0        | 0.0                     | 0.0              | 100.0                | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Bet Adjust successful main wallet
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "description" in response body array with index "[0]" has value "<description>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<amount>"
    And the property "postBalance" in response body array with index "[0]" has value "<postBalanceMain2>"

    Examples:
      | accountId | amount | currency | issued                  | productId  | type   | description | autocapture | status   | captured | gameId | bonusAmount | postBalanceMain2 | taxAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -100.0 | DEFAULT  | 2019-7-8T13:30:26+03:00 | SPORTSBOOK | ADJUST | Bet         | true        | VERIFIED | true     | PBS    | -0.0        | 0.0              | 0.0       |                      |

  Scenario Outline: Get wallet balance after ADJUST main wallet - (Bonus/Betting = 0 , Lottery = same)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Bet Prize Successful to Main Wallet
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"

    Examples:
      | accountId | amount | currency | issued                  | productId  | type  | description | autocapture | status   | captured | gameId | bonusAmount | taxAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | 200.00 | EUR      | 2019-7-8T13:30:26+03:00 | SPORTSBOOK | PRIZE | Prize       | true        | VERIFIED | false    | PBS    | 0.00        | 10.0      |                      |

  Scenario Outline: Get wallet balance after PRIZE main wallet - (Betting changed,Bonus = 0 , Lottery = same)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 210.0    | 210.0        | 0.0                     | 0.0              | 210.0                | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 210.0    | 210.0        | 0.0                     | 0.0              | 210.0                | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Wager funds - Prize Rollback successfull main wallet
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "description" in response body array with index "[0]" has value "<description>"
    And the property "autocapture" in response body array with index "[0]" has value "<autocapture>"
    And the property "captured" in response body array with index "[0]" has value "<captured>"
    And the property "amount" in response body array with index "[0]" has value "<amount>"
    And the property "postBalance" in response body array with index "[0]" has value "<postBalanceMain2>"

    Examples:
      | accountId | amount | currency | issued                    | productId  | type           | description    | autocapture | status   | captured | gameId | bonusAmount | taxAmount | postBalanceMain2 | metadataBonusPrizeId |
      | null      | -200.0 | EUR      | 2019-07-08T13:30:26+03:00 | SPORTSBOOK | PRIZE_ROLLBACK | PRIZE_ROLLBACK | true        | VERIFIED | true     | PBS    | -0.0        | 10.0      | 10.0             |                      |

  Scenario Outline: Get wallet balance final - (Betting/Bonus = 0 , Lottery = same)
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Bonus Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance3> <buyingPower3> <nonWithdrawableBalance3> <reservedBalance3> <withdrawableBalance3> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 | balance3 | buyingPower3 | nonWithdrawableBalance3 | reservedBalance3 | withdrawableBalance3 |
      | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |



##########################################################################################################################################################################################################



    ############# CONFIGURED PLAYER ##########################################################################

  # a sample example for an existing user with active bonus (joker)
  @ConfiguredBonuses
  Scenario Outline: Check Player Active Bonus - Configured Player
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with configured playerId "523751303"
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    And the property "<responseProperty>" and value "<responseValue>" exist in the response body
    And I copy the value of the bonusPrizeId from the response if exists


    Examples:
      | keys          | values       | responseProperty | responseValue |
      | gameId,status | JOKER,ACTIVE | gameId           | JOKER         |


  @ConfiguredBonuses
  Scenario Outline: Check Player Assigned Bonus OB - Configured Player
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with configured playerId "523751303"
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And I copy the value of the bonusPrizeId from the response if exists

    Examples:
      | keys          | values      |
      | gameId,status | OB,ASSIGNED |

  @ConfiguredBonuses
  Scenario Outline: Get Active Bonuses - Configured Player
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    When I make a "GET" call to "Bonuses" to service "BonusService"
    Then the API call is successful with status code 200
    And I copy the value of the first bonusActiveId of providerId "<providerId>" and rewardType "<rewardType>" from the response


    Examples:
      | keys                       | values        | providerId | rewardType        |
      | status,pageNumber,pageSize | ACTIVE,1,1000 | PBS        | EXTERNAL_CAMPAIGN |

  @ConfiguredTest1
  Scenario Outline: Wager funds - Bet Reserve Successful from both wallets -  Configured TEST
    Given I login as an Api user
    Given I create a PlayBetFunds payload with taxAmount <taxAmount> gameId "<gameId>" bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with configured playerId "240830000"
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "[0]" has value "<type>"
    And the property "status" in response body array with index "[0]" has value "<status>"
    And the property "productId" in response body array with index "[0]" has value "<productId>"
    And the property "accountId" in response body array with index "[0]" has value "<accountId>"

    Examples:
      | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | gameId | bonusAmount | taxAmount | metadataBonusPrizeId |
      | AT_MAIN-2 | -20    | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | PBS    | -10.0       | 0.0       |                      |


  @ConfiguredBonuses
  Scenario Outline: Check Player Active Bonus - JOKER
    Given I login as an Api user
    And I create a Get "api_mainSpec_mainHost" header with query params "<keys>" "<values>"
    And I change url resource of method "GetBonusPrizes" of service "BonusService" with configured playerId "523751303"
    When I make a "GET" call to "GetBonusPrizes" to service "BonusService"
    Then the API call is successful with status code 200
    And the property "<responseProperty>" and value "<responseValue>" exist in the response body

    Examples:
      | keys          | values       | responseProperty | responseValue |
      | gameId,status | JOKER,ACTIVE | gameId           | JOKER         |