Feature: Place Bets

  ##################### New Player ##################

  @nightlySuite @UAT @Preprod
  Scenario: Get Time
    Given I create a Get "mainSpec" header
    When I make a "GET" call to "GetTime" to service "WagerService"
    Then the API call is successful with status code 200

  @nightlySuite @UAT @Preprod
  Scenario Outline: Place Wager (Lottery Wager)
    Given I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
    And I setup gameId header to "<gameType>"
    And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
    When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And I copy the value of the serialNumber from the response
    And the "[0].gameType" in response body is "<gameType>"

    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick |
      | JOKER    | 0       |         | 1 2 3 4 5     | 15             | false     |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get Lottery Wager Details (Web) - Verify Wager Selections & Serial Number
    Given I create a Get "mainSpec" header
    And I change url resource of method "GetLotteryWagerDetailsWeb" of service "WagerService" with new playerId
    And I change url resource of method "GetLotteryWagerDetailsWeb" of service "WagerService" with new serialNumber
    When I make a "GET" call to "GetLotteryWagerDetailsWeb" to service "WagerService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "serialNumbers" is 1
    And I verify the serial number in array with index "serialNumbers[0]" is the serialNumber from placeWager
    And the "gameType" in response body is "<gameType>"
    And the property "betType" in response body array with index "<boards>" has value "<betTypeValue>"
    And the property "multipliers" in response body array with index "<boards>" has value "<multiplierValue>"
    And the "wager.cost" in response body is "<wagerCost>"
    And the property "selection[0]" in response body array with index "<panels0>" has value "<selection1>"
    And the property "selection[1]" in response body array with index "<panels0>" has value "<selection2>"
    And the property "selection[2]" in response body array with index "<panels0>" has value "<selection3>"
    And the property "selection[3]" in response body array with index "<panels0>" has value "<selection4>"
    And the property "selection[4]" in response body array with index "<panels0>" has value "<selection5>"
    And the number of results in the first nested array "<panels1>.selection" is 1
    And the property "selection[0]" in response body array with index "<panels1>" has value "<jokerSelection>"

    Examples:
      | gameType | betTypeValue | multiplierValue | wagerCost | selection1 | selection2 | selection3 | selection4 | selection5 | jokerSelection | panels0                   | panels1                   | boards          |
      | JOKER    | 1            | 1               | 1.0       | 1          | 2          | 3          | 4          | 5          | 15             | wager.boards[0].panels[0] | wager.boards[0].panels[1] | wager.boards[0] |

    #These fail preprod cause of place wager mocks.. the serial number is in invalid format..

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get Lottery Wager Details (CC) - Verify Selections, GameType ,Wager Cost
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetLotteryWagerDetailsCC" of service "WagerService" with new playerId
    And I change url resource of method "GetLotteryWagerDetailsCC" of service "WagerService" with new serialNumber
    When I make a "GET" call to "GetLotteryWagerDetailsCC" to service "WagerService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "serialNumbers" is 1
    And I verify the serial number in array with index "serialNumbers[0]" is the serialNumber from placeWager
    And the "gameType" in response body is "<gameType>"
    And the property "betType" in response body array with index "<boards>" has value "<betTypeValue>"
    And the property "multipliers" in response body array with index "<boards>" has value "<multiplierValue>"
    And the "wager.cost" in response body is "<wagerCost>"
    And the property "selection[0]" in response body array with index "<panels0>" has value "<selection1>"
    And the property "selection[1]" in response body array with index "<panels0>" has value "<selection2>"
    And the property "selection[2]" in response body array with index "<panels0>" has value "<selection3>"
    And the property "selection[3]" in response body array with index "<panels0>" has value "<selection4>"
    And the property "selection[4]" in response body array with index "<panels0>" has value "<selection5>"
    And the number of results in the first nested array "<panels1>.selection" is 1
    And the property "selection[0]" in response body array with index "<panels1>" has value "<jokerSelection>"

    Examples:
      | gameType | betTypeValue | multiplierValue | wagerCost | selection1 | selection2 | selection3 | selection4 | selection5 | jokerSelection | panels0                   | panels1                   | boards          |
      | JOKER    | 1            | 1               | 1.0       | 1          | 2          | 3          | 4          | 5          | 15             | wager.boards[0].panels[0] | wager.boards[0].panels[1] | wager.boards[0] |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Joker Winning Bet - Verify Wallet, Prize, GameType, status, captured
    Given I login as an Intralot user
    And I create a PayWinningBet payload with <amount> <taxAmount> "<currency>" "<description>" "<issued>" "<partialPayment>" "<productId>"
    When I make a "POST" call to "PayWinningBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "accountId" in response body array with index "<array0>" has value "AT_MAIN-1"
    And the property "type" in response body array with index "<array0>" has value "PRIZE"
    And the property "status" in response body array with index "<array0>" has value "VERIFIED"
    And the property "captured" in response body array with index "<array0>" has value "true"
    And the property "productId" in response body array with index "<array0>" has value "<productId>"

    Examples:
      | amount | taxAmount | currency | description | issued  | partialPayment | productId | array0 |
      | 100    | 1         | EUR      | Prize       | datenow | false          | JOKER     | [0]    |


  @nightlySuite @UAT @Preprod
  Scenario: Get Wallet Balance - Copy balance MAIN-1 & MAIN-2
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the balance in wallet "AT_MAIN-1"
    And I copy the value of the balance in wallet "AT_MAIN-2"
    And I verify the balance in wallet "AT_MAIN-2" is "900.0"


  @nightlySuite @UAT @Preprod
  Scenario Outline: PlayBetFunds (PAME STOIXIMA) -  Verify response
    Given I login as an Api user
    And I setup gameId header to "<xGameId>"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "accountId" in response body array with index "<arrayWithIndex>" has value "<accountId>"
    And the property "productId" in response body array with index "<arrayWithIndex>" has value "<productId>"
    And the property "description" in response body array with index "<arrayWithIndex>" has value "<description>"
    And the property "amount" in response body array with index "<arrayWithIndex>" has value "<amount>"
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"
    And the property "autocapture" in response body array with index "<arrayWithIndex>" has value "<autocapture>"
    And the property "captured" in response body array with index "<arrayWithIndex>" has value "<captured>"

    Examples:
      | xGameId    | accountId | amount | currency | issued  | productId  | type | description | autocapture | status   | captured | arrayWithIndex | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | SPORTSBOOK | AT_MAIN-2 | -10.0  | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | VERIFIED | false    | [0]            | 0.0       | ""     | 0.0         |                      |

  @nightlySuite @UAT @Preprod
  Scenario Outline: CaptureBet -  Verify type & status
    Given I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with new playerId
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

    Examples:
      | amount | type | status   | arrayWithIndex |
      | -10    | BUY  | VERIFIED | [0]            |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Get Wallet Balance - Verify amount at 2 wallets (MAIN-1, MAIN-2) New assertions
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the balance in wallet "AT_MAIN-1" remains the same
    #And I verify the balance in wallet "AT_MAIN-2" is "895"
    And I verify the balance in wallet "AT_MAIN-2" is oldAmount "-" <amount>
    And I copy the value of the balance in wallet "AT_MAIN-2"


    Examples:
      | amount |
      | 10     |

  @nightlySuite @UAT @Preprod
  Scenario Outline: PlayBetFunds (PAME STOIXIMA winning ticket)
    Given I login as an Api user
    And I setup gameId header to "<xGameId>"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with new playerId
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "accountId" in response body array with index "<arrayWithIndex>" has value "<accountId>"
    And the property "productId" in response body array with index "<arrayWithIndex>" has value "<productId>"
    And the property "description" in response body array with index "<arrayWithIndex>" has value "<description>"
    And the property "amount" in response body array with index "<arrayWithIndex>" has value "<decimalAmount>"
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"
    And the property "autocapture" in response body array with index "<arrayWithIndex>" has value "<autocapture>"
    And the property "captured" in response body array with index "<arrayWithIndex>" has value "<autocapture>"

    Examples:
      | xGameId    | accountId | decimalAmount | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | arrayWithIndex | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | SPORTSBOOK | AT_MAIN-2 | 500.0         | 500    | DEFAULT  | datenow | SPORTSBOOK | PRIZE | Bet         | true        | VERIFIED |          | [0]            | 0.0       | ""     | 0.0         |                      |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get Wallet Balance - Verify amount at 2 wallets (MAIN-1, MAIN-2) New assertions 3
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the balance in wallet "AT_MAIN-1" remains the same
    And I verify the balance in wallet "AT_MAIN-2" is oldAmount "+" <amount>
    And I verify the balance in wallet "AT_MAIN-2" is "1390.0"



    Examples:
      | amount |
      | 500    |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get Player Levels - Check New Player level
    And I create a Get "specWithGameId" header
    When I make a "GET" call to "GetPlayerLevels" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "<key>" in response body is "<value>"

    Examples:
      | key         | value        |
      | playerLevel | FULL_ACCOUNT |

  ############################## CONFIGURED USER #######################################################################

  @PlaceBetsConfigured @noDependency
  Scenario: Get Time - Configured User
    Given I login as a "configuredPlayerWeb" user
    And I create a Get "mainSpec" header
    When I make a "GET" call to "GetTime" to service "WagerService"
    Then the API call is successful with status code 200

  #Hooks for getTime Dependency
  @PlaceBetsConfigured @getTime @noDependency
  Scenario Outline: Place Wager - Configured User (Lottery Wager)
    Given I login as a "configuredPlayerWeb" user
    And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with configured playerId "904649748"
    And I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
    When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And I copy the value of the serialNumber from the response

    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick |
      | JOKER    | 0       |         | 1 2 3 4 5     | 15             | false     |

    #Depends on PlaceWager
  @PlaceBetsConfigured
  Scenario Outline: Get Lottery Wager Details (Web) - Verify Wager Selections & Serial Number (Configured User)
    Given I create a Get "mainSpec" header
    And I change url resource of method "GetLotteryWagerDetailsWeb" of service "WagerService" with configured playerId "904649748"
    And I change url resource of method "GetLotteryWagerDetailsWeb" of service "WagerService" with new serialNumber
    When I make a "GET" call to "GetLotteryWagerDetailsWeb" to service "WagerService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "serialNumbers" is 1
    And I verify the serial number in array with index "serialNumbers[0]" is the serialNumber from placeWager
    And the "gameType" in response body is "<gameType>"
    And the property "betType" in response body array with index "<boards>" has value "<betTypeValue>"
    And the property "multipliers" in response body array with index "<boards>" has value "<multiplierValue>"
    And the "wager.cost" in response body is "<wagerCost>"
    And the property "selection[0]" in response body array with index "<panels0>" has value "<selection1>"
    And the property "selection[1]" in response body array with index "<panels0>" has value "<selection2>"
    And the property "selection[2]" in response body array with index "<panels0>" has value "<selection3>"
    And the property "selection[3]" in response body array with index "<panels0>" has value "<selection4>"
    And the property "selection[4]" in response body array with index "<panels0>" has value "<selection5>"
    And the number of results in the first nested array "<panels1>.selection" is 1
    And the property "selection[0]" in response body array with index "<panels1>" has value "<jokerSelection>"


    Examples:
      | gameType | betTypeValue | multiplierValue | wagerCost | selection1 | selection2 | selection3 | selection4 | selection5 | jokerSelection | panels0                   | panels1                   | boards          |
      | JOKER    | 1            | 1               | 1.0       | 1          | 2          | 3          | 4          | 5          | 15             | wager.boards[0].panels[0] | wager.boards[0].panels[1] | wager.boards[0] |

    #Depends on PlaceWager
  @PlaceBetsConfigured
  Scenario Outline: Get Lottery Wager Details (CC) - Verify Selections, GameType ,Wager Cost - Configured User
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetLotteryWagerDetailsCC" of service "WagerService" with configured playerId "904649748"
    And I change url resource of method "GetLotteryWagerDetailsCC" of service "WagerService" with new serialNumber
    When I make a "GET" call to "GetLotteryWagerDetailsCC" to service "WagerService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "serialNumbers" is 1
    And I verify the serial number in array with index "serialNumbers[0]" is the serialNumber from placeWager
    And the "gameType" in response body is "<gameType>"
    And the property "betType" in response body array with index "<boards>" has value "<betTypeValue>"
    And the property "multipliers" in response body array with index "<boards>" has value "<multiplierValue>"
    And the "wager.cost" in response body is "<wagerCost>"
    And the property "selection[0]" in response body array with index "<panels0>" has value "<selection1>"
    And the property "selection[1]" in response body array with index "<panels0>" has value "<selection2>"
    And the property "selection[2]" in response body array with index "<panels0>" has value "<selection3>"
    And the property "selection[3]" in response body array with index "<panels0>" has value "<selection4>"
    And the property "selection[4]" in response body array with index "<panels0>" has value "<selection5>"
    And the number of results in the first nested array "<panels1>.selection" is 1
    And the property "selection[0]" in response body array with index "<panels1>" has value "<jokerSelection>"

    Examples:
      | gameType | betTypeValue | multiplierValue | wagerCost | selection1 | selection2 | selection3 | selection4 | selection5 | jokerSelection | panels0                   | panels1                   | boards          |
      | JOKER    | 1            | 1               | 1.0       | 1          | 2          | 3          | 4          | 5          | 15             | wager.boards[0].panels[0] | wager.boards[0].panels[1] | wager.boards[0] |

  @PlaceBetsConfigured
    #Depends on PlaceWager (SerialNumber)
  Scenario Outline: Joker Winning Bet - Intralot Token
    Given I login as an Intralot user
    And I create a PayWinningBet payload with <amount> <taxAmount> "<currency>" "<description>" "<issued>" "<partialPayment>" "<productId>"
    And I change url resource of method "PayWinningBet" of service "WagerService" with configured playerId "904649748"
    When I make a "POST" call to "PayWinningBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "accountId" in response body array with index "<array0>" has value "AT_MAIN-1"
    And the property "type" in response body array with index "<array0>" has value "PRIZE"
    And the property "status" in response body array with index "<array0>" has value "VERIFIED"
    And the property "captured" in response body array with index "<array0>" has value "true"
    And the property "productId" in response body array with index "<array0>" has value "<productId>"

    Examples:
      | amount | taxAmount | currency | description | issued  | partialPayment | productId | array0 |
      | 100    | 1         | EUR      | Prize       | datenow | false          | JOKER     | [0]    |

  @PlaceBetsConfigured @noDependency
    #Runs Independently if you know the correct balance remaining
  Scenario Outline: Get Wallet Balance - Verify amount at MAIN-2 - Copy balance MAIN-1 (Configured User)
    Given I login as a "configuredPlayerCc" user
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with configured playerId "904649748"
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the balance in wallet "AT_MAIN-1"
    And I copy the value of the balance in wallet "AT_MAIN-2"
    #Uncomment if you know the exactly amount for configured User
   # And I verify the balance in wallet "AT_MAIN-2" is "<amount>"

    Examples:
      | amount  |
      | 57888.5 |


  @PlaceBetsConfigured @noDependency
  Scenario Outline: PlayBet (PAME STOIXIMA) - Configured User -  Funds
    Given I login as an Api user
    And I setup gameId header to "<xGameId>"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with configured playerId "904649748"
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "accountId" in response body array with index "<arrayWithIndex>" has value "<accountId>"
    And the property "productId" in response body array with index "<arrayWithIndex>" has value "<productId>"
    And the property "description" in response body array with index "<arrayWithIndex>" has value "<description>"
    And the property "amount" in response body array with index "<arrayWithIndex>" has value "<decimalAmount>"
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "VERIFIED"
    And the property "autocapture" in response body array with index "<arrayWithIndex>" has value "<autocapture>"
    And the property "captured" in response body array with index "<arrayWithIndex>" has value "<captured>"

    Examples:
      | xGameId    | accountId | amount | decimalAmount | currency | issued  | productId  | type | description | autocapture | status | captured | arrayWithIndex | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | SPORTSBOOK | AT_MAIN-2 | -10    | -10.0         | DEFAULT  | datenow | SPORTSBOOK | BUY  | Bet         | false       | TEST   | false    | [0]            | 0.0       | ""     | 0.0         |                      |

    #depends on PlayBet (referenceId2)
  @PlaceBetsConfigured
  Scenario Outline: CaptureBet - Configured User -   Verify type & status
    And I create a CaptureBet payload with <amount>
    And I change url resource of method "CaptureBet" of service "WagerService" with configured playerId "904649748"
    And I change url resource of method "CaptureBet" of service "WagerService" with referenceId2
    When I make a "POST" call to "CaptureBet" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"

    Examples:
      | amount | type | status   | arrayWithIndex |
      | -10    | BUY  | VERIFIED | [0]            |


    #depends on previous GetWalletBalance
  @PlaceBetsConfigured
  Scenario Outline: Get Wallet Balance - Verify amount at 2 wallets (MAIN-1, MAIN-2) New assertions - Configured User
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with configured playerId "904649748"
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the balance in wallet "AT_MAIN-1" remains the same
    And I verify the balance in wallet "AT_MAIN-2" is oldAmount "-" <amount>
    And I copy the value of the balance in wallet "AT_MAIN-2"

    Examples:
      | amount |
      | 10     |


  @PlaceBetsConfigured @noDependency
  Scenario Outline: PlayBetFunds (PAME STOIXIMA winning ticket) - Verify Response -  Configured User
    Given I login as an Api user
    And I setup gameId header to "<xGameId>"
    And I create a PlayBetFunds payload with taxAmount <taxAmount> gameId <gameId> bonusAmount <bonusAmount> "<accountId>" <amount> "<currency>" "<issued>" "<productId>" "<type>" "<description>" "<autocapture>" "<status>" "<captured>" "<metadataBonusPrizeId>"
    And I change url resource of method "PlayBetFunds" of service "WagerService" with configured playerId "904649748"
    When I make a "POST" call to "PlayBetFunds" to service "WagerService"
    Then the API call is successful with status code 200
    And the property "accountId" in response body array with index "<arrayWithIndex>" has value "<accountId>"
    And the property "productId" in response body array with index "<arrayWithIndex>" has value "<productId>"
    And the property "description" in response body array with index "<arrayWithIndex>" has value "<description>"
    And the property "amount" in response body array with index "<arrayWithIndex>" has value "<decimalAmount>"
    And the property "type" in response body array with index "<arrayWithIndex>" has value "<type>"
    And the property "status" in response body array with index "<arrayWithIndex>" has value "<status>"
    And the property "autocapture" in response body array with index "<arrayWithIndex>" has value "<autocapture>"
    And the property "captured" in response body array with index "<arrayWithIndex>" has value "<autocapture>"

    Examples:
      | xGameId    | accountId | decimalAmount | amount | currency | issued  | productId  | type  | description | autocapture | status   | captured | arrayWithIndex | taxAmount | gameId | bonusAmount | metadataBonusPrizeId |
      | SPORTSBOOK | AT_MAIN-2 | 100.0         | 100    | DEFAULT  | datenow | SPORTSBOOK | PRIZE | Bet         | true        | VERIFIED |          | [0]            | 0.0       | ""     | 0.0         |                      |

    #depends on previous calls
  @PlaceBetsConfigured
  Scenario Outline: Get Wallet Balance - Verify amount at 2 wallets (MAIN-1, MAIN-2) New assertions 3 - ConfiguredUser
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with configured playerId "904649748"
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the balance in wallet "AT_MAIN-1" remains the same
    And I verify the balance in wallet "AT_MAIN-2" is oldAmount "+" <amount>
    And I copy the value of the balance in wallet "AT_MAIN-2"

    Examples:
      | amount |
      | 100    |

  @PlaceBetsConfigured @noDependency
  Scenario Outline: Get Player Levels - Configured
    Given I login as a "configuredPlayerWeb" user
    And I change url resource of method "GetPlayerLevels" of service "PlayerService" with configured playerId "904649748"
    And I create a Get "specWithGameId" header
    When I make a "GET" call to "GetPlayerLevels" to service "PlayerService"
    Then the API call is successful with status code 200
    And the "<key>" in response body is "<value>"

    Examples:
      | key         | value        |
      | playerLevel | FULL_ACCOUNT |
