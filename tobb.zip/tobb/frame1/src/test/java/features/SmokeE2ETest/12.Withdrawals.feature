@withdrawals
Feature: Withdrawals

  ############################New Player#########################

  @nightlySuite @Preprod
  Scenario Outline: Prepare valid withdrawal via card - Joker wallet
    Given I login as an Api user
    And I setup gameId header to "JOKER"
    When I create a Post Withdrawal via "<viaMethod>" payload with <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "ValidWithdrawalViaCardOrIBAN" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "PENDING"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "CARD"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "paymentMethod.type" in response body is "CARD"
    And the "paymentMethod.card.expiryMonth" in response body is "12"
    And the "paymentMethod.card.expiryYear" in response body is "2030"
    And I verify the player id "owner.id" in the response body
    And I verify the card number and the card fingerprint
    And I copy the value of the withdrawal paymentId

    Examples:
      | amount | action  | operation         | paymentMethodType | viaMethod |
      | 30     | PREPARE | WALLET_WITHDRAWAL | CARD              | CARD      |


  @nightlySuite @UAT @Preprod
  Scenario Outline: Commit Card Withdrawal To Tora
    When I create a CommitWithdrawal to Tora Put payload with <amount> "<currency>" <forceReview> "<auditData>"
    When I change url resource of method "CommitCardWithdrawalToTora" of service "WalletService" with new withdrawal payment Id
    And I make a "PUT" call to "CommitCardWithdrawalToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "amount.amount" in response body is "30.0"
    And the "paymentStatus" in response body is "REVIEW"
    And I verify the player id "owner.id" in the response body
    And the "paymentMethod.type" in response body is "CARD"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "serviceProviderId" in response body is "TORA"
    And the "paymentMethod.card.expiryMonth" in response body is "12"
    And the "paymentMethod.card.expiryYear" in response body is "2030"

    Examples:
      | amount | currency | forceReview | auditData |
      | 10     | EUR      | false       | null      |

  @nightlySuite @Preprod
  Scenario Outline: Get BO Payments in REVIEW
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I make a "GET" call to "GetBOPayments" to service "WalletService"
    Then the API call is successful with status code 200
    And the property "status" in response body array with index "<index>" has value "REVIEW"
    And the property "amount" in response body array with index "<index>" has value "-30.0"
    And the property "currency" in response body array with index "<index>" has value "EUR"
    And the property "destination" in response body array with index "<index>" has value "CARD"
    And the property "paymentType" in response body array with index "<index>" has value "PT_TRANSFER_OUT"
    And the property "paymentMethodType" in response body array with index "<index>" has value "PMT_CARD"
    And the property "accountId" in response body array with index "<index>" has value "AT_MAIN-1"


    Examples:
      | keys                                                                                          | values                                                                | index   |
      | serviceProviderId,serviceProviderTargetId,fromDate,toDate,status,index,chunkSize,sortBy,order | TORA,CARD,2025-06-15T23:59:00Z,datenowinseconds,7,1,10,paymentId,desc | data[0] |

  @nightlySuite @Preprod
  Scenario: Put - Approve Withdrawal via card - BackOffice
    Given I create a ApproveWithdrawalCC Put payload with action "APPROVE"
    When I change url resource of method "ApproveWithdrawalCC" of service "WalletService" with new withdrawal payment Id
    And I make a "PUT" call to "ApproveWithdrawalCC" to service "WalletService"
    Then the API call is successful with status code 200
    And the "status" in response body is "APPROVED"
    And the "accountId" in response body is "AT_MAIN-1"
    And the "destination" in response body is "CARD"
    And the "paymentMethodType" in response body is "PMT_CARD"
    And the "amount" in response body is "-30.0"
    And the "currency" in response body is "EUR"
    And I verify the player id "owner.id" in the response body



#OLD APPROVE VIA API (it probably doesn't work in new flow)

  #@nightlySuite @Preprod
  #Scenario: Approve Withdrawal via card - API
  # Given I create a ApproveWithdrawal Put payload with amount 30
  # When I change url resource of method "ApproveWithdrawal" of service "WalletService" with new withdrawal payment Id
  # And I make a "PUT" call to "ApproveWithdrawal" to service "WalletService"
  # Then the API call is successful with status code 200
  # And the "paymentStatus" in response body is "APPROVED"
  # And the "serviceProviderId" in response body is "TORA"
  # And the "serviceProviderTargetId" in response body is "CARD"
  # And the "paymentType" in response body is "PT_TRANSFER_OUT"
  # And the "paymentDirection" in response body is "OUT"
  # And the "paymentMethod.type" in response body is "CARD"
  # And the "amount.amount" in response body is "30.0"
  # And the "amount.currency" in response body is "EUR"
  # And the "paymentMethod.card.expiryMonth" in response body is "06"
  # And the "paymentMethod.card.expiryYear" in response body is "2025"
  # And I verify the player id "owner.id" in the response body
  # And I verify the card number and the card fingerprint

   #delay is added because TORA doesn't send the response immediately. This should fix it.
  @nightlySuite @Preprod
  Scenario: Verify payment via Tora webhooks
    Given I add 5 seconds delay
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 30
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 204

  @nightlySuite
  Scenario Outline: Get and Verify Wallets Balance
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 1390.0   | 1390.0       | 890.0                   | 0.0              | 500.0                | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Prepare valid withdrawal via IBAN - Pame stoixima wallet
    And I setup gameId header to "SPORTSBOOK"
    When I create a Post Withdrawal via "<viaMethod>" payload with <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "ValidWithdrawalViaCardOrIBAN" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "PENDING"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "IBAN"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "paymentMethod.type" in response body is "BANK_ACCOUNT"
    And the "paymentMethod.id" in response body is "IBAN"
    And the "amount.currency" in response body is "EUR"
    And the "paymentMethod.bankAccount.accountNumber" in response body is "GR2202655559367039137283047"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the withdrawal paymentId

    Examples:
      | amount | action  | operation         | paymentMethodType | viaMethod |
      | 10     | PREPARE | WALLET_WITHDRAWAL | BANK_ACCOUNT      | IBAN      |

 #@nightlySuite @UAT @Preprod
 #Scenario: Approve Withdrawal via IBAN
 #  Given I create a ApproveWithdrawal Put payload with amount 10
 #  When I change url resource of method "ApproveWithdrawal" of service "WalletService" with new withdrawal payment Id
 #  And I make a "PUT" call to "ApproveWithdrawal" to service "WalletService"
 #  Then the API call is successful with status code 200
 #  And the "paymentStatus" in response body is "APPROVED"
 #  And the "serviceProviderId" in response body is "TORA"
 #  And the "serviceProviderTargetId" in response body is "IBAN"
 #  And the "paymentType" in response body is "PT_TRANSFER_OUT"
 #  And the "paymentDirection" in response body is "OUT"
 #  And the "paymentMethod.type" in response body is "BANK_ACCOUNT"
 #  And the "paymentMethod.id" in response body is "IBAN"
 #  And the "amount.currency" in response body is "EUR"
 #  And the "paymentMethod.bankAccount.accountNumber" in response body is "GR2202655559367039137283047"
 #  And I verify the player id "owner.id" in the response body

  @nightlySuite @UAT @Preprod
  Scenario Outline: Commit  Withdrawal via IBAN
    When I create a CommitWithdrawal to Tora Put payload with <amount> "<currency>" <forceReview> "<auditData>"
    When I change url resource of method "CommitCardWithdrawalToTora" of service "WalletService" with new withdrawal payment Id
    And I make a "PUT" call to "CommitCardWithdrawalToTora" to service "WalletService"
    Then the API call is successful with status code 200
    And the "amount.amount" in response body is "10.0"
    And the "paymentStatus" in response body is "APPROVED"
    And I verify the player id "owner.id" in the response body
    And the "paymentMethod.type" in response body is "BANK_ACCOUNT"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "serviceProviderId" in response body is "TORA"

    Examples:
      | amount | currency | forceReview | auditData |
      | 10     | EUR      | false       | null      |


  @nightlySuite @UAT @Preprod
  Scenario: Verify withdrawal with IBAN
    Given I create a VerifyWithdrawalViaIBAN Put Payload
    And I change url resource of method "VerifyWithdrawalWithIBAN" of service "WalletService" with new withdrawal payment Id
    And I make a "PUT" call to "VerifyWithdrawalWithIBAN" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "IBAN"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "paymentMethod.type" in response body is "BANK_ACCOUNT"
    And the "paymentMethod.id" in response body is "IBAN"
    And the "amount.currency" in response body is "EUR"
    And the "paymentMethod.bankAccount.accountNumber" in response body is "GR2202655559367039137283047"
    And I verify the player id "owner.id" in the response body


  Scenario Outline: Get and Verify Wallets Balance
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 1019.0   | 1019.0       | 949.0                   | 0.0              | 70.0                 |

    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 1380.0   | 1380.0       | 890.0                   | 0.0              | 490.0                | 999.0    | 999.0        | 899.0                   | 0.0              | 100.0                |