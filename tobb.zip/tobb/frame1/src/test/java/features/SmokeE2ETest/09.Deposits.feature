@deposits
Feature: Deposits

  ############################New Player#########################

  @nightlySuite @UAT @Preprod
  Scenario Outline: Valid deposit payment code (>800 Euros) - Non Exclusive Games
    Given I login as an Api user
    When I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
    And the "amount.amount" in response body is "900.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 900    | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get and Verify Wallets Balance
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  | 0.0      | 0.0          | 0.0                     | 0.0              | 0.0                  |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Valid deposit payment code (>800 Euros) - Exclusive Games
    When I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_EXCLUSIVE"
    And the "amount.amount" in response body is "900.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body
    And I copy the value of the paymentId

    Examples:
      | paymentMethodId        | paymentCode | amount | action | operation      | paymentMethodType |
      | PAYMENT_CODE_EXCLUSIVE | Exclusive   | 900    | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get and Verify Wallets Balance
    Given I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    When I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  |

    #TODO: Replace Header Limits with new step calculating headers for specific wallet
  @nightlySuite @UAT @Preprod
  Scenario Outline: Get web v1 balance header JOKER
    Given I login as a "newPlayerWeb" user
    And I setup gameId header to "JOKER"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV1" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV1" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV1 for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Lottery Wallet"
  # And the property "[1].productIds" includes value "JOKER"
  # And the property "[1].productIds" includes value "PROTO"
  # And the property "[1].productIds" includes value "LOTTO"
  # And the property "[1].productIds" includes value "OPAPONLINE"
  # And the property "[1].productIds" includes value "KINO"
  # And the property "[1].productIds" includes value "SUPER3"

    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 900.0   | 900.0       | 900.0                  | 0.0             | 0.0                 |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get web v1 balance header CASINO
    Given I setup gameId header to "CASINO"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV1" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV1" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV1 for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Betting Wallet"



    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 900.0   | 900.0       | 900.0                  | 0.0             | 0.0                 |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Get web v1 balance header SPORTSBOOK
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV1" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV1" to service "BalanceService"
    Then the API call is successful with status code 200
    And I verify the response for GetBalanceV1 for <balance> <buyingPower> <nonWithdrawableBalance> <reservedBalance> <withdrawableBalance> for "Betting Wallet"



    Examples:
      | balance | buyingPower | nonWithdrawableBalance | reservedBalance | withdrawableBalance |
      | 900.0   | 900.0       | 900.0                  | 0.0             | 0.0                 |

  #TODO: Replace Header Limits with new step calculating headers for specific wallet
  @nightlySuite @UAT @Preprod
  Scenario Outline: Get web v2 balance header JOKER
    Given I setup gameId header to "JOKER"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV2" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV2" to service "BalanceService"
    Then the API call is successful with status code 200
  #And the property "primary[1].productIds" includes value "JOKER"
  #And the property "primary[1].productIds" includes value "PROTO"
  #And the property "primary[1].productIds" includes value "LOTTO"
  #And the property "primary[1].productIds" includes value "OPAPONLINE"
  #And the property "primary[1].productIds" includes value "KINO"
  #And the property "primary[1].productIds" includes value "SUPER3"
    And I verify the response for GetBalanceV2 for primary <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Lottery Wallet" and secondary <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Betting Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  |

      #TODO: Replace Header Limits with new step calculating headers for specific wallet
  @nightlySuite @UAT @Preprod
  Scenario Outline: Get web v2 balance header CASINO
    Given I setup gameId header to "CASINO"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV2" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV2" to service "BalanceService"
    Then the API call is successful with status code 200
  # And the property "secondary[1].productIds" includes value "JOKER"
  # And the property "secondary[1].productIds" includes value "PROTO"
  # And the property "secondary[1].productIds" includes value "LOTTO"
  # And the property "secondary[1].productIds" includes value "OPAPONLINE"
  # And the property "secondary[1].productIds" includes value "KINO"
  # And the property "secondary[1].productIds" includes value "SUPER3"
    And I verify the response for GetBalanceV2 for primary <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet" and secondary <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  |

   #TODO: Replace Header Limits with new step calculating headers for specific wallet
  @nightlySuite @UAT @Preprod
  Scenario Outline: Get web v2 balance header SPORTSBOOK
    Given I setup gameId header to "SPORTSBOOK"
    When I create a Get "specWithGameId" header
    And I change url resource of method "GetBalanceV2" of service "BalanceService" with new playerId
    And I make a "GET" call to "GetBalanceV2" to service "BalanceService"
    Then the API call is successful with status code 200
   # And the property "secondary[1].productIds" includes value "JOKER"
   # And the property "secondary[1].productIds" includes value "PROTO"
   # And the property "secondary[1].productIds" includes value "LOTTO"
   # And the property "secondary[1].productIds" includes value "OPAPONLINE"
   # And the property "secondary[1].productIds" includes value "KINO"
   # And the property "secondary[1].productIds" includes value "SUPER3"
    And I verify the response for GetBalanceV2 for primary <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet" and secondary <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"


    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  |

  @nightlySuite @UAT @Preprod
  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card
    And I copy the value of the signature of card

    Examples:
      | amount |
      | 50     |

  Scenario Outline: Set Master Card Details
    Given I create a Post Checkout Torawallet payload with amount "<amount>" "<cardNumber>" "<holderName>" "<cvv>" "<exp_month>" "<exp_year>" "<currency>" "<primaryKey>"
    When I make a "POST" call to "PostMastercardDetailsToSandbox" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the deposit tokenId

    @nightlySuite
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm |

    @UAT
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5413330002001031 | TEST PROD  | 100 | 12        | 2030     | EUR      | pk_ucnmwjkspFMybrr42iBaYsZilhuUcxBs |

    @Preprod
    Examples:
      | amount | cardNumber       | holderName | cvv | exp_month | exp_year | currency | primaryKey                          |
      | 5000   | 5199992312641465 | TEST PROD  | 010 | 12        | 2030     | EUR      | pk_U0jMXzvD8cOv0kx0qDHghRVZ56TCELA7 |


  @nightlySuite @UAT @Preprod
  Scenario: Commit Card Deposit To Tora
    When I create a CommitCardDeposit to Tora Put payload
    And I change url resource of method "CommitCardDepositToTora" of service "WalletService" with new via card deposit paymentId
    And I make a "PUT" call to "CommitCardDepositToTora" to service "WalletService"
    Then the API call is successful with status code 202
    And I verify the deposit paymentId via card

  Scenario Outline: Get and Verify Wallets Balance
    When I create a Get "cc_csrftokenSpec" header
    And I change url resource of method "GetWalletBalance" of service "WalletService" with new playerId
    And I make a "GET" call to "GetWalletBalance" to service "WalletService"
    Then the API call is successful with status code 200
    And I verify the response for GetWalletBalance for <balance1> <buyingPower1> <nonWithdrawableBalance1> <reservedBalance1> <withdrawableBalance1> for "Betting Wallet"
    And I verify the response for GetWalletBalance for <balance2> <buyingPower2> <nonWithdrawableBalance2> <reservedBalance2> <withdrawableBalance2> for "Lottery Wallet"

    @nightlySuite @Preprod
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  | 950.0    | 950.0        | 950.0                   | 0.0              | 0.0                  |


    @UAT
    Examples:
      | balance1 | buyingPower1 | nonWithdrawableBalance1 | reservedBalance1 | withdrawableBalance1 | balance2 | buyingPower2 | nonWithdrawableBalance2 | reservedBalance2 | withdrawableBalance2 |
      | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  | 900.0    | 900.0        | 900.0                   | 0.0              | 0.0                  |




