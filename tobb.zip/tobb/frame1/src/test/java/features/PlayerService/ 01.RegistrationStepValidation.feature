@PlayerService
Feature: Registration Step Validation

  #Validate Registration Fields
  Scenario: Create OTP Verification
    Given I create a "POST" VerifyOTP payload
    When I make a "POST" call to "VerifyOTP" to service "PlayerService"
    Then the API call is successful with status code 200
    And I copy the value of the uuid from the response

  Scenario: Verify OTP Code
    Given I create a "PUT" VerifyOTP payload
    When I make a "PUT" call to "VerifyOTP" to service "PlayerService"
    Then the API call is successful with status code 204

  Scenario Outline: Register - Verify same request values in response
    Given I setup gameId header to "<xGameId>"
    And I create a Register payload with "<username>" "<password>" "<email>" "<identityType>" "<firstName>" "<middleName>" "<lastName>" "<gender>" "<dateOfBirth>" "<country>" "<address1>" "<profession>" "<city>" "<zipCode>" "<bonusCode>" "<secretQuestion>" "<secretAnswer>" "<ibanNumber>" "<permanentResidenceCountry>"
    When I make a "POST" call to "RegisterPlayer" to service "PlayerService"
    Then the API call is successful with status code 200
    And I copy the value of the player id "id" from the response
    And the "sendOtpOnRegistration" in response body has value not null
    And the "dateOfBirth" in response body is "<dateOfBirth>"
    And the "firstName" in response body is "<firstName>"
    And the "middleName" in response body is "<middleName>"
    And the "lastName" in response body is "<lastName>"
    And the "address1" in response body is "<address1>"
    And the "identityType" in response body is "<identityType>"
    And the "country" in response body is "<country>"
    And the "gender" in response body is "<gender>"
    And the "zip" in response body is "<zipCode>"
    And the "city" in response body is "<city>"
    And the "permanentResidenceCountry" in response body is "<permanentResidenceCountry>"

    Examples:
      | xGameId | username    | password     | email       | identityType | firstName | middleName | lastName | gender | dateOfBirth | country | address1           | profession | city   | zipCode | bonusCode            | secretQuestion     | secretAnswer  | ibanNumber                  | permanentResidenceCountry |
      | JOKER   | restAssured | Qwerty12345! | restAssured | OTHER        | PAM       | LOTTERY    | PLATFORM | M      | 1924-04-13  | GR      | First Address 0100 | Unemployed | Athens | 15125   | THIS_IS_A_BONUS_CODE | What is your name? | restAssuredAI | GR2202655559367039137283047 | GRC                       |

  Scenario Outline: Get MailId For Fetch Hash - Verify origin has value player
    Given I login as a "configuredPlayerCc" user
    And I create a Get "cc_csrftokenSpec" header with query params "<key>" "<value>"
    When I make a "GET" call to "GetMailIdForFetchHash" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the number of results in the first nested array "<array>" is 1
    And the property "<property>" in response body array with index "<arrayWithIndex>" has value "<propertyValue>"
    And I copy the value of the mailId from the response

    Examples:
      | key      | value    | property | propertyValue | array | arrayWithIndex |
      | playerId | changeit | origin   | player        | data  | data[0]        |

  Scenario Outline: Get hash For Mail Verification - Verify event name/owner
    Given I create a Get "cc_csrftokenSpec" header
    When I make a "GET" call to "GetHashForMailVerification" to service "CommunicationService"
    Then the API call is successful with status code 200
    And the "<property>" in response body is "<propertyValue>"
    And the "<property2>" in response body is "<propertyValue2>"
    And the id in response body is mailIdForHash
    And I copy the value of the hash from the response

    Examples:
      | property  | propertyValue                       | property2  | propertyValue2 |
      | eventName | registrationWelcomeEvent.opaponline | eventOwner | player         |

  Scenario: Verify Player's Email - Call to verify player's email
    Given I create a VerifyEmail payload with inner playerId and hash
    When I make a "POST" call to "VerifyPlayersEmail" to service "PlayerService"
    Then the API call is successful with status code 204

  Scenario Outline: Validate Registration Fields - Step Validation 1
    Given I setup gameId header to "CASINO"
    Given I create a Registration Step 1 Validation payload with "<username>" "<password>" "<mobilePhone>" "<email>" "<promoCode>"
    When I make a "POST" call to "ValidateRegistrationFields" to service "PlayerService"
    Then the API call is successful with status code 200
    And I verify Step Validation Error occurs on "<fieldName1>" with "<errorId1>" and on "<fieldName2>" with "<errorId2>"

    Examples:
      | fieldName1  | errorId1                          | fieldName2 | errorId2                  | username                   | password                          | mobilePhone         | email                  | promoCode          |
      | username    | PROPERTY_NOT_FOUND                | password   | PASSWORD_USERNAME_MISSING |                            | Qwerty12345!                      | 6947444449          | test@test.gr           |                    |
      | username    | USERNAME_TOO_SHORT                |            |                           | tes                        | Qwerty12345!                      | 6947444449          | test@test.gr           |                    |
      | username    | INVALID_USERNAME_PATTERN          |            |                           | τεστερ                     | Qwerty12345!                      | 6947444449          | test@test.gr           |                    |
      | username    | INVALID_USERNAME_PATTERN          |            |                           | tester123!                 | Qwerty12345!                      | 6947444449          | test@test.gr           |                    |
      | username    | USERNAME_TOO_LONG                 |            |                           | thisisalongusername1245678 | Qwerty12345!                      | 6947444449          | test@test.gr           |                    |
      | username    | USERNAME_ALREADY_EXISTS           |            |                           | <USED_USERNAME>            | Qwerty12345!                      | 6947444449          | test@test.gr           |                    |

      | password    | PROPERTY_NOT_FOUND                |            |                           | validusername555           |                                   | 6947444449          | test@test.gr           |                    |
      | password    | INVALID_PASSWORD_MIN_LENGTH       |            |                           | validusername555           | shortPass                         | 6947444449          | test@test.gr           |                    |
      | password    | INSUFFICIENT_CHARACTER_CATEGORIES |            |                           | validusername555           | thisIsAGreatPass1                 | 6947444449          | test@test.gr           |                    |
      | password    | INSUFFICIENT_CHARACTER_CATEGORIES |            |                           | validusername555           | thisIsAGreatPass!                 | 6947444449          | test@test.gr           |                    |
      | password    | INSUFFICIENT_CHARACTER_CATEGORIES |            |                           | validusername555           | thisisagreatpas$1                 | 6947444449          | test@test.gr           |                    |
      | password    | INSUFFICIENT_CHARACTER_CATEGORIES |            |                           | validusername555           | THISISAGREATPAS$1                 | 6947444449          | test@test.gr           |                    |
      | password    | INSUFFICIENT_CHARACTER_CATEGORIES |            |                           | validusername555           | thisIsAGreatPass                  | 6947444449          | test@test.gr           |                    |
      | password    | INSUFFICIENT_CHARACTER_CATEGORIES |            |                           | validusername555           | thisisagreatpass                  | 6947444449          | test@test.gr           |                    |
      | password    | INSUFFICIENT_CHARACTER_CATEGORIES |            |                           | validusername555           | στ@Ελλην!κα                       | 6947444449          | test@test.gr           |                    |
      | password    | INVALID_PASSWORD_MAX_LENGTH       |            |                           | validusername555           | thisIsA33CharPassword1234567890!! | 6947444449          | test@test.gr           |                    |
      | password    | INVALID_PASSWORD_USERNAME         |            |                           | validusername555           | validUsername555A!                | 6947444449          | test@test.gr           |                    |
      | password    | INVALID_PASSWORD_EMAIL            |            |                           | validusername555           | teSt@test.gr1!                    | 6947444449          | test@test.gr           |                    |

      | mobilePhone | PROPERTY_NOT_FOUND                |            |                           | validusername555           | Qwerty12345!                      |                     | test@test.gr           |                    |
      | mobilePhone | INVALID_MOBILE_PHONE_PATTERN      |            |                           | validusername555           | Qwerty12345!                      | test                | test@test.gr           |                    |
      | mobilePhone | INVALID_MOBILE_PHONE_PATTERN      |            |                           | validusername555           | Qwerty12345!                      | 1111112222          | test@test.gr           |                    |
      | mobilePhone | INVALID_MOBILE_PHONE_PATTERN      |            |                           | validusername555           | Qwerty12345!                      | 694744444           | test@test.gr           |                    |
      | mobilePhone | INVALID_MOBILE_PHONE_PATTERN      |            |                           | validusername555           | Qwerty12345!                      | 69474444491         | test@test.gr           |                    |
      | mobilePhone | MOBILE_PHONE_NOT_FREE             |            |                           | validusername555           | Qwerty12345!                      | <USED_MOBILE_PHONE> | test@test.gr           |                    |

      | email       | PROPERTY_NOT_FOUND                | password   | PASSWORD_EMAIL_MISSING    | validusername555           | Qwerty12345!                      | 6947444449          |                        |                    |
      | email       | INVALID_EMAIL                     |            |                           | validusername555           | Qwerty12345!                      | 6947444449          | test@test              |                    |
      | email       | INVALID_EMAIL                     |            |                           | validusername555           | Qwerty12345!                      | 6947444449          | test@test.             |                    |
      | email       | INVALID_EMAIL                     |            |                           | validusername555           | Qwerty12345!                      | 6947444449          | ab(cd,e:f;g<h@test.com |                    |
      | email       | EMAIL_NOT_FREE                    |            |                           | validusername555           | Qwerty12345!                      | 6947444449          | <USED_EMAIL>           |                    |

      | promoCode   | INVALID_PROMO_CODE                |            |                           | validusername555           | Qwerty12345!                      | 6947444449          | validemail555@test.gr  | invalid_promo_code |
      # ep predefined valid promoCode but with CASINO header
      | promoCode   | INVALID_PROMO_CODE                |            |                           | validusername555           | Qwerty12345!                      | 6947444449          | validemail555@test.gr  | opap               |
      # nep predefined valid promoCode with CASINO header (no validation error test case)
      |             |                                   |            |                           | validusername555           | Qwerty12345!                      | 6947444449          | validemail555@test.gr  | promo              |
      # empty promoCode (no validation error test case)
      |             |                                   |            |                           | validusername555           | Qwerty12345!                      | 6947444449          | validemail555@test.gr  |                    |
