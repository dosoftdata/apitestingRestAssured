#This feature is to check for Deposit Functionallity in an existing user
  # @ConfiguredUser is mandatory tag for the scenarios to run because of hooks as the playerId value changes just for now.
  # This enables the step new player Id to work.
@ConfiguredDeposits @ConfiguredUser
Feature: Deposits Verified User

  ############################Configured Player#########################

  Scenario Outline: Get and Verify Payment Codes
    Given I login as a "configuredPlayerCc" user
    When I create a Get "cc_csrftokenSpec" header with query params "<keys>" "<values>"
    And I change url resource of method "GetPaymentCodes" of service "WalletService" with new playerId
    And I make a "GET" call to "GetPaymentCodes" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the values of the Payment Codes
    Examples:
      | keys     | values |
      | category | ALL    |

  Scenario Outline: Deposit via Payment code - Betting wallet
    Given I login as an Api user
    Given I create a Post DepositViaPaymentCode payload with "<paymentMethodId>" "<paymentCode>" <amount> "<action>" "<operation>" "<paymentMethodType>"
    When I make a "POST" call to "PostPaymentViaPaymentCode" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the paymentId
    And the "paymentMethod.id" in response body is "PAYMENT_CODE_NON_EXCLUSIVE"
    And the "amount.amount" in response body is "<amountResponse>"
    And the "amount.currency" in response body is "EUR"
    And the "paymentStatus" in response body is "APPROVED"
    And the "paymentType" in response body is "PT_TRANSFER_IN"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "PAYMENT_CODE"
    And I verify the player id "owner.id" in the response body

    Examples:
      | paymentMethodId            | paymentCode  | amount | action | operation      | paymentMethodType | amountResponse |
      | PAYMENT_CODE_NON_EXCLUSIVE | NonExclusive | 20     | COMMIT | WALLET_DEPOSIT | PAYMENT_CODE      | 20.0           |


  Scenario Outline: Place Wager (Lottery Wager)
    Given I login as a "configuredPlayerWeb" user
    Given I create a PlaceMultipleWagers payload with "<gameType>" "<betType>" "<boardId>" "<mainSelection>" "<jokerSelection>" "<quickPick>"
    And I change url resource of method "PlaceMultipleWagers" of service "WagerService" with new playerId
    When I make a "POST" call to "PlaceMultipleWagers" to service "WagerService"
    Then the API call is successful with status code 200
    And I copy the value of the serialNumber from the response
    And the "gameType" in response body is "<gameType>"

    Examples:
      | gameType | betType | boardId | mainSelection | jokerSelection | quickPick |
      | JOKER    | 0       |         | 1 2 3 4 5     | 15             | false     |


  Scenario Outline: Valid deposit card - Exclusive games JOKER
    Given I login as a "configuredPlayerWeb" user
    Given I setup gameId header to "JOKER"
    When I create a Post DepositViaCard payload with "<amount>"
    And I change url resource of method "PostPaymentViaCard" of service "WalletService" with new playerId
    And I make a "POST" call to "PostPaymentViaCard" to service "WalletService"
    Then the API call is successful with status code 202
    And I copy the value of the paymentId for deposit via card

    Examples:
      | amount |
      | 20     |


  Scenario Outline: Valid withdrawal via card - Joker wallet
    Given I setup card fingerprint "<cardFingerprint>"
    And I login as an Api user
    And I setup gameId header to "JOKER"
    When I create a Post Withdrawal via "<viaMethod>" payload with <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "ValidWithdrawalViaCardOrIBAN" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the withdrawal paymentId
    And the "paymentStatus" in response body is "PENDING"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "CARD"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "paymentMethod.type" in response body is "CARD"
    And the "paymentMethod.card.expiryMonth" in response body is "06"
    And the "paymentMethod.card.expiryYear" in response body is "2025"
    And I verify the player id "owner.id" in the response body

    @skipIfNotIntegration
    Examples:
      | amount | action  | operation         | paymentMethodType | viaMethod | cardFingerprint                                                  |
      | 30     | PREPARE | WALLET_WITHDRAWAL | CARD              | CARD      | 8e60229f8a5687609c5b529ba4458691582fa1a4aa4c967c48e9fb780739a4a6 |

    #TODO: not sure about the fingerprints below..
    @skipIfNotUAT
    Examples:
      | amount | action  | operation         | paymentMethodType | viaMethod | cardFingerprint                                                  |
      | 30     | PREPARE | WALLET_WITHDRAWAL | CARD              | CARD      | 8e60229f8a5687609c5b529ba4458691582fa1a4aa4c967c48e9fb780739a4a6 |

    @skipIfNotPreprod
    Examples:
      | amount | action  | operation         | paymentMethodType | viaMethod | cardFingerprint                                                  |
      | 30     | PREPARE | WALLET_WITHDRAWAL | CARD              | CARD      | 8e60229f8a5687609c5b529ba4458691582fa1a4aa4c967c48e9fb780739a4a6 |


  Scenario: Approve Withdrawal via card
    Given I create a ApproveWithdrawal Put payload with amount 30
    When I change url resource of method "ApproveWithdrawal" of service "WalletService" with new withdrawal payment Id
    And I make a "PUT" call to "ApproveWithdrawal" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "APPROVED"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "CARD"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "paymentMethod.type" in response body is "CARD"
    And the "amount.amount" in response body is "30.0"
    And the "amount.currency" in response body is "EUR"
    And the "paymentMethod.card.expiryMonth" in response body is "06"
    And the "paymentMethod.card.expiryYear" in response body is "2025"
    And I verify the player id "owner.id" in the response body

   #delay is added because TORA doesn't send the response immediately. This should fix it.
  Scenario: Verify payment via Tora webhooks
    Given I add 5 seconds delay
    When I create a Post VerifyPaymentViaToraWebhooks payload with amount 30
    And I make a "POST" call to "VerifyPaymentViaToraWebhooks" to service "WalletService"
    Then the API call is successful with status code 204

  Scenario Outline: Valid withdrawal via IBAN - Pame stoixima wallet
    And I setup gameId header to "SPORTSBOOK"
    When I create a Post Withdrawal via "<viaMethod>" payload with <amount> "<action>" "<operation>" "<paymentMethodType>"
    And I make a "POST" call to "ValidWithdrawalViaCardOrIBAN" to service "WalletService"
    Then the API call is successful with status code 200
    And I copy the value of the withdrawal paymentId
    And the "paymentStatus" in response body is "PENDING"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "IBAN"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "paymentMethod.type" in response body is "BANK_ACCOUNT"
    And the "paymentMethod.id" in response body is "IBAN"
    And the "amount.currency" in response body is "EUR"
    And I verify the player id "owner.id" in the response body
    #And the "paymentMethod.bankAccount.accountNumber" in response body is "GR1601101250000000012300695"


    Examples:
      | amount | action  | operation         | paymentMethodType | viaMethod |
      | 10     | PREPARE | WALLET_WITHDRAWAL | CARD              | IBAN      |

  Scenario: Approve Withdrawal via IBAN
    Given I create a ApproveWithdrawal Put payload with amount 10
    When I change url resource of method "ApproveWithdrawal" of service "WalletService" with new withdrawal payment Id
    And I make a "PUT" call to "ApproveWithdrawal" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "APPROVED"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "IBAN"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "paymentMethod.type" in response body is "BANK_ACCOUNT"
    And the "paymentMethod.id" in response body is "IBAN"
    And the "amount.currency" in response body is "EUR"
    And I verify the player id "owner.id" in the response body
   # And the "paymentMethod.bankAccount.accountNumber" in response body is "GR1601101250000000012300695"


  Scenario: Verify withdrawal with IBAN
    Given I create a VerifyWithdrawalViaIBAN Put Payload
    And I change url resource of method "VerifyWithdrawalWithIBAN" of service "WalletService" with new withdrawal payment Id
    And I make a "PUT" call to "VerifyWithdrawalWithIBAN" to service "WalletService"
    Then the API call is successful with status code 200
    And the "paymentStatus" in response body is "VERIFIED"
    And the "serviceProviderId" in response body is "TORA"
    And the "serviceProviderTargetId" in response body is "IBAN"
    And the "paymentType" in response body is "PT_TRANSFER_OUT"
    And the "paymentDirection" in response body is "OUT"
    And the "paymentMethod.type" in response body is "BANK_ACCOUNT"
    And the "paymentMethod.id" in response body is "IBAN"
    And the "amount.currency" in response body is "EUR"
    And I verify the player id "owner.id" in the response body
   # And the "paymentMethod.bankAccount.accountNumber" in response body is "GR1601101250000000012300695"
