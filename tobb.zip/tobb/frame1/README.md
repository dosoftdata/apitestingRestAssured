# REST Assured

## Name

Rest Assured Framework

## Description

This project is created for Api Testing of Lottery PAM replacing the old way of Postman. The purpose of this project is
to migrate the
postman suites as well as add new test cases when necessary. RestAssured is an open-sourced Java based framework that
combined
with Gherkin language can make things easy and dynamic with data driven examples and less code.
<p>For more info please check the
documentation: </p>
<p><a href="https://opapgr.atlassian.net/wiki/spaces/QT/pages/2250604636/Functional+E2E+Testing+with+REST+Assured">
Documentation</a> </p>

## Installation

For Installation you should check the installation part of the documentation mentioned below:

<a href="https://opapgr.atlassian.net/wiki/spaces/QT/pages/2251849814/How+to+get+started+Installation">
Installation</a>

## Rest Assured Pipelines

There is already one pipeline where you can choose the enviroments and the tags of the tests. Daily the restAssured
pipeline runs in Integration as some regression test on basic
functionalities. (PAM Suite)

<p>The pipeline is located here:</p>
<a href="https://gitlab.dc.opap/deveng/client-opap/rest-assured/-/pipelines">
Rest Assured Pipeline</a>

General instruction for environments and tags can be found here.

<p><a href="https://opapgr.atlassian.net/wiki/spaces/QT/pages/2634481722/Environments+Tags">
Environments & Tags</a></p>
But if something is not clear for the pipeline there will be one separate section soon in documentation.

## Authors and acknowledgment

The project was created from scratch by Chatzi and Tsitsirikis.
Below are all the developers involved by chronological order:

<p>Chatzi Evgenia, Tsitsirikis Grigoris</p>
<p>Boukouvala Fryni</p>
<p>Ploumis Thanos</p>

## Project status

<b>In progress </b>

<p><b>PAM Smoke Suites</b>: have been migrated to rest Assured for environments (Integration,UAT,Azure,Preprod) - <b>Completed</b></p>
<p><b>Wager Service Suite</b>: has been migrated to Rest Assured. Environments Tested: (Integration,UAT,Azure,Preprod) - <b>Completed</b></p>
<p><b>Communication Service Suite</b>: has been migrated to Rest Assured. Environments Tested: (Integration,UAT,Azure,Preprod) - <b>Completed</b></p>
<p><b>Access Service Suite</b>: has been migrated to Rest Assured. Environments Tested: (Integration,Azure,Preprod) - <b>Completed</b></p>

## Roadmap

<p><b>Bonus Service: In progress</b></p>
<p><b>Wallet & Wit Service: In progress</b></p>
<p><b>Balance Service: In progress</b></p>
<p>Player Service: TBD</p>
<p>Limit Service: TBD</p>
<p>Subscription Service: TBD</p>
<p>Promotion Service: TBD</p>