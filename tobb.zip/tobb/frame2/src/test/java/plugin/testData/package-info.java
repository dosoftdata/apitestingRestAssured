/**
 * Test data repositories, loaders, and generators.
 *
 * <p>Facilities for loading fixture data (files, DB, services), and
 * generating synthetic datasets for parameterized scenarios.</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>Repository interfaces and concrete loaders (JSON, CSV, DB)</li>
 *   <li>Data generation/seeding utilities</li>
 *   <li>Per-scenario scoping and cleanup helpers</li>
 * </ul>
 *
 * @since 1.0
 */

package java.plugin.testData;