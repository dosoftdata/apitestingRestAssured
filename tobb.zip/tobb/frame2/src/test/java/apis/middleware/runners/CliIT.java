package apis.middleware.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.qameta.allure.testng.AllureTestNg;
import lombok.extern.slf4j.Slf4j;
import apis.middleware.dsl.ScenarioContext;
import org.testng.annotations.*;

/**
 * The type Cli it.
 */
@Listeners({AllureTestNg.class})
@CucumberOptions(
    plugin = {
        "pretty",
        "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"
    },
    features = "classpath:features",
    glue = {
        "apis.middleware.dsl.actions",
        "apis.middleware.stepDefs",
        "apis.middleware.hooks"
    }
   //,tags = "@regression"
)
@Slf4j
public class CliIT extends AbstractTestNGCucumberTests {
  @Override
  @DataProvider(name = "scenarios", parallel = false)
  public Object[][] scenarios() {

    int dpThreads = getDataProviderThreadCount();
    log.info("DataProvider threads: {}", dpThreads);

    return super.scenarios();
  }

  private int getDataProviderThreadCount() {
    String prop = System.getProperty("dataProviderThreadCount", "1");
    try {
      return Integer.parseInt(prop);
    } catch (NumberFormatException e) {
      return 1;
    }
  }

  /**
   * Before class.
   */
  @BeforeClass(alwaysRun = true)
  public void beforeClass() {
    String tag = System.getProperty("cucumber.filter.tags", "");
    log.info("Running tests with tag: {}", !tag.isEmpty() ? tag : "No tag filter applied");
  }

  /**
   * After clas.
   */
  @AfterClass(alwaysRun = true)
  public void afterClas() {
    ScenarioContext.clear();
  }

}