/**
 * Step definitions that implement high-level test steps.
 *
 * <p>Reusable, readable steps built on top of the DSL/actions layer, designed
 * to express business flows succinctly.</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>Given/When/Then-style step methods</li>
 *   <li>Argument parsing, defaults, and validation</li>
 *   <li>Bridges to {@code apis.middleware.dsl.actions}</li>
 * * </ul>
 *
 * @since 1.0
 */
package java.apis.middleware.stepDefs;