/**
 * Test lifecycle hooks and extensions.
 *
 * <p>Setup/teardown, before/after hooks, and environment adapters that integrate
 * the DSL with the middleware runtime and external systems.</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>Environment bootstrap and cleanup</li>
 *   <li>Per-scenario resource management</li>
 *   <li>Cross-cutting listeners and reporters</li>
 * </ul>
 *
 * @since 1.0
 */
package java.apis.middleware.hooks;