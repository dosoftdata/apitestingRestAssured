@mock
Feature: Mock API Test
  Background:
    Given url {{mockServerUrl}}
    And header Content-Type = application/json

  Scenario: Get payment
    When path api/payments/1234567890000
    And method GET
    Then status 200

  Scenario: Hello
    When path /api/greet
    And method GET
    Then status 200


