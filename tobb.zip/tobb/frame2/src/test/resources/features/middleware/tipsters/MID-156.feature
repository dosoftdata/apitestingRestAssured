@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-156 - Recommended Bets
  https://opapgr.atlassian.net/browse/MID-156
  user requests to get all the recommended betting selections for specific events.

  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When path uip/retail-sportsbook/api/v1.0/sports/selections/recommended

  Scenario Outline: MID-156-01 Recommended Bets landpage and View All
    And header channel = <channel>
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
      """
      {
         "code": 1000,
         "msg": "success",
         "source": "api-gateway",
         "data": { "events": "#array" },
          "time": "#number",
          "success": true,
          "failed": false
       }
      """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array",
            "marketCounts": "#object",
            "confidence": "#number"
          }
      """

    Examples:
      |testId           | location         | channel |
#      |  MID-156_01     |  rec_bets_land   |   R     |
#      |  MID-156-01     |  rec_bets_land   |   T     |
      |  MID-156-01     |  rec_bets_land   |   H     |
#      |  MID-156-01     |  rec_bets_land   |   I     |
#      |  MID-156-01     |  rec_bets_land   |   X     |
#      |  MID-156-01     |  rec_bets_land   |   M     |
#      |  MID-156-01     |  rec_bets_land   |   A     |
#      |  MID-156_01     |  rec_bets_all    |   R     |
#      |  MID-156-01     |  rec_bets_all    |   T     |
      |  MID-156-01     |  rec_bets_all    |   H     |
#      |  MID-156-01     |  rec_bets_all    |   I     |
#      |  MID-156-01     |  rec_bets_all    |   X     |
#      |  MID-156-01     |  rec_bets_all    |   M     |
#      |  MID-156-01     |  rec_bets_all    |   A     |

  Scenario: MID-156-02 Recommended Bets - Rest Sports - landpage
    And header channel = I
    And param location = rest_sports_rec_bets_land
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
      """
      {
         "code": 1000,
         "msg": "success",
         "source": "api-gateway",
         "data": { "events": "#array" },
          "time": "#number",
          "success": true,
          "failed": false
       }
      """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array",
            "marketCounts": "#object",
            "confidence": "#number"
          }
      """

  Scenario: MID-156-03 Recommended Bets - Rest Sports - view all
    And header channel = I
    And param location = rest_sports_rec_bets_land
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
      """
      {
         "code": 1000,
         "msg": "success",
         "source": "api-gateway",
         "data": { "events": "#array" },
          "time": "#number",
          "success": true,
          "failed": false
       }
      """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array",
            "marketCounts": "#object",
            "confidence": "#number"
          }
      """

  Scenario Outline: MID-156-04 - Recommended Bets - default channel
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
      """
      {
         "code": 1000,
         "msg": "success",
         "source": "api-gateway",
         "data": { "events": "#array" },
          "time": "#number",
          "success": true,
          "failed": false
       }
      """

    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array",
            "marketCounts": "#object",
            "confidence": "#number"
          }
      """
    Examples:
      |testId           | location         |
      |  MID-156-02     |  rec_bets_land   |
      |  MID-156-02     |  rec_bets_all    |


#  Scenario Outline: MID-156-05 - Recommended Bets - default channel - locationRecommendedSports
#    And param location = <location>
#    And param locationRecommendedSports = base
#   # And header channel = I
#    And header x-player-id = {{playerId}}
#    And retry GET  until condition {}
#    Then status 200
#    And match
#      """
#      {
#         "code": 1000,
#         "msg": "success",
#         "source": "api-gateway",
#         "data": { "events": "#array" },
#          "time": "#number",
#          "success": true,
#          "failed": false
#       }
#      """
#
#    And match each $.data.events[*] should match
#      """
#         {
#            "id": "#string",
#            "name": "#string",
#            "active": "#boolean",
#            "markets": "#array",
#            "marketCounts": "#object",
#            "confidence": "#number"
#          }
#      """
#    Examples:
#      |testId           | location               |
#      |  MID-156-02     |  rest_sport_bets_land  |
#      |  MID-156-02     |  rest_sport_bets_all   |

  Scenario Outline: MID-156-06 - Recommended Bets- missed location
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           | channel |
      |  MID-156-03     |  R      |

  Scenario Outline: MID-156-07 - Recommended Bets - missed player
    And param location = <location>
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'

    Examples:
      |testId           | location         | channel |
      |  MID-156-04     |  rec_bets_land   |  R      |