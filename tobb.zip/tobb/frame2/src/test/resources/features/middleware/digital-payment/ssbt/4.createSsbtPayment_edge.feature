@regression @digitalPaymentSSBT @digitalPayment
@epic:digital-payement-ssbt
Feature:[4] Edge Cases - Digital Payment - SSBT

  Background:
    When url {{middlewareHost}}
    And header Content-Type = application/json
    And header GUID = {{uuid}}
    When path ssbt/api/v1.0/digital-payment

  Scenario:[1] Create digital payment - no Auth
    And request
      """
      {
        "uuid": "{{uuid}}",
        "paymentDetails": {
          "totalAmount": {{amount}},
          "channelDetails": {
            "terminalId": "{{ssbtid}}",
            "retailerId": "{{retailerid}}"
          },
          "payments": [
            {
              "amount": {{amount}},
              "merchant": "TORA",
              "count": 1
            }
          ],
          "expiration": 0,
          "paymentProviderReferenceId": null,
          "paymentMethodType": "CARD"
        },
        "paymentType": "PURCHASE",
        "channel": "SSBT",
        "userId": "Test",
        "type": "PURCHASE"
      }
      """
    And method POST
    Then status 500
    And match response msg contains Cannot invoke


  Scenario:[2] Create digital payment
      And header Authorization = {{janusTokenType3}} {{janusToken3}}
      And request
      """
      {
        "uuid": "{{uuid}}",
        "paymentDetails": {
          "totalAmount": {{amount}},
          "channelDetails": {
            "terminalId": "{{ssbtid}}",
            "retailerId": "{{retailerid}}"
          },
          "payments": [
            {
              "amount": {{amount}},
              "merchant": "TORA",
              "count": 1
            }
          ],
          "expiration": 0,
          "paymentProviderReferenceId": null,
          "paymentMethodType": "CARD"
        },
        "paymentType": "PURCHASE",
        "channel": "SSBT",
        "userId": "Test",
        "type": "PURCHASE"
      }
      """
      And method POST
      Then status 401
      And match response msg contains Unauthorized


  Scenario:[4] Create digital payment - return not data url
    Given User has janus token
    And header Authorization = {{janusTokenType}} {{janusToken}}
    And request
      """
      {
        "uuid": "{{uuid}}",
        "paymentDetails": {
          "totalAmount": 100000000000,
          "channelDetails": {
            "terminalId": "{{ssbtid}}",
            "retailerId": "{{retailerid}}"
          },
          "payments": [
            {
              "amount": 1000000000000,
              "merchant": "TORA",
              "count": 1
            }
          ],
          "expiration": 0,
          "paymentProviderReferenceId": null,
          "paymentMethodType": "CARD"
        },
        "paymentType": "PURCHASE",
        "channel": "SSBT",
        "userId": "Test",
        "type": "PURCHASE"
      }
      """
    And method POST
    Then status 200
    And match response source = api-gateway
    And match response code = 1000
    And match response msg = success
    * def transactionId in response.data.transactionId

  Scenario:[5] Create digital payment - return not data url - null body
    And header Authorization = {{janusTokenType}} {{janusToken}}
    And request
      """
      {}
      """
    And method POST
    Then status 500
    And match response code = 1001
    And match response failed = true