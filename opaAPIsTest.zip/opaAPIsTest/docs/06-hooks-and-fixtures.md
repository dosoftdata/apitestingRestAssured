# 6. Hooks & Fixtures

This page covers the Cucumber lifecycle in `Hooks.java`, the dual-store design of `ScenarioContext`, and the **bootstrap fixture pattern** — how to set up expensive shared state once per JVM and have every consuming scenario read it cheaply.

---

## Navigation

- [Cucumber lifecycle (Hooks.java)](#lifecycle)
- **ScenarioContext — two stores, one class**
  - [Stores overview](#sc-overview)
  - [The mirroring pattern](#mirroring)
- **Bootstrap fixture pattern**
  - [When to use it](#bootstrap-when)
  - [Reference implementation: `PlayerBootstrap`](#playerbootstrap)
  - [Wiring it into Hooks](#wiring)
  - [Using it in features](#using-in-features)
- [Adding a new bootstrap fixture](#adding-bootstrap)
- [Caveats](#caveats)

---

<details id="lifecycle" open>
<summary><b>Cucumber lifecycle (Hooks.java)</b></summary>

```
JVM starts
   ↓
@BeforeAll  ─────────────────────────────────────────────────────┐
   │ • Start WireMock (singleton, ref-counted)                   │
   │ • Publish "mockServerUrl" to ScenarioContext.GLOBAL         │
   │                                                             │
For each scenario:                                               │
   │                                                             │
   ├─ @Before(order=0)  resetSpecAndSetScenarios                 │
   │     • ApiBase.spec().reset()                                │
   │     • ScenarioContext.sc.set(scenario)                      │
   │     • ConfigLoader.loadConfig()       (idempotent, JVM-once)│
   │     • mirrorGlobals(BASE_GLOBALS)     ← copies "mockServerUrl"
   │                                                             │
   ├─ @Before(value="@needsPlayer", order=1)  ensurePlayerBootstrap
   │     • PlayerBootstrap.registerOnce()  (idempotent, JVM-once)│
   │     • mirrorGlobals(PLAYER_GLOBALS)   ← copies playerId, csrftoken, etc.
   │                                                             │
   ├─ Steps run                                                  │
   │                                                             │
   └─ @After(order=Integer.MAX_VALUE)  after                     │
         • Log scenario name if failed                           │
                                                                 │
JVM shuts down                                                   │
   ↓                                                             │
@AfterAll  ──────────────────────────────────────────────────────┘
   • WireMockFactoryOnce.release()  (decrements ref count, stops at 0)
```

</details>

<details id="sc-overview">
<summary><b>ScenarioContext — two stores, one class</b></summary>

```java
// Per-scenario  (ThreadLocal<Map<String, Object>>)
ScenarioContext.set(key, value);
Object v = ScenarioContext.get(key);
String s = ScenarioContext.resolve("Hello {{name}}");   // placeholder substitution

// Global  (ConcurrentHashMap<String, Object>)
ScenarioContext.putIfAbsentGlobal(key, value);          // write-once semantics
String url = ScenarioContext.getGlobal("mockServerUrl", String.class);
```

| Store | Backing | Lifetime | Visible to placeholders? |
|---|---|---|---|
| Per-scenario | `ThreadLocal<HashMap>` | per worker thread (no `clear()` between scenarios) | yes — `{{key}}` and `#(key)` both resolve from here |
| Global | `ConcurrentHashMap` | entire JVM | **no** — must be mirrored into per-scenario context |

</details>

<details id="mirroring">
<summary><b>The mirroring pattern</b></summary>

`Hooks.@Before` copies select global keys into the current scenario's per-scenario map:

```java
private static final String[] BASE_GLOBALS = { "mockServerUrl" };

private static final String[] PLAYER_GLOBALS = {
    "randomMSISDN", "web-x-csrftoken", "otpUuid", "playerId", "username",
    "x-csrftoken", "mailHash", "hashId"
};

@Before(order = 0)
public void resetSpecAndSetScenarios(Scenario scenario) {
    ApiBase.spec().reset();
    ScenarioContext.sc.set(scenario);
    ConfigLoader.loadConfig();
    mirrorGlobals(BASE_GLOBALS);
}

@Before(value = "@needsPlayer", order = 1)
public void ensurePlayerBootstrap() {
    PlayerBootstrap.registerOnce();
    mirrorGlobals(PLAYER_GLOBALS);
}

private static void mirrorGlobals(String[] keys) {
    for (String key : keys) {
        Object v = ScenarioContext.getGlobal(key, Object.class);
        if (v != null) ScenarioContext.set(key, v);
    }
}
```

</details>

<details id="bootstrap-when">
<summary><b>Bootstrap fixture pattern — when to use it</b></summary>

When a setup is:
- **Expensive** (multi-step API flow, 60+ second wait)
- **Shared** across many scenarios
- **Idempotent in concept** (the result is the same no matter which scenario triggers it)

…then putting it in a feature file means N×cost for N scenarios, plus they collide on shared resources (e.g., trying to register the same MSISDN twice).

The pattern: **lift it into a static Java class, gate it behind a tag, run once per JVM**.

</details>

<details id="playerbootstrap">
<summary><b>Reference implementation: <code>PlayerBootstrap</code></b></summary>

`src/main/java/apis/middleware/bootstrap/PlayerBootstrap.java`

```java
public final class PlayerBootstrap {
    private static final AtomicBoolean STARTED = new AtomicBoolean(false);

    public static void registerOnce() {
        if (!STARTED.compareAndSet(false, true)) return;     // first caller wins

        // 10-step flow:
        // 1. OTP create #1 (expect 403, capture csrftoken)
        // 2. OTP create #2 with csrftoken (capture otpUuid)
        // 3. OTP verify (PUT, expect 204)
        // 4. Register player (capture playerId, username)
        // 5. BO login #1 (expect 403, capture BO csrftoken)
        // 6. BO login #2 with csrftoken
        // 7. Wait 60s for registration email
        // 8. Fetch email list, capture mailHash
        // 9. Fetch email body, regex-extract verification hash
        // 10. POST /web/customer/rest/v1/verifications/email

        // Publish all results to GLOBAL
        ScenarioContext.putIfAbsentGlobal("playerId",        playerId);
        ScenarioContext.putIfAbsentGlobal("username",        username);
        ScenarioContext.putIfAbsentGlobal("web-x-csrftoken", webCsrf);
        // ...
    }
}
```

Key properties:
- **`AtomicBoolean STARTED.compareAndSet(false, true)`** — exactly one thread wins; rest no-op.
- **Uses `ApiBase.spec()`** — same Allure tracing, same SSL config as scenario calls.
- **Uses Lombok `@Builder` POJOs** for request bodies (private static nested classes, lift to `models/` if reused).
- **Reads JSON bodies via `getString("body")`**, NOT `asString()` — the latter returns raw JSON with `\"` escapes that break regex extraction (a real bug we hit and fixed).

</details>

<details id="wiring">
<summary><b>Wiring it into Hooks</b></summary>

```java
@Before(value = "@needsPlayer", order = 1)
public void ensurePlayerBootstrap() {
    PlayerBootstrap.registerOnce();
    mirrorGlobals(PLAYER_GLOBALS);
}
```

The `value = "@needsPlayer"` is a Cucumber tag expression. The hook fires **only** for scenarios carrying that tag. Tag expressions support `or` / `and` / `not`:

```java
@Before(value = "@needsPlayer or @needsRegisteredPlayer", order = 1)
```

</details>

<details id="using-in-features">
<summary><b>Using it in features</b></summary>

```gherkin
@needsPlayer
Scenario: Place a bet for the registered player
  Given url {{psMiddlewareHost}}
  And path /uip/sportsbook/api/v1.0/bets
  And header x-player-id = {{playerId}}
  And request """{ "amount": 5 }"""
  When method POST
  Then status 200
```

Behavior matrix:

| Scenario tagged `@needsPlayer`? | Behavior |
|---|---|
| No | Bootstrap is **skipped** entirely |
| Yes — first one in the run | Bootstrap fires (~70+ seconds: OTP+register+email-verify) |
| Yes — subsequent ones | `STARTED.compareAndSet` short-circuits; only `mirrorGlobals` runs (microseconds) |

</details>

<details id="adding-bootstrap">
<summary><b>Adding a new bootstrap fixture</b></summary>

Use `PlayerBootstrap` as a template:

1. Create `src/main/java/apis/middleware/bootstrap/<NameBootstrap>.java`:
   ```java
   public final class AdminTokenBootstrap {
       private static final AtomicBoolean STARTED = new AtomicBoolean(false);

       public static void runOnce() {
           if (!STARTED.compareAndSet(false, true)) return;

           // ... acquire admin token ...
           ScenarioContext.putIfAbsentGlobal("adminToken", token);
       }
   }
   ```
2. Pick a tag, e.g., `@needsAdmin`.
3. Add to `Hooks.java`:
   ```java
   private static final String[] ADMIN_GLOBALS = { "adminToken" };

   @Before(value = "@needsAdmin", order = 1)
   public void ensureAdminToken() {
       AdminTokenBootstrap.runOnce();
       mirrorGlobals(ADMIN_GLOBALS);
   }
   ```
4. Tag the scenarios that need it:
   ```gherkin
   @needsAdmin
   Scenario: Admin can list users
   ```

</details>

<details id="caveats">
<summary><b>Caveats</b></summary>

1. **Failure of a bootstrap = whole suite fails.** Bootstraps run on the first relevant scenario's `@Before`; if they throw, that scenario fails, and `STARTED` is still `true` so subsequent scenarios skip the work but their `mirrorGlobals` finds nothing → they fail too. This is intentional: don't pretend the suite passed when setup is broken.

2. **Parallel execution caveat.** `ConfigLoader.loaded` is a JVM-static `boolean`, and `ScenarioContext.set` is `ThreadLocal`. With Failsafe `parallel=classes` and multiple worker threads, only **one** thread evaluates `config.js`, and the values land in **that thread's** `ThreadLocal`. Other threads see empty per-scenario maps. **This means parallel scenario execution is currently broken** for the `set/get` pattern — it relies on single-threaded glue. Either pin the runner to one thread, or make `ConfigLoader` write to `GLOBAL` and have hooks mirror everything per-scenario.

3. **The framework is feature-scoped, not scenario-scoped — state persists across scenarios by design.** A feature describes one HTTP flow; the scenarios inside it are the ordered steps of that flow. Scenario 2 routinely consumes a `def token`/`def id` set in scenario 1. `Hooks` deliberately does **not** call `ScenarioContext.clear()` between scenarios so this chaining works. Mirrored globals stick around as a side effect. If you ever add `clear()`, you will break working features and also need to re-run `mirrorGlobals` in `@Before`. If two scenarios that shouldn't share state are clashing, the right move is to split them into separate features, not to clear context.

</details>
