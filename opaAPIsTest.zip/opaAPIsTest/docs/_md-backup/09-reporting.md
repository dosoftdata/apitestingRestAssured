# 9. Reporting

The framework produces three independent report streams:

| Report | Source | Audience |
|---|---|---|
| **Allure HTML** | RestAssured calls + Cucumber lifecycle filters | Developers — full request/response, attachments, history, trends |
| **JUnit XML** | Maven Failsafe | GitLab merge-request widget, CI tooling |
| **Surefire/Failsafe HTML** | Maven Failsafe `report` mojo | Quick local glance, embedded in `reports/site/` |

---

## Navigation

- **Allure (primary report)**
  - [What's captured](#allure-captured)
  - [Where it lives](#allure-lives)
  - [Generating locally](#allure-local)
  - [Useful Allure labels](#allure-labels)
- [JUnit XML (GitLab integration)](#junit)
- [Surefire/Failsafe HTML (lightweight)](#surefire-html)
- [Cross-referencing reports](#cross-ref)
- [Local debugging workflow](#local-debug)
- [Customization](#customization)

---

<details id="allure-captured" open>
<summary><b>Allure — what's captured</b></summary>

Every request that goes through `ApiBase.spec()` is filtered by `AllureRequestResponseFilter`. For each scenario you get:

- The complete **request** (URL, headers, cookies, body — JSON-pretty-printed)
- The complete **response** (status, headers, body)
- **Step boundaries** matching the Gherkin lines
- **Attachments** (e.g., screenshots, files, custom logs)
- **Step duration** and **assertion failures** with full stack
- **Tags** (`@smoke`, `@needsPlayer`, etc.) propagated as Allure labels — drives filtering in the UI

</details>

<details id="allure-lives">
<summary><b>Allure — where it lives</b></summary>

| Path | Contents |
|---|---|
| `reports/` | Raw Allure JSON results (one `*-result.json` per scenario, plus attachments) |
| `reports/site/` | Generated HTML (only after explicit `allure generate` or via a Maven `verify` execution) |

</details>

<details id="allure-local">
<summary><b>Allure — generating locally</b></summary>

```powershell
# Quickest — open in a temp web server
allure serve reports

# Or generate static HTML
allure generate reports --clean -o reports/site
# → open reports/site/index.html
```

In CI the `reports/site/` HTML is published as a GitLab Pages artifact (see [CI/CD](08-cicd.md)).

</details>

<details id="allure-labels">
<summary><b>Useful Allure labels</b></summary>

The `Hooks` class includes an `epicCounter()` helper (in `DslHelper`) that promotes `@epic:<name>` Cucumber tags into Allure **Epic** labels:

```gherkin
@epic:Sportsbook
Feature: Place a bet
```

Result: scenarios in this feature appear under the *Sportsbook* epic in Allure's *Behaviours* view.

</details>

<details id="junit">
<summary><b>JUnit XML (GitLab integration)</b></summary>

Failsafe writes one XML per `IT` test class to `failsafe-reports/`. Configuration in `pom.xml`:

```xml
<plugin>
    <artifactId>maven-failsafe-plugin</artifactId>
    <configuration>
        <reportsDirectory>${project.basedir}/failsafe-reports</reportsDirectory>
        <redirectTestOutputToFile>true</redirectTestOutputToFile>
        ...
    </configuration>
</plugin>
```

`redirectTestOutputToFile=true` is the **key setting**: stdout/stderr go to `failsafe-reports/<TestClass>-output.txt` instead of being embedded as `<system-out>` blocks in the XML. Without this, request/response logs balloon the XML past GitLab's **30 MB parse limit** and the merge-request *Test Summary* widget shows a broken state.

In `.gitlab-ci.yml`:
```yaml
artifacts:
  paths: [${repo_name}/failsafe-reports]      # picks up XML + TXT
  reports:
    junit: [${repo_name}/failsafe-reports/*.xml]
```

The XML feeds GitLab's MR widget; the captured TXT files ride along as ordinary artifacts.

</details>

<details id="surefire-html">
<summary><b>Surefire/Failsafe HTML (lightweight)</b></summary>

`mvn verify` produces a basic HTML site under `reports/site/` (different from the Allure-generated one). It's included in artifacts and via GitLab Pages, but most teams default to Allure for analysis.

</details>

<details id="cross-ref">
<summary><b>Cross-referencing reports</b></summary>

In CI, every pipeline run typically yields:

| Where to look | What you get |
|---|---|
| **Merge-request page** (Test Summary widget) | Pass/fail counts, failing-test list with stack traces |
| **Pipeline page → Job artifacts** | Browse the full `failsafe-reports/`, `reports/site/`, and `*-output.txt` files |
| **GitLab Pages URL** | Live HTML report (Allure or Surefire site, whichever was copied to `public/`) |

</details>

<details id="local-debug">
<summary><b>Local debugging workflow</b></summary>

1. Run a small subset locally:
   ```powershell
   mvn clean install -Denv=uat "-Dcucumber.filter.tags=@MyFlakyTag" -Dthread.count=1
   ```
2. If a step fails, RestAssured's `enableLoggingOfRequestAndResponseIfValidationFails()` (set in `ApiBase` static block) prints the offending request/response to stdout — **redirected to `failsafe-reports/<class>-output.txt`** because of the redirect-output flag.
3. Open the Allure report:
   ```powershell
   allure serve reports
   ```
   Find the failing scenario, expand the failing step, see request/response side-by-side.
4. If you need the raw JSON results (e.g., to diff between runs), they're under `reports/*-result.json`.

</details>

<details id="customization">
<summary><b>Customization</b></summary>

- **Add custom attachments** with `Allure.addAttachment(name, content)` from inside a step def.
- **Add categories** (categorize failures as "Product Defect", "Test Defect", "Environment Issue") via `reports/categories.json`.
- **Add executor info** via `reports/executor.json` to display CI run metadata in the report.

See the official Allure docs at <https://allurereport.org/docs/>.

</details>
