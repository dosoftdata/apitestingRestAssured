# 10. Troubleshooting

A reference for the most common failure modes — what they look like, why they happen, and how to fix them.

---

## Navigation

- **CI / GitLab**
  - [GitLab Test summary failed to load — 30 MB cap](#issue-junit-cap)
  - [MR shows 'Checking pipeline status' forever](#issue-mr-spinning)
  - [Pipeline doesn't run on push at all](#issue-no-pipeline)
  - [Push to develop runs full regression instead of smoke](#issue-wrong-scope)
- **Test data / context**
  - [`{{playerId}}` (or any placeholder) resolves to empty](#issue-empty-placeholder)
  - [Bootstrap registers a player, but email-verify returns 400](#issue-bad-hash)
  - [Two scenarios share state in unexpected ways](#issue-state-leak)
- **Runtime / environment**
  - [Test fails locally but passes in CI (or vice versa)](#issue-flaky-env)
  - [Cucumber: No backend could find a step definition for...](#issue-no-step-def)
  - [WireMock port conflict on a CI worker](#issue-port-conflict)
  - [Bootstrap takes >70 seconds and times out](#issue-bootstrap-timeout)
- **Reporting**
  - [Allure report is missing requests / shows 'No data'](#issue-allure-empty)
- **Build / JDK**
  - [`mvn test` doesn't run any tests](#issue-mvn-test)
  - [Java version mismatch](#issue-jdk)
- [When you're stuck](#stuck)

---

## CI / GitLab

<details id="issue-junit-cap">
<summary><b>"GitLab: Test summary failed to load results — XML must be less than 30 MB"</b></summary>

| Symptom | Stack trace not the issue — GitLab MR widget shows error banner |
|---|---|
| **Cause** | Failsafe embedded full stdout/stderr in `<system-out>` blocks; with RestAssured logging it can balloon past 30 MB. |
| **Fix** | Already applied: `<redirectTestOutputToFile>true</redirectTestOutputToFile>` in `pom.xml`'s `maven-failsafe-plugin` config. Captured logs go to `failsafe-reports/<TestClass>-output.txt`. |
| **If it persists** | Shard the test run (multiple `*IT.java` runners) so you get N smaller XMLs; or `<trimStackTrace>true</trimStackTrace>`; or post-process to strip `<system-out>` before publish. |

</details>

<details id="issue-mr-spinning">
<summary><b>"MR shows 'Checking pipeline status' forever"</b></summary>

| Symptom | After opening an MR, the merge button is blocked and status spins indefinitely |
|---|---|
| **Cause** | Project setting *Settings → Merge requests → "Pipelines must succeed"* is enabled, but the workflow rules return `when: never` for that MR — no pipeline is ever created → GitLab waits forever. |
| **Fix** | Either: (a) uncheck "Pipelines must succeed" if you don't need MR-gating; or (b) ensure the workflow rules let the MR run a (lightweight) pipeline so GitLab has something to consume. |

</details>

<details id="issue-no-pipeline">
<summary><b>"Pipeline doesn't run on push at all"</b></summary>

| Symptom | Push to a branch produces no pipeline |
|---|---|
| **Cause** | Either the workflow rules block the source/branch combo, or `.gitlab-ci.yml` is at a non-default path and the project's *CI/CD configuration file* setting wasn't updated. |
| **Fix** | Check *Settings → CI/CD → General pipelines → "CI/CD configuration file"* — should be `devops/.gitlab-ci.yml`. Then validate the workflow rules in [CI/CD](08-cicd.md). |

</details>

<details id="issue-wrong-scope">
<summary><b>"Push to develop runs full regression instead of smoke"</b></summary>

| Symptom | Pipeline triggered by post-merge push to `develop` runs the full suite |
|---|---|
| **Cause** | The workflow rule that overrides `tag: "@smoke"` for push events is missing or misordered. |
| **Fix** | Verify `.gitlab-ci.yml` matches the matrix in [CI/CD](08-cicd.md). The rule order matters — first match wins. |

</details>

## Test data / context

<details id="issue-empty-placeholder">
<summary><b>"<code>{{playerId}}</code> (or any other placeholder) resolves to empty string"</b></summary>

| Symptom | Request body shows `"playerId": ""` or URL contains `id=` with no value |
|---|---|
| **Cause** | Either the global wasn't published yet (e.g., `PlayerBootstrap` didn't run) or `Hooks.@Before` didn't mirror it into per-scenario context. |
| **Fix** | Confirm: (1) the scenario carries `@needsPlayer` so the bootstrap fires; (2) the placeholder name is in `Hooks.PLAYER_GLOBALS` so it gets mirrored. If neither matches, you've added a new global — extend the appropriate array in `Hooks.java`. |

</details>

<details id="issue-bad-hash">
<summary><b>"Bootstrap registers a player, but email-verify returns 400 INVALID_VERIFICATION_TOKEN"</b></summary>

| Symptom | Steps 1–9 succeed; step 10 (email verify) fails with 400 |
|---|---|
| **Cause** | The hash extracted from the email body has a trailing escape character (e.g., `…ef84b6e55f49\`). Happens if you pull the email body via `extract().asString()` (raw JSON with `\"` escapes) and then regex on it — the regex stops at `"` and includes the preceding `\`. |
| **Fix** | Already applied: `extract().body().jsonPath().getString("body")` in `PlayerBootstrap.java`. JSON gets parsed first, the regex sees decoded HTML, and the hash comes out clean. |

</details>

<details id="issue-state-leak">
<summary><b>"Two scenarios share state in unexpected ways"</b></summary>

| Symptom | Scenario B reads a `def` value set by scenario A |
|---|---|
| **Cause** | `ScenarioContext.set` is `ThreadLocal`, and `Hooks` does **not** call `ScenarioContext.clear()` between scenarios. On the same worker thread, the per-scenario map persists. This is intentional for mirrored globals, but exposes you to leakage of scenario-local `def`s. |
| **Fix** | If you genuinely need isolation, add `ScenarioContext.clear()` to a new `@After` and re-mirror globals in `@Before` *after* the clear. **Be careful**: the existing `mirrorGlobals` is in `@Before`, so clearing in `@After` is safer than clearing in `@Before`. |

</details>

## Runtime / environment

<details id="issue-flaky-env">
<summary><b>"Test fails locally but passes in CI (or vice versa)"</b></summary>

| Symptom | Inconsistent results across runs |
|---|---|
| **Likely causes** | (1) Different `env` — local hitting `dev`, CI hitting `uat`. Check `-Denv` value. (2) Stale Maven cache — `mvn clean install -U` to force re-resolve. (3) Time-sensitive test data: `config.js` evaluates once per JVM; `{{timestamp}}` is fixed for the run. (4) Random data collisions: `{{pam.$random8Digit}}` is stable per-JVM, so re-runs reuse the same MSISDN — second run might fail because the player already exists. |
| **Fix** | Restart the JVM (= rerun `mvn clean install`) to refresh random values. For genuine flakes, tag `@flaky` and exclude from gating runs. |

</details>

<details id="issue-no-step-def">
<summary><b>"Cucumber error: 'No backend could find a step definition for...'"</b></summary>

| Symptom | Test fails immediately with a step-not-defined error |
|---|---|
| **Cause** | The DSL phrase doesn't match any registered step regex. Common reasons: typo, wrong word order, missing parameter capture. |
| **Fix** | Compare your line against `CommonSteps.java` / `OneTimeSteps.java`. The Cucumber error message includes a snippet you can paste into a step def stub. If a step is missing entirely, add it to `oneRowSpecSteps.java` (or a new step-defs file in `apis.middleware.stepDefs`). See [Step Definitions](05-step-definitions.md). |

</details>

<details id="issue-port-conflict">
<summary><b>"WireMock port conflict on a CI worker"</b></summary>

| Symptom | `BindException: Address already in use` |
|---|---|
| **Cause** | Two pipelines on the same runner concurrently, or a previous run didn't release. |
| **Fix** | `WireMockFactoryOnce` uses `dynamicPort()` so this should be rare. If it happens: confirm `release()` is called in `@AfterAll`. Restarting the GitLab runner clears stuck processes. |

</details>

<details id="issue-bootstrap-timeout">
<summary><b>"Bootstrap takes >70 seconds and times out"</b></summary>

| Symptom | First `@needsPlayer` scenario takes a long time, possibly fails on a network timeout |
|---|---|
| **Cause** | `PlayerBootstrap` includes a hard `Thread.sleep(60_000)` between registration and email-fetch, mirroring the feature file's `delay request 60000`. The 60s wait is for the registration email to arrive in the BO mailbox. |
| **Fix** | Don't reduce the 60s without verifying with the email backend team — emails can take that long. If your environment has faster mail delivery, you could replace the `sleep` with an `awaitUntil`-style poll on the email-list endpoint. |

</details>

## Reporting

<details id="issue-allure-empty">
<summary><b>"Allure report is missing requests / shows 'No data'"</b></summary>

| Symptom | Scenarios ran, but the Allure report is empty or shows no request/response detail |
|---|---|
| **Causes** | (a) Step def used raw `RestAssured.given()` instead of `ApiBase.spec()` — bypassed the Allure filter. (b) `reports/` directory wasn't passed through to `allure generate`. (c) RestAssured response was consumed without going through `.then().extract()` (rare). |
| **Fix** | Always go through `ApiBase.spec()`. Check that `reports/*-result.json` files exist before running `allure serve reports`. |

</details>

## Build / JDK

<details id="issue-mvn-test">
<summary><b>"<code>mvn test</code> doesn't run any tests"</b></summary>

| Symptom | `mvn test` finishes in seconds; says "Tests run: 0" |
|---|---|
| **Cause** | This project's tests are integration tests (file naming `*IT.java`), bound to the `verify` phase via Failsafe — not the `test` phase via Surefire. Surefire is explicitly configured with `<skipTests>true</skipTests>`. |
| **Fix** | Use `mvn install` or `mvn verify` instead of `mvn test`. |

</details>

<details id="issue-jdk">
<summary><b>"Java version mismatch"</b></summary>

| Symptom | Compile errors about `--enable-native-access`, missing methods, or `unsupported class file major version` |
|---|---|
| **Cause** | JDK other than 17 in use. The `argLine` includes `--enable-native-access=ALL-UNNAMED` (Java 17 syntax), and dependencies target 17. |
| **Fix** | `java -version` must show 17.x. Set `JAVA_HOME` accordingly. On Windows: `setx JAVA_HOME "C:\Program Files\Java\jdk-17"` then restart shell. |

</details>

<details id="stuck">
<summary><b>When you're stuck</b></summary>

1. **Check the most recent successful CI run** for the same branch — diff your local changes against what CI ran.
2. **Read the Allure report** in detail — request/response side-by-side often reveals the issue.
3. **Try `-Dthread.count=1`** to rule out parallelism issues.
4. **Try `mvn clean install -U`** to refresh dependencies and re-evaluate the build.
5. **Check `failsafe-reports/<TestClass>-output.txt`** — captured stdout often includes more context than the JUnit XML.

</details>
