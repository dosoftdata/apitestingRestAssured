# 1. Overview

---

## Navigation

- [What this project is](#what-this-project-is)
- [Tech stack](#tech-stack)
- [Design philosophy — Karate-style DSL](#design-philosophy)
- [Source layout convention](#source-layout)
- [What you can do with it](#what-you-can-do)
- [What this framework deliberately does NOT do](#non-goals)

---

<details id="what-this-project-is" open>
<summary><b>What this project is</b></summary>

An end-to-end API testing framework for OPAP/Allwyn middleware services. It runs Gherkin feature files against the real APIs (UAT/preprod) or against a local mock (WireMock), produces Allure + JUnit reports, and is wired into GitLab CI.

</details>

<details id="tech-stack">
<summary><b>Tech stack</b></summary>

| Layer | Choice | Version |
|---|---|---|
| Language | Java | 17 |
| BDD | Cucumber-JVM | 7.30.0 |
| Test runner | TestNG (via `AbstractTestNGCucumberTests`) | 7.8.0 |
| HTTP client | RestAssured | 5.5.6 |
| Reporting | Allure | 2.30.0 |
| Codegen | Lombok | 1.18.38 |
| Mocking | WireMock | (singleton, dynamic port) |
| Config eval | Nashorn (JavaScript on JVM) | OpenJDK Nashorn |
| Async | Awaitility | 4.2.0 |
| Build | Maven Failsafe | 3.5.4 |
| Logging | Log4j2 | 2.20.0 |

</details>

<details id="design-philosophy">
<summary><b>Design philosophy — Karate-style DSL</b></summary>

This is **not** plain Cucumber. The framework borrows the Karate idea: feature files express **what** happens (URL, headers, body, expected status, response captures) without imperative step definitions per scenario.

What that means in practice:

- **Feature files** read like API call scripts:
  ```gherkin
  Given url {{middlewareHost}}
  And path /uip/sportsbook/api/v1.0/bets
  And header Authorization = Bearer {{janusToken}}
  And request """{ "amount": 10 }"""
  When method POST
  Then status 200
  And def betId in response.id
  ```

- **Step definitions** are reusable building blocks (`url`, `path`, `header`, `request`, `method`, `def`, `match`, ...) defined once in `src/main/java/apis/middleware/dsl/actions/CommonSteps.java` and `OneTimeSteps.java`. You rarely write new step defs — you write features.

- **Variables flow** through `ScenarioContext`. Placeholders `{{var}}` and `#(var)` resolve at step execution time.

</details>

<details id="source-layout">
<summary><b>Source layout convention</b></summary>

Unlike vanilla Cucumber:

- `src/main/java/...` — the DSL itself (step defs, helpers, models, config loader)
- `src/test/...` — feature files, hooks, runner, test resources

This is **intentional**: it lets the DSL be packaged and reused by other test repositories, while keeping concrete features and runners isolated. See [Architecture](02-architecture.md) for the full picture.

</details>

<details id="what-you-can-do">
<summary><b>What you can do with it</b></summary>

| Goal | How |
|---|---|
| Add a new test | Write a new `.feature` file under `src/test/resources/features/<domain>/` |
| Add a domain-specific helper step | Add a method to `oneRowSpecSteps.java` or create a new step-defs class |
| Run against a different environment | `-Denv=dev|uat|preprod|local` |
| Run a subset | `-Dcucumber.filter.tags="@smoke and not @flaky"` |
| Mock an external dependency | Add a JSON file under `src/test/resources/wiremock/mappings/` |
| One-time setup (e.g., register a player) | See [Hooks & Fixtures](06-hooks-and-fixtures.md) — `PlayerBootstrap` pattern |

</details>

<details id="non-goals">
<summary><b>What this framework deliberately does NOT do</b></summary>

- **It is not a unit-test framework.** Use JUnit/TestNG directly for that.
- **It does not run UI tests.** No Selenium / Playwright / Karate UI extensions.
- **It does not stub HTTP itself by default.** WireMock is opt-in via specific feature paths.
- **It does not generate test code from OpenAPI specs.** Specs live in feature files, hand-written.

</details>
