# 2. Architecture

---

## Navigation

- [Source layout](#source-layout)
- [Component diagram (high level)](#component-diagram)
- **Component responsibilities**
  - [`ApiBase` & `CustomRequestSpec`](#apibase)
  - [`ConfigLoader`](#configloader)
  - [`ScenarioContext`](#scenariocontext)
  - [`Hooks`](#hooks)
  - [`JsonMatcher`](#jsonmatcher)
  - [`WireMockFactoryOnce`](#wiremock)
- [Lifecycle of a single scenario](#scenario-lifecycle)
- [Key design decisions](#design-decisions)

---

<details id="source-layout">
<summary><b>Source layout</b></summary>

```
apis.middleware/
├── pom.xml                    Maven build, Failsafe runner, dependency versions
├── devops/.gitlab-ci.yml      Pipeline definition (smoke/regression rules, cache)
├── docs/                      This documentation
│
├── src/main/java/apis/middleware/
│   ├── bootstrap/             One-time JVM fixtures (e.g., PlayerBootstrap)
│   ├── config/                ConfigLoader (Nashorn evaluator for config.js)
│   ├── core/
│   │   ├── base/              ApiBase, CustomRequestSpec, ApiSpecsMap
│   │   ├── filters/           Allure request/response filter, dedup, latency
│   │   └── helpers/           WireMockFactoryOnce
│   ├── dsl/
│   │   ├── ScenarioContext.java       Per-scenario + global state
│   │   ├── JsonMatcher.java           Custom matcher engine ($.path, #marker, deep)
│   │   ├── DslUtils.java              String/path/parse helpers
│   │   └── actions/                   The DSL itself
│   │       ├── CommonSteps.java       Stateful steps (work on context.spec)
│   │       ├── OneTimeSteps.java      Reset-spec-each-call steps
│   │       └── DslHelper.java         Base class for step-def classes
│   ├── models/                Lombok DTOs for request/response payloads
│   ├── testData/              Test data generators, repository, CSV utilities
│   └── utilities/             RandomUtil, TimestampUtil, CSV read/write
│
└── src/test/
    ├── apis/middleware/
    │   ├── hooks/Hooks.java           Cucumber lifecycle (Before/After)
    │   ├── runners/CliIT.java         TestNG/Cucumber entry point
    │   └── stepDefs/                  Domain-specific step definitions
    │       ├── oneRowSpecSteps.java
    │       └── janusOneRowSpecSteps.java
    └── resources/
        ├── config.js                  Per-environment configuration (Nashorn)
        ├── features/                  Gherkin feature files, organized by domain
        │   ├── middleware/
        │   │   ├── digital-payment/
        │   │   ├── sportsbook/
        │   │   ├── casino/
        │   │   ├── opta/
        │   │   ├── tipsters/
        │   │   └── worldCup/
        │   ├── PAM/
        │   └── placeBets/
        └── wiremock/
            ├── mappings/              Stub definitions (JSON)
            └── __files/               Mock response bodies
```

</details>

<details id="component-diagram">
<summary><b>Component diagram (high level)</b></summary>

```
                  ┌──────────────────────────────────┐
                  │   src/test/resources/features/   │
                  │       *.feature  (Gherkin)       │
                  └────────────┬─────────────────────┘
                               │ scanned by
                               ▼
   ┌──────────────────────┐    glue=  ┌──────────────────────────────┐
   │  CliIT.java          │──────────▶│  CommonSteps + OneTimeSteps  │
   │  (TestNG runner)     │           │  + stepDefs.* classes        │
   │  Allure plugin       │           └────────────┬─────────────────┘
   └──────────┬───────────┘                        │ uses
              │ Cucumber lifecycle                 ▼
              ▼                            ┌────────────────┐
   ┌──────────────────────┐                │  ApiBase.spec()│
   │  Hooks.java          │                │  CustomReqSpec │
   │  @BeforeAll WireMock │                │  + Allure flt  │
   │  @Before  config+    │                └────────┬───────┘
   │           mirror     │                         │ HTTP via
   │  @AfterAll release   │                         ▼
   └──────────┬───────────┘                ┌────────────────┐
              │ writes/reads               │   RestAssured  │
              ▼                            └────────────────┘
   ┌──────────────────────┐
   │ ScenarioContext      │
   │ - ThreadLocal map    │ ◀──── used by all step defs to read/write state
   │ - GLOBAL map         │ ◀──── written once (config, bootstrap fixtures)
   └──────────────────────┘
```

</details>

## Component responsibilities

<details id="apibase">
<summary><b><code>ApiBase</code> &amp; <code>CustomRequestSpec</code></b></summary>

A thin wrapper around RestAssured. `ApiBase.spec()` returns a fresh `CustomRequestSpec` with the Allure filter pre-attached. All step defs go through this so every HTTP call appears in Allure reports.

</details>

<details id="configloader">
<summary><b><code>ConfigLoader</code></b></summary>

Loads `src/test/resources/config.js` once per JVM via Nashorn, walks the resulting object graph, and writes flattened keys (`pam.webBaseUrl`, `janus.baseUrl`, ...) into `ScenarioContext`. See [Configuration](03-configuration.md).

</details>

<details id="scenariocontext">
<summary><b><code>ScenarioContext</code></b></summary>

Two stores in one class:
- **Per-scenario** (`ThreadLocal<Map<String, Object>>`) — written by step defs (`def`, `defResponse`, etc.); read by the `{{var}}` placeholder resolver.
- **Global** (`ConcurrentHashMap<String, Object>`) — written once during `@BeforeAll` (mock URL) or via `PlayerBootstrap.registerOnce()`; mirrored into per-scenario context by `Hooks.@Before`.

</details>

<details id="hooks">
<summary><b><code>Hooks</code></b></summary>

Cucumber lifecycle:
- `@BeforeAll` — start WireMock once per worker (ref-counted), publish `mockServerUrl` globally.
- `@Before(order=0)` — reset spec, set scenario, load config, mirror `BASE_GLOBALS` (always).
- `@Before(value="@needsPlayer", order=1)` — invoke `PlayerBootstrap.registerOnce()`, mirror `PLAYER_GLOBALS` (only if scenario tagged).
- `@After` — log failures.
- `@AfterAll` — release WireMock.

</details>

<details id="jsonmatcher">
<summary><b><code>JsonMatcher</code></b></summary>

Custom assertion engine used by `match response`, `match each`, `match string`, etc. Supports:
- `#string`, `#number`, `#boolean`, `#null`, `#notnull`, `#empty`, `#array`, `#date`, `#regex`, `#size`, `#min`, `#max`, ...
- JSONPath conditions: `$.field = value`, `$.field > 10`, `$.field contains foo`, `$.field exists`
- Deep-tree comparison with `"..."` wildcards to ignore subtrees.

</details>

<details id="wiremock">
<summary><b><code>WireMockFactoryOnce</code></b></summary>

Singleton WireMock server, ref-counted. Started lazily, on a dynamic port; mappings under `src/test/resources/wiremock/mappings/`, response files under `__files/`. Response templating is enabled (`{{request.body...}}` etc. inside stubs).

</details>

<details id="scenario-lifecycle">
<summary><b>Lifecycle of a single scenario</b></summary>

```
mvn ... test
  ↓
Failsafe loads CliIT (TestNG runner)
  ↓
Cucumber discovers features under classpath:features
  ↓
For each scenario:
    ├─ Hooks.@Before(order=0):
    │     • ApiBase.spec().reset()
    │     • ScenarioContext.sc.set(scenario)
    │     • ConfigLoader.loadConfig()      ← idempotent; runs JS once per JVM
    │     • mirrorGlobals(BASE_GLOBALS)    ← copies mockServerUrl from GLOBAL → ThreadLocal
    │
    ├─ (if @needsPlayer) Hooks.@Before(order=1):
    │     • PlayerBootstrap.registerOnce() ← idempotent; OTP+register+verify, once per JVM
    │     • mirrorGlobals(PLAYER_GLOBALS)
    │
    ├─ Steps execute
    │     • Each step calls into CommonSteps / OneTimeSteps / stepDefs.*
    │     • Step defs read placeholders, build/send request via ApiBase.spec()
    │     • Responses captured back into ScenarioContext via def / defResponse
    │
    └─ Hooks.@After:
          • Log if scenario failed
```

</details>

<details id="design-decisions">
<summary><b>Key design decisions</b></summary>

1. **DSL in `src/main`, features in `src/test`** — packaging boundary. The DSL can be lifted into a shared library; features stay project-specific.
2. **One config file (`config.js`), Nashorn-evaluated** — lets you compute values dynamically (random IDs, timestamps, etc.) at JVM start, then treat them as constants for the run.
3. **ThreadLocal scenario state, no `clear()` between scenarios** — each test thread accumulates state. With the default single-threaded execution this is fine; parallel execution requires care (see [Troubleshooting](10-troubleshooting.md)).
4. **Bootstrap fixtures via tag-gated hooks** — expensive setup (e.g., player registration) only fires for scenarios that need it, runs once per JVM, results published globally. See [Hooks & Fixtures](06-hooks-and-fixtures.md).

</details>
