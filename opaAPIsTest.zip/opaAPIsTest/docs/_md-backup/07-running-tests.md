# 7. Running Tests

---

## Navigation

- [Prerequisites](#prereqs)
- [Quickest possible run](#quickest)
- [Selecting an environment](#env)
- [Filtering by tag](#tags)
- [Running a single feature or scenario](#single)
- [Useful system properties](#sys-props)
- [What gets produced](#outputs)
- [Viewing the Allure report locally](#allure-local)
- [Running just the player bootstrap (manual debugging)](#bootstrap-only)
- [Common run patterns](#patterns)
- [What NOT to do](#dont)

---

<details id="prereqs" open>
<summary><b>Prerequisites</b></summary>

| Requirement | Notes |
|---|---|
| **Java 17** | The pom is built around 17. Earlier JDKs won't compile. |
| **Maven 3.6+** | Wrapper not committed; install Maven globally. |
| **Network access** to UAT/preprod | Unless running with `-Denv=local` against WireMock |
| **Allure CLI** *(optional)* | For viewing reports locally — `npm i -g allure-commandline` or download |

</details>

<details id="quickest">
<summary><b>Quickest possible run</b></summary>

```powershell
# Default env=uat, no tag filter (= everything)
mvn clean install
```

That runs the full suite against UAT. Plan for it to take a while.

</details>

<details id="env">
<summary><b>Selecting an environment</b></summary>

| Env | Command |
|---|---|
| `dev` | `mvn clean install -Denv=dev` |
| `uat` (default) | `mvn clean install -Denv=uat` |
| `preprod` | `mvn clean install -Denv=preprod` |
| `local` (against WireMock) | `mvn clean install -Denv=local` |

`-Denv` is a system property read by `config.js` and by Failsafe's `<systemPropertyVariables>`.

</details>

<details id="tags">
<summary><b>Filtering by tag</b></summary>

```powershell
# Smoke set only (~5–15 critical scenarios)
mvn clean install -Denv=uat "-Dcucumber.filter.tags=@smoke"

# Regression set
mvn clean install -Denv=uat "-Dcucumber.filter.tags=@regression"

# Combinations — Cucumber tag expression syntax
mvn clean install -Denv=uat "-Dcucumber.filter.tags=@smoke and not @flaky"
mvn clean install -Denv=uat "-Dcucumber.filter.tags=@needsPlayer and @sportsbook"
```

PowerShell quirk: wrap the system property in double quotes if it contains `@`, `&`, or spaces:
```powershell
"-Dcucumber.filter.tags=@smoke and @needsPlayer"
```

</details>

<details id="single">
<summary><b>Running a single feature or scenario</b></summary>

Cucumber doesn't have a built-in "run this single file" flag in this setup, but you can:

1. **Tag the scenario(s) with a unique tag:**
   ```gherkin
   @debug
   Scenario: The one I'm fixing
   ```
   Then: `mvn clean install -Denv=uat "-Dcucumber.filter.tags=@debug"`.

2. **Use the IDE.** IntelliJ's Cucumber plugin lets you right-click a scenario → *Run*. It generates the equivalent tag filter behind the scenes.

</details>

<details id="sys-props">
<summary><b>Useful system properties</b></summary>

| Property | Default | Effect |
|---|---|---|
| `-Denv` | `uat` | Selects environment in `config.js` |
| `-Dcucumber.filter.tags` | (none) | Cucumber tag expression |
| `-Dthread.count` | `2` | Failsafe parallel threads (per-class parallelization) |
| `-DskipTests` | `false` | Skip the `tests` execution |
| `-DskipITs` | `false` | Skip integration tests (this project's tests are ITs) |
| `-Dmaven.repo.local=...` | `~/.m2` | Use a project-local Maven cache (CI does this) |

</details>

<details id="outputs">
<summary><b>What gets produced</b></summary>

After a run, expect:

| Path | Contents |
|---|---|
| `failsafe-reports/*.xml` | JUnit XML (small — `<system-out>` redirected) |
| `failsafe-reports/*-output.txt` | Captured stdout/stderr per test class |
| `reports/` | Allure raw results (`*.json`, attachments) |
| `reports/site/` | Surefire-style HTML site (after `mvn verify`) |
| `target/` | Compiled classes |

</details>

<details id="allure-local">
<summary><b>Viewing the Allure report locally</b></summary>

```powershell
# After a Maven run that produced reports/ raw results
allure serve reports
```

If you don't have Allure CLI:
```powershell
allure generate reports --clean -o reports/site
# Then open reports/site/index.html
```

</details>

<details id="bootstrap-only">
<summary><b>Running just the player bootstrap (manual debugging)</b></summary>

The `PlayerBootstrap` flow is gated behind `@needsPlayer`. To run it standalone, tag any cheap scenario `@needsPlayer` (or use one of the still-present scenarios in `src/test/resources/features/PAM/`) and run with that tag filter:

```powershell
mvn clean install -Denv=uat "-Dcucumber.filter.tags=@needsPlayer"
```

The first scenario triggers the full registration; subsequent scenarios are no-ops on the bootstrap (just mirror globals).

</details>

<details id="patterns">
<summary><b>Common run patterns</b></summary>

```powershell
# Smoke loop while developing CI changes
mvn clean install -Denv=uat "-Dcucumber.filter.tags=@smoke"

# Investigating a flaky regression scenario
mvn clean install -Denv=uat "-Dcucumber.filter.tags=@MyFlakyTag" -Dthread.count=1

# Running against your local middleware + WireMock
mvn clean install -Denv=local

# Generate Allure report after the run
allure serve reports
```

</details>

<details id="dont">
<summary><b>What NOT to do</b></summary>

- **Don't `mvn test`** — the runner is `IT` (integration test), bound to the `verify` phase, not `test`. `mvn test` won't run any features.
- **Don't run with parallel `>1`** unless you've confirmed your scenarios are isolated. The current `ConfigLoader.loaded` static flag is not parallel-safe (see [Hooks & Fixtures](06-hooks-and-fixtures.md) caveats).
- **Don't run `@needsPlayer` against preprod casually** — registers a real player; takes ~70 seconds. Use sparingly.

</details>
