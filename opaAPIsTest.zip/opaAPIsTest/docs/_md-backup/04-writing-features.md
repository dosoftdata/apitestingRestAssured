# 4. Writing Features

Feature files live under `src/test/resources/features/<domain>/...feature` and are written in **Gherkin with the project's custom DSL**. This page is a reference for the DSL, with copy-pasteable examples.

---

## Navigation

- [Skeleton](#skeleton)
- [Placeholder syntax](#placeholders)
- **DSL reference**
  - [Building a request — stateful (`CommonSteps`)](#dsl-stateful)
  - [Building a request — fresh-per-step (`OneTimeSteps`)](#dsl-fresh)
  - [Capturing values from the response](#dsl-capture)
  - [Defining and reusing local variables](#dsl-def)
  - [Asserting status and content](#dsl-assert)
  - [Special: timing and retries](#dsl-timing)
  - [Multipart upload](#dsl-multipart)
- [Tags](#tags)
- [Scenario Outline + Examples](#outlines)
- [Background](#background)
- [Putting it together — a complete example](#full-example)
- [Where to read more](#read-more)

---

<details id="skeleton" open>
<summary><b>Skeleton</b></summary>

```gherkin
Feature: <short title>

  Background:                  # optional — runs before every scenario
    Given url {{middlewareHost}}
    And header Content-Type = application/json

  @smoke @needsPlayer
  Scenario: <what we are verifying>
    Given path /uip/sportsbook/api/v1.0/bets
    And header Authorization = Bearer {{janusToken}}
    And request
      """
      { "amount": 10, "playerId": "{{playerId}}" }
      """
    When method POST
    Then status 200
    And def betId in response.id
    And match response status = ACCEPTED
```

</details>

<details id="placeholders">
<summary><b>Placeholder syntax</b></summary>

Two interchangeable forms (both supported by `ScenarioContext.resolve`):

| Syntax | Example |
|---|---|
| `{{key}}` | `{{playerId}}`, `{{pam.webBaseUrl}}`, `{{apiKeys[0]}}` |
| `#(key)` | `#(playerId)`, `#(pam.webBaseUrl)` |

Use `{{}}` by default for new features (more visually distinct in editors).

Resolution order: per-scenario `ThreadLocal` map → returns empty string if key not found. Globals (e.g., `mockServerUrl`, `playerId`) must be **mirrored** into per-scenario context first, which `Hooks.@Before` does automatically.

</details>

## DSL reference

<details id="dsl-stateful">
<summary><b>Building a request — stateful (<code>CommonSteps</code>)</b></summary>

These work on `context.spec` — the spec is **carried across steps** within a scenario.

| Step | Purpose |
|---|---|
| `Given url <expr>` | Set base URI |
| `And path <path>` / `Given path <path>` | Set base path |
| `And param <name> = <value>` | Add query parameter |
| `And pathParam <name> = <value>` | Set a `{name}` placeholder in the path |
| `And header <name> = <value>` | Set request header |
| `And cookie <name> = <value>` | Set cookie |
| `And request """<body>"""` | Set body (multi-line docstring) |
| `When method <VERB>` | Send HTTP request (GET/POST/PUT/DELETE/PATCH) |
| `When method <VERB> <path>` | Send with explicit path override |

Example (single scenario, single spec):

```gherkin
Scenario: Get janus token
  Given url {{janus.baseUrl}}
  And path {{janus.basePath}}
  And header Content-Type = {{janus.contentType}}
  And header Authorization = {{janus.authorization}}
  And formField grant_type = {{janus.grantType}}
  When method POST
  Then status 200
  And def janusToken in response.access_token
```

</details>

<details id="dsl-fresh">
<summary><b>Building a request — fresh-per-step (<code>OneTimeSteps</code>)</b></summary>

Use these when you want to send **multiple distinct requests** within one scenario without leftover state from the previous one. Each `set Url` resets the spec.

| Step | Purpose |
|---|---|
| `Given set Url <expr>` | Reset spec, set base URI |
| `And add path <path>` | Set base path on the fresh spec |
| `And add pathParam <name> = <value>` | Add path parameter |
| `And set header <name> = <value>` | Add header |
| `And set Cookie <name> = <value>` | Add cookie |
| `And add request """<body>"""` | Set body |
| `And add form field <name> = <value>` | Add form field |
| `And add delay request <ms>` | Add a request delay filter |
| `When set method <VERB>` | Send |

Example (two requests in one scenario):

```gherkin
Scenario: Fetch email then verify
  # Request 1
  Given url {{pam.boBaseUrl}}
  And path /cc/communication/rest/v1/emails
  And param playerId = {{playerId}}
  When method GET
  Then status 200
  And def mailHash in response.data[0].id

  # Request 2 — fresh spec
  Given set Url {{pam.boBaseUrl}}
  And add path /cc/communication/rest/v1/emails/{hash_for_mail}
  And add pathParam hash_for_mail = {{mailHash}}
  When set method GET
  And status 200 or 204
```

</details>

<details id="dsl-capture">
<summary><b>Capturing values from the response</b></summary>

| Step | Purpose |
|---|---|
| `And def <name> in response.<jsonPath>` | Capture a JSON-path from the body |
| `* Cookie <name> in response.<cookieName>` | Capture a response cookie into a variable |
| `And extract string using <token> with name <var> from body response` | Substring extract by anchor (e.g., everything after `&hash=` until `"`/space/`<`) |

```gherkin
When method POST
And status 403
* Cookie web-x-csrftoken in response.csrftoken

When method POST
And status 200
And def otpUuid in response.uuid
```

</details>

<details id="dsl-def">
<summary><b>Defining and reusing local variables</b></summary>

| Step | Purpose |
|---|---|
| `And def <name> = <expr>` | Set a per-scenario variable |

```gherkin
And def randomMSISDN = {{pam.$random8Digit}}
And request
  """
  { "phoneNumber": "69{{randomMSISDN}}" }
  """
```

</details>

<details id="dsl-assert">
<summary><b>Asserting status and content</b></summary>

| Step | Purpose |
|---|---|
| `Then status <code>` / `And status <code>` | Strict status assertion |
| `And status <a> or <b>` | Allow either of two status codes (e.g., `200 or 204`) |
| `And match response <jsonPath> = <expected>` | Equality check |
| `And match response <jsonPath> contains <substr>` | Contains check |
| `And match response <jsonPath> any <values>` | Value is one of |
| `And match response <jsonPath> only <values>` | Array contains only these values |
| `And match response <jsonPath> deep <json>` | Full subtree match (with `"..."` wildcard) |
| `And match each <arrayPath> <pattern>` | Apply pattern to every array element |
| `And match string <expr> contains <substr>` | Plain string assertion |
| `And match response body path <p> should be <matcherName> <expected>` | Hamcrest matcher (e.g., `greaterThan`, `hasSize`, `notNullValue`) |
| `And match response time should be less than <ms>` | Latency check |

JsonMatcher pattern markers (used inside `match response` `deep` and `match each`):

| Marker | Meaning |
|---|---|
| `#string`, `#number`, `#boolean`, `#null`, `#notnull` | Type checks |
| `#array`, `#object`, `#empty`, `#notempty` | Container checks |
| `#date` | ISO date format |
| `#regex/<pattern>/` | Regex match |
| `#size <n>`, `#min <n>`, `#max <n>` | Size constraints on arrays |
| `#contains <value>` | String/array contains |
| `#any` | Wildcard — accept anything |

Example:

```gherkin
And match response data.players deep
  """
  [
    { "id": "#number", "username": "#string", "registered": "#date" },
    "..."
  ]
  """
```

</details>

<details id="dsl-timing">
<summary><b>Special: timing and retries</b></summary>

| Step | Purpose |
|---|---|
| `And delay request <ms>` | Add latency to outgoing request (filter-based) |
| `And add delay request <ms>` | Same on a fresh spec |

For polling / "wait until 200" behavior, use `awaitUntil(...)` from `DslHelper` in a custom step def — see [Step Definitions](05-step-definitions.md).

</details>

<details id="dsl-multipart">
<summary><b>Multipart upload</b></summary>

| Step | Purpose |
|---|---|
| `And multipart file <controlName> <path> <mimeType>` | Attach file to multipart request |

</details>

<details id="tags">
<summary><b>Tags</b></summary>

Tags drive both filtering and hook behavior. Place them above `Scenario:` (or `Feature:` to apply to every scenario inside).

| Tag | Effect |
|---|---|
| `@smoke` | Included by the `@smoke` filter (run by GitLab CI on git activity) |
| `@regression` | Included by the `@regression` filter (default for Web/scheduled runs) |
| `@needsPlayer` | Triggers `PlayerBootstrap.registerOnce()` before the scenario; mirrors player globals |
| `@manual` / custom | Use to mark scenarios excluded from automated runs |

Combine via Cucumber tag expressions: `-Dcucumber.filter.tags="@smoke and not @flaky"`.

</details>

<details id="outlines">
<summary><b>Scenario Outline + Examples</b></summary>

```gherkin
Scenario Outline: Place bet of <amount>
  Given url {{psMiddlewareHost}}
  And path /uip/sportsbook/api/v1.0/bets
  And request
    """
    { "amount": <amount>, "playerId": "{{playerId}}" }
    """
  When method POST
  Then status <code>

  Examples:
    | amount | code |
    | 10     | 200  |
    | 0      | 400  |
    | -1     | 400  |
```

</details>

<details id="background">
<summary><b>Background</b></summary>

`Background` runs before every scenario in the file. Use it for shared setup (URL, headers, common variables). Avoid putting tag-gated behavior here — tags apply to scenarios, not to backgrounds.

</details>

<details id="full-example">
<summary><b>Putting it together — a complete example</b></summary>

```gherkin
Feature: Place a sportsbook bet

  Background:
    Given url {{psMiddlewareHost}}
    And header Content-Type = application/json
    And header Accept = application/json

  @smoke @needsPlayer
  Scenario: Successful bet creation
    Given path /uip/sportsbook/api/v1.0/bets
    And header x-player-id = {{playerId}}
    And request
      """
      {
        "amount": 5,
        "selections": [{ "outcomeId": "12345", "odds": "2.5" }]
      }
      """
    When method POST
    Then status 200
    And def betId in response.id
    And match response status = ACCEPTED
    And match response body path data.amount should be equalTo 5

  @regression @needsPlayer
  Scenario Outline: Reject invalid amounts
    Given path /uip/sportsbook/api/v1.0/bets
    And header x-player-id = {{playerId}}
    And request
      """
      { "amount": <amount>, "selections": [] }
      """
    When method POST
    Then status 400

    Examples:
      | amount |
      | 0      |
      | -10    |
```

</details>

<details id="read-more">
<summary><b>Where to read more</b></summary>

- [Step Definitions](05-step-definitions.md) — when the DSL doesn't cover your case, write a custom step def.
- [Hooks & Fixtures](06-hooks-and-fixtures.md) — how `@needsPlayer` triggers a bootstrap fixture.
- Real example: see `src/test/resources/features/middleware/digital-payment/ssbt/1.createSsbtPayment.feature` for an intermediate-complexity flow.

</details>
