# 12. Random Player Selection

Opt a feature into picking a **random player from a pool**, filtered by conditions
(enabled/disabled, minimum balance), instead of using the single `config.playerId`.
Selection happens **once per feature** and every scenario in it reuses the same player.

---

## Usage

Tag the feature (or scenario) and declare conditions:

```gherkin
@randomPlayer @enabled @minBalance:10
Feature: Place a bet
  ...
  Scenario: ...
    And header x-player-id = {{playerId}}   # resolves to the picked player
```

| Tag | Effect |
|-----|--------|
| `@randomPlayer` | Activates selection for the feature/scenario. |
| `@enabled` | Only players with `enabled=true`. |
| `@disabled` | Only players with `enabled=false`. |
| `@minBalance:N` | Only players with `balance >= N`. |

Feature bodies need **no change** — `{{playerId}}` resolves to the pick automatically.

---

## The pool — `players.csv`

`src/test/resources/testdata/players.csv` (override with `-Dplayers.file=...`):

```csv
env,playerId,enabled,balance
dev,413451693,true,150.00
dev,555000111,false,80.00
uat,939932925,true,25.00
```

- Rows are filtered to the active `-Denv` and cached once per JVM (`PlayerPool`,
  package `apis.middleware.testData`).
- **Static attributes**: `enabled` / `balance` are read from the file as-is. The pool
  does **not** query live account state, so keep the CSV in sync with reality.

---

## How it works

- `@Before("@randomPlayer", order=2)` in `Hooks.java` selects a player and writes it to
  the **per-thread** store. `ScenarioContext.get()` checks that store before the GLOBAL
  config, so `{{playerId}}` resolves to the pick.
- **Per-feature, once**: a `ConcurrentMap<URI,String>` keyed by `scenario.getUri()` with
  `computeIfAbsent` — the first scenario in a feature selects, the rest reuse. Parallel-safe
  because scenarios within a feature share one worker thread.
- **No match → skip**: if no pooled player satisfies the conditions, the scenario is
  skipped via `Assumptions` (same mechanism as `@skipOn<Env>`), not failed.
- `order=2` means it wins over `@needsPlayer` (order=1) if a scenario carries both.

---

## Extending it

1. Add a column to `players.csv`.
2. Parse it into `PlayerPool.PlayerRecord` in `PlayerPool.load`.
3. Add a tag branch in `Hooks.conditionsFromTags` (e.g. `@currency:EUR`).

> Verify through the real suite — surefire is disabled in this repo. The decisive check
> is the negative path: an unsatisfiable condition (`@minBalance:999999`) must **skip** the
> scenario without hitting the API.
