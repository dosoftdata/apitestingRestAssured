# 8. CI/CD Pipeline

GitLab CI is configured in `devops/.gitlab-ci.yml`. The pipeline has three stages — `checkout`, `tests`, `deploy` — and a workflow rule set that controls **when** the pipeline runs and **what tag scope** it uses.

---

## Navigation

- [When does the pipeline run?](#when)
- [The workflow rules](#workflow-rules)
- [Pipeline-level inputs (Web UI)](#web-inputs)
- **Stages**
  - [`checkout`](#stage-checkout)
  - [`tests`](#stage-tests)
  - [`pages` (deploy)](#stage-pages)
- [Maven cache](#maven-cache)
- [JUnit XML size limit](#junit-size)
- [Tagging conventions for CI](#ci-tags)
- [Schedules](#schedules)
- [Modifying the pipeline](#modifying)
- [Limits to be aware of](#limits)

---

<details id="when" open>
<summary><b>When does the pipeline run?</b></summary>

| Trigger | Runs? | Effective `tag` filter |
|---|---|---|
| Push to any branch (incl. `develop` post-merge) | Yes | `@smoke` |
| MR targeting any branch (incl. `develop`, `main`) | Yes | `@smoke` |
| **"Run pipeline" from Web UI** | Yes | whatever the user selects (default `@regression`) |
| **Scheduled pipeline** | Yes | schedule's variable, else default `@regression` |
| Anything else (tag push, etc.) | No | — |

So:
- **Day-to-day git activity → smoke set only**, fast.
- **Full regression → only on demand** (manual run) or scheduled (e.g., nightly).

</details>

<details id="workflow-rules">
<summary><b>The workflow rules</b></summary>

```yaml
workflow:
  rules:
    - if: '$CI_PIPELINE_SOURCE == "merge_request_event" || $CI_PIPELINE_SOURCE == "push"'
      variables:
        tag: "@smoke"
      when: always
    - if: '$CI_PIPELINE_SOURCE == "web" || $CI_PIPELINE_SOURCE == "schedule"'
      when: always
    - when: never
```

The `variables: tag: "@smoke"` in a workflow rule **overrides** the top-level `variables.tag` (default `@regression`) for pipelines created by that rule.

</details>

<details id="web-inputs">
<summary><b>Pipeline-level inputs (Web UI)</b></summary>

When you click *Run pipeline* in GitLab, you see:

| Variable | Description | Default | Options |
|---|---|---|---|
| `branch_name` | The middleware-api-testing branch to test | `develop` | (free text) |
| `tag` | Cucumber tag filter | `@regression` | (free text) |
| `environment` | Test environment | `uat` | `dev`, `uat`, `preprod` |
| `parallel` | Enable feature-level parallel execution | `false` | `false`, `true` |
| `thread` | Parallel worker count (used when `parallel=true`) | `1` | (free text) |

These are exposed as variables with `description:` blocks in `.gitlab-ci.yml` so the UI renders them as form fields.

</details>

## Stages

<details id="stage-checkout">
<summary><b><code>checkout</code></b></summary>

Reuses a shared template from `devops/gitlab-template`:

```yaml
checkout:
  stage: checkout
  extends: .checkout_repo
  tags: [docker]
  artifacts:
    paths: [$repo_name]
    expire_in: 6 hours
```

Clones `middleware-api-testing` at `$branch_name` and exposes the working tree as an artifact for the `tests` job.

</details>

<details id="stage-tests">
<summary><b><code>tests</code></b></summary>

Runs the actual Maven build:

```yaml
tests:
  image: registry.dc.opap/tools/centos_multiple_java_maven:v1.0.3
  stage: tests
  tags: [docker]
  dependencies: [checkout]
  script:
    - cd ${repo_name}
    - mvn clean install -Dcucumber.filter.tags="${tag}" -Denv="${environment}" -Dparallel="${parallel}" -Dthread="${thread}"
  timeout: 7h
  artifacts:
    paths:
      - ${repo_name}/reports/site
      - ${repo_name}/failsafe-reports
    reports:
      junit:
        - ${repo_name}/failsafe-reports/*.xml
    expire_in: 48 hours
    when: always
    expose_as: "API Test Report"
```

The `reports.junit` is the file GitLab parses for the merge-request **Test Summary** widget. The `paths` block also captures the full `failsafe-reports/` directory (incl. `*-output.txt`) and the Allure HTML site under `reports/site/`.

</details>

<details id="stage-pages">
<summary><b><code>pages</code> (deploy)</b></summary>

```yaml
pages:
  stage: deploy
  needs: [tests]
  tags: [docker]
  script:
    - rm -rf public
    - mkdir -p public
    - if [ -d ${repo_name}"/reports/site" ]; then cp -r ${repo_name}/reports/site/* public/; fi
  artifacts:
    paths: [public]
    expire_in: 2 weeks
```

Copies the report site into `public/`, which GitLab Pages serves — gives you a stable URL to share the latest report.

</details>

<details id="maven-cache">
<summary><b>Maven cache</b></summary>

Defined at the top of `.gitlab-ci.yml`:

```yaml
variables:
  MAVEN_OPTS: "-Dmaven.repo.local=$CI_PROJECT_DIR/.m2/repository"

cache:
  key:
    files:
      - middleware-api-testing/pom.xml
    prefix: "$CI_COMMIT_REF_SLUG"
  paths:
    - .m2/repository/
  policy: pull-push
```

| Behavior | Detail |
|---|---|
| **Cache key** | `<branch>-<hash(pom.xml)>` — invalidates automatically on dependency changes |
| **Per-branch isolation** | `prefix: $CI_COMMIT_REF_SLUG` — `develop` and `main` don't share a cache |
| **Policy** | `pull-push` — downloads at start, uploads at end |
| **First run on a branch** | Cache miss → full download |
| **Subsequent runs on same branch (no `pom.xml` change)** | Cache hit → ~30s saved on dependency resolution |

</details>

<details id="junit-size">
<summary><b>JUnit XML size limit</b></summary>

GitLab parses `reports.junit` files for the test-summary widget but rejects anything over **30 MB**. The framework's pom mitigates this by setting:

```xml
<configuration>
    ...
    <redirectTestOutputToFile>true</redirectTestOutputToFile>
    ...
</configuration>
```

This sends `System.out` / `System.err` to `failsafe-reports/<TestClass>-output.txt` instead of embedding them in `<system-out>` blocks in the XML. The XML stays under a few MB even for thousands of scenarios; the captured logs ride along in artifacts.

</details>

<details id="ci-tags">
<summary><b>Tagging conventions for CI</b></summary>

| Tag | Purpose |
|---|---|
| `@smoke` | Critical-path subset (~5–15 scenarios). Runs on every push/MR. |
| `@regression` | Full or near-full suite. Runs on manual / scheduled triggers. |
| `@needsPlayer` | Scenario depends on `PlayerBootstrap` having registered a player |
| Anything else (e.g. `@bo`, `@payment`) | Domain grouping — useful for `-Dcucumber.filter.tags="@payment and @smoke"` |

A scenario can carry multiple tags:

```gherkin
@smoke @needsPlayer @sportsbook
Scenario: Place a sportsbook bet
```

</details>

<details id="schedules">
<summary><b>Schedules</b></summary>

To run full regression nightly (or whatever cadence):

1. *Project → CI/CD → Schedules → New schedule*
2. Set cron: `0 3 * * *` (3 AM daily)
3. Branch: `develop`
4. Variables: leave `tag` unset (defaults to `@regression`), set `environment` if desired

The workflow rule `if: '$CI_PIPELINE_SOURCE == "schedule"'` catches it; no `variables.tag` override fires, so the default `@regression` value applies.

</details>

<details id="modifying">
<summary><b>Modifying the pipeline</b></summary>

Common tweaks, with where to make them:

| Change | Where |
|---|---|
| Add a new branch filter | `workflow.rules` |
| Change Maven memory | `MAVEN_OPTS` env var, or pass `-Xmx...` in `argLine` |
| Add a new stage (e.g., `lint`) | `stages:` list + new job block |
| Skip tests for `[skip ci]` commits | Add a workflow rule checking `$CI_COMMIT_MESSAGE` |
| Run on a tag push | Add `if: '$CI_COMMIT_TAG'` rule |

</details>

<details id="limits">
<summary><b>Limits to be aware of</b></summary>

- **JUnit XML 30 MB hard cap** in the GitLab parser.
- **Artifact retention 48h** on `tests` job — extend if you need historical browsing.
- **Pipeline timeout 7h** — full regression is bounded; if a single test job hits this, split.
- **Cache size** can grow over time; GitLab evicts old caches based on project-level retention policy.

</details>
