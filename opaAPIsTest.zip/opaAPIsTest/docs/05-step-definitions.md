# 5. Step Definitions

The DSL covers ~95% of normal HTTP interactions. When you need bespoke logic — multi-step polling, custom token refresh, complex extraction, state transitions — write a step definition.

---

## Navigation

- **Contributor tiers**
  - [Tier 1 — Test author](#tier-1)
  - [Tier 2 — Domain owner](#tier-2)
  - [Tier 3 — Framework maintainer](#tier-3)
- [Where step defs live](#location)
- [Anatomy of a step-defs class](#anatomy)
- [`CustomRequestSpec` reference](#customreqspec)
- [Using POJOs for request bodies (Lombok)](#lombok-pojos)
- [Polling / "wait until" pattern](#polling)
- [Hamcrest matchers (via `DslHelper.buildMatcher`)](#hamcrest)
- [Naming and registration conventions](#naming)
- [Adding a step that emits to globals (bootstrap-style)](#globals)

---

<details id="tiers" open>
<summary><b>Contributor tiers</b></summary>

The framework is layered so each contributor only touches what their work requires. Pick the tier that matches what you're doing:

| Tier | Who | What they touch | Java required? |
|---|---|---|---|
| **1. Test author** | Most testers | `.feature` files only | No |
| **2. Domain owner** | Team lead for a specific area (payments, sportsbook, PAM, casino, ...) | A new `<Domain>Steps.java` file under `src/test/apis/middleware/stepDefs/` | Yes — basic |
| **3. Framework maintainer** | Core team | `CommonSteps`, `OneTimeSteps`, `Hooks`, `ScenarioContext`, `ConfigLoader`, `JsonMatcher` | Yes — advanced |

</details>

<details id="tier-1">
<summary><b>Tier 1 — Test author</b></summary>

You only write Gherkin. See [Writing Features](04-writing-features.md). If you find yourself wanting a step the DSL doesn't have, talk to your domain owner before introducing one — the existing DSL probably covers it.

</details>

<details id="tier-2">
<summary><b>Tier 2 — Domain owner</b></summary>

When your domain needs a step that isn't in the generic DSL (e.g., a multi-step token-refresh flow, a polling loop with domain-specific exit conditions, a complex response extraction):

1. **Don't dump it into `oneRowSpecSteps.java`** — that file is just the historical default. Adding to it forces every domain to share one file → merge conflicts and a kitchen-sink class.
2. **Create your own file** under `src/test/apis/middleware/stepDefs/<Domain>Steps.java`:
   ```java
   package apis.middleware.stepDefs;

   import apis.middleware.dsl.ScenarioContext;
   import apis.middleware.dsl.actions.DslHelper;
   import io.cucumber.java.en.*;
   import lombok.extern.slf4j.Slf4j;

   @Slf4j
   public class paymentSteps extends DslHelper {
       public paymentSteps(ScenarioContext context) { super(context); }

       @Given("^Refresh payment session for (.+)$")
       public void refreshPaymentSession(String playerId) {
           // your steps here
       }
   }
   ```
3. **No registration needed.** Cucumber's `glue` config in `CliIT.java` scans `apis.middleware.stepDefs.*` automatically. Drop the file in the package, write your `@Given`/`@When`/`@Then`, done.
4. **Naming convention** — `<domain>Steps.java` (lowercase first letter is the existing convention; pick a class name that makes the domain obvious).

This keeps domain logic isolated. Your team owns one file; other domains' files don't move when you ship changes.

</details>

<details id="tier-3">
<summary><b>Tier 3 — Framework maintainer</b></summary>

You change the DSL itself, the lifecycle, the context, the matcher engine. These changes ripple through every feature file and every step-defs class, so:

- **Backwards compatibility** — never silently rename or remove a DSL phrase. Add a new phrase and deprecate the old one with a one-release deprecation cycle.
- **Update the docs** — the [Writing Features](04-writing-features.md) page is the contract with Tier 1 contributors. Every framework change that touches the DSL surface needs a docs update in the same PR.
- **Test against existing features** — run the full `@regression` suite locally before merging.

</details>

<details id="location">
<summary><b>Where step defs live</b></summary>

| Location | When to use |
|---|---|
| `src/main/java/apis/middleware/dsl/actions/CommonSteps.java` | The core DSL itself — only edit if extending the *language* (new generic verb) |
| `src/main/java/apis/middleware/dsl/actions/OneTimeSteps.java` | Same, for the "fresh-spec" variant |
| `src/test/apis/middleware/stepDefs/oneRowSpecSteps.java` | Domain-specific helpers (token acquisition, polling flows, payment specifics) |
| `src/test/apis/middleware/stepDefs/<NewFile>.java` | New domain (just add the file; no registration needed — Cucumber finds it via glue) |

Cucumber `glue` is configured in `CliIT.java`:

```
apis.middleware.dsl.actions
apis.middleware.stepDefs
apis.middleware.hooks
```

So any `@Given`/`@When`/`@Then` in those packages is auto-discovered.

</details>

<details id="anatomy">
<summary><b>Anatomy of a step-defs class</b></summary>

```java
package apis.middleware.stepDefs;

import apis.middleware.core.base.ApiBase;
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.dsl.actions.DslHelper;
import io.cucumber.java.en.*;
import io.restassured.path.json.JsonPath;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class oneRowSpecSteps extends DslHelper {

    public oneRowSpecSteps(ScenarioContext context) {
        super(context);
    }

    @Given("^User has janus token$")
    public void user_has_janus_token() {
        spec = ApiBase.spec();                          // fresh CustomRequestSpec
        spec.setBaseUri(context.getProp("janus.baseUrl"));
        spec.setBasePath(context.getProp("janus.basePath"));
        spec.header("Content-Type", context.getProp("janus.contentType"));
        spec.setFormParam("grant_type", context.getProp("janus.grantType"));
        spec.setFormParam("scope",       context.getProp("janus.scope"));

        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);

        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        context.setProp("janusToken",     resp.get("access_token"));
        context.setProp("janusTokenType", resp.get("token_type"));
    }
}
```

The pattern is consistent across every step in the codebase:

1. Get a fresh spec: `spec = ApiBase.spec()`
2. Configure it: `spec.setBaseUri / setBasePath / header / setFormParam / setBody / ...`
3. Send: `spec.when().post()` (or `.get()`, `.put()`, `.delete()`)
4. Stash the response on `context.getApi()` so subsequent `match`/`def` steps can reach it.
5. Extract values via `JsonPath` and write them back into the per-scenario context.

</details>

<details id="customreqspec">
<summary><b><code>CustomRequestSpec</code> reference</b></summary>

`spec = ApiBase.spec()` returns a `CustomRequestSpec` — a thin wrapper around RestAssured's `RequestSpecification` that pre-attaches the Allure filter (so the request lands in your Allure report).

Common builder methods (chain or call sequentially):

| Method | Purpose |
|---|---|
| `setBaseUri(uri)` | Base URL |
| `setBasePath(path)` | Base path appended to URI |
| `setHeader(name, value)` / `header(name, value)` | Set a header |
| `setHeaders(map)` | Bulk-set headers |
| `setBody(obj)` | JSON body — POJO auto-serialized via Jackson |
| `setQueryParam(name, value)` | Query parameter |
| `setPathParam(name, value)` | Substitute `{name}` in path |
| `setFormParam(name, value)` | Form parameter (`application/x-www-form-urlencoded`) |
| `setCookie(name, value)` | Request cookie |
| `addMultiPartFile(controlName, file, mimeType)` | File upload |
| `setRedirectFollow(bool)` / `setRedirectCircular(bool)` | Redirect control |
| `when()` | Returns the underlying `RequestSender` for `.post()`, `.get()`, etc. |
| `build()` | Returns the underlying `RequestSpecification` (used in polling helpers) |

</details>

<details id="lombok-pojos">
<summary><b>Using POJOs for request bodies (Lombok)</b></summary>

Prefer Lombok DTOs over inline JSON strings for anything beyond a single field:

```java
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public static class CardPaymentRequest {
    private final Card card;
    private final long amount;
    private final String currency;
}
```

```java
CardPaymentRequest req = CardPaymentRequest.builder()
    .card(Card.builder().number("5413330089604111").expMonth(5).expYear(2031).build())
    .amount(1000)
    .currency("EUR")
    .build();

spec = ApiBase.spec();
spec.setBaseUri("https://...");
spec.setHeader("Content-Type", "application/json");
spec.setBody(req);                                  // Jackson serializes
context.getApi().setResponse(spec.when().post());
```

The codebase has examples in `apis.middleware.models.request.payment.*`. Reusable DTOs go under `src/main/java/apis/middleware/models/request/<domain>/`.

</details>

<details id="polling">
<summary><b>Polling / "wait until" pattern</b></summary>

`DslHelper` provides `awaitUntil(method, path, conditionJson)` for retry-until-condition flows:

```java
@Given("^Wait for player ([^ ]+) to be ACTIVE$")
public void waitForPlayerActive(String playerId) {
    spec = ApiBase.spec();
    spec.setBaseUri(context.getProp("pam.boBaseUrl"));
    spec.setBasePath("/cc/players/rest/v1/players/{id}");
    spec.setPathParam("id", playerId);
    context.setSpec(spec);

    awaitUntil("GET", null,
        "{ \"status\": 200, \"bodyPath\": \"status\", \"action\": \"equal\", "
      + " \"hasValue\": \"ACTIVE\", \"minutes\": 2, \"pollMillis\": 3000 }");
}
```

`awaitUntil`:
- Polls every `pollMillis` for up to `minutes:seconds`
- Re-runs the request each iteration via the saved spec
- Exits when status matches `status` AND `bodyPath` evaluates true vs `hasValue` per `action` (`equal`, `contains`, `exists`, `greater`, `listcontains`, `any`)
- Stores the final response in `context.getApi()`

For ad-hoc polling, drop directly into Awaitility:

```java
import static org.awaitility.Awaitility.await;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicReference;

AtomicReference<Response> last = new AtomicReference<>();
await()
    .atMost(Duration.ofMinutes(5))
    .pollInterval(Duration.ofSeconds(5))
    .ignoreExceptions()
    .until(() -> {
        Response r = context.getRes().spec(spec.build()).when().get();
        last.set(r);
        return r.statusCode() == 200;
    });
context.getApi().setResponse(last.get());
```

</details>

<details id="hamcrest">
<summary><b>Hamcrest matchers (via <code>DslHelper.buildMatcher</code>)</b></summary>

If you want a Hamcrest assertion driven by string keywords, `DslHelper.buildMatcher(name, value)` returns the right `Matcher<?>`. Supported keywords:

| Category | Keywords |
|---|---|
| Equality | `equalTo`, `notEqualTo`, `isEqualTo`, `not` |
| String | `containsString`, `containsIgnoringCase`, `startsWith`, `endsWith`, `equalToIgnoringCase`, `equalToIgnoringWhitespace`, `matchesRegex`, `matchesPattern` |
| Numeric | `greaterThan`, `greaterThanOrEqualTo`, `lessThan`, `lessThanOrEqualTo`, `closeTo` |
| Collection | `hasItem`, `hasItems`, `hasSize`, `isEmpty`, `everyItemContains` |
| Map | `hasKey`, `hasValue`, `hasEntry` |
| Null/Type | `nullValue`, `notNullValue`, `instanceOf` |
| Boolean | `isTrue`, `isFalse` |

This is what powers the `match response body path X should be <matcher> Y` step.

</details>

<details id="naming">
<summary><b>Naming and registration conventions</b></summary>

- **One class per domain** (`oneRowSpecSteps`, `janusOneRowSpecSteps`, ...). Adding a new file requires no wiring — Cucumber scans the glue packages.
- **Step regex prefixes**: pick `Given` for state setup, `When` for actions, `Then` for assertions, `And`/`But` for follow-ups. Cucumber treats them all equivalently — the choice is purely for readability.
- **Avoid duplicate regexes** — Cucumber will error if two step defs match the same line.
- **Always extend `DslHelper`** to inherit `context`, `spec`, `mapper`, `args`, and `awaitUntil`.

</details>

<details id="globals">
<summary><b>Adding a step that emits to globals (bootstrap-style)</b></summary>

If your step result should outlive the scenario (e.g., a long-lived auth token), publish to `ScenarioContext.GLOBAL`:

```java
@Given("^Acquire shared admin token$")
public void acquireAdminToken() {
    if (ScenarioContext.getGlobal("adminToken", String.class) != null) return;

    spec = ApiBase.spec();
    // ... fetch token ...
    String token = resp.get("access_token");

    ScenarioContext.putIfAbsentGlobal("adminToken", token);
    ScenarioContext.set("adminToken", token);    // also mirror into per-scenario for {{adminToken}}
}
```

Add `"adminToken"` to `Hooks.BASE_GLOBALS` (or a new array gated by a tag) so it gets mirrored automatically for subsequent scenarios. See [Hooks & Fixtures](06-hooks-and-fixtures.md).

</details>
