# 11. External Test Data

The framework ships an in-tree test-data system that pulls `Scenario Outline` examples from CSV, Excel, or a JDBC database and injects them into feature files before Cucumber runs. The code lives in `src/main/java/apis/middleware/testData/`.

---

## Navigation

- [What it is](#what-it-is)
- [Architecture](#architecture)
- **Components**
  - [`TestDataRepository`](#repo)
  - [`DynamicDataPreProcessor`](#preprocessor)
  - [`initGenerator`](#init)
- [End-to-end example](#example)
- [**Runnable PoC in this repo**](#poc)
- [Data file format](#data-format)
- [Database mode](#db-mode)
- [System properties reference](#sys-props)
- [Things to know](#things-to-know)

---

<details id="what-it-is" open>
<summary><b>What it is</b></summary>

A two-step pipeline:

1. **Load** test data from a source (CSV / Excel / DB) into a singleton in-memory map, keyed by `"<feature_name>::<scenario_name>"`.
2. **Rewrite** feature files: for every `Scenario Outline:` in a feature tagged `@DataSource:<type>`, strip the existing `Examples:` table and replace it with rows from the repository — filtered to only the `<placeholders>` actually referenced.

After the rewrite, Cucumber sees a normal feature file with a real `Examples:` block and runs it the usual way.

</details>

<details id="architecture">
<summary><b>Architecture</b></summary>

```
┌────────────────────────────┐
│  testdata.csv / .xlsx / DB │   source of truth
└─────────────┬──────────────┘
              │ loads (once per JVM, cached)
              ▼
┌────────────────────────────┐
│  TestDataRepository        │   Map<"feature::scenario", List<Map<col,val>>>
└─────────────┬──────────────┘
              │ consumed by
              ▼
┌────────────────────────────┐
│  DynamicDataPreProcessor   │   walks .feature files, rewrites Examples:
└─────────────┬──────────────┘
              │ triggered by
              ▼
┌────────────────────────────┐
│  initGenerator.main(...)   │   standalone CLI — run before `mvn install`
└────────────────────────────┘
```

</details>

## Components

<details id="repo">
<summary><b><code>TestDataRepository</code></b></summary>

Singleton multi-source loader at `apis.middleware.testData.TestDataRepository`.

**Sources**

| Type | Backend | Notes |
|---|---|---|
| `csv` | `BufferedReader`, UTF-8 | Header row required |
| `excel` / `xlsx` | Apache POI `XSSFWorkbook` | Reads sheet `0`; cell values coerced to `String` |
| `db` | JDBC | Auto-registers driver from URL prefix (SQLite, MySQL, Postgres, H2, SQL Server, Oracle) |

**File resolution** — tries the filesystem first, then the classpath (full path, then bare filename). Default: `src/test/resources/testdata/testdata.csv`. Override with `-Dtestdata.file=...`.

**Grouping** — every row must have a `feature_name` and `scenario_name` column. Rows missing either are silently skipped. Remaining rows are bucketed by `"<feature_name>::<scenario_name>"`.

**Usage from Java**

```java
TestDataRepository repo = TestDataRepository.getInstance();
Map<String, List<Map<String, String>>> data = repo.loadData("csv"); // or "excel" / "db"

List<Map<String, String>> rows = data.get("TC001::Add item to inventory");
```

The cache is JVM-wide. Call `repo.clearCache()` to force a reload.

</details>

<details id="preprocessor">
<summary><b><code>DynamicDataPreProcessor</code></b></summary>

Walks every `.feature` file under the directory pointed to by `-Dcucumber.features` (the `classpath:` prefix is resolved against the runtime classpath) and rewrites them.

Per file:

1. Read source.
2. Look for a tag line starting with `@DataSource:` (`@DataSource:csv`, `@DataSource:excel`, `@DataSource:db`). **Skip the file entirely if absent.**
3. Extract the feature title (text after `Feature:`).
4. For each `Scenario Outline:` block:
   - Pull every `<placeholder>` token used in the outline body.
   - Look up rows in `TestDataRepository` by `"<feature_name>::<scenario_name>"`.
   - Filter the row maps down to just those placeholder columns.
   - Strip the existing `Examples:` block.
   - Append a freshly-built `Examples:` pipe-table with the filtered rows.
5. Write the new content back to the same file.

Plain `Scenario:` blocks are ignored — only outlines are processed.

</details>

<details id="init">
<summary><b><code>initGenerator</code></b></summary>

Standalone entry point — `initGenerator.main(String[])`.

What it does:
1. Creates `reports/` directory if missing.
2. Writes `reports/environment.properties` with `Environment`, `OS`, `Java Version` (consumed by Allure).
3. Runs `new DynamicDataPreProcessor().run()`.

Invocation (PowerShell):

```powershell
java -cp target/classes "-Dcucumber.features=classpath:features" apis.middleware.testData.initGenerator
```

This is **not** wired into the Cucumber lifecycle or Maven Failsafe — it's an explicit pre-step you run before `mvn install`.

</details>

<details id="example">
<summary><b>End-to-end example</b></summary>

**1. Create the data file** at `src/test/resources/testdata/testdata.csv`:

```
feature_name,scenario_name,item_id,quantity,order_id,user,product,invoice_id,amount
TC001,Add item to inventory,ITEM-0012,502,,,,,
TC001,Add item to inventory,ITEM-0099,1,,,,,
TC001,Add item to inventory,ITEM-1500,250,,,,,
```

**2. Write the feature** with a `@DataSource:csv` tag and a stub Examples block:

```gherkin
@DataSource:csv
Feature: TC001

  Scenario Outline: Add item to inventory
    Given url {{middlewareHost}}
    And path /inventory
    And request """{ "id": "<item_id>", "qty": <quantity> }"""
    When method POST
    Then status 200

    Examples:
      | item_id | quantity |
```

**3. Compile, generate, run**:

```powershell
mvn compile
java -cp target/classes "-Dcucumber.features=classpath:features" apis.middleware.testData.initGenerator
mvn install -Denv=uat
```

After step 2, the feature file on disk has been rewritten:

```gherkin
@DataSource:csv
Feature: TC001

  Scenario Outline: Add item to inventory
    Given url {{middlewareHost}}
    And path /inventory
    And request """{ "id": "<item_id>", "qty": <quantity> }"""
    When method POST
    Then status 200

    Examples:
      | item_id | quantity |
      | ITEM-0012 | 502 |
      | ITEM-0099 | 1 |
      | ITEM-1500 | 250 |
```

Cucumber runs three iterations of the outline against the real CSV rows.

</details>

<details id="poc">
<summary><b>Runnable PoC in this repo</b></summary>

A self-contained proof of concept lives at:

| File | Purpose |
|---|---|
| `src/test/resources/features/poc-testdata/1.inventory.feature` | Feature tagged `@poc @mock` + `@DataSource:csv` (on its own line), two `Scenario Outline:` blocks |
| `src/test/resources/testdata/testdata.csv` | 6 rows feeding both outlines (3 for `Add item`, 3 for `Submit order`) |
| `src/test/resources/wiremock/mappings/inventory/add-item.json` | WireMock stub: `POST /inventory/items` → `200` + echo body |
| `src/test/resources/wiremock/mappings/inventory/submit-order.json` | WireMock stub: `POST /inventory/orders` → `201` + echo body |

**What the PoC demonstrates**

1. One CSV with 9 data columns drives **two different outlines**. Each outline only receives the columns it references (`item_id, quantity` vs `order_id, user, product`).
2. Assertions use the JsonMatcher `#contains` marker via `match path $.x should be #contains Y` — covered in [Writing Features → Asserting status and content](04-writing-features.md#dsl-assert).
3. Because the feature is tagged `@mock`, it runs against the in-process WireMock server — no external middleware needed.

**The CSV** (`src/test/resources/testdata/testdata.csv`)

```
feature_name,scenario_name,item_id,quantity,order_id,user,product,invoice_id,amount
TC001,Add item to inventory,ITEM-0012,502,,,,,
TC001,Add item to inventory,ITEM-0099,1,,,,,
TC001,Add item to inventory,ITEM-1500,250,,,,,
TC001,Submit order,,,ORD-7001,alice,ITEM-0012,,
TC001,Submit order,,,ORD-7002,bob,ITEM-1500,,
TC001,Submit order,,,ORD-7003,carol,ITEM-0099,,
```

**Run it**

```powershell
# 1. Compile so target/classes contains the preprocessor
mvn compile

# 2. Rewrite the Examples blocks from the CSV
java -cp "target/classes;target/test-classes" `
     "-Dcucumber.features=classpath:features" `
     apis.middleware.testData.initGenerator

# 3. Run only the PoC against the local WireMock
mvn install -Denv=local "-Dcucumber.filter.tags=@poc"
```

### Before — feature as authored (stub Examples)

```gherkin
@poc @mock
@DataSource:csv
Feature: TC001

  Background:
    Given url {{mockServerUrl}}
    And header Content-Type = application/json

  Scenario Outline: Add item to inventory
    Given path /inventory/items
    And request
      """
      { "id": "<item_id>", "qty": <quantity> }
      """
    When method POST
    Then status 200
    And match path $.id should be #contains <item_id>
    And match path $.status should be #contains ACCEPTED

    Examples:
      | item_id   | quantity |
      | STUB-0000 | 0        |

  Scenario Outline: Submit order
    Given path /inventory/orders
    And request
      """
      { "orderId": "<order_id>", "user": "<user>", "product": "<product>" }
      """
    When method POST
    Then status 201
    And match path $.orderId should be #contains <order_id>
    And match path $.status should be #contains CREATED

    Examples:
      | order_id  | user | product   |
      | STUB-0000 | stub | STUB-0000 |
```

### After — same file once `initGenerator` has run

```gherkin
@poc @mock
@DataSource:csv
Feature: TC001

  Background:
    Given url {{mockServerUrl}}
    And header Content-Type = application/json

  Scenario Outline: Add item to inventory
    Given path /inventory/items
    And request
      """
      { "id": "<item_id>", "qty": <quantity> }
      """
    When method POST
    Then status 200
    And match path $.id should be #contains <item_id>
    And match path $.status should be #contains ACCEPTED

    Examples:
      | item_id | quantity |
      | ITEM-0012 | 502 |
      | ITEM-0099 | 1 |
      | ITEM-1500 | 250 |

  Scenario Outline: Submit order
    Given path /inventory/orders
    And request
      """
      { "orderId": "<order_id>", "user": "<user>", "product": "<product>" }
      """
    When method POST
    Then status 201
    And match path $.orderId should be #contains <order_id>
    And match path $.status should be #contains CREATED

    Examples:
      | order_id | user | product |
      | ORD-7001 | alice | ITEM-0012 |
      | ORD-7002 | bob | ITEM-1500 |
      | ORD-7003 | carol | ITEM-0099 |
```

**What changed**
- Each `Examples:` block — the single `STUB-0000` row was stripped and replaced by the rows whose `feature_name=TC001` + `scenario_name=<outline title>` match in the CSV.
- Only the placeholder columns referenced by each outline appear (`Add item` got `item_id`/`quantity`; `Submit order` got `order_id`/`user`/`product` — the `invoice_id` and `amount` columns from the CSV are filtered out because nothing references them).
- Everything outside the `Examples:` blocks is preserved verbatim — tags, background, steps, assertions.

**Run results**

| Outline | Iterations | Status |
|---|---|---|
| `Add item to inventory` | 3 (ITEM-0012, ITEM-0099, ITEM-1500) | 200 — `id` and `status` echoed by WireMock |
| `Submit order` | 3 (ORD-7001, ORD-7002, ORD-7003) | 201 — `orderId` and `status` echoed by WireMock |

Scenarios show up in Allure under the `@poc` tag label. Re-running steps 2–3 is idempotent — the preprocessor regenerates the same `Examples:` blocks each time. To reset the file back to stub rows for a clean demo, `git checkout src/test/resources/features/poc-testdata/1.inventory.feature`.

</details>

<details id="data-format">
<summary><b>Data file format</b></summary>

**Required columns**

| Column | Used for |
|---|---|
| `feature_name` | Matches text after `Feature:` in the feature file (literal match, trimmed) |
| `scenario_name` | Matches text after `Scenario Outline:` (literal match, trimmed) |

**Data columns** — every other column is a candidate placeholder. A column only ends up in the generated `Examples:` table if the outline body contains `<columnName>`. This means one wide CSV can feed many outlines; each outline picks only the columns it needs.

**CSV specifics**
- UTF-8 encoding.
- Comma delimiter (no quoting / escaping logic — values with commas will split incorrectly).
- Header row mandatory.
- Empty trailing values stay empty strings.

**Excel specifics**
- First sheet only (sheet index `0`).
- All cells coerced to `String` (`CellType.STRING`).

</details>

<details id="db-mode">
<summary><b>Database mode</b></summary>

Triggered by `@DataSource:db` on the feature **and** the CSV→DB switch is made via `loadData("db")` inside the preprocessor. (Note: `DynamicDataPreProcessor.run()` currently calls `loadData("csv")` unconditionally — switching to DB requires a code change there, or adapt the preprocessor to read the tag's suffix.)

**Required system properties**

| Property | Example | Purpose |
|---|---|---|
| `-Ddb.url` | `jdbc:postgresql://localhost:5432/testdb` | JDBC URL — driver auto-loaded from prefix |
| `-Ddb.user` | `tester` | Username (omit for trust auth / SQLite) |
| `-Ddb.pass` | `secret` | Password |
| `-Ddb.table` | `testdata` (default) | Table to `SELECT *` from |

**Supported drivers** (auto-registered): SQLite, MySQL, PostgreSQL, H2, SQL Server, Oracle.

**Sample SQLite invocation**

```powershell
java -cp "target/classes;target/test-classes;<sqlite-jdbc.jar>" `
  "-Dcucumber.features=classpath:features" `
  "-Ddb.url=jdbc:sqlite:src/test/resources/testdata/testdata.db" `
  "-Ddb.table=testdata" `
  apis.middleware.testData.initGenerator
```

The schema must include the `feature_name` and `scenario_name` columns plus the placeholder columns referenced by your outlines.

</details>

<details id="sys-props">
<summary><b>System properties reference</b></summary>

| Property | Default | Used by | Purpose |
|---|---|---|---|
| `-Dcucumber.features` | (none) | `DynamicDataPreProcessor` | Directory or `classpath:` to scan for `.feature` files |
| `-Dtestdata.file` | `src/test/resources/testdata/testdata.csv` | `TestDataRepository` | CSV / Excel path |
| `-Ddb.url` | (none) | `TestDataRepository` | JDBC URL |
| `-Ddb.user` | `""` | `TestDataRepository` | DB username |
| `-Ddb.pass` | `""` | `TestDataRepository` | DB password |
| `-Ddb.table` | `testdata` | `TestDataRepository` | Table name for `SELECT *` |
| `-Denv` | `dev` (in `initGenerator`) | Allure `environment.properties` | Reported in Allure env block |

</details>

<details id="things-to-know">
<summary><b>Things to know</b></summary>

- **In-place file mutation.** Each run of `initGenerator` rewrites every tagged feature file on disk. If you hand-edit an `Examples:` block in a `@DataSource:`-tagged feature, the next run replaces your edits with whatever is in the data source.
- **Match key is the literal feature title**, not the file name. `Feature: TC001` matches CSV rows with `feature_name=TC001`, regardless of whether the file is `TC001.feature` or `1.inventory.feature`.
- **Only `Scenario Outline:` is processed.** Plain `Scenario:` blocks are left alone.
- **No CSV escaping.** Values containing commas, newlines, or quotes will be split incorrectly by the naive `line.split(",", -1)`. Use Excel or the DB source if your data is complex.
- **Cache lasts for the JVM.** `initGenerator` is a one-shot CLI, so this is rarely an issue — but if you embed the repository in a longer-running JVM, call `clearCache()` after the source changes.
- **`@DataSource:` value isn't currently read.** The preprocessor only checks for the tag's presence and unconditionally calls `loadData("csv")`. Switching to Excel or DB today means editing `DynamicDataPreProcessor.run()`.
- **DB query is plain string concatenation** (`"SELECT * FROM " + dbTable`). Fine for test-runner use because `dbTable` comes from a controlled system property; don't wire user input into it.
- **No features use `@DataSource:` today.** The wiring is in place but unused; the only sample is `src/test/resources/testdata/testdata.csv` with one row for `TC001`.

</details>
