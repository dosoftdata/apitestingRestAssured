# Middleware API Testing Framework — Documentation

A Cucumber + JUnit Platform + RestAssured framework with a custom **Karate-style DSL**: feature files express HTTP flows declaratively, step definitions live in `src/main/java`, and a JS configuration file (`config.js`) drives per-environment values. Feature-level parallelism is opt-in via `-Dparallel=true -Dthread=<n>` (defaults: sequential, 1 thread).

---

## Navigation

- [Index — all pages](#index)
- [Importing into Confluence](#confluence)
- [Quick start (for the impatient)](#quick-start)

---

<details id="index" open>
<summary><b>Index — all pages</b></summary>

| # | Page | What's in it |
|---|---|---|
| 1 | [Overview](01-overview.md) | What this project is, tech stack, design philosophy |
| 2 | [Architecture](02-architecture.md) | Source layout, key components, how they fit together |
| 3 | [Configuration](03-configuration.md) | `config.js`, environment switching, variable resolution |
| 4 | [Writing Features](04-writing-features.md) | DSL reference, examples, placeholders |
| 5 | [Step Definitions](05-step-definitions.md) | Extending the DSL, `ApiBase.spec()` pattern, Lombok DTOs |
| 6 | [Hooks & Fixtures](06-hooks-and-fixtures.md) | Lifecycle, `ScenarioContext`, `PlayerBootstrap` pattern |
| 7 | [Running Tests](07-running-tests.md) | Local Maven, system properties, tag filtering |
| 8 | [CI/CD Pipeline](08-cicd.md) | GitLab workflow, smoke vs regression, Maven cache |
| 9 | [Reporting](09-reporting.md) | Allure, JUnit XML, GitLab Pages |
| 10 | [Troubleshooting](10-troubleshooting.md) | Common issues and how to fix them |
| 11 | [External Test Data](11-test-data.md) | CSV/Excel/DB-driven `Scenario Outline` examples — `@DataSource:` workflow |
| 12 | [Random Player Selection](12-random-player-selection.md) | `@randomPlayer` tag — pick a pooled player per feature, filtered by enabled/disabled + balance |

</details>

<details id="confluence">
<summary><b>Importing into Confluence</b></summary>

Each markdown file in this folder maps cleanly to one Confluence page. Two paths:

1. **Manual paste** — In Confluence, create a page and use *Insert → Markdown* (or the `/markdown` slash command) and paste the contents.
2. **Bulk import** — If your Confluence space has the *Markdown Importer* app, point it at this `docs/` folder.

Anchors (`#section-id`) and relative links (`02-architecture.md`) survive Confluence import in most modern spaces; verify after the first import.

</details>

<details id="quick-start">
<summary><b>Quick start (for the impatient)</b></summary>

```powershell
# Run everything against UAT
mvn clean install -Denv=uat

# Run only @smoke
mvn clean install -Denv=uat -Dcucumber.filter.tags="@smoke"

# Run only PAM scenarios that need a registered player
mvn clean install -Denv=uat -Dcucumber.filter.tags="@needsPlayer"
```

For details on what each tag does, see [Running Tests](07-running-tests.md).

</details>
