# 3. Configuration

All per-environment values live in **one file**: `src/test/resources/config.js`. It is evaluated **once per JVM** by `ConfigLoader` (via Nashorn) and the resulting JS object is flattened into `ScenarioContext`.

---

## Navigation

- [How `config.js` is wired in](#wired-in)
- [Anatomy of `config.js`](#anatomy)
- [How key flattening works](#flattening)
- [Environment selection](#env-selection)
- [Random / time-sensitive values are evaluated once](#random-values)
- [Adding a new key](#adding-key)
- [Caveats](#caveats)

---

<details id="wired-in" open>
<summary><b>How <code>config.js</code> is wired in</b></summary>

```
@Before(order=0)                       loadConfig()                 ScenarioContext
   ↓                                       ↓                              ↓
ConfigLoader.loadConfig()  ──→  Nashorn evals fn() once  ──→  flat keys: pam.webBaseUrl,
                                                              janus.baseUrl, GAMES.JOKER, ...
```

After load, every flat key is reachable as a placeholder:

```gherkin
Given url {{pam.webBaseUrl}}
And path /web/customer/rest/v1/otp
And header Authorization = Bearer {{janusToken}}
```

</details>

<details id="anatomy">
<summary><b>Anatomy of <code>config.js</code></b></summary>

Simplified excerpt:

```javascript
function fn(name) {
  var env = java.lang.System.getProperty("env");
  if (!env) { env = "uat"; }                          // default

  var RandomUtil   = Java.type('apis.middleware.utilities.RandomUtil');
  var TimestampUtil = Java.type('apis.middleware.utilities.TimestampUtil');

  var config = {
    env: env,

    // Top-level URLs (defaults are dev/integration values)
    janusBaseUrl     : "https://janusint.development.dc.opap",
    middlewareHost   : "https://uip-dev.development.dc.opap",
    psMiddlewareHost : "https://ciapi.pamestoixima.gr",

    // Nested objects flatten to dot-paths: janus.baseUrl, janus.basePath, ...
    janus: {
      baseUrl: "https://janusint.development.dc.opap",
      basePath: "web/access/oidc/token",
      ...
    },
    pam: {
      $random8Digit: RandomUtil.generateSecureDigits(8),  // computed once per JVM
      webBaseUrl: "https://onlineapidev.allwyn.gr",
      boBaseUrl: "https://pamint.development.dc.opap",
    },

    // Constants and one-shot random values
    bo_username: "admin",
    bo_password: "admin",
    $randomPassword: RandomUtil.generatePassword(),
    timestamp: TimestampUtil.getLocalTimestamp(),
    uuid: java.util.UUID.randomUUID(),

    // Maps & arrays
    GAMES: { JOKER: "JOKER", SPORTSBOOK: "SPORTSBOOK", ... },
    apiKeys: ["key1", "key2"]
  };

  // Per-environment overrides
  if (env === "uat") {
    config.middlewareHost      = "https://uip-uat.development.dc.opap";
    config.janus.baseUrl       = "https://janusuat.development.dc.opap";
    config.pam.webBaseUrl      = "https://onlineapiuat.allwyn.gr";
    config.pam.boBaseUrl       = "https://pamuat.development.dc.opap";
    config.playerId            = 939932925;
  } else if (env === "preprod") {
    ...
  } else if (env === "local") {
    config.middlewareHost = "http://localhost:80";
    ...
  }

  return config;
}
```

</details>

<details id="flattening">
<summary><b>How key flattening works</b></summary>

`ConfigLoader.storeNested` walks the returned JS object and emits flat keys:

| JS structure | Flat key |
|---|---|
| `janus: { baseUrl: "..." }` | `janus.baseUrl` |
| `pam: { webBaseUrl: "...", boBaseUrl: "..." }` | `pam.webBaseUrl`, `pam.boBaseUrl` |
| `GAMES: { JOKER: "JOKER" }` | `GAMES.JOKER` |
| `apiKeys: ["key1", "key2"]` | `apiKeys[0]`, `apiKeys[1]` |
| `uuid: java.util.UUID.randomUUID()` | `uuid` |

In feature files use `{{flat.key}}`:

```gherkin
Given url {{pam.boBaseUrl}}
And def gameType = {{GAMES.JOKER}}
And def first key = {{apiKeys[0]}}
```

</details>

<details id="env-selection">
<summary><b>Environment selection</b></summary>

Set `-Denv=...` on the Maven command line.

| `env` | Defaults |
|---|---|
| `dev` | `*int.development.dc.opap`, `onlineapidev.allwyn.gr` |
| `uat` (default if unset, see note below) | `*uat.development.dc.opap`, `onlineapiuat.allwyn.gr` |
| `preprod` | `*pre.development.dc.opap`, `onlineapipre.allwyn.gr` |
| `local` | `localhost:80`, dev URLs for everything else |

Note: the JS code uses `if (!env) { env = "uat"; }` as a fallback when no `-Denv` is provided. The CI default in `.gitlab-ci.yml` is also `uat`.

```powershell
# Run against uat
mvn clean install -Denv=uat

# Run against preprod
mvn clean install -Denv=preprod
```

</details>

<details id="random-values">
<summary><b>Random / time-sensitive values are evaluated once</b></summary>

```javascript
pam: {
  $random8Digit: RandomUtil.generateSecureDigits(8),  // ← evaluated once per JVM
}
```

Because `ConfigLoader` has a `static boolean loaded` guard, `fn()` runs **exactly once** per Maven test execution. So `{{pam.$random8Digit}}` returns the **same value** for every scenario in a single suite run.

This is what makes the `PlayerBootstrap` pattern viable: the random MSISDN used to register a player at suite-start matches the one referenced by every scenario that consumes it.

</details>

<details id="adding-key">
<summary><b>Adding a new key</b></summary>

1. Add it to `config.js`:
   ```javascript
   newService: {
     baseUrl: "https://devservice.example.com",
     timeout: 5000
   }
   ```
2. Add env-specific overrides:
   ```javascript
   if (env === "uat") {
     config.newService.baseUrl = "https://uatservice.example.com";
   }
   ```
3. Use immediately in features:
   ```gherkin
   Given url {{newService.baseUrl}}
   ```

No Java changes required. ConfigLoader will pick it up automatically.

</details>

<details id="caveats">
<summary><b>Caveats</b></summary>

- **Nashorn is deprecated** in Java 17+ but still functional. The framework explicitly uses `org.openjdk.nashorn:nashorn-core` for Java 15+. If/when you migrate to a future JDK without Nashorn, a port to GraalVM JS or Rhino would be needed.
- **Don't store secrets in `config.js`.** Anything sensitive should come from environment variables / CI secret variables and be injected via `-DsomeSecret=...` then read with `java.lang.System.getProperty(...)`.
- **Don't put per-scenario values in `config.js`.** It's loaded once. Anything that should change per scenario goes through `def` in the feature file.

</details>
