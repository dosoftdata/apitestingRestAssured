package apis.middleware.stepDefs;


import static io.restassured.RestAssured.given;
import static io.restassured.http.ContentType.URLENC;
import static org.awaitility.Awaitility.await;
import static org.testng.Assert.assertEquals;
import apis.middleware.core.base.ApiBase;
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.dsl.actions.DslHelper;
import apis.middleware.models.request.payment.Card;
import apis.middleware.models.request.payment.CardPaymentRequest;
import io.cucumber.java.en.*;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import apis.middleware.utilities.*;


/**
 * The type One row spec steps.
 */
@Slf4j
public class oneRowSpecSteps extends DslHelper {

    /**
     * Instantiates a new One row spec steps.
     *
     * @param context the context
     */
    public oneRowSpecSteps(ScenarioContext context) {
        super(context);
    }

    /**
     * User has janus token.
     */
    @Given("^User has janus token$")
    public void user_has_janus_token() {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("janus.baseUrl"));
        spec.setBasePath(context.getProp("janus.basePath"));
        spec.header("Content-Type",context.getProp("janus.contentType"));
        spec.header("Authorization",context.getProp("janus.authorization"));
        spec.setFormParam("grant_type",context.getProp("janus.grantType"));
        spec.setFormParam("scope",context.getProp("janus.scope"));
        spec.setFormParam("ssbtId",context.getProp("ssbtid"));
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);
        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        context.setProp("janusToken", resp.get("access_token"));
        context.setProp("janusTokenType", resp.get("token_type"));

    }


    /**
     * Casino favorite games.
     *
     * @param location the location
     */
    @Given("^Get Casino Favorite Games in (.*) location$")
    public void casino_favorite_games( String location ) {
        spec = ApiBase.spec();
        AtomicReference<Response> lastResp = new AtomicReference<>();
        spec.setBaseUri(context.getProp("psMiddlewareHost"));
        spec.setBasePath("uip/casino/api/v1.0/games/favorite");
        spec.header("Content-Type","application/json");
        spec.header("Accept","application/json");
        spec.header("locale","el-GR");
        spec.header("x-player-id",context.getProp("playerId"));
        spec.param("location",location);
        await()
            .atMost(Duration.ofMinutes(5).plusSeconds(30))
            .pollInterval(Duration.ofMillis(5000))
            .ignoreExceptions()
            .until(() -> {
                Response resp = context.getRes()
                    .spec(spec.build())
                    .when().get();
                lastResp.set(resp);
              return resp.statusCode() == 200;
            });
        context.getApi().setResponse(lastResp.get());
        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        context.setProp("casinoFavoriteGames", String.join(",", resp.getList("data.id")));
        List<String> hrefs = resp.getList("data.vendor.href");
        List<String> ids = hrefs.stream()
            .map(h -> h.substring(h.lastIndexOf("/") + 1))
            .collect(Collectors.toList());
        context.setProp("casinoFavoriteGamesVendor", String.join(",", ids) );

    }

    /**
     * User has tora token.
     */
    @Given("^User has tora token$")
    public void user_has_tora_token() {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("tora.baseUrl"));
        spec.setBasePath(context.getProp("tora.basePath"));
        spec.header("Content-Type",context.getProp("janus.contentType"));
        spec.header(" Cookie",context.getProp("tora.cookie"));
        spec.setFormParam("grant_type",context.getProp("tora.grant_type"));
        spec.setFormParam("client_id",context.getProp("tora.client_id"));
        spec.setFormParam("client_secret",context.getProp("tora.client_secret"));
        spec.setFormParam("scope",context.getProp("tora.scope"));
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);
        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        context.setProp("toraAccessToken", resp.get("access_token"));
        context.setProp("toraTokenType", resp.get("token_type"));
    }
    /**
     * User has Natech token.
     */
    @Given("^User has natech token$")
    public void user_has_natech_token() {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("tora.baseUrl"));
        spec.setBasePath(context.getProp("tora.natech.tenant_id").concat("/oauth2/v2.0/token"));
        spec.header("Content-Type",context.getProp("janus.contentType"));
        spec.header(" Cookie",context.getProp("tora.cookie"));
        spec.setFormParam("grant_type",context.getProp("tora.grant_type"));
        spec.setFormParam("client_id",context.getProp("tora.natech.client_id"));
        spec.setFormParam("client_secret",context.getProp("tora.natech.client_secret"));
        spec.setFormParam("scope",context.getProp("tora.scope"));
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);
        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        context.setProp("natechAccessToken", resp.get("access_token"));
        context.setProp("natechTokenType", resp.get("token_type"));
    }
    /**
     * User has Intralot token.
     */
    @Given("^User has Intralot token$")
    public void user_has_intralot_token() {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("l10ApiGatewayUrl"));
        spec.setHeader("Authorization", "Basic b3BhcDph");
        spec.setHeader("Content-Type",context.getProp("janus.contentType"));
        spec.setFormParam("grant_type",context.getProp("tora.grant_type"));
        context.getApi().setResponse(spec.when().post("/authentication/token"));
        context.getApi().getResponse().then().statusCode(200);
        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        context.setProp("intralotAccessToken", resp.get("access_token"));
        context.setProp("intralotTokenType", resp.get("token_type"));
//        Response response =
//            (Response) given()
//                .baseUri("https://apigatewayjh.l10.ilotdev.dc.opap")
//                .header("Authorization", "Basic b3BhcDph")
//                .contentType(ContentType.URLENC)
//                .formParam("grant_type", "client_credentials")
//                .when()
//                .post("/authentication/token")
//                .then()
//                .log().all()
//                .statusCode(200);
    }
    @Given("^Get Tipsters betslips-recommended outcomes_ids in (.*) location and (.*) channel$")
    public void tipsters_betslips_recommended_outcomes_ids( String location, String channel ) {
        String dataKey = "Tipsters/betslips/recommended/outcomes_ids";
       if(!context.hasProp(dataKey)){
           spec = ApiBase.spec();
           AtomicReference<Response> lastResp = new AtomicReference<>();
           spec.setBaseUri(context.getProp("psMiddlewareHost"));
           spec.setBasePath("uip/retail-sportsbook/api/v1.0/sports/betslips/recommended");
           spec.header("Content-Type","application/json");
           spec.header("Accept","application/json");
           spec.header("locale","el-GR");
           spec.header("channel",channel);
           spec.header("x-player-id",context.getProp("playerId"));
           spec.param("location",location);
           await()
               .atMost(Duration.ofMinutes(5).plusSeconds(30))
               .pollInterval(Duration.ofMillis(5000))
               .ignoreExceptions()
               .until(() -> {
                   Response resp = context.getRes()
                       .spec(spec.build())
                       .when().get();
                   lastResp.set(resp);
                   return resp.statusCode() == 200;
               });
           context.getApi().setResponse(lastResp.get());
           JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
           List<String> outcomeIds = resp.getList("data.allBetSlips.events.markets.outcomes.id.flatten()", String.class);
           context.setProp(dataKey, String.join(",", outcomeIds));
       }

    }

    @And("^extract host and query param (.*) from (.*) url$")
    public void getHostAndParamsFromUrl(String paramKey, String urlKey) {
        synchronized (context) { // Ensure thread safety if context is shared
            if (context.hasProp(urlKey)) {
                String fullUrl = context.getProp(urlKey);
                args = extractHostAndParams(fullUrl);
                // Extract host and params safely
                String host = (String) args.get("host");
                @SuppressWarnings("unchecked")
                Map<String, Object> params = (Map<String, Object>) args.get("params");
                context.setProp(urlKey, host);
                context.setProp(paramKey, params.getOrDefault(paramKey, null));
            }
        }
    }
    @Given("Set Instant Win test data")
    public void set_instant_win_test_data() {
        context.setProp("$random10Digit", RandomUtil.generateSecureDigits(20));
        context.setProp("dateTimeNowPlus", TimestampUtil.getLocalDateTimePlus(1));
        context.setProp("dateTimeNowPlus2", TimestampUtil.getLocalDateTimePlus(3));
    }

    @And("Tora card payment")
    public void tora_card_payment() {
        String baseUri   = "https://".concat(context.getProp("url"));
        String sessionId = context.getProp("sid");
        String token     = context.getProp("janusToken");
        // Build the POJOs using Lombok @Builder
        Card card = Card.builder()
            .number("5413330089604111")
            .expMonth(5)
            .expYear(2031)
            .holderName("TEST WALLET")
            .cvv("100")
            .build();

        CardPaymentRequest req = CardPaymentRequest.builder()
            .pk(context.getProp("pk"))
            .type("card")
            .email("email@test.com")
            .card(card)
            .build();

        spec = ApiBase.spec();
        spec.setBaseUri(baseUri);
        spec.pathParam("id", sessionId);
        spec.header("Authorization", "Bearer " + token);
        spec.contentType("application/json");
        spec.body(req);
        context.getApi().setResponse(spec.when().put("/api/pay/sessions/{id}"));
        context.getApi().getResponse().then().statusCode(200);
        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        assertEquals(resp.get("status"), "processed");
        context.setProp("paymentCheckoutUrl", resp.get("url"));

        spec = ApiBase.spec();
        context.getApi().setResponse( spec.when().get(context.getProp("paymentCheckoutUrl")));

        // The HTML response body as a String
        String responseBody = context.getApi().getResponse().then().extract().body().asPrettyString();

        // Regex to extract the 'action' URL from the form
        Pattern actionPattern = Pattern.compile("<form[^>]*name=\"redirectForm\"[^>]*action=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
        Matcher actionMatcher = actionPattern.matcher(responseBody);

        // Regex to extract the 'tok' input value
        Pattern tokPattern = Pattern.compile("<input[^>]*name=\"t\"[^>]*value=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
        Matcher tokMatcher = tokPattern.matcher(responseBody);

        // Regex to extract the 'enrolled' input value
        Pattern enrolledPattern = Pattern.compile("<input[^>]*name=\"enrolled\"[^>]*value=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
        Matcher enrolledMatcher = enrolledPattern.matcher(responseBody);

        // Regex to extract the 'status' input value
        Pattern statusPattern = Pattern.compile("<input[^>]*name=\"status\"[^>]*value=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
        Matcher statusMatcher = statusPattern.matcher(responseBody);

        // Regex to extract the 'sig' input value
        Pattern sigPattern = Pattern.compile("<input[^>]*name=\"sig\"[^>]*value=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
        Matcher sigMatcher = sigPattern.matcher(responseBody);

        String redirectUrl = null;
        String sig = null;
        String tok = null;
        String enrolled = null;
        String status = null;

        if (tokMatcher.find()) {
            tok = tokMatcher.group(1);
        }
        if (enrolledMatcher.find()) {
            enrolled = enrolledMatcher.group(1);
        }

        if (statusMatcher.find()) {
            status = statusMatcher.group(1);
        }

        if (sigMatcher.find()) {
            sig = sigMatcher.group(1);
        }

        if (actionMatcher.find()) {
            redirectUrl = actionMatcher.group(1);
        }

        if (sigMatcher.find()) {
            sig = sigMatcher.group(1);
        }

        // Print or store values
        log.info("tok: {}" , tok);
        log.info("enrolled: {}" ,  enrolled);
        log.info("status: {}" ,  status);
        log.info("redirectUrl: {}" , redirectUrl);
        log.info("sig: {}" , sig);

        spec = ApiBase.spec();
        spec.setRedirectFollow(true);
        spec.setQueryParam("t", tok);
        spec.setQueryParam("enrolled", enrolled);
        spec.setQueryParam("status", status);
        spec.setQueryParam("sig", sig);
        context.getApi().setResponse( spec.when().get(redirectUrl));
        context.getApi().getResponse().then().statusCode(200);

//        responseBody = context.getApi().getResponse().then().extract().body().asPrettyString();
//
//        // Regex to extract the 'action' URL from the form
//        actionPattern = Pattern.compile("<form[^>]*name=\"redirectForm\"[^>]*action=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
//        actionMatcher = actionPattern.matcher(responseBody);
//
//        // Regex to extract the 'sig' input value
//        Pattern sidPattern = Pattern.compile("<input[^>]*name=\"sid\"[^>]*value=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
//        Matcher sidMatcher = sidPattern.matcher(responseBody);
//        String sid = null;
//        if (actionMatcher.find()) {
//            redirectUrl = actionMatcher.group(1);
//        }
//
//        if (sidMatcher.find()) {
//            sid = sidMatcher.group(1);
//        }
//        log.info("redirectUrl: {}" , redirectUrl);
//        log.info("sid: {}" , sid);
//
//        spec = ApiBase.spec();
//        spec.setRedirectFollow(false);
//        spec.setQueryParam("sid", sid);
//        context.getApi().setResponse( spec.when().get(redirectUrl));
//        context.getApi().getResponse().then().statusCode(200);
    }

    @And("^extract string using (.*) with name (.*) from body response$")
    public void extractStringFromResponseBody(String delimiter, String name) {
        String body = context.getProp("response_body");
        String hash = body.split(delimiter)[1].substring(0, 36);
        context.setProp(name, hash);
    }
}
