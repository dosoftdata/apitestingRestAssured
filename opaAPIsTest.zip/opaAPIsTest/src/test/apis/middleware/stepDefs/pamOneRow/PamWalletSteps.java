package apis.middleware.stepDefs.pamOneRow;

import apis.middleware.core.base.ApiBase;
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.dsl.actions.DslHelper;
import apis.middleware.models.request.pam.deposit.CardThreeDSecureRequest;
import apis.middleware.models.request.pam.deposit.DepositRequest;
import io.restassured.path.json.JsonPath;
import apis.middleware.models.request.pam.wallet.MoneyAmount;
import apis.middleware.models.request.pam.wallet.WalletPaymentMethod;
import apis.middleware.models.request.pam.wallet.WalletPaymentOwner;
import apis.middleware.models.request.pam.wallet.WalletPaymentRequest;
import apis.middleware.models.request.pam.withdraw.WithdrawalApprovalRequest;
import apis.middleware.models.request.pam.withdraw.WithdrawalCommitRequest;
import apis.middleware.models.request.pam.withdraw.WithdrawalPaymentMethod;
import apis.middleware.models.request.pam.withdraw.WithdrawalRequest;
import apis.middleware.models.request.payment.PaymentCodeRef;
import io.cucumber.java.en.And;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class PamWalletSteps extends DslHelper {

    public PamWalletSteps(ScenarioContext context) {
        super(context);
    }

    // ========================= PRIVATE BUILDERS =========================

    private String resolveStringValue(String valueRef) {
        return ScenarioContext.resolve(valueRef);
    }

    private Object resolveObjectValue(String valueRef) {
        String resolvedValue = resolveStringValue(valueRef);
        return resolvedValue == null || "null".equalsIgnoreCase(resolvedValue) ? null : resolvedValue;
    }

    private Double resolveDoubleValue(String valueRef) {
        return Double.parseDouble(resolveStringValue(valueRef));
    }

    private Integer resolveIntegerValue(String valueRef) {
        return Integer.parseInt(resolveStringValue(valueRef));
    }

    private Boolean resolveBooleanValue(String valueRef) {
        return Boolean.parseBoolean(resolveStringValue(valueRef));
    }

    private DepositRequest buildCardDeposit(String amount, String currency, String paymentMethodType, String paymentType) {
        return DepositRequest.builder()
                .amount(amount)
                .currency(currency)
                .paymentMethodType(paymentMethodType)
                .paymentType(paymentType)
                .build();
    }

    private CardThreeDSecureRequest buildCardThreeDSecureRequest(String merchantReference, String signature,
                                                                 String cardNumber, String holderName, String cvv,
                                                                 String expMonth, String expYear, String amount,
                                                                 String pk, String currency) {
        return CardThreeDSecureRequest.builder()
                .card(CardThreeDSecureRequest.Card.builder()
                        .number(cardNumber)
                        .holderName(holderName)
                        .cvv(cvv)
                        .expMonth(expMonth)
                        .expYear(expYear)
                        .build())
                .merchantReference(merchantReference)
                .signature(signature)
                .amount(amount)
                .pk(pk)
                .currency(currency)
                .build();
    }

  private CardThreeDSecureRequest buildMasterCard3DSecureRequest(
          String cardNumber, String holderName, String cvv,
          String expMonth, String expYear, String merchantReference, String signature, String amount, String currency) {
    CardThreeDSecureRequest.CardThreeDSecureRequestBuilder builder = CardThreeDSecureRequest.builder()
            .card(CardThreeDSecureRequest.Card.builder()
                    .number(resolveStringValue(cardNumber))
                    .holderName(resolveStringValue(holderName))
                    .cvv(resolveStringValue(cvv))
                    .expMonth(resolveStringValue(expMonth))
                    .expYear(resolveStringValue(expYear))
                    .build())
            .merchantReference(resolveStringValue(merchantReference))
            .signature(resolveStringValue(signature))
            .amount(resolveStringValue(amount))
            .pk(resolveStringValue("{{pam.card_primary_key}}"))
            .currency(resolveStringValue(currency));

    return builder.build();
  }

    private CardThreeDSecureRequest buildDefaultCardThreeDSecureRequestWithAmount(String amount) {

        return CardThreeDSecureRequest.builder()
                .card(CardThreeDSecureRequest.Card.builder()
                        .number("5457210001000001")
                        .holderName("TEST PROD")
                        .cvv("152")
                        .expMonth("12")
                        .expYear("2030")
                        .build())
                .amount(amount)
                .pk(resolveStringValue("{{pam.card_primary_key}}"))
                .currency("EUR")
                .build();
    }

    private String toMinorCurrencyUnit(String amount) {
        return new BigDecimal(amount)
                .movePointRight(2)
                .setScale(0, RoundingMode.UNNECESSARY)
                .toPlainString();
    }

    private WalletPaymentRequest buildWalletDeposit(String action, String operation, String channel, String paymentType,
                                                    String paymentMethodType, String paymentMethodId, String paymentCode,
                                                    String pspPaymentId, String amount, String amountCurrency,
                                                    String serviceCostAmount, String serviceCostCurrency, String ownerId,
                                                    String ownerType, String pspId, String pspTargetId, String forceReview,
                                                    String paybankId) {
        return WalletPaymentRequest.builder()
                .action(action)
                .operation(operation)
                .channel(channel)
                .paymentType(paymentType)
                .paymentMethod(WalletPaymentMethod.builder()
                        .type(paymentMethodType)
                        .id(paymentMethodId)
                        .paymentCode(PaymentCodeRef.builder()
                                .paymentCode(paymentCode)
                                .build())
                        .build())
                .pspPaymentId(pspPaymentId)
                .amount(MoneyAmount.builder().amount(resolveDoubleValue(amount)).currency(amountCurrency).build())
                .serviceCost(MoneyAmount.builder().amount(resolveDoubleValue(serviceCostAmount)).currency(serviceCostCurrency).build())
                .owner(WalletPaymentOwner.builder()
                        .id(ownerId)
                        .type(resolveIntegerValue(ownerType))
                        .build())
                .pspId(pspId)
                .pspTargetId(pspTargetId)
                .forceReview(resolveBooleanValue(forceReview))
                .paybankId(paybankId)
                .build();
    }

    private WithdrawalRequest buildWithdrawal(String action, String operation, String channel, String paymentType,
                                              String withdrawalType, String paymentMethodId, String card, String bankId, String voucher,
                                              String pspPaymentId, String amount, String amountCurrency,
                                              String serviceCostAmount, String serviceCostCurrency, String ownerId,
                                              String ownerType, String pspId, String pspTargetId, String forceReview,
                                              String paybankId) {
        return WithdrawalRequest.builder()
                .action(action)
                .operation(operation)
                .channel(channel)
                .paymentType(paymentType)
                .paymentMethod(WithdrawalPaymentMethod.builder()
                        .type(withdrawalType)
                        .id(resolveNullableString(paymentMethodId))
                        .card(resolveObjectValue(card))
                        .bankAccount(buildWithdrawalBankAccount(bankId))
                        .voucher(resolveObjectValue(voucher))
                        .build())
                .pspPaymentId(pspPaymentId)
                .amount(WithdrawalRequest.MoneyAmount.builder()
                        .amount(amount)
                        .currency(amountCurrency)
                        .build())
                .serviceCost(WithdrawalRequest.MoneyAmount.builder()
                        .amount(amount)
                        .currency(serviceCostCurrency)
                        .build())
                .owner(WithdrawalRequest.Owner.builder()
                        .id(ownerId)
                        .type(ownerType)
                        .build())
                .pspId(pspId)
                .pspTargetId(pspTargetId)
                .forceReview(resolveBooleanValue(forceReview))
                .paybankId(paybankId)
                .build();
    }

    private WithdrawalRequest buildDefaultCardWithdrawal(String fingerprint, String amount) {
        return WithdrawalRequest.builder()
                .action("PREPARE")
                .operation("WALLET_WITHDRAWAL")
                .channel("WEB")
                .paymentType("PT_TRANSFER_OUT")
                .paymentMethod(WithdrawalPaymentMethod.builder()
                        .type("CARD")
                        .id(fingerprint)
                        .card(null)
                        .bankAccount(WithdrawalRequest.BankAccount.builder()
                                .bankId("112233")
                                .build())
                        .voucher(null)
                        .build())
                .pspPaymentId("pspId.1")
                .amount(WithdrawalRequest.MoneyAmount.builder()
                        .amount(amount)
                        .currency("EUR")
                        .build())
                .serviceCost(WithdrawalRequest.MoneyAmount.builder()
                        .amount("1.0")
                        .currency("EUR")
                        .build())
                .owner(WithdrawalRequest.Owner.builder()
                        .id(context.getProp("playerId"))
                        .type("1")
                        .build())
                .pspId("TORA")
                .pspTargetId("CARD")
                .forceReview(false)
                .paybankId("123")
                .build();
    }


    private String resolveNullableString(String valueRef) {
        Object resolvedValue = resolveObjectValue(valueRef);
        return resolvedValue == null ? null : String.valueOf(resolvedValue);
    }

    private WithdrawalRequest.BankAccount buildWithdrawalBankAccount(String bankId) {
        String resolvedBankId = resolveNullableString(bankId);
        return resolvedBankId == null ? null : WithdrawalRequest.BankAccount.builder()
                .bankId(resolvedBankId)
                .build();
    }

    private WithdrawalCommitRequest buildWithdrawalCommit(String amount, String serviceCostCurrency,
                                                         String forceReview, String auditData) {
        return WithdrawalCommitRequest.builder()
                .serviceCost(WithdrawalRequest.MoneyAmount.builder()
                        .amount(amount)
                        .currency(serviceCostCurrency)
                        .build())
                .forceReview(resolveBooleanValue(forceReview))
                .auditData(auditData)
                .build();
    }

    private WithdrawalCommitRequest buildDefaultWithdrawalCommit(String amount, String serviceCostCurrency,
                                                          String forceReview, String auditData) {
        return WithdrawalCommitRequest.builder()
                .serviceCost(WithdrawalRequest.MoneyAmount.builder()
                        .amount(amount)
                        .currency(serviceCostCurrency)
                        .build())
                .forceReview(resolveBooleanValue(forceReview))
                .auditData(resolveObjectValue(auditData))
                .build();
    }

    private WithdrawalApprovalRequest buildWithdrawalApproval(String action) {
        return WithdrawalApprovalRequest.builder()
                .action(action)
                .build();
    }

    // ========================= STEP DEFINITIONS =========================

    @And("^card deposit request body amount ([^ ]+) currency ([^ ]+) paymentMethodType ([^ ]+) paymentType ([^ ]+)$")
    public void cardDepositRequestBody(String amount, String currency, String paymentMethodType, String paymentType) {
        context.getSpec().setBody(buildCardDeposit(
                resolveStringValue(amount),
                resolveStringValue(currency),
                resolveStringValue(paymentMethodType),
                resolveStringValue(paymentType)));
    }

    @And("^default card 3DSecure request body with amount ([^ ]+)$")
    public void defaultCard3dsRequestBody(String amount) {
        context.getSpec().setBody(buildDefaultCardThreeDSecureRequestWithAmount(
                resolveStringValue(amount)));
    }

    @And("^card 3DSecure request body with merchantReference ([^ ]+) signature ([^ ]+) cardNumber ([^ ]+) holderName (.+?) cvv ([^ ]+) expMonth ([^ ]+) expYear ([^ ]+) amount ([^ ]+) pk ([^ ]+) currency ([^ ]+)$")
    public void card3dsRequestBody(String merchantReferenceVar, String signatureVar, String cardNumber,
                                   String holderName, String cvv, String expMonth, String expYear,
                                   String amount, String pkVar, String currency) {
        context.getSpec().setBody(buildCardThreeDSecureRequest(
                resolveStringValue(merchantReferenceVar),
                resolveStringValue(signatureVar),
                resolveStringValue(cardNumber),
                resolveStringValue(holderName),
                resolveStringValue(cvv),
                resolveStringValue(expMonth),
                resolveStringValue(expYear),
                resolveStringValue(amount),
                resolveStringValue(pkVar),
                resolveStringValue(currency)));
    }

    @And("^wallet deposit request action ([^ ]+) operation ([^ ]+) channel ([^ ]+) paymentType ([^ ]+) paymentMethodType ([^ ]+) paymentMethodId ([^ ]+) paymentCode ([^ ]+) pspPaymentId ([^ ]+) amount ([^ ]+) amountCurrency ([^ ]+) serviceCostAmount ([^ ]+) serviceCostCurrency ([^ ]+) ownerId ([^ ]+) ownerType ([^ ]+) pspId ([^ ]+) pspTargetId ([^ ]+) forceReview ([^ ]+) paybankId ([^ ]+)$")
    public void walletDepositWithPaymentCode(String action, String operation, String channel, String paymentType,
                                             String paymentMethodType, String paymentMethodId, String paymentCode,
                                             String pspPaymentId, String amount, String amountCurrency,
                                             String serviceCostAmount, String serviceCostCurrency, String ownerId,
                                             String ownerType, String pspId, String pspTargetId, String forceReview,
                                             String paybankId) {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("pam.walletHost"));
        spec.setBasePath("/api/wallet/rest/v1/payments");
        spec.contentType("application/json");
        spec.header("Authorization", "Bearer " + context.getProp("api_access_token"));
        spec.body(buildWalletDeposit(
                resolveStringValue(action),
                resolveStringValue(operation),
                resolveStringValue(channel),
                resolveStringValue(paymentType),
                resolveStringValue(paymentMethodType),
                resolveStringValue(paymentMethodId),
                resolveStringValue(paymentCode),
                resolveStringValue(pspPaymentId),
                resolveStringValue(amount),
                resolveStringValue(amountCurrency),
                resolveStringValue(serviceCostAmount),
                resolveStringValue(serviceCostCurrency),
                resolveStringValue(ownerId),
                resolveStringValue(ownerType),
                resolveStringValue(pspId),
                resolveStringValue(pspTargetId),
                resolveStringValue(forceReview),
                resolveStringValue(paybankId)));
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);
    }

    @And("^player prepares withdrawal request action ([^ ]+) operation ([^ ]+) channel ([^ ]+) paymentType ([^ ]+) paymentMethodType ([^ ]+) paymentMethodId ([^ ]+) card ([^ ]+) bankId ([^ ]+) voucher ([^ ]+) pspPaymentId ([^ ]+) amount ([^ ]+) amountCurrency ([^ ]+) serviceCostAmount ([^ ]+) serviceCostCurrency ([^ ]+) ownerId ([^ ]+) ownerType ([^ ]+) pspId ([^ ]+) pspTargetId ([^ ]+) forceReview ([^ ]+) paybankId ([^ ]+)$")
    public void playerPreparesWithdrawalRequest(String action, String operation, String channel, String paymentType,
                                                String paymentMethodType, String paymentMethodId, String card,
                                                String bankId, String voucher,
                                                String pspPaymentId, String amount, String amountCurrency,
                                                String serviceCostAmount, String serviceCostCurrency, String ownerId,
                                                String ownerType, String pspId, String pspTargetId, String forceReview,
                                                String paybankId) {
        context.getSpec().setBody(buildWithdrawal(
                resolveStringValue(action),
                resolveStringValue(operation),
                resolveStringValue(channel),
                resolveStringValue(paymentType),
                resolveStringValue(paymentMethodType),
                resolveStringValue(paymentMethodId),
                resolveStringValue(card),
                resolveStringValue(bankId),
                resolveStringValue(voucher),
                resolveStringValue(pspPaymentId),
                resolveStringValue(amount),
                resolveStringValue(amountCurrency),
                resolveStringValue(serviceCostAmount),
                resolveStringValue(serviceCostCurrency),
                resolveStringValue(ownerId),
                resolveStringValue(ownerType),
                resolveStringValue(pspId),
                resolveStringValue(pspTargetId),
                resolveStringValue(forceReview),
                resolveStringValue(paybankId)));
    }

    @And("^player prepares CARD withdrawal request with fingerprint ([^ ]+) amount ([^ ]+)$")
    public void playerPreparesCardWithdrawalRequest(String fingerprint, String amount) {
        context.getSpec().setBody(buildDefaultCardWithdrawal(
                resolveStringValue(fingerprint),
                resolveStringValue(amount)));
    }

    @And("^player commits default withdrawal request with amount ([^ ]+)$")
    public void playerCommitsDefaultWithdrawalRequestBody(String amount) {
        context.getSpec().setBody(buildWithdrawalCommit(
                resolveStringValue(amount),
                resolveStringValue("EUR"),
                resolveStringValue("false"),
                resolveStringValue(null)));
    }

    @And("^player commits withdrawal request body amount ([^ ]+) currency ([^ ]+) forceReview ([^ ]+) auditData ([^ ]+)$")
    public void playerCommitsWithdrawalRequestBody(String serviceCostAmount, String serviceCostCurrency,
                                                   String forceReview, String auditData) {
        context.getSpec().setBody(buildWithdrawalCommit(
                resolveStringValue(serviceCostAmount),
                resolveStringValue(serviceCostCurrency),
                resolveStringValue(forceReview),
                resolveStringValue(auditData)));
    }

    @And("^backoffice withdrawal approval request body action ([^ ]+)$")
    public void backofficeApprovesWithdrawalRequestBody(String action) {
        context.getSpec().setBody(buildWithdrawalApproval(resolveStringValue(action)));
    }

  @And("^player sets master card 3DSecure details number ([^ ]+) holderName \"([^\"]+)\" cvv ([^ ]+) expMonth ([^ ]+) expYear ([^ ]+) merchantReference ([^ ]+) signature ([^ ]+) amount ([^ ]+) currency ([^ ]+)$")
  public void playerSetsMasterCard3DSecureDetailsAndCapturesDepositTokenId(
          String cardNumber, String holderName, String cvv,
          String expMonth, String expYear, String merchantReference, String signature, String amount, String currency) {
    spec = ApiBase.spec();
    spec.setBaseUri(context.getProp("pam.toraWalletHost"));
    spec.setBasePath("api/threedsecure");
    spec.contentType("application/json");
    spec.header("Origin", context.getProp("pam.webBaseUrl"));
    spec.body(buildMasterCard3DSecureRequest(cardNumber, holderName, cvv, expMonth, expYear, merchantReference, signature, amount, currency));
    context.getApi().setResponse(spec.when().post());

    context.getApi().getResponse().then().statusCode(200);
    JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
    context.setProp("deposit_token_id", resp.get("id").toString());
  }
}
