package apis.middleware.stepDefs.pamOneRow;

import apis.middleware.core.base.ApiBase;
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.dsl.actions.DslHelper;
import apis.middleware.models.request.pam.bonus.BonusRequest;
import apis.middleware.models.request.pam.login.BoLoginRequest;
import io.cucumber.java.en.And;
import io.restassured.path.json.JsonPath;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class PamBonusSteps extends DslHelper {

  public PamBonusSteps(ScenarioContext context) {
        super(context);
    }

    // ========================= PRIVATE BUILDERS =========================
    private String valueOrDefault(String value, String defaultValue) {
        return value == null || value.isEmpty() ? defaultValue : value;
    }

    private String resolveStringValue(String valueRef) {
        return ScenarioContext.resolve(valueRef);
    }

    private Boolean resolveBooleanValue(String valueRef) {
        return Boolean.parseBoolean(resolveStringValue(valueRef));
    }

    private String defaultDateFrom() {
        return LocalDate.now().atStartOfDay().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    }

    private String defaultDateTo(String dateFrom) {
        return LocalDateTime.parse(dateFrom).plusDays(10).format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    }

    private String bonusNameFor(String gameId) {
        return gameId.toLowerCase(Locale.ROOT) + "-bonus-" + context.getProp("pam.$random10Digit");
    }


    private BonusRequest buildDefaultExclusiveBonus(String gameId, String rewardType, String bonusTerms, String dateFrom, String dateTo,
                                                    String rollOver, String maxWinningsCap, String minimumBets,
                                                    String bonusAssignment, String rewardExpiryDays,
                                                    String activationTrigger, String rewardAmountType,
                                                    String rewardAmount) {
        String resolvedDateFrom = valueOrDefault(dateFrom, defaultDateFrom());
        String resolvedDateTo = valueOrDefault(dateTo, defaultDateTo(resolvedDateFrom));

        return buildBonus(
                valueOrDefault(rewardType, "PRE_WAGER"),
                valueOrDefault(bonusTerms, "https://opap.gr"),
                resolvedDateFrom,
                valueOrDefault(dateTo, resolvedDateTo),
                valueOrDefault(rollOver, "1"),
                valueOrDefault(maxWinningsCap, ""),
                valueOrDefault(minimumBets, "1"),
                "numbergames",
                gameId,
                "OTHER",
                false,
                valueOrDefault(bonusAssignment, "SEGMENT"),
                valueOrDefault(rewardExpiryDays, "31"),
                valueOrDefault(activationTrigger, "NONE"),
                valueOrDefault(rewardAmountType, "FIXED"),
                valueOrDefault(rewardAmount, "50"));
    }

    private BonusRequest buildBonus(String rewardType, String bonusTerms, String dateFrom, String dateTo,
                                    String rollOver, String maxWinningsCap, String minimumBets,
                                    String gameType, String gameId, String program, Boolean singleUse,
                                    String bonusAssignment, String rewardExpiryDays,
                                    String activationTrigger, String rewardAmountType, String rewardAmount) {

        return BonusRequest.builder()
                .rewardType(rewardType)
                .bonusTerms(bonusTerms)
                .bonusValidFrom(dateFrom)
                .bonusValidTo(dateTo)
                .rollOver(rollOver)
                .maxWinningsCap(maxWinningsCap)
                .minimumBets(minimumBets)
                .allowedGames(buildAllowedGames(gameType, gameId))
                .program(program)
                .singleUse(singleUse)
                .bonusAssignment(bonusAssignment)
                .rewardExpiryDays(rewardExpiryDays)
                .activationTrigger(activationTrigger)
                .rewardAmountType(rewardAmountType)
                .rewardAmount(rewardAmount)
                .langDetails(buildLangDetails(gameId))
                .status(0)
                .build();
    }

    private List<BonusRequest.AllowedGame> buildAllowedGames(String gameType, String gameId) {
        return Arrays.asList(BonusRequest.AllowedGame.builder()
                .gameType(gameType)
                .gameIds(Arrays.asList(gameId))
                .build());
    }

    private List<BonusRequest.LangDetail> buildLangDetails(String gameId) {
        String bonusName = bonusNameFor(gameId);

        return Arrays.asList(
                BonusRequest.LangDetail.builder()
                        .name(bonusName)
                        .description("Sample text")
                        .code("el")
                        .build(),
                BonusRequest.LangDetail.builder()
                        .name(bonusName)
                        .description("Sample text")
                        .code("en")
                        .build());
    }

    // ========================= STEP DEFINITIONS =========================

    /**
     * Compound step: GET /cc/bonus + create bonus + capture bonusId.
     * Equivalent to the manual multi-step flow:
     *   GET /cc/bonus → 200 → csrftoken
     *   POST /cc/bonus/rest/v1/bonuses   → 200/201 → saves bonus_<gameId>_id
     *
     * Optional keyword args follow the same nullable/default pattern as
     * {@link #defaultExclusiveBonusRequestBody}.
     */
    @And("^backoffice create default bonus with gameId ([^ ]+)(?: rewardType ([^ ]+))?(?: bonusTerms ([^ ]+))?(?: dateFrom ([^ ]+))?(?: dateTo ([^ ]+))?(?: rollOver ([^ ]+))?(?: maxWinningsCap ([^ ]+))?(?: minimumBets ([^ ]+))?(?: bonusAssignment ([^ ]+))?(?: rewardExpiryDays ([^ ]+))?(?: activationTrigger ([^ ]+))?(?: rewardAmountType ([^ ]+))?(?: rewardAmount ([^ ]+))?$")
    public void backofficeCreateDefaultBonus(String gameId, String rewardType, String bonusTerms,
                                             String dateFrom, String dateTo, String rollOver,
                                             String maxWinningsCap, String minimumBets,
                                             String bonusAssignment, String rewardExpiryDays,
                                             String activationTrigger, String rewardAmountType,
                                             String rewardAmount) {
        String boBase = context.getProp("pam.boBaseUrl");
        String boUser = context.getProp("bo_username");
        String boPass = context.getProp("bo_password");

        // Step 1: POST /cc/bonus with csrftoken headers
        spec = ApiBase.spec();
        spec.setBaseUri(boBase);
        spec.setBasePath("/cc/bonus/rest/v1/bonuses");
        spec.contentType("application/json");
        spec.header("x-csrftoken", context.getProp("x-csrftoken"));
        spec.header("Cookie", "csrftoken=" + context.getProp("x-csrftoken"));
//        spec.setRedirectFollow(true);
        spec.body(buildDefaultExclusiveBonus(gameId, rewardType, bonusTerms, dateFrom, dateTo,
                rollOver, maxWinningsCap, minimumBets, bonusAssignment, rewardExpiryDays,
                activationTrigger, rewardAmountType, rewardAmount));
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);

        // Step 2: Capture bonusId into ScenarioContext as bonus_<gameId>_id (e.g. bonus_kino_id)
        JsonPath bonusResp = context.getApi().getResponse().then().extract().body().jsonPath();
        String bonusId = bonusResp.getString("bonusId");
        String key = "bonus_" + gameId.toLowerCase(java.util.Locale.ROOT) + "_id";
        context.setProp(key, bonusId);
    }

    @And("^create default bonus request body with gameId ([^ ]+)(?: rewardType ([^ ]+))?(?: bonusTerms ([^ ]+))?(?: dateFrom ([^ ]+))?(?: dateTo ([^ ]+))?(?: rollOver ([^ ]+))?(?: maxWinningsCap ([^ ]+))?(?: minimumBets ([^ ]+))?(?: bonusAssignment ([^ ]+))?(?: rewardExpiryDays ([^ ]+))?(?: activationTrigger ([^ ]+))?(?: rewardAmountType ([^ ]+))?(?: rewardAmount ([^ ]+))?$")
    public void defaultExclusiveBonusRequestBody(String gameId, String rewardType, String bonusTerms, String dateFrom, String dateTo,
                                                 String rollOver, String maxWinningsCap, String minimumBets,
                                                 String bonusAssignment, String rewardExpiryDays,
                                                 String activationTrigger, String rewardAmountType,
                                                 String rewardAmount) {
      context.getSpec().setBody(buildDefaultExclusiveBonus(
              gameId,
              rewardType,
              bonusTerms,
              dateFrom,
              dateTo,
              rollOver,
              maxWinningsCap,
              minimumBets,
              bonusAssignment,
              rewardExpiryDays,
              activationTrigger,
              rewardAmountType,
              rewardAmount));
    }

    @And("^create bonus request with rewardType ([^ ]+) bonusTerms ([^ ]+) dateFrom ([^ ]+) dateTo ([^ ]+) rollOver ([^ ]+) maxWinningsCap ([^ ]+) minimumBets ([^ ]+) gameType ([^ ]+) gameId ([^ ]+) program ([^ ]+) singleUse ([^ ]+) bonusAssignment ([^ ]+) rewardExpiryDays ([^ ]+) activationTrigger ([^ ]+) rewardAmountType ([^ ]+) rewardAmount ([^ ]+)$")
    public void bonusRequestBody(String rewardType, String bonusTerms, String dateFrom, String dateTo,
                                 String rollOver, String maxWinningsCap, String minimumBets,
                                 String gameType, String gameId, String program, String singleUse,
                                 String bonusAssignment, String rewardExpiryDays, String activationTrigger,
                                 String rewardAmountType, String rewardAmount) {
        context.getSpec().setBody(buildBonus(
                resolveStringValue(rewardType),
                resolveStringValue(bonusTerms),
                resolveStringValue(dateFrom),
                resolveStringValue(dateTo),
                resolveStringValue(rollOver),
                resolveStringValue(maxWinningsCap),
                resolveStringValue(minimumBets),
                resolveStringValue(gameType),
                resolveStringValue(gameId),
                resolveStringValue(program),
                resolveBooleanValue(singleUse),
                resolveStringValue(bonusAssignment),
                resolveStringValue(rewardExpiryDays),
                resolveStringValue(activationTrigger),
                resolveStringValue(rewardAmountType),
                resolveStringValue(rewardAmount)));
    }

    @And("^backoffice captures bonus prize id for product ([^ ]+)$")
    public void backofficeCapturesBonusPrizeIdForProduct(String productId) {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("pam.boBaseUrl"));
        spec.setBasePath("/cc/wallet/rest/v2/users/1-" + context.getProp("playerId") + "/accounts");
        spec.header("x-csrftoken", context.getProp("x-csrftoken"));
        spec.header("Cookie", "csrftoken=" + context.getProp("x-csrftoken"));
        context.getApi().setResponse(spec.when().get());
        context.getApi().getResponse().then().statusCode(200);

        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        List<Map<String, Object>> accounts = resp.getList("");
        String resolvedProductId = resolveStringValue(productId);

        String bonusPrizeId = null;
        for (Map<String, Object> account : accounts) {
            if (resolvedProductId.equals(String.valueOf(account.get("productId")))) {
                String id = String.valueOf(account.get("id"));
                bonusPrizeId = id.substring(id.lastIndexOf("-") + 1);
                break;
            }
        }
        if (bonusPrizeId == null) throw new AssertionError("No account found for productId: " + resolvedProductId);

        context.setProp("bonus_prize_id", bonusPrizeId);
    }
}
