package apis.middleware.stepDefs.pamOneRow;

import apis.middleware.dsl.ScenarioContext;
import apis.middleware.dsl.actions.DslHelper;
import apis.middleware.models.request.pam.register.PlayerRegistrationRequest;
import io.cucumber.java.en.And;

public class PamPlayerSteps extends DslHelper {

    public PamPlayerSteps(ScenarioContext context) {
        super(context);
    }

    // ========================= PRIVATE BUILDERS =========================

    private PlayerRegistrationRequest buildPlayerRegistration(String username, String password, String dob,
                                                              String gender, String bonusCode, String identityType) {
        String msisdn = context.getProp("randomMSISDN");
        return PlayerRegistrationRequest.builder()
                .username(username + msisdn)
                .password(password)
                .email(username + msisdn + "@mailsac.com")
                .identityType(identityType)
                .identityNumber(msisdn)
                .firstName("PAM")
                .middleName("LOTTERY")
                .lastName("PLATFORM")
                .gender(gender)
                .dateOfBirth(dob)
                .country("GR")
                .city("Athens")
                .address1("First address 0100")
                .zip("15125")
                .profession("Unemployed")
                .phone("21" + msisdn)
                .mobilePhone("69" + msisdn)
                .bonusCode(bonusCode)
                .secretQuestion("What is your name?")
                .secretAnswer("automationsuite")
                .ibanNumber(context.getProp("pam.IBAN"))
                .otpUuid(context.getProp("otpUuid"))
                .permanentResidenceCountry("GRC")
                .build();
    }

    // ========================= STEP DEFINITIONS =========================

    @And("^new player registration username ([^ ]+) password ([^ ]+) dob ([^ ]+) gender ([^ ]+) bonus ([^ ]+) identityType ([^ ]+)$")
    public void player_registration(String username, String password, String dob,
                                    String gender, String bonusCode, String identityType) {
        context.getSpec().setBody(buildPlayerRegistration(username, password, dob, gender, bonusCode, identityType));
    }
}
