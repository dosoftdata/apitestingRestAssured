package apis.middleware.stepDefs.pamOneRow;

import apis.middleware.core.base.ApiBase;
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.dsl.actions.DslHelper;
import apis.middleware.models.request.pam.login.BoLoginRequest;
import apis.middleware.models.request.pam.login.OidcLoginRequest;
import apis.middleware.models.request.pam.otp.OtpRequest;
import apis.middleware.models.request.pam.otp.OtpVerifyRequest;
import io.cucumber.java.en.And;
import io.restassured.path.json.JsonPath;

public class PamAccessSteps extends DslHelper {

    public PamAccessSteps(ScenarioContext context) {
        super(context);
    }

    // ========================= PRIVATE BUILDERS =========================

    private OtpRequest buildOtpRequest(String phoneNumber) {
        return OtpRequest.builder()
                .phoneNumber(phoneNumber)
                .build();
    }

    private OtpVerifyRequest buildOtpVerifyRequest(String phoneNumber, String uuid) {
        return OtpVerifyRequest.builder()
                .phoneNumber(phoneNumber)
                .uuid(uuid)
                .verificationCode("000000")
                .build();
    }

    private BoLoginRequest buildBoLogin(String username, String password) {
        return BoLoginRequest.builder()
                .loginName(username)
                .password(password)
                .build();
    }

    private OidcLoginRequest buildOidcLoginRequest(String username) {
        return OidcLoginRequest.builder()
                .grantType("password")
                .username(username)
                .password("Qwerty12345!")
                .channel("WEB")
                .group("EP")
                .scope("openid http://betware.com/oidc/scopes/session")
                .build();
    }

    // ========================= STEP DEFINITIONS =========================

    @And("^OTP create request body$")
    public void otp_create_request_body() {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("pam.webBaseUrl"));
        spec.setBasePath("web/customer/rest/v1/otp");
        spec.contentType("application/json");
        spec.body(buildOtpRequest("69" + context.getProp("pam.$random8Digit")));
        context.getApi().setResponse(spec.when().post());
        int firstStatus = context.getApi().getResponse().getStatusCode();

        if (firstStatus == 200) {
            JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
            context.setProp("otpUuid", resp.get("uuid"));
        } else {
            context.getApi().getResponse().then().statusCode(403);
            context.setProp("web-x-csrftoken", context.getApi().getResponse().cookie("csrftoken"));

            // Retry with valid csrftoken.
            spec.header("x-csrftoken", context.getProp("web-x-csrftoken"));
            spec.header("Cookie", "csrftoken=" + context.getProp("web-x-csrftoken"));
            context.getApi().setResponse(spec.when().post());
            context.getApi().getResponse().then().statusCode(200);
            JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
            context.setProp("otpUuid", resp.get("uuid"));
        }
    }

    @And("^OTP verify request body$")
    public void otp_verify_request_body() {
        context.getSpec().setBody(buildOtpVerifyRequest(
                "69" + context.getProp("randomMSISDN"),
                context.getProp("otpUuid")));
    }

    @And("^backoffice login with username ([^ ]+) password ([^ ]+)$")
    public void backoffice_login(String username, String password) {
        context.getSpec().setBody(buildBoLogin(username, password));
    }

    @And("^OIDC player login request body$")
    public void oidc_player_login_request_body() {
        context.getSpec().setBody(buildOidcLoginRequest(context.getProp("username")));
    }

    @And("^get ILOT access token$")
    public void get_ilot_access_token() {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("pam.webBaseUrl"));
        spec.setBasePath("/api/access/oidc/token");
        spec.contentType("application/x-www-form-urlencoded");
        spec.header("Authorization", "Basic " + context.getProp("pam.basic_ilot_auth"));
        spec.body("grant_type=client_credentials");
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);
        String ilotToken = context.getApi().getResponse().then().extract().body().jsonPath().get("access_token");
        context.setProp("ilot_access_token", ilotToken);
    }
}
