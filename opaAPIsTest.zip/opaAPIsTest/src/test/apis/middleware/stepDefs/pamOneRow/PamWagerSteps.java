package apis.middleware.stepDefs.pamOneRow;

import apis.middleware.core.base.ApiBase;
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.dsl.actions.DslHelper;
import apis.middleware.models.request.pam.wager.PlaceWagerRequest;
import apis.middleware.models.request.pam.wager.PlaceWagerRequest.Board;
import apis.middleware.models.request.pam.wager.PlaceWagerRequest.ExclusiveWager;
import apis.middleware.models.request.pam.wager.PlaceWagerRequest.Panel;
import apis.middleware.models.request.pam.wager.PlaceWagerRequest.ParticipatingDraws;
import apis.middleware.models.request.pam.wager.WinningRequest;
import apis.middleware.validators.pam.wager.PlaceWagerResponseValidator;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.awaitility.Awaitility.await;

public class PamWagerSteps extends DslHelper {

    public PamWagerSteps(ScenarioContext context) {
        super(context);
    }

    // ========================= PRIVATE BUILDERS =========================

    private WinningRequest buildWinningRequest(String gameId, String amount, String taxAmount, String serialNumber) {
        return WinningRequest.builder()
                .amount(amount)
                .currency("EUR")
                .description("Prize")
                .issued("2019-01-24T15:38:02Z")
                .partialPayment("false")
                .productId(gameId)
                .referenceId(context.getProp("pam.$random10Digit"))
                .serialNumber(serialNumber)
                .taxAmount(taxAmount)
                .build();
    }

    private PlaceWagerRequest buildPlaceWagerRequest(String gameType, String betType,
                                                     String selection, String secondSelection, String quickPick,
                                                     String multiplier, String multipleDraws) {
        String resolvedGameType = valueOrDefault(gameType, "JOKER");
        int resolvedBetType = Integer.parseInt(betType);
        int resolvedMultipleDraws = Integer.parseInt(valueOrDefault(multipleDraws, "1"));
        boolean resolvedQuickPick = Boolean.parseBoolean(valueOrDefault(quickPick, "false"));
        int resolvedMultiplier = Integer.parseInt(valueOrDefault(multiplier, "2"));
        List<Integer> mainNumbersSelection = parseNumberSelection(valueOrDefault(selection, "1,2,3,4,5"));
        List<Integer> secondaryNumbersSelection = parseNumberSelection(valueOrDefault(secondSelection, "15"));

        Panel primaryNumbersPanel = Panel.builder()
                .selection(mainNumbersSelection)
                .quickPick(resolvedQuickPick)
                .build();

        Board singleBoard;
        Panel secondaryNumbersPanel;
        if ("JOKER".equalsIgnoreCase(resolvedGameType)) {

            secondaryNumbersPanel = Panel.builder()
                    .selection(secondaryNumbersSelection)
                    .quickPick(resolvedQuickPick)
                    .build();

            singleBoard = Board.builder()
                    .boardId(1)
                    .betType(resolvedBetType)
                    .panels(Arrays.asList(primaryNumbersPanel, secondaryNumbersPanel))
                    .build();
        } else {
            singleBoard = Board.builder()
                    .boardId(1)
                    .betType(resolvedBetType)
                    .panels(Arrays.asList(primaryNumbersPanel))
                    .multipliers(resolvedMultiplier)
                    .build();
        }

        ExclusiveWager exclusiveWager = ExclusiveWager.builder()
                .boards(Arrays.asList(singleBoard))
                .participatingDraws(ParticipatingDraws.builder()
                        .multipleDraws(resolvedMultipleDraws)
                        .build())
                .build();

        return PlaceWagerRequest.builder()
                .gameType(resolvedGameType)
                .wager(exclusiveWager)
                .build();
    }

    private String valueOrDefault(String value, String defaultValue) {
        return value == null || value.isEmpty() ? defaultValue : value;
    }

    private List<Integer> parseNumberSelection(String commaSeparatedNumbers) {
        List<Integer> selectedNumbers = new ArrayList<>();
        for (String number : commaSeparatedNumbers.split(",")) {
            selectedNumbers.add(Integer.parseInt(number.trim()));
        }
        return selectedNumbers;
    }

    private void getIlotAccessToken() {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("pam.webBaseUrl"));
        spec.setBasePath("/api/access/oidc/token");
        spec.contentType("application/x-www-form-urlencoded");
        spec.header("Authorization", "Basic " + context.getProp("pam.basic_ilot_auth"));
        spec.body("grant_type=client_credentials");
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);
        String ilotToken = context.getApi().getResponse().then().extract().body().jsonPath().get("access_token");
        context.setProp("ilot_access_token", ilotToken);
    }

    // ========================= STEP DEFINITIONS =========================

    @And("^exclusive bet wins with gameId ([^ ]+) serialNumber ([^ ]+) amount ([^ ]+) taxAmount ([^ ]+)$")
    public void prize_pay_winning_bet(String gameId, String serialNumber, String amount, String taxAmount) {
        getIlotAccessToken();

        // Prize with retry until 200.
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("pam.webBaseUrl"));
        spec.setBasePath("/api/wager-service/rest/v1/winnings");
        spec.contentType("application/json");
        spec.header("Authorization", "Bearer " + context.getProp("ilot_access_token"));
        spec.header("X-GAME-ID", gameId);

        String winningSerialNumber = context.getProp(serialNumber);
        spec.body(buildWinningRequest(gameId, amount, taxAmount, winningSerialNumber));

        await().atMost(Duration.ofSeconds(60))
               .pollInterval(Duration.ofMillis(5000))
               .ignoreExceptions()
               .until(() -> {
                   Response resp = spec.when().post();
                   context.getApi().setResponse(resp);
                   return resp.statusCode() == 200;
               });

        context.getApi().getResponse().then().statusCode(200);
    }

    /**
     * Place bet request body (body-only step).
     * All parameters are optional - defaults: gameType=JOKER, betType=0,
     * selection=1,2,3,4,5, secondSelection=15, multipleDraws=1, quickPick=false
     */
    @And("^player prepares wager request for gameId ([^ ]+)(?: betType ([^ ]+))?(?: selection ([^ ]+))?(?: secondSelection ([^ ]+))?(?: quickPick ([^ ]+))?(?: multiplier ([^ ]+))?(?: multipleDraws ([^ ]+))?$")
    public void placeBetRequestBody(String gameType, String betType, String selection,
                                    String secondSelection, String quickPick, String multiplier, String multipleDraws) {
        context.getSpec().body(buildPlaceWagerRequest(gameType, betType, selection, secondSelection, quickPick, multiplier, multipleDraws));
    }

    @Then("^exclusive wager response has expected schema$")
    public void exclusiveWagerResponseHasExpectedSchema() {
        PlaceWagerResponseValidator.assertSchema(context.getApi().getResponse());
    }
}
