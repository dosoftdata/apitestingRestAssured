package apis.middleware.stepDefs.pamOneRow;

import apis.middleware.core.base.ApiBase;
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.dsl.actions.DslHelper;
import apis.middleware.models.request.pam.limit.LimitQuantity;
import apis.middleware.models.request.pam.limit.LimitRequest;
import apis.middleware.models.request.pam.limit.LimitScope;
import io.cucumber.java.en.And;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PamLimitSteps extends DslHelper {

    public PamLimitSteps(ScenarioContext context) {
        super(context);
    }

    // ========================= PRIVATE BUILDERS =========================

    private List<LimitRequest> buildMandatoryExclusiveLimits() {
        List<LimitRequest> limits = new ArrayList<>();
        limits.add(LimitRequest.builder()
                .limitType("TIME")
                .quantityType("MAX_DURATION")
                .quantity(LimitQuantity.builder().durationInSeconds(86400L).build())
                .period("DAILY")
                .scope(LimitScope.builder().gameId("").build())
                .build());
        limits.add(LimitRequest.builder()
                .limitType("DEPOSIT")
                .quantityType("MAX_AMOUNT")
                .quantity(LimitQuantity.builder().amount(3000.0).currency("EUR").build())
                .period("DAILY")
                .scope(LimitScope.builder().gameId("").build())
                .build());
        for (String gameId : Arrays.asList("JOKER", "PROTO", "KINO", "LOTTO", "SUPER3", "EUROJACKPOT")) {
            limits.add(LimitRequest.builder()
                    .limitType("LOSS")
                    .quantityType("MAX_AMOUNT")
                    .quantity(LimitQuantity.builder().amount(3000.0).currency("EUR").build())
                    .period("DAILY")
                    .scope(LimitScope.builder().gameId(gameId).build())
                    .build());
        }
        return limits;
    }

    // ========================= STEP DEFINITIONS =========================

    @And("^set mandatory exclusive limits$")
    public void set_mandatory_exclusive_limits() {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("pam.webBaseUrl"));
        spec.setBasePath("/web/limit/rest/v2/customers/me/limits");
        spec.contentType("application/json");
        spec.header("x-csrftoken", context.getProp("web-x-csrftoken"));
        spec.header("Cookie", "csrftoken=" + context.getProp("web-x-csrftoken"));
        spec.header("X-GAME-ID", "JOKER");
        spec.header("Authorization", context.getProp("token_type") + " " + context.getProp("oidc_access_token"));
        spec.body(buildMandatoryExclusiveLimits());
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);
    }
}
