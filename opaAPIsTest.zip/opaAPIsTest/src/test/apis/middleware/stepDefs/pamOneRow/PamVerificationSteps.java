package apis.middleware.stepDefs.pamOneRow;

import apis.middleware.core.base.ApiBase;
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.dsl.actions.DslHelper;
import apis.middleware.models.request.pam.verification.EmailVerificationRequest;
import apis.middleware.models.request.pam.verification.IbanVerificationRequest;
import apis.middleware.models.request.pam.verification.VerificationConfirmRequest;
import apis.middleware.models.request.pam.verification.VerificationDocumentApproveRequest;
import io.cucumber.java.en.And;

public class PamVerificationSteps extends DslHelper {

    public PamVerificationSteps(ScenarioContext context) {
        super(context);
    }

    // ========================= PRIVATE BUILDERS =========================

    private EmailVerificationRequest buildEmailVerification(String playerId, String hash) {
        return EmailVerificationRequest.builder()
                .playerId(playerId)
                .hash(hash)
                .build();
    }

    private VerificationDocumentApproveRequest buildVerificationDocumentApproval(String verificationId,
                                                                                String verificationType,
                                                                                String documentId,
                                                                                String statusDescription) {
        return VerificationDocumentApproveRequest.builder()
                .verificationId(verificationId)
                .verificationType(verificationType)
                .documentId(documentId)
                .statusDescription(statusDescription)
                .build();
    }

    private VerificationConfirmRequest buildVerificationConfirm(String verificationId, String verificationType) {
        return VerificationConfirmRequest.builder()
                .id(verificationId)
                .verificationType(verificationType)
                .build();
    }

    private IbanVerificationRequest buildIbanVerification(String iban, String id) {
        return IbanVerificationRequest.builder()
                .iban(iban)
                .id(id)
                .build();
    }

    // ========================= STEP DEFINITIONS =========================

    @And("^backoffice verify player's email with hash ([^ ]+)$")
    public void playerEmailVerification(String hashVar) {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("pam.webBaseUrl"));
        spec.setBasePath("/web/customer/rest/v1/verifications/email");
        spec.contentType("application/json");
        spec.header("x-csrftoken", context.getProp("web-x-csrftoken"));
        spec.header("Cookie", "csrftoken=" + context.getProp("web-x-csrftoken"));
        spec.body(buildEmailVerification(context.getProp("playerId"), context.getProp(hashVar)));
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(204);
    }

    @And("^verification document approval request body verificationId ([^ ]+) verificationType ([^ ]+) documentId ([^ ]+) statusDescription (.+)$")
    public void verificationDocumentApprovalRequestBody(String verificationIdVar, String verificationType,
                                                        String documentIdVar, String statusDescription) {
        context.getSpec().setBody(buildVerificationDocumentApproval(
                context.getProp(verificationIdVar),
                verificationType,
                context.getProp(documentIdVar),
                statusDescription));
    }

    @And("^verification confirm request body id ([^ ]+) verificationType ([^ ]+)$")
    public void verificationConfirmRequestBody(String verificationIdVar, String verificationType) {
        context.getSpec().setBody(buildVerificationConfirm(
                context.getProp(verificationIdVar),
                verificationType));
    }

    @And("^IBAN account verification request with iban ([^ ]+) id ([^ ]+)$")
    public void ibanAccountVerificationRequestBody(String ibanNumber, String idNumber) {
        context.getSpec().setBody(buildIbanVerification(
                context.getProp(ibanNumber),
                context.getProp(idNumber)));
    }
}
