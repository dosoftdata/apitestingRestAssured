package apis.middleware.stepDefs;

import apis.middleware.core.base.ApiBase;
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.dsl.actions.DslHelper;
import io.cucumber.java.en.*;
import io.restassured.path.json.JsonPath;

public class janusOneRowSpecSteps extends DslHelper {

    /**
     * Instantiates a new One row spec steps.
     *
     * @param context the context
     */
    public janusOneRowSpecSteps(ScenarioContext context) {
        super(context);
    }

    @And("^User logins with voucher and terminalid (.+)$")
    public void user_logins_with_voucher_and_terminalid(String terminalid) {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("janusAllwynUrl"));
        spec.setBasePath(context.getProp("janus.basePath"));
        spec.header("Content-Type",context.getProp("janus.contentType"));
        spec.header("Authorization",context.getProp("janus.authorization_ssbts"));
        spec.setFormParam("grant_type",context.getProp("janus.grantTypeVoucherLogin"));
        spec.setFormParam("scope",context.getProp("janus.scope"));
        spec.setFormParam("ssbtId",terminalid);
        spec.setFormParam("voucher",context.getProp("voucherId"));
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);
        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        context.setProp("janusToken", resp.get("access_token"));
        context.setProp("janusTokenType", resp.get("token_type"));
        context.setProp("x-csrftoken",context.getApi().getResponse().cookie("csrftoken"));
    }

}
