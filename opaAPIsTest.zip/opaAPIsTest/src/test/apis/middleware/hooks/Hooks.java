
package apis.middleware.hooks;

import apis.middleware.bootstrap.PlayerBootstrap;
import apis.middleware.core.base.ApiBase;
import apis.middleware.core.base.ApiSpecsMap;
import apis.middleware.core.helpers.DBManager;
import apis.middleware.core.helpers.WireMockFactoryOnce; // singleton factory (start once)
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.config.ConfigLoader;
import com.github.tomakehurst.wiremock.WireMockServer;
import io.cucumber.java.*;
import lombok.extern.slf4j.Slf4j;
import org.opentest4j.TestAbortedException;


@Slf4j
public class Hooks {
  // Per-thread guard: ensure this glue class runs its before-all init once per worker (safe even if @BeforeAll is once)
  private static final ThreadLocal<Boolean> TL_INIT = ThreadLocal.withInitial(() -> false);

  @BeforeAll
  public static void beforeAll() {
    if (!TL_INIT.get()) {
      // Start the global WireMock only if not started by any thread yet
      WireMockServer server = WireMockFactoryOnce.getServer();
      WireMockFactoryOnce.retain(); // announce usage for ref-counted shutdown
      DBManager.retain();           // ref-counted; pool drains only when last worker exits
      ApiSpecsMap.resetCookieStore();
      // Write-once global URL, safe with multiple threads racing at startup
      String url = server.baseUrl();
      ScenarioContext.putIfAbsentGlobal("mockServerUrl", url);

     // log.info("Global mockServerUrl = {}", ScenarioContext.getGlobal("mockServerUrl", String.class));
      TL_INIT.set(true);
    }
  }

  // Always-mirrored globals (independent of any tag).
  private static final String[] BASE_GLOBALS = { "mockServerUrl" };

  // Mirrored only when a scenario opts into player bootstrap via @needsPlayer.
  private static final String[] PLAYER_GLOBALS = {
      "randomMSISDN", "web-x-csrftoken", "otpUuid", "playerId", "username",
      "x-csrftoken", "mailHash", "hashId"
  };

  /**
   * Skips a scenario when it carries a {@code @skipOn<Env>} tag matching the active environment.
   *
   * <p>Usage in a feature file:
   * <pre>
   *   @skipOnUat
   *   Scenario: only runs on dev or any other env
   *     ...
   * </pre>
   * Stack multiple tags to skip on more than one env: {@code @skipOnDev @skipOnUat}.
   * Tag matching is case-insensitive. The env value is taken from {@code -Denv} (default: uat).
   */
  @Before(order = 1)
  public void skipOnSpecificEnv(Scenario scenario) {
    String currentEnv = currentEnv();
    String skipTag = "skipon" + currentEnv;
    boolean shouldSkip = scenario.getSourceTagNames().stream()
            .map(Hooks::normalizeTag)
            .anyMatch(skipTag::equals);

    if (shouldSkip) {
      throw new TestAbortedException(
              "Scenario skipped: not applicable on env '" + currentEnv + "'");
    }
  }

  @Before(order = 0)
  public void resetSpecAndSetScenarios(Scenario scenario) {
    // Clear per-thread cookie jar so cookies from a previous scenario on
    // the same worker (scenarios within one feature share a thread) cannot
    // leak into this scenario's requests.
    ApiBase.spec().reset();
    ScenarioContext.sc.set(scenario);
    ConfigLoader.loadConfig();

    mirrorGlobals(BASE_GLOBALS);
  }

  // Triggered only for scenarios tagged @needsPlayer. Bootstrap itself is JVM-idempotent,
  // so even if many scenarios carry the tag the HTTP flow runs only on the first.
  @Before(value = "@needsPlayer", order = 1)
  public void ensurePlayerBootstrap() {
    PlayerBootstrap.registerOnce();
    mirrorGlobals(PLAYER_GLOBALS);
  }

  private static void mirrorGlobals(String[] keys) {
    for (String key : keys) {
      Object v = ScenarioContext.getGlobal(key, Object.class);
      if (v != null) {
        ScenarioContext.set(key, v);
      }
    }
  }

  private static String currentEnv() {
    Object configuredEnv = ScenarioContext.get("env");
    String env = configuredEnv != null
            ? String.valueOf(configuredEnv)
            : System.getProperty("env", "dev");
    env = env.trim().toLowerCase();
    return env.isBlank() ? "dev" : env;
  }

  private static String normalizeTag(String tag) {
    String normalized = tag == null ? "" : tag.trim().toLowerCase();
    return normalized.startsWith("@") ? normalized.substring(1) : normalized;
  }

  @After(order = Integer.MAX_VALUE)
  public void after(Scenario scenario) {
    if (scenario.isFailed()) {
      log.warn("Scenario failed: {}", scenario.getName());
      // attach diagnostics if needed
    }
  }

  @AfterAll
  public static void afterAll() {
    if (Boolean.TRUE.equals(TL_INIT.get())) {
      try {
        WireMockFactoryOnce.release();
      } finally {
        try {
          // Ref-counted release: pool only drains on the LAST worker's exit,
          // so other workers still running can keep borrowing connections.
          DBManager.getInstance().release();
        } finally {
          TL_INIT.remove();
        }
      }
    }
  }
}
