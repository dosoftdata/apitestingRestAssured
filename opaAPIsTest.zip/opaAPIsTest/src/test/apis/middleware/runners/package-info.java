
/**
 *  CLI Test and scenario runners for the middleware test suite.
 *
 * <p>Entry points that bootstrap environment configuration, discover scenarios,
 * and orchestrate execution (locally and in CI/CD).</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>Parameterized/JUnit runners for suites and categories</li>
 *   <li>CLI/CI bootstraps and profile selection</li>
 *   <li>Reporting integration and exit codes</li>
 * </ul>
 *
 * @since 1.0
 */

package apis.middleware.runners;