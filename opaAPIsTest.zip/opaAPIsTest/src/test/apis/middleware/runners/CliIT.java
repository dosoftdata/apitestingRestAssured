package apis.middleware.runners;

import apis.middleware.core.helpers.DBManager;
import apis.middleware.core.helpers.WireMockFactoryOnce;
import io.cucumber.core.options.Constants;
import lombok.extern.slf4j.Slf4j;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.platform.engine.TestExecutionResult;
import org.junit.platform.engine.TestSource;
import org.junit.platform.engine.discovery.DiscoverySelectors;
import org.junit.platform.engine.support.descriptor.ClasspathResourceSource;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.TestExecutionListener;
import org.junit.platform.launcher.TestIdentifier;
import org.junit.platform.launcher.TestPlan;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;

/**
 * Failsafe-discovered integration runner with in-JVM whole-feature retry.
 *
 * <p>Pass 1 runs all features. {@link FailedFeatureTracker} captures which
 * features failed and the per-scenario throwables. If Pass 1 is clean, the
 * test passes. Otherwise Pass 2 re-runs only the failing features. The
 * assertion message after Pass 2 enumerates: features that recovered on
 * retry (flaky) and features still failing, with scenario names and the
 * first line of each failure's message — enough to triage from CI logs
 * without opening Allure.
 *
 * <p>{@link WireMockFactoryOnce} and {@link DBManager} are retained around
 * both passes so the published {@code mockServerUrl} and JDBC pool survive
 * the per-worker {@code @AfterAll} between passes.
 */
@Slf4j
public class CliIT {

  private static final String GLUE =
      "apis.middleware.dsl.actions,apis.middleware.stepDefs,apis.middleware.hooks";

  private static final String PLUGINS =
      "pretty,io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm";

  // Per-scenario JUnit XML lives here so Failsafe's own report (which only
  // sees this synthetic @Test) doesn't hide the real scenarios from CI's
  // test widget. Each pass writes its own file; results.xml is the merged,
  // post-retry view that GitLab's reports:junit points at.
  private static final Path REPORT_DIR = Path.of("failsafe-reports", "cucumber");
  private static final Path PASS1_XML = REPORT_DIR.resolve("pass1.xml");
  private static final Path PASS2_XML = REPORT_DIR.resolve("pass2.xml");
  private static final Path RESULTS_XML = REPORT_DIR.resolve("results.xml");

  // Whole-feature retry budget. 1 = each failing feature gets one extra run.
  private static final int MAX_RETRIES = 1;

  @Test
  @DisplayName("Cucumber suite (whole-feature retry: up to " + MAX_RETRIES + " retry per failing feature)")
  void runAllFeaturesWithRetry() throws IOException {
    // Set Allure results directory per environment to preserve reports across runs
    //String env = System.getProperty("env", "uat");
    String allureResultsDir = "reports/";
    System.setProperty("allure.results.directory", allureResultsDir);
    log.info("[CliIT] Allure results directory: {}", allureResultsDir);

    Files.createDirectories(REPORT_DIR);

    WireMockFactoryOnce.retain();
    DBManager.retain();
    try {
      Launcher launcher = LauncherFactory.create();

      // ----- Pass 1 -----
      FailedFeatureTracker pass1 = new FailedFeatureTracker();
      launcher.execute(buildAllFeaturesRequest(PASS1_XML), pass1);

      Set<String> failed = pass1.failedFeatures();
      if (failed.isEmpty()) {
        // Pass 1 is the complete, authoritative run — publish it verbatim.
        Files.copy(PASS1_XML, RESULTS_XML, StandardCopyOption.REPLACE_EXISTING);
        log.info("[CliIT] Pass 1 clean — no retry needed.");
        return;
      }

      log.info("[CliIT] Pass 1 had {} failing feature(s); retrying once:", failed.size());
      failed.forEach(f -> log.info("  - {}", f));

      // ----- Pass 2 (retry) -----
      FailedFeatureTracker pass2 = new FailedFeatureTracker();
      launcher.execute(buildSpecificFeaturesRequest(failed, PASS2_XML), pass2);

      // Publish the post-retry view: pass 1 minus the retried features, plus
      // pass 2's authoritative re-run of those features (so recovered/flaky
      // scenarios show green in CI).
      JUnitXmlReportMerger.merge(PASS1_XML, PASS2_XML, RESULTS_XML);

      reportAndAssert(pass1, pass2);
    } finally {
      DBManager.getInstance().release();
      WireMockFactoryOnce.release();
    }
  }

  // ===== merge guard =====

  /**
   * Pure unit test (no infra) for {@link JUnitXmlReportMerger}: a whole-feature
   * retry must replace the failed pass-1 cases of the retried feature with
   * pass-2's authoritative re-run, while leaving non-retried features untouched
   * and recomputing the suite counters. Lives here so the merge logic and its
   * guard ship as one unit; the live suite only exercises the merge when a
   * feature happens to be flaky, so this keeps coverage deterministic.
   */
  @Test
  void mergeOverridesRetriedFeatureAndKeepsTheRest() throws Exception {
    Path dir = Files.createTempDirectory("merge-test");
    Path pass1 = dir.resolve("pass1.xml");
    Path pass2 = dir.resolve("pass2.xml");
    Path out = dir.resolve("results.xml");

    // Feature A: one pass, one fail. Feature B: one pass (never retried).
    Files.writeString(pass1,
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        + "<testsuite name=\"Cucumber\" time=\"3.0\" tests=\"3\" skipped=\"0\" failures=\"1\" errors=\"0\">\n"
        + "<testcase classname=\"Feature A\" name=\"A1\" time=\"1.0\"/>\n"
        + "<testcase classname=\"Feature A\" name=\"A2\" time=\"1.0\"><failure message=\"boom\"/></testcase>\n"
        + "<testcase classname=\"Feature B\" name=\"B1\" time=\"1.0\"/>\n"
        + "</testsuite>\n");

    // Retry of Feature A only: both green now.
    Files.writeString(pass2,
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        + "<testsuite name=\"Cucumber\" time=\"2.0\" tests=\"2\" skipped=\"0\" failures=\"0\" errors=\"0\">\n"
        + "<testcase classname=\"Feature A\" name=\"A1\" time=\"1.0\"/>\n"
        + "<testcase classname=\"Feature A\" name=\"A2\" time=\"1.0\"/>\n"
        + "</testsuite>\n");

    JUnitXmlReportMerger.merge(pass1, pass2, out);

    org.w3c.dom.Document doc = javax.xml.parsers.DocumentBuilderFactory.newInstance()
        .newDocumentBuilder().parse(out.toFile());
    org.w3c.dom.Element suite = (org.w3c.dom.Element) doc.getElementsByTagName("testsuite").item(0);
    org.w3c.dom.NodeList cases = doc.getElementsByTagName("testcase");

    org.junit.jupiter.api.Assertions.assertEquals(3, cases.getLength(),
        "A1, A2 (from retry) and B1 (kept)");
    org.junit.jupiter.api.Assertions.assertEquals("3", suite.getAttribute("tests"));
    org.junit.jupiter.api.Assertions.assertEquals("0", suite.getAttribute("failures"),
        "recovered scenario must read green");
    org.junit.jupiter.api.Assertions.assertEquals(0, doc.getElementsByTagName("failure").getLength());

    boolean keptB1 = false;
    for (int i = 0; i < cases.getLength(); i++) {
      org.w3c.dom.Element c = (org.w3c.dom.Element) cases.item(i);
      if ("Feature B".equals(c.getAttribute("classname")) && "B1".equals(c.getAttribute("name"))) {
        keptB1 = true;
      }
    }
    org.junit.jupiter.api.Assertions.assertTrue(keptB1, "non-retried feature B must survive the merge");
  }

  // ===== request builders =====

  private LauncherDiscoveryRequest buildAllFeaturesRequest(Path junitXml) {
    return applyParallelConfig(LauncherDiscoveryRequestBuilder.request()
        .selectors(DiscoverySelectors.selectClasspathResource("features"))
        .configurationParameter(Constants.GLUE_PROPERTY_NAME, GLUE)
        .configurationParameter(Constants.PLUGIN_PROPERTY_NAME, pluginsWith(junitXml)))
        .build();
  }

  private LauncherDiscoveryRequest buildSpecificFeaturesRequest(Set<String> features, Path junitXml) {
    return applyParallelConfig(LauncherDiscoveryRequestBuilder.request()
        .selectors(DiscoverySelectors.selectClasspathResource("features"))
        .configurationParameter(Constants.GLUE_PROPERTY_NAME, GLUE)
        .configurationParameter(Constants.PLUGIN_PROPERTY_NAME, pluginsWith(junitXml))
        .configurationParameter(Constants.FEATURES_PROPERTY_NAME, String.join(",", features)))
        .build();
  }

  // Append the Cucumber junit-xml formatter so each pass emits a per-scenario
  // JUnit report. The forward slashes are intentional — the formatter parses
  // everything after "junit:" as the output path.
  private static String pluginsWith(Path junitXml) {
    return PLUGINS + ",junit:" + junitXml.toString().replace('\\', '/');
  }

  // System-property overrides for parallel execution. Defaults are safe
  // (sequential, single thread); CI passes -Dparallel=true -Dthread=<n> to
  // opt into feature-level parallelism without editing junit-platform.properties.
  private static LauncherDiscoveryRequestBuilder applyParallelConfig(LauncherDiscoveryRequestBuilder b) {
    String enabled = propOr("parallel", "false");
    String threads = propOr("thread", "1");
    log.info("[CliIT] parallel={} thread={}", enabled, threads);
    return b
        .configurationParameter("cucumber.execution.parallel.enabled", enabled)
        .configurationParameter("cucumber.execution.parallel.config.strategy", "fixed")
        .configurationParameter("cucumber.execution.parallel.config.fixed.parallelism", threads)
        .configurationParameter("cucumber.execution.execution-mode.feature", "same_thread");
  }

  private static String propOr(String name, String fallback) {
    String v = System.getProperty(name);
    return (v == null || v.isBlank()) ? fallback : v.trim();
  }

  // ===== reporting =====

  private static void reportAndAssert(FailedFeatureTracker pass1, FailedFeatureTracker pass2) {
    Set<String> pass1Failed = pass1.failedFeatures();
    Set<String> stillFailing = pass2.failedFeatures();

    Set<String> flaky = new LinkedHashSet<>(pass1Failed);
    flaky.removeAll(stillFailing);

    StringBuilder sb = new StringBuilder("\n");
    sb.append("===== Whole-feature retry summary =====\n");
    sb.append(String.format("  Pass 1 failed features:          %d%n", pass1Failed.size()));
    sb.append(String.format("  Recovered on retry (flaky):      %d%n", flaky.size()));
    sb.append(String.format("  Still failing after retry:       %d%n", stillFailing.size()));

    if (!flaky.isEmpty()) {
      sb.append("\n  Flaky (passed on retry):\n");
      flaky.forEach(f -> sb.append("    ✓ ").append(f).append('\n'));
    }

    if (stillFailing.isEmpty()) {
      // Recovered — log and pass.
      log.info("{}", sb);
      log.info("[CliIT] All retried features recovered. Build PASS (marked flaky).");
      return;
    }

    sb.append("\n  Still failing after retry:\n");
    int countFails = 0;
    for (Map.Entry<String, List<FailedScenario>> e : pass2.failuresByFeature().entrySet()) {
      sb.append("    ✗ ").append(e.getKey()).append('\n');
      for (FailedScenario s : e.getValue()) {
        countFails++;
        sb.append("        - ").append(s.scenario()).append('\n');
        String msg = firstLine(s.message());
        if (!msg.isEmpty()) {
          sb.append("          ").append(msg).append('\n');
        }
      }
    }

    sb.append(String.format(
        "%n  %d feature(s) / %d scenario(s) still red after %d retry. See Allure for full traces.%n",
        stillFailing.size(), countFails, MAX_RETRIES));

    // Surface the full report in stdout AND in the AssertionError so it
    // lands in both Failsafe console output and the XML report's failure
    // message — CI dashboards reading either source get the same triage info.
    String report = sb.toString();
    log.error("{}", report);
    throw new AssertionError(report);
  }

  private static String firstLine(String s) {
    if (s == null) return "";
    int nl = s.indexOf('\n');
    String line = (nl >= 0 ? s.substring(0, nl) : s).trim();
    // Truncate very long single-line messages so the report stays scannable.
    return line.length() > 220 ? line.substring(0, 217) + "..." : line;
  }

  // ===== listener =====

  /**
   * Walks each failed test identifier up to its feature-file ancestor and
   * groups failures by feature classpath URI.
   */
  static final class FailedFeatureTracker implements TestExecutionListener {

    private final Map<String, List<FailedScenario>> byFeature = new LinkedHashMap<>();
    private volatile TestPlan plan;

    @Override
    public void testPlanExecutionStarted(TestPlan testPlan) {
      this.plan = testPlan;
    }

    @Override
    public void executionFinished(TestIdentifier id, TestExecutionResult result) {
      if (result.getStatus() != TestExecutionResult.Status.FAILED) return;
      Optional<String> feature = featurePathOf(id);
      if (feature.isEmpty()) return;
      String scenario = id.getDisplayName();
      String msg = result.getThrowable().map(Throwable::getMessage).orElse("");
      synchronized (byFeature) {
        byFeature.computeIfAbsent(feature.get(), k -> new ArrayList<>())
            .add(new FailedScenario(scenario, msg));
      }
    }

    Set<String> failedFeatures() {
      synchronized (byFeature) {
        return new LinkedHashSet<>(byFeature.keySet());
      }
    }

    Map<String, List<FailedScenario>> failuresByFeature() {
      synchronized (byFeature) {
        return new LinkedHashMap<>(byFeature);
      }
    }

    private Optional<String> featurePathOf(TestIdentifier id) {
      TestIdentifier cur = id;
      while (cur != null) {
        Optional<TestSource> src = cur.getSource();
        if (src.isPresent() && src.get() instanceof ClasspathResourceSource crs) {
          String name = crs.getClasspathResourceName();
          if (name.endsWith(".feature")) {
            return Optional.of("classpath:" + (name.startsWith("/") ? name.substring(1) : name));
          }
        }
        cur = (plan == null) ? null : plan.getParent(cur).orElse(null);
      }
      return Optional.empty();
    }
  }

  record FailedScenario(String scenario, String message) {}

  /**
   * Merges the pass-1 JUnit XML with the retry (pass-2) XML into a single
   * post-retry report. The retry re-runs whole features, so pass 2 is the
   * authoritative record for every feature it touched: we drop pass 1's
   * {@code <testcase>}s for those features (matched by {@code classname},
   * which the Cucumber formatter sets to the feature name) and splice in all
   * of pass 2's. The {@code testsuite} counters are recomputed from the
   * merged set so flaky-but-recovered scenarios read green in CI.
   */
  static final class JUnitXmlReportMerger {

    static void merge(Path pass1, Path pass2, Path out) {
      try {
        javax.xml.parsers.DocumentBuilder db = newDocumentBuilder();
        org.w3c.dom.Document base = db.parse(pass1.toFile());
        org.w3c.dom.Document retry = db.parse(pass2.toFile());

        org.w3c.dom.Element baseSuite = (org.w3c.dom.Element) base
            .getElementsByTagName("testsuite").item(0);

        Set<String> retriedFeatures = new LinkedHashSet<>();
        List<org.w3c.dom.Element> retryCases = testCases(retry);
        for (org.w3c.dom.Element c : retryCases) {
          retriedFeatures.add(c.getAttribute("classname"));
        }

        // Drop pass-1 cases for any feature that was retried.
        for (org.w3c.dom.Element c : testCases(base)) {
          if (retriedFeatures.contains(c.getAttribute("classname"))) {
            baseSuite.removeChild(c);
          }
        }
        // Splice in pass-2's authoritative cases.
        for (org.w3c.dom.Element c : retryCases) {
          baseSuite.appendChild(base.importNode(c, true));
        }

        recomputeCounters(base, baseSuite);
        write(base, out);
      } catch (Exception e) {
        // Reporting must never mask the real test outcome. Fall back to the
        // pass-1 report so CI still shows scenarios, and log loudly.
        log.error("[CliIT] Failed to merge retry JUnit XML; publishing pass-1 report instead.", e);
        try {
          Files.copy(pass1, out, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException copyFail) {
          log.error("[CliIT] Could not publish fallback report either.", copyFail);
        }
      }
    }

    private static List<org.w3c.dom.Element> testCases(org.w3c.dom.Document doc) {
      org.w3c.dom.NodeList nodes = doc.getElementsByTagName("testcase");
      List<org.w3c.dom.Element> out = new ArrayList<>(nodes.getLength());
      for (int i = 0; i < nodes.getLength(); i++) {
        out.add((org.w3c.dom.Element) nodes.item(i));
      }
      return out;
    }

    private static void recomputeCounters(org.w3c.dom.Document doc, org.w3c.dom.Element suite) {
      int tests = 0, failures = 0, errors = 0, skipped = 0;
      double time = 0.0;
      for (org.w3c.dom.Element c : testCases(doc)) {
        tests++;
        if (c.getElementsByTagName("failure").getLength() > 0) failures++;
        if (c.getElementsByTagName("error").getLength() > 0) errors++;
        if (c.getElementsByTagName("skipped").getLength() > 0) skipped++;
        String t = c.getAttribute("time");
        if (t != null && !t.isBlank()) {
          try { time += Double.parseDouble(t); } catch (NumberFormatException ignored) { /* leave as-is */ }
        }
      }
      suite.setAttribute("tests", Integer.toString(tests));
      suite.setAttribute("failures", Integer.toString(failures));
      suite.setAttribute("errors", Integer.toString(errors));
      suite.setAttribute("skipped", Integer.toString(skipped));
      suite.setAttribute("time", String.format(java.util.Locale.ROOT, "%.3f", time));
    }

    private static javax.xml.parsers.DocumentBuilder newDocumentBuilder() throws Exception {
      javax.xml.parsers.DocumentBuilderFactory f =
          javax.xml.parsers.DocumentBuilderFactory.newInstance();
      // Hardening: this XML is generated by our own run, but disable external
      // entity resolution on principle.
      f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
      return f.newDocumentBuilder();
    }

    private static void write(org.w3c.dom.Document doc, Path out) throws Exception {
      javax.xml.transform.Transformer tr =
          javax.xml.transform.TransformerFactory.newInstance().newTransformer();
      tr.setOutputProperty(javax.xml.transform.OutputKeys.ENCODING, "UTF-8");
      tr.transform(new javax.xml.transform.dom.DOMSource(doc),
          new javax.xml.transform.stream.StreamResult(out.toFile()));
    }
  }
}
