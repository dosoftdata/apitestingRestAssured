package apis.middleware.validators.pam.wager;

import apis.middleware.models.response.pam.wager.PlaceWagerResponse;
import io.restassured.response.Response;
import org.testng.asserts.SoftAssert;

import java.util.List;

public final class PlaceWagerResponseValidator {

    private PlaceWagerResponseValidator() {
    }

    public static void assertSchema(Response response) {
        SoftAssert softly = new SoftAssert();
        PlaceWagerResponse placeWagerResponse = response.as(PlaceWagerResponse.class);
        String gameType = placeWagerResponse.getGameType();

        if (gameType == null || gameType.trim().isEmpty()) {
            softly.fail("Cannot determine place wager response schema: gameType is missing");
        } else if ("JOKER".equalsIgnoreCase(gameType)) {
            assertJokerPlaceWagerResponse(softly, placeWagerResponse);
        } else if ("KINO".equalsIgnoreCase(gameType)) {
            assertKinoPlaceWagerResponse(softly, placeWagerResponse);
        } else {
            softly.fail("Unsupported place wager response schema gameType: " + gameType);
        }

        softly.assertAll();
    }

    private static void assertJokerPlaceWagerResponse(SoftAssert softly, PlaceWagerResponse placeWagerResponse) {
        assertPlaceWagerResponse(softly, placeWagerResponse, "JOKER place wager response");
    }

    private static void assertKinoPlaceWagerResponse(SoftAssert softly, PlaceWagerResponse placeWagerResponse) {
        String path = "KINO place wager response";
        assertPlaceWagerResponse(softly, placeWagerResponse, path);
        softly.assertNotNull(placeWagerResponse.getKinoSystemEnabled(), path + ".kinoSystemEnabled should exist");
    }

    static void assertPlaceWagerResponse(SoftAssert softly, PlaceWagerResponse placeWagerResponse, String path) {
        softly.assertNotNull(placeWagerResponse.getWagerId(), path + ".wagerId should exist");
        assertNotEmpty(softly, placeWagerResponse.getSerialNumbers(), path + ".serialNumbers");
        softly.assertNotNull(placeWagerResponse.getCrcCode(), path + ".crcCode should exist");
        softly.assertNotNull(placeWagerResponse.getHexCrcCode(), path + ".hexCrcCode should exist");
        softly.assertNotNull(placeWagerResponse.getTransactionId(), path + ".transactionId should exist");
        softly.assertNotNull(placeWagerResponse.getGuid(), path + ".guid should exist");
        softly.assertNotNull(placeWagerResponse.getOperator(), path + ".operator should exist");
        softly.assertNotNull(placeWagerResponse.getChannelId(), path + ".channelId should exist");
        softly.assertNotNull(placeWagerResponse.getGameType(), path + ".gameType should exist");
        softly.assertNotNull(placeWagerResponse.getWager(), path + ".wager should exist");
        softly.assertNotNull(placeWagerResponse.getPromotionOutcomes(), path + ".promotionOutcomes should exist");

        PlaceWagerResponse.Wager wager = placeWagerResponse.getWager();
        if (wager != null) {
            assertNotEmpty(softly, wager.getBoards(), path + ".wager.boards");
            softly.assertNotNull(wager.getColumns(), path + ".wager.columns should exist");
            softly.assertNotNull(wager.getCost(), path + ".wager.cost should exist");
            softly.assertNotNull(wager.getParticipatingDraws(), path + ".wager.participatingDraws should exist");
            softly.assertNotNull(wager.getStatus(), path + ".wager.status should exist");
            softly.assertNotNull(wager.getBlockStatus(), path + ".wager.blockStatus should exist");
            softly.assertNotNull(wager.getDiscount(), path + ".wager.discount should exist");
            assertBoardSchema(softly, wager.getBoards(), path + ".wager.boards");
            assertParticipatingDrawsSchema(softly, wager.getParticipatingDraws(), path + ".wager.participatingDraws");
        }
    }

    private static void assertBoardSchema(SoftAssert softly, List<PlaceWagerResponse.Board> boards, String path) {
        if (boards == null || boards.isEmpty()) {
            return;
        }

        PlaceWagerResponse.Board board = boards.get(0);
        softly.assertNotNull(board.getBetType(), path + "[0].betType should exist");
        softly.assertNotNull(board.getBoardId(), path + "[0].boardId should exist");
        softly.assertNotNull(board.getMultipliers(), path + "[0].multipliers should exist");
        assertNotEmpty(softly, board.getPanels(), path + "[0].panels");

        if (board.getPanels() != null) {
            for (int i = 0; i < board.getPanels().size(); i++) {
                assertPanelSchema(softly, board.getPanels().get(i), path + "[0].panels[" + i + "]");
            }
        }
    }

    private static void assertPanelSchema(SoftAssert softly, PlaceWagerResponse.Panel panel, String path) {
        softly.assertNotNull(panel, path + " should exist");
        if (panel != null) {
            assertNotEmpty(softly, panel.getSelection(), path + ".selection");
            softly.assertNotNull(panel.getQuickPick(), path + ".quickPick should exist");
        }
    }

    private static void assertParticipatingDrawsSchema(SoftAssert softly,
                                                       PlaceWagerResponse.ParticipatingDraws participatingDraws,
                                                       String path) {
        if (participatingDraws == null) {
            return;
        }

        assertNotEmpty(softly, participatingDraws.getDraws(), path + ".draws");
        softly.assertNotNull(participatingDraws.getFirstDraw(), path + ".firstDraw should exist");
        softly.assertNotNull(participatingDraws.getFirstDrawTime(), path + ".firstDrawTime should exist");
        softly.assertNotNull(participatingDraws.getLastDraw(), path + ".lastDraw should exist");
        softly.assertNotNull(participatingDraws.getLastDrawTime(), path + ".lastDrawTime should exist");
        softly.assertNotNull(participatingDraws.getMultipleDraws(), path + ".multipleDraws should exist");
    }

    private static void assertNotEmpty(SoftAssert softly, List<?> values, String path) {
        softly.assertNotNull(values, path + " should exist");
        if (values != null) {
            softly.assertFalse(values.isEmpty(), path + " should not be empty");
        }
    }
}
