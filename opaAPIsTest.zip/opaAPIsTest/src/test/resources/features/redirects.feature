@mock @redirects
Feature: Redirect handling (WireMock simulation)
  Stubs under wiremock/mappings/redirects/ simulate a 3-hop chain:
  /redirects/start -> /redirects/hop/1 -> /redirects/hop/2 -> /redirects/final (200)
  plus a circular loop at /redirects/loop (302 to itself).

  Background:
    Given url {{mockServerUrl}}

  # Postman: "Automatically follow redirects" OFF — assert on the 3xx itself
  Scenario: Follow disabled - assert the 302 and its Location header
    And redirect follow false
    When path /redirects/start
    And method GET
    Then status 302
    And Header loc in response.Location
    And match string {{loc}} contains /redirects/hop/1

  # Postman default: follow ON — the test sees only the final response
  Scenario: Follow enabled - 3-hop chain lands on the final 200
    And redirect follow true
    When path /redirects/start
    And method GET
    Then status 200
    And match path $.status should be #contains LANDED

  # Postman: "Maximum number of redirects" — cap above chain length still lands
  Scenario: Max redirects above chain length - still lands
    And redirect follow true
    And redirect max 5
    When path /redirects/start
    And method GET
    Then status 200
    And match path $.status should be #contains LANDED

  # Same toggle via the fresh-per-step DSL (OneTimeSteps: set/add prefixes)
  Scenario: Follow disabled via one-time steps - assert the 302
    Given set Url {{mockServerUrl}}
    And add redirect follow false
    And add path /redirects/start
    When set method GET
    Then status 302
    And Header loc in response.Location
    And match string {{loc}} contains /redirects/hop/1

  # A cap below the chain length (e.g. redirect max 1 on this chain) or the
  # /redirects/loop stub makes the GET itself fail with
  # "Maximum redirects (N) exceeded" / CircularRedirectException — there is no
  # DSL step to assert a transport error, so that path is not scenario-ized.
