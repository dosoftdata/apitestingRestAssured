@pam
@sanity
Feature: Player Onboarding and Initial Setup

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  # Initial OTP creation may need retry as a /web call without a valid/present csrftoken
  @player-setup @player-registration @email-verification
  Scenario: Create OTP Verification
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1/otp
    And def randomMSISDN = {{pam.$random8Digit}}
    And OTP create request body


  @player-setup @player-registration @email-verification
  Scenario: Verify OTP Code
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And OTP verify request body
    When method PUT
    Then status 204


  @player-registration @email-verification @temporary-account @full-account
  Scenario Outline: Register Player
    Given path /web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And new player registration username <username> password <password> dob <dateOfBirth> gender <gender> bonus <bonusCode> identityType <identityType>
    When method POST
    Then status 200
    * def playerId in response.id
    * def username in response.username

    Examples:
      | username | password     | dateOfBirth | gender | bonusCode            | identityType |
      | testuser | Qwerty12345! | 1970-09-29  | M      | THIS_IS_A_BONUS_CODE | OTHER        |


  @temporary-account @email-verification @full-account
  Scenario Outline: Login BackOffice
    Given url {{pam.boBaseUrl}}
    And path /cc/access/rest/v1/sessions
    And backoffice login with username <username> password <password>
    When method POST
    And status 403
    * Cookie x-csrftoken in response.csrftoken
    # Retry POST with a valid csrftoken
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method POST
    Then status 200 or 204

    Examples:
      | username | password |
      | admin    | admin    |


  # Retrieve registration mail, hold verification hash and use it
  @email-verification @temporary-account @full-account
  Scenario: Verify Registration Player's Email
    Given url {{pam.boBaseUrl}}
    And path /cc/communication/rest/v1/emails
    And param playerId = {{playerId}}
    And delay request 10000
    When method GET
    Then status 200
    * def mailHash in response.data[0].id

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/communication/rest/v1/emails/{hash_for_mail}
    And add pathParam hash_for_mail = {{mailHash}}
    When set method GET
    Then status 200 or 204
    * def response_body in response.$

    And extract string using &hash= with name hashId from body response
    And backoffice verify player's email with hash hashId


  @full-account
  Scenario: Get Payment Codes - EX & NEX
    Given url {{pam.boBaseUrl}}
    And path /cc/wallet/rest/v2/customers/{{playerId}}/payment-methods
    And param category = ALL
    When method GET
    Then status 200


  @full-account
  Scenario: Add User to EP group
    # Get API Token
    Given url {{pam.webBaseUrl}}
    And path /api/access/oidc/token
    And header Content-Type = application/x-www-form-urlencoded
    And header Authorization = Basic {{pam.basic_auth}}
    And request
    """
    grant_type=client_credentials
    """
    When method POST
    Then status 200
    * def api_access_token in response.access_token

    # Get access groups types
    Given set Url {{pam.webBaseUrl}}
    And add path /api/access/rest/v1/accessgroups
    And set header Authorization = Bearer {{api_access_token}}
    And set header Content-Type = application/json
    When set method GET
    Then status 200
    * def exclusive_games_group_id in response.find { it.name == 'EXCLUSIVE_GAMES_ONLY' }.accessGroupId

    # Add User to EX Games Group
    Given set Url {{pam.webBaseUrl}}
    And add path /api/access/rest/v1/accessgroups/{{exclusive_games_group_id}}/members
    And set header Authorization = Bearer {{api_access_token}}
    And set header Content-Type = application/json
    And add request
    """
    {
      "memberId": "1-{{playerId}}",
      "retailerId": "1",
      "updatedByUserId": "1-{{playerId}}"
    }
    """

    When set method POST
    Then status 201


  @full-account
  Scenario: Set Mandatory Exclusive Limits
    # Login with Player - Get OIDC Token
    Given url {{pam.webBaseUrl}}
    And path /web/access/oidc/token
    And header Authorization = Basic {{pam.basic_auth_widgets}}
    And header X-GAME-ID = KINO
    And OIDC player login request body
    When method POST
    Then status 200
    * def token_type in response.token_type
    * def oidc_access_token in response.access_token
    * Cookie web-x-csrftoken in response.csrftoken

    # Set Mandatory Limits for Exclusive Games
    And set mandatory exclusive limits


  @full-account
  Scenario Outline: Deposit via Payment Code
    # Get Payment code for EXCLUSIVE games
    Given url {{pam.boBaseUrl}}
    And path /cc/wallet/rest/v2/customers/{{playerId}}/payment-methods
    And param category = ALL
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    * def payment_code_exclusive in response.find { it.paymentMethodId == 'PAYMENT_CODE_EXCLUSIVE' }.paymentCode

    # Make the deposit
    And wallet deposit request action <walletAction> operation <walletOperation> channel <walletChannel> paymentType <walletPaymentType> paymentMethodType <walletPaymentMethodType> paymentMethodId <walletPaymentMethodId> paymentCode <paymentCode> pspPaymentId <pspPaymentId> amount <amount> amountCurrency <amountCurrency> serviceCostAmount <serviceCostAmount> serviceCostCurrency <serviceCostCurrency> ownerId <ownerId> ownerType <ownerType> pspId <pspId> pspTargetId <pspTargetId> forceReview <forceReview> paybankId <paybankId>

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/wallet/rest/v2/users/1-{{playerId}}/accounts
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And set header Content-Type = application/json
    When set method GET
    Then status 200
    * match path $[?(@.accountType=='AT_MAIN')].accountType should be = AT_MAIN
    * match path $[?(@.accountType=='AT_MAIN')].id should be = AT_MAIN-1
    * match path $[?(@.accountType=='AT_MAIN')].balance should be = <amount>
    * match path $[?(@.accountType=='AT_MAIN')].buyingPower should be = <amount>

    Examples:
      | walletAction | walletOperation | walletChannel | walletPaymentType | walletPaymentMethodType | walletPaymentMethodId  | paymentCode                | pspPaymentId | amount | amountCurrency | serviceCostAmount | serviceCostCurrency | ownerId      | ownerType | pspId          | pspTargetId | forceReview | paybankId |
      | COMMIT       | WALLET_DEPOSIT  | WEB           | PT_TRANSFER_IN    | PAYMENT_CODE            | PAYMENT_CODE_EXCLUSIVE | {{payment_code_exclusive}} | pspId.1      | 10.0   | EUR            | 1.0               | EUR                 | {{playerId}} | 1         | voucherPSPDemo | pspTargetId | false       | 123       |


  @full-account @skipOnUat
  Scenario Outline: Deposit via CARD
    # Make TRANSFER_IN deposit
    Given url {{pam.webBaseUrl}}
    And path /web/tora/rest/v1/customers/{{playerId}}/payments
    And header Origin = {{pam.webBaseUrl}}
    And header Content-type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = KINO
    And header Authorization = {{token_type}} {{oidc_access_token}}
    And card deposit request body amount <depositAmount> currency <currency> paymentMethodType <depositPaymentMethodType> paymentType <depositPaymentType>
    And delay request 5000
    When method POST
    Then status 202
    * def deposit_payment_id in response.paymentId
    * def signature in response.signature
    * def deposit_amount in response.amount

    And player sets master card 3DSecure details number <cardNumber> holderName "<holderName>" cvv <cvv> expMonth <expMonth> expYear <expYear> merchantReference <merchant> signature <signature> amount <cardAmount> currency <currency>

    # Commit Deposit Action to Tora
    Given set Url {{pam.webBaseUrl}}
    And add path /web/tora/rest/v1/payments/{{deposit_payment_id}}/token
    And set header Origin = {{pam.webBaseUrl}}
    And set header Content-type = application/json
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header x-game-id = KINO
    And set header Authorization = {{token_type}} {{oidc_access_token}}
    And add request
    """
    {
     "token": "{{deposit_token_id}}"
    }
    """
    And add delay request 2000
    When set method PUT
    Then status 202

    # Check wallet balance
    Given set Url {{pam.boBaseUrl}}
    And add path /cc/wallet/rest/v2/users/1-{{playerId}}/accounts
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And set header Content-Type = application/json
    And add delay request 5000
    When set method GET
    Then status 200
    * match path $[?(@.accountType=='AT_MAIN')].id should be = AT_MAIN-1
    * match path $[?(@.accountType=='AT_MAIN')].balance should be = <expectedBalance>
    * match path $[?(@.accountType=='AT_MAIN')].buyingPower should be = <expectedBuyingPower>

    Examples:
      | depositAmount | depositPaymentMethodType | depositPaymentType | cardNumber       | holderName | cvv | expMonth | expYear | merchant              | signature     | cardAmount | currency | expectedBalance | expectedBuyingPower |
      | 10            | CARD                     | PT_TRANSFER_IN     | 5457210001000001 | TEST PROD  | 152 | 12       | 2030    | {{deposit_payment_id}}| {{signature}} | 1000       | EUR      | 20.0            | 20.0                |


  @full-account
  Scenario: Upload Card Documents
    # Uploading of CARD jpeg files
    Given url {{pam.webBaseUrl}}
    And path /web/customer/rest/v1/players/{{playerId}}/documents
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header Content-Type = multipart/form-data
    And header Authorization = {{token_type}} {{oidc_access_token}}
    And form field fileName = image_card_front.jpg
    And form field type = CARD_FRONT
    And form field file = image_card_front.jpg
    And multipart file file path src/test/resources/files/image_card_front.jpg mimeType image/jpeg
    When method POST
    Then status 200

    Given set Url {{pam.webBaseUrl}}
    And add path /web/customer/rest/v1/players/{{playerId}}/documents
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header Content-Type = multipart/form-data
    And set header Authorization = {{token_type}} {{oidc_access_token}}
    And add form field fileName = image_card_back.jpg
    And add form field type = CARD_BACK
    And add form field file = image_card_back.jpg
    And add multipart file file path src/test/resources/files/image_card_back.jpg mimeType image/jpeg
    When set method POST
    Then status 200


  @full-account @skipOnUat
  Scenario: Get pending Verification CARD Documents and Uploaded Documents
    # Save pending verification and document IDs in order to verify them one by one
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/pending-verifications
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And delay request 2000
    When method GET
    Then status 200
    And match response body path $ should be hasSize 2
    And match path $[?(@.verificationType=='CARD')].status should be = WAITING_ADMIN_APPROVAL
    And match path $[?(@.verificationType=='IBAN')].status should be = PENDING
    * def CARD_verification_ID in response.find { it.verificationType == 'CARD' }.id
    * def card_fingerprint in response.find { it.verificationType == 'CARD' }.metadata.fingerprint

    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/documents
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And header Content-Type = application/json
    When method GET
    Then status 200
    * def ID_card_document_front_ID in response.find { it.type == 'CARD_FRONT' }.id
    * def ID_card_document_back_ID in response.find { it.type == 'CARD_BACK' }.id


  @full-account @skipOnUat
  Scenario: Verify Card Documents and CARD payment type
    # Verify Card document - FRONT
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/verification-documents/approve
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And verification document approval request body verificationId CARD_verification_ID verificationType CARD documentId ID_card_document_front_ID statusDescription Approve uploaded document for Card
    When method POST
    Then status 200
    And match response documentType = CARD_FRONT
    And match response status = APPROVED


    # Verify Card document - BACK
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/verification-documents/approve
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And verification document approval request body verificationId CARD_verification_ID verificationType CARD documentId ID_card_document_back_ID statusDescription Approve uploaded document for Card
    When method POST
    Then status 200
    * match response documentType = CARD_BACK
    * match response status = APPROVED


    # Verify Player's CARD
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/verifications/confirm
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And request
    """
    {
      "id": {{CARD_verification_ID}},
      "verificationType": "CARD"
    }
    """

    When method POST
    Then status 200
    And match response verificationType = CARD
    And match response status = VERIFIED
    * def card_fingerprint in response.metadata.fingerprint


  @full-account
  Scenario: Verify IBAN account
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/pending-verifications
    And param verificationType = IBAN
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match path $[?(@.verificationType=='IBAN')].status should be = PENDING
    And match path $[?(@.verificationType=='IBAN')].value should be = GR2202655559367039137283047
    * def IBAN_verification_ID in response.find { it.verificationType == 'IBAN' }.id

    Given set Url {{pam.webBaseUrl}}
    And add path /api/access/oidc/token
    And set header Content-Type = application/x-www-form-urlencoded
    And set header Authorization = Basic {{pam.basic_auth}}
    And add request
    """
    grant_type=client_credentials
    """
    When set method POST
    Then status 200
    * def api_access_token in response.access_token

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/customers/{{playerId}}/verifications/iban
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header Authorization = Bearer {{oidc_access_token}}
    And set header Content-Type = application/json
    And add request
    """
    {
     "iban":"{{pam.IBAN}}",
     "id":{{IBAN_verification_ID}}
    }
    """
    When set method POST
    Then status 200 or 204


  @full-account
  Scenario: Player Upload ID documents
    # Uploading of OTHER document type
    Given url {{pam.webBaseUrl}}
    And path /web/customer/rest/v1/players/{{playerId}}/documents
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header Content-Type = multipart/form-data
    And header Authorization = {{token_type}} {{oidc_access_token}}
    And form field fileName = image.jpg
    And form field type = OTHER
    And form field file = image.jpg
    And multipart file file path src/test/resources/files/image.jpg mimeType image/jpeg
    When method POST
    Then status 200

    # Uploading of UTILITY BILL document type
    Given set Url {{pam.webBaseUrl}}
    And add path /web/customer/rest/v1/players/{{playerId}}/documents
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header Content-Type = multipart/form-data
    And set header Authorization = {{token_type}} {{oidc_access_token}}
    And add form field fileName = image.jpg
    And add form field type = UTILITY_BILL
    And add form field file = image.jpg
    And add multipart file file path src/test/resources/files/image.jpg mimeType image/jpeg
    When set method POST
    Then status 200


  @full-account
  Scenario: Get pending Verification IDENTITY Documents and Uploaded Documents
    # Save pending verification IDs in order to verify them later
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/pending-verifications
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And delay request 3000
    When method GET
    Then status 200
    * match response body path $ should be hasSize 1
    * match path $[?(@.verificationType=='IDENTITY')].status should be = WAITING_ADMIN_APPROVAL
    * def ID_verification_ID in response.find { it.verificationType == 'IDENTITY' }.id

    # Get uploaded documents IDs in order to verify them later
    Given set Url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/documents
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And set header Content-Type = application/json
    When method GET
    Then status 200
    * def ID_other_document_ID in response.find { it.type == 'OTHER' }.id
    * def ID_utility_document_ID in response.find { it.type == 'UTILITY_BILL' }.id


  @full-account
  Scenario: Verify ID Documents | IDENTITY type | FULL_ACCOUNT player status
    # Verify ID Document (OTHER)
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/verification-documents/approve
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And verification document approval request body verificationId ID_verification_ID verificationType IDENTITY documentId ID_other_document_ID statusDescription Approve uploaded document for ID
    When method POST
    Then status 200
    * match response documentType = OTHER
    * match response status = APPROVED

    # Verify ID Document (UTILITY BILL)
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/verification-documents/approve
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And verification document approval request body verificationId ID_verification_ID verificationType IDENTITY documentId ID_utility_document_ID statusDescription Approve uploaded document for ID
    When method POST
    Then status 200
    * match response documentType = UTILITY_BILL
    * match response status = APPROVED

    # Verify Player's IDENTITY
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/verifications/confirm
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And verification confirm request body id ID_verification_ID verificationType IDENTITY
    When method POST
    Then status 200
    * match response verificationType = IDENTITY
    * match response status = VERIFIED

    # Verify Player level = FULL_ACCOUNT
    Given set Url {{pam.webBaseUrl}}
    And add path /web/customer/rest/v1/players/{{playerId}}/player-levels
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header Authorization = {{token_type}} {{oidc_access_token}}
    When set method GET
    * match response playerLevel = FULL_ACCOUNT


  Scenario Outline: Place wager - place bet
    Given url {{pam.webBaseUrl}}
    And path /web/wager-service/rest/v1/wagers/{{playerId}}/place/lotteryWager
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = <gameType>
    And header Authorization = {{token_type}} {{oidc_access_token}}
    And player prepares wager request for gameId <gameType> betType <betType> multiplier <multiplier>
    When method POST
    Then status 200
    And exclusive wager response has expected schema
    * def serial_number in response.serialNumbers[0]
    * def game_type in response.gameType

    Examples:
      | gameType | betType | multiplier |
      | KINO     | 1       | 2          |


  Scenario Outline: Pay KINO winning wager
    # Get ILOT token
    Given get ILOT access token

    # Prize win KINO
    And exclusive bet wins with gameId <gameId> serialNumber <serialNumber> amount <amount> taxAmount <taxAmount>
    Then match
    """
    [
      {
        "userId": {
          "id": "#string",
          "type": "#number"
        },
        "accountId": "#string",
        "amount": "#number",
        "currency": "#string",
        "issued": "#string",
        "referenceId": "#string",
        "productId": "#string",
        "batchId": "#string",
        "type": "#string",
        "description": "#string",
        "autocapture": "#boolean",
        "id": "#number",
        "postBalance": "#number",
        "status": "#string",
        "captured": "#boolean"
      }
    ]
    """

    Examples:
    | gameId | serialNumber  | amount | taxAmount |
    | KINO   | serial_number | 10     | 1         |


  Scenario Outline: Withdraw via Card
    # Prepare withdrawal via card - Kino wallet
    Given url {{pam.webBaseUrl}}
    And path /api/wallet/rest/v1/payments
    And header Authorization = Bearer {{api_access_token}}
    And header X-GAME-ID = KINO
    And player prepares CARD withdrawal request with fingerprint <fingerprint> amount <amount>
    And delay request 5000
    When method POST
    Then status 200
    * def withdrawal_amount in response.amount
    * def withdrawal_payment_id in response.paymentId


    # Commit withdrawal via card
    Given url {{pam.webBaseUrl}}
    And path /api/wallet/rest/v1/payments/{{withdrawal_payment_id}}
    And header Authorization = Bearer {{api_access_token}}
    And player commits default withdrawal request with amount <amount>
    When method PUT
    Then status 200

    # Approve withdrawal via CARD from Backoffice
    Given url {{pam.boBaseUrl}}
    And path /cc/wallet/rest/v1/payments/{{withdrawal_payment_id}}
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And backoffice withdrawal approval request body action APPROVE
    When method PUT
    Then status 200

    Examples:
      | fingerprint          | amount    |
      | {{card_fingerprint}} | 10.0      |

  Scenario: Create bonus and assign it
    Given url {{pam.boBaseUrl}}
    And path /cc/bonus/rest/v1/bonuses?status=ACTIVE
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200


    # Use existing EX Bonus or create new
    And backoffice create default bonus with gameId KINO

    # Assign Kino Bonus to player
    Given set Url {{pam.webBaseUrl}}
    And add path /api/bonus/rest/v1/bonuses/{{bonus_kino_id}}/segment
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    And add request
    """
    {
        "users": [
            "1-{{playerId}}"
        ]
    }
    """
    When set method POST
    Then status 200 or 204
    * match response numberAssigned = 1
    Then match
    """
    {
      "totalNumberOfPlayers": "#number",
      "numberAssigned": "#number",
      "numberOfAbusers": "#number",
      "numberOfAlreadyAssignedBonuses": "#number",
      "numberOfInsufficientFundsPlayers": "#number",
      "abuserList": "#empty",
      "alreadyAssignedUsersList": "#empty",
      "numberOfInsufficientFundsPlayersList": "#empty"
    }
    """


  Scenario Outline: Place Kino bonus Wager
    # Place a big bet to consume from both wallets money
    # Kino bet amount is 50 Euros
    # betType == 2 -> KINO_BONUS
    Given url {{pam.webBaseUrl}}
    And path /web/wager-service/rest/v1/wagers/{{playerId}}/place/lotteryWager
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = <gameType>
    And header Authorization = {{token_type}} {{oidc_access_token}}
    And player prepares wager request for gameId <gameType> betType <betType> multiplier <multiplier>
    When method POST
    Then status 200
#    And exclusive wager response has expected schema

    Examples:
      | gameType | betType | multiplier |
      | KINO     | 2       | 50         |


  Scenario: Cancel bonus and bonus prizes
    # Get player's bonus prize id
    Given backoffice captures bonus prize id for product KINO

    # Cancel bonus prize
    Given set Url {{pam.boBaseUrl}}
    And add path /cc/bonus/rest/v1/bonus-prizes/{{bonus_prize_id}}
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And set header Content-type = application/json
    And add request
    """
    {"status":"CANCELLED","metaData": {"cancelReason":"used"}}
    """
    When set method PUT
    Then status 200 or 204

    # Cancel cc bonus
    Given set Url {{pam.boBaseUrl}}
    And add path /cc/bonus/rest/v1/bonuses/{{bonus_kino_id}}
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And set header Content-type = application/json
    And add request
    """
    {"status":"CANCELLED"}
    """
    When set method PUT
    Then status 200
    * match response status = CANCELLED
