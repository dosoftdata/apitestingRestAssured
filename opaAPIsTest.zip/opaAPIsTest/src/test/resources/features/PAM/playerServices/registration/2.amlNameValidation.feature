@pam
@playerServices
@registration
@aml
@amlNameValidation
Feature: Registration Process - AML - firstName and lastName validation

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Registration_Process > AML > Registration - firstName, lastName
  # Names must be all-Greek or all-Latin, uppercase or accented per AML rules.

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  # Postman: AML > Preparation (Create OTP Verification + Verify OTP Code)
  Scenario: Preparation - csrf token and verified OTP
    * call feature features/PAM/playerServices/common/otpHelpers.feature

    # Expected error descriptions, defined once and referenced from Examples rows
    # (they contain '|' and so cannot live in table cells).
    * def nameMixError =
    """
    First name and Last name should be both in Greek or Latin. ([Error Id: INVALID_PATTERN])
    """
    * def firstNamePatternError =
    """
    First name must match: ^(\p{InGreek}+(?:[- ](?![ -])\p{InGreek}+)*)$|^([A-Z]+(?:[- ](?![ -])[A-Z]+)*)$ ([Error Id: INVALID_PATTERN])
    """
    * def lastNamePatternError =
    """
    Last name must match: ^(\p{InGreek}+(?:[- ](?![ -])\p{InGreek}+)*)$|^([A-Z]+(?:[- ](?![ -])[A-Z]+)*)$ ([Error Id: INVALID_PATTERN])
    """


  # Postman: "failedRegister Player - ..." (15 requests)
  Scenario Outline: failedRegister Player - <case>
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "OTHER",
      "identityNumber": "ΨΓ{{regId}}",
      "firstName": "<firstName>",
      "middleName": "LOTTERY",
      "lastName": "<lastName>",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "ALB",
      "phone": "21{{regId}}",
      "mobilePhone": "69{{msisdn}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 400
    And match response errorId = INVALID_PATTERN
    And match response description = <description>

    Examples:
      | case                                | firstName | lastName | description               |
      | firstName GR, lastName ENG          | ΑΡΗΣ      | DRIVAS   | {{nameMixError}}          |
      | firstName ENG, lastName GR          | ARIS      | ΔΡΙΒΑΣ   | {{nameMixError}}          |
      | lastName GR contains 1 ENG char     | ΑΡΗΣ      | ΔΡΙΒAΣ   | {{lastNamePatternError}}  |
      | firstName, lastName lowercase ENG   | aris      | drivas   | {{firstNamePatternError}} |
      | firstName, lastName camelcase ENG   | Aris      | Drivas   | {{firstNamePatternError}} |
      | lastName camelcase ENG              | ARIS      | Drivas   | {{lastNamePatternError}}  |
      | lastName lowercase ENG              | ARIS      | drivas   | {{lastNamePatternError}}  |
      | firstName starting with dash GR     | -ΑΡΗΣ     | ΔΡΙΒΑΣ   | {{firstNamePatternError}} |
      | firstName ending with dash GR       | ΑΡΗΣ-     | ΔΡΙΒΑΣ   | {{firstNamePatternError}} |
      | lastName starting with dash GR      | ΑΡΗΣ      | -ΔΡΙΒΑΣ  | {{lastNamePatternError}}  |
      | lastName ending with dash GR        | ΑΡΗΣ      | ΔΡΙΒΑΣ-  | {{lastNamePatternError}}  |
      | firstName starting with dash ENG    | -ARIS     | DRIVAS   | {{firstNamePatternError}} |
      | firstName ending with dash ENG      | ARIS-     | DRIVAS   | {{firstNamePatternError}} |
      | lastName starting with dash ENG     | ARIS      | -DRIVAS  | {{lastNamePatternError}}  |
      | lastName ending with dash ENG       | ARIS      | DRIVAS-  | {{lastNamePatternError}}  |


  # Postman: "Register Player - ... GR" (5 requests, each preceded by Create OTP + Verify OTP)
  # NOTE: Postman kept the original 400 INVALID_PATTERN assertions commented out —
  # lowercase / accented Greek names are accepted since the rule was relaxed; expected 200.
  Scenario Outline: Register Player - <case>
    * call feature features/PAM/playerServices/common/otpHelpers.feature scenario Create and verify OTP
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "OTHER",
      "identityNumber": "ΨΓ{{regId}}",
      "firstName": "<firstName>",
      "middleName": "LOTTERY",
      "lastName": "<lastName>",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "ALB",
      "phone": "21{{regId}}",
      "mobilePhone": "69{{msisdn}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    And match response mobilePhone = 69{{msisdn}}

    Examples:
      | case                                          | firstName | lastName |
      | firstName, lastName lowercase GR              | αρης      | δριβας   |
      | firstName, lastName camelcase GR              | Άρης      | Δρίβας   |
      | firstName, lastName capitals with accent GR   | ΆΡΗΣ      | ΔΡΊΒΑΣ   |
      | lastName camelcase GR                         | ΑΡΗΣ      | Δρίβας   |
      | lastName lowercase GR                         | ΑΡΗΣ      | δρίβας   |
