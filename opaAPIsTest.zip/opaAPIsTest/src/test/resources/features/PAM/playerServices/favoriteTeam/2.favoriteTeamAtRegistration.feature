@pam
@playerServices
@favoriteTeam
@favoriteTeamAtRegistration
Feature: Player registration - favorite team included in registration process

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Player registration- favorite team is included in registration process
  # Postman used a fixed phone (6957120123) and username (testplayerFavTeam) —
  # replaced with fresh random data so the feature is re-runnable on a persistent env.

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  # Postman: "Create OTP Verification" + "Verify OTP Code"
  Scenario: Preparation - csrf token and verified OTP
    * call feature features/PAM/playerServices/common/otpHelpers.feature


  # Postman: "Register Player" (favoriteTeam FT_ARSENAL, identityType PASSPORT)
  Scenario: Register Player with favorite team
    Given def regId = random 8 digits
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "PASSPORT",
      "identityNumber": "{{regId}}",
      "firstName": "TEST",
      "middleName": "PLAYER",
      "lastName": "SERVICE",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "phone": "21{{regId}}",
      "mobilePhone": "69{{msisdn}}",
      "permanentResidenceCountry": "GRC",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "testplayerservice",
      "ibanNumber": "{{pam.IBAN}}",
      "favoriteTeam": "FT_ARSENAL",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    * def playerId in response.id
    * def username in response.username


  # Postman: "Get mailId for fetching hash" + "Get hash for mail verification" + "Verify Player's Email"
  Scenario: Verify registration email
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Login BackOffice

    Given url {{pam.boBaseUrl}}
    And path /cc/communication/rest/v1/emails
    And param playerId = {{playerId}}
    And delay request 10000
    When method GET
    Then status 200
    And match response body path data should be hasSize 1
    And match path $.data[0].messageText should be = Απέχεις ένα βήμα από την ενεργοποίηση του λογαριασμού σου
    And match path $.data[0].origin should be = player
    And match path $.data[0].status should be = SENT
    * def mailHash in response.data[0].id

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/communication/rest/v1/emails/{hash_for_mail}
    And add pathParam hash_for_mail = {{mailHash}}
    When set method GET
    Then check status 200
    And check match path $.subject should be = Απέχεις ένα βήμα από την ενεργοποίηση του λογαριασμού σου
    And check match path $.eventName should be = registrationWelcomeEvent.opaponline
    And check match path $.eventOwner should be = player
    And check match path $.status should be = SENT
    * def response_body in response.$

    And extract string using &hash= with name hashId from body response
    And backoffice verify player's email with hash hashId


  # Postman: "Get player info cc- favorite team exists"
  Scenario: Get player info cc - favorite team exists
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v2/players/{{playerId}}
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match response username = {{username}}
    And match response id = {{playerId}}
    And match response favoriteTeam = FT_ARSENAL


  # Postman: "Get Bearer Token (WEB)"
  Scenario: Get bearer token
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Get web bearer token


  # Postman: "Get Player Level (Temporary account)"
  Scenario: Get Player Level - temporary account
    Given path web/customer/rest/v1/players/{{playerId}}/player-levels
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
    And match response playerLevel = TEMPORARY_ACCOUNT


  # Postman: "Get Player (UserInfo)- player has set his favorite team" (X-GAME-ID CASINO)
  Scenario: Get UserInfo - favorite team set at registration
    Given path web/access/oidc/userinfo
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = CASINO
    When method GET
    Then status 200
    And match response username = {{username}}
    And match response id = {{playerId}}
    And match response playerLevel = TEMPORARY_ACCOUNT
    And match response optin = false
    And match response accountVerificationState = PENDING
    And match response favoriteTeam = FT_ARSENAL
