@pam
@playerServices
@registrationValidation
@validationStepThree
Feature: Registration validation endpoint - step 3 - identity and commercial options

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Validation endpoint for player registration
  # subfolders: Step Validation 3: commercial options / identityType / identityNumber / favorite team
  # Note: the validate endpoint expects commercialOptions as a JSON-encoded
  # STRING (kept verbatim, including the deliberately malformed variants).

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  Scenario: Preparation - csrf token
    * call feature features/PAM/playerServices/common/otpHelpers.feature scenario Bootstrap csrf token
    # The collection's fixed identityNumber 123456789 is already registered on a
    # persistent env (IDENTITY_NUMBER_NOT_FREE) — valid rows use a fresh one
    * def valIdNum = random 9 digits


  # Postman: "Step validation 3 invalid channel / commercialGroups / commercialBonus"
  Scenario Outline: Step validation 3 - commercial options <case>
    Given path web/customer/rest/v1-opap/players/registration-fields/validate
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request
    """
    { "commercialOptions": "<commercialOptions>", "identityType": "OTHER", "identityNumber": "MASASFDDAS", "favoriteTeam": "FT_AASD" }
    """
    When method POST
    Then status 200
    And match path $[?(@.fieldName=='commercialOptions')] should be exists

    Examples:
      | case                         | commercialOptions                                                                          |
      | invalid channel              | { \"channels\": [ \"TEST\" ], \"commercialComGroups\": true, \"commercialBonus\": true }   |
      | invalid commercialGroups     | { \"channels\": [ \"EMAIL\" ], \"commercialComGroups\": test, \"commercialBonus\": true }  |
      | invalid commercialBonus      | { \"channels\": [ \"EMAIL\" ], \"commercialComGroups\": true, \"commercialBonus\": false123 } |


  # Postman: "Step validation 3 valid" + "Step validation 3 valid identity type OTHER / PASSPORT"
  # + "Step validation 3 empty favoriteTeam- valid"
  Scenario Outline: Step validation 3 - valid <case>
    Given path web/customer/rest/v1-opap/players/registration-fields/validate
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request
    """
    { "commercialOptions": "{ \"channels\": [ \"EMAIL\" ], \"commercialComGroups\": true, \"commercialBonus\": <commercialBonus> }", "identityType": "<identityType>", "identityNumber": "<identityNumber>", "favoriteTeam": "<favoriteTeam>" }
    """
    When method POST
    Then status 200
    And match response body path $ should be hasSize 0

    Examples:
      | case                | commercialBonus | identityType | identityNumber | favoriteTeam |
      | commercial options  | true            | OTHER        | {{valIdNum}}   | FT_AASD      |
      | identity OTHER      | true            | OTHER        | {{valIdNum}}   | FT_AASD      |
      | identity PASSPORT   | false           | PASSPORT     | {{valIdNum}}   | FT_AASD      |
      | empty favoriteTeam  | true            | OTHER        | 222233334      |              |


  # Postman: "Create OTP Verification" + "Verify OTP Code" + "Register Player valid"
  Scenario: Register player with valid commercial options
    * call feature features/PAM/playerServices/common/otpHelpers.feature scenario Create and verify OTP
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "mobilePhone": "69{{msisdn}}",
      "email": "pampla{{regId}}@gmail.com",
      "identityType": "PASSPORT",
      "identityNumber": "{{regId}}",
      "firstName": "TEST",
      "middleName": "PLAYER",
      "lastName": "TESTERS",
      "gender": "M",
      "dateOfBirth": "1999-09-01",
      "country": "GR",
      "city": "Athens",
      "address1": "test 1",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "21{{regId}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "testplayerservice",
      "ibanNumber": "{{pam.IBAN}}",
      "commercialOptions": { "channels": [ "EMAIL" ], "commercialBonus": false, "commercialComGroups": false },
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    * def takenIdentityNumber = {{regId}}


  # Postman: "Step validation 3 empty/invalid identityType" + register pairs
  Scenario Outline: Step validation 3 - identityType <case>
    Given path web/customer/rest/v1-opap/players/registration-fields/validate
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request
    """
    { "commercialOptions": "{ \"channels\": [ \"EMAIL\" ], \"commercialComGroups\": true, \"commercialBonus\": true }", "identityType": "<identityType>", "identityNumber": "123456789", "favoriteTeam": "FT_AASD" }
    """
    When method POST
    Then status 200
    And match path $[?(@.fieldName=='identityType')] should be exists

    Examples:
      | case    | identityType |
      | empty   |              |
      | invalid | test         |


  # Postman: "Step validation 3 empty/max-length/passport-length/taken/national-id identityNumber"
  Scenario Outline: Step validation 3 - identityNumber <case>
    Given path web/customer/rest/v1-opap/players/registration-fields/validate
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request
    """
    { "commercialOptions": "{ \"channels\": [ \"EMAIL\" ], \"commercialComGroups\": true, \"commercialBonus\": true }", "identityType": "<identityType>", "identityNumber": "<identityNumber>", "favoriteTeam": "FT_AASD" }
    """
    When method POST
    Then status 200
    And match path $[?(@.fieldName=='identityNumber')] should be exists

    Examples:
      | case                        | identityType | identityNumber                            |
      | empty                       | OTHER        |                                           |
      | max length exceeded         | OTHER        | TESTTETETTESTTETTTESTSDSTTDSDTSADDASASDDS |
      | passport invalid length     | PASSPORT     | 2525121424                                |
      | already taken               | PASSPORT     | {{takenIdentityNumber}}                   |
      | national_id invalid pattern | NATIONAL_ID  | 123467588                                 |


  # Postman: register pairs for identityType / identityNumber / dateOfBirth quirks
  Scenario Outline: Register player - <case>
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "pamplaval3",
      "password": "Qwerty12345!",
      "mobilePhone": "6973444364",
      "email": "pamplaval3@gmail.com",
      "identityType": "<identityType>",
      "identityNumber": "<identityNumber>",
      "firstName": "TEST",
      "middleName": "PLAYER",
      "lastName": "TESTERS",
      "gender": "M",
      "dateOfBirth": "1999-09-01",
      "country": "GR",
      "city": "Athens",
      "address1": "test 12",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "2101000123",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "testplayerservice",
      "ibanNumber": "{{pam.IBAN}}",
      "commercialOptions": { "channels": [ "EMAIL" ], "commercialBonus": false, "commercialComGroups": false }
    }
    """
    When method POST
    Then status 400

    Examples:
      | case                              | identityType | identityNumber                            |
      | empty identityType                |              | 142327523                                 |
      | invalid identityType              | test         | 142327523                                 |
      | empty identityNumber              | OTHER        |                                           |
      | identityNumber max length         | OTHER        | TESTTETETTESTTETTTESTSDSTTDSDTSADDASASDDS |
      | passport number invalid length    | PASSPORT     | 2525121424                                |
      | existing identityNumber           | PASSPORT     | {{takenIdentityNumber}}                   |
      | national_id invalid pattern       | NATIONAL_ID  | 12346758AB                                |


  # Postman: "Step validation 3 invalid favorite team" (AEK, FTAEK)
  Scenario Outline: Step validation 3 - invalid favorite team <favoriteTeam>
    Given path web/customer/rest/v1-opap/players/registration-fields/validate
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request
    """
    { "commercialOptions": "{ \"channels\": [ \"EMAIL\" ], \"commercialComGroups\": true, \"commercialBonus\": true }", "identityType": "OTHER", "identityNumber": "222233334", "favoriteTeam": "<favoriteTeam>" }
    """
    When method POST
    Then status 200
    And match path $[?(@.fieldName=='favoriteTeam')] should be exists

    Examples:
      | favoriteTeam |
      | AEK          |
      | FTAEK        |


  # Postman: "Register Player invalid favorite team"
  Scenario: Register player - invalid favorite team
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "pamplafavval",
      "password": "Qwerty12345!",
      "email": "pamplafavval@mailsac.com",
      "identityType": "PASSPORT",
      "identityNumber": "123123523",
      "firstName": "TEST",
      "middleName": "PLAYER",
      "lastName": "SERVICE",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "2101000123",
      "mobilePhone": "6957120123",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "testplayerservice",
      "ibanNumber": "{{pam.IBAN}}",
      "favoriteTeam": "AEK"
    }
    """
    When method POST
    Then status 400
