@pam
@playerServices
@verificationWeb
@verifMsisdnIdIban
Feature: Verification Process Web - MSISDN, ID and IBAN

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Verification_Process_Web > MSISDN_ID_IBAN
  # Full verification chain: MSISDN change with SMS OTP, IBAN verification via
  # the api client, ID_FRONT/ID_BACK upload + BO approval until VERIFIED.
  # Postman used fixed player data (testprlver1/6956920126) — replaced with
  # fresh random data so the feature is re-runnable on a persistent env.

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  # Postman: Create OTP + Verify OTP + "Register Player 2" + BO session
  Scenario: Preparation - register player and BackOffice login
    * call feature features/PAM/playerServices/common/otpHelpers.feature
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "NATIONAL_ID",
      "identityNumber": "ΑΚ{{regId}}",
      "firstName": "TEST",
      "middleName": "PLR",
      "lastName": "VER",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "21{{regId}}",
      "mobilePhone": "69{{msisdn}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "agentId": "101001",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    * def playerId in response.id
    * def username in response.username
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Login BackOffice

  Scenario: Preparation - verify registration email
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Verify registration email

  # Postman: "Get Bearer Token (WEB)" + "Get Player Level (Temporary account)"
  Scenario: Preparation - player OIDC login
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Get web bearer token
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1/players/{{playerId}}/player-levels
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
    And match response playerLevel = TEMPORARY_ACCOUNT


  # Postman: "Get pending verifications documents (MSISDN-IBAN)"
  Scenario: Pending verifications - MSISDN and IBAN pending
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/pending-verifications
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match path $[?(@.verificationType=='MSISDN')].status should be = PENDING
    And match path $[?(@.verificationType=='MSISDN')].value should be = 69{{msisdn}}
    And match path $[?(@.verificationType=='IBAN')].status should be = PENDING
    And match path $[?(@.verificationType=='IBAN')].value should be = {{pam.IBAN}}
    * def IBAN_verification_ID in response.find { it.verificationType == 'IBAN' }.id


  # Postman: "MobilePhone Verification Request" + "Get BO Sms - OTP" + "Correct OTP Try"
  Scenario: Change mobile phone and verify via SMS OTP
    Given def newMsisdn = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v2/players/{{playerId}}/msisdn
    And header Content-Type = application/json
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"msisdn": "69{{newMsisdn}}", "otp": null}
    When method PUT
    Then status 200

    # The OTP code is the 5th word of the SMS message text
    Given set Url {{pam.boBaseUrl}}
    And add path /cc/communication/rest/v1/sms
    And add param playerId = {{playerId}}
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add delay request 5000
    When set method GET
    Then check status 200
    And check match path $.data[0].origin should be = player
    * def OTP = word 4 of response.data[0].messageText

    Given set Url {{pam.webBaseUrl}}
    And add path web/customer/rest/v2/players/{{playerId}}/msisdn
    And set header Content-Type = application/json
    And set header Authorization = {{token_type}} {{access_token}}
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header X-GAME-ID = JOKER
    And add request {"msisdn": "69{{newMsisdn}}", "otp": "{{OTP}}"}
    When set method PUT
    Then check status 200


  # Postman: "Get pending verifications documents (IBAN)" — MSISDN no longer pending
  Scenario: Pending verifications - only IBAN remains
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/pending-verifications
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match path $[?(@.verificationType=='IBAN')].status should be = PENDING
    And match response body path findAll { it.verificationType.equals('MSISDN') } should be hasSize 0


  # Postman: "Get Bearer Token" (api, client credentials) + "Verify IBAN account"
  Scenario: Verify IBAN account
    Given url {{pam.webBaseUrl}}
    And path /api/access/oidc/token
    And header Content-Type = application/x-www-form-urlencoded
    And header Authorization = Basic {{pam.basic_auth}}
    And request grant_type=client_credentials
    When method POST
    Then status 200
    * def api_access_token in response.access_token

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/customers/{{playerId}}/verifications/iban
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    And add request {"iban": "{{pam.IBAN}}", "id": {{IBAN_verification_ID}}}
    When set method POST
    Then check status 200 or 204


  # Postman: "Player Upload ID_FRONT document" + "Player Upload ID_BACK document"
  # One upload per scenario: two multipart callees in one scenario accumulate
  # form params on the shared spec (ArrayList cast error on the second POST).
  Scenario: Upload ID_FRONT document
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Upload identity document with args
      """
      { "docType": "ID_FRONT" }
      """

  Scenario: Upload ID_BACK document
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Upload identity document with args
      """
      { "docType": "ID_BACK" }
      """


  # Postman: "Get pending verifications documents (ID)" + "Get uploaded documents"
  Scenario: Pending verifications - identity waiting admin approval
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/pending-verifications
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match path $[?(@.verificationType=='IDENTITY')].status should be = WAITING_ADMIN_APPROVAL
    * def ID_verification_ID in response.find { it.verificationType == 'IDENTITY' }.id

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/{{playerId}}/documents
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    * def idFrontDocId in response.find { it.type == 'ID_FRONT' }.id
    * def idBackDocId in response.find { it.type == 'ID_BACK' }.id


  # Postman: alternating "Verify player's identity" + "Verify ID document" requests
  Scenario: Approve identity documents and verify identity
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Confirm identity - not all documents approved
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Approve identity document with args
      """
      { "approveDocumentId": "{{idFrontDocId}}", "approveDocType": "ID_FRONT" }
      """
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Confirm identity - not all documents approved
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Approve identity document with args
      """
      { "approveDocumentId": "{{idBackDocId}}", "approveDocType": "ID_BACK" }
      """
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Confirm identity - verified


  # Postman: "Get Player Level (Fully Verified account)" — no Postman assertions
  Scenario: Get player level - fully verified
    Given path web/customer/rest/v1/players/{{playerId}}/player-levels
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
