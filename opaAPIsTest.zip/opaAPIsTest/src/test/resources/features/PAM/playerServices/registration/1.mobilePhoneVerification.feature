@pam
@playerServices
@registration
@mobilePhoneVerification
Feature: Registration Process - MobilePhone Verification

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Registration_Process > MobilePhone Verification

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  # Postman: "Create OTP Veriification - csrftoken missing"
  # Doubles as the csrf bootstrap for the rest of the feature (saves the csrftoken cookie)
  Scenario: Create OTP Verification - csrftoken missing
    Given path web/customer/rest/v1/otp
    And request {}
    When method POST
    Then status 403
    And match response description = CSRF Token mismatch
    * Cookie web-x-csrftoken in response.csrftoken


  # Postman: "payload empty" / "phoneNumber null" / "phoneNumber empty"
  Scenario Outline: Create OTP Verification - validation error - phoneNumber <case>
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request <body>
    When method POST
    Then status 400
    And match response errorId = VALIDATION_ERROR
    And match response description = Validation failed
    And match path $.constraintViolations[0].constraintType should be = PARAMETER
    And match path $.constraintViolations[0].path should be = createOtp.arg0.phoneNumber
    And match path $.constraintViolations[0].message should be = may not be empty

    Examples:
      | case    | body                  |
      | missing | {}                    |
      | null    | {"phoneNumber": null} |
      | empty   | {"phoneNumber": ""}   |


  # Postman: "phoneNumber long/short/invalid starting numbers/alphanumeric/country code starting numbers"
  Scenario Outline: Create OTP Verification - invalid pattern - phoneNumber <case>
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"phoneNumber": "<phoneNumber>"}
    When method POST
    Then status 400
    And match response errorId = INVALID_MOBILE_PHONE_PATTERN
    And match response description = Invalid mobile phone pattern ([Error Id: INVALID_MOBILE_PHONE_PATTERN])

    Examples:
      | case                          | phoneNumber       |
      | long                          | 69712345679999999 |
      | short                         | 697               |
      | invalid starting numbers      | 1676888444        |
      | alphanumeric                  | 69769889ab        |
      | country code starting numbers | 306976985451      |


  # Postman: "Create OTP Veriification" (happy path)
  Scenario: Create OTP Verification
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    # fresh per pass (unlike pam.$random8Digit) so a whole-feature retry doesn't hit MOBILE_PHONE_NOT_FREE
    And def randomMSISDN = random 8 digits
    And request {"phoneNumber": "69{{randomMSISDN}}"}
    When method POST
    Then status 200
    And match response status = PENDING
    And match response phoneNumber = 3069{{randomMSISDN}}
    Then match
    """
    {
      "phoneNumber": "#string",
      "status": "#string",
      "uuid": "#string",
      "created": "#string",
      "expirationDate": "#string"
    }
    """
    * def otpUuid in response.uuid


  # Postman: "Verify OTP Code - payload empty" / "uuid phoneNumber missing"
  Scenario Outline: Verify OTP Code - validation errors - <case>
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request <body>
    When method PUT
    Then status 400
    And match response errorId = VALIDATION_ERROR
    And match response description = Validation failed
    And match response body path constraintViolations should be hasSize <violations>

    Examples:
      | case                      | body                            | violations |
      | payload empty             | {}                              | 3          |
      | uuid phoneNumber missing  | {"verificationCode": "000000"}  | 2          |


  # Postman: "Verify OTP Code - phoneNumber/uuid/verificationCode missing|null|empty"
  Scenario Outline: Verify OTP Code - validation error - <case>
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request <body>
    When method PUT
    Then status 400
    And match response errorId = VALIDATION_ERROR
    And match response description = Validation failed
    And match path $.constraintViolations[0].constraintType should be = PARAMETER
    And match path $.constraintViolations[0].path should be = <violationPath>
    And match path $.constraintViolations[0].message should be = <violationMessage>

    Examples:
      | case                     | body                                                                                                    | violationPath                  | violationMessage                          |
      | phoneNumber missing      | {"verificationCode": "000000", "uuid": "{{otpUuid}}"}                                                   | verifyOtp.arg0.phoneNumber     | may not be empty                          |
      | phoneNumber null         | {"verificationCode": "000000", "uuid": "{{otpUuid}}", "phoneNumber": null}                              | verifyOtp.arg0.phoneNumber     | may not be empty                          |
      | phoneNumber empty        | {"verificationCode": "000000", "uuid": "{{otpUuid}}", "phoneNumber": ""}                                | verifyOtp.arg0.phoneNumber     | may not be empty                          |
      | uuid missing             | {"phoneNumber": "69{{randomMSISDN}}", "verificationCode": "000000"}                                     | verifyOtp.arg0.uuid            | may not be empty                          |
      | uuid null                | {"phoneNumber": "69{{randomMSISDN}}", "verificationCode": "000000", "uuid": null}                       | verifyOtp.arg0.uuid            | may not be empty                          |
      | uuid empty               | {"phoneNumber": "69{{randomMSISDN}}", "verificationCode": "000000", "uuid": ""}                         | verifyOtp.arg0.uuid            | may not be empty                          |
      | verificationCode missing | {"phoneNumber": "69{{randomMSISDN}}", "uuid": "{{otpUuid}}"}                                            | verifyOtp.arg0.verificationCode | may not be null                          |
      | verificationCode null    | {"phoneNumber": "69{{randomMSISDN}}", "uuid": "{{otpUuid}}", "verificationCode": null}                  | verifyOtp.arg0.verificationCode | may not be null                          |
      | verificationCode empty   | {"phoneNumber": "69{{randomMSISDN}}", "uuid": "{{otpUuid}}", "verificationCode": ""}                    | verifyOtp.arg0.verificationCode | Otp verification code must contain 6 digits |


  # Postman: "Verify OTP Code - phoneNumber wrong" / "uuid invalid"
  Scenario Outline: Verify OTP Code - not found - <case>
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request <body>
    When method PUT
    Then status 404
    And match response errorId = OTP_VERIFICATION_NOT_FOUND
    And match response description = Otp verification not found. ([Error Id: OTP_VERIFICATION_NOT_FOUND])

    Examples:
      | case              | body                                                                                                                  |
      | phoneNumber wrong | {"verificationCode": "000000", "uuid": "{{otpUuid}}", "phoneNumber": "6976876567"}                                    |
      | uuid invalid      | {"phoneNumber": "69{{randomMSISDN}}", "verificationCode": "000000", "uuid": "37e57db8-8559-43e8-ba1e-219545068651"}   |


  # Postman: "Verify OTP Code - verificationCode invalid"
  Scenario: Verify OTP Code - verificationCode invalid
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"phoneNumber": "69{{randomMSISDN}}", "uuid": "{{otpUuid}}", "verificationCode": "123456"}
    When method PUT
    Then status 400
    And match response errorId = INVALID_VERIFICATION_CODE
    And match response description = Verification code is not valid. ([Error Id: INVALID_VERIFICATION_CODE])


  # Postman: "Verify OTP Code" (happy path, static dev/uat code 000000)
  Scenario: Verify OTP Code
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"phoneNumber": "69{{randomMSISDN}}", "uuid": "{{otpUuid}}", "verificationCode": "000000"}
    When method PUT
    Then status 204


  # Postman: "Verify OTP Code - verificationCode already verified"
  Scenario: Verify OTP Code - already verified
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"phoneNumber": "69{{randomMSISDN}}", "uuid": "{{otpUuid}}", "verificationCode": "000000"}
    When method PUT
    Then status 404


  # Postman: "Register Player - otpUuid missing"
  Scenario: Register Player - otpUuid missing
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And request
    """
    {
      "username": "pampla{{randomMSISDN}}",
      "password": "Qwerty12345!",
      "email": "pampla{{randomMSISDN}}@mailsac.com",
      "identityType": "OTHER",
      "identityNumber": "{{randomMSISDN}}",
      "firstName": "PAM",
      "middleName": "LOTTERY",
      "lastName": "PLATFORM",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "21{{randomMSISDN}}",
      "mobilePhone": "69{{randomMSISDN}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}"
    }
    """
    When method POST
    Then status 400
    And match response errorId = OTP_UUID_MISSING
    And match response description = Invalid request, otp uuid is missing. ([Error Id: OTP_UUID_MISSING])


  # Postman: "Register Player - otpUuid null/empty/invalid"
  Scenario Outline: Register Player - otpUuid <case>
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And request
    """
    {
      "username": "pampla{{randomMSISDN}}",
      "password": "Qwerty12345!",
      "email": "pampla{{randomMSISDN}}@mailsac.com",
      "identityType": "OTHER",
      "identityNumber": "{{randomMSISDN}}",
      "firstName": "PAM",
      "middleName": "LOTTERY",
      "lastName": "PLATFORM",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "21{{randomMSISDN}}",
      "mobilePhone": "69{{randomMSISDN}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "otpUuid": <otpUuid>
    }
    """
    When method POST
    Then status <status>
    And match response errorId = <errorId>
    And match response description = <description>

    Examples:
      | case    | otpUuid                                        | status | errorId                    | description                                                            |
      | null    | null                                           | 400    | OTP_UUID_MISSING           | Invalid request, otp uuid is missing. ([Error Id: OTP_UUID_MISSING])   |
      | empty   | ""                                             | 400    | OTP_UUID_MISSING           | Invalid request, otp uuid is missing. ([Error Id: OTP_UUID_MISSING])   |
      | invalid | "d3890919-eaeb-4bc8-b6ae-a3b9a23ca5e71312124"  | 404    | OTP_VERIFICATION_NOT_FOUND | Otp verification not found. ([Error Id: OTP_VERIFICATION_NOT_FOUND])   |


  # Postman: second "Create OTP Veriification" - fresh PENDING code for the register-pending check
  Scenario: Create OTP Verification - new pending code
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"phoneNumber": "69{{randomMSISDN}}"}
    When method POST
    Then status 200
    And match response status = PENDING
    * def otpUuid in response.uuid


  # Postman: "Register Player - verificationCode pending" (OTP exists but not verified yet)
  Scenario: Register Player - verificationCode pending
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And request
    """
    {
      "username": "pampla{{randomMSISDN}}",
      "password": "Qwerty12345!",
      "email": "pampla{{randomMSISDN}}@mailsac.com",
      "identityType": "OTHER",
      "identityNumber": "{{randomMSISDN}}",
      "firstName": "PAM",
      "middleName": "LOTTERY",
      "lastName": "PLATFORM",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "21{{randomMSISDN}}",
      "mobilePhone": "69{{randomMSISDN}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 404
    And match response errorId = OTP_VERIFICATION_NOT_FOUND
    And match response description = Otp verification not found. ([Error Id: OTP_VERIFICATION_NOT_FOUND])


  # Postman: second "Verify OTP Code"
  Scenario: Verify OTP Code - new pending code
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"phoneNumber": "69{{randomMSISDN}}", "uuid": "{{otpUuid}}", "verificationCode": "000000"}
    When method PUT
    Then status 204


  # Postman: "Register Player - mobilePhoneNumber invalid" (mobilePhone differs from the verified OTP phone)
  Scenario: Register Player - mobilePhoneNumber invalid
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And request
    """
    {
      "username": "pampla{{randomMSISDN}}",
      "password": "Qwerty12345!",
      "email": "pampla{{randomMSISDN}}@mailsac.com",
      "identityType": "OTHER",
      "identityNumber": "{{randomMSISDN}}",
      "firstName": "PAM",
      "middleName": "LOTTERY",
      "lastName": "PLATFORM",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "21{{randomMSISDN}}",
      "mobilePhone": "6951234567",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 404
    And match response errorId = OTP_VERIFICATION_NOT_FOUND
    And match response description = Otp verification not found. ([Error Id: OTP_VERIFICATION_NOT_FOUND])


  # Postman: "Register Player" (happy path)
  Scenario: Register Player
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And request
    """
    {
      "username": "pampla{{randomMSISDN}}",
      "password": "Qwerty12345!",
      "email": "pampla{{randomMSISDN}}@mailsac.com",
      "identityType": "OTHER",
      "identityNumber": "{{randomMSISDN}}",
      "firstName": "PAM",
      "middleName": "LOTTERY",
      "lastName": "PLATFORM",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "21{{randomMSISDN}}",
      "mobilePhone": "69{{randomMSISDN}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    And match response mobilePhone = 69{{randomMSISDN}}
    * def playerId in response.id
    * def username in response.username


  # Postman: "Create OTP Veriification - phoneNumber already verified"
  Scenario: Create OTP Verification - phoneNumber already verified
    Given path web/customer/rest/v1/otp
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"phoneNumber": "69{{randomMSISDN}}"}
    When method POST
    Then status 400
    And match response errorId = MOBILE_PHONE_NOT_FREE
    And match response description = Mobile phone number has already been registered in the system. ([Error Id: MOBILE_PHONE_NOT_FREE])
