@pam
@playerServices
@playerServiceBaseline
@baselineCc
Feature: Player service baseline - Cc

  # Converted from Postman collection player-service_access-token
  # folder: player-service-baseline > Cc
  # BackOffice surface: customer reads, status/account edits, verifications,
  # contracts, v2 patches and the v3 account-info edit. Postman reused the Web
  # folder's player and the Api folder's edits; this feature registers its own
  # player, so asserts that depended on those edits use this feature's state
  # (secret question from the registration helper, status descriptions set here).

  Background:
    Given url {{pam.boBaseUrl}}
    And header Content-Type = application/json
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}


  # Postman: "Login BO" + "Get time" + player setup. Email verification is a
  # precondition for the cc password-reset (EMAIL_NOT_VERIFIED otherwise).
  Scenario: Preparation - register player and BackOffice login
    * call feature features/PAM/playerServices/common/otpHelpers.feature
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Register temporary player
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Login BackOffice
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Verify registration email

    # One-time spec: the shared spec still carries the registration body after
    # the callees, and /cc/time rejects a GET with a body (400 Bad Request)
    Given set Url {{pam.boBaseUrl}}
    And add path /cc/time/rest/v1
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200


  # Postman: "Get customers" + "Get customer"
  Scenario: Get customers and specific customer
    Given path /cc/customer/rest/v1/customers
    When method GET
    Then status 200

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/customers/{{playerId}}
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $.loginName should be = {{username}}
    And check match path $.id should be = {{playerId}}


  # Postman: "Reset password non existing player" + "Reset password successful"
  Scenario: Reset player password
    Given path /cc/customer/rest/v1/customers/111111111/password-reset
    And request {"oldPassword": "Qwerty12345!", "newPassword": "Qwerty12345!!"}
    When method POST
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND
    And match response description = Player 111111111 does not exist ([Error Id: PLAYER_NOT_FOUND])

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/customers/{{playerId}}/password-reset
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method POST
    Then check status 200 or 204


  # Postman: "Get non existing player status" + "Get player status"
  Scenario: Get player status from v1
    Given path /cc/customer/rest/v1/customers/111111111/status
    When method GET
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/customers/{{playerId}}/status
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $.playerStatus should be = ENABLED
    And check match path $.selfExcluded should be = false
    And check match path $.sessionBlocked should be = false


  # Postman: "Get / Edit customer account" + non existing variants
  Scenario: Get and edit customer account
    Given path /cc/customer/rest/v1/customers/111111111/customer-account
    When method GET
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/customers/{{playerId}}/customer-account
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $.status should be = ENABLED

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/customers/111111111/customer-account
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"status": "ENABLED", "statusDescription": "Player was enabled by admin"}
    When set method PUT
    Then check status 404

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/customers/{{playerId}}/customer-account
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"status": "ENABLED", "statusDescription": "Player was enabled by admin"}
    When set method PUT
    Then check status 200 or 204


  # Postman: contract agreement + levels + change history
  Scenario: Contract agreement, levels and change history
    Given path /cc/customer/rest/v1/players/111111111/contract-agreements/latest
    When method GET
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/111111111/player-levels
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 404

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/{{playerId}}/player-levels
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/{{playerId}}/change-history
    And add param dateFrom = 1999-02-25
    And add param dateTo = 2030-01-01
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200


  # Postman: verifications + documents reads
  Scenario: Verification and document reads
    Given path /cc/customer/rest/v1/players/111111111/pending-verifications
    When method GET
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/{{playerId}}/pending-verifications
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/{{playerId}}/documents
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/111111111/verifications
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 404

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/{{playerId}}/verifications
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/pending-verifications
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200


  # Postman: "Get contracts" + "Get non existing contract"
  Scenario: Contracts
    Given path /cc/customer/rest/v1/contracts
    When method GET
    Then status 200

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/contracts/189
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 404
    And check match path $.errorId should be = CONTRACT_NOT_FOUND


  # Postman: v2 player reads + patch
  Scenario: Get and patch players via v2
    Given path /cc/customer/rest/v2/players
    When method GET
    Then status 200

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/111111111
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 404

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/{{playerId}}
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $.id should be = {{playerId}}

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/111111111
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"identityType": "NATIONAL_ID", "identityNumber": "ΑΚ{{regId}}", "firstName": "JOHN", "lastName": "STAMOS", "middleName": "STAMOU"}
    When set method POST
    Then check status 404

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/{{playerId}}
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"identityType": "NATIONAL_ID", "identityNumber": "ΑΚ{{regId}}", "firstName": "JOHN", "lastName": "STAMOS", "middleName": "STAMOU"}
    When set method POST
    Then check status 200
    And check match path $.id should be = {{playerId}}


  # Postman: v2 email patches
  Scenario: Patch player email via v2
    Given path /cc/customer/rest/v2/players/111111111/email
    And request {"email": "newcc{{regId}}@email.com"}
    When method PUT
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/{{playerId}}/email
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"email": "newcc{{regId}}@email.com"}
    When set method PUT
    Then check status 200
    And check match path $.id should be = {{playerId}}

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/{{playerId}}/email
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"email": "newcc{{regId}}@email.com"}
    When set method PUT
    Then check status 400
    And check match path $.errorId should be = EMAIL_NOT_FREE

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/{{playerId}}/email
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"email": ""}
    When set method PUT
    Then check status 400
    And check match path $.errorId should be = PROPERTY_NOT_FOUND


  # Postman: "Get player's secret question" (+ non existing) — values from the
  # registration helper, not Postman's Api-folder edit
  Scenario: Get player secret question
    Given path /cc/customer/rest/v2/players/111111111/secret-question
    When method GET
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/{{playerId}}/secret-question
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $.secretQuestion should be = What is your name?


  # Postman: "Get account actions" + "Edit Player's Account Info (cc/v3/players)"
  Scenario: Account actions and v3 account info edit
    Given path /cc/customer/rest/v2/players/account-actions
    When method GET
    Then status 200

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v3/players/{{playerId}}
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"dateOfBirth": "1970-09-29", "favoriteTeam": "FT_EMPTY", "identityExpirationDate": "2044-02-25", "permanentResidenceCountry": "BGR", "identityIssuedCountry": "BGR", "identityNumberEn": "CC{{regId}}"}
    When set method POST
    Then check status 200
    And check match path $.permanentResidenceCountry should be = BGR
    And check match path $.identityIssuedCountry should be = BGR
    And check match path $.identityExpirationDate should be = 2044-02-25
    And check match path $.id should be = {{playerId}}


  # Postman: "Get non existing player's status" + "Get / Change player's status"
  # Last step: disabling the player ends its usability.
  Scenario: Get and change player status via v2
    Given path /cc/customer/rest/v2/players/111111111/status
    When method GET
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/{{playerId}}/status
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $.status should be = ENABLED
    And check match path $.statusDescription should be = Player was enabled by admin

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/111111111/status
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"status": "DISABLED", "statusReason": "SELF_EXCLUSION_BY_ADMIN", "statusDescription": "Self exclusion by player request"}
    When set method PUT
    Then check status 404

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/{{playerId}}/status
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"status": "DISABLED", "statusReason": "SELF_EXCLUSION_BY_ADMIN", "statusDescription": "Self exclusion by player request"}
    When set method PUT
    Then check status 200
    And check match path $.status should be = DISABLED
    And check match path $.statusReason should be = SELF_EXCLUSION_BY_ADMIN
