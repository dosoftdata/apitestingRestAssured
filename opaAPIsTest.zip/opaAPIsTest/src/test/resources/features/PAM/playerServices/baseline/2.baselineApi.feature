@pam
@playerServices
@playerServiceBaseline
@baselineApi
Feature: Player service baseline - Api

  # Converted from Postman collection player-service_access-token
  # folder: player-service-baseline > Api
  # The /api surface with a client-credentials bearer token: customer creation
  # validations, reads/edits, password management, verifications, levels,
  # exclusions and segments. Postman reused the Web folder's player; this
  # feature registers its own (password chain: Qwerty12345! -> Qwerty12345!!).
  # Postman's "empty status/currency" requests duplicated the invalid bodies
  # verbatim (copy-paste) and are not converted separately.

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json
    And header Authorization = Bearer {{api_access_token}}


  # Postman: "Get Bearer Token" (client credentials) + OTP preparation
  Scenario: Preparation - api token and verified OTP
    * call feature features/PAM/playerServices/common/otpHelpers.feature
    Given url {{pam.webBaseUrl}}
    And path /api/access/oidc/token
    And header Content-Type = application/x-www-form-urlencoded
    And header Authorization = Basic {{pam.basic_auth}}
    And request grant_type=client_credentials
    When method POST
    Then status 200
    * def api_access_token in response.access_token


  # Postman: "Add player_empty_password" — no Postman assertions
  Scenario: Add player - empty password
    Given path /api/customer/rest/v1/customers
    And request
    """
    { "loginName": "DemoUser", "password": "", "ssn": "000000000000", "identityType": "SSN", "firstName": "JOHN", "middleName": "DUKE", "lastName": "WAYNE", "email": "demo@example.com", "status": "ENABLED", "country": "US", "state": "MA", "city": "Boston", "address1": "Silverlane 201", "address2": "Silverlane 202", "zip": "20113", "phone": "+01 848 4568 157", "mobilePhone": "+01 848 4568 152", "timeZone": "CET", "language": "EN", "currency": "USD", "sex": "M", "nationality": "US", "taxRegion": "MA", "taxCountry": "US", "secretQuestion": "What is the name of your pet?", "secretAnswer": "Beowulf", "dateOfBirth": "1970-01-01", "accountNumber": "ES9121000418450200051332", "bankType": "IBAN", "serviceProviderId": "SEPA", "direction": 1, "paymentMethodType": 2, "paymentMethodId": "DEFAULT_OUT", "paymentMethodStatus": 2 }
    """
    When method POST
    Then status 400


  # Postman: "Add player_*" requests without an OTP in the body
  Scenario Outline: Add player - <case>
    Given path /api/customer/rest/v1/customers
    And request
    """
    { "loginName": "DemoUser", "password": "<password>", "ssn": "<ssn>", "identityType": "<identityType>", "firstName": "JOHN", "middleName": "DUKE", "lastName": "WAYNE", "email": "demo@example.com", "status": "ENABLED", "country": "<country>", "state": "MA", "city": "Boston", "address1": "Silverlane 201", "address2": "Silverlane 202", "zip": "<zip>", "phone": "<phone>", "mobilePhone": "+01 848 4568 152", "timeZone": "CET", "language": "EN", "currency": "USD", "sex": "M", "nationality": "US", "taxRegion": "MA", "taxCountry": "US", "secretQuestion": "What is the name of your pet?", "secretAnswer": "Beowulf", "dateOfBirth": "<dateOfBirth>", "accountNumber": "ES9121000418450200051332", "bankType": "IBAN", "serviceProviderId": "SEPA", "direction": 1, "paymentMethodType": 2, "paymentMethodId": "DEFAULT_OUT", "paymentMethodStatus": 2 }
    """
    When method POST
    Then status 400
    And match response errorId = <errorId>
    And match response description = <description>

    Examples:
      | case                     | password     | ssn          | identityType | country | zip   | phone             | dateOfBirth | errorId                             | description                                                                                            |
      | insufficient password    | 1234567890   | 000000000000 | SSN          | US      | 20113 | +01 848 4568 157  | 1970-01-01  | INSUFFICIENT_CHARACTER_CATEGORIES   | Password includes insufficient number of character types ([Error Id: INSUFFICIENT_CHARACTER_CATEGORIES]) |
      | invalid identity type    | Qwerty12345! | 000000000000 | SSN          | US      | 20113 | +01 848 4568 157  | 2010-01-01  | IDENTITY_NUMBER_VALIDATOR_NOT_FOUND | Invalid identity-type. No validator to handle the type SSN ([Error Id: IDENTITY_NUMBER_VALIDATOR_NOT_FOUND]) |
      | empty identity type      | Qwerty12345! | 000000000000 |              | US      | 20113 | +01 848 4568 157  | 2010-01-01  | IDENTITY_TYPE_MISSING_EXCEPTION     | identity type information is missing. ([Error Id: IDENTITY_TYPE_MISSING_EXCEPTION])                     |
      | invalid identity number  | Qwerty12345! | 000000000000 | NATIONAL_ID  | US      | 20113 | +01 848 4568 157  | 1970-01-01  | IDENTITY_NUMBER_INVALID_PATTERN     | identity-number contains an invalid pattern. ([Error Id: IDENTITY_NUMBER_INVALID_PATTERN])              |
      | empty identity number    | Qwerty12345! |              | NATIONAL_ID  | US      | 20113 | +01 848 4568 157  | 1970-01-01  | IDENTITY_NUMBER_EXCEPTION           | Identity Number information is missing. ([Error Id: IDENTITY_NUMBER_EXCEPTION])                        |
      | unsupported country code | Qwerty12345! | AK088416     | NATIONAL_ID  | US      | 20113 | +01 848 4568 157  | 1970-01-01  | UNSUPPORTED_COUNTRY_CODE            | The provided country code is not supported ([Error Id: UNSUPPORTED_COUNTRY_CODE])                       |
      | empty country code       | Qwerty12345! | AK088416     | NATIONAL_ID  |         | 20113 | +01 848 4568 157  | 1970-01-01  | PROPERTY_NOT_FOUND                  | Required property COUNTRY was not found. ([Error Id: PROPERTY_NOT_FOUND])                              |
      | invalid zip code         | Qwerty12345! | AK088416     | NATIONAL_ID  | GR      | 20113 | +01 848 4568 157  | 1970-01-01  | ZIP_DOES_NOT_EXIST                  | Zip code does not exist: 20113 ([Error Id: ZIP_DOES_NOT_EXIST])                                        |
      | empty zip code           | Qwerty12345! | AK088416     | NATIONAL_ID  | GR      |       | +01 848 4568 157  | 1970-01-01  | PROPERTY_NOT_FOUND                  | Required property ZIP was not found. ([Error Id: PROPERTY_NOT_FOUND])                                  |
      | invalid land number      | Qwerty12345! | AK088416     | NATIONAL_ID  | GR      | 15125 | +01 848 4568 157  | 1970-01-01  | INVALID_LAND_PHONE_PATTERN          | Invalid land phone pattern ([Error Id: INVALID_LAND_PHONE_PATTERN])                                    |


  # Postman: "Add player_*" requests carrying the verified otpUuid
  Scenario Outline: Add player with otp - <case>
    Given path /api/customer/rest/v1/customers
    And request
    """
    { "loginName": "DemoUser", "password": "Qwerty12345!", "ssn": "AK088416", "identityType": "NATIONAL_ID", "firstName": "JOHN", "middleName": "DUKE", "lastName": "WAYNE", "email": "testapiraml@mailsac.com", "status": <status>, "country": "<country>", "state": "MA", "city": "Boston", "address1": "Silverlane 201", "address2": "Silverlane 202", "zip": "15125", "phone": "2101987365", "mobilePhone": "<mobilePhone>", "timeZone": "CET", "language": "EN", "currency": <currency>, "sex": "<sex>", "nationality": "US", "taxRegion": "MA", "taxCountry": "US", "secretQuestion": "What is the name of your pet?", "secretAnswer": "Beowulf", "dateOfBirth": "<dateOfBirth>", "accountNumber": "ES9121000418450200051332", "bankType": "IBAN", "serviceProviderId": "SEPA", "direction": 1, "paymentMethodType": 2, "paymentMethodId": "DEFAULT_OUT", "paymentMethodStatus": 2, "otpUuid": "{{otpUuid}}" }
    """
    When method POST
    Then status <httpStatus>
    And match response errorId = <errorId>

    Examples:
      | case                  | mobilePhone      | sex  | status    | country | currency | dateOfBirth | httpStatus | errorId                       |
      | invalid mobile number | +01 848 4568 152 | M    | "ENABLED" | GR      | "USD"    | 1970-01-01  | 404        | OTP_VERIFICATION_NOT_FOUND    |
      | empty mobile number   |                  | M    | "ENABLED" | GR      | "USD"    | 1970-01-01  | 400        | PASSWORD_MOBILE_PHONE_MISSING |
      | invalid contract      | 69{{msisdn}}     | M    | "ENABLED" | GR      | "USD"    | 1970-01-01  | 400        | INVALID_CONTRACT              |
      | wrong gender          | 69{{msisdn}}     | Male | "ENABLED" | GR      | "USD"    | 1970-01-01  | 400        | UNSUPPORTED_GENDER            |
      | empty gender          | 69{{msisdn}}     |      | "ENABLED" | GR      | "USD"    | 1970-01-01  | 400        | PROPERTY_NOT_FOUND            |
      | invalid status        | 69{{msisdn}}     | M    | "test"    | GR      | "USD"    | 1970-01-01  | 400        | INVALID_JSON                  |
      | invalid country       | 69{{msisdn}}     | M    | "ENABLED" | Greece  | "USD"    | 1970-01-01  | 400        | INVALID_COUNTRY_CODE          |
      | empty country         | 69{{msisdn}}     | M    | "ENABLED" |         | "USD"    | 1970-01-01  | 400        | PROPERTY_NOT_FOUND            |
      | invalid currency      | 69{{msisdn}}     | M    | "ENABLED" | GR      | "test"   | 1970-01-01  | 400        | INVALID_JSON                  |
      | invalid date of birth | 69{{msisdn}}     | M    | "ENABLED" | GR      | "USD"    | 01-01-1970  | 400        | INVALID_JSON                  |
      | not allowed birthdate | 69{{msisdn}}     | M    | "ENABLED" | GR      | "USD"    | 2010-01-01  | 400        | INVALID_AGE                   |
      | empty date of birth   | 69{{msisdn}}     | M    | "ENABLED" | GR      | "USD"    |             | 400        | VALIDATION_ERROR              |


  # Register this feature's own player (Postman reused the Web folder's testprlbas)
  Scenario: Preparation - register player and verify email
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Register temporary player
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Login BackOffice
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Verify registration email


  # Postman: "Get non existing player" + "Get player"
  Scenario: Get player and non existing player
    Given path /api/customer/rest/v1/customers/111111111
    When method GET
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND
    And match response description = Player 111111111 does not exist ([Error Id: PLAYER_NOT_FOUND])

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/customers/{{playerId}}
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    When set method GET
    Then check status 200
    And check match path $.loginName should be = {{username}}
    And check match path $.id should be = {{playerId}}


  # Postman: "Edit non existing player" + "Edit player" (sets new mobile + secret question)
  Scenario: Edit player and non existing player
    Given def editedMobile = random 8 digits
    Given path /api/customer/rest/v1/customers/111111111
    And request
    """
    { "loginName": "johnstamos", "status": "ENABLED", "statusDescription": "Player was enabled by something", "statusDate": "1970-01-01T00:00:00.000+0000", "ssn": "123456789", "identityType": "SSN", "firstName": "John", "middleName": "S.", "lastName": "Stamos", "email": "john@stamos.com", "country": "US", "state": "CA", "city": "LA", "address1": "First address 0011", "address2": "Second address 0011", "zip": "15124", "phone": "65-48-546843", "mobilePhone": "65-48-546844", "timeZone": "GMT", "language": "EN", "currency": "USD", "sex": "M", "nationality": "US", "taxRegion": "US", "taxCountry": "US", "secretQuestion": "What is the name of your pet?", "secretAnswer": "Beowulf", "dateOfBirth": "1989-09-27" }
    """
    When method PUT
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/customers/{{playerId}}
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    And add request
    """
    { "loginName": "johnstamos", "status": "ENABLED", "statusDescription": "Player was enabled by something", "statusDate": "1970-01-01T00:00:00.000+0000", "ssn": "123456789", "identityType": "SSN", "firstName": "JOHN", "middleName": "STAMOU", "lastName": "STAMOS", "email": "john{{regId}}@mailsac.com", "country": "GR", "state": "CA", "city": "LA", "address1": "First address 0011", "address2": "Second address 0011", "zip": "15124", "phone": "2104845896", "mobilePhone": "69{{editedMobile}}", "timeZone": "GMT", "language": "EN", "currency": "USD", "sex": "M", "nationality": "US", "taxRegion": "US", "taxCountry": "US", "secretQuestion": "What is the name of your pet?", "secretAnswer": "Beowulf", "dateOfBirth": "1989-09-27" }
    """
    When set method PUT
    Then check status 200 or 204


  # Postman: "Change password ..." chain. Current password is Qwerty12345! (helper
  # registration); Postman's bodies are adapted to this feature's own state.
  Scenario Outline: Change password - <case>
    Given path /api/customer/rest/v1/customers/<player>/password
    And request {"oldPassword": "<oldPassword>", "newPassword": "<newPassword>"}
    When method PUT
    Then status <status>
    And match response errorId = <errorId>

    Examples:
      | case                | player       | oldPassword     | newPassword   | status | errorId                           |
      | non existing player | 111111111    | Qwerty12345!    | Qwerty12345!! | 404    | PLAYER_NOT_FOUND                  |
      | wrong old password  | {{playerId}} | Qwerty12345!!!  | Qwerty12345!! | 403    | INVALID_PASSWORD                  |
      | same password       | {{playerId}} | Qwerty12345!    | Qwerty12345!  | 400    | NEW_PASSWORD_SAME_AS_OLD_PASSWORD |
      | empty new password  | {{playerId}} | Qwerty12345!!   |               | 403    | INVALID_PASSWORD                  |

  # Postman: "Change password missing email" — the successful change
  Scenario: Change password successfully
    Given path /api/customer/rest/v1/customers/{{playerId}}/password
    And request {"oldPassword": "Qwerty12345!", "newPassword": "Qwerty12345!!"}
    When method PUT
    Then status 200 or 204


  # Postman: "Get player's verifications" + non existing + add variants
  Scenario: Player verifications
    Given path /api/customer/rest/v1/customers/111111111/verifications
    When method GET
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/customers/{{playerId}}/verifications
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    When set method GET
    Then check status 200

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/customers/{{playerId}}/verifications
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    And add request {"verificationType": "EMAIL", "data": "pampla{{regId}}@mailsac.com"}
    When set method POST
    Then check status 400
    And check match path $.errorId should be = EMAIL_NOT_FREE

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/customers/{{playerId}}/verifications
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    And add request {"verificationType": "", "data": "newmail{{regId}}@mailsac.com"}
    When set method POST
    Then check status 404
    And check match path $.errorId should be = VERIFICATION_UNAVAILABLE

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/customers/{{playerId}}/verifications
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    And add request {"verificationType": "EMAIL", "data": "newmail{{regId}}@mailsac.com"}
    When set method POST
    Then check status 200 or 204


  # Postman: "Check non existing / player's password - success / failed"
  Scenario: Check player password
    Given path /api/customer/rest/v1/customers/username/password/check
    And request {"password": "Qwerty12345!"}
    When method POST
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/customers/{{username}}/password/check
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    And add request {"password": "Qwerty12345!!"}
    When set method POST
    Then check status 200
    And check match path $.result should be = SUCCESS
    And check match path $.customerId should be = {{playerId}}

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/customers/{{username}}/password/check
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    And add request {"password": "Qwerty12345!!!!"}
    When set method POST
    Then check status 200
    And check match path $.result should be = INVALID_PASSWORD


  # Postman: "Check / Update player's level" + non existing variants
  Scenario: Player levels
    Given path /api/customer/rest/v1/players/111111111/player-levels
    When method GET
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/players/{{playerId}}/player-levels
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    When set method GET
    Then check status 200
    And check match path $.playerLevel should be = TEMPORARY_ACCOUNT

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/players/111111111/player-levels
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    When set method PUT
    Then check status 404

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/players/{{playerId}}/player-levels
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    When set method PUT
    Then check status 200 or 204


  # Postman: "Check player's audit" + exclusions + segments
  Scenario: Audit, exclusions and segments
    Given path /api/customer/rest/v1/players/{{playerId}}/player-audit
    And param dateFrom = 1999-02-25
    And param dateTo = 2030-01-01
    When method GET
    Then status 200

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/exclusions
    And set header Authorization = Bearer {{api_access_token}}
    When set method GET
    Then check status 200

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/exclusions
    And add param exclusionType = Test
    And set header Authorization = Bearer {{api_access_token}}
    When set method GET
    Then check status 400
    And check match path $.errorId should be = UNSUPPORTED_EXCLUSION_TYPE

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/exclusions
    And add param identityType = Test
    And set header Authorization = Bearer {{api_access_token}}
    When set method GET
    Then check status 400
    And check match path $.errorId should be = UNSUPPORTED_IDENTITY_TYPE

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/segments/ACTIVE_PLAYERS/recipients
    And set header Authorization = Bearer {{api_access_token}}
    When set method GET
    Then check status 200

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/segments/TEST/recipients
    And set header Authorization = Bearer {{api_access_token}}
    When set method GET
    Then check status 404
    And check match path $.errorId should be = UNSUPPORTED_SEGMENT


  # Postman: v2 player reads (by id, by mobile)
  Scenario: Get players via v2
    Given path /api/customer/rest/v2/players/111111111
    When method GET
    Then status 404
    And match response errorId = PLAYER_NOT_FOUND

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v2/players
    And add param mobileNumber = 69{{editedMobile}}
    And set header Authorization = Bearer {{api_access_token}}
    When set method GET
    Then check status 200
    And check match path $[0].id should be = {{playerId}}

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v2/players/{{playerId}}
    And set header Authorization = Bearer {{api_access_token}}
    When set method GET
    Then check status 200
    And check match path $.id should be = {{playerId}}
