@helper
Feature: Player services helpers - identity verification

  # Callees for `call feature` — not meant to run standalone (no suite tags).
  # All scenarios require: {{playerId}}, {{web-x-csrftoken}}, {{x-csrftoken}} (BO),
  # {{token_type}}/{{access_token}} (player OIDC login).

  # Uploads src/test/resources/files/image.jpg as the given document type.
  # args: docType (e.g. ID_FRONT, PASSPORT, SOLEMN_DECLARATION, UTILITY_BILL)
  Scenario: Upload identity document
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1/players/{{playerId}}/documents
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And header Content-Type = multipart/form-data
    And form field fileName = image.jpg
    And form field type = {{docType}}
    And form field file = image.jpg
    And multipart file file path src/test/resources/files/image.jpg mimeType image/jpeg
    When method POST
    Then status 200
    And match response type = {{docType}}
    And match response fileName = image.jpg
    And match response fileType = image/jpeg
    And match response playerId = {{playerId}}
    And match response updatedByUserType = 1
    And match response updatedByUserId = {{playerId}}

  # Uploads src/test/resources/files/image.jpg as the given document type via
  # the BackOffice (cc) endpoint — requires {{x-csrftoken}} from Login BackOffice.
  # args: docType
  Scenario: Upload identity document via cc
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/documents
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And header Content-Type = multipart/form-data
    And form field fileName = image.jpg
    And form field type = {{docType}}
    And form field file = image.jpg
    And multipart file file path src/test/resources/files/image.jpg mimeType image/jpeg
    When method POST
    Then status 200
    And match response type = {{docType}}
    And match response fileName = image.jpg
    And match response fileType = image/jpeg
    And match response playerId = {{playerId}}
    And match response updatedByUserType = 3
    And match response updatedByUserId = 1

  # Approves one uploaded document of the player's IDENTITY verification.
  # args: approveDocumentId, approveDocType — requires {{ID_verification_ID}}
  Scenario: Approve identity document
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/verification-documents/approve
    And header Content-Type = application/json
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And request {"verificationId": {{ID_verification_ID}}, "verificationType": "IDENTITY", "documentId": {{approveDocumentId}}, "statusDescription": "Approve uploaded document for ID"}
    When method POST
    Then status 200
    And match response verificationType = IDENTITY
    And match response documentType = {{approveDocType}}
    And match response statusDescription = Approve uploaded document for ID
    And match response status = APPROVED

  # Identity confirm before any documents are in WAITING_ADMIN_APPROVAL
  Scenario: Confirm identity - pending not found
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/verifications/confirm
    And header Content-Type = application/json
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And request {"id": {{ID_verification_ID}}, "verificationType": "IDENTITY"}
    When method POST
    And match response errorId = PENDING_NOT_FOUND
    And match response description = Pending verification not found ([Error Id: PENDING_NOT_FOUND])

  # Identity confirm while some required documents are still unapproved
  Scenario: Confirm identity - not all documents approved
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/verifications/confirm
    And header Content-Type = application/json
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And request {"id": {{ID_verification_ID}}, "verificationType": "IDENTITY"}
    When method POST
    And match response errorId = NOT_ALL_DOCUMENTS_APPROVED
    And match response description = Not all sufficient documents have been approved to verify ([Error Id: NOT_ALL_DOCUMENTS_APPROVED])

  # Final identity confirm once every required document is approved
  Scenario: Confirm identity - verified
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/verifications/confirm
    And header Content-Type = application/json
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And request {"id": {{ID_verification_ID}}, "verificationType": "IDENTITY"}
    When method POST
    Then status 200
    And match response verificationType = IDENTITY
    And match response status = VERIFIED
