@pam
@playerServices
@documentUpload
@documentUploadWeb
Feature: Document Upload Web

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Document Upload Web
  # Player uploads verification documents of every supported file type via the
  # web API; uploads are visible from both cc and web document endpoints.
  # Postman used fixed player data (testuploaddocs/6952220123) — replaced with
  # fresh random data so the feature is re-runnable on a persistent env.

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  # Postman: "Create OTP Verification" + "Verify OTP Code" + "Register Player 1" + "Login BO"
  Scenario: Preparation - register player and BackOffice login
    * call feature features/PAM/playerServices/common/otpHelpers.feature
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Register temporary player
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Login BackOffice


  # Postman: "Get mailId..." + "Get hash..." + "Verify Player's Email"
  Scenario: Verify registration email
    Given url {{pam.boBaseUrl}}
    And path /cc/communication/rest/v1/emails
    And param playerId = {{playerId}}
    And delay request 10000
    When method GET
    Then status 200
    And match response body path data should be hasSize 1
    And match path $.data[0].messageText should be = Απέχεις ένα βήμα από την ενεργοποίηση του λογαριασμού σου
    And match path $.data[0].origin should be = player
    And match path $.data[0].status should be = SENT
    * def mailHash in response.data[0].id

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/communication/rest/v1/emails/{hash_for_mail}
    And add pathParam hash_for_mail = {{mailHash}}
    When set method GET
    Then check status 200
    And check match path $.eventName should be = registrationWelcomeEvent.opaponline
    And check match path $.status should be = SENT
    * def response_body in response.$

    And extract string using &hash= with name hashId from body response
    And backoffice verify player's email with hash hashId


  # Postman: "Get Bearer Token (WEB)" + "Get Player Level" + "Get Player (UserInfo)"
  Scenario: Player login and account checks
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Get web bearer token

    Given url {{pam.webBaseUrl}}
    And path web/access/oidc/userinfo
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
    And match response username = {{username}}
    And match response id = {{playerId}}
    And match response playerLevel = TEMPORARY_ACCOUNT
    And match response optin = false
    And match response accountVerificationState = PENDING


  # Postman: "Add Player Tax information" + "Get Player Tax information"
  Scenario: Add and get player tax information
    Given path web/customer/rest/v1-opap/players/{{playerId}}/tax
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"taxNumber": "123456789", "streetAddress": "Street Address", "city": "City", "postalCode": "10431"}
    When method PUT
    Then status 200
    And match response taxNumber = 123456789
    And match response streetAddress = Street Address
    And match response city = City
    And match response postalCode = 10431
    And match response playerId = {{playerId}}

    Given set Url {{pam.webBaseUrl}}
    And add path web/customer/rest/v1-opap/players/{{playerId}}/tax
    And set header Authorization = {{token_type}} {{access_token}}
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header X-GAME-ID = JOKER
    When set method GET
    Then check status 200
    And check match path $.taxNumber should be = 123456789
    And check match path $.playerId should be = {{playerId}}


  # Postman: "Player Upload ID document (Non-existing type)"
  Scenario: Upload document - non-existing type
    Given path web/customer/rest/v1/players/{{playerId}}/documents
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And header Content-Type = multipart/form-data
    And form field fileName = image.jpg
    And form field type = OTHERS
    And form field file = image.jpg
    And multipart file file path src/test/resources/files/image.jpg mimeType image/jpeg
    When method POST
    Then status 400
    # Postman (2023) expected VALIDATION_ERROR; dev now returns a dedicated errorId
    And match response errorId = UNSUPPORTED_DOCUMENT_TYPE


  # Postman: "Player Upload ID document (Non-supported file type)"
  Scenario: Upload document - non-supported file type
    Given path web/customer/rest/v1/players/{{playerId}}/documents
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And header Content-Type = multipart/form-data
    And form field fileName = nonsupported_type.bat
    And form field type = OTHER
    And form field file = nonsupported_type.bat
    And multipart file file path src/test/resources/files/nonsupported_type.bat mimeType application/octet-stream
    When method POST
    Then status 400
    And match response errorId = INVALID_FILE_EXTENSION
    And match response description = Invalid file uploaded ([Error Id: INVALID_FILE_EXTENSION])


  # Postman: "Player Upload <TYPE> document (<ext>)" — 6 requests
  Scenario Outline: Upload <type> document (<ext>)
    Given path web/customer/rest/v1/players/{{playerId}}/documents
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And header Content-Type = multipart/form-data
    And form field fileName = <fileName>
    And form field type = <type>
    And form field file = <fileName>
    And multipart file file path src/test/resources/files/<fileName> mimeType <mimeType>
    When method POST
    Then status 200
    And match response type = <type>
    And match response fileName = <fileName>
    And match response fileType = <mimeType>
    And match response playerId = {{playerId}}
    And match response updatedByUserType = 1
    And match response updatedByUserId = {{playerId}}

    Examples:
      | type               | ext      | fileName  | mimeType        |
      | OTHER              | jpg/jpeg | image.jpg | image/jpeg      |
      | ID_FRONT           | tif/tiff | image.tif | image/tiff      |
      | ID_BACK            | pdf      | image.pdf | application/pdf |
      | PASSPORT           | bmp      | image.bmp | image/bmp       |
      | SOLEMN_DECLARATION | png      | image.png | image/png       |
      | UTILITY_BILL       | gif      | image.gif | image/gif       |


  # Postman: "Get uploaded documents (CC)" — cumulative per-upload GETs collapsed
  # into one final check of all six entries.
  Scenario: Get uploaded documents from cc
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/documents
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match response body path $ should be hasSize 6
    And match path $[?(@.fileName=='image.jpg')].fileType should be = image/jpeg
    And match path $[?(@.fileName=='image.tif')].fileType should be = image/tiff
    And match path $[?(@.fileName=='image.pdf')].fileType should be = application/pdf
    And match path $[?(@.fileName=='image.bmp')].fileType should be = image/bmp
    And match path $[?(@.fileName=='image.png')].fileType should be = image/png
    And match path $[?(@.fileName=='image.gif')].fileType should be = image/gif


  # Postman: "Get uploaded documents (WEB)" — verification documents all PENDING
  Scenario: Get verification documents from web
    Given path web/customer/rest/v1/players/{{playerId}}/verification-documents
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
    And match response body path $ should be hasSize 6
    And match response body path status should be everyItemContains PENDING
    And match response body path verificationType should be everyItemContains IDENTITY
