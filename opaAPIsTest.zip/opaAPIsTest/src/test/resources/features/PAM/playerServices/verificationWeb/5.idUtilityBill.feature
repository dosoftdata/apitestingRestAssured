@pam
@playerServices
@verificationWeb
@verifIdUtilityBill
Feature: Verification Process Web - NATIONAL_ID and UTILITY_BILL

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Verification_Process_Web > ID_UTILITY_BILL
  # Identity via ID_FRONT + ID_BACK plus a UTILITY_BILL address document
  # (no IBAN in the registration). Postman used fixed player data — replaced
  # with fresh random data.

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  Scenario: Preparation - register player and BackOffice login
    * call feature features/PAM/playerServices/common/otpHelpers.feature
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "NATIONAL_ID",
      "identityNumber": "ΑΚ{{regId}}",
      "firstName": "TEST",
      "middleName": "PLR",
      "lastName": "VER",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "21{{regId}}",
      "mobilePhone": "69{{msisdn}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "agentId": "101001",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    * def playerId in response.id
    * def username in response.username
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Login BackOffice

  Scenario: Preparation - verify registration email
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Verify registration email

  Scenario: Preparation - player OIDC login
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Get web bearer token
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1/players/{{playerId}}/player-levels
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
    And match response playerLevel = TEMPORARY_ACCOUNT


  # Postman: "Player Upload ID_FRONT document" + "Player Upload ID_BACK document"
  # One upload per scenario: two multipart callees in one scenario accumulate
  # form params on the shared spec (ArrayList cast error on the second POST).
  Scenario: Upload ID_FRONT document
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Upload identity document with args
      """
      { "docType": "ID_FRONT" }
      """

  Scenario: Upload ID_BACK document
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Upload identity document with args
      """
      { "docType": "ID_BACK" }
      """


  # Postman: "Get pending verifications documents (ID)" — identity still PENDING
  # because the address document is missing
  Scenario: Pending verifications - identity pending
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/pending-verifications
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match path $[?(@.verificationType=='MSISDN')].status should be = PENDING
    And match path $[?(@.verificationType=='IDENTITY')].status should be = PENDING
    * def ID_verification_ID in response.find { it.verificationType == 'IDENTITY' }.id


  # Postman: "Verify player's identity" — nothing in WAITING_ADMIN_APPROVAL yet
  Scenario: Confirm identity - pending not found
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Confirm identity - pending not found


  # Postman: "Player Upload UTILITY_BILL document"
  Scenario: Upload UTILITY_BILL document
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Upload identity document with args
      """
      { "docType": "UTILITY_BILL" }
      """


  # Postman: "Get uploaded documents" — capture the document ids for approval
  Scenario: Capture uploaded document ids
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/documents
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    * def idFrontDocId in response.find { it.type == 'ID_FRONT' }.id
    * def idBackDocId in response.find { it.type == 'ID_BACK' }.id
    * def addressDocId in response.find { it.type == 'UTILITY_BILL' }.id


  # Postman: alternating "Verify ID document" + "Verify player's identity" requests
  Scenario: Approve identity documents and verify identity
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Approve identity document with args
      """
      { "approveDocumentId": "{{idFrontDocId}}", "approveDocType": "ID_FRONT" }
      """
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Confirm identity - not all documents approved
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Approve identity document with args
      """
      { "approveDocumentId": "{{idBackDocId}}", "approveDocType": "ID_BACK" }
      """
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Confirm identity - not all documents approved
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Approve identity document with args
      """
      { "approveDocumentId": "{{addressDocId}}", "approveDocType": "UTILITY_BILL" }
      """
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Confirm identity - verified


  # Postman: "Get Player Level (Verified account)" — no Postman assertions
  Scenario: Get player level - verified
    Given path web/customer/rest/v1/players/{{playerId}}/player-levels
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
