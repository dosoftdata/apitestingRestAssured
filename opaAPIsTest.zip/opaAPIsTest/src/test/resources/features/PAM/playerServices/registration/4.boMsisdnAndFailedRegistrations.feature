@pam
@playerServices
@registration
@registrationChain
Feature: Registration Process - BO MSISDN change and failed registrations

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Registration_Process (post-AML chain):
  # Get BO Player Info / BO Update MSISDN / BO Resend OTP / Get BO Sms / OTP Try /
  # BO Pending Verifications / KYC MSISDN Status / Changes Tab +
  # Step validation email taken + FailedRegister_* one-offs.
  # Postman used fixed phones/identities — replaced with fresh random data.

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  Scenario: Preparation - register player, BackOffice login and email verification
    * call feature features/PAM/playerServices/common/otpHelpers.feature
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Register temporary player
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Login BackOffice
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Verify registration email


  # Postman: "Get BO Player Info"
  Scenario: Get BO player info - registered mobile phone
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v2/players/{{playerId}}
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match response mobilePhone = 69{{msisdn}}


  # Postman: "BO Update MSISDN" + "BO Resend OTP" + "Get BO Sms - OTP" +
  # "OTP Try - MSISDN Registration Verification Completed"
  Scenario: BackOffice changes the player MSISDN with SMS OTP confirmation
    Given def newMsisdn = random 8 digits
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v4/players/{{playerId}}/msisdn
    And header Content-Type = application/json
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And request {"msisdn": "69{{newMsisdn}}"}
    When method PUT
    Then status 200

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v4/players/{{playerId}}/msisdn
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"msisdn": "69{{newMsisdn}}", "requiredToSendOtpSms": true}
    When set method PUT
    Then check status 200

    # The OTP code is the 5th word of the SMS message text
    Given set Url {{pam.boBaseUrl}}
    And add path /cc/communication/rest/v1/sms
    And add param playerId = {{playerId}}
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add delay request 5000
    When set method GET
    Then check status 200
    And check match path $.data[0].origin should be = player
    * def OTP = word 4 of response.data[0].messageText

    Given set Url {{pam.webBaseUrl}}
    And add path web/customer/rest/v2/players/{{playerId}}/msisdn-register
    And set header Content-Type = application/json
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header X-GAME-ID = JOKER
    And add request {"msisdn": "69{{newMsisdn}}", "otp": "{{OTP}}"}
    When set method PUT
    Then check status 200


  # Postman: "Get BO Pending Verifications - MSISDN not pending"
  # Postman asserted an empty global list; on a persistent env other players'
  # MSISDNs are pending, so only the call itself is asserted here.
  Scenario: BO pending verifications query
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/pending-verifications
    And param verificationType = MSISDN
    And param status = PENDING
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200


  # Postman: "Get BO KYC MSISDN Status"
  Scenario: BO KYC MSISDN status is verified
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/verifications
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match path $[?(@.type=='MSISDN')].verification.status should be = VERIFIED
    And match path $[?(@.type=='MSISDN')].verification.value should be = 69{{newMsisdn}}
    And match path $[?(@.type=='MSISDN')].verification.metadata.alreadyVerified should be = false


  # Postman: "Get BO Changes Tab" (date range widened: their dateTo is in the past)
  Scenario: BO changes tab shows the MSISDN change
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/change-history
    And param dateFrom = 1999-02-25
    And param dateTo = 2030-01-01
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match path $[0].updates[0].field should be = mobilePhone
    And match path $[0].updates[0].fromValue should be = 69{{msisdn}}
    And match path $[0].updates[0].toValue should be = 69{{newMsisdn}}


  # Postman: "Step validation 1: email already taken" (email of the registered player)
  Scenario: Step validation - email already taken
    Given path web/customer/rest/v1-opap/players/registration-fields/validate
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"username": "user1234", "password": "testQwerty12!", "mobilePhone": "6947453444", "email": "pampla{{regId}}@mailsac.com", "promoCode": ""}
    When method POST
    Then status 200
    And match path $[?(@.fieldName=='email')].errorId should be = EMAIL_NOT_FREE


  # Postman: "FailedRegister_Empty_Form"
  Scenario: Failed registration - empty form
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "",
      "password": "",
      "email": "",
      "identityType": "",
      "identityNumber": "",
      "firstName": "",
      "middleName": "",
      "lastName": "",
      "gender": "",
      "dateOfBirth": "",
      "country": "",
      "city": "",
      "address1": "",
      "zip": "",
      "profession": "",
      "permanentResidenceCountry": "",
      "mobilePhone": "",
      "secretQuestion": "",
      "secretAnswer": "",
      "agentId": "",
      "ibanNumber": "",
      "commercialOptions": { "channels": [], "commercialBonus": false, "commercialComGroups": false },
      "otpUuid": ""
    }
    """
    When method POST
    Then status 400
    And match response errorId = VALIDATION_ERROR
    And match response description = Validation failed


  # Postman: Create OTP + Verify OTP + "EmptyMiddleName Success Registration"
  Scenario: Successful registration with empty middle name
    * call feature features/PAM/playerServices/common/otpHelpers.feature scenario Create and verify OTP
    Given def regId2 = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "pampla{{regId2}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId2}}@mailsac.com",
      "identityType": "PASSPORT",
      "identityNumber": "{{regId2}}",
      "firstName": "PLAYER",
      "middleName": "",
      "lastName": "SERVICE",
      "gender": "M",
      "dateOfBirth": "1968-01-01",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "mobilePhone": "69{{msisdn}}",
      "permanentResidenceCountry": "GRC",
      "secretQuestion": "What is your name?",
      "secretAnswer": "PlayerService",
      "agentId": "101001",
      "commercialOptions": { "channels": [], "commercialBonus": false, "commercialComGroups": false },
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    And match response username = pampla{{regId2}}


  # Postman: "FailedRegister_EmptyCountry" + "FailedRegister_NotSupportedCountry"
  # Postman sent these without an otpUuid; dev now validates the OTP before the
  # country, so each row needs a fresh verified OTP + matching mobile to reach
  # the country validation under test.
  Scenario Outline: Failed registration - <case>
    * call feature features/PAM/playerServices/common/otpHelpers.feature scenario Create and verify OTP
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "pamplafail{{regId2}}",
      "password": "Qwerty12345!",
      "email": "pamplafail{{regId2}}@mailsac.com",
      "identityType": "PASSPORT",
      "identityNumber": "623455954",
      "firstName": "PLAYER",
      "middleName": "OPAP",
      "lastName": "SERVICE",
      "gender": "M",
      "dateOfBirth": "1968-01-01",
      "country": "<country>",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "permanentResidenceCountry": "GRC",
      "mobilePhone": "69{{msisdn}}",
      "secretQuestion": "What is your name?",
      "secretAnswer": "PlayerService",
      "agentId": "101001",
      "ibanNumber": "{{pam.IBAN}}",
      "commercialOptions": { "channels": [], "commercialBonus": false, "commercialComGroups": false },
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 400
    And match response errorId = <errorId>
    And match response description = <description>

    Examples:
      | case                  | country | errorId                  | description                                                                        |
      | empty country         |         | PROPERTY_NOT_FOUND       | Required property COUNTRY was not found. ([Error Id: PROPERTY_NOT_FOUND])          |
      | not supported country | IT      | UNSUPPORTED_COUNTRY_CODE | The provided country code is not supported ([Error Id: UNSUPPORTED_COUNTRY_CODE]) |


  # Postman: Create OTP + Verify OTP + "FailedRegister_PlayerExistingMail"
  Scenario: Failed registration - existing email
    * call feature features/PAM/playerServices/common/otpHelpers.feature scenario Create and verify OTP
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "pamplamail{{regId2}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "PASSPORT",
      "identityNumber": "441788984",
      "firstName": "PLAYER",
      "middleName": "OPAP",
      "lastName": "EXISTINGEMAIL",
      "gender": "M",
      "dateOfBirth": "1968-01-01",
      "country": "GR",
      "city": "Athens",
      "address1": "Test 69",
      "zip": "15124",
      "permanentResidenceCountry": "GRC",
      "mobilePhone": "69{{msisdn}}",
      "secretQuestion": "What is your name?",
      "secretAnswer": "Player Service",
      "agentId": "101001",
      "ibanNumber": "{{pam.IBAN}}",
      "commercialOptions": { "channels": [], "commercialBonus": false, "commercialComGroups": false },
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 400
    And match response errorId = EMAIL_NOT_FREE
    And match response description = This email has already been registered in the system. ([Error Id: EMAIL_NOT_FREE])


  # Postman: "FailedRegister_NotSupportedIBAN" — valid but unsupported (non-supported bank)
  Scenario: Failed registration - not supported IBAN
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "pamplaiban{{regId2}}",
      "password": "Qwerty12345!",
      "email": "pamplaiban{{regId2}}@mailsac.com",
      "identityType": "PASSPORT",
      "identityNumber": "402658283",
      "firstName": "PLAYER",
      "middleName": "OPAP",
      "lastName": "NOTSUPPORTEDIBAN",
      "gender": "M",
      "dateOfBirth": "1968-01-01",
      "country": "GR",
      "city": "Athens",
      "address1": "Test 69",
      "zip": "15124",
      "permanentResidenceCountry": "GRC",
      "mobilePhone": "6985123087",
      "secretQuestion": "What is your name?",
      "secretAnswer": "Player Service",
      "agentId": "101001",
      "ibanNumber": "GR7201101250000000012300695",
      "commercialOptions": { "channels": [], "commercialBonus": false, "commercialComGroups": false }
    }
    """
    When method POST
    Then status 400
    And match response errorId = UNSUPPORTED_IBAN
    And match response description = Given IBAN is valid but not supported ([Error Id: UNSUPPORTED_IBAN])
