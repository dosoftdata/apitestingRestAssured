@pam
@playerServices
@registrationValidation
@validationStepTwo
Feature: Registration validation endpoint - step 2 - personal data

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Validation endpoint for player registration
  # subfolders: Step Validation 2: firstname / lastName / gender / date of birth / city / zip code / address
  # Postman asserted nothing on these requests; we assert that an error is
  # reported for the field under test. Field values kept verbatim from the
  # collection (including the author's quirky "test" as an empty birth date).

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  Scenario: Preparation - csrf token
    * call feature features/PAM/playerServices/common/otpHelpers.feature scenario Bootstrap csrf token


  # Postman: "Step validation 2: <case>" requests
  Scenario Outline: Step validation 2 - <case>
    Given path web/customer/rest/v1-opap/players/registration-fields/validate
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"firstName": "<firstName>", "lastName": "<lastName>", "gender": "<gender>", "dateOfBirth": "<dateOfBirth>", "city": "<city>", "zip": "<zip>", "address1": "<address1>"}
    When method POST
    Then status 200
    And match path $[?(@.fieldName=='<fieldName>')] should be exists

    Examples:
      | case                          | firstName                                 | lastName                                  | gender | dateOfBirth              | city                                      | zip   | address1                                                       | fieldName   |
      | empty firstname               |                                           | TEST                                      | M      | 1980-05-10T00:00:00.000Z | athens                                    | 18450 | test 1                                                         | firstName   |
      | number in firstname           | ΟΠ4Π                                      | TEST                                      | M      | 1980-05-10T00:00:00.000Z | athens                                    | 18450 | test 1                                                         | firstName   |
      | firstname invalid length      | TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTT | TEST                                      | M      | 1980-05-10T00:00:00.000Z | athens                                    | 18450 | test 1                                                         | firstName   |
      | wrong firstname format        | 43523452345234                            | TEST                                      | M      | 1980-05-10T00:00:00.000Z | athens                                    | 18450 | test 1                                                         | firstName   |
      | empty lastName                | TEST                                      |                                           | M      | 1980-05-10T00:00:00.000Z | athens                                    | 18450 | test 1                                                         | lastName    |
      | number in lastName            | TEST                                      | ΟΠ4Π                                      | M      | 1980-05-10T00:00:00.000Z | athens                                    | 18450 | test 1                                                         | lastName    |
      | lastName invalid length       | TEST                                      | TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTT | M      | 1980-05-10T00:00:00.000Z | athens                                    | 18450 | test 1                                                         | lastName    |
      | wrong lastname format         | TEST                                      | 152556589                                 | M      | 1980-05-10T00:00:00.000Z | athens                                    | 18450 | test 1                                                         | lastName    |
      | empty gender                  | TEST                                      | TEST                                      |        | 1980-05-10T00:00:00.000Z | athens                                    | 18450 | test 1                                                         | gender      |
      | unsupported gender            | TEST                                      | TEST                                      | test   | 1980-05-10T00:00:00.000Z | athens                                    | 18450 | test 1                                                         | gender      |
      | invalid birth date            | TEST                                      | TEST                                      | M      | test                     | athens                                    | 18450 | test 1                                                         | dateOfBirth |
      | age less than allowed         | TEST                                      | TEST                                      | M      | 2010-05-10               | athens                                    | 18450 | test 1                                                         | dateOfBirth |
      | age more than allowed         | TEST                                      | TEST                                      | M      | 1870-01-01               | athens                                    | 18450 | test 1                                                         | dateOfBirth |
      | wrong birth date format       | TEST                                      | TEST                                      | M      | 15-02-1980               | athens                                    | 18450 | test 1                                                         | dateOfBirth |
      | empty city                    | TEST                                      | TEST                                      | F      | 1999-09-01               |                                           | 18450 | test 1                                                         | city        |
      | invalid city format           | TEST                                      | TEST                                      | M      | 1999-01-01               | athens1                                   | 18450 | test 1                                                         | city        |
      | city only numbers             | TEST                                      | TEST                                      | M      | 1999-01-01               | 12455689                                  | 18450 | test 1                                                         | city        |
      | max city length               | TEST                                      | TEST                                      | M      | 1999-01-01               | testtesttestttttesttestesttteetstttesttes | 18450 | test 1                                                         | city        |
      | empty zip                     | TEST                                      | TEST                                      | F      | 1999-09-01               | Athens                                    |       | test 1                                                         | zip         |
      | invalid zip format            | TEST                                      | TEST                                      | M      | 1999-01-01               | athens                                    | abcde | test 1                                                         | zip         |
      | invalid zip length            | TEST                                      | TEST                                      | M      | 1999-01-01               | athens                                    | 123   | test 1                                                         | zip         |
      | invalid zip max length        | TEST                                      | TEST                                      | M      | 1999-01-01               | athens                                    | 123456 | test 1                                                        | zip         |
      | zip does not exist            | TEST                                      | TEST                                      | M      | 1999-01-01               | athens                                    | 12345 | test 1                                                         | zip         |
      | empty address                 | TEST                                      | TEST                                      | F      | 1999-09-01               | test                                      | 18450 |                                                                | address1    |
      | invalid address length        | TEST                                      | TEST                                      | M      | 1999-01-01               | athens                                    | 18450 | testtesttestttttesttestesttteetstttesttesttttesttesttesttestt | address1    |


  # Postman: "Register Player <case>" — the matching full registrations all fail
  Scenario Outline: Register player - <case>
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "testers",
      "password": "Qwerty12345!",
      "mobilePhone": "6973444364",
      "email": "testers@gmail.com",
      "identityType": "PASSPORT",
      "identityNumber": "126443123",
      "firstName": "<firstName>",
      "middleName": "PLAYER",
      "lastName": "<lastName>",
      "gender": "<gender>",
      "dateOfBirth": "<dateOfBirth>",
      "country": "GR",
      "city": "<city>",
      "address1": "<address1>",
      "zip": "<zip>",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "2101000123",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "testplayerservice",
      "ibanNumber": "{{pam.IBAN}}"
    }
    """
    When method POST
    Then status 400

    Examples:
      | case                    | firstName                                 | lastName                                  | gender | dateOfBirth | city                                      | zip    | address1                                                       |
      | empty firstname         |                                           | SERVICE                                   | M      | 1970-09-29  | Athens                                    | 15125  | First address 0100                                             |
      | number in firstname     | ΟΠ4Π                                      | SERVICE                                   | M      | 1970-09-29  | Athens                                    | 15125  | First address 0100                                             |
      | firstname invalid length| TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTT | SERVICE                                   | M      | 1970-09-29  | Athens                                    | 15125  | First address 0100                                             |
      | wrong firstname format  | 43523452345234                            | SERVICE                                   | M      | 1968-01-01  | Athens                                    | 15125  | First address 0100                                             |
      | empty lastName          | TEST                                      |                                           | M      | 1970-09-29  | Athens                                    | 15125  | First address 0100                                             |
      | number in lastName      | test                                      | ΟΠ4Π                                      | M      | 1970-09-29  | Athens                                    | 15125  | First address 0100                                             |
      | lastName invalid length | TEST                                      | TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTT | M      | 1970-09-29  | Athens                                    | 15125  | First address 0100                                             |
      | wrong lastname format   | PLAYER                                    | 152556589                                 | M      | 1968-01-01  | Athens                                    | 15125  | First address 0100                                             |
      | empty gender            | TEST                                      | TESTERS                                   |        | 1970-09-29  | Athens                                    | 15125  | First address 0100                                             |
      | unsupported gender      | TEST                                      | TESTERS                                   | test   | 1970-09-29  | Athens                                    | 15125  | First address 0100                                             |
      | empty birth date        | TEST                                      | TESTERS                                   | M      |             | Athens                                    | 15125  | First address 0100                                             |
      | invalid birth date      | TEST                                      | TESTERS                                   | M      | test        | Athens                                    | 15125  | First address 0100                                             |
      | age less than allowed   | TEST                                      | TESTERS                                   | M      | 2010-05-10  | Athens                                    | 15125  | First address 0100                                             |
      | age more than allowed   | PLAYER                                    | SERVICE                                   | M      | 1870-01-01  | Athens                                    | 15125  | First address 0100                                             |
      | wrong birth date format | PLAYER                                    | SERVICE                                   | M      | 15-02-1990  | Athens                                    | 15125  | First address 0100                                             |
      | empty city              | TEST                                      | TESTERS                                   | M      | 1999-09-01  |                                           | 15125  | First address 0100                                             |
      | invalid city            | TEST                                      | TESTERS                                   | M      | 1999-09-01  | Athens1                                   | 15125  | First address 0100                                             |
      | city only numbers       | PLAYER                                    | SERVICE                                   | M      | 1968-01-01  | 12455689                                  | 15125  | First address 0100                                             |
      | city invalid length     | PLAYER                                    | SERVICE                                   | M      | 1968-01-01  | testtesttestttttesttestesttteetstttesttes | 15125  | First address 0100                                             |
      | empty zip               | TEST                                      | TESTERS                                   | M      | 1999-09-01  | Athens                                    |        | First address 0100                                             |
      | invalid zip             | TEST                                      | TESTERS                                   | M      | 1999-09-01  | Athens                                    | abcde  | First address 0100                                             |
      | invalid zip length      | TEST                                      | TESTERS                                   | M      | 1999-09-01  | Athens                                    | 123    | First address 0100                                             |
      | invalid zip max length  | TEST                                      | TESTERS                                   | M      | 1999-09-01  | Athens                                    | 123456 | First address 0100                                             |
      | zip does not exist      | TEST                                      | TESTERS                                   | M      | 1999-09-01  | Athens                                    | 12345  | First address 0100                                             |
      | empty address           | TEST                                      | TESTERS                                   | M      | 1999-09-01  | Athens                                    | 15125  |                                                                |
      | invalid address length  | TEST                                      | TESTERS                                   | M      | 1999-09-01  | Athens                                    | 15125  | testtesttestttttesttestesttteetstttesttesttttesttesttesttestt |
