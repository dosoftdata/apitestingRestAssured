@helper
Feature: Player services helpers - player setup

  # Callees for `call feature` — not meant to run standalone (no suite tags).

  # Registers a temporary player on the phone captured by otpHelpers.feature
  # "Create and verify OTP" ({{msisdn}}/{{otpUuid}} must be set).
  # Captures {{playerId}} and {{username}}.
  Scenario: Register temporary player
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "OTHER",
      "identityNumber": "{{regId}}",
      "firstName": "PAM",
      "middleName": "LOTTERY",
      "lastName": "PLATFORM",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "21{{regId}}",
      "mobilePhone": "69{{msisdn}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    * def playerId in response.id
    * def username in response.username

  # BackOffice login (admin/admin) — captures {{x-csrftoken}} for /cc endpoints.
  # Body is raw (not the `backoffice login` step): FeatureCaller can only dispatch
  # glue registered in its GLUE_CLASSES (src/main dsl.actions), and the domain
  # stepDefs live in src/test, so they are not callable from a called feature.
  # One-time specs (set/add/check) on purpose: the first POST must carry NO
  # leftover csrf headers from the calling scenario — the BO csrf filter is a
  # double-submit check (header == cookie), so a stray matching web-token pair
  # makes it answer 204 WITHOUT issuing a csrftoken cookie, and the capture
  # below would come up empty. A clean spec deterministically gets 403 + cookie.
  Scenario: Login BackOffice
    Given set Url {{pam.boBaseUrl}}
    And add path /cc/access/rest/v1/sessions
    And set header Content-Type = application/json
    And add request {"loginName": "admin", "password": "admin"}
    When set method POST
    Then check status 403
    * Cookie x-csrftoken in response.csrftoken

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/access/rest/v1/sessions
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    And add request {"loginName": "admin", "password": "admin"}
    When set method POST
    Then check status 200 or 204

  # Verifies the registration email of {{playerId}}: reads the welcome mail via
  # the BO communication API, extracts the verification hash from the mail body
  # and posts it to the web email-verification endpoint. Raw steps only, so it
  # stays callable from called features.
  Scenario: Verify registration email
    Given url {{pam.boBaseUrl}}
    And path /cc/communication/rest/v1/emails
    And param playerId = {{playerId}}
    And delay request 10000
    When method GET
    Then status 200
    And match response body path data should be hasSize 1
    And match path $.data[0].origin should be = player
    And match path $.data[0].status should be = SENT
    * def mailHash in response.data[0].id

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/communication/rest/v1/emails/{{mailHash}}
    When set method GET
    Then check status 200
    * def hashId = response substring after &hash= length 36

    Given set Url {{pam.webBaseUrl}}
    And add path /web/customer/rest/v1/verifications/email
    And set header Content-Type = application/json
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And add request {"playerId": "{{playerId}}", "hash": "{{hashId}}"}
    When set method POST
    Then check status 204

  # Player OIDC password-grant login for {{username}} — captures {{token_type}}
  # and {{access_token}}, refreshes {{web-x-csrftoken}}. Includes the
  # mandatory-limits-set scope so /web/access/oidc/userinfo exposes that field.
  Scenario: Get web bearer token
    Given url {{pam.webBaseUrl}}
    And path /web/access/oidc/token
    And header Content-Type = application/json
    And header Authorization = Basic {{pam.basic_auth_widgets}}
    And header X-GAME-ID = JOKER
    And request
    """
    {
      "grant_type": "password",
      "username": "{{username}}",
      "password": "Qwerty12345!",
      "channel": "WEB",
      "group": "EP",
      "scope": "openid http://betware.com/oidc/scopes/session http://betware.com/oidc/scopes/mandatory-limits-set"
    }
    """
    When method POST
    Then status 200
    * def token_type in response.token_type
    * def access_token in response.access_token
    * Cookie web-x-csrftoken in response.csrftoken
