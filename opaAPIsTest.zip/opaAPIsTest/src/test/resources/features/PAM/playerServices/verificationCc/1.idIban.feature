@pam
@playerServices
@verificationCc
@verifCcIdIban
Feature: Verification Process CC - NATIONAL_ID and IBAN

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Verification_Process_CC > ID_IBAN
  # Same chain as the web variant but documents are uploaded by the BackOffice
  # user via /cc (updatedByUserType 3). Postman used fixed player data —
  # replaced with fresh random data.

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  Scenario: Preparation - register player and BackOffice login
    * call feature features/PAM/playerServices/common/otpHelpers.feature
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "NATIONAL_ID",
      "identityNumber": "ΑΚ{{regId}}",
      "firstName": "TEST",
      "middleName": "PLR",
      "lastName": "VER",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "21{{regId}}",
      "mobilePhone": "69{{msisdn}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "agentId": "101001",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    * def playerId in response.id
    * def username in response.username
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Login BackOffice

  Scenario: Preparation - verify registration email
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Verify registration email

  Scenario: Preparation - player OIDC login
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Get web bearer token
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1/players/{{playerId}}/player-levels
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
    And match response playerLevel = TEMPORARY_ACCOUNT


  # Postman: "Get pending verifications documents (IBAN)"
  Scenario: Pending verifications - MSISDN and IBAN pending
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/pending-verifications
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match path $[?(@.verificationType=='MSISDN')].status should be = PENDING
    And match path $[?(@.verificationType=='MSISDN')].value should be = 69{{msisdn}}
    And match path $[?(@.verificationType=='IBAN')].status should be = PENDING
    And match path $[?(@.verificationType=='IBAN')].value should be = {{pam.IBAN}}
    * def IBAN_verification_ID in response.find { it.verificationType == 'IBAN' }.id


  # Postman: "Get Bearer Token" (api, client credentials) + "Verify IBAN account"
  Scenario: Verify IBAN account
    Given url {{pam.webBaseUrl}}
    And path /api/access/oidc/token
    And header Content-Type = application/x-www-form-urlencoded
    And header Authorization = Basic {{pam.basic_auth}}
    And request grant_type=client_credentials
    When method POST
    Then status 200
    * def api_access_token in response.access_token

    Given set Url {{pam.webBaseUrl}}
    And add path /api/customer/rest/v1/customers/{{playerId}}/verifications/iban
    And set header Content-Type = application/json
    And set header Authorization = Bearer {{api_access_token}}
    And add request {"iban": "{{pam.IBAN}}", "id": {{IBAN_verification_ID}}}
    When set method POST
    Then check status 200 or 204


  # Postman: "CC Upload ID_FRONT document" + "CC Upload ID_BACK document"
  # One upload per scenario: two multipart callees in one scenario accumulate
  # form params on the shared spec (ArrayList cast error on the second POST).
  Scenario: CC upload ID_FRONT document
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Upload identity document via cc with args
      """
      { "docType": "ID_FRONT" }
      """

  Scenario: CC upload ID_BACK document
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Upload identity document via cc with args
      """
      { "docType": "ID_BACK" }
      """


  # Postman: "Get pending verifications documents (ID)" + "Get uploaded documents"
  Scenario: Pending verifications - identity waiting admin approval
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v1/players/{{playerId}}/pending-verifications
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match path $[?(@.verificationType=='IDENTITY')].status should be = WAITING_ADMIN_APPROVAL
    * def ID_verification_ID in response.find { it.verificationType == 'IDENTITY' }.id

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/{{playerId}}/documents
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    * def idFrontDocId in response.find { it.type == 'ID_FRONT' }.id
    * def idBackDocId in response.find { it.type == 'ID_BACK' }.id


  # Postman: alternating "Verify player's identity" + "Verify ID document" requests
  Scenario: Approve identity documents and verify identity
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Confirm identity - not all documents approved
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Approve identity document with args
      """
      { "approveDocumentId": "{{idFrontDocId}}", "approveDocType": "ID_FRONT" }
      """
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Confirm identity - not all documents approved
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Approve identity document with args
      """
      { "approveDocumentId": "{{idBackDocId}}", "approveDocType": "ID_BACK" }
      """
    * call feature features/PAM/playerServices/common/verificationHelpers.feature scenario Confirm identity - verified


  # Postman: "Get Player Level (Fully Verified account)" — no Postman assertions
  Scenario: Get player level - fully verified
    Given path web/customer/rest/v1/players/{{playerId}}/player-levels
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
