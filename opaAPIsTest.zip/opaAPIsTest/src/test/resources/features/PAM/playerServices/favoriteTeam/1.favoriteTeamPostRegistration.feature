@pam
@playerServices
@favoriteTeam
@favoriteTeamPostRegistration
Feature: Player favorite team - not provided during registration

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Player favorite team- Player has not provided his favorite team during registration
  # A registered player without a favorite team sets/clears it via PUT /players/me;
  # FT_EMPTY clears it, null leaves it unchanged.

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  # Postman precondition: env vars left by Registration_Process + BO session.
  # Here: register a fresh player (no favoriteTeam), BO login, verify email,
  # then player OIDC login (password grant is 403 until the email is verified).
  Scenario: Preparation - register player and BackOffice login
    * call feature features/PAM/playerServices/common/otpHelpers.feature
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Register temporary player
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Login BackOffice

  Scenario: Preparation - verify registration email
    Given url {{pam.boBaseUrl}}
    And path /cc/communication/rest/v1/emails
    And param playerId = {{playerId}}
    And delay request 10000
    When method GET
    Then status 200
    And match response body path data should be hasSize 1
    * def mailHash in response.data[0].id

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/communication/rest/v1/emails/{hash_for_mail}
    And add pathParam hash_for_mail = {{mailHash}}
    When set method GET
    Then check status 200
    * def response_body in response.$

    And extract string using &hash= with name hashId from body response
    And backoffice verify player's email with hash hashId

  Scenario: Preparation - player OIDC login
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Get web bearer token


  # Postman: "Get player info cc- favorite team does not exist"
  Scenario: Get player info cc - favorite team does not exist
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v2/players/{{playerId}}
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match response username = {{username}}
    And match response id = {{playerId}}
    And match path $.favoriteTeam should be = null


  # Postman: "Get Player Level (Temporary account)"
  Scenario: Get Player Level - temporary account
    Given path web/customer/rest/v1/players/{{playerId}}/player-levels
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
    And match response playerLevel = TEMPORARY_ACCOUNT


  # Postman: "Get Player (UserInfo)- player has not set his favorite team"
  Scenario: Get UserInfo - favorite team not present
    Given path web/access/oidc/userinfo
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
    And match path $.mandatory_limits_set should be exists
    And match path $.signedUser should be exists
    And match response username = {{username}}
    And match response id = {{playerId}}
    And match response playerLevel = TEMPORARY_ACCOUNT
    And match response optin = false
    And match response accountVerificationState = PENDING
    And match path $.favoriteTeam should be !exists


  # Postman: "Add Player Favorite Team - empty prefix / not underscore / not only
  # uppercase / invalid length / invalid character" (no explicit Postman asserts;
  # the API rejects values not matching FT_[A-Z]+ — verified live)
  Scenario Outline: Add Player Favorite Team - <case>
    Given path web/customer/rest/v1-opap/players/me
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"favoriteTeam": "<favoriteTeam>"}
    When method PUT
    Then status 400

    Examples:
      | case                          | favoriteTeam                        |
      | empty prefix                  | AEK                                 |
      | not underscore                | FTAEK                               |
      | not only uppercase characters | FT_aEk                              |
      | invalid length                | FT_AEKAKEKSLEKALSKALEKALSASESASFSES |
      | invalid character             | FT_AEK!                             |


  # Postman: "Add Player Favorite Team"
  Scenario: Add Player Favorite Team
    Given path web/customer/rest/v1-opap/players/me
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"favoriteTeam": "FT_AEK"}
    When method PUT
    Then status 200 or 204


  # Postman: "Get Player (UserInfo)- player has set his favorite team"
  Scenario: Get UserInfo - favorite team set
    Given path web/access/oidc/userinfo
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
    And match response username = {{username}}
    And match response id = {{playerId}}
    And match response playerLevel = TEMPORARY_ACCOUNT
    And match response favoriteTeam = FT_AEK


  # Postman: "Get player info cc- favorite team is included in response body"
  Scenario: Get player info cc - favorite team included
    Given url {{pam.boBaseUrl}}
    And path /cc/customer/rest/v2/players/{{playerId}}
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    When method GET
    Then status 200
    And match response username = {{username}}
    And match response id = {{playerId}}
    And match response favoriteTeam = FT_AEK


  # Postman: "Set player favorite team to null" + "...unchanged" checks
  Scenario: Set favorite team to null leaves it unchanged
    Given path web/customer/rest/v1-opap/players/me
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"favoriteTeam": null}
    When method PUT
    Then status 200 or 204

    # Postman: "Get Player (UserInfo)- player favorite team unchanged" (X-GAME-ID LOTTO)
    Given set Url {{pam.webBaseUrl}}
    And add path web/access/oidc/userinfo
    And set header Authorization = {{token_type}} {{access_token}}
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header X-GAME-ID = LOTTO
    When set method GET
    Then check status 200
    And check match path $.favoriteTeam should be = FT_AEK

    # Postman: "Get player info cc- favorite team unchanged"
    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/{{playerId}}
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $.favoriteTeam should be = FT_AEK


  # Postman: "Set player favorite team to FT_EMPTY" + cleared-state checks
  Scenario: Set favorite team to FT_EMPTY clears it
    Given path web/customer/rest/v1-opap/players/me
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"favoriteTeam": "FT_EMPTY"}
    When method PUT
    Then status 200 or 204

    # Postman: "Get Player (UserInfo)- player favorite team not included in response body" (X-GAME-ID SPORTSBOOK)
    Given set Url {{pam.webBaseUrl}}
    And add path web/access/oidc/userinfo
    And set header Authorization = {{token_type}} {{access_token}}
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header X-GAME-ID = SPORTSBOOK
    When set method GET
    Then check status 200
    And check match path $.favoriteTeam should be !exists

    # Postman: "Get player info cc- favorite team equal to null in response body"
    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v2/players/{{playerId}}
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $.favoriteTeam should be = null
