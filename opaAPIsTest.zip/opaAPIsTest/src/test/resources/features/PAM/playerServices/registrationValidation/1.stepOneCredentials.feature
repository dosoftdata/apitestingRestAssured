@pam
@playerServices
@registrationValidation
@validationStepOne
Feature: Registration validation endpoint - step 1 - credentials

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Validation endpoint for player registration
  # subfolders: Step Validation 1: username / password / mobile phone / email / promoCode
  # POST /players/registration-fields/validate answers 200 with a list of
  # [{fieldName, errorId}] entries. Postman asserted almost nothing on these
  # requests; we assert that an error is reported for the field under test.

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  Scenario: Preparation - csrf token
    * call feature features/PAM/playerServices/common/otpHelpers.feature scenario Bootstrap csrf token


  # Postman: "Step validation 1: <case>" requests
  Scenario Outline: Step validation 1 - <case>
    Given path web/customer/rest/v1-opap/players/registration-fields/validate
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"username": "<username>", "password": "<password>", "mobilePhone": "<mobilePhone>", "email": "<email>", "promoCode": ""}
    When method POST
    Then status 200
    And match path $[?(@.fieldName=='<fieldName>')] should be exists

    Examples:
      | case                           | username                   | password                  | mobilePhone | email                          | fieldName   |
      | empty username                 |                            | testQwerty12!             | 6947444444  | test@test.gr                   | username    |
      | too short username             | tes                        | testQwerty12              | 6947444444  | test@test.gr                   | username    |
      | invalid username chars         | τεστ                       | testQwerty12              | 6947444444  | test@test.gr                   | username    |
      | invalid username special chars | test123!                   | testQwerty12              | 6947444444  | test@test.gr                   | username    |
      | too long username              | thisisalongusername1245678 | testQwerty12              | 6947444444  | test@test.gr                   | username    |
      | wrong username format          | *^%./                      | testQwerty12              | 6947444444  | test@test.gr                   | username    |
      | empty password                 | test                       |                           | 6947444443  | test@test.gr                   | password    |
      | short password                 | tes5                       | testQwe                   | 6947444244  | test@test.gr                   | password    |
      | invalid password chars         | tes5                       | @$%^@$^@$^^@$%^@$%@$%@$   | 6947444244  | test@test.gr                   | password    |
      | password only numbers          | test                       | 1234567890                | 6947444442  | test@test.gr                   | password    |
      | password only uppercase        | thisisalongusername        | THISISAGREATTEST          | 6947442444  | test@test.gr                   | password    |
      | password only lowercase        | thisisalongusername        | thisisgreatest            | 6947442444  | test@test.gr                   | password    |
      | empty mobile phone             | username1234               | Qwerty12345!              |             | test@test.gr                   | mobilePhone |
      | string as mobile phone         | tes5                       | testQwe123!               | test        | tes5@test.gr                   | mobilePhone |
      | mobile not starting with 69    | tes5                       | testQwe123!               | 1111112222  | tes5@test.gr                   | mobilePhone |
      | mobile shorter than 10         | tes5                       | testQwe123!               | 698956550   | tes5@test.gr                   | mobilePhone |
      | mobile longer than 10          | tes5                       | testQwe123!               | 69895655063 | tes5@test.gr                   | mobilePhone |
      | empty email                    | username1234               | Qwerty12345!              | 6973444364  |                                | email       |
      | email invalid pattern          | username1234               | Qwerty12345!              | 6973444364  | test@test                      | email       |
      | email invalid                  | username1234               | Qwerty12345!              | 6973444364  | test@test.                     | email       |
      | email invalid chars            | username1234               | Qwerty12345!              | 6973444364  | ab(c)d,e:f;g<h>i[jk]l@test.com | email       |


  # Postman: "Register Player <case>" — the matching full registrations all fail
  Scenario Outline: Register player - <case>
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "<username>",
      "password": "<password>",
      "mobilePhone": "<mobilePhone>",
      "email": "<email>",
      "identityType": "PASSPORT",
      "identityNumber": "123123123",
      "firstName": "TEST",
      "middleName": "PLAYER",
      "lastName": "SERVICE",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "2101000123",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "testplayerservice",
      "ibanNumber": "{{pam.IBAN}}"
    }
    """
    When method POST
    Then status 400

    Examples:
      | case                           | username                   | password                | mobilePhone | email                          |
      | empty username                 |                            | testQwerty12            | 6947444444  | test@test.gr                   |
      | too short username             | tes                        | testQwerty12            | 6947444444  | test@test.gr                   |
      | invalid username chars         | τεστ                       | testQwerty12            | 6947444444  | test@test.gr                   |
      | invalid username special chars | test123!                   | testQwerty12            | 6947444444  | test@test.gr                   |
      | wrong username format          | *^%./                      | Qwerty12345!            | 6985660087  | testswronguserformat@test.gr   |
      | too long username              | thisisalongusername1245678 | testQwerty12            | 6947444444  | test@test.gr                   |
      | empty password                 | test                       |                         | 6947444433  | test@test.gr                   |
      | short password                 | tes5                       | testQwe                 | 6947444244  | test@test.gr                   |
      | invalid password chars         | tes5                       | @$%^@$^@$^^@$%^@$%@$%@$ | 6947444244  | test@test.gr                   |
      | password only numbers          | test                       | 1234567890              | 6947444442  | test@test.gr                   |
      | password only uppercase        | thisisalongusername        | THISISAGREATTEST        | 6947442444  | test@test.gr                   |
      | password only lowercase        | thisisalongusername        | thisisgreatest          | 6947442444  | test@test.gr                   |
      | empty mobile phone             | username1234               | Qwerty12345!            |             | username1234@test.gr           |
      | string as mobile phone         | tes5                       | tesQwe123!              | test        | tes5@test.gr                   |
      | mobile not starting with 69    | tes5                       | tesQwe123!              | 1111112222  | tes5@test.gr                   |
      | mobile shorter than 10         | tes5                       | tesQwe123!              | 698956550   | tes5@test.gr                   |
      | mobile longer than 10          | tes5                       | tesQwe123!              | 69895655063 | tes5@test.gr                   |
      | empty email                    | username1234               | Qwerty12345!            | 6973444364  |                                |
      | email invalid pattern          | username1234               | Qwerty12345!            | 6973444364  | test@test                      |
      | email invalid                  | username1234               | Qwerty12345!            | 6973444364  | test@test.                     |
      | email invalid chars            | username1234               | Qwerty12345!            | 6973444364  | ab(c)d,e:f;g<h>i[jk]l@test.com |


  # Postman: "Step validation 1: template 1/2 with/without promoCode" + "invalid promoCode"
  # The base password testQwerty12 lacks a special character, so the validator
  # reports INSUFFICIENT_CHARACTER_CATEGORIES on password in every variant.
  Scenario Outline: Step validation 1 - promoCode <case>
    Given path web/customer/rest/v1-opap/players/registration-fields/validate
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request <body>
    When method POST
    Then status 200
    And match path $[?(@.fieldName=='password')].errorId should be = INSUFFICIENT_CHARACTER_CATEGORIES

    Examples:
      | case                       | body                                                                                                                          |
      | template 1 without code    | {"username": "testusername", "password": "testQwerty12", "mobilePhone": "6947444444", "email": "test@test.gr"}                |
      | template 1 with valid code | {"username": "testusername", "password": "testQwerty12", "mobilePhone": "6947444444", "email": "test@test.gr", "promoCode": ""} |
      | template 2 without code    | {"username": "testusername", "password": "testQwerty12", "email": "test@test.gr"}                                             |
      | template 2 with valid code | {"username": "testusername", "password": "testQwerty12", "email": "test@test.gr", "promoCode": ""}                            |
      | invalid code               | {"username": "testusername", "password": "testQwerty12", "email": "test@test.gr", "promoCode": "abcd1234"}                    |


  # Postman: "Step validation 1: Valid registration" + OTP + "Register player valid"
  Scenario: Step validation 1 - valid data then successful registration
    * call feature features/PAM/playerServices/common/otpHelpers.feature scenario Create and verify OTP
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players/registration-fields/validate
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"username": "pampla{{regId}}", "password": "testQwerty12!", "mobilePhone": "69{{msisdn}}", "email": "pampla{{regId}}@test.gr", "promoCode": ""}
    When method POST
    Then status 200
    And match response body path $ should be hasSize 0

    Given set Url {{pam.webBaseUrl}}
    And add path web/customer/rest/v1-opap/players
    And set header Content-Type = application/json
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header x-game-id = JOKER
    # Password deliberately "tes..." not "test...": it must not contain the
    # player's firstName TEST (INVALID_PASSWORD_FIRSTNAME)
    And add request
    """
    {
      "username": "pampla{{regId}}",
      "password": "tesQwerty12!",
      "mobilePhone": "69{{msisdn}}",
      "email": "pampla{{regId}}@test.gr",
      "identityType": "PASSPORT",
      "identityNumber": "{{regId}}",
      "firstName": "TEST",
      "middleName": "PLAYER",
      "lastName": "SERVICE",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "21{{regId}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "testplayerservice",
      "ibanNumber": "{{pam.IBAN}}",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When set method POST
    Then check status 200
    * def playerId in response.id
    * def username in response.username


  # Postman: "Step validation 1: Username already exists" + "mobile phone already taken"
  # (merged: validating the just-registered username + phone reports both errors)
  Scenario: Step validation 1 - username and mobile phone already taken
    Given path web/customer/rest/v1-opap/players/registration-fields/validate
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"username": "{{username}}", "password": "testQwe123!", "mobilePhone": "69{{msisdn}}", "email": "taken@test.gr", "promoCode": ""}
    When method POST
    Then status 200
    And match path $[?(@.fieldName=='username')].errorId should be = USERNAME_ALREADY_EXISTS
    And match path $[?(@.fieldName=='mobilePhone')].errorId should be = MOBILE_PHONE_NOT_FREE


  # Postman: "Register player username already exists" + "Register player with mobile already taken"
  Scenario Outline: Register player - <case> already taken
    Given path web/customer/rest/v1-opap/players
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header x-game-id = JOKER
    And request
    """
    {
      "username": "<username>",
      "password": "tesQwe123!",
      "mobilePhone": "<mobilePhone>",
      "email": "taken{{regId}}@test.gr",
      "identityType": "PASSPORT",
      "identityNumber": "123123123",
      "firstName": "TEST",
      "middleName": "PLAYER",
      "lastName": "SERVICE",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "GRC",
      "phone": "2101000123",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "testplayerservice",
      "ibanNumber": "{{pam.IBAN}}"
    }
    """
    When method POST
    Then status 400

    Examples:
      | case     | username     | mobilePhone |
      | username | {{username}} | 6947445344  |
      | mobile   | tester       | 69{{msisdn}} |
