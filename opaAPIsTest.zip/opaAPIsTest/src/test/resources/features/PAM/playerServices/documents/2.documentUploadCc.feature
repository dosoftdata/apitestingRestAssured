@pam
@playerServices
@documentUpload
@documentUploadCc
Feature: Document Upload CC

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Document Upload CC
  # BackOffice-side player administration: tickets/affiliation/tax, player notes
  # CRUD + pinning, AML process/notes/audit, risk profile, fraud attributes, and
  # cc document uploads of every supported file type.
  # Postman used fixed player data (testuploaddocscc/6952220400) — replaced with
  # fresh random data so the feature is re-runnable on a persistent env.

  Background:
    Given url {{pam.boBaseUrl}}
    And header Content-Type = application/json
#    And header x-csrftoken = {{x-csrftoken}}
#    And header Cookie = csrftoken={{x-csrftoken}}


  # Postman: "Create OTP Verification" + "Verify OTP Code" + "Register Player cc" + BO session
  Scenario: Preparation - register player and BackOffice login
    * call feature features/PAM/playerServices/common/otpHelpers.feature
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Register temporary player
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Login BackOffice


  # Postman: "Get mailId..." + "Get hash..." + "Verify Player's Email"
  Scenario: Preparation - verify registration email
    Given path /cc/communication/rest/v1/emails
    And param playerId = {{playerId}}
    And delay request 10000
    When method GET
    Then status 200
    And match response body path data should be hasSize 1
    And match path $.data[0].origin should be = player
    And match path $.data[0].status should be = SENT
    * def mailHash in response.data[0].id

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/communication/rest/v1/emails/{hash_for_mail}
    And add pathParam hash_for_mail = {{mailHash}}
    When set method GET
    Then check status 200
    * def response_body in response.$

    And extract string using &hash= with name hashId from body response
    And backoffice verify player's email with hash hashId


  # Postman: "Get Bearer Token (WEB)" + "Get Player Level"
  Scenario: Preparation - player OIDC login
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Get web bearer token

    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1/players/{{playerId}}/player-levels
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
    And match response playerLevel = TEMPORARY_ACCOUNT


  # Postman: "Get Player's tickets"
  Scenario: Get player tickets
    Given path /cc/customer/rest/v1-opap/players/{{playerId}}/tickets
    When method GET
    Then status 200


  # Postman: "Get Player's affiliation" — none exists for a fresh player
  Scenario: Get player affiliation - not found
    Given path /cc/customer/rest/v1-opap/players/{{playerId}}/affiliation
    When method GET
    Then status 404
    # dev now answers the 404 with an empty body; Postman (2023) asserted:
    #   errorId = NOT_FOUND, description = Resource not found. ([Error Id: NOT_FOUND])


  # Postman: "Add Player Tax information" + "Get Player Tax information" (cc side)
  Scenario: Add and get player tax information from cc
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1-opap/players/{{playerId}}/tax
    And request {"taxNumber": "123456789", "streetAddress": "Street Address", "city": "City", "postalCode": "10431"}
    When method PUT
    Then status 200
    And match response taxNumber = 123456789
    And match response streetAddress = Street Address
    And match response city = City
    And match response postalCode = 10431
    And match response playerId = {{playerId}}

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1-opap/players/{{playerId}}/tax
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $.taxNumber should be = 123456789
    And check match path $.playerId should be = {{playerId}}


  # Postman: "Get Player's notes" (empty)
  Scenario: Get player notes - empty list
    Given path /cc/customer/rest/v1/players/{{playerId}}/notes
    When method GET
    Then status 200
    And match response body path $ should be hasSize 0


  # Postman: "Add new player note" + "Get Player's notes"
  Scenario: Add first player note
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1/players/{{playerId}}/notes
    And request {"text": "This is the 1st posted player note!", "pinned": false}
    When method POST
    Then status 200
    And match response pinned = false
    And match response text = This is the 1st posted player note!
    And match response playerId = {{playerId}}
    And match response updatedByUserType = 3
    And match response updatedByUserId = 1
    * def noteId in response.id

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/{{playerId}}/notes
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    # exactly one note: index 1 must not exist (JsonMatcher #size is unsupported on $)
    And check match path $[1] should be !exists
    And check match path $[0].id should be = {{noteId}}
    And check match path $[0].pinned should be = false
    And check match path $[0].text should be = This is the 1st posted player note!


  # Postman: "failedAdd new player note - text property missing / empty text"
  Scenario Outline: failedAdd player note - <case>
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1/players/{{playerId}}/notes
    And request <body>
    When method POST
    Then status 400
    And match response errorId = INVALID_INPUT
    And match response description contains The request payload is empty

    Examples:
      | case                  | body                            |
      | text property missing | {"pinned": false}               |
      | empty text            | {"text": "", "pinned": false}   |


  # Postman: "Add new player note - pinned property missing" (defaults to false)
  Scenario: Add second player note - pinned missing defaults to false
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1/players/{{playerId}}/notes
    And request {"text": "This is a player note missing the pinned property!"}
    When method POST
    Then status 200
    And match response pinned = false
    And match response text = This is a player note missing the pinned property!
    * def noteId2 in response.id


  # Postman: "Add new player pinned note" + "Get Player's notes" (3 notes, newest first)
  Scenario: Add third player note - pinned
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1/players/{{playerId}}/notes
    And request {"text": "This is the 3rd posted player note!", "pinned": true}
    When method POST
    Then status 200
    And match response pinned = true
    And match response text = This is the 3rd posted player note!
    * def noteId3 in response.id

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/{{playerId}}/notes
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    # exactly three notes: index 3 must not exist (JsonMatcher #size is unsupported on $)
    And check match path $[3] should be !exists
    And check match path $[0].id should be = {{noteId3}}
    And check match path $[0].pinned should be = true
    And check match path $[1].id should be = {{noteId2}}
    And check match path $[1].pinned should be = false
    And check match path $[2].id should be = {{noteId}}
    And check match path $[2].pinned should be = false


  # Postman: "failedPin Player's note - text property missing / empty text"
  Scenario Outline: failedPin player note - <case>
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1/players/{{playerId}}/notes/{{noteId}}
    And request <body>
    When method PUT
    Then status 400
    And match response errorId = INVALID_INPUT
    And match response description contains The request payload is empty

    Examples:
      | case                  | body                          |
      | text property missing | {"pinned": true}              |
      | empty text            | {"text": "", "pinned": true}  |


  # Postman: "Player's note - pinned property missing - remains false"
  Scenario: Update player note without pinned - stays unpinned
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1/players/{{playerId}}/notes/{{noteId}}
    And request {"text": "This is the 1st posted player note!"}
    When method PUT
    Then status 200
    And match response id = {{noteId}}
    And match response pinned = false


  # Postman: "Pin Player's note" + "Get Player's notes - Former pinned gets unpinned"
  Scenario: Pin first note - former pinned note gets unpinned
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1/players/{{playerId}}/notes/{{noteId}}
    And request {"text": "This is the 1st posted player note!", "pinned": true}
    When method PUT
    Then status 200
    And match response id = {{noteId}}
    And match response pinned = true

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/{{playerId}}/notes
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $[3] should be !exists
    And check match path $[2].id should be = {{noteId}}
    And check match path $[2].pinned should be = true
    And check match path $[0].id should be = {{noteId3}}
    And check match path $[0].pinned should be = false


  # Postman: "Pin Player's note - text change" + final "Get Player's notes"
  Scenario: Edit pinned note text
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1/players/{{playerId}}/notes/{{noteId}}
    And request {"text": "This is the 1st posted player note but edited!", "pinned": true}
    When method PUT
    Then status 200
    And match response id = {{noteId}}
    And match response pinned = true
    And match response text = This is the 1st posted player note but edited!

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1/players/{{playerId}}/notes
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $[2].text should be = This is the 1st posted player note but edited!


  # Postman: "Get AML process info" (404) + "Put AML process status" + "Get AML process info" (status 1)
  Scenario: AML process - create and read status
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1-opap/players/{{playerId}}/aml-process
    When method GET
    Then status 404
    And match response errorId = AML_PROCESS_NOT_FOUND
    And match response description = AML Process Not Found ([Error Id: AML_PROCESS_NOT_FOUND])

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1-opap/players/{{playerId}}/aml-process/status
    And set header Content-Type = application/json
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method PUT
    Then check status 200
    And check match path $.status should be = 1
    And check match path $.playerId should be = {{playerId}}
    And check match path $.updatedByUserType should be = 3

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1-opap/players/{{playerId}}/aml-process
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $.status should be = 1
    And check match path $.playerId should be = {{playerId}}


  # Postman: "Put AML note" + "Get AML note"
  Scenario: AML process notes
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1-opap/players/{{playerId}}/aml-process/notes
    And request {"text": "Test Note Text"}
    When method POST
    Then status 200
    And match response text = Test Note Text
    And match response playerId = {{playerId}}
    And match response updatedByUserType = 3
    And match response updatedByUserId = 1

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1-opap/players/{{playerId}}/aml-process/notes
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $[0].playerId should be = {{playerId}}
    And check match path $[0].updatedByUserType should be = 3


  # Postman: "Get Risk Profile info" (404)
  Scenario: Risk profile - not found for fresh player
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1-opap/players/{{playerId}}/riskprofile
    When method GET
    Then status 404
    And match response errorId = RISK_PROFILE_NOT_FOUND
    And match response description = Player risk profile resource not found. ([Error Id: RISK_PROFILE_NOT_FOUND])

  # Postman: "Put Risk Profile"
  Scenario: Risk profile - set flags
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1-opap/players/{{playerId}}/riskprofile
    And request {"riskAttributeFlags": ["HIGH_RISK", "AML", "BA"]}
    When method PUT
    Then status 200
    And match response body path riskAttributeFlags should be hasItems HIGH_RISK,AML,BA

  # Postman: "Get Risk Profile info" (flags present)
  Scenario: Risk profile - read flags
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1-opap/players/{{playerId}}/riskprofile
    When method GET
    Then status 200
    And match response body path riskAttributeFlags should be hasItems HIGH_RISK,AML,BA


  # Postman: "Put AML fraud attributes note" + "Get fraud attributes note"
  Scenario: Fraud attributes notes
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1-opap/players/{{playerId}}/fraud-attributes/notes
    And request {"text": "Test Note Text"}
    When method POST
    Then status 200
    And match response text = Test Note Text
    And match response playerId = {{playerId}}
    And match response updatedByUserType = 3
    And match response updatedByUserId = 1

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1-opap/players/{{playerId}}/fraud-attributes/notes
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200
    And check match path $[0].playerId should be = {{playerId}}
    And check match path $[0].updatedByUserType should be = 3


  # Postman: "Get AML audit" + "Get risk profile audit"
  Scenario: AML and risk profile audits
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1-opap/players/{{playerId}}/aml-process/audit
    When method GET
    Then status 200
    And match path $[0].updates[0].field should be = playerId
    And match path $[0].updates[0].toValue should be = {{playerId}}
    And match path $[0].updatedBy.id should be = 1
    And match path $[0].updatedBy.type should be = 3

    Given set Url {{pam.boBaseUrl}}
    And add path /cc/customer/rest/v1-opap/players/{{playerId}}/risk-profile/audit
    And set header x-csrftoken = {{x-csrftoken}}
    And set header Cookie = csrftoken={{x-csrftoken}}
    When set method GET
    Then check status 200


  # Postman: "CC Upload <TYPE> document (<ext>)" — 6 requests
  Scenario Outline: CC upload <type> document (<ext>)
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1/players/{{playerId}}/documents
    And header Content-Type = multipart/form-data
    And form field fileName = <fileName>
    And form field type = <type>
    And form field file = <fileName>
    And multipart file file path src/test/resources/files/<fileName> mimeType <mimeType>
    When method POST
    Then status 200
    And match response type = <type>
    And match response fileName = <fileName>
    And match response fileType = <mimeType>
    And match response playerId = {{playerId}}
    And match response updatedByUserType = 3
    And match response updatedByUserId = 1

    Examples:
      | type               | ext      | fileName  | mimeType        |
      | OTHER              | jpg/jpeg | image.jpg | image/jpeg      |
      | ID_FRONT           | tif/tiff | image.tif | image/tiff      |
      | ID_BACK            | pdf      | image.pdf | application/pdf |
      | PASSPORT           | bmp      | image.bmp | image/bmp       |
      | SOLEMN_DECLARATION | png      | image.png | image/png       |
      | UTILITY_BILL       | gif      | image.gif | image/gif       |


  # Postman: "Get uploaded documents (CC)" — cumulative per-upload GETs collapsed
  Scenario: Get uploaded documents from cc
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    Given path /cc/customer/rest/v1/players/{{playerId}}/documents
    When method GET
    Then status 200
    And match response body path $ should be hasSize 6
    And match path $[?(@.fileName=='image.jpg')].fileType should be = image/jpeg
    And match path $[?(@.fileName=='image.tif')].fileType should be = image/tiff
    And match path $[?(@.fileName=='image.pdf')].fileType should be = application/pdf
    And match path $[?(@.fileName=='image.bmp')].fileType should be = image/bmp
    And match path $[?(@.fileName=='image.png')].fileType should be = image/png
    And match path $[?(@.fileName=='image.gif')].fileType should be = image/gif


  # Postman: "Get uploaded documents (WEB)" — uploads made by the BO user (type 3)
  Scenario: Get verification documents from web
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1/players/{{playerId}}/verification-documents
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200
    And match response body path $ should be hasSize 6
    And match response body path status should be everyItemContains PENDING
    And match response body path verificationType should be everyItemContains IDENTITY
