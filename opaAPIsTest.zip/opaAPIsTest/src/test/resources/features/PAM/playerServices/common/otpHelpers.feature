@helper
Feature: Player services helpers - OTP

  # Callees for `call feature` — not meant to run standalone (no suite tags).
  # Converted from Postman folder: opap-player-service > Registration_Process > AML > Preparation

  # Captures {{web-x-csrftoken}} for the calling feature.
  Scenario: Bootstrap csrf token
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1/otp
    And header Content-Type = application/json
    And request {}
    When method POST
    Then status 403
    * Cookie web-x-csrftoken in response.csrftoken

  # Creates + verifies an OTP for a fresh MSISDN (static dev/uat code 000000).
  # Captures {{msisdn}} (8-digit suffix; phone = 69{{msisdn}}) and {{otpUuid}}.
  # Requires {{web-x-csrftoken}} (run "Bootstrap csrf token" first).
  Scenario: Create and verify OTP
    Given def msisdn = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1/otp
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And request {"phoneNumber": "69{{msisdn}}"}
    When method POST
    Then status 200
    And match response status = PENDING
    And match response phoneNumber = 3069{{msisdn}}
    * def otpUuid in response.uuid

    Given set Url {{pam.webBaseUrl}}
    And add path web/customer/rest/v1/otp
    And set header Content-Type = application/json
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And add request {"phoneNumber": "69{{msisdn}}", "uuid": "{{otpUuid}}", "verificationCode": "000000"}
    When set method PUT
    Then check status 204
