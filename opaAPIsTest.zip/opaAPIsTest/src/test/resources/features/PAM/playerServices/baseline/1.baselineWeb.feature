@pam
@playerServices
@playerServiceBaseline
@baselineWeb
Feature: Player service baseline - Web

  # Converted from Postman collection player-service_access-token
  # folder: player-service-baseline > Web
  # Player self-service surface: email/password/username updates, preferences,
  # password reset, self exclusion. Postman used fixed player data (testprlbas) —
  # replaced with fresh random data so the feature is re-runnable.
  # Player password chain: Qwerty12345! -> Qwerty12345!! (after "Update password successfully").

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  # Postman: Create OTP + Verify OTP + "Register Player baseline" + "Login BO"
  Scenario: Preparation - register player and BackOffice login
    * call feature features/PAM/playerServices/common/otpHelpers.feature
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "NATIONAL_ID",
      "identityNumber": "ΑΚ{{regId}}",
      "firstName": "TEST",
      "middleName": "PLAYER",
      "lastName": "SERVICE",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "BGR",
      "phone": "21{{regId}}",
      "mobilePhone": "69{{msisdn}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "testuplrbas",
      "agentId": "101001",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    * def playerId in response.id
    * def username in response.username
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Login BackOffice

  Scenario: Preparation - verify registration email
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Verify registration email

  # Postman: "Get Bearer Token (WEB)" + "get emails" (GET /v2/players/me)
  Scenario: Preparation - player OIDC login and players me
    * call feature features/PAM/playerServices/common/playerHelpers.feature scenario Get web bearer token
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v2/players/me
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    When method GET
    Then status 200


  # Postman: "Update email with invalid / not free / new email address"
  Scenario Outline: Update email - <case>
    Given path web/customer/rest/v2/players/{{playerId}}/email
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"email": "<email>"}
    When method PUT
    Then status 400
    And match response errorId = <errorId>
    And match response description = <description>

    Examples:
      | case     | email                      | errorId       | description                                                                       |
      | invalid  | pamplabasnewmailsac.com    | INVALID_EMAIL | Email is invalid ([Error Id: INVALID_EMAIL])                                      |
      | not free | pampla{{regId}}@mailsac.com | EMAIL_NOT_FREE | This email has already been registered in the system. ([Error Id: EMAIL_NOT_FREE]) |

  # Postman: "Update email with new email address" — change is pending, response keeps the old address
  Scenario: Update email with new email address
    Given path web/customer/rest/v2/players/{{playerId}}/email
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"email": "pampla{{regId}}new@mailsac.com"}
    When method PUT
    Then status 200
    And match response email = pampla{{regId}}@mailsac.com


  # Postman: "Update password with mismatch / invalid / wrong current password"
  Scenario Outline: Update password - <case>
    Given path web/customer/rest/v2/players/{{playerId}}/password
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"oldPassword": "<oldPassword>", "newPassword": "<newPassword>", "passwordConfirmation": "<passwordConfirmation>"}
    When method PUT
    Then status <status>
    And match response errorId = <errorId>

    Examples:
      | case                   | oldPassword   | newPassword    | passwordConfirmation | status | errorId               |
      | confirmation mismatch  | Qwerty12345!  | Qwerty12345!!  | Qwerty12345!         | 400    | NEW_PASSWORD_MISMATCH |
      | invalid empty password | Qwerty12345!  |                |                      | 400    | VALIDATION_ERROR      |
      | wrong current password | test          | Qwerty12345!!  | Qwerty12345!!        | 403    | INVALID_PASSWORD      |

  # Postman: "Update password successfully" + "Update password with used password"
  Scenario: Update password successfully then reject reusing the old one
    Given path web/customer/rest/v2/players/{{playerId}}/password
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"oldPassword": "Qwerty12345!", "newPassword": "Qwerty12345!!", "passwordConfirmation": "Qwerty12345!!"}
    When method PUT
    Then status 200 or 204

    Given set Url {{pam.webBaseUrl}}
    And add path web/customer/rest/v2/players/{{playerId}}/password
    And set header Content-Type = application/json
    And set header Authorization = {{token_type}} {{access_token}}
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header X-GAME-ID = JOKER
    And add request {"oldPassword": "Qwerty12345!!", "newPassword": "Qwerty12345!", "passwordConfirmation": "Qwerty12345!"}
    When set method PUT
    Then check status 400
    And check match path $.errorId should be = PASSWORD_HAS_BEEN_USED


  # Postman: "Update username with existing / invalid username" — username can only be defined once
  Scenario Outline: Update username - <case>
    Given path web/customer/rest/v2/players/{{playerId}}/username
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"username": "<newUsername>", "password": "Qwerty12345!!"}
    When method PUT
    Then status 400
    And match response errorId = USERNAME_ALREADY_DEFINED
    And match response description = Username already defined. ([Error Id: USERNAME_ALREADY_DEFINED])

    Examples:
      | case              | newUsername   |
      | existing username | testplrbasnew |
      | invalid username  | 12345         |


  # Postman: "Add preference with wrong category / empty preference / wrong sub-category"
  Scenario Outline: Add preference - <case>
    Given path web/customer/rest/v1/players/{{playerId}}/preferences
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"category": "<category>", "subCategory": "<subCategory>", "preference": "<preference>"}
    When method POST
    Then status 400
    And match response errorId = <errorId>

    Examples:
      | case               | category | subCategory | preference | errorId                             |
      | wrong category     | test     | DEFAULT     | US_EN      | UNSUPPORTED_PREFERENCE_CATEGORY     |
      | empty preference   | LANGUAGE | DEFAULT     |            | VALIDATION_ERROR                    |
      | wrong sub-category | LANGUAGE | test        | US_EN      | UNSUPPORTED_PREFERENCE_SUBCATEGORY  |

  # Postman: "Add preference for player" + "Add same preference for player"
  Scenario: Add preference then reject the duplicate
    Given path web/customer/rest/v1/players/{{playerId}}/preferences
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"category": "LANGUAGE", "subCategory": "DEFAULT", "preference": "US_EN"}
    When method POST
    Then status 200

    Given set Url {{pam.webBaseUrl}}
    And add path web/customer/rest/v1/players/{{playerId}}/preferences
    And set header Content-Type = application/json
    And set header Authorization = {{token_type}} {{access_token}}
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header X-GAME-ID = JOKER
    And add request {"category": "LANGUAGE", "subCategory": "DEFAULT", "preference": "US_EN"}
    When set method POST
    Then check status 400
    And check match path $.errorId should be = PREFERENCE_ALREADY_EXISTS


  # Postman: "Reset password request - Date of birth is missing" + "Reset password request"
  Scenario: Password reset request requires date of birth
    Given path web/customer/rest/v1/password-resets
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"resetType": "EMAIL", "value": "pampla{{regId}}@mailsac.com"}
    When method POST
    Then status 400
    And match response errorId = VALIDATION_ERROR
    And match path $.constraintViolations[0].path should be = requestPasswordReset.arg0.dateOfBirth
    And match path $.constraintViolations[0].message should be = dateOfBirth may not be null

    Given set Url {{pam.webBaseUrl}}
    And add path web/customer/rest/v1/password-resets
    And set header Content-Type = application/json
    And set header x-csrftoken = {{web-x-csrftoken}}
    And set header Cookie = csrftoken={{web-x-csrftoken}}
    And set header X-GAME-ID = JOKER
    And add request {"resetType": "EMAIL", "value": "pampla{{regId}}@mailsac.com", "dateOfBirth": "1970-09-29"}
    When set method POST
    Then check status 200 or 204


  # Postman: "Set self-exclusion for player" — last step, locks the player.
  # Postman sent the original password; the current one after the change is Qwerty12345!!.
  Scenario: Set self-exclusion for player
    Given path web/customer/rest/v2/players/{{playerId}}/self-exclude
    And header Authorization = {{token_type}} {{access_token}}
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = JOKER
    And request {"exclusionHours": "24", "password": "Qwerty12345!!", "reason": "Not allowed to play anymore :/"}
    When method POST
    Then status 200 or 204
