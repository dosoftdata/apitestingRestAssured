@pam
@playerServices
@registration
@aml
@amlResidenceCountry
Feature: Registration Process - AML - permanentResidenceCountry validation

  # Converted from Postman collection player-service_access-token
  # folder: opap-player-service > Registration_Process > AML > Registration - permanentResidenceCountry
  # The field takes an ISO 3166-1 alpha-3 code (e.g. GRC, ALB); defaults to GRC when omitted.

  Background:
    Given url {{pam.webBaseUrl}}
    And header Content-Type = application/json


  # Postman: AML > Preparation (Create OTP Verification + Verify OTP Code)
  Scenario: Preparation - csrf token and verified OTP
    * call feature features/PAM/playerServices/common/otpHelpers.feature


  # Postman: "failedRegister Player - permanentResidenceCountry invalid/empty/null" (6 requests)
  # Bean validation fires before the OTP lookup, so the same otpUuid serves every row.
  Scenario Outline: failedRegister Player - permanentResidenceCountry <case>
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "OTHER",
      "identityNumber": "{{regId}}",
      "firstName": "PAM",
      "middleName": "LOTTERY",
      "lastName": "PLATFORM",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "permanentResidenceCountry": <country>,
      "profession": "Unemployed",
      "phone": "21{{regId}}",
      "mobilePhone": "69{{msisdn}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 400
    And match response errorId = VALIDATION_ERROR
    And match response description = Validation failed
    And match path $.constraintViolations[0].constraintType should be = PARAMETER
    And match path $.constraintViolations[0].path should be = registerPlayer.arg1.permanentResidenceCountry
    And match path $.constraintViolations[0].message should be = The Country Code provided is invalid

    Examples:
      | case          | country |
      | invalid "GR"  | "GR"    |
      | invalid "GGG" | "GGG"   |
      | invalid "grc" | "grc"   |
      | invalid "-"   | "-"     |
      | empty         | ""      |
      | null          | null    |


  # Postman: "Register Player - permanentResidenceCountry missing -> GRC" (after fresh OTP)
  Scenario: Register Player - permanentResidenceCountry missing defaults to GRC
    * call feature features/PAM/playerServices/common/otpHelpers.feature scenario Create and verify OTP
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "OTHER",
      "identityNumber": "{{regId}}",
      "firstName": "PAM",
      "middleName": "LOTTERY",
      "lastName": "PLATFORM",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "phone": "21{{regId}}",
      "mobilePhone": "69{{msisdn}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    And match response mobilePhone = 69{{msisdn}}
    And match response permanentResidenceCountry = GRC


  # Postman: "Register Player - permanentResidenceCountry ALB" (after fresh OTP)
  Scenario: Register Player - permanentResidenceCountry ALB
    * call feature features/PAM/playerServices/common/otpHelpers.feature scenario Create and verify OTP
    Given def regId = random 8 digits
    Given url {{pam.webBaseUrl}}
    And path web/customer/rest/v1-opap/players
    And header Content-Type = application/json
    And header x-csrftoken = {{web-x-csrftoken}}
    And header Cookie = csrftoken={{web-x-csrftoken}}
    And header X-GAME-ID = KINO
    And request
    """
    {
      "username": "pampla{{regId}}",
      "password": "Qwerty12345!",
      "email": "pampla{{regId}}@mailsac.com",
      "identityType": "OTHER",
      "identityNumber": "{{regId}}",
      "firstName": "PAM",
      "middleName": "LOTTERY",
      "lastName": "PLATFORM",
      "gender": "M",
      "dateOfBirth": "1970-09-29",
      "country": "GR",
      "city": "Athens",
      "address1": "First address 0100",
      "zip": "15125",
      "profession": "Unemployed",
      "permanentResidenceCountry": "ALB",
      "phone": "21{{regId}}",
      "mobilePhone": "69{{msisdn}}",
      "bonusCode": "THIS_IS_A_BONUS_CODE",
      "secretQuestion": "What is your name?",
      "secretAnswer": "pamlotteryplatform",
      "ibanNumber": "{{pam.IBAN}}",
      "otpUuid": "{{otpUuid}}"
    }
    """
    When method POST
    Then status 200
    And match response mobilePhone = 69{{msisdn}}
    And match response permanentResidenceCountry = ALB
