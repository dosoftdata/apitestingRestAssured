@mock @callFeature
Feature: DSL call feature
  Runs features/common/landed.feature inside these scenarios and consumes the
  variables it captures.

  Scenario: Call all scenarios of a feature and read its captured vars
    # defaults for the parameterized callee scenario (shared context flows in)
    And def argItemId = DEFAULT-0
    And def argQty = 1
    * call feature features/common/landed.feature
    And match string {{landedStatus}} contains LANDED
    And match string {{landedHops}} contains 3
    And match string {{calledItemId}} contains CALLED-1
    And match string {{argPostedId}} contains DEFAULT-0

  Scenario: Call a single named scenario only
    * call feature features/common/landed.feature scenario Land and capture
    And match string {{landedStatus}} contains LANDED

  Scenario: Calling the whole feature runs every Examples row
    * call feature features/common/landed.feature
    # last example row (OUTL-2) ran last, so its capture wins
    And match string {{lastItemId}} contains OUTL-2

  Scenario: Opt into a single Examples row by its substituted name
    * call feature features/common/landed.feature scenario Post item OUTL-1
    And match string {{lastItemId}} contains OUTL-1

  Scenario: Pass arguments to the callee via docstring (Karate call-with-arg)
    * call feature features/common/landed.feature scenario Post one item from args with args
      """
      { "argItemId": "ARG-9", "argQty": 42 }
      """
    And match string {{argPostedId}} contains ARG-9
