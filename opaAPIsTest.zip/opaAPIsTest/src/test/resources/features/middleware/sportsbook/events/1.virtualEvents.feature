@not-used  @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[7] Virtual Events

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = en-US
    And param drilldownTagIds = 11,12
    And param orderEventsBy = upperHierarchy
    And param excludeEventsWithNoMarkets = true
    And param includeRaceDetails = false
    And param excludeSettledEvents = true
    And param excludeResultedEvents = true
    When path /uip/sportsbook/api/v1.0/events/virtualEvents

  Scenario Outline:[1] Virtual Events list
    And header channel = <channel>
    #And header x-player-id = {{playerId}}
    #And param playerId = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
      {
        "data": {
             "data":{
                    "events":"#array"
                    }
         }
      }
     """
    And match each $.data.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "teams": "#array"
          }
      """
    Examples:
      |channel|
#      |R      |
#      |T      |
#      |H      |
       |I      |
#      |X      |
#      |M      |
#      |A      |

