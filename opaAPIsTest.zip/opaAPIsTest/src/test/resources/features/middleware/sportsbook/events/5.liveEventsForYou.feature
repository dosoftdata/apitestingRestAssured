@regression @personalized @event @live @events @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[11] live events for you

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    When path  /uip/sportsbook/api/v1.0/events/liveEventsForYou
    And param location = inplay_widget
    And param locale = el-GR
    And param channel = I

  Scenario:[0] Live events for you
    And header x-player-id = {{playerId}}
    And param recommended = true
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """

  Scenario:[1] Live events for you - no player id
    And param recommended = false
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'
