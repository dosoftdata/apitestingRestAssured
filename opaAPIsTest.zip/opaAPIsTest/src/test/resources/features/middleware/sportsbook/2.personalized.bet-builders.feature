@regression @personalized @betbuilder @MID-69 @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[6] MID-69 - personalized bet-builders

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And param locale = el-GR
    And param location = samegame_accas
    When path /uip/sportsbook/api/v1.0/personalized/bet-builders

  Scenario Outline:[1] personalized bet-builders
    And param recommended = true
    And param channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    Examples:
      |channel|
      |R      |
      |T      |
      |H      |
      |I      |
      |X      |
      |M      |
      |A      |

  Scenario:[2] personalized bet-builders no player
    And header channel = T
    And retry GET  until condition {}
    Then status 500
    And match response msg contains Required request header 'x-player-id'

  Scenario:[3] personalized betslip null player
    And header x-player-id = ""
    And header channel = T
    And retry GET  until condition {}
    Then status 500
    And match response msg contains For input string: """"

  Scenario Outline:[4] personalized bet-builders not recommended
    And param recommended = false
    And param channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    Examples:
      |channel|
      |R      |