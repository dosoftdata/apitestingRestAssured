@regression @events @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[14] Events with Boosted Markets from Open Bet by providing a list of event ids.
  Recommended Events (Event Cards) - Get Sportsbook Events from Open Bet by providing a list of event ids.

  Background:
    Given url {{psMiddlewareHost}}
    And header Content-Type = application/json
    When path  /uip/sportsbook/api/v1.0/events/getEventsNew/byEventIds
    And param location = recommended_events
    And param locale = el-GR
    And param channel = I
    And param active = true
   # And param eventIds = 5126907
    And param drilldownTagIds = 11
    And param excludeEventsWithNoMarkets = true
    And param excludeExpiredMarketsEvent = true
    And param excludeSettledEvents = true
    And param excludeResultedEvents = true
    And param excludeExpiredMarketsMarket = true
    And param limit = 10
    And param orderEventsBy = displayOrder
    And param prioritisePrimaryMarkets = true
    And param marketLimit = 2
    And param includeMarkets = true
    And param includeTeams = true
    And param includeCommentary = true
    And param includeProviders = true
    And param includeCollections = true
    And param includeRaceDetails = FALSE
    And param playerId = {{ playerId }}
    And param count = 3
    And param fromOffset = -5d
    And param toOffset = 5d



  Scenario:[0] events new by event id  - no player id
    And param recommended = true
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'playerId'

  Scenario:[1] events new by event id
    And param eventIds = 5126907
    And header x-player-id = {{playerId}}
    And param recommended = true
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """

  Scenario:[2] events new by event id - not recommended
    And header x-player-id = {{playerId}}
    And param recommended = false
    And retry GET  until condition {}
    Then status 200
    And match
     """
      {
       "data": {
          "events":"#array"
        }
      }
     """
  #-- Error response vaix, not api gateway
  Scenario:[3] events new - no player id
    And param recommended = true
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'playerId'


