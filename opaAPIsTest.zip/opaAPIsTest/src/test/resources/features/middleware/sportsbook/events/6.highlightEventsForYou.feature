@regression @highlight @events @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[12] highlight events for you

  Background:
    Given url {{psMiddlewareHost}}
    And header Content-Type = application/json
    When path  /uip/sportsbook/api/v1.0/events/highlightEventsForYou
    And param location = recommended_prematchevents
    And param locale = el-GR
    And param channel = I

  Scenario:[0] highlight events for you - no player id
    And param recommended = true
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'

  Scenario:[1] highlight events for you
    And header x-player-id = {{playerId}}
    And param recommended = true
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """


  Scenario:[2] highlight events for you - not recommended
    And header x-player-id = {{playerId}}
    And param recommended = false
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
  @passUAT-Preprod @FailedLocal-Dev
  Scenario:[3] highlight events for you - no player id
    And param recommended = true
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'


