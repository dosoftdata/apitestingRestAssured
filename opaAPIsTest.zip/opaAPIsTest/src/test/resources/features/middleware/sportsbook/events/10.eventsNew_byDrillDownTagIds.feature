@regression @events @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[15] Events with Boosted Markets from Open Bet by providing a list of event ids.
  Recommended Events (Event Cards) - Get Sportsbook Events from Open Bet by providing a list of event ids.

  Background:
    Given url {{psMiddlewareHost}}
    And header Content-Type = application/json
    When path  /uip/sportsbook/api/v1.0/events/getEventsNew/byDrillDownTagIds
    And param location = recommended_prematchevents
    And param drilldownTagIds = 11
    And param active = true
    And param excludeEventsWithNoMarkets = true
    And param excludeExpiredMarketsEvent = true
    And param excludeSettledEvents = true
    And param excludeResultedEvents = true
    And param excludeExpiredMarketsMarket = true
    And param sortsIncluded = MTCH
    And param limit = 10
    And param liveNow = 0
    And param orderEventsBy = upperHierarchy
    And param prioritisePrimaryMarkets = true
    And param marketGroupCodesIncluded = MATCH_RESULT,TOTAL_GOALS_OVER/UNDER,BOTH_TEAMS_TO_SCORE
    And param includePrimaryMarketsOnly = false
    And param includeMarkets = true
    And param includeTeams = true
    And param includeCommentary = true
    And param includeProviders = true
    And param includeCollections = true
    And param includeRaceDetails = false
    And param playerId = {{playerId}}
    And param count = 10
    And param toOffset = 5d
    And param channel = I
    And param locale = el-GR

  Scenario:[0] events new by event id  - no player id
    And param recommended = true
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'playerId'

  Scenario:[1] events new by event id
    And header x-player-id = {{playerId}}
    And param recommended = true
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """

  Scenario:[2] events new by event id - not recommended
    And header x-player-id = {{playerId}}
    And param recommended = false
    And retry GET  until condition {}
    Then status 200
    And match
     """
      {
       "data": {
          "events":"#array"
        }
      }
     """
  #-- Error response vaix, not api gateway
  Scenario:[3] events new - no player id
    And param recommended = true
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'playerId'


