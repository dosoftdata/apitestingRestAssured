@regression @personalized @event @live @market @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[9] live markets

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    When path  /uip/sportsbook/api/v1.0/events/liveMarkets

  Scenario:[0] Live Markets
    And param locale = el-GR
    And param recommended = true
    And param oddsTypeMarket = FIXED
    And param includeCommentary = true
    And param channel = I
    And param eventIds = 3333,3444
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """

  Scenario:[0] Live Markets - not recommended
    And param locale = el-GR
    And param recommended = false
    And param oddsTypeMarket = FIXED
    And param includeCommentary = true
    And param channel = I
    And param eventIds = 3333,3444
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """