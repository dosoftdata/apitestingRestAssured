@regression @liveSport @events @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[13] Live Sports - Live Drill Down Sports from OB
   issue : missed  player validation from api-gateway
   /uip/sportsbook/api/v1.0/events/getEventsNew
  Background:
    Given url {{psMiddlewareHost}}
    And header Content-Type = application/json
    When path  /uip/sportsbook/api/v1.0/events/getLiveDrilldownSports
    And param location = homepage_recommended_livesports
    And param eventState = LIVE_EVENT
    And param locale = el-GR
    And param channel = I

  Scenario:[0] highlight events for you - no player id
    And param recommended = true
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'playerId'

  Scenario:[1] highlight events for you
    And header x-player-id = {{playerId}}
    And param recommended = true
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "drilldownNodes":"#array"
        }
      }
     """


  Scenario:[2] highlight events for you - not recommended
    And header x-player-id = {{playerId}}
    And param recommended = false
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "drilldownNodes":"#array"
        }
      }
     """
  @passUAT-Preprod @FailedLocal-Dev
  Scenario:[3] highlight events for you - no player id
    And param recommended = true
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'playerId'


