@regression @personalized @betslip @MID-67 @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[5] MID-67 - personalized betslip

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And param locale = el-GR
    And param location = multigame_accas
    When path /uip/sportsbook/api/v1.0/personalized/betslips

  Scenario Outline:[1] personalized betslip
    And param recommended = true
    And param channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    Examples:
      |channel|
      |R      |
#      |T      |
#      |H      |
#      |I      |
#      |X      |
#      |M      |
#      |A      |

  Scenario:[2] personalized betslip no player
    And param recommended = true
    And header channel = T
    And retry GET  until condition {}
    Then status 500
    And match response msg contains Required request header 'x-player-id'

  Scenario:[3] personalized betslip null player
    And param recommended = true
    And header x-player-id = ""
    And header channel = T
    And retry GET  until condition {}
    Then status 500
    And match response msg contains For input string: """"

  Scenario Outline:[4] personalized betslip not recommended
    And param recommended = false
    And param channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    Examples:
      |channel|
      |R      |