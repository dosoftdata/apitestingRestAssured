@regression @events @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[13] Events with Boosted Markets from Open Bet (Pregame only).
  Price Boost Recommended - Get Sportsbook Events with Boosted Markets from Open Bet (Pregame only).

  Background:
    Given url {{psMiddlewareHost}}
    And header Content-Type = application/json
    When path  /uip/sportsbook/api/v1.0/events/getEventsNew
    And param location = recommended_events
    And param locale = el-GR
    And param channel = I
    And param active = true
#    And param excludeEventsWithNoMarkets = true
#    And param excludeExpiredMarketsEvent = true
#    And param excludeSettledEvents = true
#    And param boostedMarketsAvailable = true
#    And param excludeExpiredMarketsMarket = true
#    And param limit = 20
#    And param liveNow = true
#    And param orderEventsBy = startTime
#    And param orderMarketsBy = displayOrder
#    And param prioritisePrimaryMarkets = true
#    And param includePrimaryMarketsOnly = false
#    And param boostedMarketsOnly = true
#    And param includeMarkets = true
#    And param includeTeams = true
#    And param includeCommentary = true
#    And param includeProviders = true
#    And param includeCollections = false
#    And param includeRaceDetails = false
#    And param recommended = true
#    And param count = 20
#    And param playerId = {{playerId}}
#    And param toOffset = 7d


  Scenario:[0] events new  - no player id
    And param recommended = true
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'playerId'

  Scenario:[1] events new
    And header x-player-id = {{playerId}}
    And param recommended = true
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """

  Scenario:[2] events new - not recommended
    And header x-player-id = {{playerId}}
    And param recommended = false
    And retry GET  until condition {}
    Then status 200
    And match
     """
      {
       "data": {
          "events":"#array"
        }
      }
     """

  Scenario:[3] events new - no player id
    And param recommended = true
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'playerId'


