@regression @personalized @event @pregame @market @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[8] PreGame markets

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json

  Scenario:[0] Get Event
    And param locale = el-GR
    And param location = samegame_accas
    When path /uip/sportsbook/api/v1.0/personalized/bet-builders
    And param recommended = false
    And param channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    * def eventIds in response.data.events[0].id
    * def eventIdsList in response.data.events[0].id,response.data.events[1].id

  Scenario:[1] PreGame market without event id - not recommended
    And header locale = en-US
    And param location = eventpage_recommended_markets

    And param recommended = false
    When path  /uip/sportsbook/api/v1.0/events/preGameMarkets
    And header channel = I
    And retry GET  until condition {}
    Then status 500
    And match response msg = System Error: Required request parameter 'eventIds' for method parameter type String is not present

  Scenario:[2] PreGame market without event id - recommended
    And header locale = en-US
    And param location = eventpage_recommended_markets
    And param recommended = true
    When path  /uip/sportsbook/api/v1.0/events/preGameMarkets
    And header channel = I
    And retry GET  until condition {}
    Then status 500
    And match response msg = System Error: Required request parameter 'eventIds' for method parameter type String is not present

  Scenario:[3] PreGame market with event id - recommended - without playerId
    And header locale = en-US
    And param location = eventpage_recommended_markets
    And param recommended = true
    And param eventIds = {{eventIds}}
    When path  /uip/sportsbook/api/v1.0/events/preGameMarkets
    And header channel = I
    And retry GET  until condition {}
    Then status 500
    And match response msg = System Error: Required request parameter 'playerId' for method parameter type String is not present

  Scenario:[4] PreGame market with event id - recommended - with playerId
    And header locale = en-US
    And param location = eventpage_recommended_markets
    And param recommended = true
    And param eventIds = {{eventIds}}
    When path  /uip/sportsbook/api/v1.0/events/preGameMarkets
    And header channel = I
    And header x-player-id = {{playerId}}
    #And param playerId = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "{{eventIds}}",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """

  Scenario:[5] PreGame market with event id - not recommended
    And header locale = en-US
    And param location = eventpage_recommended_markets
    And param recommended = false
    And param eventIds = {{eventIds}}
    When path  /uip/sportsbook/api/v1.0/events/preGameMarkets
    And header channel = I
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "{{eventIds}}",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """