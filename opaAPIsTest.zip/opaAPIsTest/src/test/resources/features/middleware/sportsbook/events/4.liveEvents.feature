@regression @personalized @event @live @events @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[10] live events

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    When path  /uip/sportsbook/api/v1.0/events/getLiveEvents

  Scenario:[0] Live events
    And param drilldownTagIds = 11
    And param limit = 7
    And param orderEventsBy = upperHierarchy
    And param marketGroupCodesIncluded = MATCH_RESULT,TOTAL_GOALS_OVER/UNDER,BOTH_TEAMS_TO_SCORE
    And header x-player-id = {{playerId}}
    And param recommended = true
    And param locale = el-GR
    And param channel = I
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """

  Scenario:[0] Live events - no player id
    And param drilldownTagIds = 11
    And param limit = 7
    And param orderEventsBy = upperHierarchy
    And param marketGroupCodesIncluded = MATCH_RESULT,TOTAL_GOALS_OVER/UNDER,BOTH_TEAMS_TO_SCORE
    And param recommended = false
    And param locale = el-GR
    And param channel = I
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
