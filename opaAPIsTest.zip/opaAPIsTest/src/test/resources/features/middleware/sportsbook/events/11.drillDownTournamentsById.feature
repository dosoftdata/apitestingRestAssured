@regression @events @ps
@epic:MID-61-Middleware-Sportsbook
Feature:[16] Events Drill Down Tournaments by id.
  All Sports Recommended - Get Drill Down Tournaments from Open Bet (Pregame Only).

  Background:
    Given url {{psMiddlewareHost}}
    And header Content-Type = application/json
    When path  /uip/sportsbook/api/v1.0/events/drillDownTournamentsById
    And param location = sports_atoz
    And param count = 10
    And param toOffset = 5d
    And param channel = I
    And param locale = el-GR
    And param playerId = {{playerId}}

  Scenario:[0] drill Down Tournaments by id  - no player id
    And param recommended = false
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "drilldownNodes":"#array"
        }
      }
     """

  Scenario:[1] drill Down Tournaments by id
    And param drilldownNodeIds = 2
    And header x-player-id = {{playerId}}
    And param recommended = true
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "drilldownNodes":"#array"
        }
      }
     """

  Scenario:[2] drill Down Tournaments by id - not recommended
    And param drilldownNodeIds = 2
    And header x-player-id = {{playerId}}
    And param recommended = false
    And retry GET  until condition {}
    Then status 200
    And match
     """
      {
       "data": {
          "drilldownNodes":"#array"
        }
      }
     """
  #-- Error response vaix, not api gateway
  Scenario:[3] drill Down Tournaments by id- no player id
    And param recommended = true
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'playerId' for method parameter


