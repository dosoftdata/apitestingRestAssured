@regression @digitalPaymentAPOLLO @digitalPaymentAPOLLOcreate
@digitalPayment
@epic:TPR-2404-digital-payement-APOLLO

Feature:[3] Cancel Digital Payment - APOLLO
  Background:
    When url {{middlewareHost}}
    And header Content-Type = application/json

  Scenario:[1] Create digital payment
    When User has Intralot token
    And header Authorization = Bearer {{intralotAccessToken}}
    And header x-authorization-system = Intralot
    And header GUID = {{uuid}}
    When uri apollo/api/v1.0/payment
    And request
      """
      {
        "uuid": "{{uuid}}",
        "paymentDetails": {
          "totalAmount": {{amount}},
          "channelDetails": {
            "terminalId": "234020trm01",
            "retailerId": "234020"
          },
          "payments": [
            {
              "amount": {{amount}},
              "merchant": "TORA",
              "count": 1
            }
          ],
          "expiration": 0,
          "paymentProviderReferenceId": null,
          "paymentMethodType": "CARD",
           "playDetails": [
            {
              "businessVertical": "OPAP",
              "amount": 0,
              "count": 0
            }
          ]
        },
        "channel": "APOLLO",
        "userId": {{playerId}},
        "type": "PURCHASE"
      }
      """
    And method Post
    Then status 200
    * def transactionId in response.data.transactionId
    * def uuid in response.data.uuid
    And match response source = api-gateway
    And match response code = 1000
    And match response msg = success

  Scenario Outline:[2] Check digital payment Status WAIT_FROM_NATECH
    And path apollo/api/v1.0/payment/{transactionId}
    And pathParam transactionId = {{transactionId}}
    And header Authorization = Bearer {{intralotAccessToken}}
    And delay request 1000
    When method GET
    Then status 200
    And match response data.status = <status>
    And match response code = 1000
    And match response msg = success
    And match response source = api-gateway
    Examples:
      | status            |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |

  Scenario Outline:[3] Cancel digital payment
    And header GUID = {{uuid}}
    And path apollo/api/v1.0/payment/{{transactionId}}/cancel
    And delay request 1000
    When method POST
    Then status 200
    And match response data.status = <status>
    And match response code = 1000
    And match response msg = success
    And match response source = api-gateway
    * print {{transactionId}}
    Examples:
      | status     |
      | CANCELLED  |

  Scenario:[4] Digital Payment Finalize
    And User has natech token
    And url {{toraMiddlewareHost}}
    And path natech/api/v1.0/payment/{transactionId}/finalize
    And pathParam transactionId = {{transactionId}}
    And header Authorization = {{natechTokenType}} {{natechAccessToken}}
    And delay request 800
    And request
      """
      {
        "uuid": "{{uuid}}",
        "referenceId": "{{transactionId}}"
      }
      """
    And method POST
    Then status 500
    And match response success = false
    And match response code = 20003
    And match response msg = workflow instance {{transactionId}} was cancelled
    And match response failed = true
    * print {{transactionId}}


  Scenario:[6] Check digital payment Status CANCELLED
    And path apollo/api/v1.0/payment/{{transactionId}}
    And delay request 800
    When method GET
    Then status 500
    And match response success = false
    And match response code = 20003
    And match response msg = workflow instance {{transactionId}} was cancelled
    And match response failed = true
    * print {{transactionId}}