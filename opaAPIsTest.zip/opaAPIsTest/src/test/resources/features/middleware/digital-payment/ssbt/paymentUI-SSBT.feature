@regression @digitalPaymentSSBT @digitalPaymentSSBTcreate
@digitalPayment
@epic:digital-payement-ssbt
Feature: Create Digital Payment - SSBT - UI
 Background:
   When url {{middlewareHost}}
   And header Accept = application/json
   And header Content-Type = application/json
   When path ssbt/api/v1.0/digital-payment

  Scenario: Create payment
    Given User has janus token
    And header Authorization = {{janusTokenType}} {{janusToken}}
    And header GUID = {{uuid}}
    And request
      """
      {
        "uuid": "{{uuid}}",
        "paymentDetails": {
          "totalAmount": {{amount}},
          "channelDetails": {
            "terminalId": "{{ssbtid}}",
            "retailerId": "{{retailerid}}"
          },
          "payments": [
            {
              "amount": {{amount}},
              "merchant": "TORA",
              "count": 1
            }
          ],
          "expiration": 0,
          "paymentProviderReferenceId": null,
          "paymentMethodType": "CARD"
        },
        "paymentType": "PURCHASE",
        "channel": "SSBT",
        "userId": "Test",
        "type": "PURCHASE"
      }
      """
    And method POST
    Then status 200
    * def transactionId in response.data.transactionId
    * def uuid in response.data.uuid
    * def url in response.data.url
    And match response source = api-gateway
    And match response code = 1000
    And match response msg = success
    And match string {{url}} contains sid
    * extract host and query param sid from url url
    
  Scenario Outline: Check digital payment Status WAIT_FROM_TORA
    And path ssbt/api/v1.0/digital-payment/{transactionId}
    And pathParam transactionId = {{transactionId}}
    And delay request 100
    When method GET
    Then status 200
    And match response data.status = <status>
    And match response code = 1000
    And match response msg = success
    And match response source = api-gateway
    Examples:
      | status          |
      | WAIT_FROM_TORA  |
      | WAIT_FROM_TORA  |
      | WAIT_FROM_TORA  |

  Scenario: Get Tora wallet UI form payment
    Given url https://{{url}}
    And uri api/pay/sessions/{sid}
    And pathParam sid = {{sid}}
    When method get
    Then status 200
    * def pk in response.pk
    And Tora card payment

  Scenario Outline:[6] Check digital payment Status COMPLETED
    And path ssbt/api/v1.0/digital-payment/{{transactionId}}
    And delay request 800
    When method Get
    #When retry GET  until condition  { "bodyPath": "status", "hasValue": "<status>" }
    Then status 200
    And match path $.data.status should be = <status>
    And match response code = 1000
    And match response msg = success
    And match response source = api-gateway
    Examples:
      | status    |
      | COMPLETED  |