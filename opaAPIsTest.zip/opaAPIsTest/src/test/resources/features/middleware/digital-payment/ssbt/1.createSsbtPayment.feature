@digitalPaymentSSBT @digitalPaymentSSBTcreate
@digitalPayment
@epic:digital-payement-ssbt
Feature: Create Digital Payment - SSBT
Background:
  When url {{middlewareHost}}
  And header Content-Type = application/json

  Scenario: Create digital payment
      Given User has janus token
      And header Authorization = {{janusTokenType}} {{janusToken}}
      And header GUID = {{uuid}}
      When path ssbt/api/v1.0/digital-payment
      And request
      """
      {
        "uuid": "{{uuid}}",
        "paymentDetails": {
          "totalAmount": {{amount}},
          "channelDetails": {
            "terminalId": "{{ssbtid}}",
            "retailerId": "{{retailerid}}"
          },
          "payments": [
            {
              "amount": {{amount}},
              "merchant": "TORA",
              "count": 1
            }
          ],
          "expiration": 0,
          "paymentProviderReferenceId": null,
          "paymentMethodType": "CARD"
        },
        "paymentType": "PURCHASE",
        "channel": "SSBT",
        "userId": "Test",
        "type": "PURCHASE"
      }
      """
      And method POST
      Then status 200
      * def transactionId in response.data.transactionId
      * def uuid in response.data.uuid
      * def url in response.data.url
      And match response source = api-gateway
      And match response code = 1000
      And match response msg = success
      And match string {{url}} contains sid

  Scenario Outline: Check digital payment Status WAIT_FROM_TORA
    And path ssbt/api/v1.0/digital-payment/{transactionId}
    And pathParam transactionId = {{transactionId}}
    And delay request 100
    When method GET
    Then status 200
    And match response data.status = <status>
    And match response code = 1000
    And match response msg = success
    And match response source = api-gateway
    Examples:
      | status          |
      | WAIT_FROM_TORA  |
      | WAIT_FROM_TORA  |
      | WAIT_FROM_TORA  |

  Scenario: Digital Payment Finalize
    And url {{toraMiddlewareHost}}
    Given User has tora token
    And header Authorization = {{toraTokenType}} {{toraAccessToken}}
    And delay request 800
    When path tora/api/v1.0/payment/finalize
    And request
      """
      {
     "event_id":"evt_{{uuid}}",
     "event":"payment.purchased",
     "data":{
        "id":"pmt_{{uuid}}",
        "object":"payment",
        "captured":true,
        "amount":"{{amount}}",
        "currency":"EUR",
        "description":"SSBT PAYMENT - SSBT ID: {{ssbtid}} - WORKFLOWID:{{transactionId}}",
        "meta":{},
        "status":"captured",
        "merchant_reference":"{{transactionId}}",
        "customer":null,
        "method":"card",
        "method_info":{
           "holder_name":"TEST",
           "exp_year":2027,
           "exp_month":11,
           "last4":"9130",
           "brand":"master",
           "bin":"541333",
           "fingerprint":"15beb8fa2e11da480fdca085c629b1072bbfa56cd088fd4e7cb6bc76dc4b934c",
           "country":"GR",
           "issuer_name":"SANDBOX BANK",
           "card_type":"C",
           "consumer_type":"CN",
           "payment_account_reference":null,
           "provider":"torawallet"
        },
        "created_at": "{{timestamp}}",
        "updated_at":"{{timestamp}}",
        "captured_at":"{{timestamp}}",
        "refunded":false,
        "refunds":[],
        "refunded_amount":"0",
        "fee_amount":0,
        "error_code":null,
        "error_message":null,
        "transaction_id":"{{uuid}}",
        "provider":"torawallet"
     },
     "webhook_token":"hok_{{$randomPassword}}{{$randomAlphaNumeric}}{{$randomAlphaNumeric}}{{$randomAlphaNumeric}}{{$randomAlphaNumeric}}{{$randomAlphaNumeric}}"
      }
      """
    And method POST
    Then status 200
    And match
     """
     """

  Scenario Outline:[6] Check digital payment Status COMPLETED
    And path ssbt/api/v1.0/digital-payment/{{transactionId}}
    And delay request 800
    When method GET
    Then status 200
    And match response data.status = <status>
    And match response code = 1000
    And match response msg = success
    And match response source = api-gateway
    Examples:
      | status    |
      | COMPLETED  |