@regression @digitalPaymentAPOLLO @digitalPaymentAPOLLOcreate
@digitalPayment
@epic:TPR-2404-digital-payement-APOLLO
Feature:[2] Reject Digital Payment - APOLLO
  Background:
    When url {{middlewareHost}}
    And header Content-Type = application/json

  Scenario:[0] Create digital payment
    When User has Intralot token
    And header Authorization = Bearer {{intralotAccessToken}}
    And header x-authorization-system = Intralot
    And header GUID = {{uuid}}
    When uri apollo/api/v1.0/payment
    And request
      """
      {
        "uuid": "{{uuid}}",
        "paymentDetails": {
          "totalAmount": {{amount}},
          "channelDetails": {
            "terminalId": "234020trm01",
            "retailerId": "234020"
          },
          "payments": [
            {
              "amount": {{amount}},
              "merchant": "TORA",
              "count": 1
            }
          ],
          "expiration": 0,
          "paymentProviderReferenceId": null,
          "paymentMethodType": "CARD",
           "playDetails": [
            {
              "businessVertical": "OPAP",
              "amount": 0,
              "count": 0
            }
          ]
        },
        "channel": "APOLLO",
        "userId": {{playerId}},
        "type": "PURCHASE"
      }
      """
    And method Post
    Then status 200
    * def transactionId in response.data.transactionId
    * def uuid in response.data.uuid
    And match response source = api-gateway
    And match response code = 1000
    And match response msg = success

  Scenario Outline:[1] Check digital payment Status WAIT_FROM_NATECH
    And path apollo/api/v1.0/payment/{transactionId}
    And pathParam transactionId = {{transactionId}}
    And header Authorization = Bearer {{intralotAccessToken}}
    And delay request 1000
    When method GET
    Then status 200
    And match response data.status = <status>
    And match response code = 1000
    And match response msg = success
    And match response source = api-gateway
    Examples:
      | status            |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |

#  Scenario Outline: Digital Payment Finalize
#    And User has natech token
#    And url {{toraMiddlewareHost}}
#    And path natech/api/v1.0/payment/{transactionId}/finalize
#    And pathParam transactionId = {{transactionId}}
#    And header Authorization = {{natechTokenType}} {{natechAccessToken}}
#    And delay request 800
#    And request
#      """
#      {
#        "uuid": "{{uuid}}",
#        "referenceId": "{{transactionId}}"
#      }
#      """
#    And method POST
#    Then status 200
#    And match response data.status = <status>
#    And match response code = 1000
#    And match response msg = success
#    And match response source = api-gateway
#    Examples:
#      | status    |
#      | WAIT_FROM_APOLLO  |

  Scenario:[3] Digital Payment Finalize - Reject
    And User has natech token
    And url {{toraMiddlewareHost}}
    And path natech/api/v1.0/payment/{transactionId}/reject
    And pathParam transactionId = {{transactionId}}
    And header Authorization = {{natechTokenType}} {{natechAccessToken}}
    And delay request 800
    And request
      """
      {
        "uuid": "{{uuid}}",
        "transactionId": "{{transactionId}}",
        "rejectionReason": {
          "code": "10000",
          "reason": "BE test"
        }
      }
      """
    And method POST
    Then status 200
    And match response success = true
    And match response code = 1000
    * print {{transactionId}}


  Scenario:[4] Check digital payment Status Rejected
    And path apollo/api/v1.0/payment/{{transactionId}}
    And delay request 800
    When method GET
    Then status 500
    And match response success = false
    And match response code = 20005
    And match response msg = Payment has been rejected by the provider
    And match response failed = true
    * print {{transactionId}}


