@regression @digitalPaymentAPOLLO @digitalPaymentAPOLLOcreate
@digitalPayment
@epic:TPR-2404-digital-payement-APOLLO
Feature:[1] Create Digital Payment - APOLLO
  Background:
    When url {{middlewareHost}}
    And header Content-Type = application/json
    And header Accept = application/json

  Scenario:[1] Create payment - Apollo
      When User has Intralot token
      And header Authorization = Bearer {{intralotAccessToken}}
      And header x-authorization-system = Intralot
      And header GUID = {{uuid}}
      When uri apollo/api/v1.0/payment
      And request
      """
      {
        "uuid": "{{uuid}}",
        "paymentDetails": {
          "totalAmount": {{amount}},
          "channelDetails": {
            "terminalId": "234020trm01",
            "retailerId": "234020"
          },
          "payments": [
            {
              "amount": {{amount}},
              "merchant": "TORA",
              "count": 1
            }
          ],
          "expiration": 0,
          "paymentProviderReferenceId": null,
          "paymentMethodType": "CARD",
           "playDetails": [
            {
              "businessVertical": "OPAP",
              "amount": 0,
              "count": 0
            }
          ]
        },
        "channel": "APOLLO",
        "userId": {{playerId}},
        "type": "PURCHASE"
      }
      """
      And method Post
      Then status 200
      * def transactionId in response.data.transactionId
      * def uuid in response.data.uuid
      And match response source = api-gateway
      And match response code = 1000
      And match response msg = success


  Scenario Outline:[2] Check digital payment Status WAIT_FROM_NATECH
    And path apollo/api/v1.0/payment/{transactionId}
    And pathParam transactionId = {{transactionId}}
    And header Authorization = Bearer {{intralotAccessToken}}
    And delay request 1000
    When method GET
    Then status 200
    And match response data.status = <status>
    And match response code = 1000
    And match response msg = success
    And match response source = api-gateway
    Examples:
      | status            |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |
      | WAIT_FROM_NATECH  |

  Scenario Outline:[3] Digital Payment Finalize -> WAIT_FROM_APOLLO
    And User has natech token
    And url {{toraMiddlewareHost}}
    And path natech/api/v1.0/payment/{transactionId}/finalize
    And pathParam transactionId = {{transactionId}}
    And header Authorization = {{natechTokenType}} {{natechAccessToken}}
    And delay request 800
    And request
      """
      {
        "uuid": "{{uuid}}",
        "referenceId": "{{transactionId}}"
      }
      """
    And method POST
    Then status 200
    And match response data.status = <status>
    And match response code = 1000
    And match response msg = success
    And match response source = api-gateway
    Examples:
      | status            |
      | WAIT_FROM_APOLLO  |



  Scenario Outline:[4] Check digital payment Status Completed
    And path apollo/api/v1.0/payment/{transactionId}
    And pathParam transactionId = {{transactionId}}
    And header Authorization = Bearer {{intralotAccessToken}}
    And delay request 1000
    When method GET
    Then status 200
    And match response code = 1000
    And match path $.data.status should be #contains <status>
    And match path $.source should be #contains api-gateway
    Examples:
      | status  |
      | PAID    |


  Scenario Outline:[5] Check digital payment Status already completed
    And path apollo/api/v1.0/payment/{transactionId}
    And pathParam transactionId = {{transactionId}}
    And header Authorization = Bearer {{intralotAccessToken}}
    And delay request 1000
    When method GET
    Then status 500
    And match response code = 20001
    And match path $.msg should be #contains <status>
    And match path $.source should be #contains restate-connector
    Examples:
      | status             |
      | already completed  |

#  Scenario Outline:[6] Check digital payment report
#    And path apollo/api/v1.0/report/{transactionId}
#    And pathParam transactionId = {{transactionId}}
#    And header Authorization = Bearer {{intralotAccessToken}}
#    And delay request 1000
#    When method GET
#    Then status 500
#    And match response code = 20002
#    And match path $.msg should be #contains <status>
#    And match path $.source should be #contains restate-connector
#    Examples:
#      | status    |
#      | Payment has expired  |