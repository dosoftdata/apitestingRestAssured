@regression @casino
@epic:MID-106-Casino
Feature: MID-132 - Trending Now
  https://opapgr.atlassian.net/browse/MID-132
  
  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header Accept = application/json
    And header locale = el-GR
    #And param location = base
    When path uip/casino/api/v1.0/games/trending

  Scenario: Trending Now
    And param location = base
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
      "data": [
        {
            "href": "#any",
            "id": "#any",
            "name": "#any",
            "launchUrl": "#any",
            "backgroundImageUrl": "#any",
            "popularity": "#any",
            "isNew": "#boolean",
            "width": "#any",
            "height": "#any",
            "hasFunMode": "#boolean",
            "hasAnonymousFunMode": "#boolean",
            "thumbnail": "#any",
            "subVendor": "#any",
            "subVendorId": "#any",
            "subVendorDisplayName": "#any",
            "defaultThumbnail": "#any",
            "type": "#any",
            "minBet": "#any",
            "maxWin": "#any",
            "volatility": "#any",
            "liveCasinoCategory": "#any",
            "advancedTags": "#any",
            "logo": "#any",
            "slug": "#any",
            "theoreticalPayOut": "#any",
            "alias": "#any",
            "cellSize": "#any",
            "isVIPTable": "#any",
            "platform": "#any",
            "maxBetRestriction": "#any",
            "position": "#any",
            "groups": "#any",
            "subGroups": "#any",
           "groupInfos": "#any",
            "vendor": {
                "href": "#any"
            },
            "tags": "#any",
            "categories": "#any",
            "jackpots": "#any",
            "details": "#any",
            "promo": "#any",
            "exclusive": "#any",
            "gameCode": "#any",
            "ruleUrl": "#any",
            "helpUrl":  "#any",
            "languages": "#any",
            "currencies": "#any",
            "realMode": "#any",
            "license": "#any",
             "minHitFrequency": "#any",
            "maxHitFrequency":"#any",
            "jackpotContribution": "#any",
            "evolutionGamingTableID": "#any",
            "vendorGameID": "#any",
            "restrictedTerritories": "#any",
            "lobby": "#any",
             "gameId": "#any",
            "thumbnails": "#any",
            "fpp": "#any",
            "bonusContribution": "#any",
            "icons": "#any",
            "gid": "#any"
        }
     ]
     }
     """
    And match path $.data[*].type should be #contains casino
    And match path $.data[*].platform should be #contains PC
    And match path $.data[*].href should be #contains everymatrix

  Scenario: Trending Now - player id as "#any" string
    And param location = base
    And header x-player-id = ""
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains For input string: ""
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Trending Now - player id hack
    And param location = base
    And header x-player-id = 99999999999999999999999
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains 99999999999999999999999
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Trending Now - no location
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains System Error: Required request parameter 'location'
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Trending Now - no location - no player id
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains System Error: Required request parameter 'location'
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001



