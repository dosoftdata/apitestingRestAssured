@regression @casino @MID-129 @middleware
@epic:MID-106-Casino
Feature: MID-129 - Favorite Vendor
  https://opapgr.atlassian.net/browse/MID-129

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Accept = application/json
    And header Content-Type = application/json
    And header locale = el-GR
    * def retryPattern = { "minutes": 1,"seconds" : 30,"pollMillis":5000,"status": 200 }
    When uri uip/casino/api/v1.0/vendors/favorite

  @smoke
  Scenario Outline: Favorite Vendor - default channel PC
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition  {{retryPattern}}
    Then status 200
    And match
     """
       {
       "data": {
            "gamesCount": "#any",
            "gamesTotal": "#any",
            "isTopVendor": "#any",
            "ordinal": null,
            "href": "#string",
            "id": "#any",
            "name": "#any",
            "enabled": "#any",
            "displayName": "#any",
            "image": "#any",
            "logo": "#any",
            "subVendors": "#array",
            "games": "#object"
         }
      }
     """
    And match path $.data.gamesCount should be != 0
    #
      # And match path $.data.href should be #contains platform
   # And match path $.data.href should be #contains language
    #And match path $.data.href should be #contains <channel>
    And match path $.data.href should be #contains everymatrix
    Examples:
        |testId       | location | channel  |
        | MID-129     |  base    |  PC      |
        | MID-129     |  ""      |  PC      |
        | MID-129     |  unknown |  PC      |

  Scenario Outline: Favorite Vendor - channel PC,iPhone,iPad, Android
    And header channel = <channel>
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {{retryPattern}}
    Then status 200
    And match
     """
       {
       "data": {
            "gamesCount": "#any",
            "gamesTotal": "#any",
            "isTopVendor": "#any",
            "ordinal": null,
            "href": "#any",
            "id": "#any",
            "name": "#any",
            "enabled": "#any",
            "displayName": "#any",
            "image": "#any",
            "logo": "#any",
            "subVendors": "#array",
            "games": "#object"
         }
      }
     """
    And match path $.data.gamesCount should be != 0
    #And match path $.data.href should be #contains platform
    #And match path $.data.href should be #contains language
    #And match path $.data.href should be #contains <channel>
    And match path $.data.href should be #contains everymatrix

    Examples:
      |testId       | location | channel      |
      | MID-129     |  base    |  PC          |
      | MID-129     |  base    |  iPhone      |
      | MID-129     |  base    |  iPad        |
      | MID-129     |  base    |  Android     |

  Scenario Outline: Favorite Vendor - Wrong channel
    And header channel = <channel>
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition  {{retryPattern}}
    Then status 200
    And match
     """
       {
       "data": {
            "gamesCount": "#any",
            "gamesTotal": "#any",
            "isTopVendor": "#any",
            "ordinal": null,
            "href": "#any",
            "id": "#any",
            "name": "#any",
            "enabled": "#any",
            "displayName": "#any",
            "image": "#any",
            "logo": "#any",
            "subVendors": "#array",
            "games": "#object"
         }
      }
     """
    And match path $.data.gamesCount should be != 0
    #And match path $.data.href should be #contains platform
    #And match path $.data.href should be #contains language
    #And match path $.data.href should be #contains <channel>
    And match path $.data.href should be #contains everymatrix

    Examples:
      |testId       | location | channel   |
      | MID-129     |  base    |   test    |
      | MID-129     |  base    |  Unknown  |
      | MID-129     |  base    |  <script> |

#  Scenario Outline: Favorite Vendor - Wrong channel script - Security
#    And header channel = <channel>
#    And param location = <location>
#    And header x-player-id = {{playerId}}
#    And retry GET  until condition {{retryPattern}}
#    Then status 500
#    And match path $.msg should be #contains Api Gw Rest Client error
#    And match path $.source should be #contains EveryMatrixConnector
#    And match path $.code should be = 5003
#
#    Examples:
#      |testId       | location | channel   |
#      | MID-129     |  base    |  <script> |

  Scenario: Favorite Vendor - player id as null string
    And param location = base
    And header x-player-id = ""
    And retry GET  until condition  { "status": 500 }
    Then status 500
    And match path $.msg should be #contains For input string: ""
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Favorite Vendor - player id hack
    And param location = base
    And header x-player-id = 99999999999999999999999
    And retry GET  until condition  { "status": 500 }
    Then status 500
    And match path $.msg should be #contains 99999999999999999999999
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Favorite Vendor - no player id
    And param location = base
    And retry GET  until condition { "status": 500 }
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Favorite Vendor - no location
    And header x-player-id = {{playerId}}
    And retry GET  until condition { "status": 500 }
    Then status 500
    And match path $.msg should be #contains System Error: Required request parameter 'location'
