@regression @casino
@epic:MID-106-Casino
Feature: MID-131 - Because You Played
  https://opapgr.atlassian.net/browse/MID-131
  
  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Content-Type = application/json
    And header locale = el-GR
    When path uip/casino/api/v1.0/games/similar

  Scenario: Because You Played
    And Get Casino Favorite Games in base location
    And param location = base
    And param gameIds = {{casinoFavoriteGames}}
    And header x-player-id = {{playerId}}
    #And delay request 1000
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
      "data": [
        {
            "href": "#string",
            "id": "#string",
            "name": "#string",
            "launchUrl": "#string",
            "backgroundImageUrl": "#string",
            "popularity": "#any",
            "isNew": "#boolean",
            "width": "#any",
            "height": "#any",
            "hasFunMode": "#boolean",
            "hasAnonymousFunMode": "#boolean",
            "thumbnail": "#string",
            "subVendor": "#string",
            "subVendorId": "#any",
            "subVendorDisplayName": "#any",
            "defaultThumbnail": "#string",
            "type": "casino-games",
            "minBet": "#any",
            "maxWin": "#any",
            "volatility": "#any",
            "liveCasinoCategory": "#any",
            "advancedTags": "#any",
            "logo": "#string",
            "slug": "#string",
            "theoreticalPayOut": "#any",
            "alias": "#any",
            "cellSize": "#any",
            "isVIPTable": "#any",
            "platform": "#any",
            "maxBetRestriction": "#any",
            "position": "#any",
            "groups": "#any",
            "subGroups": "#any",
           "groupInfos": "#any",
            "vendor": {
                "href": "#string"
            },
            "tags": "#any",
            "categories": "#any",
            "jackpots": "#any",
            "details": "#any",
            "promo": "#any",
            "exclusive": "#any",
            "gameCode": "#string",
            "ruleUrl": "#any",
            "helpUrl":  "#string",
            "languages": "#any",
            "currencies": "#any",
            "realMode": "#any",
            "license": "#string",
             "minHitFrequency": "#any",
            "maxHitFrequency":"#any",
            "jackpotContribution": "#any",
            "evolutionGamingTableID": "#any",
            "vendorGameID": "#string",
            "restrictedTerritories": "#any",
            "lobby": "#any",
             "gameId": "#any",
            "thumbnails": "#any",
            "fpp": "#any",
            "bonusContribution": "#any",
            "icons": "#any",
            "gid": "#any"
        }
     ]
     }
     """
    And match path $.data[*].href should be #contains everymatrix
    And match path $.data[*].platform should be #contains PC
    Then match response time should be less than 60000 milliseconds


  Scenario: Because You Played - no player id
    And param location = base
    And param gameIds = {{casinoFavoriteGames}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
      "data": [
        {
            "href": "#string",
            "id": "#string",
            "name": "#string",
            "launchUrl": "#string",
            "backgroundImageUrl": "#string",
            "popularity": "#any",
            "isNew": "#boolean",
            "width": "#any",
            "height": "#any",
            "hasFunMode": "#boolean",
            "hasAnonymousFunMode": "#boolean",
            "thumbnail": "#string",
            "subVendor": "#string",
            "subVendorId": "#any",
            "subVendorDisplayName": "#any",
            "defaultThumbnail": "#string",
            "type": "casino-games",
            "minBet": "#any",
            "maxWin": "#any",
            "volatility": "#any",
            "liveCasinoCategory": "#any",
            "advancedTags": "#any",
            "logo": "#string",
            "slug": "#string",
            "theoreticalPayOut": "#any",
            "alias": "#any",
            "cellSize": "#any",
            "isVIPTable": "#any",
            "platform": "#any",
            "maxBetRestriction": "#any",
            "position": "#any",
            "groups": "#any",
            "subGroups": "#any",
           "groupInfos": "#any",
            "vendor": {
                "href": "#string"
            },
            "tags": "#any",
            "categories": "#any",
            "jackpots": "#any",
            "details": "#any",
            "promo": "#any",
            "exclusive": "#any",
            "gameCode": "#string",
            "ruleUrl": "#any",
            "helpUrl":  "#string",
            "languages": "#any",
            "currencies": "#any",
            "realMode": "#any",
            "license": "#string",
             "minHitFrequency": "#any",
            "maxHitFrequency":"#any",
            "jackpotContribution": "#any",
            "evolutionGamingTableID": "#any",
            "vendorGameID": "#string",
            "restrictedTerritories": "#any",
            "lobby": "#any",
             "gameId": "#any",
            "thumbnails": "#any",
            "fpp": "#any",
            "bonusContribution": "#any",
            "icons": "#any",
            "gid": "#any"
        }
     ]
     }
     """
    And match path $.data[*].href should be #contains everymatrix
    Then match response time should be less than 60000 milliseconds

  Scenario: Because You Played - unknown game
    And param location = base
    And param gameIds = x99999999
    #And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains No similar games found for player: 0 and games: x99999999
    And match path $.source should be #contains api-gateway-gr
    And match path $.code should be = 10006



  Scenario: Because You Played - player id as "#null" string
    And param location = base
    And header x-player-id = ""
    And param gameIds = {{casinoFavoriteGames}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains For input string: ""
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Because You Played - player id hack
    And param location = base
    And param gameIds = {{casinoFavoriteGames}}
    And header x-player-id = 99999999999999999999999
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains 99999999999999999999999
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001



  Scenario: Because You Played - no game id
    And param location = base
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'gameIds'
    And match path $.source should be #contains api-gateway-gr
    And match path $.code should be = 1001

  Scenario: Because You Played - invalid game id
    And param location = base
    And param gameIds = 99999999999999999999999
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains No similar games found for player: {{playerId}} and games: 99999999999999999999999
    And match path $.source should be #contains api-gateway-gr
    And match path $.code should be = 10006

  Scenario: Because You Played - null game id
    And param location = base
    And param gameIds = ""
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains No similar games found for player: {{playerId}} and games: ""
    And match path $.source should be #contains api-gateway-gr
    And match path $.code should be = 10006

  Scenario: Because You Played - no location
    And header x-player-id = {{playerId}}
    And param gameIds = {{casinoFavoriteGames}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains System Error: Required request parameter 'location'
    And match path $.source should be #contains api-gateway-gr
    And match path $.code should be = 1001

