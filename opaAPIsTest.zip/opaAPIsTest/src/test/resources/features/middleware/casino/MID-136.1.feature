@regression @casino
@epic:MID-106-Casino
Feature: MID-136.1 - Because You Liked: 3 -tag

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header Accept = application/json
    And header locale = en_US
    When path uip/casino/api/v1.0/game_tag/recommended

  Scenario Outline: Because You Liked: 3 - tag
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
        "href": "#string",
        "id": "#string",
        "name": "#string"
        }
      }
     """
    And match path $.data[*].href should be #contains everymatrix
    Then match response time should be less than 60000 milliseconds
    Examples:
      |testId       | location |
      | MID-136     |  base    |
#      | MID-136     |  ""      |
#      | MID-136     |  unknown |


  Scenario: Because You Liked: 3 tag- player id as "#any" string
    And param location = base
    And header x-player-id = ""
   # And param gameIds = 49259,49122
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains For input string: ""
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Because You Liked: 3 tag - player id hack
    And param location = base
    And header x-player-id = 99999999999999999999999
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains 99999999999999999999999
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001


  Scenario: Because You Liked: 3 - no location
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains System Error: Required request parameter 'location'
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001


