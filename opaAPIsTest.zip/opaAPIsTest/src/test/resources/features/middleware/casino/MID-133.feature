@regression @casino
@epic:MID-106-Casino
Feature: MID-133 - Popular
  https://opapgr.atlassian.net/browse/MID-133
  
  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header Accept = application/json
    And header locale = el-GR
    When path uip/casino/api/v1.0/games/popular

  Scenario: Popular games
    And param location = top_ten_region
    #And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
      "data": [
        {
            "href": "#any",
            "id": "#any",
            "name": "#any",
            "launchUrl": "#any",
            "backgroundImageUrl": "#any",
            "popularity": "#any",
            "isNew": "#boolean",
            "width": "#any",
            "height": "#any",
            "hasFunMode": "#boolean",
            "hasAnonymousFunMode": "#boolean",
            "thumbnail": "#any",
            "subVendor": "#any",
            "subVendorId": "#any",
            "subVendorDisplayName": "#any",
            "defaultThumbnail": "#any",
            "type": "#any",
            "minBet": "#any",
            "maxWin": "#any",
            "volatility": "#any",
            "liveCasinoCategory": "#any",
            "advancedTags": "#any",
            "logo": "#any",
            "slug": "#any",
            "theoreticalPayOut": "#any",
            "alias": "#any",
            "cellSize": "#any",
            "isVIPTable": "#any",
            "platform": "#any",
            "maxBetRestriction": "#any",
            "position": "#any",
            "groups": "#any",
            "subGroups": "#any",
           "groupInfos": "#any",
            "vendor": {
                "href": "#any"
            },
            "tags": "#any",
            "categories": "#any",
            "jackpots": "#any",
            "details": "#any",
            "promo": "#any",
            "exclusive": "#any",
            "gameCode": "#any",
            "ruleUrl": "#any",
            "helpUrl":  "#any",
            "languages": "#any",
            "currencies": "#any",
            "realMode": "#any",
            "license": "#any",
             "minHitFrequency": "#any",
            "maxHitFrequency":"#any",
            "jackpotContribution": "#any",
            "evolutionGamingTableID": "#any",
            "vendorGameID": "#any",
            "restrictedTerritories": "#any",
            "lobby": "#any",
             "gameId": "#any",
            "thumbnails": "#any",
            "fpp": "#any",
            "bonusContribution": "#any",
            "icons": "#any",
            "gid": "#any"
        }
     ]
     }
     """
    And match path $.data[*].type should be #contains casino
    And match path $.data[*].platform should be #contains PC
    And match path $.data[*].href should be #contains everymatrix

  Scenario: Popular - player id as "" string
    And param location = base
    And header x-player-id = ""
    And param gameIds = 49259,49122
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains For input string: ""
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Popular - player id hack
    And param location = base
    And header x-player-id = 99999999999999999999999
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains 99999999999999999999999
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001

  Scenario: Popular - no location
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains System Error: Required request parameter 'location'
    And match path $.source should be #contains api-gateway
    And match path $.code should be = 1001




