@regression @opta @middleware
@epic:TPR-3344-OPTA
Feature: contestant season expected goals

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Accept = application/json
    And header Content-Type = application/json
    And header locale = el-GR
    When uri uip/sportsbook/api/v1.0/stats/contestant/season/expected/goals
    And param ctst = 3czravw89omgc9o4s0w3l1bg5
    And header GUID = {{uuid}}

  Scenario: contestant season expected goals
    And param tmcl = 80zg2v1cuqcfhphn56u4qpyqc
    And retry GET  until condition  {}
    Then status 200
    And match
     """
     {
       "contestant": {
          "id": "#string",
          "name": "#string",
          "stat": "#array"
          }
     }
     """

  Scenario: contestant season expected goals - wrong tournament Id
    And param tmcl = 1234567
    And retry GET  until condition  {}
    Then status 500
    And match path $.code should be = 5003
    And match path $.success should be = false
    And match path $.failed should be = true

  Scenario: contestant season expected goals - missed tournament Id
    And param tmcl = ''
    And retry GET  until condition  {}
    Then status 500
    And match path $.code should be = 5003
    And match path $.success should be = false
    And match path $.failed should be = true
