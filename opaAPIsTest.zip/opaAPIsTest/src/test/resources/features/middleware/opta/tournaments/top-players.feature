@regression @opta @middleware
@epic:TPR-3344-OPTA
Feature: Tournament Top players

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Accept = application/json
    And header Content-Type = application/json
    And header locale = el-GR
    When uri uip/sportsbook/api/v1.0/stats/tournament/players/top
    #And param ctst = 3czravw89omgc9o4s0w3l1bg5
    And header GUID = {{uuid}}

  Scenario: Tournament Top players
    And param tmcl = 80zg2v1cuqcfhphn56u4qpyqc
    And retry GET  until condition  {}
    Then status 200
    And match
     """
     {
      "data": {
        "ranking": "#array"
        }
      }
     """
    And match each $.data.ranking[*] should match
      """
         {
            "name": "#string",
            "player": "#array"
          }
      """
    And match each $.data.ranking[*].player[*] should match
      """
          {
            "contestantId": "#string",
            "contestantName": "#string",
            "id": "#string",
            "firstName": "#string",
            "lastName": "#string",
            "shortFirstName": "#string",
            "shortLastName": "#string",
            "matchName": "#string",
            "rank": "#number",
            "value": "#number"
          }
      """
  Scenario: Tournament Top players - wrong tournament Id
    And param tmcl = 1234567
    And retry GET  until condition  {}
    Then status 500
    And match path $.code should be = 5003
    And match path $.success should be = false
    And match path $.failed should be = true

  Scenario: Tournament Top players - missed tournament Id
    And param tmcl = ''
    And retry GET  until condition  {}
    Then status 500
    And match path $.code should be = 5003
    And match path $.success should be = false
    And match path $.failed should be = true