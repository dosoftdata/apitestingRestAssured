@regression @opta @middleware
@epic:TPR-3344-OPTA
Feature: contestant Past Results

  Scenario: contestant Past Results
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Accept = application/json
    And header Content-Type = application/json
    And header GUID = {{uuid}}
    * def pastResultsUri = uip/sportsbook/api/v1.0/stats/contestant/past-results

    When uri {{pastResultsUri}}
    And param ctst = 3czravw89omgc9o4s0w3l1bg5
    And param tmcl = 80zg2v1cuqcfhphn56u4qpyqc
    And retry GET  until condition  {}
    Then status 200
    And match each $.data[*] should match
     """
         {
            "id": "#string",
            "startDate": "#any",
            "teams": "#array",
            "stats": "#array",
            "matchResult": "#string"
        }
     """

    # contestant Past Results - wrong tournament Id
    When set Url {{psMiddlewareHost}}
    And set header Connection = keep-alive
    And set header Accept = application/json
    And set header Content-Type = application/json
    And set header GUID = {{uuid}}
    When add uri {{pastResultsUri}}
    And add param ctst = 3czravw89omgc9o4s0w3l1bg5
    And add param tmcl = 1234567
    And set method get
    Then status 500
    And match path $.code should be = 5003
    And match path $.success should be = false
    And match path $.failed should be = true

    # contestant Past Results - missed tournament Id
    When set Url {{psMiddlewareHost}}
    And set header Connection = keep-alive
    And set header Accept = application/json
    And set header Content-Type = application/json
    And set header GUID = {{uuid}}
    When add uri {{pastResultsUri}}
    And add param ctst = 3czravw89omgc9o4s0w3l1bg5
    And add param tmcl = ''
    And set method get
    Then status 500
    And match path $.code should be = 5003
    And match path $.success should be = false
    And match path $.failed should be = true

