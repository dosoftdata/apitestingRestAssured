@regression @opta @middleware
@epic:TPR-3344-OPTA
Feature: Tournament standings

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Accept = application/json
    And header Content-Type = application/json
    And header locale = el-GR
    When uri uip/sportsbook/api/v1.0/stats/tournament/standings
    #And param ctst = 3czravw89omgc9o4s0w3l1bg5
    And header GUID = {{uuid}}

  Scenario: Tournament standings
    And param tmcl = 80zg2v1cuqcfhphn56u4qpyqc
    And retry GET  until condition  {}
    Then status 200
    And match
     """
         {
        "data": [
          {
            "type": "#string",
            "ranking": [
              {
                "rank": "#number",
                "rankStatus":"##string",
                "rankId": "##string",
                "contestantId": "#string",
                "contestantName": "#string",
                "contestantShortName": "#string",
                "contestantClubName": "#string",
                "contestantCode": "#string",
                "points":  "#number",
                "matchesPlayed":  "#number",
                "matchesWon":  "#number",
                "matchesLost":  "#number",
                "matchesDrawn":  "#number",
                "goalsFor":  "#number",
                "goalsAgainst":  "#number",
                "goaldifference":  "#number"
              }
            ]
          }
        ]
      }
     """

  Scenario: Tournament standings - wrong tournament Id
    And param tmcl = 1234567
    And retry GET  until condition  {}
    Then status 500
    And match path $.code should be = 5003
    And match path $.success should be = false
    And match path $.failed should be = true

  Scenario: Tournament standings - missed tournament Id
    And param tmcl = ''
    And retry GET  until condition  {}
    Then status 500
    And match path $.code should be = 5003
    And match path $.success should be = false
    And match path $.failed should be = true