@regression @opta @middleware
@epic:TPR-3344-OPTA
Feature: Tournament Schedule

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Accept = application/json
    And header Content-Type = application/json
    And header locale = el-GR
    When uri uip/sportsbook/api/v1.0/stats/tournament/schedule
    And param ctst = 3czravw89omgc9o4s0w3l1bg5
    And header GUID = {{uuid}}

  Scenario: Tournament Schedule
    And param tmcl = 80zg2v1cuqcfhphn56u4qpyqc
    And retry GET  until condition  {}
    Then status 200
    And match
     """
     { "matchDate": "#array" }
     """

  Scenario: Tournament Schedule - wrong tournament Id
    And param tmcl = 1234567
    And retry GET  until condition  {}
    Then status 500
    And match path $.code should be = 5003
    And match path $.success should be = false
    And match path $.failed should be = true

  Scenario: Tournament Schedule - missed tournament Id
    And param tmcl = ''
    And retry GET  until condition  {}
    Then status 500
    And match path $.code should be = 5003
    And match path $.success should be = false
    And match path $.failed should be = true