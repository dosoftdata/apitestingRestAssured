@world_cup
@regression
@world_cup_coverage
@epic:SBRET-2792-Instant-win

Feature: Instant Win for WC - coverage
  https://opapgr.atlassian.net/browse/SBRET-2792

  Background:
    Given url {{middlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header Accept = application/json
    And header Authorization = Bearer 54d90941-cf57-4220-acfb-d754bbf6fde2

  Scenario: [0] create campaign - with null backetId | coverage
    And Set Instant Win test data
    And uri api/draw/campaigns/create
    * def campaignId = {{$random10Digit}}
    And request
      """
      {
        "campaignId": "C{{campaignId}}",
        "name": "Test Campaign - {{campaignId}}",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 10,
        "buckets": [
          {
            "bucketId": "",
            "totalWinners": 2
          },
         {
            "bucketId": "medium",
            "totalWinners": 1
          },
      {
            "bucketId": "grand",
            "totalWinners": 3
          }
        ]
      }
      """

    When method post
    Then status 400 or 201
    And match
    """

    """
  Scenario: [1] create campaign - totalWinners = 0 | coverage
    And Set Instant Win test data
    And uri api/draw/campaigns/create
    * def campaignId = {{$random10Digit}}
    And request
      """
      {
        "campaignId": "C{{campaignId}}",
        "name": "Test Campaign - {{campaignId}}",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 0,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 0
          },
         {
            "bucketId": "medium",
            "totalWinners": 0
          },
      {
            "bucketId": "grand",
            "totalWinners": 0
          }
        ]
      }
      """

    When method post
    Then status 400
    And match path $.error should be #contains No fraction rule found for totalWinners 0

  Scenario: [2] create campaign | coverage
    And uri api/draw/campaigns/create
    And request
      """
      {
        "campaignId": "C{{campaignId}}",
        "name": "Test Campaign - {{campaignId}}",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 0,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 100
          },
         {
            "bucketId": "medium",
            "totalWinners": 10
          },
      {
            "bucketId": "grand",
            "totalWinners": 1
          }
        ]
      }
      """

    When method post
    Then status 201
    And match
     """

     """

  Scenario:[3] update campaign | coverage
    And uri api/draw/campaigns/update/C{{campaignId}}
    And request
      """
      {
        "campaignId": "C{{campaignId}}",
        "name": "Test Campaign - {{campaignId}}",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 1,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 100
          },
         {
            "bucketId": "medium",
            "totalWinners": 10
          },
      {
            "bucketId": "grand",
            "totalWinners": 1
          }
        ]
      }
      """
    When method put
    Then status 204
    And match
    """

    """

  Scenario:[4] get campaign by id | coverage
    And uri api/draw/campaigns/C9049272353
    When method get
    Then status 200
    And match
      """
        {
            "campaignId": "#string",
            "name": "#string",
            "start": "#datetime",
            "end": "#datetime",
            "buckets": [
                {
                    "bucketId": "#string",
                    "totalWinners": "#number",
                    "minFraction": "#number",
                    "maxFraction": "#number",
                    "prizes": "#array"
                }
            ]
        }
      """

  Scenario:[5] get campaign status | coverage
    And uri api/draw/campaigns/C{{campaignId}}/status
    When method get
    Then status 200
    And match
    """
    {
    "campaignId": "C{{campaignId}}",
    "buckets": [
        {
            "bucketId": "small",
            "totalPrizes": 100,
            "remainingPrizes": 100,
            "winnersAllocated": 0,
            "consumedPercentage": 0.0
        },
        {
            "bucketId": "medium",
            "totalPrizes": 10,
            "remainingPrizes": 10,
            "winnersAllocated": 0,
            "consumedPercentage": 0.0
        },
        {
            "bucketId": "grand",
            "totalPrizes": 1,
            "remainingPrizes": 1,
            "winnersAllocated": 0,
            "consumedPercentage": 0.0
        }
    ]
    }
    """

  Scenario:[6] place bet in campaign - campaign started
    And uri api/draw/service/bet
    And delay request 200000
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": true,
      "bucketId": "small"
     }
     """

  Scenario:[7] place bet in campaign - same user
    And uri api/draw/service/bet
    And delay request 100
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": true,
      "bucketId": "small"
     }
     """

  Scenario:[8] place bet in campaign - other user
    And uri api/draw/service/bet
    And delay request 100
    And request
      """
      {
        "betId": "{{uuid}}",
        "campaignId": "C{{campaignId}}",
        "playerId": "{{playerId}}"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": true,
      "bucketId": "small"
     }
     """

  Scenario:[9] get campaign status
    And uri api/draw/campaigns/C{{campaignId}}/status
    When method get
    Then status 200
    And match path $.buckets[0].remainingPrizes should be = 98

  Scenario:[10] campaign has started it cannot be modified
    And uri api/draw/campaigns/update/C{{campaignId}}
    And request
      """
      {
        "campaignId": "C{{campaignId}}",
        "name": "Test Campaign - {{campaignId}}",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 10,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 100
          },
         {
            "bucketId": "medium",
            "totalWinners": 10
          },
      {
            "bucketId": "grand",
            "totalWinners": 1
          }
        ]
      }
      """

    When method put
    Then status 400
    And match path $.error should be #contains Campaign C{{campaignId}} has already started and cannot be updated

  Scenario:[11] place bet in campaign - after expiration
    And uri api/draw/service/bet
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": true,
      "bucketId": "#any"
     }
     """

  Scenario:[12] get All campaign
    And uri api/draw/campaigns
    When method get
    Then status 200
    And match
      """
      [
        {
            "campaignId": "#string",
            "name": "#string",
            "start": "#datetime",
            "end": "#datetime",
            "buckets": [
                {
                    "bucketId": "#string",
                    "totalWinners": "#number",
                    "minFraction": "#number",
                    "maxFraction": "#number",
                    "prizes": "#array"
                }
            ]
        }
      ]
      """

  Scenario:[13] get campaign status
    And uri api/draw/campaigns/C{{campaignId}}/status
    When method get
    Then status 200
    And match path $.buckets[0].remainingPrizes should be = 98

  Scenario: [01] create campaign with missed compaignId in request body string
    And uri api/draw/campaigns/create
    And request
      """
      {
        "name": "Test Campaign - {{campaignId}}",
        "start": "2050-03-16T12:00",
        "end": "2050-03-16T13:00",
        "timeExtensionMins": 0,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 1
          },
         {
            "bucketId": "medium",
            "totalWinners": 1
          },
      {
            "bucketId": "grand",
            "totalWinners": 1
          }
        ]
      }
      """

    When method post
    Then status 400
    And match path $.error should be #contains campaignId not found in request


  Scenario: [0001] create campaign with existing campaign id
    And uri api/draw/campaigns/create
    And request
      """
      {
        "campaignId": "C{{$random10Digit}}",
        "name": "Test Campaign - C{{$random10Digit}}",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 0,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 0
          },
         {
            "bucketId": "medium",
            "totalWinners": 0
          },
      {
            "bucketId": "grand",
            "totalWinners": 0
          }
        ]
      }
      """

    When method post
    Then status 400
    And match path $.error should be #contains Campaign C{{$random10Digit}} already exists


  Scenario:[02] update campaign
    And uri api/draw/campaigns/update/C8681567838
    And request
      """
      {
        "name": "Test Campaign - C8681567838",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 5,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 100
          },
         {
            "bucketId": "medium",
            "totalWinners": 10
          },
      {
            "bucketId": "grand",
            "totalWinners": 1
          }
        ]
      }
      """
    When method put
    Then status 400
    And match path $.error should be #contains campaignId not found in request


  Scenario: [002] create campaign with empty companyId | coverage
    And Set Instant Win test data
    And uri api/draw/campaigns/create
    And request
      """
      {
        "campaignId": "",
        "name": "Test Campaign - {{campaignId}}",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 0,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 100
          },
         {
            "bucketId": "medium",
            "totalWinners": 10
          },
      {
            "bucketId": "grand",
            "totalWinners": 1
          }
        ]
      }
      """

    When method post
    Then status 400
    And match path $.error should be #contains campaignId not found in request

  Scenario:[003] get All campaign
    And uri api/draw/campaigns
    When method get
    Then status 200
    And match
      """
      [
        {
            "campaignId": "#string",
            "name": "#string",
            "start": "#datetime",
            "end": "#datetime",
            "buckets": [
                {
                    "bucketId": "#string",
                    "totalWinners": "#number",
                    "minFraction": "#number",
                    "maxFraction": "#number",
                    "prizes": "#array"
                }
            ]
        }
      ]
      """

  Scenario: [004] create campaign - double bucketId
    And Set Instant Win test data
    And uri api/draw/campaigns/create
    And def campaignId = {{$random10Digit}}
    And request
      """
      {
        "campaignId": "C{{campaignId}}",
        "name": "Test Campaign - {{campaignId}}",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 0,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 10
          },
         {
            "bucketId": "grand",
            "totalWinners": 10
          },
      {
            "bucketId": "grand",
            "totalWinners": 10
          }
        ]
      }
      """

    When method post
    Then status 400
    And match path $.error should be #contains Duplicate bucketId values are not allowed