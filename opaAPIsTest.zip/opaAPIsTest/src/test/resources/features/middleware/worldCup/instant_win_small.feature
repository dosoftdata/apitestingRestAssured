@world_cup
@regression
@epic:SBRET-2792-Instant-win

Feature: Instant Win for WC - small
  https://opapgr.atlassian.net/browse/SBRET-2792

  Background:
    Given url {{middlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header Accept = application/json
    And header Authorization = Bearer 54d90941-cf57-4220-acfb-d754bbf6fde2

  Scenario: [1] create campaign - small
    And Set Instant Win test data
    And uri api/draw/campaigns/create
    And def campaignId = {{$random10Digit}}
    And request
      """
      {
        "campaignId": "C{{campaignId}}",
        "name": "Test Campaign - {{campaignId}}",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 0,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 100
          },
         {
            "bucketId": "medium",
            "totalWinners": 10
          },
      {
            "bucketId": "grand",
            "totalWinners": 1
          }
        ]
      }
      """

    When method post
    Then status 201
    And match
     """

     """

  Scenario:[2] get campaign status before place bet - small
    And uri api/draw/campaigns/C{{campaignId}}/status
    When method get
    Then status 200
    And match path $.buckets[0].remainingPrizes should be = 100

  Scenario:[3] place bet in campaign - before campaign start - small
    And uri api/draw/service/bet
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": false,
      "bucketId": "#any"
     }
     """

  Scenario:[4] place bet in campaign - campaign started - small
    And uri api/draw/service/bet
    And delay request 200000
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
       "won": "#boolean",
      "bucketId": "#any"
     }
     """

  Scenario:[5] place bet in campaign - same user - small
    And uri api/draw/service/bet
    And delay request 100
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": "#boolean",
      "bucketId": "#any"
     }
     """

  Scenario:[6] place bet in campaign - other user - small
    And uri api/draw/service/bet
    And delay request 100
    And request
      """
      {
        "betId": "{{uuid}}",
        "campaignId": "C{{campaignId}}",
        "playerId": "{{playerId}}"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
       "won": "#boolean",
      "bucketId": "#any"
     }
     """

  Scenario:[7] get campaign status - small
    And uri api/draw/campaigns/C{{campaignId}}/status
    When method get
    Then status 200
    And match path $.buckets[0].remainingPrizes should be != 0

