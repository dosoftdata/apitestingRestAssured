@world_cup
@regression
@epic:SBRET-2792-Instant-win

Feature: Instant Win for WC - grand
  https://opapgr.atlassian.net/browse/SBRET-2792

  Background:
    Given url {{middlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header Accept = application/json
    And header Authorization = Bearer 54d90941-cf57-4220-acfb-d754bbf6fde2

  Scenario: [1] create campaign - grand
    And Set Instant Win test data
    And uri api/draw/campaigns/create
    And def campaignId = {{$random10Digit}}
    And request
      """
      {
        "campaignId": "C{{campaignId}}",
        "name": "Test Campaign - {{campaignId}}",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 0,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 10
          },
         {
            "bucketId": "medium",
            "totalWinners": 1
          },
         {
            "bucketId": "grand",
            "totalWinners": 100
          }
        ]
      }
      """

    When method post
    Then status 201
    And match
     """

     """

  Scenario:[2] get campaign status before place bet - grand
    And uri api/draw/campaigns/C{{campaignId}}/status
    When method get
    Then status 200
    And match path $.buckets[2].remainingPrizes should be = 100

  Scenario:[3] place bet in campaign - before campaign start - grand
    And uri api/draw/service/bet
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": false,
      "bucketId": "#any"
     }
     """

  Scenario:[4] place bet in campaign - campaign started - grand
    And uri api/draw/service/bet
    And delay request 150000
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": true,
      "bucketId": "grand"
     }
     """

  Scenario:[5] place bet in campaign - same user - grand
    And uri api/draw/service/bet
    And delay request 100
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": true,
      "bucketId": "grand"
     }
     """

  Scenario:[6] place bet in campaign - other user - grand
    And uri api/draw/service/bet
    And delay request 100
    And request
      """
      {
        "betId": "{{uuid}}",
        "campaignId": "C{{campaignId}}",
        "playerId": "{{playerId}}"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": true,
      "bucketId": "grand"
     }
     """

  Scenario:[7] get campaign status - grand
    And uri api/draw/campaigns/C{{campaignId}}/status
    When method get
    Then status 200
    And match path $.buckets[2].remainingPrizes should be = 98

  Scenario: [81] create campaign - grand
    And Set Instant Win test data
    And uri api/draw/campaigns/create
    And def campaignId = {{$random10Digit}}
    And request
      """
      {
        "campaignId": "C{{campaignId}}",
        "name": "Test Campaign - {{campaignId}}",
        "start": "{{dateTimeNowPlus}}",
        "end": "{{dateTimeNowPlus2}}",
        "timeExtensionMins": 0,
        "buckets": [
          {
            "bucketId": "small",
            "totalWinners": 10
          },
         {
            "bucketId": "medium",
            "totalWinners": 10
          },
      {
            "bucketId": "grand",
            "totalWinners": 10
          }
        ]
      }
      """

    When method post
    Then status 201
    And match
     """

     """

  Scenario:[82] get campaign status before place bet - grand
    And uri api/draw/campaigns/C{{campaignId}}/status
    When method get
    Then status 200
    And match path $.buckets[*].remainingPrizes should be = 10

  Scenario:[83] place bet in campaign - before campaign start - grand
    And uri api/draw/service/bet
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": "#boolean",
      "bucketId": "#any"
     }
     """

  Scenario:[84] place bet in campaign - campaign started - grand
    And uri api/draw/service/bet
    And delay request 200000
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
     "won": "#boolean",
      "bucketId": "#any"
     }
     """

  Scenario:[85] place bet in campaign - same user - grand
    And uri api/draw/service/bet
    And delay request 100
    And request
      """
      {
        "betId": "c2392065-ec25-434a-8d4c-b3848f2d017c",
        "campaignId": "C{{campaignId}}",
        "playerId": "player-150"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": "#boolean",
      "bucketId": "#any"
     }
     """

  Scenario:[86] place bet in campaign - other user - grand
    And uri api/draw/service/bet
    And delay request 100
    And request
      """
      {
        "betId": "{{uuid}}",
        "campaignId": "C{{campaignId}}",
        "playerId": "{{playerId}}"
      }
      """

    When method post
    Then status 200
    And match
     """
     {
      "won": "#boolean",
      "bucketId": "#any"
     }
     """

  Scenario:[87] get campaign status - grand
    And uri api/draw/campaigns/C{{campaignId}}/status
    When method get
    Then status 200
    And match path $.buckets[*].remainingPrizes should be != 0