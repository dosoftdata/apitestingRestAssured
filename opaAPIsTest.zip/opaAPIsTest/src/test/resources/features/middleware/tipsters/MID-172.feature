@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-172 - Popular Bets
  https://opapgr.atlassian.net/browse/MID-172
  In this scenario the user requests to get all the Popular Bets among all users according to VAIX’s metrics, without including any related markets or additional betting information.

  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When path uip/retail-sportsbook/api/v1.0/sports/selections/popular

  Scenario Outline: MID-172-01 -  Popular Bets landpage and view all
    And param location = <location>
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "sortCode": "MTCH",
            "markets": "#array",
            "active": true,
            "startTime": "#datetime",
             "hasBoostedMarket": "#boolean",
            "status": "ACTIVE",
            "displayed": true,
            "marketCounts": "#object"
          }
      """
    Examples:
      |testId           | location           | channel |
#      |  MID_170_01     |    pop_bets_land   |   R     |
#      |  MID-182-01     |    pop_bets_land   |   T     |
      |  MID-182-01     |    pop_bets_land   |   H     |
#      |  MID-182-01     |    pop_bets_land   |   I     |
#      |  MID-182-01     |    pop_bets_land   |   X     |
#      |  MID-182-01     |    pop_bets_land   |   M     |
#      |  MID-182-01     |    pop_bets_land   |   A     |
#      |  MID_170_01     |    pop_bets_all    |   R     |
#      |  MID-182-01     |    pop_bets_all    |   T     |
      |  MID-182-01     |    pop_bets_all    |   H     |
#      |  MID-182-01     |    pop_bets_all    |   I     |
#      |  MID-182-01     |    pop_bets_all    |   X     |
#      |  MID-182-01     |    pop_bets_all    |   M     |
#      |  MID-182-01     |    pop_bets_all    |   A     |

  Scenario Outline: MID-172-02 - Popular Bets - default channel
    And param location = <location>
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "sortCode": "MTCH",
            "markets": "#array",
            "active": true,
            "startTime": "#datetime",
             "hasBoostedMarket": "#boolean",
            "status": "ACTIVE",
            "displayed": true,
            "marketCounts": "#object"
          }
      """
    Examples:
      |testId           | location           |
      |  MID-172-02     |    pop_bets_land   |
      |  MID-172-02     |    pop_bets_all    |

  Scenario Outline: MID-172-03 - Popular Bets - missed location
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           |  channel |
      |  MID-172-03     |   R      |
