@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-170 - Recommended Betslips
  https://opapgr.atlassian.net/browse/MID-170
  user requests to get all the recommended betslips according to VAIXs metrics.

  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When path  uip/retail-sportsbook/api/v1.0/sports/betslips/recommended


  Scenario Outline: MID-170-01 - Recommended Betslips landpage and view all
    And param location = <location>
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    * def <testId> in response.data.allBetSlips
    Examples:
      |testId           | location             | channel |
#      |  MID_170_01     |  rec_betslips_land   |   R     |
#      |  MID-170-01     |  rec_betslips_land   |   T     |
      |  MID-170-01     |  rec_betslips_land   |   H     |
#      |  MID-170-01     |  rec_betslips_land   |   I     |
#      |  MID-170-01     |  rec_betslips_land   |   X     |
#      |  MID-170-01     |  rec_betslips_land   |   M     |
#      |  MID-170-01     |  rec_betslips_land   |   A     |
#      |  MID_170_01     |  rec_betslips_all    |   R     |
#      |  MID-170-01     |  rec_betslips_all    |   T     |
      |  MID-170-01     |  rec_betslips_all    |   H     |
#      |  MID-170-01     |  rec_betslips_all    |   I     |
#      |  MID-170-01     |  rec_betslips_all    |   X     |
#      |  MID-170-01     |  rec_betslips_all    |   M     |
#      |  MID-170-01     |  rec_betslips_all    |   A     |

  Scenario Outline: MID-170-02 - Recommended Betslips - default channel
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    Examples:
      |testId           | location            |
      |  MID-170-02     |  rec_betslips_land  |
      |  MID-170-02     |  rec_betslips_all   |

  Scenario Outline: MID-170-03 - Recommended Betslips - missed location
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           | channel |
      |  MID-170-03     |    R      |

  Scenario Outline: MID-170-04 - Recommended Betslips - missed player
    And param location = <location>
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'

    Examples:
      |testId           | location             | channel |
      |  MID-170-04     |  rec_betslips_land   |  R      |

  Scenario Outline: MID-170-05 - Recommended Betslips -  Hot combos doubles landpage and view All
    And param location = <location>
    #And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    * def <testId> in response.data.allBetSlips
    Examples:
      |testId           | location                | channel |
      |  MID_170_01     | hotcombos_double_land   |   R     |
      |  MID-170-01     | hotcombos_double_all    |   R     |


  Scenario Outline: MID-170-06 - Recommended Betslips -  Hot combos trebles landpage and view All
    And param location = <location>
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    * def <testId> in response.data.allBetSlips
    Examples:
      |testId           | location                | channel |
      |  MID_170_01     | hotcombos_trebles_land  |   I     |
      |  MID-170-01     | hotcombos_trebles_all   |   I     |



  Scenario Outline: MID-170-07 - Recommended Betslips -  Hot combos 4+ landpage and view All
    And param location = <location>
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    * def <testId> in response.data.allBetSlips
    Examples:
      |testId           | location                | channel |
      |  MID_170_01     | hotcombos_4plus_all     |   R     |
      |  MID-170-01     | hotcombos_4plus_land    |   R     |

  Scenario Outline: MID-170-01 - Recommended Betslips | Accass
    And param location = <location>
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    * def <testId> in response.data.allBetSlips
    Examples:
      |testId           | location                        | channel |
      |  MID_170_01     |  restsports_recommended_accas   |   R     |
      |  MID-170-01     |  restsports_recommended_accas   |   T     |
      |  MID-170-01     |  restsports_recommended_accas   |   H     |
      |  MID-170-01     |  restsports_recommended_accas   |   I     |
      |  MID-170-01     |  restsports_recommended_accas   |   X     |
      |  MID-170-01     |  restsports_recommended_accas   |   M     |
      |  MID-170-01     |  restsports_recommended_accas   |   A     |


  Scenario Outline: MID-170-06 - Recommended Betslips - Rest sport- locationRecommendedSports
    And param location = <location>
    And param locationRecommendedSports = rest_sport_topsport
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    * def <testId> in response.data.allBetSlips
    Examples:
      |testId           | location                   | channel |
      |  MID_170_01     | rest_sport_betslips_land   |   R     |