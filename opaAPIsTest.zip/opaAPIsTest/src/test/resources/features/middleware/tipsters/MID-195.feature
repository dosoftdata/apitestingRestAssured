@tipsters @MID-195
@regression
@epic:TPR-2720-Tipsters

Feature: MID-195 - Shuffle Bets
  https://opapgr.atlassian.net/browse/MID-195
  In this scenario, the user requests to get a new selection which should replace a specific betslip selection provided earlier by MID-170: Recommended Betslips
  -Given a betslip recommended to the user, the latter should be able to request the replacement of a betslip selection with a new one.


  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When path  uip/retail-sportsbook/api/v1.0/sports/selections/similar
    And Get Tipsters betslips-recommended outcomes_ids in rec_betslips_land location and R channel

  Scenario Outline: MID-195-01 - Shuffle Bets
    And param location = <location>
    And header channel = <channel>
    And param selection_ids = {{Tipsters/betslips/recommended/outcomes_ids}}
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """
    Examples:
      |testId           | location       | channel |
#      |  MID_182_01     |  shuffle_bet   |   R     |
#      |  MID-195-01     |  shuffle_bet   |   T     |
      |  MID-195-01     |  shuffle_bet   |   H     |
#      |  MID-195-01     |  shuffle_bet   |   I     |
#      |  MID-195-01     |  shuffle_bet   |   X     |
#      |  MID-195-01     |  shuffle_bet   |   M     |
#      |  MID-195-01     |  shuffle_bet   |   A     |
  
    
  Scenario Outline: MID-195-02 - Shuffle Bets - default channel
    And param location = <location>
    And header x-player-id = {{playerId}}
    And param selection_ids = {{Tipsters/betslips/recommended/outcomes_ids}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array"
          }
      """
    And match each $.data.allBetSlips[*].events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """

    Examples:
      |testId           | location               |
      |  MID-195-02     |  shuffle_bet           |
#      |  MID-195-02     |  shuffle_bet_refresh   |

  Scenario Outline: MID-195-03 - Shuffle Bets - empty selection id
    And param location = <location>
    And header channel = <channel>
    And param selection_ids = ""
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains No shuffle bets found

    Examples:
      |testId           | location       | channel |
      |  MID-195-03     |  shuffle_bet   |  R      |

  Scenario Outline: MID-195-03 - Shuffle Bets - missed selection id
    And param location = <location>
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'selection_ids'

    Examples:
      |testId           | location       | channel |
      |  MID-195-03     |  shuffle_bet   |  R      |

  Scenario Outline: MID-195-03 - Shuffle Bets - missed location
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           |  channel |
      |  MID-195-03     |  R       |

  Scenario Outline: MID-195-04 - Shuffle Bets - missed player
    And param location = <location>
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'

    Examples:
      |testId           | location       | channel |
      |  MID-195-04     |  shuffle_bet   |  R      |