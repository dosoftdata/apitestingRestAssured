@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-171 - Popular Events
  https://opapgr.atlassian.net/browse/MID-171
  In this scenario the user requests to get all the popular events among all users according to VAIX’s metrics, without including any related markets or additional betting information.

  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When path uip/retail-sportsbook/api/v1.0/sports/events/popular

  Scenario Outline: MID-171-01 - Popular events landpage and view all
    And param location = <location>
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "sortCode": "MTCH",
            "active": true,
            "startTime": "#datetime",
            "confidence": "#number",
            "hasBoostedMarket": "#boolean",
            "status": "#string",
            "displayed": "#boolean"
          }
      """
    Examples:
      |testId           | location          | channel |
#      |  MID_170_01     |  pop_events_land   |   R     |
#      |  MID-182-01     |  pop_events_land   |   T     |
      |  MID-182-01     |  pop_events_land   |   H     |
#      |  MID-182-01     |  pop_events_land   |   I     |
#      |  MID-182-01     |  pop_events_land   |   X     |
#      |  MID-182-01     |  pop_events_land   |   M     |
#      |  MID-182-01     |  pop_events_land   |   A     |
#      |  MID_170_01     |  pop_events_all    |   R     |
#      |  MID-182-01     |  pop_events_all    |   T     |
      |  MID-182-01     |  pop_events_all    |   H     |
#      |  MID-182-01     |  pop_events_all    |   I     |
#      |  MID-182-01     |  pop_events_all    |   X     |
#      |  MID-182-01     |  pop_events_all    |   M     |
#      |  MID-182-01     |  pop_events_all    |   A     |

  Scenario Outline: MID-171-02 - Popular Events - default channel
    And param location = <location>
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "sortCode": "MTCH",
            "active": true,
            "startTime": "#datetime",
            "confidence": "#number",
            "hasBoostedMarket": "#boolean",
            "status": "#string",
            "displayed": "#boolean"
          }
      """
    Examples:
      |testId           | location           |
      |  MID-171-02     |  pop_events_land   |
      |  MID-171-02     |  pop_events_all    |

  Scenario Outline: MID-171-03 - Popular Events - missed location
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           |  channel |
      |  MID-171-03     |    R     |
