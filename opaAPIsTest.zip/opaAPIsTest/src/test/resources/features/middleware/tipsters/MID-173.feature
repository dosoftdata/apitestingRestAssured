@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-173 - Popular Betslips
  https://opapgr.atlassian.net/browse/MID-173
  In this scenario the user requests to get all the Popular Betslipslips across all users, according to VAIXs metrics.
  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When path uip/retail-sportsbook/api/v1.0/sports/betslips/popular


  Scenario Outline: MID-173-01 - Popular Betslips landpage and view all
    And param location = <location>
    And header channel = <channel>
    And delay request 1024
    And retry GET  until condition {}
    Then status 200 or 500
    And match if status = 200
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """
    And match each $.data.allBetSlips[*].events[*] should match if status = 200
      """
         {
            "id": "#string",
            "name": "#string",
            "sortCode": "MTCH",
            "markets": "#array",
            "active": true,
            "startTime": "#datetime",
            "hasBoostedMarket": "#boolean",
            "status": "ACTIVE",
            "displayed": true,
            "marketCounts": "#object"
          }
      """
    Examples:
      |testId           | location             | channel |
#      |  MID-173_01     |  pop_betslips_land   |   R     |
#      |  MID-173-01     |  pop_betslips_land   |   T     |
      |  MID-173-01     |  pop_betslips_land   |   H     |
#      |  MID-173-01     |  pop_betslips_land   |   I     |
#      |  MID-173-01     |  pop_betslips_land   |   X     |
#      |  MID-173-01     |  pop_betslips_land   |   M     |
#      |  MID-173-01     |  pop_betslips_land   |   A     |
#      |  MID-173_01     |  pop_betslips_all    |   R     |
#      |  MID-173-01     |  pop_betslips_all    |   T     |
      |  MID-173-01     |  pop_betslips_all    |   H     |
#      |  MID-173-01     |  pop_betslips_all    |   I     |
#      |  MID-173-01     |  pop_betslips_all    |   X     |
#      |  MID-173-01     |  pop_betslips_all    |   M     |
#      |  MID-173-01     |  pop_betslips_all    |   A     |
    
  Scenario Outline: MID-173-02 - Popular Betslips - default channel
    And param location = <location>
    And retry GET  until condition {}
    Then status 200 or 500
    And match if status = 200
     """
     {
       "data": {
          "allBetSlips":"#array"
        }
      }
     """

    And match each $.data.allBetSlips[*].events[*] should match if status = 200
      """
         {
            "id": "#string",
            "name": "#string",
            "sortCode": "MTCH",
            "markets": "#array",
            "active": true,
            "startTime": "#datetime",
            "hasBoostedMarket": "#boolean",
            "status": "ACTIVE",
            "displayed": true,
            "marketCounts": "#object"
          }
      """
    And match path $.msg should be = No popular bet slips found if status = 500

    Examples:
      |testId           | location             |
      |  MID-173-02     |  pop_betslips_land   |
      |  MID-173-02     |  pop_betslips_all    |

  Scenario Outline: MID-173-03 - Popular Betslips - missed location
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           | channel |
      |  MID-173-03     |  R      |

