@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-174 - Similar Tipsters
  https://opapgr.atlassian.net/browse/MID-174
  In this scenario the user requests to get a list of tipsters which are similar to his betting activity. The user should receive a list of objects, each one containing a user id and a distance field, which indicates how similar to the user each tipster is.
  
  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When uri uip/retail-sportsbook/api/v1.0/sports/users/similar


  Scenario Outline: MID-174-01 - Similar Tipsters landpage and view all
    And param location = <location>
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200 or 500
    And match if status = 200
     """
     {
       "data": {
          "tipsters":"#array"
        }
      }
     """
    And match each $.data.tipsters[*] should match if status = 200
      """
          {
           "distance": "#number",
           "user_id": "#string"
         }
      """
    And match path $.msg should be #contains No similar tipsters if status = 500
    Examples:
      |testId           | location                 | channel |
#      |  MID_174_01     |  similar_tipsters_land   |   R     |
#      |  MID-174-01     |  similar_tipsters_land   |   T     |
#      |  MID-174-01     |  similar_tipsters_land   |   H     |
      |  MID-174-01     |  similar_tipsters_land   |   I     |
#      |  MID-174-01     |  similar_tipsters_land   |   X     |
#      |  MID-174-01     |  similar_tipsters_land   |   M     |
#      |  MID-174-01     |  similar_tipsters_land   |   A     |
#      |  MID_174_01     |  similar_tipsters_all    |   R     |
#      |  MID-174-01     |  similar_tipsters_all    |   T     |
#      |  MID-174-01     |  similar_tipsters_all    |   H     |
      |  MID-174-01     |  similar_tipsters_all   |   I     |
#      |  MID-174-01     |  similar_tipsters_all   |   X     |
#      |  MID-174-01     |  similar_tipsters_all   |   M     |
#      |  MID-174-01     |  similar_tipsters_all   |   A     |
  
  Scenario Outline: MID-174-02 - Similar Tipsters - default channel
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200 or 500
    And match if status = 200
     """
     {
       "data": {
          "tipsters":"#array"
        }
      }
     """
    And match each $.data.tipsters[*] should match if status = 200
      """
          {
           "distance": "#number",
           "user_id": "#string"
         }
      """
    And match path $.msg should be #contains No similar tipsters if status = 500
    Examples:
      |testId           | location                 |
      |  MID-174-02     |  similar_tipsters_land   |
      |  MID-174-02     |  similar_tipsters_all    |

  Scenario Outline: MID-174-03 - Similar Tipsters - missed location
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           |  channel |
      |  MID-174-03     |   I      |


  Scenario Outline: MID-174-02 - Similar Tipsters - missed user id
    And param location = <location>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'
    Examples:
      |testId           | location                 |
      |  MID-174-02     |  similar_tipsters_land   |
