@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-182 - Recommended Bet Builder
  https://opapgr.atlassian.net/browse/MID-182
  user requests to get all the recommended Bet Builder according to VAIXs metrics.

  Background:
    Given url {{psMiddlewareHost}}
    And header Accept = application/json
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header locale = el-GR
    When path  uip/retail-sportsbook/api/v1.0/sports/bet_builders/recommended


  Scenario Outline: MID-182-01 - Bet builder landpage and view all
    And param location = <location>
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array",
            "marketCounts": "#object",
            "confidence": "#number",
            "betBuilders":"#array"
          }
      """
    And match each $.data.events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """

    * def <testId> in response.data.events
    Examples:
      |testId           | location           | channel |
#      |  MID_182_01     |  betbuilder_land   |   R     |
#      |  MID-182-01     |  betbuilder_land   |   T     |
      |  MID-182-01     |  betbuilder_land   |   H     |
#      |  MID-182-01     |  betbuilder_land   |   I     |
#      |  MID-182-01     |  betbuilder_land   |   X     |
#      |  MID-182-01     |  betbuilder_land   |   M     |
#      |  MID-182-01     |  betbuilder_land   |   A     |
#      |  MID_182_01     |  betbuilder_all    |   R     |
#      |  MID-182-01     |  betbuilder_all    |   T     |
      |  MID-182-01     |  betbuilder_all    |   H     |
#      |  MID-182-01     |  betbuilder_all    |   I     |
#      |  MID-182-01     |  betbuilder_all    |   X     |
#      |  MID-182-01     |  betbuilder_all    |   M     |
#      |  MID-182-01     |  betbuilder_all    |   A     |
  
  Scenario Outline: MID-182-02 - Recommended Bet Builder - default channel
    And param location = <location>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 200
    And match
     """
     {
       "data": {
          "events":"#array"
        }
      }
     """
    And match each $.data.events[*] should match
      """
         {
            "id": "#string",
            "name": "#string",
            "active": "#boolean",
            "markets": "#array",
            "marketCounts": "#object",
            "confidence": "#number",
            "betBuilders":"#array"
          }
      """
    And match each $.data.events[*].markets[*] should match
      """
         {
            "id": "#string",
            "eventId": "#string",
            "active": "#boolean"
          }
      """

    Examples:
      |testId           |  location          |
      | MID-182-02      |  betbuilder_land   |
      | MID-182-02      |  betbuilder_all    |

  Scenario Outline: MID-182-03 - Recommended Bet Builder - missed location
    And header channel = <channel>
    And header x-player-id = {{playerId}}
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request parameter 'location'

    Examples:
      |testId           |  channel |
      |  MID-182-03     |   R      |

  Scenario Outline: MID-182-04 - Recommended Bet Builder - missed player
    And param location = <location>
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id'

    Examples:
      |testId           | location           | channel |
      |  MID-182-04     |  betbuilder_land   |  R      |