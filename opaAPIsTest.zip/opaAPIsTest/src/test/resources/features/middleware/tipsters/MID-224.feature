@tipsters
@regression
@epic:TPR-2720-Tipsters

Feature: MID-224 - Popular for Shops
  https://opapgr.atlassian.net/browse/MID-224
  Popular events, bets and betslips for a specific shop id.

  Background:
    Given url {{psMiddlewareHost}}
    And header Connection = keep-alive
    And header Content-Type = application/json
    And header Accept = application/json
    And header locale = en-US
    When path  uip/retail-sportsbook/api/v1.0/sports/shop/betslips/recommended

  Scenario Outline: MID-224-01 - Popular for Shops landpage
    And param location = <location>
    And param doubleslocation = <location>
    And param trebleslocation = <location>
    And param doublesExpectedCount = 5
    And param treblesExpectedCount = 2
    And header x-player-id = {{playerId}}
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 200 or 500
    And match path $.code should be = 1000 if status = 200
    And match path $.code should be = 10015 if status = 500
    And match if status = 200
       """
       {
         "data": {
             "indicator": "#string",
              "data": "#object"
            }
       }
       """
    Examples:
      |testId           | location             | channel |
      |  MID_224_01     |  pop_betslips_land   |   R     |
#


  Scenario Outline: MID-224-02 - Popular for Shops |  missed player id
    And param location = <location>
    And param doubleslocation = <location>
    And param trebleslocation = <location>
    And param doublesExpectedCount = 5
    And param treblesExpectedCount = 2
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains Required request header 'x-player-id' for method parameter type String is not present
    Examples:
      |testId           | location             | channel |
      |  MID_224_01     |  pop_betslips_land   |   R     |


  Scenario Outline: MID-224-03 - Popular for Shops
    And param location = <location>
    And param doubleslocation = <location>
    And param trebleslocation = <location>
    And param doublesExpectedCount = 0
    And param treblesExpectedCount = 0
    And header x-player-id = {{playerId}}
    And header channel = <channel>
    And retry GET  until condition {}
    Then status 500
    And match path $.msg should be #contains No bet slips found for shop: {{playerId}}
    Examples:
      |testId           | location             | channel |
      |  MID_224_01     |  pop_betslips_land   |   R     |


#  Scenario Outline: MID-224-02 - Popular for Shops view all
#    And param location = <location>
#    And header x-player-id = {{playerId}}
#    And retry GET  until condition {}
#    Then status 200
#    And match
#      """
#      {
#         "code": 1000,
#         "msg": "success",
#         "source": "api-gateway",
#         "data": { "events": "#array" },
#          "time": "#number",
#          "success": true,
#          "failed": false
#       }
#      """
#
#    And match each $.data.events[*] should match
#      """
#      {
#                "id": "#string",
#                "name": "#string",
#                "active": true,
#                "displayOrder": "#number",
#                "sortCode": "#string",
#                "startTime": "#datetime",
#                "liveNow": "#boolean",
#                "resulted": "#boolean",
#                "settled": "#boolean",
#                "rcpAvailable": "#boolean",
#                "hasBoostedMarket": "#boolean",
#                "type": "#object",
#                "class": "#object",
#                "category": "#object",
#                 "sportDrilldownTagId": "#string",
#                "regionDrilldownTagId": "#string",
#                "competitionDrilldownTagId": "#string",
#                "displayed": true,
#                 "started": false,
#                "confidence": "#number"
#            }
#      """
#    # And match path $.data.events[*].started should be = false
#    And match path $.data.events[*].status should be = ACTIVE
#    And match path $.data.events[*].displayed should be = true
#    And match each $.data.events[*].externalIds[*] should match
#      """
#       {
#          "id": "#string",
#          "provider": "#string"
#       }
#      """
#
#    Examples:
#      |testId           | location              |
#      |  MID-224-02     |  rec_events_land      |
#      |  MID-224-02     |  rec_events_all       |
#
#
#  Scenario Outline: MID-224-03 - Recommended event - missed location
#    And header channel = <channel>
#    And header x-player-id = {{playerId}}
#    And retry GET  until condition {}
#    Then status 500
#    And match path $.msg should be #contains Required request parameter 'location'
#
#    Examples:
#      |testId           | location                      | channel |
#      |  MID-224-03     |  rec_events_land   |  R      |
#
#  Scenario Outline: MID-224-04 - Recommended event - missed player
#    And param location = <location>
#    And header channel = <channel>
#    And retry GET  until condition {}
#    Then status 500
#    And match path $.msg should be #contains Required request header 'x-player-id'
#
#    Examples:
#      |testId           | location              | channel |
#      |  MID-224-04     |  rec_events_land   |  R      |
#
#  Scenario Outline: MID-224-05 - Rest sports Popular for Shops landpage and view All
#    And param location = <location>
#    And header channel = <channel>
#    And header x-player-id = {{playerId}}
#    And retry GET  until condition {}
#    Then status 200
#    And match
#      """
#      {
#         "code": 1000,
#         "msg": "success",
#         "source": "api-gateway",
#         "data": { "events": "#array" },
#          "time": "#number",
#          "success": true,
#          "failed": false
#       }
#      """
#    And match each $.data.events[*] should match
#      """
#      {
#                "id": "#string",
#                "name": "#string",
#                "active": true,
#                "displayOrder": "#number",
#                "sortCode": "#string",
#                "startTime": "#datetime",
#                "liveNow": "#boolean",
#                "resulted": "#boolean",
#                "settled": "#boolean",
#                "rcpAvailable": "#boolean",
#                "hasBoostedMarket": "#boolean",
#                "type": "#object",
#                "class": "#object",
#                "category": "#object",
#                 "sportDrilldownTagId": "#string",
#                "regionDrilldownTagId": "#string",
#                "competitionDrilldownTagId": "#string",
#                "displayed": true,
#                "confidence": "#number"
#            }
#      """
#    And match path $.data.events[*].started should be = false
#    And match path $.data.events[*].status should be = ACTIVE
#    And match path $.data.events[*].displayed should be = true
#    And match each $.data.events[*].externalIds[*] should match
#      """
#       {
#          "id": "#string",
#          "provider": "#string"
#       }
#      """
#
#     #* def events/recommended in response.data.events
#    Examples:
#      |testId           | location                      | channel |
##      |  MID_155_01     |  rest_sport_events_land   |   R     |
##      |  MID-224-01     |  rest_sport_events_land   |   T     |
#      |  MID-224-01     |  rest_sport_events_land   |   H     |
##      |  MID-224-01     |  rest_sport_events_land   |   I     |
##      |  MID-224-01     |  rest_sport_events_land   |   X     |
##      |  MID-224-01     |  rest_sport_events_land   |   M     |
##      |  MID-224-01     |  rest_sport_events_land   |   A     |
##      |  MID_155_01     |  rest_sport_events_all     |   R     |
##      |  MID-224-01     |  rest_sport_events_all        |   T     |
#      |  MID-224-01     |  rest_sport_events_all        |   H     |
##      |  MID-224-01     |  rest_sport_events_all        |   I     |
##      |  MID-224-01     |  rest_sport_events_all        |   X     |
##      |  MID-224-01     |  rest_sport_events_all        |   M     |
##      |  MID-224-01     |  rest_sport_events_all        |   A     |
#
#  Scenario Outline: MID-224-06 - Recommended event - Rest Sports - locationRecommendedSports
#    And param location = <location>
#    And param locationRecommendedSports = rest_sport_topsport
#    And header x-player-id = {{playerId}}
#    And retry GET  until condition {}
#    Then status 200
#    And match
#      """
#      {
#         "code": 1000,
#         "msg": "success",
#         "source": "api-gateway",
#         "data": { "events": "#array" },
#          "time": "#number",
#          "success": true,
#          "failed": false
#       }
#      """
#    And match each $.data.events[*] should match
#      """
#      {
#                "id": "#string",
#                "name": "#string",
#                "active": true,
#                "displayOrder": "#number",
#                "sortCode": "#string",
#                "startTime": "#datetime",
#                "liveNow": "#boolean",
#                "resulted": "#boolean",
#                "settled": "#boolean",
#                "rcpAvailable": "#boolean",
#                "hasBoostedMarket": "#boolean",
#                "type": "#object",
#                "class": "#object",
#                "category": "#object",
#                 "sportDrilldownTagId": "#string",
#                "regionDrilldownTagId": "#string",
#                "competitionDrilldownTagId": "#string",
#                "displayed": true,
#                "confidence": "#number"
#            }
#      """
#    And match path $.data.events[*].started should be = false
#    And match path $.data.events[*].status should be = ACTIVE
#    And match path $.data.events[*].displayed should be = true
#    And match each $.data.events[*].externalIds[*] should match
#      """
#       {
#          "id": "#string",
#          "provider": "#string"
#       }
#      """
#
#     #* def events/recommended in response.data.events
#    Examples:
#      |testId           | location                     |
#      |  MID_155_01     |  rest_sport_events_land      |
#      |  MID-224-01     |  rest_sport_events_all       |