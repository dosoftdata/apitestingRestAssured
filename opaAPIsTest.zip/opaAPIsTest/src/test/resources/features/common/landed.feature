@ignore
Feature: Reusable - land on final redirect target
  Callee for `call feature` — not meant to run standalone (tagged @ignore by
  convention; CI filters are inclusion-based so it is never selected directly).

  Background:
    Given url {{mockServerUrl}}

  Scenario: Land and capture
    When path /redirects/final
    And method GET
    Then status 200
    And def landedStatus in response.status
    And def landedHops in response.hops

  Scenario: Post an item with docstring body
    When path /inventory/items
    And header Content-Type = application/json
    And request
      """
      { "id": "CALLED-1", "qty": 7 }
      """
    When method POST
    Then status 200
    And def calledItemId in response.id

  Scenario Outline: Post item <itemId>
    When path /inventory/items
    And header Content-Type = application/json
    And request
      """
      { "id": "<itemId>", "qty": <qty> }
      """
    When method POST
    Then status 200
    And def lastItemId in response.id

    Examples:
      | itemId | qty |
      | OUTL-1 | 1   |
      | OUTL-2 | 2   |

  # Parameterized callee — expects {{argItemId}} / {{argQty}} set by the caller
  # (via `call feature ... with args` + JSON docstring).
  Scenario: Post one item from args
    When path /inventory/items
    And header Content-Type = application/json
    And request
      """
      { "id": "{{argItemId}}", "qty": {{argQty}} }
      """
    When method POST
    Then status 200
    And def argPostedId in response.id
