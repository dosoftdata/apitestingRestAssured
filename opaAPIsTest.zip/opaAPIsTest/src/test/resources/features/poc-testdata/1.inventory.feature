@poc @mock
@DataSource:csv
Feature: TC001

  Background:
    Given url {{mockServerUrl}}
    And header Content-Type = application/json

  # Examples table is rewritten by apis.middleware.testData.initGenerator
  # from src/test/resources/testdata/testdata.csv. Don't hand-edit rows.
  Scenario Outline: Add item to inventory
    Given path /inventory/items
    And request
      """
      { "id": "<item_id>", "qty": <quantity> }
      """
    When method POST
    Then status 200
    And match path $.id should be #contains <item_id>
    And match path $.status should be #contains ACCEPTED

    Examples:
      | item_id | quantity |
      | ITEM-0012 | 502 |
      | ITEM-0099 | 1 |
      | ITEM-1500 | 250 |


  Scenario Outline: Submit order
    Given path /inventory/orders
    And request
      """
      { "orderId": "<order_id>", "user": "<user>", "product": "<product>" }
      """
    When method POST
    Then status 201
    And match path $.orderId should be #contains <order_id>
    And match path $.status should be #contains CREATED

    Examples:
      | order_id | user | product |
      | ORD-7001 | alice | ITEM-0012 |
      | ORD-7002 | bob | ITEM-1500 |
      | ORD-7003 | carol | ITEM-0099 |
