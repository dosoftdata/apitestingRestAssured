@janus @ssbt
@epic:DEV-15154-Migrate-Janus-Nightly-Suite
Feature: Create Voucher - Top Up SSBT

  Background:
    When url {{janusBaseUrl}}
    And header Content-Type = application/json


  # Get generic token as retailer in order to use it for Apollo TRM
  Scenario: Get generic access token (ssbts client)
    And path api/access/oidc/token
    And header Authorization = {{janus.authorization_ssbts}}
    And header Content-Type = application/x-www-form-urlencoded
    And form field grant_type = client_credentials
    And method POST
    Then status 200
    * def accessToken in response.access_token
    * def janusTokenType in response.token_type


  # Retailer creates a new normal type voucher for ssbt usage
  Scenario: Create normal voucher from Apollo (TRM)
    And path  api/voucher/rest/v1/vouchers/create
    And header Authorization = {{janusTokenType}} {{accessToken}}
    And param channelId = 2
    And param retailerId = 234020
    And param terminalId = 234020TRM01
    And param paymentId = 1
    And param amount = 100
    And param voucherType = normal
    And method POST
    Then status 200
    And match response type = normal
    And match response status = active
    And match response voucherProvider = ilot
    And match response extTerminalId = 23402081
    * def voucherId in response.voucherId


  # Retailer re prints voucher
  Scenario: Reprint voucher
    And path api/voucher/rest/v1/vouchers/{voucherId}/reprint
    And header Authorization = {{janusTokenType}} {{accessToken}}
    And pathParam voucherId = {{voucherId}}
    And param channelId = 2
    And param retailerId = 234020
    And param operatorId = 2
    And method PUT
    Then status 200
    And match response voucherId = {{voucherId}}
    And match response type = normal
    And match response status = active
    And match response voucherProvider = ilot
    And match response extTerminalId = 23402081



  # Retailer gets voucher details
  Scenario: Get voucher details
    And path web/voucher/rest/v1/vouchers/{voucherId}
    And header Authorization = {{janusTokenType}} {{accessToken}}
    And pathParam voucherId = {{voucherId}}
    And param retailerId = 234020
    And method GET
    And status 200
    And match response voucherId = {{voucherId}}
    And match response type = normal
    And match response status = active
    And match response voucherProvider = ilot
    And match response extTerminalId = 23402081


  # The player logs into SSBT, using the voucher created by the retailer and gets SSBT balance
  Scenario: Get SSBT Balance
    When url {{janusAllwynUrl}}
    And User logins with voucher and terminalid 234020HPT01
    And path web/wallet/rest/v2-opap/customers/ssbt/accounts
    And header Authorization = {{janusTokenType}} {{janusToken}}
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And method GET
    And status 200
    And match response transactions = https://retailapidev.allwyn.gr/web/wallet/rest/v2-opap/customers/ssbt/accounts/transactions
    And match response currency = EUR
    And match response id = AT_MAIN-0


  # The player logs into SSBT, using the voucher created by the retailer, and cashes it in.
  Scenario: Cash in voucher
    When url {{janusAllwynUrl}}
    And path web/wallet/rest/v1-opap/payments/voucher/{voucherId}
    And pathParam voucherId = {{voucherId}}
    And header Authorization = {{janusTokenType}} {{janusToken}}
    And header x-csrftoken = {{x-csrftoken}}
    And header Cookie = csrftoken={{x-csrftoken}}
    And method POST
    Then status 200
    And match response amount = 100.0
    And match response currency = EUR