@mock @db @sqlite @csv-import
Feature: Import testdata.csv into testdata.db (SQLite)
  Loads the project's CSV test data into the SQLite database that
  TestDataRepository reads when -Ddb.url is set. The table schema is
  derived from the CSV header (all columns TEXT).

  Background:
    Given def _ = db.connect('jdbc:sqlite:src/test/resources/testdata/testdata.db')

  Scenario: Load all CSV rows into the testdata table
    # Start clean so the scenario is idempotent.not
    Given def _ = db.execute('DROP TABLE IF EXISTS testdata')

    When  def inserted = db.importCsv('src/test/resources/testdata/testdata.csv', 'testdata')
    Then  match inserted = 6

    # Verify the inventory group (3 rows, ordered by item_id).
    When def rows = db.query('SELECT feature_name, scenario_name, item_id, quantity FROM testdata WHERE scenario_name = ''Add item to inventory'' ORDER BY item_id ASC')
    Then match rows.size = 3
    And  match rows[0].feature_name = TC001
    And  match rows[0].item_id = ITEM-0012
    And  match rows[0].quantity = 502
    And  match rows[1].item_id = ITEM-0099
    And  match rows[2].item_id = ITEM-1500

    # Verify the orders group (3 rows, ordered by order_id).
    When def rows = db.query('SELECT order_id, user, product FROM testdata WHERE scenario_name = ''Submit order'' ORDER BY order_id ASC')
    Then match rows.size = 3
    And  match rows[0].order_id = ORD-7001
    And  match rows[0].user = alice
    And  match rows[0].product = ITEM-0012
    And  match rows[1].order_id = ORD-7002
    And  match rows[1].user = bob
    And  match rows[2].order_id = ORD-7003
    And  match rows[2].user = carol
