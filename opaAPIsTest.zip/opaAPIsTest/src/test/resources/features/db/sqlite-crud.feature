@mock @db @sqlite
Feature: SQLite CRUD demo (pooled DBManager)
  Demonstrates the Karate-style db.* DSL against a file-backed SQLite database.
  The pool is initialised by db.connect on first use and closed in Hooks.@AfterAll.

  Background:
    Given def _ = db.connect('jdbc:sqlite:src/test/resources/testdata/testdata.db')
    And   def _ = db.execute('DROP TABLE IF EXISTS crud_demo_players')
    And   def _ = db.execute('CREATE TABLE crud_demo_players (id INTEGER PRIMARY KEY, name TEXT, email TEXT)')

  Scenario: Full CRUD lifecycle (inline SQL)
    # CREATE
    When def inserted = db.execute('INSERT INTO crud_demo_players(id, name, email) VALUES (1, ''Alice'', ''alice@x.com'')')
    Then match inserted = 1

    # READ
    When def rows = db.query('SELECT id, name, email FROM crud_demo_players WHERE id = 1')
    Then match rows.size = 1
    And  match rows[0].name = Alice
    And  match rows[0].email = alice@x.com

    # UPDATE
    When def updated = db.execute('UPDATE crud_demo_players SET email = ''alice2@x.com'' WHERE id = 1')
    Then match updated = 1
    When def rows = db.query('SELECT email FROM crud_demo_players WHERE id = 1')
    Then match rows[0].email = alice2@x.com

    # DELETE
    When def deleted = db.execute('DELETE FROM crud_demo_players WHERE id = 1')
    Then match deleted = 1
    When def rows = db.query('SELECT id FROM crud_demo_players WHERE id = 1')
    Then match rows.size = 0

  Scenario: Bulk insert + multi-row read (docstring SQL)
    When def _ = db.execute
      """
      INSERT INTO crud_demo_players(id, name, email) VALUES
        (10, 'Bob',   'bob@x.com'),
        (11, 'Carol', 'carol@x.com'),
        (12, 'Dave',  'dave@x.com')
      """
    When def rows = db.query
      """
      SELECT id, name, email
      FROM   crud_demo_players
      ORDER  BY id ASC
      """
    Then match rows.size = 3
    And  match rows[0].name = Bob
    And  match rows[1].name = Carol
    And  match rows[2].name = Dave
