function fn(name) {

  var env = java.lang.System.getProperty("env");
  if (!env) { env = "dev"; } // default
  var RandomUtil = Java.type('apis.middleware.utilities.RandomUtil'),
      TimestampUtil = Java.type('apis.middleware.utilities.TimestampUtil');


  var config = {
    env: env,
    janusBaseUrl : "https://janusint.development.dc.opap",
    l10ApiGatewayUrl : "https://apigatewayjh.l10.ilotdev.dc.opap",
    janusAllwynUrl : "https://retailapidev.allwyn.gr",
    janus: {
      baseUrl: "https://janusint.development.dc.opap",
      basePath: "web/access/oidc/token",
      authorization : "Basic YmV0d2FyZTpodHRwczovL2ppcmEuYmV0d2FyZS5jb20vYnJvd3NlL0JXSU1EQ0QtMzcx",
      authorization_ssbts : "Basic c3NidHM6aHR0cHM6Ly9qaXJhLmJldHdhcmUuY29tL2Jyb3dzZS9CV0lNRENELTM3MQ==",
      contentType : "application/x-www-form-urlencoded",
      grantType : "http://betware.com/oidc/grant-type/ssbt.terminal",
      grantTypeVoucherLogin : "http://betware.com/oidc/grant-type/retailer.terminal-voucher",
      scope : "http://betware.com/oidc/scopes/session"
    },
    pam: {
      webBaseUrl: "https://onlineapidev.allwyn.gr",
      boBaseUrl: "https://pamint.development.dc.opap",
      walletHost: "https://pamint-ingressvip.development.dc.opap",
      toraWalletHost: "https://checkout.sandbox.torawallet.gr",
      basic_ilot_auth: "SUxPVDpodHRwczovL2ppcmEuYmV0d2FyZS5jb20vYnJvd3NlL0JXSU1EQ0QtMzcx",
      basic_auth: "YmV0d2FyZTpodHRwczovL2ppcmEuYmV0d2FyZS5jb20vYnJvd3NlL0JXSU1EQ0QtMzcx",
      basic_auth_widgets: "d2lkZ2V0Omh0dHBzOi8vZGV2LWppcmEuZGV2ZWxvcG1lbnQuZGMub3BhcC9icm93c2UvREVWLTEyNzIx",
      card_num: "5457210001000001",
      card_primary_key: "pk_WLEPICUpl6Gfp5aiF8AMm5Uqjj5Um7Hm",
      IBAN: "GR2202655559367039137283047",
      $random8Digit: RandomUtil.generateSecureDigits(8),
      $random10Digit: RandomUtil.generateSecureDigits(10)
    },
    tora: {
      baseUrl: "https://login.microsoftonline.com",
      basePath: "97c3f67d-6d05-42a8-9ec0-d8e78cd4aedc/oauth2/v2.0/token",
      client_id: "10cf3481-5d45-466b-ae4c-b08a5ab06628",
      client_secret : "ngR8Q~L1ZgI7JbtRHGs9J.UkG5Xb_l-vCfF0.cLn",
      grant_type: "client_credentials",
      scope: "api://7af097ad-2c9f-46bb-adcf-d17892f571b5/.default",
      cookie: "fpc=AkY5X8ysnoFNiOgQknuKz3Dkg2nfAQAAANxdZOAOAAAA",
        natech:{
          client_id: "49dc0c89-6ba6-4424-8258-149abcec6062",
          client_secret: "JpN8Q~qvqwTNF3-URNeBpfmXH5msG3K64Ce-7c0m",
          app_id : "7af097ad-2c9f-46bb-adcf-d17892f571b5",
          tenant_id: "97c3f67d-6d05-42a8-9ec0-d8e78cd4aedc"
        }
    },
    middlewareHost : "https://uip-dev.development.dc.opap",
    toraMiddlewareHost : "https://uip-dev.opap.gr",
    psMiddlewareHost: "https://ciapi.pamestoixima.gr",
    ApiOPAP : {
      http: "https://apidev.opap.gr",
      host: "apidev.opap.gr"
    },
    bo_username: "admin",
    bo_password: "admin",
    $randomPassword : RandomUtil.generatePassword(),
    $randomAlphaNumeric:  RandomUtil.randomAlphaNumeric(20),
    $random10Digit: RandomUtil.generateSecureDigits(10),
    timestamp: TimestampUtil.getLocalTimestamp(),
    dateTimeNowPlus:TimestampUtil.getLocalDateTimePlus(1),
    dateTimeNowPlus2:TimestampUtil.getLocalDateTimePlus(3),
    uuid : java.util.UUID.randomUUID(),
    ssbtid: "101023HPT02",
    retailerid: 101023,
    playerId: 413451693, //191088323,
    amount: 10,
    GAMES: {
      JOKER: "JOKER",
      SPORTSBOOK: "SPORTSBOOK",
      CASINO: "CASINO",
      KINO: "KINO",
      LOTTO: "LOTTO",
      PROTO: "PROTO",
      OPAPONLINE :"OPAPONLINE"
    },
    database: {
      host: "localhost",
      ports: [5432, 5433],
      credentials: { user: "admin", pass: "secret" }
    },
    apiKeys: ["key1", "key2"],
    enabled: true
  };
  if (env === "uat") {
    config.middlewareHost = "https://uip-uat.development.dc.opap";
    config.janus.baseUrl = "https://janusuat.development.dc.opap";
    config.toraMiddlewareHost = "https://uip-uat.opap.gr";
    config.psMiddlewareHost = "https://uatapi.pamestoixima.gr";
    config.pam.webBaseUrl = "https://onlineapiuat.allwyn.gr";
    config.pam.boBaseUrl = "https://pamuat.development.dc.opap";
    config.pam.walletHost= "https://pamuat-ingressvip.development.dc.opap";
    config.playerId = 939932925;
  } else if (env === "preprod") {
    config.middlewareHost = "http://uip-pre.development.dc.opap";
    config.janus.baseUrl = "https://januspre.development.dc.opap";
    config.toraMiddlewareHost = "http://uip-pre.opap.gr";
    config.psMiddlewareHost = "https://preapi.pamestoixima.gr";
    config.pam.webBaseUrl = "https://onlineapipre.allwyn.gr";
    config.pam.boBaseUrl = "https://pampre.development.dc.opap";
    config.playerId = 708235797;
  }
  else if (env === "local") {
        config.janus.baseUrl = "https://janusint.development.dc.opap",
        config.middlewareHost = "http://localhost:80",
        config.toraMiddlewareHost = "https://uip-dev.opap.gr",
        config.psMiddlewareHost= config.middlewareHost,
        config.playerId = 191088323
  }

  return config;
}
