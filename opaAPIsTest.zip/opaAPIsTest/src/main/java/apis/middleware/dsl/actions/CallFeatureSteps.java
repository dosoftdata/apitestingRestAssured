package apis.middleware.dsl.actions;

import apis.middleware.dsl.FeatureCaller;
import apis.middleware.dsl.ScenarioContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import io.cucumber.java.en.When;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

/**
 * Karate-style {@code call feature} step.
 *
 * <pre>
 *   * call feature features/common/landed.feature
 *   * call feature features/common/landed.feature scenario Land on final
 * </pre>
 *
 * The called feature runs inside the current scenario, sharing its
 * {@link ScenarioContext} (variables, cookie jar, request spec) — values it
 * captures via {@code def x in response...} are available to the caller as
 * {@code {{x}}} afterwards. See {@link FeatureCaller} for semantics and limits.
 */
@Slf4j
public final class CallFeatureSteps extends DslHelper {

  /**
   * Instantiates a new Call feature steps.
   *
   * @param context the context
   */
  public CallFeatureSteps(ScenarioContext context) {
    super(context);
  }

  /**
   * Call feature.
   *
   * @param featurePath  the feature path (placeholders allowed)
   * @param scenarioName optional exact scenario name to run; all scenarios if omitted
   */
  // The negative lookbehind keeps this from colliding with the "with args" variant
  // below (the greedy scenario group would otherwise swallow " with args").
  // Consequence: a scenario whose name literally ends in "with args" can only be
  // called via the with-args step.
  @When("^call feature ([^\\s]+)(?: scenario (.+))?(?<! with args)$")
  public void callFeature(String featurePath, String scenarioName) {
    FeatureCaller.call(context, ScenarioContext.resolve(featurePath), scenarioName);
  }

  /**
   * Call feature with arguments — Karate's {@code call read('x.feature') { arg: v }}.
   * The docstring is a JSON object; each entry is set as a context variable before
   * the callee runs, so the callee reads them as {{arg}}. Placeholders inside the
   * JSON are resolved first, so caller variables can be forwarded.
   *
   * <pre>
   *   * call feature features/common/landed.feature with args
   *     """
   *     { "argItemId": "ARG-9", "argQty": 42 }
   *     """
   * </pre>
   *
   * Note: variables share the caller's per-thread context (consistent with the rest
   * of call feature), so the args remain visible after the call returns.
   *
   * @param featurePath  the feature path (placeholders allowed)
   * @param scenarioName optional exact scenario name to run; all scenarios if omitted
   * @param argsJson     docstring with a JSON object of variables to set
   */
  @When("^call feature ([^\\s]+)(?: scenario (.+))? with args$")
  public void callFeatureWithArgs(String featurePath, String scenarioName, String argsJson) {
    try {
      Map<String, Object> args = mapper.readValue(
          ScenarioContext.resolve(argsJson), new TypeReference<Map<String, Object>>() {});
      args.forEach(ScenarioContext::set);
    } catch (JsonProcessingException e) {
      throw new IllegalArgumentException(
          "[call feature] 'with args' docstring is not a JSON object: " + argsJson, e);
    }
    FeatureCaller.call(context, ScenarioContext.resolve(featurePath), scenarioName);
  }
}
