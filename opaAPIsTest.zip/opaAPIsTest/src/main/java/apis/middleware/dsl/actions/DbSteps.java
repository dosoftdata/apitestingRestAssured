package apis.middleware.dsl.actions;

import apis.middleware.core.helpers.DBManager;
import apis.middleware.dsl.ScenarioContext;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;

/**
 * Karate-style DSL glue for JDBC CRUD against the pooled {@link DBManager}.
 *
 * Grammar (inline):
 *   def _    = db.connect('jdbc:sqlite:target/sqlite-demo.db')
 *   def _    = db.execute('CREATE TABLE players (id INTEGER PRIMARY KEY, name TEXT)')
 *   def rows = db.query('SELECT id, name FROM players')
 *
 * Grammar (docstring) — useful for multi-line SQL:
 *   When def _ = db.execute
 *   """
 *   INSERT INTO players(id, name) VALUES (1, 'Alice')
 *   """
 *
 * SQL string literals follow standard SQL escaping: double a single quote
 * inside the wrapping quotes, e.g. {@code VALUES (1, ''Alice'')}.
 *
 * Assertions on stored rows:
 *   match rows.size = 1
 *   match rows[0].name = Alice
 */
@Slf4j
@SuppressWarnings("deprecation")
public final class DbSteps extends DslHelper {

  public DbSteps(ScenarioContext context) { super(context); }

  // ----- connect -----

  @When("^def (\\w+) = db\\.connect\\((.+)\\)$")
  public void connect(String var, String urlArg) {
    String url = stripQuotes(ScenarioContext.resolve(urlArg));
    DBManager.getInstance().connect(url, "", "");
    ScenarioContext.set(var, "connected");
  }

  // ----- execute (DDL / INSERT / UPDATE / DELETE) -----

  @When("^def (\\w+) = db\\.execute\\((.+)\\)$")
  public void executeInline(String var, String sqlArg) throws SQLException {
    int rows = executeSql(stripQuotes(ScenarioContext.resolve(sqlArg)));
    ScenarioContext.set(var, rows);
  }

  @When("^def (\\w+) = db\\.execute$")
  public void executeDoc(String var, String sql) throws SQLException {
    int rows = executeSql(ScenarioContext.resolve(sql));
    ScenarioContext.set(var, rows);
  }

  // ----- import CSV file -----

  @When("^def (\\w+) = db\\.importCsv\\('([^']+)'\\s*,\\s*'([^']+)'\\)$")
  public void importCsv(String var, String pathArg, String tableArg) throws IOException, SQLException {
    String path = ScenarioContext.resolve(pathArg);
    String table = ScenarioContext.resolve(tableArg);
    int inserted = importCsvFile(path, table);
    ScenarioContext.set(var, inserted);
  }

  // ----- query (SELECT) -----

  @When("^def (\\w+) = db\\.query\\((.+)\\)$")
  public void queryInline(String var, String sqlArg) throws SQLException {
    List<Map<String, Object>> rows = runQuery(stripQuotes(ScenarioContext.resolve(sqlArg)));
    ScenarioContext.set(var, rows);
  }

  @When("^def (\\w+) = db\\.query$")
  public void queryDoc(String var, String sql) throws SQLException {
    List<Map<String, Object>> rows = runQuery(ScenarioContext.resolve(sql));
    ScenarioContext.set(var, rows);
  }

  // ----- assertions on stored rows -----

  @Then("^match (\\w+)\\[(\\d+)\\]\\.(\\w+) = (.+)$")
  public void matchRowCell(String var, int idx, String col, String expected) {
    List<Map<String, Object>> rows = rowsOf(var);
    Object actual = rows.get(idx).get(col);
    Assert.assertEquals(
        String.valueOf(actual),
        ScenarioContext.resolve(expected).trim(),
        "row[" + idx + "]." + col + " mismatch in '" + var + "'");
  }

  @Then("^match (\\w+)\\.size = (\\d+)$")
  public void matchSize(String var, int expectedSize) {
    Object v = ScenarioContext.get(var);
    int actual = (v instanceof List) ? ((List<?>) v).size() : -1;
    Assert.assertEquals(actual, expectedSize, "size mismatch in '" + var + "'");
  }

  // Scalar match for context variables, e.g. `match inserted = 1` after
  // `def inserted = db.execute(...)`. Word-only LHS keeps this from clashing
  // with `match rows.size = ...` or `match rows[0].name = ...`.
  @Then("^match (\\w+) = (.+)$")
  public void matchScalar(String var, String expected) {
    Object actual = ScenarioContext.get(var);
    Assert.assertEquals(
        String.valueOf(actual),
        ScenarioContext.resolve(expected).trim(),
        "scalar mismatch in '" + var + "'");
  }

  // ----- helpers -----

  @SuppressWarnings("unchecked")
  private static List<Map<String, Object>> rowsOf(String var) {
    Object v = ScenarioContext.get(var);
    if (!(v instanceof List)) {
      throw new AssertionError("context variable '" + var + "' is not a row list");
    }
    return (List<Map<String, Object>>) v;
  }

  // Strips one layer of surrounding ' or " and un-doubles inner single quotes
  // (standard SQL literal escape).
  private static String stripQuotes(String s) {
    String t = s.trim();
    if (t.length() >= 2) {
      char first = t.charAt(0), last = t.charAt(t.length() - 1);
      if ((first == '\'' && last == '\'') || (first == '"' && last == '"')) {
        return t.substring(1, t.length() - 1).replace("''", "'");
      }
    }
    return t;
  }

  private static int executeSql(String sql) throws SQLException {
    try (Connection c = DBManager.getInstance().getConnection();
         Statement st = c.createStatement()) {
      st.execute(sql);
      int n = st.getUpdateCount();
      return n < 0 ? 0 : n;
    }
  }

  // Reads a CSV (first line = header), creates table {name}(col1 TEXT, col2 TEXT, ...)
  // if absent, and bulk-inserts all data rows. Returns the count of rows inserted.
  private static int importCsvFile(String path, String table) throws IOException, SQLException {
    File file = new File(path);
    try (BufferedReader br = new BufferedReader(
             new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
      String headerLine = br.readLine();
      if (headerLine == null) return 0;
      String[] cols = headerLine.split(",");
      for (int i = 0; i < cols.length; i++) cols[i] = cols[i].trim();

      try (Connection c = DBManager.getInstance().getConnection()) {
        StringBuilder ddl = new StringBuilder("CREATE TABLE IF NOT EXISTS \"")
            .append(table).append("\" (");
        for (int i = 0; i < cols.length; i++) {
          if (i > 0) ddl.append(", ");
          ddl.append('"').append(cols[i]).append("\" TEXT");
        }
        ddl.append(")");
        try (Statement st = c.createStatement()) { st.execute(ddl.toString()); }

        StringBuilder ins = new StringBuilder("INSERT INTO \"").append(table).append("\" (");
        for (int i = 0; i < cols.length; i++) {
          if (i > 0) ins.append(", ");
          ins.append('"').append(cols[i]).append('"');
        }
        ins.append(") VALUES (");
        for (int i = 0; i < cols.length; i++) {
          if (i > 0) ins.append(", ");
          ins.append("?");
        }
        ins.append(")");

        boolean prevAuto = c.getAutoCommit();
        c.setAutoCommit(false);
        int count = 0;
        try (PreparedStatement ps = c.prepareStatement(ins.toString())) {
          String line;
          while ((line = br.readLine()) != null) {
            if (line.isEmpty()) continue;
            String[] vals = line.split(",", -1);
            for (int i = 0; i < cols.length; i++) {
              ps.setString(i + 1, i < vals.length ? vals[i].trim() : "");
            }
            ps.addBatch();
            count++;
          }
          ps.executeBatch();
          c.commit();
        } catch (SQLException e) {
          c.rollback();
          throw e;
        } finally {
          c.setAutoCommit(prevAuto);
        }
        return count;
      }
    }
  }

  private static List<Map<String, Object>> runQuery(String sql) throws SQLException {
    try (Connection c = DBManager.getInstance().getConnection();
         Statement st = c.createStatement();
         ResultSet rs = st.executeQuery(sql)) {
      ResultSetMetaData md = rs.getMetaData();
      int n = md.getColumnCount();
      List<Map<String, Object>> rows = new ArrayList<>();
      while (rs.next()) {
        Map<String, Object> row = new LinkedHashMap<>();
        for (int i = 1; i <= n; i++) {
          row.put(md.getColumnLabel(i), rs.getObject(i));
        }
        rows.add(row);
      }
      return rows;
    }
  }
}
