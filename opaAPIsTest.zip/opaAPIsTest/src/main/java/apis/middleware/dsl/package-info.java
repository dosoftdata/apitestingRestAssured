/**
 * The middleware testing DSL (Domain-Specific Language).
 *
 * <p>Fluent builders and matchers for expressing API scenarios in a readable,
 * composable style. Targets black-box tests over the middleware layer.</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>Fluent builders for requests, steps, and assertions</li>
 *   <li>Reusable scenario fragments and fixtures</li>
 *   <li>Integration helpers to run scenarios in CI</li>
 * </ul>
 *
 * @since 1.0
 * @see apis.middleware.dsl.actions
 * @see apis.middleware.models.request
 */
package apis.middleware.dsl;