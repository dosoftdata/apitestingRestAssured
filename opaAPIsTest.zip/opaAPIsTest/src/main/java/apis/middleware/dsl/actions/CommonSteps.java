package apis.middleware.dsl.actions;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;

import io.cucumber.java.en.*;
import io.restassured.response.ValidatableResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import apis.middleware.core.filters.RequestDelayFilter;
import apis.middleware.dsl.*;
import apis.middleware.utilities.RandomUtil;

import java.io.File;
import org.hamcrest.Matcher;
import org.testng.Assert;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.testng.Assert.assertTrue;

/**
 * The type Common steps.
 */
@Slf4j
@SuppressWarnings("deprecation")
public final class CommonSteps extends DslHelper {

  /**
   * Instantiates a new Common steps.
   *
   * @param context the context
   */
  public CommonSteps(ScenarioContext context) {super(context);}

  /**
   * Url.
   *
   * @param expression the expression
   */
  @When("^url (.+)")
  public void url(String expression) {
    this.context.getSpec().setBaseUri(ScenarioContext.resolve(expression));
    epicCounter();
  }

  /**
   * Delay request.
   *
   * @param millisecond the millisecond
   */
  @When("^delay request (\\d+)")
  public void delayRequest(int millisecond) {
    this.context.getSpec().setFilter(new RequestDelayFilter(millisecond));
  }

  /**
   * Path.
   *
   * @param path the path
   */
  @When("^path (.+)")
  @When("^uri (.+)")
  public void path(String path) {
    this.context.getSpec().setBasePath(ScenarioContext.resolve(path));
  }

  /**
   * Param.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^param ([^\\s]+) = (.+)")
  public void param(String name, String value) {
    this.context.getSpec().setQueryParam(name, ScenarioContext.resolve(value));
  }

  /**
   * Path param.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^pathParam ([^\\s]+) = (.+)")
  public void pathParam(String name, String value) {
    this.context.getSpec().setPathParam(name, ScenarioContext.resolve(value));
  }

  /**
   * Cookie.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^cookie ([^\\s]+) = (.+)")
  public void cookie(String name, String value) {
    this.context.getSpec().setCookie(name, ScenarioContext.resolve(value));
  }

  /**
   * Header.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^header ([^\\s]+) = (.+)")
  public void header(String name, String value) {

    this.context.getSpec().setHeader(name, ScenarioContext.resolve(value));
  }

  /**
   * Method.
   *
   * @param method the method
   * @param path   the path
   */
  @When("^method (Get|Post|Put|Patch|Delete)(?: \"([^\"]+)\")?$")
  @When("^method (get|post|put|patch|delete)(?: \"([^\"]+)\")?$")
  @When("^method (GET|POST|PUT|PATCH|DELETE)(?: \"([^\"]+)\")?$")
  public void method(String method, String path) {
    if (path != null) {
      this.context.getSpec().setBasePath(ScenarioContext.resolve(path));
    }
    this.context.getApi().setResponse(this.context.getRes().spec(this.context.getSpec().build()).when().request(method.toUpperCase()) );

  }

  /**
   * Retry.
   *
   * @param method        the method
   * @param path          the path
   * @param conditionJson the condition json
   */
  @When("^retry (GET|POST|PUT|PATCH|DELETE)\\s+([^\\s]+)? until condition$")
  public void retry(String method, String path,  String conditionJson)  {
    awaitUntil(method, path, conditionJson);
  }

  /**
   * Retry json.
   *
   * @param method        the method
   * @param path          the path
   * @param conditionJson the condition json
   */
  @When("^retry (GET|POST|PUT|PATCH|DELETE)\\s+([^\\s]+)? until condition (.*)$")
  public void retryJson(String method, String path,  String conditionJson)  {
    awaitUntil(method, path, conditionJson);
  }

  /**
   * Form field.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^form field ([^\\s]+) = (.+)")
  public void formField(String name, Object value) {
    this.context.getSpec().setFormParam(name, ScenarioContext.resolve((String) value));
  }

  /**
   * Request docstring.
   *
   * @param body the body
   */
  @When("^request$")
  public void requestDocstring(String body) {
    this.context.getSpec().setBody(ScenarioContext.resolve(body));
  }

  /**
   * Request.
   *
   * @param body the body
   */
  @When("^request (.+)")
  public void request(String body) { this.context.getSpec().setBody(ScenarioContext.resolve(body));}

  /**
   * Def.
   *
   * @param name       the name
   * @param expression the expression
   */
  @When("^def (\\w+) = (?!db\\.)(?!random \\d+ digits$)(?!response substring after )(?!word \\d+ of response\\.)(.+)$")
  public void def(String name, String expression) {
    ScenarioContext.set(name, ScenarioContext.resolve(expression));
  }

  /**
   * Def substring of the response body — everything after the first occurrence
   * of the delimiter, cut to the given length. Generic equivalent of the
   * domain "extract string using ... from body response" step, usable inside
   * called features (FeatureCaller can only dispatch src/main glue).
   * Example: {@code def hashId = response substring after &hash= length 36}
   *
   * @param name      the variable name
   * @param delimiter the literal delimiter to split on
   * @param length    number of characters to keep after the delimiter
   */
  @When("^def (\\w+) = response substring after (\\S+) length (\\d+)$")
  public void defResponseSubstring(String name, String delimiter, Integer length) {
    String body = this.context.getApi().getResponse().asString();
    String value = body.split(java.util.regex.Pattern.quote(delimiter))[1].substring(0, length);
    ScenarioContext.set(name, value);
  }

  /**
   * Def the Nth space-separated word (0-based) of a response field — e.g. the
   * OTP code embedded in an SMS message text.
   * Example: {@code def OTP = word 4 of response.data[0].messageText}
   *
   * @param name  the variable name
   * @param index 0-based word index
   * @param expr  RestAssured jsonPath expression of the field
   */
  @When("^def (\\w+) = word (\\d+) of response\\.(.+)$")
  public void defWordOfResponse(String name, Integer index, String expr) {
    String value = this.context.getApi().getResponse().jsonPath().getString(expr.trim());
    ScenarioContext.set(name, value.split(" ")[index]);
  }

  /**
   * Def random digits — a fresh value on every invocation, unlike the
   * config.js {@code $random8Digit} which is generated once per JVM. Use for
   * data that must be unique per scenario/row (e.g. MSISDNs), so that
   * whole-feature retries and repeated rows don't collide with already
   * registered data.
   *
   * @param name   the variable name
   * @param length number of digits to generate
   */
  @When("^def (\\w+) = random (\\d+) digits$")
  public void defRandomDigits(String name, Integer length) {
    ScenarioContext.set(name, RandomUtil.generateSecureDigits(length));
  }

  /**
   * Def doc string.
   *
   * @param name       the name
   * @param expression the expression
   */
  @When("^def (.+) =$")
  public void defDocString(String name, String expression) {
    ScenarioContext.set(name, expression);
  }

  /**
   * Print.
   *
   * @param expression the expression
   */
  @When("^print (.+)")
  public void print(@NonNull String expression) {
    log.info(ScenarioContext.resolve(expression));
  }

  /**
   * Def response.
   *
   * @param name       the name
   * @param expression the expression
   */
  @When("^def (.*) in response.(.*)$")
  public void defResponse(String name, String expression) {
    String[] expressions = expression.split(",");
    List<String> values = new ArrayList<>();

    for (String expr : expressions) {
      String trimmedExpr = expr.trim();
      String value = context.getApi().getResponse().jsonPath().getString(trimmedExpr);
      if (value != null) {
        values.add(value);
      }
    }

    if (!values.isEmpty()) {
      String combinedValue = String.join(",", values);
      ScenarioContext.set(name, combinedValue);
    }
  }

  /**
   * Def response cookie.
   *
   * @param name       the name
   * @param expression the expression
   */
  @When("^Cookie (.+) in response.(.+)$")
  public void defResponseCookie(@NonNull String name, @NonNull String expression) {
    String[] expressions = expression.split(",");
    List<String> values = new ArrayList<>();

    for (String expr : expressions) {
      String trimmedExpr = expr.trim();
      String value = context.getApi().getResponse().cookie(trimmedExpr);
      if (value != null) {
        values.add(value);
      }
    }

    if (!values.isEmpty()) {
      String combinedValue = String.join(",", values);
      ScenarioContext.set(name, combinedValue);
    }
  }

  /**
   * Def response header.
   *
   * @param name       the name
   * @param expression the expression
   */
  @When("^Header (.+) in response.(.+)$")
  public void defResponseHeader(@NonNull String name, @NonNull String expression) {
    String[] expressions = expression.split(",");
    List<String> values = new ArrayList<>();

    for (String expr : expressions) {
      String trimmedExpr = expr.trim();
      String value = context.getApi().getResponse().getHeader(trimmedExpr);
      if (value != null) {
        values.add(value);
      }
    }

    if (!values.isEmpty()) {
      String combinedValue = String.join(",", values);
      ScenarioContext.set(name, combinedValue);
    }
  }


  /**
   * Status.
   *
   * @param status the status
   */
  @When("^status (\\d+)")
  public void status(int status) {
    context.getApi().getResponse().then().statusCode(status);
  }

  /**
   * Status or.
   *
   * @param status  the status
   * @param status1 the status 1
   */
  @When("^status (\\d+) or (\\d+)")
  public void statusOr(int status, int status1) {
    context.getApi().getResponse().then().statusCode(
        anyOf(equalTo(status),
            equalTo(status1))
    );
  }

  /**
   * Assert equal.
   *
   * @param expression the expression
   * @param s1         the s 1
   */
  @When("^assert (.+) = (.+)")
  public void assertEqual(String expression,String s1) {
    Assert.assertEquals(ScenarioContext.resolve(expression.toString().trim()), s1.toString().trim() == ""? null : s1.toString().trim() );
  }

  /**
   * Match.
   *
   * @param expression the expression
   * @param op1        the op 1
   * @param rhs        the rhs
   */

  @When("^match response (.+?)(=|contains|any|only|deep)(.*?)(?: if (present|status\\b.+))?$")
  public void match(String expression, String op1, String rhs, String condition) throws JsonProcessingException {
    if (shouldSkip(condition, expression.trim())) return;
    String jsonPath = expression.trim();
    String expected = ScenarioContext.resolve(rhs).trim();

    Object actual = context.getApi().getResponse().path(jsonPath);

    switch (op1) {
      case "=":
        assertThat(actual.toString(), equalTo(expected));
        break;
      case "contains":
        assertThat(actual.toString(), containsString(expected));
        break;
      case "any":
        assertThat(actual.toString().split(","), hasItemInArray(expected));
        break;
      case "only":
        assertThat(actual.toString(), equalTo(expected));
        break;
      case "deep":
        JsonNode actualNode = mapper.readTree(mapper.writeValueAsString(actual));
        JsonNode expectedNode = mapper.readTree(expected);
        assertThat("JSON deep comparison failed", actualNode.equals(expectedNode), is(true));
        break;
      default:
        log.error("Unsupported match operator: " .concat( op1));
    }
  }

  /**
   * Match doc string.
   *
   * @param expression the expression
   * @param op1        the op 1
   * @param rhs        the rhs
   */
  @When("^match string (.+?)(=|contains|has)(.*?)(?: if (present|status\\b.+))?$")
  public void matchDocString(String expression, String op1, String rhs, String condition)  {
    String _expression = ScenarioContext.resolve(expression);
    if (shouldSkip(condition, _expression)) return;
    String expected = ScenarioContext.resolve(rhs).trim();

    switch (op1) {
      case "=":
        assertThat(_expression.toString(), equalTo(expected));
        break;
      case "contains":
        assertThat(_expression.toString(), containsString(expected));
        break;
      case "any":
        assertThat(_expression.toString().split(","), hasItemInArray(expected));
        break;
      case "only":
        assertThat(_expression.toString(), equalTo(expected));
        break;
      default:
        log.error("Unsupported match operator: " .concat( op1));
    }
  }

  /**
   * Redirect follow — Postman-style "Automatically follow redirects" toggle.
   * Accepts true/false or 1/0. RestAssured follows redirects by default, so the
   * usual use is "redirect follow false" to assert on the 3xx response itself.
   * (Boolean.valueOf on a digit string is always false, which is why the old
   * numeric-only form could never enable following.)
   *
   * @param b true|false|1|0
   */
  @When("^redirect follow (true|false|1|0)$")
  public void redirectFollow(String b) {
    this.context.getSpec().setRedirectFollow(toBoolean(b));
  }

  /**
   * Redirect circular — allow circular redirects (RestAssured default: off).
   * Accepts true/false or 1/0.
   *
   * @param b true|false|1|0
   */
  @When("^redirect circular (true|false|1|0)$")
  public void redirectCircular(String b) {
    this.context.getSpec().setRedirectCircular(toBoolean(b));
  }


  /**
   * Redirect max — cap how many redirects are followed before failing, like
   * Postman's "Maximum number of redirects" setting (RestAssured default: 100).
   * Only meaningful while following is enabled.
   *
   * @param max the maximum redirect count
   */
  @When("^redirect max (\\d+)$")
  public void redirectMax(Integer max) {
    this.context.getSpec().setRedirectMax(max);
  }

  /**
   * Multipart file.
   *
   * @param controlName the controlName
   * @param filePath the file path
   * @param mimeType the mime type
   */
  @When("^multipart file (.+) path (.+) mimeType (.+)")
  public void multipartFile(String controlName, String filePath, String mimeType) {
    File resolved = resolveFile(filePath);
    if (resolved.isDirectory()) {
      resolved = new File(resolved, controlName);
    }
    this.context.getSpec().addMultiPartFile(controlName, resolved, mimeType);
  }


  /**
   * Multipart.
   *
   * @param file     the file
   * @param filePath the file path
   * @param mimeType the mime type
   */
  @When("^multipart (.+), (.+), (.+)$")
  public void multipart(String file, String filePath, String mimeType) {
    this.context.getSpec().addMultiPart(file, filePath, mimeType);
  }

  /**
   * Match.
   *
   * @param expected the expected
   */
  @Then("^match(?: if (present|status\\b.+))?$")
  public void match(String condition, String expected) {
    if (shouldSkip(condition, null)) return;
    JsonMatcherResult result = JsonMatcher.matchJson(this.context.getApi().getResponse().asString(), ScenarioContext.resolve(expected));
    assertTrue(result.isSuccess(), result.getMessage());
  }

  /**
   * Match path.
   *
   * @param path the path
   * @param expr the expr
   */
  @Then("^match path (.+?) should be (.+?)(?: if (present|status\\b.+))?$")
  public void matchPath(String path, String expr, String condition) {
    if (shouldSkip(condition, path)) return;
    JsonMatcherResult result = JsonMatcher.matchJson(this.context.getApi().getResponse().asString(), path + " " + ScenarioContext.resolve(expr));
    assertTrue(result.isSuccess(), result.getMessage());
  }

  /**
   * Match each.
   *
   * @param arrayPath the array path
   * @param expected  the expected
   */
  @Then("^match each (.+?) should match(?: if (present|status\\b.+))?$")
  public void match_each(String arrayPath, String condition, String expected) {
    if (shouldSkip(condition, arrayPath)) return;
    JsonMatcherResult result = JsonMatcher.matchEach(this.context.getApi().getResponse().asString(), arrayPath, ScenarioContext.resolve(expected));
    assertTrue(result.isSuccess(), result.getMessage());
  }

  /**
   * Match response body path.
   *
   * @param path        the path
   * @param matcherName the matcher name
   * @param expected    the expected
   */
  @Then("^match response body path (.+?) should be (.+?) (.+?)(?: if (present|status\\b.+))?$")
  public void match_response_body_path(String path, String matcherName, String expected, String condition) {
    if (shouldSkip(condition, path)) return;
    ValidatableResponse vresponse = context.getApi().getResponse().then();
    Matcher<?> matcher = buildMatcher(matcherName, expected);
    vresponse.body(path, matcher);
  }

  /**
   * Match response time.
   *
   * @param milliseconds the milliseconds
   */
  @Then("^match response time should be less than (\\d+) milliseconds(?: if (present|status\\b.+))?$")
  public void match_response_time(Long milliseconds, String condition) {
    if (shouldSkip(condition, null)) return;
    this.context.getApi().getResponse().then().time(lessThan(milliseconds));
  }



}
