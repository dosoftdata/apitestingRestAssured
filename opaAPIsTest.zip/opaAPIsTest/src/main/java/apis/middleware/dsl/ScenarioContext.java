
package apis.middleware.dsl;

import io.cucumber.java.Scenario;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import io.restassured.specification.RequestSpecification;
import lombok.*;
import apis.middleware.core.base.ApiBase;
import apis.middleware.core.base.CustomRequestSpec;

import static io.restassured.RestAssured.given;

/**
 * The type Scenario context.
 * - ThreadLocal per-scenario store (existing)
 * - global, write-once store shared across all threads/scenarios
 */
@Getter
public class ScenarioContext {

  // ===== per-scenario store (existing) =====
  private static final ThreadLocal<Map<String, Object>> context = ThreadLocal.withInitial(HashMap::new);

  @Getter
  private ApiBase api;

  /** Current Scenario (ThreadLocal). */
  public static final ThreadLocal<Scenario> sc = new ThreadLocal<>();

  /** Scenario-level spec holder. */
  CustomRequestSpec spec;

  /** Construct per-scenario context. */
  public ScenarioContext() {
    api  = new ApiBase();
    spec = ApiBase.spec();
  }

  /**
   * Fresh request specification per call.
   * Previously cached in a field, which caused {@code .spec(...)} merges to
   * accumulate filters (notably the Allure filter) across retry iterations,
   * producing duplicate Allure attachments per request. Returning a fresh
   * {@code given()} keeps each iteration's filter chain at length one.
   */
  public RequestSpecification getRes() {
    return given();
  }

  /** Per-scenario put */
  public static void set(String key, Object value) {
    context.get().put(key, value);
  }

  /**
   * Per-scenario get (untyped).
   * Checks the per-thread map first, then falls back to the cross-thread
   * GLOBAL map. The fallback is required under feature-parallel execution:
   * config values and one-time bootstrap output are written by a single
   * winning thread but must be visible to every worker.
   */
  public static Object get(String key) {
    Map<String, Object> local = context.get();
    if (local.containsKey(key)) return local.get(key);
    return GLOBAL.get(key);
  }

  /**
   * Per-scenario get (typed convenience).
   * Mirrors the GLOBAL fallback in {@link #get(String)} so that config values
   * loaded once into the cross-thread store are visible from every worker
   * under feature-parallel execution. Returns null (not the literal string
   * "null") when the key is absent in both stores.
   */
  public String getProp(String key) {
    Object v = get(key);
    return v == null ? null : String.valueOf(v);
  }

  /** Per-scenario set (instance convenience) */
  public void setProp(String key, Object value) {
    context.get().put(key, value);
  }
  /** Per-scenario hasProp — checks per-thread store, then GLOBAL fallback. */
  public Boolean hasProp(String key) {
    return context.get().containsKey(key) || GLOBAL.containsKey(key);
  }

  /**
   * Clear per-scenario context.
   * NOTE: Using remove() prevents retaining the map on long-lived test worker threads.
   */
  public static void clear() {
    context.remove();
    sc.remove();
  }

  /** Per-scenario get all */
  public static Map<String, Object> getAll() {
    return context.get();
  }

  private static final Pattern HASH_PATTERN  = Pattern.compile("#\\((.*?)\\)");
  private static final Pattern BRACE_PATTERN = Pattern.compile("\\{\\{(.*?)\\}\\}");

  /**
   * Resolve placeholders in a string using context variables.
   * Supports #(var) and {{var}} syntax. The {{var}} pass runs over the result
   * of the #(var) pass so both styles can coexist in one string.
   */
  public static String resolve(String text) {
    if (text == null) return null;
    String afterHash = replaceAll(text, HASH_PATTERN);
    return replaceAll(afterHash, BRACE_PATTERN);
  }

  private static String replaceAll(String text, Pattern pattern) {
    Matcher m = pattern.matcher(text);
    StringBuffer sb = new StringBuffer();
    while (m.find()) {
      Object value = get(m.group(1));
      m.appendReplacement(sb, Matcher.quoteReplacement(value != null ? value.toString() : ""));
    }
    m.appendTail(sb);
    return sb.toString();
  }

  // Instance-scoped variables (existing)
  private final Map<String, Object> variables = new HashMap<>();

  public void setVariable(String name, Object value) { variables.put(name, value); }
  public Object getVariable(String name) { return variables.get(name); }

  // ===== NEW: global, write-once store =====

  /** Global store shared by all threads/scenarios; intended for immutable or write-once values. */
  private static final ConcurrentMap<String, Object> GLOBAL = new ConcurrentHashMap<>();

  /**
   * Put globally only if absent (write-once semantics).
   * @return previous value if one existed; otherwise null
   */
  public static Object putIfAbsentGlobal(String key, Object value) {
    return GLOBAL.putIfAbsent(key, value);
  }

  /** Get a global value (typed). */
  @SuppressWarnings("unchecked")
  public static <T> T getGlobal(String key, Class<T> type) {
    Object v = GLOBAL.get(key);
    return type.isInstance(v) ? (T) v : null;
  }

  /**
   * Clear the global store.
   * Use only at full suite shutdown if you really need to drop globals.
   */
  public static void clearGlobal() {
    GLOBAL.clear();
  }
}
