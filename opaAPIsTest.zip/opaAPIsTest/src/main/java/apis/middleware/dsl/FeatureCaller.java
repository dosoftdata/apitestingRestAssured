package apis.middleware.dsl;

import apis.middleware.dsl.actions.CallFeatureSteps;
import apis.middleware.dsl.actions.CommonSteps;
import apis.middleware.dsl.actions.DbSteps;
import apis.middleware.dsl.actions.OneTimeSteps;
import io.cucumber.gherkin.GherkinParser;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.messages.types.Envelope;
import io.cucumber.messages.types.Pickle;
import io.cucumber.messages.types.PickleDocString;
import io.cucumber.messages.types.PickleStep;
import io.cucumber.messages.types.PickleStepArgument;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * DSL {@code call feature} engine.
 *
 * <p>Parses a .feature file into pickles (Background merged, Scenario Outline
 * examples expanded) and replays every step through the project's own DSL glue
 * ({@link CommonSteps}, {@link OneTimeSteps}, {@link DbSteps}, {@link CallFeatureSteps}),
 * bound to the <b>caller's</b> {@link ScenarioContext}. The called feature therefore
 * reads and writes the same {{variables}}, cookie jar and request spec as the calling
 * scenario — captured values ({@code def x in response...}) are visible to the caller
 * after the call, mirroring Karate's {@code call read(...)} semantics.
 *
 * <p>Limits (by design, documented in docs/04-writing-features):
 * <ul>
 *   <li>Called steps don't exist as Cucumber pickles — failures surface at the
 *       {@code call feature} step, with the offending feature/step in the message.</li>
 *   <li>Tags on the called feature are ignored: tag-driven hooks ({@code @needsPlayer},
 *       {@code @randomPlayer}) do NOT fire for it.</li>
 *   <li>Data tables in called features are not supported (docstrings are).</li>
 * </ul>
 */
@Slf4j
public final class FeatureCaller {

  /** Glue classes whose @Given/@When/@Then/@But regexes are dispatchable. */
  private static final List<Class<?>> GLUE_CLASSES = List.of(
      CommonSteps.class, OneTimeSteps.class, DbSteps.class, CallFeatureSteps.class);

  private static final int MAX_DEPTH = 5;
  private static final ThreadLocal<Deque<String>> CALL_STACK =
      ThreadLocal.withInitial(ArrayDeque::new);

  /** One dispatchable step definition: compiled regex -> glue method. */
  private record StepDef(Pattern pattern, Method method, Class<?> owner) {}

  private static volatile List<StepDef> registry;

  private FeatureCaller() { /* no instances */ }

  /**
   * Run a feature's scenarios inside the current scenario.
   *
   * @param context      the calling scenario's context (shared with the callee)
   * @param featurePath  path to the .feature (relative paths are tried against the
   *                     project root, then src/test/resources, then .../features)
   * @param scenarioName optional: run only the scenario with this exact name
   */
  public static void call(ScenarioContext context, String featurePath, String scenarioName) {
    Path file = resolveFeature(featurePath);
    String key = file.toAbsolutePath().normalize().toString();

    Deque<String> stack = CALL_STACK.get();
    if (stack.contains(key)) {
      throw new IllegalStateException("[call feature] recursive call detected: "
          + featurePath + " (stack: " + stack + ")");
    }
    if (stack.size() >= MAX_DEPTH) {
      throw new IllegalStateException("[call feature] max call depth (" + MAX_DEPTH
          + ") exceeded at " + featurePath);
    }

    stack.push(key);
    try {
      List<Pickle> pickles = parsePickles(file);
      if (scenarioName != null) {
        String wanted = scenarioName.trim();
        pickles = pickles.stream()
            .filter(p -> p.getName().trim().equalsIgnoreCase(wanted))
            .toList();
        if (pickles.isEmpty()) {
          throw new IllegalArgumentException("[call feature] no scenario named '"
              + wanted + "' in " + featurePath);
        }
      }
      if (pickles.isEmpty()) {
        throw new IllegalArgumentException("[call feature] no scenarios found in " + featurePath);
      }

      Object[] glue = instantiateGlue(context);
      for (Pickle pickle : pickles) {
        log.info("[call feature] {} :: scenario '{}'", featurePath, pickle.getName());
        for (PickleStep step : pickle.getSteps()) {
          dispatch(glue, step, featurePath);
        }
      }
    } finally {
      stack.pop();
      if (stack.isEmpty()) {
        CALL_STACK.remove();
      }
    }
  }

  // ===== parsing =====

  private static Path resolveFeature(String featurePath) {
    Path[] candidates = {
        Paths.get(featurePath),
        Paths.get("src/test/resources", featurePath),
        Paths.get("src/test/resources/features", featurePath),
    };
    for (Path c : candidates) {
      if (Files.isRegularFile(c)) return c;
    }
    throw new IllegalArgumentException("[call feature] feature file not found: " + featurePath
        + " (tried project root, src/test/resources, src/test/resources/features)");
  }

  private static List<Pickle> parsePickles(Path file) {
    GherkinParser parser = GherkinParser.builder()
        .includeSource(false)
        .includeGherkinDocument(false)
        .includePickles(true)
        .build();
    try {
      return parser.parse(file)
          .map(Envelope::getPickle)
          .filter(Optional::isPresent)
          .map(Optional::get)
          .collect(Collectors.toList());
    } catch (IOException e) {
      throw new IllegalStateException("[call feature] failed to parse " + file, e);
    }
  }

  // ===== dispatch =====

  private static Object[] instantiateGlue(ScenarioContext context) {
    return GLUE_CLASSES.stream().map(c -> {
      try {
        return c.getConstructor(ScenarioContext.class).newInstance(context);
      } catch (ReflectiveOperationException e) {
        throw new IllegalStateException("[call feature] cannot instantiate glue " + c, e);
      }
    }).toArray();
  }

  private static void dispatch(Object[] glue, PickleStep step, String featurePath) {
    String text = step.getText();
    String docString = step.getArgument()
        .flatMap(PickleStepArgument::getDocString)
        .map(PickleDocString::getContent)
        .orElse(null);
    if (step.getArgument().flatMap(PickleStepArgument::getDataTable).isPresent()) {
      throw new UnsupportedOperationException("[call feature] data tables are not supported"
          + " in called features (step: '" + text + "' in " + featurePath + ")");
    }

    List<StepDef> defs = registry();
    StepDef hit = null;
    Matcher hitMatcher = null;
    for (StepDef def : defs) {
      Matcher m = def.pattern().matcher(text);
      if (m.matches()) {
        if (hit != null && !hit.method().equals(def.method())) {
          throw new IllegalStateException("[call feature] ambiguous step '" + text + "' in "
              + featurePath + " — matches both " + describe(hit) + " and " + describe(def));
        }
        hit = def;
        hitMatcher = m;
      }
    }
    if (hit == null) {
      throw new IllegalStateException("[call feature] undefined step '" + text + "' in "
          + featurePath + " — no DSL pattern matches");
    }

    Object target = null;
    for (Object g : glue) {
      if (hit.owner().isInstance(g)) { target = g; break; }
    }

    Object[] args = buildArgs(hit, hitMatcher, docString, text, featurePath);
    log.info("[call feature]   -> {}", text);
    try {
      hit.method().setAccessible(true);
      hit.method().invoke(target, args);
    } catch (InvocationTargetException e) {
      Throwable cause = e.getCause() != null ? e.getCause() : e;
      throw new AssertionError("[call feature] step failed: '" + text + "' in "
          + featurePath + " — " + cause.getMessage(), cause);
    } catch (IllegalAccessException | IllegalArgumentException e) {
      throw new IllegalStateException("[call feature] cannot invoke " + describe(hit)
          + " for step '" + text + "'", e);
    }
  }

  private static Object[] buildArgs(StepDef def, Matcher m, String docString,
                                    String text, String featurePath) {
    Class<?>[] types = def.method().getParameterTypes();
    int groups = m.groupCount();
    boolean wantsDocString = types.length == groups + 1;
    if (!wantsDocString && types.length != groups) {
      throw new IllegalStateException("[call feature] arity mismatch for step '" + text
          + "' in " + featurePath + ": pattern has " + groups + " group(s) but "
          + describe(def) + " takes " + types.length + " parameter(s)");
    }
    if (wantsDocString && docString == null) {
      throw new IllegalStateException("[call feature] step '" + text + "' in " + featurePath
          + " requires a docstring (\"\"\"...\"\"\") argument");
    }

    Object[] args = new Object[types.length];
    for (int i = 0; i < groups; i++) {
      args[i] = convert(m.group(i + 1), types[i], text);
    }
    if (wantsDocString) {
      args[types.length - 1] = docString;
    }
    return args;
  }

  private static Object convert(String raw, Class<?> type, String stepText) {
    if (raw == null) return null;
    if (type == String.class || type == Object.class) return raw;
    if (type == Integer.class || type == int.class) return Integer.valueOf(raw.trim());
    if (type == Long.class || type == long.class) return Long.valueOf(raw.trim());
    if (type == Double.class || type == double.class) return Double.valueOf(raw.trim());
    if (type == Boolean.class || type == boolean.class) return Boolean.valueOf(raw.trim());
    throw new IllegalStateException("[call feature] unsupported parameter type " + type
        + " for step '" + stepText + "'");
  }

  private static String describe(StepDef def) {
    return def.owner().getSimpleName() + "." + def.method().getName()
        + " [" + def.pattern().pattern() + "]";
  }

  // ===== registry =====

  private static List<StepDef> registry() {
    List<StepDef> r = registry;
    if (r == null) {
      synchronized (FeatureCaller.class) {
        r = registry;
        if (r == null) {
          r = buildRegistry();
          registry = r;
        }
      }
    }
    return r;
  }

  private static List<StepDef> buildRegistry() {
    List<StepDef> defs = new ArrayList<>();
    for (Class<?> glue : GLUE_CLASSES) {
      for (Method method : glue.getDeclaredMethods()) {
        List<String> patterns = new ArrayList<>();
        for (Given a : method.getAnnotationsByType(Given.class)) patterns.add(a.value());
        for (When a : method.getAnnotationsByType(When.class)) patterns.add(a.value());
        for (Then a : method.getAnnotationsByType(Then.class)) patterns.add(a.value());
        for (But a : method.getAnnotationsByType(But.class)) patterns.add(a.value());
        for (String p : patterns) {
          defs.add(new StepDef(Pattern.compile(p), method, glue));
        }
      }
    }
    log.info("[call feature] step registry built: {} pattern(s) from {} glue class(es)",
        defs.size(), GLUE_CLASSES.size());
    return defs;
  }
}
