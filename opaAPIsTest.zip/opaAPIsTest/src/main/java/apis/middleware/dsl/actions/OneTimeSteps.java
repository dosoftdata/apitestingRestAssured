package apis.middleware.dsl.actions;

import apis.middleware.core.base.ApiBase;
import apis.middleware.core.filters.RequestDelayFilter;
import apis.middleware.dsl.JsonMatcher;
import apis.middleware.dsl.JsonMatcherResult;
import apis.middleware.dsl.ScenarioContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.io.File;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertTrue;

/**
 * The type Common steps.
 */
@Slf4j
@SuppressWarnings("deprecation")
public final class OneTimeSteps extends DslHelper {

  /**
   * Instantiates a new Common steps.
   *
   * @param context the context
   */
  public OneTimeSteps(ScenarioContext context) {
    super(context);
  }

  /**
   * Url.
   *
   * @param expression the expression
   */
  @When("^set Url (.+)")
  public void url(String expression) {
    spec = ApiBase.spec();
    spec.setBaseUri(ScenarioContext.resolve(expression));
    epicCounter();
  }

  /**
   * Delay request.
   *
   * @param millisecond the millisecond
   */
  @When("^add delay request (\\d+)")
  public void delayRequest(int millisecond) {
    spec.setFilter(new RequestDelayFilter(millisecond));
  }

  /**
   * Path.
   *
   * @param path the path
   */
  @When("^add path (.+)")
  @When("^add uri (.+)")
  public void path(String path) {
    spec.setBasePath(ScenarioContext.resolve(path));
  }

  /**
   * Param.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^add param ([^\\s]+) = (.+)")
  public void param(String name, String value) {
    spec.setQueryParam(name, ScenarioContext.resolve(value));
  }

  /**
   * Path param.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^add pathParam ([^\\s]+) = (.+)")
  public void pathParam(String name, String value) {
    spec.setPathParam(name, ScenarioContext.resolve(value));
  }

  /**
   * Cookie.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^set Cookie ([^\\s]+) = (.+)")
  public void cookie(String name, String value) {
    spec.setCookie(name, ScenarioContext.resolve(value));
  }

  /**
   * Header.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^set header ([^\\s]+) = (.+)")
  public void header(String name, String value) {
    spec.setHeader(name, ScenarioContext.resolve(value));
  }

  /**
   * Method.
   *
   * @param method the method
   * @param path   the path
   */
  @When("^set method (Get|Post|Put|Patch|Delete)(?: \"([^\"]+)\")?$")
  @When("^set method (get|post|put|patch|delete)(?: \"([^\"]+)\")?$")
  @When("^set method (GET|POST|PUT|PATCH|DELETE)(?: \"([^\"]+)\")?$")
  public void method(String method, String path) {
    if (path != null) {
      spec.setBasePath(ScenarioContext.resolve(path));
    }
    this.context.getApi().setResponse(spec.when().request(method.toUpperCase()));
  }

  /**
   * Form field.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^add form field ([^\\s]+) = (.+)")
  public void formField(String name, Object value) {
    spec.setFormParam(name, ScenarioContext.resolve((String) value));
  }

  /**
   * Request docstring.
   *
   * @param body the body
   */
  @When("^add request$")
  public void requestDocstring(String body) {
    spec.setBody(ScenarioContext.resolve(body));
  }

  /**
   * Request.
   *
   * @param body the body
   */
  @When("^add request (.+)")
  public void request(String body) { spec.setBody(ScenarioContext.resolve(body));}

  /**
   * Redirect follow — Postman-style "Automatically follow redirects" toggle.
   * Accepts true/false or 1/0. RestAssured follows redirects by default, so the
   * usual use is "add redirect follow false" to assert on the 3xx response itself.
   * (Boolean.valueOf on a digit string is always false, which is why the old
   * numeric-only form could never enable following.)
   *
   * @param b true|false|1|0
   */
  @When("^add redirect follow (true|false|1|0)$")
  public void redirectFollow(String b) {
    spec.setRedirectFollow(toBoolean(b));
  }

  /**
   * Redirect circular — allow circular redirects (RestAssured default: off).
   * Accepts true/false or 1/0.
   *
   * @param b true|false|1|0
   */
  @When("^add redirect circular (true|false|1|0)$")
  public void redirectCircular(String b) {
    spec.setRedirectCircular(toBoolean(b));
  }

  /**
   * Redirect max — cap how many redirects are followed before failing, like
   * Postman's "Maximum number of redirects" setting (RestAssured default: 100).
   * Only meaningful while following is enabled.
   *
   * @param max the maximum redirect count
   */
  @When("^add redirect max (\\d+)$")
  public void redirectMax(Integer max) {
    spec.setRedirectMax(max);
  }

  /**
   * Multipart file.
   *
   * @param file     the file
   * @param filePath the file path
   * @param mimeType the mime type
   */
  @When("^add multipart file (.+) path (.+) mimeType (.+)")
  public void multipartFile(String file, String filePath, String mimeType) {
    File resolved = resolveFile(filePath);
    if (resolved.isDirectory()) {
      resolved = new File(resolved, file);
    }
    spec.addMultiPartFile(file, resolved, mimeType);
  }



  /**
   * Multipart.
   *
   * @param file     the file
   * @param filePath the file path
   * @param mimeType the mime type
   */
  @When("^add multipart (.+), (.+), (.+)$")
  public void multipart(String file, String filePath, String mimeType) {
    spec.addMultiPart(file, filePath, mimeType);
  }

  /**
   * Check status.
   *
   * @param status the expected status
   */
  @Then("^check status (\\d+)$")
  public void checkStatus(int status) {
    context.getApi().getResponse().then().statusCode(status);
  }

  /**
   * Check status (either of two codes).
   *
   * @param status  the first acceptable status
   * @param status1 the second acceptable status
   */
  @Then("^check status (\\d+) or (\\d+)$")
  public void checkStatusOr(int status, int status1) {
    context.getApi().getResponse().then().statusCode(
        anyOf(equalTo(status), equalTo(status1))
    );
  }

  /**
   * Check match (full body) with optional conditional.
   *
   * @param condition optional "if present" / "if status = N"
   * @param expected  the expected json (docstring)
   */
  @Then("^check match(?: if (present|status\\b.+))?$")
  public void checkMatch(String condition, String expected) {
    if (shouldSkip(condition, null)) return;
    JsonMatcherResult result = JsonMatcher.matchJson(
        context.getApi().getResponse().asString(),
        ScenarioContext.resolve(expected));
    assertTrue(result.isSuccess(), result.getMessage());
  }

  /**
   * Check match path with optional conditional.
   *
   * @param path      the json path
   * @param expr      the expected expression
   * @param condition optional "if present" / "if status = N"
   */
  @Then("^check match path (.+?) should be (.+?)(?: if (present|status\\b.+))?$")
  public void checkMatchPath(String path, String expr, String condition) {
    if (shouldSkip(condition, path)) return;
    JsonMatcherResult result = JsonMatcher.matchJson(
        context.getApi().getResponse().asString(),
        path + " " + ScenarioContext.resolve(expr));
    assertTrue(result.isSuccess(), result.getMessage());
  }

  /**
   * Check match each element with optional conditional.
   *
   * @param arrayPath the json path to the array
   * @param condition optional "if present" / "if status = N"
   * @param expected  the expected json (docstring) each element should match
   */
  @Then("^check match each (.+?) should match(?: if (present|status\\b.+))?$")
  public void checkMatchEach(String arrayPath, String condition, String expected) {
    if (shouldSkip(condition, arrayPath)) return;
    JsonMatcherResult result = JsonMatcher.matchEach(
        context.getApi().getResponse().asString(),
        arrayPath,
        ScenarioContext.resolve(expected));
    assertTrue(result.isSuccess(), result.getMessage());
  }





}
