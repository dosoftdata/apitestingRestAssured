
/**
 * Executable DSL actions and step definitions.
 *
 * <p>Defines atomic operations (e.g., send request, assert response, mutate
 * state) that can be composed into higher-level scenarios.</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>Action interfaces and concrete implementations</li>
 *   <li>Common assertions and verifications</li>
 *   <li>Scenario orchestration helpers</li>
 * </ul>
 *
 * @since 1.0
 * @see apis.middleware.dsl.actions
 */
package apis.middleware.dsl.actions;
