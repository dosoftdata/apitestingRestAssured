package apis.middleware.dsl.actions;


import apis.middleware.core.base.CustomRequestSpec;
import apis.middleware.dsl.ScenarioContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.PathNotFoundException;
import io.cucumber.datatable.DataTable;
import io.qameta.allure.Allure;
import io.qameta.allure.model.Label;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import java.io.File;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.hamcrest.Matcher;

import static org.awaitility.Awaitility.await;
import static org.hamcrest.Matchers.*;

/**
 * The type Dsl helper.
 */
@Slf4j
public abstract class DslHelper{
  /**
   * The Context.
   */
  protected final ScenarioContext context;
  /**
   * The Spec.
   */
  protected CustomRequestSpec spec = null;

  /**
   * The Mapper.
   */
  protected final ObjectMapper mapper = new ObjectMapper();
  /**
   * The Args.
   */
  protected Map<String, Object> args;

  /**
   * Instantiates a new Dsl helper.
   *
   * @param context the context
   */
  public DslHelper(ScenarioContext context) {
    this.context = context;
  }

  /**
   * Parse data table map.
   *
   * @param dataTable the data table
   * @return the map
   */
  protected Map<String, Object> parseDataTable(DataTable dataTable) {
    args = new HashMap<>();
    if (dataTable != null && !dataTable.isEmpty()) {
      List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
      for (Map<String, String> row : rows) {
        for (Map.Entry<String, String> entry : row.entrySet()) {
          args.put(entry.getKey(), entry.getValue());
        }
      }
    }
    return args;
  }

  /**
   * Parse json map.
   *
   * @param jsonPayload the json payload
   * @return the map
   */


  /**
   * Dynamically build a Hamcrest matcher based on the keyword and expected value
   *
   * @param matcherName the matcher name
   * @param value       the value
   * @return the matcher
   */
  protected Matcher<?> buildMatcher(String matcherName, String value) {
    switch (matcherName.toLowerCase()) {

      // --- Basic equality & negation
      case "equalto":
        return equalTo(parseValue(value));
      case "notequalto":
        return not(equalTo(parseValue(value)));
      case "isequalto":
        return is(equalTo(parseValue(value)));
      case "not":
        return not(parseValue(value));

      // --- String matchers
      case "containsstring":
        return containsString(value);
      case "containsignoringcase":
        return containsStringIgnoringCase(value);
      case "startswith":
        return startsWith(value);
      case "endswith":
        return endsWith(value);
      case "equaltoignoringcase":
        return equalToIgnoringCase(value);
      case "equaltoignoringwhitespace":
        return equalToIgnoringWhiteSpace(value);
      case "matchesregex":
      case "matchespattern":
        return matchesPattern(value);

      // --- Numeric comparisons
      case "greaterthan":
        return greaterThan(value.contains(".")  ? Double.parseDouble(value) : Integer.parseInt(value));
      case "greaterthanorequalto":
        return greaterThanOrEqualTo(value.contains(".")  ? Double.parseDouble(value) : Integer.parseInt(value));
      case "lessthan":
        return lessThan(value.contains(".")  ? Double.parseDouble(value) : Integer.parseInt(value));
      case "lessthanorequalto":
        return lessThanOrEqualTo(value.contains(".")  ? Double.parseDouble(value) : Integer.parseInt(value));
      case "closeto":
        return closeTo(Double.parseDouble(value), 0.001);

      // --- Collections
      case "hasitem":
        return hasItem(parseValue(value));
      case "hasitems":
        return hasItems(splitValues(value));
      case "hassize":
        return hasSize(Integer.parseInt(value));
      case "isempty":
        return empty();
      case "everyitemcontains":
        return everyItem(containsString(value));

      // --- Maps
      case "haskey":
        return hasKey(value);
      case "hasvalue":
        return hasValue(parseValue(value));
      case "hasentry": {
        String[] parts = value.split("=", 2);
        if (parts.length < 2)
          throw new IllegalArgumentException("hasEntry expects format key=value");
        return hasEntry(parts[0].trim(), parseValue(parts[1].trim()));
      }

      // --- Null / Existence
      case "nullvalue":
        return nullValue();
      case "notnullvalue":
        return notNullValue();

      // --- Type checking
      case "instanceof": {
        try {
          return instanceOf(Class.forName(value));
        } catch (ClassNotFoundException e) {
          throw new IllegalArgumentException("Invalid class for instanceOf: " + value, e);
        }
      }

      // --- Boolean checkers
      case "istrue":
        return is(true);
      case "isfalse":
        return is(false);

      // --- Default fallback
      default:
        throw new IllegalArgumentException("Unsupported matcher: " + matcherName);
    }
  }
  /**
   * Converts raw string to appropriate type (boolean, number, or string)
   */
  private Object parseValue(String value) {
    if (value == null || value.equalsIgnoreCase("null")) return null;
    if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false"))
      return Boolean.valueOf(value);
    try {
      if (value.contains(".")) return (Object) Double.parseDouble(value);
      return (Object) Integer.parseInt(value);
    } catch (NumberFormatException e) {
      return value; // treat as string
    }
  }

  /***
   * Splits comma-separated expected values into a list
   */
  private Object[] splitValues(String csv) {
    return Arrays.stream(csv.split(","))
        .map(String::trim)
        .map(this::parseValue)
        .toArray();
  }


  @SuppressWarnings("unchecked")
  private <T extends Comparable<T>> T parseComparable(String value) {
    try {
      if (value.contains(".")) {
        return (T) Double.valueOf(value);  // Double implements Comparable<Double>
      } else {
        return (T) Integer.valueOf(value); // Integer implements Comparable<Integer>
      }
    } catch (NumberFormatException e) {
      throw new IllegalArgumentException("Expected numeric value for matcher, got: " + value);
    }
  }
  // ---------------- HELPER ----------------

  /**
   * Parse args map.
   *
   * @param table     the table
   * @param docString the doc string
   * @return the map
   * @throws Exception the exception
   */
  protected Map<String, Object> parseArgs(@Nullable DataTable table, @Nullable String docString) throws Exception {
    if (table != null && !table.isEmpty()) {
      Map<String, Object> args = new HashMap<>();
      table.asMaps().forEach(args::putAll);
      return args;
    }

    if (docString != null && !docString.trim().isEmpty()) {
      return mapper.readValue(docString, Map.class);
    }

    return Collections.emptyMap();
  }

  /**
   * Evaluate condition boolean.
   *
   * @param action      the action
   * @param actualValue the actual value
   * @param expected    the expected
   * @return the boolean
   */
  protected boolean evaluateCondition(String action, Object actualValue, Object expected) {
    switch (action.toLowerCase()) {
      case "equal":
        return Objects.equals(
            String.valueOf(actualValue),
            String.valueOf(expected)
        );
      case "exists":
        return actualValue != null;
      case "contains":
        return actualValue != null && actualValue.toString().contains(String.valueOf(expected));
      case "greater":
        if (actualValue instanceof Number && expected instanceof Number) {
          return ((Number) actualValue).doubleValue() > ((Number) expected).doubleValue();
        }
        return false;
      case "listcontains":
        return actualValue instanceof List<?> list && list.contains(expected);

      case "any":
        return true;

      default:
        throw new IllegalArgumentException("Unknown action: " + action);
    }
  }

  /**
   * Await until.
   *
   * @param method        the method
   * @param path          the path
   * @param conditionJson the condition json
   */
  protected void awaitUntil(String method, String path,  String conditionJson)  {
    // Resolve path
    if (path != null) {
      path = ScenarioContext.resolve(path);
    }
    conditionJson = (conditionJson == null || conditionJson.trim().isEmpty()) ? "{}" : ScenarioContext.resolve(conditionJson);
    JsonPath json = new JsonPath(conditionJson);
    Object expected = json.get("hasValue"); // can be String, Number, Boolean, null
    String bodyPath = json.getString("bodyPath");
    String action   = json.getString("action") != null ? json.getString("action") : "equal";

    Integer minutes        = json.get("minutes")       != null ? json.getInt("minutes") : 5;
    Integer seconds        = json.get("seconds")       != null ? json.getInt("seconds") : 30;
    Integer pollMillis     = json.get("pollMillis")    != null ? json.getInt("pollMillis") : 5000;
    Integer expectedStatus = json.get("status")        != null ? json.getInt("status") : 200;

    CustomRequestSpec originalSpec = context.getSpec();

    AtomicReference<Response> lastResp = new AtomicReference<>();
    AtomicInteger attempts = new AtomicInteger(0);

    String finalPath = path;

    if (finalPath != null) {
      originalSpec.setBasePath(ScenarioContext.resolve(finalPath));
    }
    await()
        .atMost(Duration.ofMinutes(minutes).plusSeconds(seconds))
        .pollInterval(Duration.ofMillis(pollMillis))
        .ignoreExceptions()
        .until(() -> {

          Response resp = context.getRes()
              .spec(originalSpec.build())
              .when().request(method);

          lastResp.set(resp);
          attempts.incrementAndGet();

          boolean statusOk = resp.statusCode() == expectedStatus ||
                             resp.statusCode() == 500;

          Object value = null;
          if (bodyPath != null) {
            try { value = resp.path(bodyPath); } catch (Exception ignored) {}
          }

          boolean bodyOk = (bodyPath == null) ||
                  evaluateCondition(action, value, expected);

          log.info("[Retry] {} {} | status={} | attemps = {} | {}={} | passed={}",
              method, finalPath, resp.statusCode(),attempts.get(), bodyPath, value, statusOk && bodyOk);
          return statusOk && bodyOk;
        });

    this.context.getApi().setResponse(lastResp.get());
  }



  protected static Map<String, Object> extractHostAndParams(final String url) {
    // URI.create is thread-safe; we keep everything local
    final URI uri = URI.create(url);

    final String host = uri.getHost(); // may be null for some schemes; caller should handle if needed

    // Use raw query to avoid double-decoding; decode key/value separately
    final String rawQuery = uri.getRawQuery(); // e.g. "sid=cko_lQ6juhkYDhAp3AwuKILPsYU3"
    final Map<String, String> params = new LinkedHashMap<>();

    if (rawQuery != null && !rawQuery.isEmpty()) {
      for (String pair : rawQuery.split("&")) {
        if (pair.isEmpty()) continue;
        String[] kv = pair.split("=", 2);
        // Decode each part safely
        String key = URLDecoder.decode(kv[0], StandardCharsets.UTF_8);
        String value = kv.length > 1 ? URLDecoder.decode(kv[1], StandardCharsets.UTF_8) : "";
        params.put(key, value);
      }
    }

    // Publish immutable views to ensure thread-safety via safe publication
    Map<String, String> immutableParams = Collections.unmodifiableMap(params);

    // Result map is also immutable; callers cannot alter internal state
    return Map.of(
        "host", host,
        "params", immutableParams
    );
  }

  static void epicCounter() {
    ScenarioContext.sc.get().getSourceTagNames().stream()
        .filter(tag -> tag.startsWith("@epic:"))
        .findFirst()
        .ifPresent(tag -> {
          String epicName = tag.replace("@epic:", "");
          Allure.getLifecycle().updateTestCase(testResult -> {
            testResult.getLabels().add(new Label().setName("epic").setValue(epicName));
          });
        });
  }
  protected static File resolveFile(String path) {
    String lookup = path.startsWith("classpath:") ? path.substring("classpath:".length()) : path;
    File asFile = new File(lookup);
    if (asFile.isAbsolute() && asFile.exists()) {
      return asFile;
    }
    java.net.URL url = Thread.currentThread().getContextClassLoader().getResource(lookup);
    if (url != null) {
      return new File(url.getFile());
    }
    if (asFile.exists()) {
      return asFile;
    }
    throw new IllegalArgumentException("File not found on classpath or filesystem: " + path);
  }

  /**
   * Evaluate the optional "if <condition>" suffix on a match step.
   * Returns true when the step should be skipped.
   *
   * Supported conditions:
   *   - "present"           → skip if response body is empty, or if pathOrValue is missing/empty
   *   - "status = <code>"   → run only when actual status equals <code> (also !=, >, <, >=, <=)
   *   - "status <code>"     → same as "status = <code>"
   */
  protected boolean shouldSkip(String condition, String pathOrValue) {
    if (condition == null || condition.trim().isEmpty()) return false;
    String c = condition.trim();

    if (c.toLowerCase().startsWith("status")) {
      int actual;
      try { actual = context.getApi().getResponse().statusCode(); }
      catch (Exception e) {
        log.warn("Could not read response status for condition '{}' — running step", c);
        return false;
      }
      boolean met = matchesStatusCondition(c, actual);
      if (!met) log.info("Skipping step: condition '{}' not met (actual status={})", c, actual);
      return !met;
    }

    if (c.equalsIgnoreCase("present")) {
      boolean present = isPresent(pathOrValue);
      if (!present) log.info("Skipping step: condition 'present' not met (path/value='{}')", pathOrValue);
      return !present;
    }

    log.warn("Unknown 'if' condition '{}' — running step anyway", c);
    return false;
  }

  protected boolean isPresent(String pathOrValue) {
    String body = context.getApi().getResponse().asString();
    if (body == null || body.trim().isEmpty()) return false;
    if (pathOrValue == null || pathOrValue.trim().isEmpty()) return true;

    if (pathOrValue.startsWith("$")) {
      try {
        Object v = com.jayway.jsonpath.JsonPath.read(body, pathOrValue);
        if (v == null) return false;
        if (v instanceof List && ((List<?>) v).isEmpty()) return false;
        if (v instanceof Map && ((Map<?, ?>) v).isEmpty()) return false;
        if (v instanceof String && ((String) v).trim().isEmpty()) return false;
        return true;
      } catch (PathNotFoundException pnfe) {
        return false;
      } catch (Exception e) {
        return false;
      }
    }

    return pathOrValue.trim().length() > 0;
  }

  protected boolean matchesStatusCondition(String cond, int actual) {
    String rest = cond.toLowerCase().substring("status".length()).trim();
    String op;
    String numStr;
    if (rest.startsWith("!=")) { op = "!="; numStr = rest.substring(2).trim(); }
    else if (rest.startsWith(">=")) { op = ">="; numStr = rest.substring(2).trim(); }
    else if (rest.startsWith("<=")) { op = "<="; numStr = rest.substring(2).trim(); }
    else if (rest.startsWith("=")) { op = "="; numStr = rest.substring(1).trim(); }
    else if (rest.startsWith(">")) { op = ">"; numStr = rest.substring(1).trim(); }
    else if (rest.startsWith("<")) { op = "<"; numStr = rest.substring(1).trim(); }
    else { op = "="; numStr = rest; }

    int expected;
    try { expected = Integer.parseInt(numStr); }
    catch (NumberFormatException e) {
      log.warn("Invalid status condition '{}' — running step", cond);
      return true;
    }

    switch (op) {
      case "=":  return actual == expected;
      case "!=": return actual != expected;
      case ">":  return actual > expected;
      case "<":  return actual < expected;
      case ">=": return actual >= expected;
      case "<=": return actual <= expected;
      default:   return true;
    }
  }
  protected static boolean toBoolean(String b) {
    return "true".equalsIgnoreCase(b) || "1".equals(b);
  }
}
