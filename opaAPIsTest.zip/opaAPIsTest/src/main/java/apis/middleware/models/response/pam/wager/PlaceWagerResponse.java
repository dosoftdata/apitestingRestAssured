package apis.middleware.models.response.pam.wager;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PlaceWagerResponse {
    private Long wagerId;
    private List<String> serialNumbers;
    private Integer crcCode;
    private String hexCrcCode;
    private String transactionId;
    private String guid;
    private String terminalId;
    private String retailerId;
    private Integer operator;
    private Integer channelId;
    private String gameType;
    private Wager wager;
    private List<Object> promotionOutcomes;
    private Boolean kinoSystemEnabled;

    @Data
    @NoArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Wager {
        private List<Board> boards;
        private Integer columns;
        private Double cost;
        private ParticipatingDraws participatingDraws;
        private String status;
        private String blockStatus;
        private Double discount;
    }

    @Data
    @NoArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Board {
        private Integer betType;
        private Integer boardId;
        private Integer multipliers;
        private List<Panel> panels;
    }

    @Data
    @NoArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Panel {
        private List<Integer> selection;
        private Boolean quickPick;
    }

    @Data
    @NoArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class ParticipatingDraws {
        private List<Integer> draws;
        private Integer firstDraw;
        private String firstDrawTime;
        private Integer lastDraw;
        private String lastDrawTime;
        private Integer multipleDraws;
    }
}
