package apis.middleware.models.request.pam.limit;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LimitQuantity {
  private Long durationInSeconds;
  private Double amount;
  private String currency;
}
