package apis.middleware.models.request.pam.verification;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class EmailVerificationRequest {
  private String playerId;
  private String hash;
}
