package apis.middleware.models.request.pam.wallet;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WalletPaymentRequest {
  private String action;
  private String operation;
  private String channel;
  private String paymentType;
  private WalletPaymentMethod paymentMethod;
  private String paymentId;
  private String pspPaymentId;
  private MoneyAmount amount;
  private MoneyAmount serviceCost;
  private WalletPaymentOwner owner;
  private Object issuer;
  private String pspId;
  private String pspTargetId;
  private Object extraParams;
  private boolean forceReview;
  private String paybankId;
}
