package apis.middleware.models.request.pam.deposit;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class DepositRequest {
  private String amount;
  private String currency;
  private String paymentMethodType;
  private String paymentType;
}
