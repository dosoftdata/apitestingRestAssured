package apis.middleware.models.request.pam.otp;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class OtpRequest {
  private String phoneNumber;
}
