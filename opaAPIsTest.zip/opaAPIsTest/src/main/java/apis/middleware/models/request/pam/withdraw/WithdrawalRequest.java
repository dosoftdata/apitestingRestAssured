package apis.middleware.models.request.pam.withdraw;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WithdrawalRequest {
    private String action;
    private String operation;
    private String channel;
    private String paymentType;
    private WithdrawalPaymentMethod paymentMethod;
    private String paymentId;
    private String pspPaymentId;
    private MoneyAmount amount;
    private MoneyAmount serviceCost;
    private Owner owner;
    private Object issuer;
    private String pspId;
    private String pspTargetId;
    private Object extraParams;
    private boolean forceReview;
    private String paybankId;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BankAccount {
        private String bankId;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class MoneyAmount {
        private String amount;
        private String currency;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Owner {
        private String id;
        private String type;
    }
}
