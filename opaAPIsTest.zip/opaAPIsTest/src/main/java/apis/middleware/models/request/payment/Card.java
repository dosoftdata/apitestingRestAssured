package apis.middleware.models.request.payment;


import lombok.*;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class Card {
  private String number;
  private int expMonth;
  private int expYear;
  private String holderName;
  private String cvv;
}

