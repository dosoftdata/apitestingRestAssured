package apis.middleware.models.request.pam.otp;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class OtpVerifyRequest {
  private String phoneNumber;
  private String uuid;
  private String verificationCode;
}
