package apis.middleware.models.request.pam.login;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class OidcLoginRequest {
  @JsonProperty("grant_type")
  private String grantType;
  private String username;
  private String password;
  private String channel;
  private String group;
  private String scope;
}
