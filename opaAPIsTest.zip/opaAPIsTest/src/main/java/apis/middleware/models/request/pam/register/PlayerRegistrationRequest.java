package apis.middleware.models.request.pam.register;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PlayerRegistrationRequest {
  private String username;
  private String password;
  private String email;
  private String identityType;
  private String identityNumber;
  private String firstName;
  private String middleName;
  private String lastName;
  private String gender;
  private String dateOfBirth;
  private String country;
  private String city;
  private String address1;
  private String zip;
  private String profession;
  private String phone;
  private String mobilePhone;
  private String bonusCode;
  private String secretQuestion;
  private String secretAnswer;
  private String ibanNumber;
  private String otpUuid;
  private String permanentResidenceCountry;
}
