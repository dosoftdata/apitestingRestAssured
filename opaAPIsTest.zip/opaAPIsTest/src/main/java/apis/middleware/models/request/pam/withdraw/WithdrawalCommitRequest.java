package apis.middleware.models.request.pam.withdraw;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WithdrawalCommitRequest {
    private WithdrawalRequest.MoneyAmount serviceCost;
    private boolean forceReview;
    private Object auditData;
}
