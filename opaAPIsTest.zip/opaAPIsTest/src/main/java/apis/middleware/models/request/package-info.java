/**
 * Request/command models used by the middleware and DSL.
 *
 * <p>Immutable request DTOs and builders for composing API interactions in tests
 * and integration flows.</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>DTOs representing API inputs</li>
 *   <li>Builders and factory helpers</li>
 *   <li>Validation and normalization utilities</li>
 * </ul>
 *
 * @since 1.0
 * @see apis.middleware.dsl
 */

package apis.middleware.models.request;