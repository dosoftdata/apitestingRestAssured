package apis.middleware.models.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * The type Add a stub.
 */
@Data
public class AddAStub {
  private String scenarioName;
  private String requiredScenarioState;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private int priority;

  private Request request;
  private Response response;

  /**
   * The type Request.
   */
  @Data
  public static class Request {

    /**
     * The Method.
     */
    public String method;
    /**
     * The Url.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String url;

    /**
     * The Url pattern.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String urlPattern;
  }

  /**
   * The type Headers.
   */
  @Data
  public static class headers {
    @JsonProperty("Content-Type")
    private String contentType;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String GUID;
  }

  /**
   * The type Response.
   */
  @Data
  public static class Response {
    private int status;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String body;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private headers headers;
  }
}
