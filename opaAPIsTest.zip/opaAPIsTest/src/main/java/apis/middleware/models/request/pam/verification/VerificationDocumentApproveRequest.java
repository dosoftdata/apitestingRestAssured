package apis.middleware.models.request.pam.verification;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class VerificationDocumentApproveRequest {
  private Object verificationId;
  private String verificationType;
  private Object documentId;
  private String statusDescription;
}
