package apis.middleware.models.request.pam.limit;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class LimitScope {
  private String gameId;
}
