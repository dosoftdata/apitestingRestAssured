package apis.middleware.models.request.pam.limit;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class LimitRequest {
  private String limitType;
  private String quantityType;
  private LimitQuantity quantity;
  private String period;
  private LimitScope scope;
}
