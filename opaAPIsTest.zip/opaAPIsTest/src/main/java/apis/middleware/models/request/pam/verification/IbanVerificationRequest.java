package apis.middleware.models.request.pam.verification;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class IbanVerificationRequest {
  private String iban;
  private String id;
}
