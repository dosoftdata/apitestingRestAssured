package apis.middleware.models.request.pam.wager;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PlaceWagerRequest {
    private String gameType;
    private ExclusiveWager wager;
    private String promotionInfo;

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ExclusiveWager {
        private List<Board> boards;
        private ParticipatingDraws participatingDraws;
    }

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class Board {
        private Integer boardId;
        private Integer betType;
        private List<Panel> panels;
        private Integer multipliers;
    }

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class Panel {
        private List<Integer> selection;
        private Boolean quickPick;
    }

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ParticipatingDraws {
        private Integer multipleDraws;
    }
}
