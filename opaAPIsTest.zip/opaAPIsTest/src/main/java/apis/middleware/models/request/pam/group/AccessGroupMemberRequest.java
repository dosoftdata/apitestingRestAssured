package apis.middleware.models.request.pam.group;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class AccessGroupMemberRequest {
  private String memberId;
  private String retailerId;
  private String updatedByUserId;
}
