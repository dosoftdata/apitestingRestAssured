package apis.middleware.models.request.pam.wallet;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class MoneyAmount {
  private Double amount;
  private String currency;
}
