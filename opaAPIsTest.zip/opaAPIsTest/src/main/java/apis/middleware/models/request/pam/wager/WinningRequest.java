package apis.middleware.models.request.pam.wager;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class WinningRequest {
    private String amount;
    private String currency;
    private String description;
    private String issued;
    private String partialPayment;
    private String productId;
    private String referenceId;
    private String serialNumber;
    private String taxAmount;
}
