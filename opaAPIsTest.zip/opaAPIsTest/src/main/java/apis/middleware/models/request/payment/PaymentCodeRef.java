package apis.middleware.models.request.payment;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PaymentCodeRef {
  private String paymentCode;
}
