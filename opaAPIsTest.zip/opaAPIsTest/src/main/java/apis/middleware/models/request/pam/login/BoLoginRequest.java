package apis.middleware.models.request.pam.login;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class BoLoginRequest {
  private String loginName;
  private String password;
}
