package apis.middleware.models.request.pam.withdraw;

import apis.middleware.models.request.pam.withdraw.WithdrawalRequest.BankAccount;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WithdrawalPaymentMethod {
    private String type;
    private String id;

    @JsonInclude(JsonInclude.Include.ALWAYS)
    @JsonProperty("card")
    private Object card;

    private BankAccount bankAccount;

    @JsonInclude(JsonInclude.Include.ALWAYS)
    @JsonProperty("voucher")
    private Object voucher;
}
