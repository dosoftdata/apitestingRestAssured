package apis.middleware.models.request.pam.bonus;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BonusRequest {
    private String rewardType;
    private String bonusTerms;
    private String bonusValidFrom;
    private String bonusValidTo;
    private String rollOver;
    private String maxWinningsCap;
    private String minimumBets;
    private List<AllowedGame> allowedGames;
    private String program;
    private Boolean singleUse;
    private String bonusAssignment;
    private String rewardExpiryDays;
    private String activationTrigger;
    private String rewardAmountType;
    private String rewardAmount;
    private List<LangDetail> langDetails;
    private Integer status;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class AllowedGame {
        private String gameType;
        private List<String> gameIds;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class LangDetail {
        private String name;
        private String description;
        private String code;
    }
}
