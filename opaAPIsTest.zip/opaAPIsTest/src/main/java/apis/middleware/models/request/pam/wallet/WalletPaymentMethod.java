package apis.middleware.models.request.pam.wallet;

import apis.middleware.models.request.payment.PaymentCodeRef;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WalletPaymentMethod {
  private String type;
  private String id;
  private Object card;
  private PaymentCodeRef paymentCode;
  private Object voucher;
}
