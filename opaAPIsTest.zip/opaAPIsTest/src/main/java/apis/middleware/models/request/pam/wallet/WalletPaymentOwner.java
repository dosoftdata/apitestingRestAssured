package apis.middleware.models.request.pam.wallet;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class WalletPaymentOwner {
  private String id;
  private int type;
}
