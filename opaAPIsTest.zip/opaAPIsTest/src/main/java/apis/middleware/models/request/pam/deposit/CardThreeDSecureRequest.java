package apis.middleware.models.request.pam.deposit;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.ALWAYS)
public class CardThreeDSecureRequest {
  private Card card;
  @JsonProperty("merchant_reference")
  private String merchantReference;
  private String signature;
  private String amount;
  private String pk;
  private String currency;

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  public static class Card {
    private String number;
    @JsonProperty("holder_name")
    private String holderName;
    private String cvv;
    @JsonProperty("exp_month")
    private String expMonth;
    @JsonProperty("exp_year")
    private String expYear;
  }
}
