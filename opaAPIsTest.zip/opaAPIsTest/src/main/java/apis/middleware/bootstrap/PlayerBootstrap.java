package apis.middleware.bootstrap;

import apis.middleware.core.base.ApiBase;
import apis.middleware.core.base.CustomRequestSpec;
import apis.middleware.dsl.ScenarioContext;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import lombok.Builder;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.equalTo;

/**
 * One-time player registration + email verification.
 * Mirrors the flow in src/test/resources/features/PAM/1.Create and Email Verify Player.feature
 * but executes once per JVM and publishes results to ScenarioContext.GLOBAL.
 *
 * Uses the project's standard ApiBase.spec() / CustomRequestSpec pattern so that all
 * bootstrap traffic flows through the same Allure filter as scenario calls.
 */
@Slf4j
public final class PlayerBootstrap {

  private static final AtomicBoolean STARTED = new AtomicBoolean(false);
  private static final Pattern HASH_PATTERN = Pattern.compile("&hash=([^&\"\\s<]+)");

  private PlayerBootstrap() { /* no instances */ }

  /** Idempotent: first caller runs the flow; subsequent callers no-op. */
  public static void registerOnce() {
    if (!STARTED.compareAndSet(false, true)) return;

    String webBase = str("pam.webBaseUrl");
    String boBase  = str("pam.boBaseUrl");
    String msisdn  = str("pam.$random8Digit");
    String boUser  = str("bo_username");
    String boPass  = str("bo_password");

    log.info("[PlayerBootstrap] starting one-time registration (msisdn=69{}, webBase={}, boBase={})",
        msisdn, webBase, boBase);

    OtpRequest otpReq = OtpRequest.builder().phoneNumber("69" + msisdn).build();
    CustomRequestSpec spec;
    Response resp;

    // Step 1: OTP create — first attempt, expect 403 + Set-Cookie csrftoken
    spec = ApiBase.spec();
    spec.setBaseUri(webBase);
    spec.setBasePath("/web/customer/rest/v1/otp");
    spec.setHeader("Content-Type", "application/json");
    spec.setBody(otpReq);
    resp = spec.when().post();
    resp.then().statusCode(403);
    String webCsrf = resp.getCookie("csrftoken");

    // Step 2: OTP create — retry with csrftoken
    spec = ApiBase.spec();
    spec.setBaseUri(webBase);
    spec.setBasePath("/web/customer/rest/v1/otp");
    spec.setHeader("Content-Type", "application/json");
    spec.setHeader("x-csrftoken", webCsrf);
    spec.setCookie("csrftoken", webCsrf);
    spec.setBody(otpReq);
    resp = spec.when().post();
    resp.then().statusCode(200);
    String otpUuid = resp.then().extract().body().jsonPath().getString("uuid");

    // Step 3: OTP verify
    OtpVerifyRequest otpVerifyReq = OtpVerifyRequest.builder()
        .phoneNumber("69" + msisdn)
        .uuid(otpUuid)
        .verificationCode("000000")
        .build();
    spec = ApiBase.spec();
    spec.setBaseUri(webBase);
    spec.setBasePath("/web/customer/rest/v1/otp");
    spec.setHeader("Content-Type", "application/json");
    spec.setHeader("x-csrftoken", webCsrf);
    spec.setCookie("csrftoken", webCsrf);
    spec.setBody(otpVerifyReq);
    resp = spec.when().put();
    resp.then().statusCode(204);

    // Step 4: Register player
    spec = ApiBase.spec();
    spec.setBaseUri(webBase);
    spec.setBasePath("/web/customer/rest/v1-opap/players");
    spec.setHeader("Content-Type", "application/json");
    spec.setHeader("x-csrftoken", webCsrf);
    spec.setHeader("X-GAME-ID", "JOKER");
    spec.setCookie("csrftoken", webCsrf);
    spec.setBody(buildRegisterRequest(msisdn, otpUuid));
    resp = spec.when().post();
    resp.then().statusCode(200);
    JsonPath registerJson = resp.then().extract().body().jsonPath();
    Object playerId = registerJson.get("id");
    String username = registerJson.getString("username");

    BoLoginRequest boReq = BoLoginRequest.builder()
        .loginName(boUser)
        .password(boPass)
        .build();

    // Step 5: BO login — first attempt, expect 403 + csrftoken cookie
    spec = ApiBase.spec();
    spec.setBaseUri(boBase);
    spec.setBasePath("/cc/access/rest/v1/sessions");
    spec.setHeader("Content-Type", "application/json");
    spec.setBody(boReq);
    resp = spec.when().post();
    resp.then().statusCode(403);
    String boCsrf = resp.getCookie("csrftoken");

    // Step 6: BO login retry with csrftoken
    spec = ApiBase.spec();
    spec.setBaseUri(boBase);
    spec.setBasePath("/cc/access/rest/v1/sessions");
    spec.setHeader("Content-Type", "application/json");
    spec.setHeader("x-csrftoken", boCsrf);
    spec.setCookie("csrftoken", boCsrf);
    spec.setBody(boReq);
    resp = spec.when().post();
    resp.then().statusCode(anyOf(equalTo(200), equalTo(204)));

    // Step 7: Wait for the registration email (matches feature: delay request 60000)
    sleep(60_000);

    // Step 8: Fetch email list for the new player → mailHash
    spec = ApiBase.spec();
    spec.setBaseUri(boBase);
    spec.setBasePath("/cc/communication/rest/v1/emails");
    spec.setHeader("x-csrftoken", boCsrf);
    spec.setCookie("csrftoken", boCsrf);
    spec.setQueryParam("playerId", playerId);
    resp = spec.when().get();
    resp.then().statusCode(200);
    Object mailHash = resp.then().extract().body().jsonPath().get("data[0].id");

    // Step 9: Fetch email body → extract hash via "&hash=" pattern
    spec = ApiBase.spec();
    spec.setBaseUri(boBase);
    spec.setBasePath("/cc/communication/rest/v1/emails/{hash_for_mail}");
    spec.setHeader("x-csrftoken", boCsrf);
    spec.setCookie("csrftoken", boCsrf);
    spec.setPathParam("hash_for_mail", mailHash);
    resp = spec.when().get();
    resp.then().statusCode(anyOf(equalTo(200), equalTo(204)));
    // Extract the "body" field via JsonPath so JSON escapes (e.g. \") are decoded
    // before the regex runs, otherwise the trailing \ leaks into the captured hash.
    String emailBody = resp.then().extract().body().jsonPath().getString("body");

    Matcher m = HASH_PATTERN.matcher(emailBody);
    if (!m.find()) {
      throw new IllegalStateException("[PlayerBootstrap] '&hash=' not found in registration email body");
    }
    String hashId = m.group(1);

    // Step 10: Verify email on the web side
    EmailVerifyRequest emailVerifyReq = EmailVerifyRequest.builder()
        .playerId(String.valueOf(playerId))
        .hash(hashId)
        .build();
    spec = ApiBase.spec();
    spec.setBaseUri(webBase);
    spec.setBasePath("/web/customer/rest/v1/verifications/email");
    spec.setHeader("Content-Type", "application/json");
    spec.setHeader("x-csrftoken", webCsrf);
    spec.setCookie("csrftoken", webCsrf);
    spec.setBody(emailVerifyReq);
    resp = spec.when().post();
    resp.then().statusCode(anyOf(equalTo(200), equalTo(204)));

    // Publish to global context — features can read via {{key}} after Hooks mirrors them.
    // playerId and mailHash come from JsonPath as Object; coerce to String so the
    // GLOBAL store only ever holds immutable scalars (any future JSON shape change
    // returning a Map/List would leak shared mutable state across workers).
    ScenarioContext.putIfAbsentGlobal("randomMSISDN",    msisdn);
    ScenarioContext.putIfAbsentGlobal("web-x-csrftoken", webCsrf);
    ScenarioContext.putIfAbsentGlobal("otpUuid",         otpUuid);
    ScenarioContext.putIfAbsentGlobal("playerId",        String.valueOf(playerId));
    ScenarioContext.putIfAbsentGlobal("username",        username);
    ScenarioContext.putIfAbsentGlobal("x-csrftoken",     boCsrf);
    ScenarioContext.putIfAbsentGlobal("mailHash",        String.valueOf(mailHash));
    ScenarioContext.putIfAbsentGlobal("hashId",          hashId);

    log.info("[PlayerBootstrap] done — playerId={}, username={}", playerId, username);
  }

  private static String str(String key) {
    Object v = ScenarioContext.get(key);
    return v == null ? null : String.valueOf(v);
  }

  private static void sleep(long ms) {
    try {
      Thread.sleep(ms);
    } catch (InterruptedException ie) {
      Thread.currentThread().interrupt();
      throw new RuntimeException("[PlayerBootstrap] interrupted while waiting for email", ie);
    }
  }

  private static RegisterPlayerRequest buildRegisterRequest(String msisdn, String otpUuid) {
    return RegisterPlayerRequest.builder()
        .username("swatteam" + msisdn)
        .password("Qwerty12345!")
        .email("swatteam" + msisdn + "@mailsac.com")
        .identityType("OTHER")
        .identityNumber(msisdn)
        .firstName("PAM")
        .middleName("LOTTERY")
        .lastName("PLATFORM")
        .gender("M")
        .dateOfBirth("1950-09-29")
        .country("GR")
        .city("Athens")
        .address1("First address 0100")
        .zip("15125")
        .profession("Unemployed")
        .phone("21" + msisdn)
        .mobilePhone("69" + msisdn)
        .bonusCode("THIS_IS_A_BONUS_CODE")
        .secretQuestion("What is your name?")
        .secretAnswer("automationsuite")
        .ibanNumber("GR2202655559367039137283047")
        .otpUuid(otpUuid)
        .permanentResidenceCountry("GRC")
        .build();
  }

  // ===== Request DTOs (private to bootstrap; lift to apis.middleware.models.request.pam if reused) =====

  @Getter
  @Builder
  private static class OtpRequest {
    private final String phoneNumber;
  }

  @Getter
  @Builder
  private static class OtpVerifyRequest {
    private final String phoneNumber;
    private final String uuid;
    private final String verificationCode;
  }

  @Getter
  @Builder
  private static class BoLoginRequest {
    private final String loginName;
    private final String password;
  }

  @Getter
  @Builder
  private static class EmailVerifyRequest {
    private final String playerId;
    private final String hash;
  }

  @Getter
  @Builder
  private static class RegisterPlayerRequest {
    private final String username;
    private final String password;
    private final String email;
    private final String identityType;
    private final String identityNumber;
    private final String firstName;
    private final String middleName;
    private final String lastName;
    private final String gender;
    private final String dateOfBirth;
    private final String country;
    private final String city;
    private final String address1;
    private final String zip;
    private final String profession;
    private final String phone;
    private final String mobilePhone;
    private final String bonusCode;
    private final String secretQuestion;
    private final String secretAnswer;
    private final String ibanNumber;
    private final String otpUuid;
    private final String permanentResidenceCountry;
  }
}
