package apis.middleware.testData;

import java.io.*;
import java.net.URL;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;

/**
 * Fully automatic test data preprocessor.
 * - Walks all feature files recursively under src/test/resources/features
 * - Detects @DataSource tags (@DataSource:csv, @DataSource:excel, @DataSource:db)
 * - Loads data for all features/scenarios from unified repository
 * - Rewrites each feature file with updated Example tables
 */
@Slf4j
public class DynamicDataPreProcessor {

  private final TestDataRepository dataRepo = TestDataRepository.getInstance();

  // Guards against concurrent re-entry: feature files are rewritten in place,
  // so two workers running this simultaneously would corrupt them.
  private static final AtomicBoolean RAN = new AtomicBoolean(false);

  /**
   * Entry point — run this before executing Cucumber. JVM-idempotent.
   */

  public void run() {
    if (!RAN.compareAndSet(false, true)) {
      log.info("[PreProcessor] already ran in this JVM — skipping.");
      return;
    }

    String featureDirPath = System.getProperty("cucumber.features", "");

    if (featureDirPath != null && featureDirPath.startsWith("classpath:")) {
      String resourcePath = featureDirPath.substring("classpath:".length());
      URL resource = Thread.currentThread().getContextClassLoader().getResource(resourcePath);
      if (resource == null) {
        log.error("Could not find resource: " + resourcePath);
      }
      assert resource != null;
      featureDirPath = resource.getPath();
    }

    assert featureDirPath != null;
    File featureDir = new File(featureDirPath);
    List<File> features = findFeatureFiles(featureDir);

    // Load all test data once (supports CSV, Excel, DB — implementation in TestDataRepository)
    Map<String, List<Map<String, String>>> allData = dataRepo.loadData("csv");

    for (File f : features) {
      try {
        String source = Files.readString(f.toPath());
        String featureName = extractFeatureName(source);
        String tag = extractDataSourceTag(source);
        if (tag == null) continue; // skip if no @DataSource tag
        System.out.println("[PreProcessor] Updating feature: " + featureName);
        updateFeatureFile(f, featureName, allData);
      } catch (Exception e) {
        log.error("[PreProcessor] Failed updating {} : {}" , f.getName(),e.getMessage() );
      }
    }
  }

  /**
   * Recursively find all .feature files under a directory
   */
  private List<File> findFeatureFiles(File dir) {
    List<File> list = new ArrayList<>();
    if (dir.exists()) {
      for (File f : Objects.requireNonNull(dir.listFiles())) {
        if (f.isDirectory()) list.addAll(findFeatureFiles(f));
        else if (f.getName().endsWith(".feature")) list.add(f);
      }
    }
    return list;
  }

  /**
   * Extract the "Feature:" line
   */
  private String extractFeatureName(String source) {
    for (String line : source.split("\\R")) {
      if (line.trim().startsWith("Feature:")) {
        return line.replace("Feature:", "").trim();
      }
    }
    return "Unnamed Feature";
  }

  /**
   * Detect @DataSource:csv, @DataSource:excel, or @DataSource:db
   */
  private String extractDataSourceTag(String source) {
    for (String line : source.split("\\R")) {
      if (line.trim().startsWith("@DataSource:")) {
        return line.trim();
      }
    }
    return null;
  }

  /**
   * Update Examples sections of all Scenario Outlines in the feature
   */
  private void updateFeatureFile(File file, String featureName, Map<String, List<Map<String, String>>> allData) throws IOException {
    String content = Files.readString(file.toPath());
    // Preserve the file's existing line-ending style so we never rewrite the
    // whole file's EOLs (and never split a CRLF) — we only touch the tables.
    String eol = content.contains("\r\n") ? "\r\n" : "\n";
    List<String> scenarios = extractScenarioOutlines(content);

    for (String scenario : scenarios) {
      List<Map<String, String>> rows = allData.getOrDefault(featureName + "::" + scenario, new ArrayList<>());
      if (!rows.isEmpty()) {
        content = replaceExamples(content, scenario, rows, eol);
      }
    }

    Files.writeString(file.toPath(), content);
  }

  /**
   * Find all Scenario Outline titles
   */
  private List<String> extractScenarioOutlines(String source) {
    List<String> list = new ArrayList<>();
    for (String line : source.split("\\R")) {
      if (line.trim().startsWith("Scenario Outline:")) {
        list.add(line.replace("Scenario Outline:", "").trim());
      }
    }
    return list;
  }

  /**
   * Replace the data rows of a Scenario Outline's Examples table — and nothing
   * else. The scenario's steps, the "Examples:" keyword line, the blank lines
   * around it, and the file's line endings are all preserved verbatim; only the
   * "| ... |" rows are swapped. This keeps the rewrite surgical and idempotent
   * (no whole-file reformatting, no CRLF/LF churn).
   */
  private String replaceExamples(String content, String scenario, List<Map<String, String>> rows, String eol) {
    // group 1: scenario steps up to and including the "Examples:" line (+ its EOL)
    // group 2: the existing table rows (zero or more "| ... |" lines)
    Pattern pattern = Pattern.compile(
        "(?s)(Scenario Outline:[ \\t]*" + Pattern.quote(scenario)
            + ".*?\\R[ \\t]*Examples:[ \\t]*\\R)"
            + "((?:[ \\t]*\\|[^\\r\\n]*\\R?)*)");

    Matcher matcher = pattern.matcher(content);
    StringBuffer sb = new StringBuffer();

    while (matcher.find()) {
      String head = matcher.group(1);

      // Placeholders actually used in this scenario's steps
      Set<String> usedPlaceholders = extractUsedPlaceholders(head);

      // Filter test data columns to match placeholders, then build the new rows
      List<Map<String, String>> filteredRows = filterColumns(rows, usedPlaceholders);
      String examples = buildExamplesTable(filteredRows, usedPlaceholders, eol);

      // Re-emit the head untouched, replacing only the old rows with the new ones
      matcher.appendReplacement(sb, Matcher.quoteReplacement(head + examples));
    }

    matcher.appendTail(sb);
    return sb.toString();
  }

  /**
   * Extract all <placeholders> used in a Scenario Outline
   */
  private Set<String> extractUsedPlaceholders(String scenarioBlock) {
    Set<String> placeholders = new LinkedHashSet<>();
    Matcher m = Pattern.compile("<(.*?)>").matcher(scenarioBlock);
    while (m.find()) {
      placeholders.add(m.group(1).trim());
    }
    return placeholders;
  }

  /**
   * Keep only the data columns used in this scenario
   */
  private List<Map<String, String>> filterColumns(List<Map<String, String>> rows, Set<String> usedCols) {
    List<Map<String, String>> filtered = new ArrayList<>();
    for (Map<String, String> row : rows) {
      Map<String, String> newRow = new LinkedHashMap<>();
      for (String key : usedCols) {
        if (row.containsKey(key)) {
          newRow.put(key, row.get(key));
        }
      }
      filtered.add(newRow);
    }
    return filtered;
  }

  /**
   * Build the Examples table dynamically
   */
  private String buildExamplesTable(List<Map<String, String>> rows, Set<String> usedCols, String eol) {
    if (rows.isEmpty() || usedCols.isEmpty()) return "";

    StringBuilder sb = new StringBuilder();
    sb.append("      | ").append(String.join(" | ", usedCols)).append(" |").append(eol);

    for (Map<String, String> row : rows) {
      sb.append("      | ");
      sb.append(String.join(" | ", usedCols.stream()
          .map(h -> Optional.ofNullable(row.get(h)).orElse("").trim())
          .toList()));
      sb.append(" |").append(eol);
    }

    return sb.toString();
  }
}
