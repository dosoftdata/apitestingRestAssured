package apis.middleware.core.filters;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;
import lombok.extern.slf4j.Slf4j;


/**
 * The type Log 4 j rest assured filter.
 */
@Slf4j
public class Log4jRestAssuredFilter implements Filter {

 
  @Override
  public Response filter(FilterableRequestSpecification requestSpec,
      FilterableResponseSpecification responseSpec,
      FilterContext context) {

    log.info("Request: {}()", requestSpec.getURI());
    log.info("Request Headers: {}", requestSpec.getHeaders());
    //log.info(Optional.of("Request Body: {}"), requestSpec.getBody());

    Response response = context.next(requestSpec, responseSpec);

    log.info("Response Status Code: {}", response.getStatusCode());
    log.info("Response Headers: {}", response.getHeaders());
    log.info("Response Body: {}", response.getBody().asPrettyString());

    return response;
  }
}
