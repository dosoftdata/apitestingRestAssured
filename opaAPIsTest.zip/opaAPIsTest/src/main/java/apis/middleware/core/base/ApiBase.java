package apis.middleware.core.base;

import io.restassured.RestAssured;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.Getter;
import lombok.Setter;

/**
 * The type Api base.
 */
public class ApiBase{
    static {
        RestAssured.reset();
        RestAssured.requestSpecification = null;
        RestAssured.responseSpecification = null;
        RestAssured.urlEncodingEnabled = true;
        // Disable SSL verification globally for all requests
        RestAssured.useRelaxedHTTPSValidation();
        RestAssured.defaultParser = Parser.JSON;
        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
    }
    private static final RequestSpecification requestSpec = ApiSpecsMap.requestSpec;

    @Getter
    @Setter
    private Response response;

    /**
     * Fresh per-call CustomRequestSpec. Each scenario thread builds its own,
     * so request-level state (filters, headers, body) never crosses workers.
     */
    public static CustomRequestSpec spec(){
        return new CustomRequestSpec(requestSpec);
    }
}
