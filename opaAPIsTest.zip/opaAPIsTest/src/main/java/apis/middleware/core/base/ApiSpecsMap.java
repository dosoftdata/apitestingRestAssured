package apis.middleware.core.base;

import apis.middleware.core.filters.AllureRequestResponseFilter;
import apis.middleware.core.filters.DedupeRequestFilter;
import apis.middleware.core.filters.RequestDelayFilter;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.*;
import io.restassured.filter.log.*;
import io.restassured.specification.RequestSpecification;
import lombok.Data;
import org.apache.http.client.CookieStore;
import org.apache.http.client.protocol.RequestAcceptEncoding;
import org.apache.http.client.protocol.ResponseContentEncoding;
import org.apache.http.impl.client.*;


/**
 * The type Api specs map.
 */
@Data
@SuppressWarnings("deprecation")
public abstract class ApiSpecsMap {
  // Cookie jar is per-worker-thread so cookies set by one scenario do not
  // leak into a concurrent scenario on another worker under feature-parallel
  // execution. Hooks.@Before calls resetCookieStore() to clear between
  // scenarios that share a thread (same feature).
  private static final ThreadLocal<CookieStore> COOKIE_STORE =
      ThreadLocal.withInitial(BasicCookieStore::new);

  /** Clear the calling thread's cookie jar — call from Hooks.@Before. */
  public static void resetCookieStore() {
    COOKIE_STORE.get().clear();
  }

  /**
   * The constant requestSpec.
   */
  public static final RequestSpecification requestSpec = new RequestSpecBuilder()
            .addFilter(new RequestDelayFilter(2000))
            .addFilter(new DedupeRequestFilter())
            .addFilter(new AllureRequestResponseFilter())
            .addFilter(new RequestLoggingFilter(LogDetail.ALL))
            .addFilter(new ResponseLoggingFilter(LogDetail.ALL))
             .build()
            .config(RestAssuredConfig.newConfig()
                    .httpClient(HttpClientConfig.httpClientConfig()
                    .httpClientFactory(() -> {
                        DefaultHttpClient httpClient = new DefaultHttpClient();
                        httpClient.addRequestInterceptor(new RequestAcceptEncoding());
                        httpClient.addResponseInterceptor(new ResponseContentEncoding());
                        httpClient.setCookieStore(COOKIE_STORE.get());
                        return httpClient;
                    })
                    .setParam("http.protocol.cookie-policy", "compatibility")));

  private ApiSpecsMap (){}
}
