package apis.middleware.core.filters;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;

import java.util.concurrent.locks.LockSupport;
import java.util.concurrent.TimeUnit;

/**
 * The type Request delay filter.
 */
public class RequestDelayFilter implements Filter {
  private final long delayMillis;

  /**
   * Instantiates a new Request delay filter.
   *
   * @param delayMillis the delay millis
   */
  public RequestDelayFilter(long delayMillis) {
    this.delayMillis = delayMillis;
  }

  @Override
  public Response filter(FilterableRequestSpecification requestSpec,
      FilterableResponseSpecification responseSpec,
      FilterContext ctx) {
    // Park the calling thread. Previously a single-thread ScheduledExecutor
    // serialized every request through one worker, defeating feature-parallel
    // execution; per-thread parking lets workers wait independently.
    LockSupport.parkNanos(TimeUnit.MILLISECONDS.toNanos(delayMillis));
    return ctx.next(requestSpec, responseSpec);
  }
}
