/**
 * Base abstractions and shared primitives for the RestAssured core.
 *
 * <p>Defines foundational types (interfaces, base classes, error model) and
 * cross-cutting contracts that the rest of the middleware relies on.</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>Base request/response types</li>
 *   <li>Error handling, result wrappers, and validation utilities</li>
 *   <li>Lifecycle hooks and extension points</li>
 * </ul>
 *
 * @since 1.0
 * @see apis.middleware.core.filters
 * @see apis.middleware.core.helpers
 */
package apis.middleware.core.base;