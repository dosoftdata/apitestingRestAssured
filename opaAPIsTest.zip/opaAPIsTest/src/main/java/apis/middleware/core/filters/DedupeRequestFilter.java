package apis.middleware.core.filters;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;

import java.util.LinkedHashMap;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

/**
 * The type Dedupe request filter.
 */
@Slf4j
public class DedupeRequestFilter implements Filter {


  @Override
  public Response filter(FilterableRequestSpecification requestSpec,
      FilterableResponseSpecification responseSpec,
      FilterContext ctx) {

    // All scratch maps are per-invocation locals (previously public static
    // fields), so feature-parallel workers cannot clobber each other's
    // request state. For each kind we capture into a LinkedHashMap keyed by
    // name (last value wins), strip the originals from the spec, then
    // re-attach from the deduped map.

    // Headers
    Map<String, String> lastHeaders = new LinkedHashMap<>();
    requestSpec.getHeaders().asList().forEach(h -> lastHeaders.put(h.getName(), h.getValue()));
    requestSpec.removeHeaders();
    lastHeaders.forEach(requestSpec::header);

    // Query params
    Map<String, String> lastQueryParams = new LinkedHashMap<>();
    requestSpec.getQueryParams().forEach((k, v) -> lastQueryParams.put(k, String.valueOf(v)));
    lastQueryParams.keySet().forEach(requestSpec::removeQueryParam);
    lastQueryParams.forEach(requestSpec::queryParam);

    // Form params
    Map<String, String> lastFormParams = new LinkedHashMap<>();
    requestSpec.getFormParams().forEach((k, v) -> lastFormParams.put(k, String.valueOf(v)));
    lastFormParams.keySet().forEach(requestSpec::removeFormParam);
    lastFormParams.forEach(requestSpec::formParam);

    // Path params
    Map<String, String> lastPathParams = new LinkedHashMap<>();
    requestSpec.getPathParams().forEach((k, v) -> lastPathParams.put(k, String.valueOf(v)));
    lastPathParams.keySet().forEach(requestSpec::removePathParam);
    lastPathParams.forEach(requestSpec::pathParam);

    // Cookies
    Map<String, String> lastCookies = new LinkedHashMap<>();
    requestSpec.getCookies().asList().forEach(c -> lastCookies.put(c.getName(), c.getValue()));
    requestSpec.removeCookies();
    lastCookies.forEach(requestSpec::cookie);

    // Multiparts — RestAssured 3.3.0 has no remove API, so capture only.
    Map<String, String> lastMultiparts = new LinkedHashMap<>();
    lastMultiparts.clear();
    requestSpec.getMultiPartParams().forEach(mp -> lastMultiparts.put(mp.getControlName(), mp.getFileName()));

    return ctx.next(requestSpec, responseSpec);
  }
}
