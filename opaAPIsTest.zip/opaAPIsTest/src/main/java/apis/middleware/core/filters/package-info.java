/**
 * RestAssured filters and interceptors.
 *
 * <p>Reusable processing steps that can be composed to apply policies such as
 * logging, authentication, rate limiting, retries, and tracing.</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>Request/response interceptors</li>
 *   <li>Retry/backoff and circuit-breaker behaviors</li>
 *   <li>Tracing and metrics decorators</li>
 * </ul>
 *
 * @since 1.0
 * @see apis.middleware.core.base
 * @see apis.middleware.core.helpers
 */
package apis.middleware.core.filters;