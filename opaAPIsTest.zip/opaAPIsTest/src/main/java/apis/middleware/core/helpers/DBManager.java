package apis.middleware.core.helpers;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.extern.slf4j.Slf4j;

/**
 * DBManager
 * Singleton manager for a HikariCP-backed JDBC connection pool, safe for
 * feature-parallel test execution. Callers obtain a pooled {@link Connection}
 * via {@link #getConnection()} and MUST close it with try-with-resources so
 * the connection is returned to the pool.
 *
 * Lifecycle is ref-counted (see {@link #retain()} / {@link #release()}) so
 * the pool only drains when the LAST worker thread finishes — calling
 * {@code close()} directly from a per-worker {@code @AfterAll} would shut
 * the pool down while other workers are still running.
 */
@Slf4j
public class DBManager {
  private static volatile DBManager instance;
  private static final AtomicInteger ACTIVE_USERS = new AtomicInteger(0);
  private volatile HikariDataSource dataSource;
  private volatile String currentUrl;

  private DBManager() {}

  public static DBManager getInstance() {
    DBManager local = instance;
    if (local == null) {
      synchronized (DBManager.class) {
        local = instance;
        if (local == null) {
          instance = local = new DBManager();
        }
      }
    }
    return local;
  }

  /**
   * Initialise the connection pool. Idempotent for the same URL.
   * Throws if called with a URL different from the pool's current URL —
   * silent switching would route subsequent queries to the wrong DB.
   */
  public void connect(String jdbcUrl, String user, String password) {
    connect(jdbcUrl, user, password, 10);
  }

  /**
   * Initialise the connection pool with an explicit maximum pool size.
   * Size the pool to at least the Cucumber feature-parallelism count
   * (see {@code junit-platform.properties}) plus headroom.
   */
  public synchronized void connect(String jdbcUrl, String user, String password, int maxPoolSize) {
    if (dataSource != null && !dataSource.isClosed()) {
      if (!Objects.equals(currentUrl, jdbcUrl)) {
        throw new IllegalStateException(
            "DBManager already initialised with URL '" + currentUrl
                + "'; refusing to switch to '" + jdbcUrl + "'.");
      }
      return;
    }
    HikariConfig cfg = new HikariConfig();
    cfg.setJdbcUrl(jdbcUrl);
    cfg.setUsername(user);
    cfg.setPassword(password);
    cfg.setMaximumPoolSize(maxPoolSize);
    cfg.setPoolName("apis-middleware-db");
    // SQLite uses file-level write locking; without WAL, concurrent writers
    // from parallel features throw SQLITE_BUSY. WAL allows readers alongside
    // a single writer; busy_timeout makes the driver wait instead of failing
    // immediately when the writer lock is held.
    if (jdbcUrl != null && jdbcUrl.startsWith("jdbc:sqlite")) {
      cfg.setConnectionInitSql("PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;");
    }
    dataSource = new HikariDataSource(cfg);
    currentUrl = jdbcUrl;
    log.info("[DBManager] Connection pool started (url={}, maxPoolSize={}).", jdbcUrl, maxPoolSize);
  }

  /**
   * Borrow a pooled connection. Caller MUST close it (try-with-resources)
   * so it is returned to the pool rather than physically closed.
   */
  public Connection getConnection() throws SQLException {
    if (dataSource == null || dataSource.isClosed()) {
      throw new SQLException("DBManager pool not initialised; call connect(...) first");
    }
    return dataSource.getConnection();
  }

  /** Announce usage for ref-counted shutdown; call from Hooks.@BeforeAll on each worker. */
  public static void retain() {
    int n = ACTIVE_USERS.incrementAndGet();
    log.debug("[DBManager] retain -> users={}", n);
  }

  /**
   * Decrement usage; closes the pool when the count reaches zero.
   * Call from Hooks.@AfterAll on each worker.
   */
  public synchronized void release() {
    int n = ACTIVE_USERS.decrementAndGet();
    log.debug("[DBManager] release -> users={}", n);
    if (n <= 0) {
      ACTIVE_USERS.set(0);
      closeInternal("last worker released");
    }
  }

  /** Force-close the pool (suite teardown / explicit cleanup). */
  public synchronized void close() {
    ACTIVE_USERS.set(0);
    closeInternal("explicit close");
  }

  private void closeInternal(String reason) {
    if (dataSource != null && !dataSource.isClosed()) {
      dataSource.close();
      log.info("[DBManager] Connection pool closed ({}).", reason);
    }
    currentUrl = null;
  }
}
