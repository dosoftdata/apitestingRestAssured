/**
 * Helper utilities for the middleware core.
 *
 * <p>Small, focused utilities (formatting, mapping, timeouts, resource
 * management) used by filters, DSL actions, and hooks.</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>Object mappers and adapters</li>
 *   <li>Resource and connection helpers</li>
 *   <li>Time and retry utilities</li>
 * * </ul>
 *
 * @since 1.0
 */
package apis.middleware.core.helpers;