
/**
 * General-purpose utilities used across middleware tests and DSL.
 *
 * <p>Small, cohesive helpers that do not belong to a specific domain area:
 * collections, IO, time, JSON, HTTP, and reflection helpers.</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>Serialization and mapping helpers</li>
 *   <li>Retry/time/clock utilities</li>
 *   <li>File and resource access helpers</li>
 * </ul>
 *
 * @since 1.0
 * @see apis.middleware.core.helpers
 * @see apis.middleware.testData
 */
package apis.middleware.utilities;