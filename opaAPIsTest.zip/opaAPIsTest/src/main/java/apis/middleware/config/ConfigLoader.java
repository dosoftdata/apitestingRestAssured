package apis.middleware.config;

import apis.middleware.dsl.ScenarioContext;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import org.openjdk.nashorn.api.scripting.NashornScriptEngineFactory;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import java.io.FileReader;
import java.util.Map;

/**
 * The type Config loader.
 */
public class ConfigLoader {

  private static final AtomicBoolean LOADED = new AtomicBoolean(false);

  /**
   * Load config.
   * Synchronized so that under feature-parallel execution, threads that lose
   * the race block until the winning thread has finished writing config into
   * the cross-thread GLOBAL store. Without this, loser threads can proceed to
   * step definitions and read missing keys (yielding the literal string
   * "null" in URIs/headers via getProp).
   */
  public static synchronized void loadConfig() {
    if (LOADED.get()) return;

    try {
      ScriptEngine engine = createScriptEngine();
      if (engine == null) {
        throw new IllegalStateException("No JavaScript engine available for config");
      }

      engine.eval(new FileReader("src/test/resources/config.js"));
      Invocable invocable = (Invocable) engine;
      Object result = invocable.invokeFunction("fn");
      storeNested(result, "");
      LOADED.set(true);
    } catch (Exception e) {
      throw new RuntimeException("Failed to load config.js", e);
    }
  }

  private static ScriptEngine createScriptEngine() {
    String version = System.getProperty("java.version");
    boolean isLegacy = version.startsWith("1.8") || version.startsWith("9") || version.startsWith("10") ||
        version.startsWith("11") || version.startsWith("12") || version.startsWith("13");

    if (isLegacy) {
      // Java 8–13 → use built-in Nashorn
      return new ScriptEngineManager().getEngineByName("nashorn");
    } else {
      // Java 15+ → use external nashorn-core
      return new NashornScriptEngineFactory()
          .getScriptEngine("--language=es6");
    }
  }
  /**
   * Recursively store nested objects and arrays into ScenarioContext.
   * Keys use dot notation for objects and [index] for arrays.
   */
  @SuppressWarnings("unchecked")
  private static void storeNested(Object value, String path) {
    if (value instanceof Map<?, ?>) {
      Map<?, ?> map = (Map<?, ?>) value;
      // Handle JS object
      map.forEach((k, v) -> {
        String newPath = path.isEmpty() ? k.toString() : path + "." + k;
        storeNested(v, newPath);
      });
    } else if (value instanceof List<?>) {
      List<?> list = (List<?>) value;
      // Handle JS array
      for (int i = 0; i < list.size(); i++) {
        String newPath = path + "[" + i + "]";
        storeNested(list.get(i), newPath);
      }
    } else {
      // Store in the cross-thread GLOBAL map (write-once semantics) so every
      // worker thread sees the value via ScenarioContext.get's GLOBAL fallback.
      // Previously this called ScenarioContext.set, which writes to a
      // ThreadLocal — combined with the load-once guard, only the first worker
      // thread ever received config values under feature-parallel execution.
      ScenarioContext.putIfAbsentGlobal(path, value);
    }
  }
}
