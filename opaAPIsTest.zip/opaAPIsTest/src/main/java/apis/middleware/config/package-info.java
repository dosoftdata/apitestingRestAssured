/**
 * Configuration components for the APIs middleware.
 *
 * <p>Provides centralized configuration keys, environment property access,
 * and bootstrap helpers used by the middleware core and DSL layers.</p>
 *
 * <h2>Contents</h2>
 * <ul>
 *   <li>Configuration models and property resolvers</li>
 *   <li>Profiles (dev, uat, prod) and test environment readers</li>
 *   <li>Utilities to load secrets and externalized settings</li>
 * </ul>
 *
 * @since 1.0
 */
package apis.middleware.config;
