# Release Notes — `parallel-junit`

**Date:** 2026-05-22
**Branch:** `parallel-junit` → targeting `develop`
**Audience:** QA, Engineering, Delivery, Product stakeholders

---

## TL;DR
The middleware API test suite now runs **~3× faster** (≈ 50 min → ≈ 16 min), tolerates transient flakes via automatic retries, keeps Allure reports separated per environment, and gains first-class **database-level test coverage**.

## What's new

### 1. Faster test execution
- Migrated from TestNG to **Cucumber on JUnit Platform** with **feature-level parallelism** (4 parallel workers by default).
- Scenarios within a single feature still run sequentially, preserving feature-internal state.
- **Business impact:** faster CI feedback on every merge request, reduced pipeline cost, shorter release cycles.

### 2. Resilient pipelines (automatic retry)
- A whole-feature retry mechanism is in place; up to 5 flaky failures are tolerated before the build is marked unstable.
- **Business impact:** transient network or environment hiccups no longer fail a release; persistent flakes are still surfaced.

### 3. Per-environment Allure reports
- Test results are now written to `reports/<env>/` (e.g. `reports/uat/`, `reports/preprod/`, `reports/azure-pam-01/`) driven by `-Denv=…`.
- **Business impact:** QA can compare runs across environments without overwriting history; easier to share environment-specific reports with stakeholders.

### 4. Database-level testing (new capability)
- New `DbSteps` DSL, HikariCP connection pool, SQLite driver.
- Demo features included (`csv-to-sqlite.feature`, `sqlite-crud.feature`).
- **Business impact:** scenarios can seed and verify data directly in the database, enabling true end-to-end data-integrity checks (e.g. payment posted via API → row present in DB).

### 5. Broader mock coverage (WireMock)
- New stub mappings for **Players** (create/get), **Invoices** (including a wrong-MIME negative case) and **Inventory** (add-item, submit-order).
- Legacy `WireMockFactory` consolidated.
- **Business impact:** more scenarios run hermetically without a live downstream, useful for PR pipelines and offline development.

### 6. Framework hardening
- `ScenarioContext`, `ConfigLoader`, request filters and the TestData layer reworked for thread safety under parallel execution.
- **Business impact:** fewer "passes locally, fails in CI" tickets going forward.

## Risks & rollout notes
- **Foundational change:** the runtime engine moved from TestNG to JUnit Platform. A smoke run on each target environment (UAT, pre-prod) is recommended before promoting to `main`.
- No changes to feature-file business logic or API contracts.
- No action required from product or delivery stakeholders.

## How to run
```bash
mvn clean test -Denv=uat         # results in reports/uat/
mvn clean test -Denv=preprod     # results in reports/preprod/
```

---

*Prepared by QA Engineering — Clement Mukendi*
