# API Testing - Middleware


**Version:** 1.0
**Language:** Java
**Build Tool:** Maven
**Test Engine:** Cucumber on JUnit Platform (opt-in feature-level parallel)

---

## 1. Overview

The **API Testing Framework** is an automation solution designed to validate RESTful APIs with high reliability and flexibility.  
It integrates **Cucumber (BDD)**, **Rest-Assured**, **WireMock**, and **Allure Reporting** to support comprehensive, automated API validation for middleware and backend services.

This framework provides a modular foundation for:
- Automated functional and regression API testing  
- Scenario-based validation using BDD  
- Mocking and stubbing of API endpoints  
- Data-driven test execution with centralized reporting  

---

## 2. Key Features

- **BDD Implementation:** Behavior-driven testing with Cucumber feature files
- **Parallel Execution:** Feature-level parallelism on JUnit Platform — **opt-in** via `-Dparallel=true -Dthread=<n>` (defaults: `parallel=false`, `thread=1`)
- **Automatic Retry:** Whole-feature retry tolerates up to 5 flaky failures per run
- **Allure Reporting:** Rich, interactive reports generated under `reports/`
- **Mocking Support:** WireMock-based API virtualization for controlled testing
- **Database Testing:** `DbSteps` DSL with HikariCP pool; built-in SQLite driver for offline data-integrity scenarios
- **Reusable Components:** Modular core classes for configuration, logging, and data handling
- **Data-Driven Testing:** CSV-based input/output utilities
- **Flexible Configuration:** Environment-specific setup via XML and JavaScript configuration files
- **Allure Reporting:** Interactive and visual reports for test analysis
- **Logging & Traceability:** Log4j2-based structured execution logs

---

## 3. Architecture & Components

### 3.1 Core Modules
| Module | Description |
|--------|--------------|
| **bootstrap** | Test-data bootstrap (e.g. player seeding) |
| **core** | Base classes for API testing, request specs, response handling, filters, DB manager, WireMock factory |
| **config** | Configuration management |
| **dsl** | Domain-specific utilities and step definitions (incl. `DbSteps`, `CommonSteps`, `OneTimeSteps`) |
| **models** | POJOs for request and response structures |
| **testData** | Dynamic test-data generation and repository |
| **utilities** | CSV utilities and shared helper methods |

### 3.2 Test Modules
| Module       | Description |
|--------------|--------------|
| **runners**  | Cucumber test runners |
| **hooks**    | Setup and teardown logic |
| **features** | BDD feature files |
| **wiremock** | WireMock stubs for simulated responses |

---

## 4. Project Structure

```
apis.middleware/
├── pom.xml
├── src/
│   ├── main/java/apis/middleware/
│   │   ├── bootstrap/
│   │   ├── config/
│   │   ├── core/
│   │   ├── dsl/
│   │   ├── models/
│   │   ├── testData/
│   │   └── utilities/
│   ├── main/resources/
│   │   ├── allure.properties
│   │   └── log4j2.xml
│   ├── test/apis/middleware/
│   │   ├── hooks/
│   │   └── runners/
│   └── test/resources/
│       ├── features/
│       ├── testdata/
│       ├── wiremock/
│       ├── config.js
│       └── junit-platform.properties
└── .gitignore
```

---

## 5. Prerequisites

| Requirement | Version                             |
|--------------|-------------------------------------|
| Java | 17+                                 |
| Maven | 3.6+                                |
| IntelliJ IDEA (Recommended) | Latest version with Cucumber plugin |
| Allure Commandline | 2.30+                               |

> ℹ️ Install Allure using:
> ```bash
> scoop install allure    # (Windows)
> brew install allure     # (macOS)
> ```

---

## 6. Setup & Installation

1. Clone the repository:
   ```bash
   git clone https://gitlab.dc.opap/deveng/middleware-backend/middleware-api-testing.git apis.middleware
   cd apis.middleware
   ```

2. Build the project:
   ```bash
   mvn clean install
   ```

3. Run sample tests to verify setup:
   ```bash
   mvn test
   ```

---

## 7. Test Execution

The suite runs on **Cucumber + JUnit Platform**. By default, execution is
**sequential (1 thread)**. Feature-level parallelism is opt-in via system
properties; scenarios within a single feature always stay sequential.

### 7.1 Run All Tests (sequential, default)
```bash
mvn clean install
```

### 7.2 Run Against a Specific Environment
```bash
mvn clean install -Denv=uat
mvn clean install -Denv=preprod
```

### 7.3 Enable Parallel Execution (opt-in)
| Property   | Default | Description                                       |
|------------|---------|---------------------------------------------------|
| `parallel` | `false` | Enable feature-level parallel execution           |
| `thread`   | `1`     | Number of parallel workers when `parallel=true`   |

```bash
mvn clean install -Denv=uat -Dparallel=true -Dthread=10
```

### 7.4 Run a Subset by Tag
```bash
mvn clean install -Dcucumber.filter.tags="@MID-130"
mvn clean install -Dcucumber.filter.tags="@smoke and not @wip"
```

### 7.5 Run from IDE
Open `src/test/apis/middleware/runners/CliIT.java`, add a tag filter and run it as
a **JUnit** test.

### 7.6 Retry / Flake Tolerance
The build tolerates up to **5 flaky failures** before being marked unstable
(`failOnFlakeCount` in `pom.xml`). Persistent failures still break the build.

---

## 8. Allure Reporting

### 8.1 Report Generation
After test execution, Allure raw results are stored under `reports/` and the
generated HTML site under `reports/site/`.

Open the interactive report:
```bash
allure serve reports
```

Or build the static HTML version:
```bash
allure generate reports --clean -o reports/site
```

### 8.2 Report Features
- Detailed step-by-step execution logs  
- Cucumber scenario hierarchy  
- Attachments for request/response payloads  
- Trend analysis (if integrated with CI/CD)  
- Status summary (Passed / Failed / Broken / Skipped)

---

## 9. Configuration

Configuration files:
- `config.js` – Environment and endpoint configuration  
- `log4j2.xml` – Logging configuration  
- `pom.xml` – Build and plugin management (including Allure)  

---

## 10. Mocking and Virtualization

WireMock is used to simulate API responses for isolated testing.  

Example stub file (`src/test/resources/wiremock/mappings/greet-mapping.json`):
```json
{
  "request": { "method": "GET", "url": "/greet" },
  "response": { "status": 200, "body": "Hello, User!" }
}
```

To enable WireMock, initialize via `WireMockFactoryOnce.java` (ref-counted singleton, safe under feature-parallel execution).

---

## 11. Test Data Management

Utilities:
- `CSVReadUtil` – Read test data from CSV
- `CSVWriteUtil` – Export results or audit logs
- `TestDataRepository` / `DynamicDataPreProcessor` – Dynamic data resolution at scenario runtime

Test data files should be placed under:
```
src/test/resources/testdata/
```

---

## 11b. Database Testing

The framework supports direct database assertions through the `DbSteps` DSL,
backed by a **HikariCP** connection pool. A built-in **SQLite** driver enables
offline demos and data-integrity scenarios.

Demo features:
- `src/test/resources/features/db/csv-to-sqlite.feature` — seed a SQLite DB from a CSV
- `src/test/resources/features/db/sqlite-crud.feature` — basic CRUD assertions

Typical use cases:
- Verify a row exists / has expected values after an API call
- Seed reference data before a scenario
- Cross-check API responses against the underlying data store

---

## 12. Logging

Logging via **Log4j2** ensures traceability:
- Config: `src/main/resources/log4j2.xml`
- Log levels: INFO, DEBUG, ERROR
- Output: Console + log files (if configured)

---

## 13. CI/CD Integration

In a CI environment (e.g., GitLab CI/CD, Azure DevOps):

```bash
mvn clean install -Denv=uat -Dparallel=true -Dthread=10
allure generate reports --clean -o reports/site
allure open reports/site
```

Integrate Allure publishing as a post-build step for visibility in your pipeline dashboard.
The GitLab pipeline exposes `parallel` and `thread` as variables (see `devops/.gitlab-ci.yml`).

---

## 14. Maintenance Guidelines

- Maintain consistent naming conventions for feature and step files.  
- Store reusable components in `/core` and `/utilities`.  
- Keep environment-specific properties externalized.  
- Validate API tests against both live and mocked data.  

---

## 15. Contact & Support

For framework-related queries or requests: 
- **Team:** QA Automation / Middleware   
- **Location:** Athens HQ  

---

© 2025–present apis.middleware Automation Framework. All rights reserved.
