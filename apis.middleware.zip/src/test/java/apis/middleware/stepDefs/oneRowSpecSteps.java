package apis.middleware.stepDefs;

import static org.awaitility.Awaitility.await;

import apis.middleware.core.base.ApiBase;
import apis.middleware.dsl.ScenarioContext;
import apis.middleware.dsl.actions.DslHelper;
import io.cucumber.java.en.Given;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;


/**
 * The type One row spec steps.
 */
@Slf4j
public class oneRowSpecSteps extends DslHelper {

    /**
     * Instantiates a new One row spec steps.
     *
     * @param context the context
     */
    public oneRowSpecSteps(ScenarioContext context) {
        super(context);
    }

    /**
     * User has janus token.
     */
    @Given("^User has janus token$")
    public void user_has_janus_token() {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("janus.baseUrl"));
        spec.setBasePath(context.getProp("janus.basePath"));
        spec.header("Content-Type",context.getProp("janus.contentType"));
        spec.header("Authorization",context.getProp("janus.authorization"));
        spec.setFormParam("grant_type",context.getProp("janus.grantType"));
        spec.setFormParam("scope",context.getProp("janus.scope"));
        spec.setFormParam("ssbtId",context.getProp("ssbtid"));
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);
        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        context.setProp("janusToken", resp.get("access_token"));
        context.setProp("janusTokenType", resp.get("token_type"));
    }

    /**
     * Casino favorite games.
     *
     * @param location the location
     */
    @Given("^Get Casino Favorite Games in (.*) location$")
    public void casino_favorite_games( String location ) {
        spec = ApiBase.spec();
        AtomicReference<Response> lastResp = new AtomicReference<>();
        spec.setBaseUri(context.getProp("psMiddlewareHost"));
        spec.setBasePath("uip/casino/api/v1.0/games/favorite");
        spec.header("Content-Type","application/json");
        spec.header("Accept","application/json");
        spec.header("locale","el-GR");
        spec.header("x-player-id",context.getProp("playerId"));
        spec.param("location",location);
        await()
            .atMost(Duration.ofMinutes(5).plusSeconds(30))
            .pollInterval(Duration.ofMillis(5000))
            .ignoreExceptions()
            .until(() -> {
                Response resp = context.getRes()
                    .spec(spec.build())
                    .when().get();
                lastResp.set(resp);
              return resp.statusCode() == 200;
            });
        context.getApi().setResponse(lastResp.get());
        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        context.setProp("casinoFavoriteGames", String.join(",", resp.getList("data.id")));
        List<String> hrefs = resp.getList("data.vendor.href");
        List<String> ids = hrefs.stream()
            .map(h -> h.substring(h.lastIndexOf("/") + 1))
            .collect(Collectors.toList());
        context.setProp("casinoFavoriteGamesVendor", String.join(",", ids) );

    }

    /**
     * User has tora token.
     */
    @Given("^User has tora token$")
    public void user_has_tora_token() {
        spec = ApiBase.spec();
        spec.setBaseUri(context.getProp("tora.baseUrl"));
        spec.setBasePath(context.getProp("tora.basePath"));
        spec.header("Content-Type",context.getProp("janus.contentType"));
        spec.header(" Cookie",context.getProp("tora.cookie"));
        spec.setFormParam("grant_type",context.getProp("tora.grant_type"));
        spec.setFormParam("client_id",context.getProp("tora.client_id"));
        spec.setFormParam("client_secret",context.getProp("tora.client_secret"));
        spec.setFormParam("scope",context.getProp("tora.scope"));
        context.getApi().setResponse(spec.when().post());
        context.getApi().getResponse().then().statusCode(200);
        JsonPath resp = context.getApi().getResponse().then().extract().body().jsonPath();
        context.setProp("toraAccessToken", resp.get("access_token"));
        context.setProp("toraTokenType", resp.get("token_type"));
    }
}
