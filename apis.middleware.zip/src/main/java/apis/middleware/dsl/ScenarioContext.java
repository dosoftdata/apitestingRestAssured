
package apis.middleware.dsl;

import apis.middleware.core.filters.AllureRequestResponseFilter;
import io.cucumber.java.Scenario;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import io.restassured.specification.RequestSpecification;
import lombok.*;
import apis.middleware.core.base.ApiBase;
import apis.middleware.core.base.CustomRequestSpec;

import static io.restassured.RestAssured.given;

/**
 * The type Scenario context.
 * - ThreadLocal per-scenario store (existing)
 * - global, write-once store shared across all threads/scenarios
 */
@Getter
public class ScenarioContext {

  // ===== per-scenario store (existing) =====
  private static final ThreadLocal<Map<String, Object>> context = ThreadLocal.withInitial(HashMap::new);

  @Getter
  private ApiBase api;
  private RequestSpecification res;

  /** Current Scenario (ThreadLocal). */
  public static final ThreadLocal<Scenario> sc = new ThreadLocal<>();

  /** Scenario-level spec holder. */
  CustomRequestSpec spec;

  /** Construct per-scenario context. */
  public ScenarioContext() {
    api  = new ApiBase();
    spec = ApiBase.spec();
    res  = given().filter(new AllureRequestResponseFilter());
  }

  /** Per-scenario put */
  public static void set(String key, Object value) {
    context.get().put(key, value);
  }

  /** Per-scenario get (untyped) */
  public static Object get(String key) {
    return context.get().get(key);
  }

  /** Per-scenario get (typed convenience) */
  public String getProp(String key) {
    return String.valueOf(context.get().get(key));
  }

  /** Per-scenario set (instance convenience) */
  public void setProp(String key, Object value) {
    context.get().put(key, value);
  }

  /**
   * Clear per-scenario context.
   * NOTE: Using remove() prevents retaining the map on long-lived test worker threads.
   */
  public static void clear() {
    context.remove();
    sc.remove();
  }

  /** Per-scenario get all */
  public static Map<String, Object> getAll() {
    return context.get();
  }

  /**
   * Resolve placeholders in a string using context variables.
   * Supports #(var) and {{var}} syntax.
   */
  public static String resolve(String text) {
    if (text == null) return null;
    StringBuffer sb;

    // #(var)
    Pattern hashPattern = Pattern.compile("#\\((.*?)\\)");
    Matcher hashMatcher = hashPattern.matcher(text);
    sb = new StringBuffer();
    while (hashMatcher.find()) {
      String key = hashMatcher.group(1);
      Object value = get(key);
      hashMatcher.appendReplacement(sb, value != null ? value.toString() : "");
    }

    // {{var}}
    hashPattern = Pattern.compile("\\{\\{(.*?)\\}\\}");
    hashMatcher = hashPattern.matcher(text);
    sb = new StringBuffer();
    while (hashMatcher.find()) {
      String key = hashMatcher.group(1);
      Object value = get(key);
      hashMatcher.appendReplacement(sb, value != null ? value.toString() : "");
    }
    hashMatcher.appendTail(sb);
    return sb.toString();
  }

  // Instance-scoped variables (existing)
  private final Map<String, Object> variables = new HashMap<>();

  public void setVariable(String name, Object value) { variables.put(name, value); }
  public Object getVariable(String name) { return variables.get(name); }

  // ===== NEW: global, write-once store =====

  /** Global store shared by all threads/scenarios; intended for immutable or write-once values. */
  private static final ConcurrentMap<String, Object> GLOBAL = new ConcurrentHashMap<>();

  /**
   * Put globally only if absent (write-once semantics).
   * @return previous value if one existed; otherwise null
   */
  public static Object putIfAbsentGlobal(String key, Object value) {
    return GLOBAL.putIfAbsent(key, value);
  }

  /** Get a global value (typed). */
  @SuppressWarnings("unchecked")
  public static <T> T getGlobal(String key, Class<T> type) {
    Object v = GLOBAL.get(key);
    return type.isInstance(v) ? (T) v : null;
  }

  /**
   * Clear the global store.
   * Use only at full suite shutdown if you really need to drop globals.
   */
  public static void clearGlobal() {
    GLOBAL.clear();
  }
}
