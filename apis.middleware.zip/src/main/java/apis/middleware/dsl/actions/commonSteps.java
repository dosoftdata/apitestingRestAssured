package apis.middleware.dsl.actions;

import com.fasterxml.jackson.databind.JsonNode;

import io.cucumber.java.en.*;
import io.qameta.allure.Allure;
import io.qameta.allure.model.Label;
import io.restassured.response.ValidatableResponse;
import java.util.ArrayList;
import java.util.List;
import lombok.NonNull;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import apis.middleware.core.filters.RequestDelayFilter;
import apis.middleware.dsl.*;

import java.io.File;
import org.hamcrest.Matcher;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import static org.junit.Assert.assertTrue;
import org.junit.Assert;
/**
 * The type Common steps.
 */
@Slf4j
@SuppressWarnings("deprecation")
public final class commonSteps extends DslHelper {

  /**
   * Instantiates a new Common steps.
   *
   * @param context the context
   */
  public commonSteps(ScenarioContext context) {super(context);}

  /**
   * Url.
   *
   * @param expression the expression
   */
  @When("^url (.+)")
  public void url(String expression) {
    this.context.getSpec().setBaseUri(ScenarioContext.resolve(expression));
    ScenarioContext.sc.get().getSourceTagNames().stream()
        .filter(tag -> tag.startsWith("@epic:"))
        .findFirst()
        .ifPresent(tag -> {
          String epicName = tag.replace("@epic:", "");
          Allure.getLifecycle().updateTestCase(testResult -> {
            testResult.getLabels().add(new Label().setName("epic").setValue(epicName));
          });
        });
  }

  /**
   * Delay request.
   *
   * @param millisecond the millisecond
   */
  @When("^delay request (\\d+)")
  public void delayRequest(int millisecond) {
    this.context.getSpec().setFilter(new RequestDelayFilter(millisecond));
  }

  /**
   * Path.
   *
   * @param path the path
   */
  @When("^path (.+)")
  public void path(String path) {
    this.context.getSpec().setBasePath(ScenarioContext.resolve(path));
  }

  /**
   * Param.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^param ([^\\s]+) = (.+)")
  public void param(String name, String value) {
    this.context.getSpec().setQueryParam(name, ScenarioContext.resolve(value));
  }

  /**
   * Path param.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^pathParam ([^\\s]+) = (.+)")
  public void pathParam(String name, String value) {
    this.context.getSpec().setPathParam(name, ScenarioContext.resolve(value));
  }

  /**
   * Cookie.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^cookie ([^\\s]+) = (.+)")
  public void cookie(String name, String value) {
    this.context.getSpec().setCookie(name, ScenarioContext.resolve(value));
  }

  /**
   * Header.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^header ([^\\s]+) = (.+)")
  public void header(String name, String value) {

    this.context.getSpec().setHeader(name, ScenarioContext.resolve(value));
  }

  /**
   * Method.
   *
   * @param method the method
   * @param path   the path
   */
  @When("^method (GET|POST|PUT|PATCH|DELETE)(?: \"([^\"]+)\")?$")
  public void method(String method, String path) {
    if (path != null) {
      this.context.getSpec().setBasePath(ScenarioContext.resolve(path));
    }
    this.context.getApi().setResponse(this.context.getRes().spec(this.context.getSpec().build()).when().request(method) );

  }

  /**
   * Retry.
   *
   * @param method        the method
   * @param path          the path
   * @param conditionJson the condition json
   */
  @SneakyThrows
  @When("^retry (GET|POST|PUT|PATCH|DELETE)\\s+([^\\s]+)? until condition$")
  public void retry(String method, String path,  String conditionJson)  {
    awaitUntil(method, path, conditionJson);
  }

  /**
   * Retry json.
   *
   * @param method        the method
   * @param path          the path
   * @param conditionJson the condition json
   */
  @When("^retry (GET|POST|PUT|PATCH|DELETE)\\s+([^\\s]+)? until condition (.*)$")
  public void retryJson(String method, String path,  String conditionJson)  {
    awaitUntil(method, path, conditionJson);
  }

  /**
   * Form field.
   *
   * @param name  the name
   * @param value the value
   */
  @When("^form field ([^\\s]+) = (.+)")
  public void formField(String name, Object value) {
    this.context.getSpec().setFormParam(name, ScenarioContext.resolve((String) value));
  }

  /**
   * Request docstring.
   *
   * @param body the body
   */
  @When("^request$")
  public void requestDocstring(String body) {
    this.context.getSpec().setBody(ScenarioContext.resolve(body));
  }

  /**
   * Request.
   *
   * @param body the body
   */
  @When("^request (.+)")
  public void request(String body) { this.context.getSpec().setBody(ScenarioContext.resolve(body));}

  /**
   * Def.
   *
   * @param name       the name
   * @param expression the expression
   */
  @When("^def (\\w+) = (.+)$")
  public void def(String name, String expression) {
    ScenarioContext.set(name, expression);
  }

  /**
   * Def doc string.
   *
   * @param name       the name
   * @param expression the expression
   */
  @When("^def (.+) =$")
  public void defDocString(String name, String expression) {
    ScenarioContext.set(name, expression);
  }

  /**
   * Print.
   *
   * @param expression the expression
   */
  @When("^print (.+)")
  public void print(@NonNull String expression) {
    log.info(ScenarioContext.resolve(expression));
  }

  /**
   * Def response.
   *
   * @param name       the name
   * @param expression the expression
   */
  @When("^def (.*) in response.(.*)$")
  public void defResponse(String name, String expression) {
    String[] expressions = expression.split(",");
    List<String> values = new ArrayList<>();

    for (String expr : expressions) {
      String trimmedExpr = expr.trim();
      String value = context.getApi().getResponse().jsonPath().getString(trimmedExpr);
      if (value != null) {
        values.add(value);
      }
    }

    if (!values.isEmpty()) {
      String combinedValue = String.join(",", values);
      ScenarioContext.set(name, combinedValue);
    }
  }

  /**
   * Def response cookie.
   *
   * @param name       the name
   * @param expression the expression
   */
  @When("^Cookie (.+) in response.(.+)$")
  public void defResponseCookie(@NonNull String name, @NonNull String expression) {
    String[] expressions = expression.split(",");
    List<String> values = new ArrayList<>();

    for (String expr : expressions) {
      String trimmedExpr = expr.trim();
      String value = context.getApi().getResponse().cookie(trimmedExpr);
      if (value != null) {
        values.add(value);
      }
    }

    if (!values.isEmpty()) {
      String combinedValue = String.join(",", values);
      ScenarioContext.set(name, combinedValue);
    }
  }

  /**
   * Def response header.
   *
   * @param name       the name
   * @param expression the expression
   */
  @When("^Header (.+) in response.(.+)$")
  public void defResponseHeader(@NonNull String name, @NonNull String expression) {
    String[] expressions = expression.split(",");
    List<String> values = new ArrayList<>();

    for (String expr : expressions) {
      String trimmedExpr = expr.trim();
      String value = context.getApi().getResponse().getHeader(trimmedExpr);
      if (value != null) {
        values.add(value);
      }
    }

    if (!values.isEmpty()) {
      String combinedValue = String.join(",", values);
      ScenarioContext.set(name, combinedValue);
    }
  }


  /**
   * Status.
   *
   * @param status the status
   */
  @When("^status (\\d+)")
  public void status(int status) {
    context.getApi().getResponse().then().statusCode(status);
  }

  /**
   * Status or.
   *
   * @param status  the status
   * @param status1 the status 1
   */
  @When("^status (\\d+) or (\\d+)")
  public void statusOr(int status, int status1) {
    context.getApi().getResponse().then().statusCode(
        anyOf(equalTo(status),
            equalTo(status1))
    );
  }

  /**
   * Assert equal.
   *
   * @param expression the expression
   * @param s1         the s 1
   */
  @When("^assert (.+) = (.+)")
  public void assertEqual(String expression,String s1) {
    Assert.assertEquals(ScenarioContext.resolve(expression.toString().trim()), s1.toString().trim() == ""? null : s1.toString().trim() );
  }

  /**
   * Match.
   *
   * @param expression the expression
   * @param op1        the op 1
   * @param rhs        the rhs
   */
  @SneakyThrows
  @When("^match response (.+)(=|contains|any|only|deep)(.*)$")
  public void match(String expression, String op1, String rhs)  {
    String jsonPath = expression.trim();
    String expected = ScenarioContext.resolve(rhs).trim();

    Object actual = context.getApi().getResponse().path(jsonPath);

    switch (op1) {
      case "=":
        assertThat(actual.toString(), equalTo(expected));
        break;
      case "contains":
        assertThat(actual.toString(), containsString(expected));
        break;
      case "any":
        assertThat(actual.toString().split(","), hasItemInArray(expected));
        break;
      case "only":
        assertThat(actual.toString(), equalTo(expected));
        break;
      case "deep":
        JsonNode actualNode = mapper.readTree(mapper.writeValueAsString(actual));
        JsonNode expectedNode = mapper.readTree(expected);
        assertThat("JSON deep comparison failed", actualNode.equals(expectedNode), is(true));
        break;
      default:
        log.error("Unsupported match operator: " .concat( op1));
    }
  }

  /**
   * Match doc string.
   *
   * @param expression the expression
   * @param op1        the op 1
   * @param rhs        the rhs
   */
  @SneakyThrows
  @When("^match string (.+)(=|contains|has)(.*)$")
  public void matchDocString(String expression, String op1, String rhs)  {
    String _expression = ScenarioContext.resolve(expression);
    String expected = ScenarioContext.resolve(rhs).trim();

    switch (op1) {
      case "=":
        assertThat(_expression.toString(), equalTo(expected));
        break;
      case "contains":
        assertThat(_expression.toString(), containsString(expected));
        break;
      case "any":
        assertThat(_expression.toString().split(","), hasItemInArray(expected));
        break;
      case "only":
        assertThat(_expression.toString(), equalTo(expected));
        break;
      default:
        log.error("Unsupported match operator: " .concat( op1));
    }
  }

  /**
   * Redirect follow.
   *
   * @param b the b
   */
  @When("^redirect follow (\\d+)")
  public void redirectFollow(Integer b) {
    this.context.getSpec().setRedirectFollow(Boolean.valueOf(String.valueOf(b)));
  }

  /**
   * Redirect circular.
   *
   * @param b the b
   */
  @When("^redirect circular (\\d+)")
  public void redirectCircular(Integer b) {
    this.context.getSpec().setRedirectCircular(Boolean.valueOf(String.valueOf(b)));
  }

  /**
   * Multipart file.
   *
   * @param file     the file
   * @param filePath the file path
   * @param mimeType the mime type
   */
  @When("^multipart file (.+) path (.+) mimeType (.+)")
  public void multipartFile(String file, File filePath, String mimeType) {
    this.context.getSpec().addMultiPartFile(file, filePath, mimeType);
  }

  /**
   * Multipart.
   *
   * @param file     the file
   * @param filePath the file path
   * @param mimeType the mime type
   */
  @When("^multipart (.+), (.+), (.+)$")
  public void multipart(String file, String filePath, String mimeType) {
    this.context.getSpec().addMultiPart(file, filePath, mimeType);
  }

  /**
   * Match.
   *
   * @param expected the expected
   */
  @Then("^match$")
  public void match(String expected) {
    JsonMatcherResult result = JsonMatcher.matchJson(this.context.getApi().getResponse().asString(), ScenarioContext.resolve(expected));
    assertTrue(result.getMessage(), result.isSuccess());
  }

  /**
   * Match path.
   *
   * @param path the path
   * @param expr the expr
   */
  @Then("^match path (.+) should be (.+)$")
  public void matchPath(String path, String expr) {
    JsonMatcherResult result = JsonMatcher.matchJson(this.context.getApi().getResponse().asString(), path + " " + ScenarioContext.resolve(expr));
    assertTrue(result.getMessage(), result.isSuccess());
  }

  /**
   * Match each.
   *
   * @param arrayPath the array path
   * @param expected  the expected
   */
  @Then("^match each (.+) should match$")
  public void match_each(String arrayPath, String expected) {
    JsonMatcherResult result = JsonMatcher.matchEach(this.context.getApi().getResponse().asString(), arrayPath, ScenarioContext.resolve(expected));
    assertTrue(result.getMessage(), result.isSuccess());
  }

  /**
   * Match response body path.
   *
   * @param path        the path
   * @param matcherName the matcher name
   * @param expected    the expected
   */
  @Then("^match response body path (.+) should be (.+) (.+)$")
  public void match_response_body_path(String path, String matcherName, String expected) {
    ValidatableResponse vresponse = context.getApi().getResponse().then();
    Matcher<?> matcher = buildMatcher(matcherName, expected);
    vresponse.body(path, matcher);
  }

  /**
   * Match response time.
   *
   * @param milliseconds the milliseconds
   */
  @Then("^match response time should be less than (\\d+) milliseconds")
  public void match_response_time(Long milliseconds) {
    this.context.getApi().getResponse().then().time(lessThan(milliseconds));
  }

}
