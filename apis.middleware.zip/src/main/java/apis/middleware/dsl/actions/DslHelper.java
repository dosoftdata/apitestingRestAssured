package apis.middleware.dsl.actions;


import apis.middleware.core.base.CustomRequestSpec;
import apis.middleware.dsl.ScenarioContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.cucumber.datatable.DataTable;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.Nullable;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.hamcrest.Matcher;

import static org.awaitility.Awaitility.await;
import static org.hamcrest.Matchers.*;

/**
 * The type Dsl helper.
 */
@Slf4j
public abstract class DslHelper{

  /**
   * The Context.
   */
  protected final ScenarioContext context;
  /**
   * The Spec.
   */
  protected CustomRequestSpec spec = null;

  /**
   * The Mapper.
   */
  protected final ObjectMapper mapper = new ObjectMapper();
  /**
   * The Args.
   */
  Map<String, Object> args;

  /**
   * Instantiates a new Dsl helper.
   *
   * @param context the context
   */
  public DslHelper(ScenarioContext context) {
    this.context = context;
  }

  /**
   * Parse data table map.
   *
   * @param dataTable the data table
   * @return the map
   */
  protected Map<String, Object> parseDataTable(DataTable dataTable) {
    args = new HashMap<>();
    if (dataTable != null && !dataTable.isEmpty()) {
      List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
      for (Map<String, String> row : rows) {
        for (Map.Entry<String, String> entry : row.entrySet()) {
          args.put(entry.getKey(), entry.getValue());
        }
      }
    }
    return args;
  }

  /**
   * Parse json map.
   *
   * @param jsonPayload the json payload
   * @return the map
   */
  @SneakyThrows
  protected Map<String, Object> parseJson(String jsonPayload) {
    args = new HashMap<>();
    if (jsonPayload != null && !jsonPayload.trim().isEmpty()) {
      JSONObject json = new JSONObject(jsonPayload);
      var keys = json.keys();
      while (keys.hasNext()) {
        String key = String.valueOf(keys.next());
        args.put(key, json.get(key));
      }
    }
    return args;
  }

  /**
   * Dynamically build a Hamcrest matcher based on the keyword and expected value
   *
   * @param matcherName the matcher name
   * @param value       the value
   * @return the matcher
   */
  protected Matcher<?> buildMatcher(String matcherName, String value) {
    switch (matcherName.toLowerCase()) {

      // --- Basic equality & negation
      case "equalto":
        return equalTo(parseValue(value));
      case "notequalto":
        return not(equalTo(parseValue(value)));
      case "isequalto":
        return is(equalTo(parseValue(value)));
      case "not":
        return not(parseValue(value));

      // --- String matchers
      case "containsstring":
        return containsString(value);
      case "containsignoringcase":
        return containsStringIgnoringCase(value);
      case "startswith":
        return startsWith(value);
      case "endswith":
        return endsWith(value);
      case "equaltoignoringcase":
        return equalToIgnoringCase(value);
      case "equaltoignoringwhitespace":
        return equalToIgnoringWhiteSpace(value);
      case "matchesregex":
      case "matchespattern":
        return matchesPattern(value);

      // --- Numeric comparisons
      case "greaterthan":
        return greaterThan(value.contains(".")  ? Double.parseDouble(value) : Integer.parseInt(value));
      case "greaterthanorequalto":
        return greaterThanOrEqualTo(value.contains(".")  ? Double.parseDouble(value) : Integer.parseInt(value));
      case "lessthan":
        return lessThan(value.contains(".")  ? Double.parseDouble(value) : Integer.parseInt(value));
      case "lessthanorequalto":
        return lessThanOrEqualTo(value.contains(".")  ? Double.parseDouble(value) : Integer.parseInt(value));
      case "closeto":
        return closeTo(Double.parseDouble(value), 0.001);

      // --- Collections
      case "hasitem":
        return hasItem(parseValue(value));
      case "hasitems":
        return hasItems(splitValues(value));
      case "hassize":
        return hasSize(Integer.parseInt(value));
      case "isempty":
        return empty();
      case "everyitemcontains":
        return everyItem(containsString(value));

      // --- Maps
      case "haskey":
        return hasKey(value);
      case "hasvalue":
        return hasValue(parseValue(value));
      case "hasentry": {
        String[] parts = value.split("=", 2);
        if (parts.length < 2)
          throw new IllegalArgumentException("hasEntry expects format key=value");
        return hasEntry(parts[0].trim(), parseValue(parts[1].trim()));
      }

      // --- Null / Existence
      case "nullvalue":
        return nullValue();
      case "notnullvalue":
        return notNullValue();

      // --- Type checking
      case "instanceof": {
        try {
          return instanceOf(Class.forName(value));
        } catch (ClassNotFoundException e) {
          throw new IllegalArgumentException("Invalid class for instanceOf: " + value, e);
        }
      }

      // --- Boolean checkers
      case "istrue":
        return is(true);
      case "isfalse":
        return is(false);

      // --- Default fallback
      default:
        throw new IllegalArgumentException("Unsupported matcher: " + matcherName);
    }
  }
  /**
   * Converts raw string to appropriate type (boolean, number, or string)
   */
  private Object parseValue(String value) {
    if (value == null || value.equalsIgnoreCase("null")) return null;
    if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false"))
      return Boolean.valueOf(value);
    try {
      if (value.contains(".")) return (Object) Double.parseDouble(value);
      return (Object) Integer.parseInt(value);
    } catch (NumberFormatException e) {
      return value; // treat as string
    }
  }

  /***
   * Splits comma-separated expected values into a list
   */
  private Object[] splitValues(String csv) {
    return Arrays.stream(csv.split(","))
        .map(String::trim)
        .map(this::parseValue)
        .toArray();
  }


  @SuppressWarnings("unchecked")
  private <T extends Comparable<T>> T parseComparable(String value) {
    try {
      if (value.contains(".")) {
        return (T) Double.valueOf(value);  // Double implements Comparable<Double>
      } else {
        return (T) Integer.valueOf(value); // Integer implements Comparable<Integer>
      }
    } catch (NumberFormatException e) {
      throw new IllegalArgumentException("Expected numeric value for matcher, got: " + value);
    }
  }
  // ---------------- HELPER ----------------

  /**
   * Parse args map.
   *
   * @param table     the table
   * @param docString the doc string
   * @return the map
   * @throws Exception the exception
   */
  protected Map<String, Object> parseArgs(@Nullable DataTable table, @Nullable String docString) throws Exception {
    if (table != null && !table.isEmpty()) {
      Map<String, Object> args = new HashMap<>();
      table.asMaps().forEach(args::putAll);
      return args;
    }

    if (docString != null && !docString.trim().isEmpty()) {
      return mapper.readValue(docString, Map.class);
    }

    return Collections.emptyMap();
  }

  /**
   * Evaluate condition boolean.
   *
   * @param action      the action
   * @param actualValue the actual value
   * @param expected    the expected
   * @return the boolean
   */
  protected boolean evaluateCondition(String action, Object actualValue, Object expected) {
    switch (action.toLowerCase()) {
      case "equal":
        return Objects.equals(
            String.valueOf(actualValue),
            String.valueOf(expected)
        );
      case "exists":
        return actualValue != null;
      case "contains":
        return actualValue != null && actualValue.toString().contains(String.valueOf(expected));
      case "greater":
        if (actualValue instanceof Number && expected instanceof Number) {
          return ((Number) actualValue).doubleValue() > ((Number) expected).doubleValue();
        }
        return false;
      case "listcontains":
        return actualValue instanceof List<?> list && list.contains(expected);

      case "any":
        return true;

      default:
        throw new IllegalArgumentException("Unknown action: " + action);
    }
  }

  /**
   * Await until.
   *
   * @param method        the method
   * @param path          the path
   * @param conditionJson the condition json
   */
  protected void awaitUntil(String method, String path,  String conditionJson)  {
    // Resolve path
    if (path != null) {
      path = ScenarioContext.resolve(path);
    }
    conditionJson = (conditionJson == null || conditionJson.trim().isEmpty()) ? "{}" : ScenarioContext.resolve(conditionJson);
    JsonPath json = new JsonPath(conditionJson);
    Object expected = json.get("hasValue"); // can be String, Number, Boolean, null
    String bodyPath = json.getString("bodyPath");
    String action   = json.getString("action") != null ? json.getString("action") : "equal";

    Integer minutes        = json.get("minutes")       != null ? json.getInt("minutes") : 5;
    Integer seconds        = json.get("seconds")       != null ? json.getInt("seconds") : 30;
    Integer pollMillis     = json.get("pollMillis")    != null ? json.getInt("pollMillis") : 5000;
    Integer expectedStatus = json.get("status")        != null ? json.getInt("status") : 200;

    CustomRequestSpec originalSpec = context.getSpec();

    AtomicReference<Response> lastResp = new AtomicReference<>();
    AtomicInteger attempts = new AtomicInteger(0);

    String finalPath = path;

    if (finalPath != null) {
      originalSpec.setBasePath(ScenarioContext.resolve(finalPath));
    }
    await()
        .atMost(Duration.ofMinutes(minutes).plusSeconds(seconds))
        .pollInterval(Duration.ofMillis(pollMillis))
        .ignoreExceptions()
        .until(() -> {

          Response resp = context.getRes()
              .spec(originalSpec.build())
              .when().request(method);

          lastResp.set(resp);
          attempts.incrementAndGet();

          boolean statusOk = resp.statusCode() == expectedStatus ||
                             resp.statusCode() == 500;

          Object value = null;
          if (bodyPath != null) {
            try { value = resp.path(bodyPath); } catch (Exception ignored) {}
          }

          boolean bodyOk = (bodyPath == null) ||
                  evaluateCondition(action, value, expected);

          log.info("[Retry] {} {} | status={} | attemps = {} | {}={} | passed={}",
              method, finalPath, resp.statusCode(),attempts.get(), bodyPath, value, statusOk && bodyOk);
          return statusOk && bodyOk;
        });

    this.context.getApi().setResponse(lastResp.get());
  }



}
