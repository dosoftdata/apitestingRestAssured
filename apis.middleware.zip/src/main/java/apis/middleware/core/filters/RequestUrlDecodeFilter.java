package apis.middleware.core.filters;

import io.restassured.filter.Filter;
import io.restassured.filter.FilterContext;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.FilterableResponseSpecification;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import lombok.extern.slf4j.Slf4j;

/**
 * The type Request url decode filter.
 */
@Slf4j
public class RequestUrlDecodeFilter implements Filter {

  @Override
  public Response filter(FilterableRequestSpecification requestSpec,
      FilterableResponseSpecification responseSpec,
      FilterContext ctx) {

      URLDecoder.decode(requestSpec.getURI(), StandardCharsets.UTF_8);

    return ctx.next(requestSpec, responseSpec);
  }
}
